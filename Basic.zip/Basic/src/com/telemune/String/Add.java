package com.telemune.String;

public class Add {
	
	 Add(int a, int b)		{
		
//	a=34;
//	b=89;
	
		 public static void main(String args[]) {
			
			
			Add a =new Add(32,45);
			
			
			
			
			
		

		
			
			
				}
	}

}