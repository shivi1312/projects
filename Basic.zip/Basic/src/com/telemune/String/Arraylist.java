package com.telemune.String;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;

public class Arraylist {
	
//	public static void main(String args[]){  
//		ArrayList<Integer> list=new ArrayList<Integer>();//Creating arraylist  
//		list.add(23);//Adding object in arraylist  
//		list.add(25);  
//		list.add(98);  
//		list.add(89);  
		//Traversing list through Iterator  
//		Iterator itr=list.iterator();  
//		while(itr.hasNext()){  
//		System.out.println(itr.next());  
//		} 
//		
}
