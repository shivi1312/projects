package com.telemune.String;

public class Example {
	
	public void shape() {
		System.out.println("drawing rectangle");
	}
	
	public class Example2 extends Example{
		public void shape() {
			System.out.println("drawing traingle");
		}
		

	public static void main(String[] args) {

		Example e = new Example();
		
		e.shape();
		
		
		
	}

}
}
