package com.telemune.String;

public class Hello {
	public static void main(String[] args) {
		
		String first = "hello"  ;
		String last ="India";
		String Join_string = first.concat(last) ;
		System.out.println(Join_string);
	}
	

}