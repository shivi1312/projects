package com.telemune.String;

import java.util.Scanner;

public class ReverseStringExample1 {
	public static void main(String args[])  
	{  
	String s = "my name is khan";  
	
	System.out.print("After reverse string is: ");  
	for(int i=s.length();i>0;--i)                //i is the length of the string  
	{  
	System.out.print(s.charAt(i-1));            //printing the character at index i-1  
	}  
	}  

}
