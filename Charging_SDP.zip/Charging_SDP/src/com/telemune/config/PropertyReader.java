
package com.telemune.config;

public interface PropertyReader
{
    public static final String USER_NAME = Configuration.getPropertyKey("username");
    public static final String PASS_WORD = Configuration.getPropertyKey("password");
    public static final String Authenticate_Url = Configuration.getPropertyKey("auth_url");
    
    public static final String vendorTxnId=Configuration.getdebitPropertyKey("vendorTxnId");
    public static final String eventName=Configuration.getdebitPropertyKey("eventName");
    public static final String amount=Configuration.getdebitPropertyKey("amount");
    public static final String languageId=Configuration.getdebitPropertyKey("languageId");
    public static final String debit_Url = Configuration.getdebitPropertyKey("debit_url");
    
    
   
    public static final String checkbal_url = Configuration.checkbalancePropertyKey("checkbal_url");
  //  public static final String eventName1=Configuration.checkbalancePropertyKey("eventName1");
    
}