package com.telemune.hit;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;


import com.telemune.process.Internalprocess;
import com.telemune.request.PojoCheckBalance;
import com.telemune.request.Pojodebit;
import com.telemune.request.Pojovalidator;
import com.telemune.response.AuthapiResponse;
import com.telemune.response.CheckbalapiResponse;
import com.telemune.response.DebitapiResponse;

public class APIHits implements IAPImethods
{
	Internalprocess process=new Internalprocess();
	
	@Override
	public AuthapiResponse AuthenticationAPI(Pojovalidator ,String pstUrl)   {
		// TODO Auto-generated method stub
		
		AuthapiResponse resp = null;
		try 
		{
			HttpResponse response=process.getResponse(pojo1, pstUrl,null);
			System.out.println("Response from authenticate:"+response);
			
			if(!(response.getStatusLine().getStatusCode()==200))
			{
				new Internalprocess().StatusCode(response);
			}
			
			String content = null;
            if (response != null)
            {
            	 HttpEntity entity = response.getEntity();
             // Read the contents of an entity and return it as a String.
                 content = EntityUtils.toString(entity);
                 System.out.println("Authenticate Response Converted into String: "+content);
                 JSONObject json_obj = new JSONObject(content);
                 System.out.println("Authenticate Response String to Json Object: "+json_obj);
                 
     			resp=new AuthapiResponse();
     			resp.setResponseCode(json_obj.getInt("responseCode"));
     			resp.setSdpTxnId(json_obj.getString("sdpTxnId"));
     			resp.setAccess_token(json_obj.getString("access_token"));
     			resp.setStatusCode(response. getStatusLine());

            }
			System.out.println("Response Object:"+resp);	
		} 
		
		catch(Exception e)
		{
			e.printStackTrace();
			
		}
	
		return resp;
		
	}


	@Override
	public DebitapiResponse DebitBalance(Pojodebit pojodebit,String debiturl) {

		// TODO Auto-generated method stub
		
		DebitapiResponse resp = null;
		try 
		{
			HttpResponse response=process.getResponse(pojodebit, debiturl,null);
			System.out.println("Response from debit: "+response);
			
			
			if(!(response.getStatusLine().getStatusCode()==200))
			{
				new Internalprocess().StatusCode(response);
			}
			
			String content = null;
            if (response != null)
            {
            	 HttpEntity entity = response.getEntity();
                 // Read the contents of an entity and return it as a String.
                 content = EntityUtils.toString(entity);
                 System.out.println("Debit Response Converted into String: "+content);
                 JSONObject json_obj = new JSONObject(content);
                 System.out.println("Debit Response String to Json Object: "+json_obj);
                 
     			 resp=new DebitapiResponse();
     			 resp.setResponseCode(json_obj.getInt("responseCode"));
     			 resp.setSdpTxnId(json_obj.getString("sdpTxnId"));
     			 resp.setVendorTxnId(json_obj.getString("vendorTxnId"));
     			 resp.setBalance(json_obj.getDouble("balance"));
     			 resp.setStatusCode(response. getStatusLine());

            }
            System.out.println(resp);
			
		} 
		
		catch(Exception e)
		{
			e.printStackTrace();
			
		}
		return resp;
	
	}

	@Override
	public CheckbalapiResponse CheckBalance(PojoCheckBalance pojocheckbalance,String checkbalurl,String Access_token) {
	
		CheckbalapiResponse resp = null;
		try 
		{
			HttpResponse response=process.getResponse(pojocheckbalance, checkbalurl,Access_token);
			System.out.println("Response from checkBalance: "+response);
			
			
			if(!(response.getStatusLine().getStatusCode()==200))
			{
				new Internalprocess().StatusCode(response);
			}
			
			String content = null;
            if (response != null)
            {
            	 HttpEntity entity = response.getEntity();
                 // Read the contents of an entity and return it as a String.
                 content = EntityUtils.toString(entity);
                 System.out.println("CheckBalance Response Converted into String: "+content);
                 JSONObject json_obj = new JSONObject(content);
                 System.out.println("CheckBalance String to Json Object: "+json_obj);
                 
     			 resp=new CheckbalapiResponse();
     			 resp.setResponseCode(json_obj.getInt("responseCode"));
     			 resp.setSdpTxnId(json_obj.getString("sdpTxnId"));
     			 resp.setVendorTxnId(json_obj.getString("vendorTxnId"));
     			 resp.setBalance(json_obj.getDouble("balance"));
     			 resp.setStatusCode(response. getStatusLine());

            }
			System.out.println(resp);
		} 
		
		catch(Exception e)
		{
			e.printStackTrace();
			
		}
		return resp;
	
	
	}

}
