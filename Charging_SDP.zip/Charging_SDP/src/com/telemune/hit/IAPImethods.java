package com.telemune.hit;

import com.telemune.request.PojoCheckBalance;
import com.telemune.request.Pojodebit;
import com.telemune.request.Pojovalidator;
import com.telemune.response.AuthapiResponse;
import com.telemune.response.CheckbalapiResponse;
import com.telemune.response.DebitapiResponse;

public interface IAPImethods {

	public AuthapiResponse AuthenticationAPI(Pojovalidator pojo1,String pstUrl) ;
	
	public DebitapiResponse DebitBalance(Pojodebit pojodebit,String debiturl) ;
	
	public CheckbalapiResponse CheckBalance(PojoCheckBalance checkbalance,String checkbalurl,String Access_token);
	
}
