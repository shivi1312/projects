package com.telemune.main;

import com.telemune.config.PropertyReader;
import com.telemune.hit.APIHits;
import com.telemune.process.Internalprocess;
import com.telemune.response.AuthapiResponse;
import com.telemune.response.CheckbalapiResponse;
import com.telemune.response.DebitapiResponse;

public class ChargingSDP 
{
	
	public static void main(String[] args)
	{
		System.out.println("Charging API Started");
		
		try
		{
		
		  APIHits api=new APIHits();
		  AuthapiResponse response=api.AuthenticationAPI(new Internalprocess().validate(),PropertyReader.Authenticate_Url);
		  
		  if(response!=null)
		  {
			  System.out.println("AythenticateApiResponse Object: "+response);
		  if (response.getStatusCode().getStatusCode()==200) 
		  {
			  
	           System.out.println("Authentication Sucess for username: "+PropertyReader.USER_NAME+" and Password: "+PropertyReader.PASS_WORD);
	           System.out.println("Now going for debit process");
	           
	        	   DebitapiResponse debitresponse=api.DebitBalance(new Internalprocess().Debit(),PropertyReader.debit_Url);
	        	   if(debitresponse!=null)
	        	   {
	        		   		System.out.println(debitresponse);
	        		   		CheckbalapiResponse checkbal=api.CheckBalance(new Internalprocess().CheckBalance(), PropertyReader.checkbal_url,response.getAccess_token());
	        		   		if(checkbal!=null)
	        		   			System.out.println(checkbal);
	        		   		else
	        		   			System.out.println("CheckBalance Response:"+Internalprocess.responsse);
	        	   }
	        	   else
	        	   {
	        		   System.out.println("Debit Response :"+Internalprocess.responsse);
	        	   }
	    
		  		}
		  }
		  else
		  {
			  System.out.println("Authenticate Response :"+Internalprocess.responsse);
		  }
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
