package com.telemune.request;


public class Pojodebit 
{
	private String msisdn;
	private String vendorRequestTime;
	private String vendorTxnId;
	private int vendorId;
	private int serviceId;
	private String eventName;
	private double amount;
	private int languageId;
	
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	public String getVendorRequestTime() {
		return vendorRequestTime;
	}
	public void setVendorRequestTime(String vendorRequestTime) {
		this.vendorRequestTime = vendorRequestTime;
	}
	public String getVendorTxnId() {
		return vendorTxnId;
	}
	public void setVendorTxnId(String vendorTxnId) {
		this.vendorTxnId = vendorTxnId;
	}
	public int getVendorId() {
		return vendorId;
	}
	public void setVendorId(int vendorId) {
		this.vendorId = vendorId;
	}
	public int getServiceId() {
		return serviceId;
	}
	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public int getLanguageId() {
		return languageId;
	}
	public void setLanguageId(int languageId) {
		this.languageId = languageId;
	}

	
	@Override
	public String toString() {
		return "Pojodebit [msisdn=" + msisdn + ", vendorRequestTime=" + vendorRequestTime + ", vendorTxnId="
				+ vendorTxnId + ", vendorId=" + vendorId + ", serviceId=" + serviceId + ", eventName=" + eventName
				+ ", amount=" + amount + ", languageId=" + languageId + "]";
	}
	
	
}
