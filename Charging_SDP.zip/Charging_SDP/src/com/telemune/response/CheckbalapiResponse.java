package com.telemune.response;

import org.apache.http.StatusLine;

public class CheckbalapiResponse 
{
	private int responseCode;
	private String sdpTxnId;
	private String vendorTxnId;
	private double balance;
	private StatusLine statusCode;
	
		public int getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(int responseCode) {
		this.responseCode = responseCode;
	}
	public String getSdpTxnId() {
		return sdpTxnId;
	}
	public void setSdpTxnId(String sdpTxnId) {
		this.sdpTxnId = sdpTxnId;
	}
	public String getVendorTxnId() {
		return vendorTxnId;
	}
	public void setVendorTxnId(String vendorTxnId) {
		this.vendorTxnId = vendorTxnId;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public StatusLine getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(StatusLine statusCode) {
		this.statusCode = statusCode;
	}
	@Override
	public String toString() {
		return "CheckbalapiResponse [responseCode=" + responseCode + ", sdpTxnId=" + sdpTxnId + ", vendorTxnId="
				+ vendorTxnId + ", balance=" + balance + ", statusCode=" + statusCode + "]";
	}
}
