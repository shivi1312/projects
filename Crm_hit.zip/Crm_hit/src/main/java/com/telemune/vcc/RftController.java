package com.telemune.vcc;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;


@Controller
public class RftController {
	
	@Autowired
	RftInterface rftInterface;
	
	String autofulfilment_url="https://tibcoprod.etisalat.corp.ae:9157/Etisalat/Falcon/Tibco/IIT/DOM_CC/CustomerManagement/BS_SelfCareService";

	@PostMapping("/hlr")
	public String createHLR(@RequestBody String  autofulfilment_url) {
		try {

			
			System.out.println("try method ");
			
				String  response  = rftInterface.sendRequest(autofulfilment_url);
				System.out.println("request sent successfully ");
				
		
		}
		
catch (Exception e) {
e.printStackTrace();
System.out.println(e);


}
		return autofulfilment_url;
		
	}
}
