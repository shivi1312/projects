package com.telemune.vcc;


public interface RftInterface {
	public String sendRequest(String  autofulfilment_url);
}
