package com.telemune.vcc;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.springframework.stereotype.Service;

@Service
public class RftServiceImpl implements RftInterface{

	@Override
	public String sendRequest(String autofulfilment_url) {
//		int retVal= -1;

		 CloseableHttpClient   httpClient    = HttpClientBuilder.create().build();
		HttpGet request = new HttpGet(autofulfilment_url);
try {
		 HttpResponse response = httpClient.execute(request);
		  
		 
		int responseCode=response.getStatusLine().getStatusCode();
		 System.out.println(responseCode);
		     
			
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e);
		}

		       
			
		return "done";
	}

}
