# Spring Boot - MAKING API REQUESTS USING RESTTEMPLATE

This project is the source code of my Youtube Video: https://youtu.be/6ACathFnEw8