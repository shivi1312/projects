package com.buinam.youtubespringrestemplate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YoutubeSpringRestemplateApplicationTests {

	@Test
	void contextLoads() {
	}

}
