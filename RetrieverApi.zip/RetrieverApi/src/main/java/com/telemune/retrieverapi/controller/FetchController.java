package com.telemune.retrieverapi.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.telemune.retrieverapi.Entity.GmatMsg_0;
import com.telemune.retrieverapi.repository.GmatRepository_0;
import com.telemune.retrieverapi.request.SmsgBean;

@RestController
public class FetchController {
	
	@Autowired
	GmatRepository_0 repo;

@GetMapping("/details")
public int getAllNotes()
{
	Iterable<GmatMsg_0> gmat = repo.findAll();
	gmat.forEach((g) -> {
		String destination =g.getDestination();
		String origination=g.getOrigin();
		String message=g.getMessage();
		
		System.out.println(destination);
		System.out.println(origination);
		System.out.println(message);
	});


//	retrieverImpl.getData(smsgbean , gmat);
  //  System.out.println(bean.setDestination_number(destination));

return 1;
}

}   


//{
//return repo.findAll();
//}
//
//}


