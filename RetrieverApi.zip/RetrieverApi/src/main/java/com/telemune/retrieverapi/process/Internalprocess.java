package com.telemune.retrieverapi.process;


import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Random;
import java.util.Scanner;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;

import com.google.gson.Gson;
import com.telemune.config.PropertyReader;
import com.telemune.request.PojoCheckBalance;
import com.telemune.request.Pojodebit;
import com.telemune.request.Pojovalidator;

public class Internalprocess 
{
		
	public static String responsse = null;
	private static  String msisdn;
	private static String strDate;
	private static int vendorId;
	private static int serviceId;
	
	public Pojovalidator validate() throws Exception
	{
		Pojovalidator pojo=new Pojovalidator();
		pojo.setUsername(PropertyReader.USER_NAME); pojo.setPassword(PropertyReader.PASS_WORD);
		return pojo;
	}
	
	public Pojodebit Debit() throws Exception
	{
	
				System.out.print("Enter Mobile No:");
				 msisdn=new Scanner(System.in).next();
				System.out.println(msisdn);
		
				System.out.println("Calender Date");
				 strDate = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss").format(Calendar.getInstance().getTime());
				System.out.println(strDate);
		
	    
	    Pojodebit pojodebit=new Pojodebit();
	    
	    pojodebit.setMsisdn(msisdn);
	    pojodebit.setVendorRequestTime(strDate);
	    pojodebit.setVendorTxnId(PropertyReader.vendorTxnId);
	    
	    vendorId=new Random().nextInt();
	    pojodebit.setVendorId(vendorId);
	    serviceId=new Random().nextInt();
	    pojodebit.setServiceId(serviceId); 
	    
	    pojodebit.setEventName(PropertyReader.eventName);
	    pojodebit.setAmount(Double.parseDouble(PropertyReader.amount));
	    pojodebit.setLanguageId(Integer.parseInt(PropertyReader.languageId)); 
		
	   
		
		return pojodebit;
	}
	
	public PojoCheckBalance CheckBalance() throws Exception
	{
	
	    
	    PojoCheckBalance checkBalance=new PojoCheckBalance();
	    
	    checkBalance.setMsisdn(msisdn);
	    checkBalance.setVendorRequestTime(strDate);
	    checkBalance.setVendorTxnId(PropertyReader.vendorTxnId);
	    
	    checkBalance.setVendorId(vendorId);
	    checkBalance.setServiceId(serviceId); 
	  
	    checkBalance.setEventName(PropertyReader.eventName);
	    checkBalance.setLanguageId(Integer.parseInt(PropertyReader.languageId)); 
	    
		return checkBalance;
		
	}
	
	public HttpResponse getResponse(Object pojo,String url,String Access_token) throws IOException
	{
		String       postUrl       = url;// put in your url
		Gson         gson          = new Gson();
		HttpClient   httpClient    = HttpClientBuilder.create().build();
		HttpPost     post          = new HttpPost(postUrl);
		StringEntity postingString;
	
		postingString = new StringEntity(gson.toJson(pojo));
		post.setEntity(postingString);
		post.setHeader("Content-type", "application/json");
		
		if(url.equals("http://10.168.3.51:8080/chargingSDPApi/checkBalance/"))
		{
			post.setHeader("Authorization", "Bearer " + Access_token);
			//post.setHeader(HttpHeaders.AUTHORIZATION, "Bearer " + Access_token);
		}
		
		HttpResponse  response = httpClient.execute(post);
		System.out.println("Response from debit: "+response);
		
		return response;
		
	}
	
	public void StatusCode(HttpResponse response)
	{
		
		
		if(response.getStatusLine().getStatusCode()==401)
			responsse="Unauthorized request";
		else if(response.getStatusLine().getStatusCode()==429)
			responsse="Too Many Requests";
		else if(response.getStatusLine().getStatusCode()==500)
			responsse="UnValidate Request";
		else if(response.getStatusLine().getStatusCode()==406)
			responsse="Cache Problem";
		else
			responsse="response Problem Unkonwn";
		
	}
	
	
}
