package com.telemune.retrieverapi.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonView;

public class SmsgBean {

	@JsonProperty("Origination_number")
	@JsonView
	private String Origination_number;

	@JsonProperty("Destination_number")
	@JsonView
	private String Destination_number;

	@JsonProperty("Message")
	@JsonView
	private String Message;

	public String getOrigination_number() {
		return Origination_number;
	}

	
	public void setOrigination_number(String origination_number) {
		Origination_number = origination_number;
	}



	public String getDestination_number() {
		return Destination_number;
	}

	public SmsgBean() {
		super();
		// TODO Auto-generated constructor stub
	}

	public void setDestination_number(String destination_number) {
		Destination_number = destination_number;
	}

	public String getMessage() {
		return Message;
	}

	public void setMessage(String message) {
		this.Message = message;
	}


	@Override
	public String toString() {
		return Origination_number + "," + Destination_number + "," + Message;
	}

	
	



}