package com.telemune.retrieverapi.service;


public interface IAPImethods {

	public AuthapiResponse AuthenticationAPI(Pojovalidator pojo1,String pstUrl) ;
	
	
	
	public CheckbalapiResponse Sendsms(PojoCheckBalance checkbalance,String checkbalurl,String Access_token);
	
}
