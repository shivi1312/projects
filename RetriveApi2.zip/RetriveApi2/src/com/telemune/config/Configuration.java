package com.telemune.config;

import java.io.FileReader;
import java.util.Properties;

public class Configuration
{
    public static String getPropertyKey(String key) 
    {
    	final Properties prop=new Properties(); 
        try 
        {
        	FileReader reader=new FileReader("application.properties");  
            prop.load(reader);  
            return prop.getProperty(key);
        }
        catch (Exception ex) 
        {
            ex.printStackTrace();
        }
        return prop.getProperty(key);
    }
    
   
    
    public static String checkbalancePropertyKey(String key) 
    {
    	final Properties prop=new Properties(); 
        try 
        {
        	FileReader reader=new FileReader("sendsms.properties");  
            prop.load(reader);  
            return prop.getProperty(key);
        }
        catch (Exception ex) 
        {
            ex.printStackTrace();
        }
        return prop.getProperty(key);
    }
}