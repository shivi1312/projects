
package com.telemune.config;

public interface PropertyReader
{
    
    public static final String Authenticate_Url = Configuration.getPropertyKey("auth_url");
    public static final String sendsms_url = Configuration.checkbalancePropertyKey("sendsmss_url");
    public static final String USER_NAME = Configuration.getPropertyKey("username");
    public static final String PASS_WORD = Configuration.getPropertyKey("password");
}