package com.telemune.hit;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;

import com.telemune.process.Internalprocess;
import com.telemune.request.Pojovalidator;
import com.telemune.request.SendSmsRequest;
import com.telemune.response.AuthapiResponse;
import com.telemune.response.SendSmsResponse;

public class APIHits implements IAPImethods
{

	Internalprocess process=new Internalprocess();
	
	@Override
	public AuthapiResponse AuthenticationAPI(Pojovalidator pojo1, String pstUrl) {

		
		AuthapiResponse resp = null;
		try 
		{
			HttpResponse response=process.getResponse(pojo1, pstUrl,null);
			System.out.println("Response from authenticate:"+response);
			
			if(!(response.getStatusLine().getStatusCode()==200))
			{
				new Internalprocess().StatusCode(response);
			}
			
			String content = null;
            if (response != null)
            {
            	 HttpEntity entity = response.getEntity();
             // Read the contents of an entity and return it as a String.
                 content = EntityUtils.toString(entity);
                 System.out.println("Authenticate Response Converted into String: "+content);
                 JSONObject json_obj = new JSONObject(content);
                 System.out.println("Authenticate Response String to Json Object: "+json_obj);
                 
     			resp=new AuthapiResponse();
     			resp.setResponseCode(json_obj.getInt("responseCode"));
     			resp.setAccess_token(json_obj.getString("access_token"));
     			resp.setStatusCode(response. getStatusLine());

            }
			System.out.println("Response Object:"+resp);	
		} 
		catch(Exception e)
		{
			e.printStackTrace();
			
		}
	
		return resp;
	}

	@Override
	public SendSmsResponse SendSms(SendSmsRequest sendsms,String sendsmsurl,String Access_token) 
	{
	
		SendSmsResponse resp = null;
		try 
		{
			HttpResponse response=process.getResponse(sendsms, sendsmsurl,Access_token);
			System.out.println("Response from sendSms: "+response);
			
			
			if(!(response.getStatusLine().getStatusCode()==200))
			{
				new Internalprocess().StatusCode(response);
			}
			
			String content = null;
            if (response != null)
            {
            	 HttpEntity entity = response.getEntity();
                 // Read the contents of an entity and return it as a String.
                 content = EntityUtils.toString(entity);
                 System.out.println("SendSms Response Converted into String: "+content);
                 JSONObject json_obj = new JSONObject(content);
                 System.out.println("SendSms String to Json Object: "+json_obj);
                 
     			 resp=new SendSmsResponse();
     			 resp.setResponseCode(json_obj.getInt("responseCode"));
     			 resp.setStatusCode(response. getStatusLine());

            }
			System.out.println(resp);
		} 
		
		catch(Exception e)
		{
			e.printStackTrace();
			
		}
		return resp;
	}
	
	
//    @Override
//	public AuthapiResponse AuthenticationAPI(Pojovalidator pojo1, String pstUrl) {
//
//		
//		AuthapiResponse resp = null;
//		try 
//		{
//			HttpResponse response=process.getResponse(pojo1, pstUrl,null);
//			System.out.println("Response from authenticate:"+response);
//			
//			if(!(response.getStatusLine().getStatusCode()==200))
//			{
//				new Internalprocess().StatusCode(response);
//			}
//			
//			String content = null;
//            if (response != null)
//            {
//            	 HttpEntity entity = response.getEntity();
//             // Read the contents of an entity and return it as a String.
//                 content = EntityUtils.toString(entity);
//                 System.out.println("Authenticate Response Converted into String: "+content);
//                 JSONObject json_obj = new JSONObject(content);
//                 System.out.println("Authenticate Response String to Json Object: "+json_obj);
//                 
//     			resp=new AuthapiResponse();
//     			resp.setResponseCode(json_obj.getInt("responseCode"));
//     			resp.setAccess_token(json_obj.getString("access_token"));
//     			resp.setStatusCode(response. getStatusLine());
//
//            }
//			System.out.println("Response Object:"+resp);	
//		} 
//		
//		catch(Exception e)
//		{
//			e.printStackTrace();
//			
//		}
//	
//		return resp;
//		
//	}

}
