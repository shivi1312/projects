package com.telemune.hit;


import com.telemune.request.Pojovalidator;
import com.telemune.request.SendSmsRequest;
import com.telemune.response.AuthapiResponse;
import com.telemune.response.SendSmsResponse;


public interface IAPImethods {

	public AuthapiResponse AuthenticationAPI(Pojovalidator pojo1,String pstUrl) ;
	

	
	public SendSmsResponse SendSms(SendSmsRequest sendsms,String sendsmsurl,String Access_token);
	
}
