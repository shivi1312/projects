package com.telemune.main;

import com.telemune.config.PropertyReader;
import com.telemune.hit.APIHits;
import com.telemune.process.Internalprocess;
import com.telemune.response.AuthapiResponse;

import com.telemune.response.SendSmsResponse;

public class Retrieverapi 
{
	
	public static void main(String[] args)
	{
		System.out.println("Retriever API Started");
		
		try
		{
		
		  APIHits api=new APIHits();
		  AuthapiResponse response=api.AuthenticationAPI(new Internalprocess().validate(),PropertyReader.Authenticate_Url);
		  
		  if(response!=null)
		  {
			  System.out.println("AythenticateApiResponse Object: "+response);
		  if (response.getStatusCode().getStatusCode()==200) 
		  {
			  
	        		   		
	        		   		SendSmsResponse sendsms=api.SendSms(new Internalprocess().SendSms(), PropertyReader.sendsms_url,response.getAccess_token());
	        		   		if(sendsms!=null) 
	        		   		
	        		   			System.out.println(sendsms);
	        		   		else
	        		   			System.out.println("SendSms Response:"+Internalprocess.responsse);
	        	  
		  }
		  else
		  {
			  System.out.println("Authenticate Response :"+Internalprocess.responsse);
		  }
		  }
		  
		
	}
		catch(Exception e)
		{
			e.printStackTrace();
		}
}
}
