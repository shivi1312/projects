package com.telemune.process;


import java.beans.Statement;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Random;
import java.util.Scanner;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;

import com.google.gson.Gson;
import com.telemune.config.PropertyReader;

import com.telemune.request.Pojovalidator;
import com.telemune.request.SendSmsRequest;

public class Internalprocess 
{
		
	public static String responsse = null;
	
//	 static final String DB_URL = "jdbc:mysql://192.168.1.102:3306/test_new";
//	   static final String USER = "umang";
//	   static final String PASS = "umang";
//	   static final String QUERY = "SELECT username, password FROM smsc_user";

//	private char[] val;
//
//	private char[] reason;
	
	public Pojovalidator validate() throws Exception
	{
		Pojovalidator pojo=new Pojovalidator();
		pojo.setUsername(PropertyReader.USER_NAME); pojo.setPassword(PropertyReader.PASS_WORD);
		return pojo;
	}
	

		  
		 // Open a connection
//	      try
//	      		{
//	    	  Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
//	      		
//	         java.sql.Statement stmt = conn.createStatement();
//	         ResultSet rs = stmt.executeQuery(QUERY);
//	      
//	      
//	      	      
//
//				       while(rs.next()){
	         
	         
//	            System.out.print(", username: " + rs.getString("username"));
//	            System.out.print(", password: " + rs.getString("password"));
//	         }
//      
	      
//	         if(rs.next()) {              // here
//	             String val = rs.getString("username");
//	             String reason = rs.getString("password");
//	           }
//	         System.out.println(val);
//	         System.out.println(reason);

	         
	        
	     
		   
		
//		pojo.setUsername(rs.getString("username")); pojo.setPassword(rs.getString("password"));
//	      		}
//	      catch (SQLException e) {
//		         e.printStackTrace();
//		      } 
//	      System.out.println("credential set in bean");
//		return pojo;
//	
//	
	
	
	
	
	 SendSmsRequest sendsms=new SendSmsRequest();
		 static final String DB_URL1 = "jdbc:mysql://192.168.1.102:3306/test_new";
		   static final String USER1 = "umang";
		   static final String PASS1 = "umang";
		   static final String QUERY1 = "SELECT Origination_number, Destination_number, Message FROM gmat_message_store";
	public SendSmsRequest SendSms() throws Exception
	{
	
		      // Open a connection
		      try
		      {
		    	  Connection conn = DriverManager.getConnection(DB_URL1, USER1, PASS1);
		    	  java.sql.Statement stmt = conn.createStatement();
			         ResultSet rs = stmt.executeQuery(QUERY1);
			         while(rs.next())
			         {
				            //Display values
				            System.out.print(", Origination_number: " + rs.getString("Origination_number"));
				            System.out.print(", Destination_number: " + rs.getString("Destination_number"));
				            System.out.print(", Message: " + rs.getString("Message"));
				     }
			         sendsms.setOrigination_number(rs.getString("origination_number"));
				      sendsms.setDestination_number(rs.getString("destination_number"));
				      sendsms.setMessage(rs.getString("message"));
		      }
		              
		    catch (SQLException e) 
		      {
		         e.printStackTrace();
		      } 
	    
		      
	    
	    
		return sendsms;
		
	}

	
	public HttpResponse getResponse(Object pojo,String url,String Access_token) throws IOException
	{
		String       postUrl       = url;// put in your url
		Gson         gson          = new Gson();
		HttpClient   httpClient    = HttpClientBuilder.create().build();
		HttpPost     post          = new HttpPost(postUrl);
		StringEntity postingString;
	
		postingString = new StringEntity(gson.toJson(pojo));
		post.setEntity(postingString);
		post.setHeader("Content-type", "application/json");
		
		if(url.equals("http://192.168.1.106:9195/sendsms"))
		{
			post.setHeader("Authorization", "Bearer " + Access_token);
			//post.setHeader(HttpHeaders.AUTHORIZATION, "Bearer " + Access_token);
		}
		
		HttpResponse  response = httpClient.execute(post);
		System.out.println("Response from SendSms: "+response);
		
		return response;
		
	}
	
	public void StatusCode(HttpResponse response)
	{
		
		
		if(response.getStatusLine().getStatusCode()==401)
			responsse="Unauthorized request";
		else if(response.getStatusLine().getStatusCode()==200)
			responsse="The request was fulfilled";
		else if(response.getStatusLine().getStatusCode()==429)
			responsse="Too Many Requests";
		else if(response.getStatusLine().getStatusCode()==500)
			responsse="UnValidate Request";
		else if(response.getStatusLine().getStatusCode()==406)
			responsse="Cache Problem";
		else
			responsse="response Problem Unkonwn";
		
	}
	
	
}
