package com.telemune.request;


public class SendSmsRequest {

	
	private String Origination_number;
private String Destination_number;

	
	private String Message;

	
	public String getOrigination_number() {
		return Origination_number;
	}


	public void setOrigination_number(String origination_number) {
		Origination_number = origination_number;
	}


	public String getDestination_number() {
		return Destination_number;
	}


	public void setDestination_number(String destination_number) {
		Destination_number = destination_number;
	}


	public String getMessage() {
		return Message;
	}


	public void setMessage(String message) {
		Message = message;
	}


	



	
	
	



}