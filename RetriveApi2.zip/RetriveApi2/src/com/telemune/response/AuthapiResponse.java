package com.telemune.response;

import org.apache.http.StatusLine;



public class AuthapiResponse {
	

	private int responseCode;
	private String access_token;
	private StatusLine statusCode;
	
	public int getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(int responseCode) {
		this.responseCode = responseCode;
	}
	
	
	public String getAccess_token() {
		return access_token;
	}
	public void setAccess_token(String access_token) {
		this.access_token = access_token;
	}
	public StatusLine getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(StatusLine statusCode) {
		this.statusCode = statusCode;
	}
	
	
	@Override
	public String toString() {
		return "AuthapiResponse [responseCode=" + responseCode + ", sdpTxnId=" + ", access_token="
				+ access_token + ", statusCode=" + statusCode + "]";
	}

}
