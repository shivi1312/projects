package com.telemune.response;

import org.apache.http.StatusLine;

public class SendSmsResponse 
{
	private int responseCode;
	
	private StatusLine statusCode;
	
		@Override
	public String toString() {
		return "SendSmsResponse [responseCode=" + responseCode + ", statusCode=" + statusCode + "]";
	}
		public int getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(int responseCode) {
		this.responseCode = responseCode;
	}
	
	public StatusLine getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(StatusLine statusCode) {
		this.statusCode = statusCode;
	}
}
	
