package com.telemune.smscapi.config;

import java.util.Hashtable;

import org.hibernate.annotations.Synchronize;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.web.context.SaveContextOnUpdateOrErrorResponseWrapper;

import FileBaseLogging.FileLogWriter;

@Configuration

public  class GlobalParams {

	
	private static FileLogWriter fileLogWriter = new FileLogWriter();
	
	@Bean
	public FileLogWriter getFileLogWriter()
	{
		
		return fileLogWriter;
	}

	
	private static Hashtable<String,String> responseData =new Hashtable<String,String>();
	
	public void defineErrorCodes()
	{
		responseData.put("-101", "Origination Number Not Valid");
		responseData.put("-200", "Destination Number can not be NULL ");
		responseData.put("-301", "Message Number Not Valid");
		responseData.put("-202", "Destination Number Not Valid");
		responseData.put("-102", "Orignation Number Not Valid, it reaches maximum size");
		responseData.put("-300", "Message is too long");
		responseData.put("100","Request Accepted Successfully");
		
	}
	public String getResponseString(String responseCode)
	{
		return responseData.get(responseCode);
	}

}
