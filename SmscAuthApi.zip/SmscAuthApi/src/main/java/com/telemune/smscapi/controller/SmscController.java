package com.telemune.smscapi.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.tomcat.jni.Address;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.telemune.smscapi.config.GlobalParams;
import com.telemune.smscapi.dao.GmatMessageStore;
import com.telemune.smscapi.dao.GmatMessageStoreImpl;
import com.telemune.smscapi.model.ResponseBean;
import com.telemune.smscapi.model.SmsgBean;
import com.telemune.smscapi.model.UserDTO;
import com.telemune.smscapi.service.SmsgService;




@RestController
public class SmscController {
	@Autowired
 private  SmsgService smscserviceimpl;
@Autowired
 private GmatMessageStoreImpl gmatMessageStoreImpl;

	private static final Logger logger = LogManager.getLogger(SmscController.class);
	@Autowired(required = true)
	private GlobalParams globalParams;
	@RequestMapping(value = "/sendsms", method = RequestMethod.POST)
	public ResponseEntity saveSms(@RequestBody SmsgBean smsgBean)
	{
		ResponseBean respBean=new ResponseBean("-201","Request Not Accepted");
try {
	
			logger.info(smsgBean.toString());
			
			System.out.println(smsgBean.toString());
			String responseCode=gmatMessageStoreImpl.addGmatMessageStore(smsgBean)+"";
			if(responseCode.equalsIgnoreCase("1"))
			{
				responseCode="100";
			}
			String responseString=globalParams.getResponseString(responseCode);
			if(responseString!=null)
			{
				respBean=new ResponseBean(responseCode, responseString);
				logger.info("Sms Sent");
			}
			else
			{	
				 respBean=new ResponseBean("-201","Request Not Accepted");
				logger.info("Some Error Occured");
			}
			
			
			
}
catch (Exception e) {
	e.printStackTrace();
}			

			return new ResponseEntity<ResponseBean>(respBean,HttpStatus.OK); 




}

}