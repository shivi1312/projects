package com.telemune.smscapi.dao;

import com.telemune.smscapi.model.SmsgBean;

public interface GmatMessageStore {

	int addGmatMessageStore(SmsgBean smsgBean);
}
