package com.telemune.smscapi.dao;

import com.telemune.smscapi.config.GlobalParams;
import com.telemune.smscapi.model.SmsgBean;
import com.telemune.smscapi.serviceImpl.SmscServiceImpl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
@Repository
public class GmatMessageStoreImpl {
	@Autowired
	private Environment environment;
	private final JdbcTemplate jdbcTemplate;
	private static final Logger logger = LogManager.getLogger(GmatMessageStoreImpl.class);
	@Autowired(required = true)
	private GlobalParams globalParams;
	@Autowired
	   public GmatMessageStoreImpl(JdbcTemplate jdbcTemplate) {
	       this.jdbcTemplate = jdbcTemplate;
	   }
	
	public int addGmatMessageStore(SmsgBean smsgBean)
	{
		try
		{
			if(smsgBean.getOrigination()==null)
			{
				return -101;
			}
			if(smsgBean.getDestination()==null)
			{
				return -200;
			}
			if(smsgBean.getMessage()==null)
			{
				return -301;
			}
			if(smsgBean.getDestination().length()!=Integer.parseInt(this.environment.getProperty("DESTINATION_NUMBER_LENGTH")))
			{
				return -202;
			}
			if(!smsgBean.getDestination().matches("[0-9]+"))
			{
				return -202;
			}
			if(smsgBean.getOrigination().length()>Integer.parseInt(this.environment.getProperty("DESTINATION_NUMBER_LENGTH")))
			{
				return -102;
			}
			if(smsgBean.getMessage().length()>Integer.parseInt(this.environment.getProperty("MESSAGE_LENGTH")))
			{
				return -300;
			}
			
			
			  makeCallLogs(smsgBean);
		 int lastchar=smsgBean.getDestination().length();
		 String sql = "INSERT into unip.gmat_message_store_"+smsgBean.getDestination().substring(lastchar-1,lastchar)+"(DESTINATION_NUMBER,ORIGINATING_NUMBER,MESSAGE_TEXT,submit_time) VALUES (?,?,?,now())";
		 
		  return jdbcTemplate.update(sql, smsgBean.getDestination(),
		           smsgBean.getOrigination(),
		           smsgBean.getMessage());
	
		}
		catch(Exception e)
		{
			e.printStackTrace();  
		}
		return 0;
	}
	public synchronized void makeCallLogs(SmsgBean smsgbean) {
		try {
			globalParams.getFileLogWriter().writeLog(smsgbean.toString());
			logger.info("Details inserted into File"+ smsgbean.toString());
		} catch (Exception e) {
			e.printStackTrace();
			
		}
	}
}
