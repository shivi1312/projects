package com.telemune.smscapi.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonView;

public class SmsgBean {

	@JsonProperty("Origination")
	@JsonView
	private String origination;

	@JsonProperty("Destination")
	@JsonView
	private String destination;

	@JsonProperty("Message")
	@JsonView
	private String Message;

	
	
	
	public SmsgBean() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	public String getMessage() {
		return Message;
	}

	public void setMessage(String message) {
		this.Message = message;
	}


	public String getOrigination() {
		return origination;
	}


	public void setOrigination(String origination) {
		this.origination = origination;
	}


	public String getDestination() {
		return destination;
	}


	public void setDestination(String destination) {
		this.destination = destination;
	}


	@Override
	public String toString() {
		return origination + "#,#" + destination + "#,#" + Message+",#SMS_SENT#,";
	}

	
	



}