package com.telemune.smscapi.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.telemune.smscapi.model.GmatMsg;




	@Repository
	public interface GmatRepository extends JpaRepository<GmatMsg, Integer>{

	
	}


