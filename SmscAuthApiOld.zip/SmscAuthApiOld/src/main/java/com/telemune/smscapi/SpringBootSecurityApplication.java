package com.telemune.smscapi;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.env.Environment;

import com.telemune.smscapi.config.GlobalParams;



@SpringBootApplication
public class SpringBootSecurityApplication implements CommandLineRunner{

	@Autowired
	private GlobalParams globalParams;
	
	@Autowired
	private Environment environment;

	
	public static void main(String[] args) {
		SpringApplication.run(SpringBootSecurityApplication.class, args);
	}

	private void loadFileLogWriterConfiguration() {
		try {
			
			String FileName = this.environment.getProperty("SMSC_LOG_FILE_NAME");
			String FilePath = this.environment.getProperty("SMSC_LOG_FILE_PATH");
			

			globalParams.getFileLogWriter().setFilename(FileName);
			globalParams.getFileLogWriter().setFilePath(FilePath);
			
			globalParams.getFileLogWriter()
		     .setNewFileInterval(Integer.parseInt(this.environment.getProperty("SMSC_LOG_FILE_INTERVAL")));
			globalParams.getFileLogWriter().initialize();
		} catch (Exception e) {
		}
	}

	@Override
 public void run(String... args) throws Exception {
		loadFileLogWriterConfiguration();
	}
}
