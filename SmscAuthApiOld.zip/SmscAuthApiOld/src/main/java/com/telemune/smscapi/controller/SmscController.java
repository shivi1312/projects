package com.telemune.smscapi.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.telemune.smscapi.model.SmsgBean;
import com.telemune.smscapi.service.SmsgService;




@RestController
public class SmscController {
	@Autowired
 private  SmsgService smscserviceimpl;



	private static final Logger logger = LogManager.getLogger(SmscController.class);

	@GetMapping("/recieve")
	public ResponseEntity saveSms(@RequestParam("Origination_number") String Origination, @RequestParam("destination_number") String destination,
	@RequestParam("message") String message)
	{
try {
           
			SmsgBean smsgbean = new SmsgBean();
			smsgbean.setOrigination_number(Origination);
			smsgbean.setDestination_number(destination);
			smsgbean.setMessage(message);
			logger.info(smsgbean.toString());

			smscserviceimpl.sendSMS(smsgbean, Origination, destination ,message);
			
			logger.info("Sms Sent");
}
catch (Exception e) {
	e.printStackTrace();
}			


			return ResponseEntity.status(HttpStatus.OK).body("OK");




}

}