package com.telemune.smscapi.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import org.hibernate.annotations.DynamicInsert;

@Entity
@DynamicInsert
@Table(name = "gmat_message_store_1")
public class GmatMsg_1 {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "RESPONSE_ID")
	private Integer responseId;

	public GmatMsg_1() {
        super();
    }
	
    @NotBlank
	@Size(max = 15)
	@Column(name = "ORIGINATING_NUMBER")
	private String origin;

	@NotBlank
	@Size(max = 15)
	@Column(name = "DESTINATION_NUMBER")
	private String destination;


	@Size(max = 400)
	@Column(name = "MESSAGE_TEXT")
	private String message;




	@Size(max = 40)
	@Column(name = "SUBMIT_TIME")
	private String submitTime;


	@Size(max = 120)
	@Column(name = "MESSAGE_TYPE")
	private String msgType;


	@Size(max = 120)
	@Column(name = "LANGUAGE")
	private String language;


	@Size(max = 120)
	@Column(name = "UDH")
	private String udh;


	@Size(max = 120)
	@Column(name = "STATUS_REPORT")
	private String statusReport;

	public Integer getResponseId() {
		return responseId;
	}


	public void setResponseId(Integer responseId) {
		this.responseId = responseId;
	}





	public String getOrigin() {
		return origin;
	}


	public void setOrigin(String origin) {
		this.origin = origin;
	}


	public String getDestination() {
		return destination;
	}


	public void setDestination(String destination) {
		this.destination = destination;
	}


	public String getMessage() {
		return message;
	}


	public void setMessage(String message) {
		this.message = message;
	}


	public String getSubmitTime() {
		return submitTime;
	}


	public void setSubmitTime(String submitTime) {
		this.submitTime = submitTime;
	}


	public String getMsgType() {
		return msgType;
	}


	public void setMsgType(String msgType) {
		this.msgType = msgType;
	}


	public String getLanguage() {
		return language;
	}


	public void setLanguage(String language) {
		this.language = language;
	}


	public String getUdh() {
		return udh;
	}


	public void setUdh(String udh) {
		this.udh = udh;
	}


	public String getStatusReport() {
		return statusReport;
	}


	public void setStatusReport(String statusReport) {
		this.statusReport = statusReport;
	}


	public String getDataCodingScheme() {
		return dataCodingScheme;
	}


	public void setDataCodingScheme(String dataCodingScheme) {
		this.dataCodingScheme = dataCodingScheme;
	}


	public String getProtocol() {
		return protocol;
	}


	public void setProtocol(String protocol) {
		this.protocol = protocol;
	}


	public String getPriority() {
		return priority;
	}


	public void setPriority(String priority) {
		this.priority = priority;
	}


	public String getChargingCode() {
		return chargingCode;
	}


	public void setChargingCode(String chargingCode) {
		this.chargingCode = chargingCode;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public String getValidity() {
		return validity;
	}


	public void setValidity(String validity) {
		this.validity = validity;
	}


	public String getMsgId() {
		return msgId;
	}


	public void setMsgId(String msgId) {
		this.msgId = msgId;
	}


	public String getInterfaceId() {
		return interfaceId;
	}


	public void setInterfaceId(String interfaceId) {
		this.interfaceId = interfaceId;
	}


	public String getInterfaceType() {
		return interfaceType;
	}


	public void setInterfaceType(String interfaceType) {
		this.interfaceType = interfaceType;
	}


	public String getDestinationPort() {
		return destinationPort;
	}


	public void setDestinationPort(String destinationPort) {
		this.destinationPort = destinationPort;
	}


	public String getCampaignId() {
		return campaignId;
	}


	public void setCampaignId(String campaignId) {
		this.campaignId = campaignId;
	}


	public String getRetryCount() {
		return retryCount;
	}


	public void setRetryCount(String retryCount) {
		this.retryCount = retryCount;
	}



	@Size(max = 120)
	@Column(name = "DATA_CODING_SCHEME")
	private String dataCodingScheme;



	@Size(max = 120)
	@Column(name = "PROTOCOL_IDENTIFIER")
	private String protocol;


	@Size(max = 120)
	@Column(name = "PRIORITY")
	private String priority;


	@Size(max = 120)
	@Column(name = "CHARGING_CODE")
	private String chargingCode;



	@Size(max = 120)
	@Column(name = "STATUS")
	private String status;



	@Size(max = 120)
	@Column(name = "VALIDITY_PERIOD")
	private String validity;



	@Size(max = 120)
	@Column(name = "MESSAGE_ID")
	private String msgId;



	@Size(max = 120)
	@Column(name = "INTERFACE_ID")
	private String interfaceId;



	@Size(max = 120)
	@Column(name = "INTERFACE_TYPE")
	private String interfaceType;



	@Size(max = 120)
	@Column(name = "DESTINATION_PORT")
	private String destinationPort;


	@Size(max = 120)
	@Column(name = "CAMPAIGN_ID")
	private String campaignId;



	@Size(max = 120)
	@Column(name = "RETRY_COUNT")
	private String retryCount;

	@Override
	public String toString() {
		return "gmatMsg [responseId=" + responseId + ",origin=" + origin
				+ ", destination=" + destination + ", message=" + message + ", submitTime=" + submitTime + ", msgType="
				+ msgType + ", language=" + language + ", udh=" + udh + ", statusReport=" + statusReport
				+ ", dataCodingScheme=" + dataCodingScheme + ", protocol=" + protocol + ", priority=" + priority
				+ ", chargingCode=" + chargingCode + ", status=" + status + ", validity=" + validity + ", msgId="
				+ msgId + ", interfaceId=" + interfaceId + ", interfaceType=" + interfaceType + ", destinationPort="
				+ destinationPort + ", campaignId=" + campaignId + ", retryCount=" + retryCount + "]";
	}




}





