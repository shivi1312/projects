package com.telemune.smscapi.service;

import com.telemune.smscapi.model.SmsgBean;

public interface SmsgService {

	public void sendSMS(SmsgBean smsgbean, String Origination, String destination, String message);
}
