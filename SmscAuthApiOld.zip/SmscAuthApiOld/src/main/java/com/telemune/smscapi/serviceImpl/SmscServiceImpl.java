package com.telemune.smscapi.serviceImpl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.telemune.smscapi.config.GlobalParams;
import com.telemune.smscapi.entity.GmatMsg_0;
import com.telemune.smscapi.model.SmsgBean;
import com.telemune.smscapi.repository.GmatRepository_0;
import com.telemune.smscapi.service.SmsgService;







@Service
public class SmscServiceImpl implements  SmsgService  {
	@Autowired
    GmatRepository_0 gmatRepository;
	
	@Autowired(required = true)
	private GlobalParams globalParams;

	private static final Logger logger = LogManager.getLogger(SmscServiceImpl.class);
	public void sendSMS(SmsgBean smsgbean, String Origination, String destination, String message) {
		try {
            makeCallLogs(smsgbean);
			GmatMsg_0 msg = new GmatMsg_0();
			msg.setOrigin(Origination);
			msg.setDestination(destination);
			msg.setMessage(message);
		
			gmatRepository.save(msg);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public synchronized void makeCallLogs(SmsgBean smsgbean) {
		try {
			globalParams.getFileLogWriter().writeLog(smsgbean.toString());
			logger.info("Details inserted into File"+ smsgbean.toString());
		} catch (Exception e) {
			e.printStackTrace();
			
		}
	}

}
