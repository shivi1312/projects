// create the prototype on the String object, trim function
    
/*String.prototype.trim=function trimStr() 
{
// skip leading and trailing whitespace and return everything in between
    var x = this;
    x = x.replace(/^\s*(.*)/, "$1");
    x = x.replace(/(.*?)\s*$/, "$1");
    return x;
}*/

// this function uses regular expression to valid mobile num ( by Jaipal Singh)
/*function valid(mobilenum)
{
    return (/^(84|00|0|)9[0-9]{9}$/.test(mobilenum)); //return true if valid else false
}*/

function valid(mobile)
{
     var ValidChars = "0123456789"
     for(var i = 0; i < mobile.length ; i++)
     {
	var Char = mobile.charAt(i);
	if (ValidChars.indexOf(Char) == -1)
	{
	    alert("Please enter a valid mobile number")
	    return false
         }
      }

     var countryCode = "1876"
     if(mobile.substr(0,1) == "+")
     {
         alert("Please remove + from the number")
         return false
     }
     if(mobile.substr(0,2)=="00") 
     {
         if(mobile.length<7)
	{	
               alert("Check! Mobile number is less than 8 digits.")
		return false
	}
	if ( mobile.length>12)
	{	
		 alert("Check! Mobile number exceeds the limit.")
         	  return false
	}
     }
	
     else if( mobile.substr(0,3) == countryCode)
	{
		if(mobile.length<8 || mobile.length>11)
		{
			alert("Check! Mobile number must contain either 8 or 11 digits.")
			return false
		}
	}
     else if(mobile.substr(0,1)=="0")
     {
         if(mobile.length<7 || mobile.length>11)
         {
             alert("Check! Mobile number must contain either 8 or 11 digits.")
	     return false	
         }
     }
	 return true
}
