// checks the date in format dd/mm/yyyy only
// pass dd as two digit and mm also as two digit and year as four digit e.g 09/02/2004
// The below two functions are added by Mr. Jaipal Singh to validate dates in dd/mm/yyyy format and
// find the difference . commented the below function due to some syntax error.

function verifydate(date,month,year)
{
	console.log("in verifydate() of VerifyDate.js");
	var entered_day = date;
	var entered_month = month;
	var entered_year = year;
	var right_now=new Date();
	var current_day=right_now.getDate();
	var current_month=(right_now.getMonth()+1);
	var current_year=right_now.getYear();
	current_year += (current_year < 1900) ? 1900 : 0;
	var err=0;
  
	if (entered_month<1 || entered_month>12) err = 1;
	if (entered_day<1 || entered_day>31) err = 1;
	if (entered_day==31 && (entered_month==4 || entered_month==6 || entered_month==9 || entered_month==11)) err=1;

	if (entered_month==2)
	{
		if ((entered_year%4==0) && (entered_year%100!=0 || entered_year%400==0))
		{
			if (entered_day>29) err=1;
		} else
		{
			if (entered_day>28) err=1;
		}
	}

	if(current_year>entered_year)
	 {
	 	 err=1;
 	 }
 	 else
	 {
 	 	if(current_year == entered_year)
		{
			if(current_month > entered_month)
			{
				err=1;
			}
			else
			{
				if(current_month==entered_month)
				{
					if(current_day>entered_day)
					err=1;
				}
			}
		}
 	 	
 	 	if(entered_year>current_year)
		{
 	 	if((entered_year-current_year)>1)
 	 		{
 	 			//alert("Please Select Date From Same Year Or Next Year Only");
 	 			return 3;
 	 		}
		}
 	 	
	 }
	
	 if (err==1) {
		return false;
	    	}
	else
		return true;

}

