
function isEmpty(param)
{	
	if(param.trim()=="" || param.trim()==null)
		{
		return true;
		}
	return false;
}

function isValidPass(password)
{
	var regularExp=/[^a-zA-Z0-9\-\/]/
if(password=="" || password.length < 8 || password.length >15 || !(regularExp.test(password)))
{
    return false
}
return true;
}

function matchConfirmPass(password,confPassword)
{
	
	if (password.length != confpassword.length)
    {
          return false
    }
    else
    {
          for(var i = 0; i < password.length ; i++)
          {
              if (password.charAt(i) != confpassword.charAt(i))
              {
                   return false
              }
         }
   }
	return true;

}

function isValidphone(phone){
	
	//var result=/^(\()?(\d{3})([\)-\. ])?(\d{3})([-\. ])?(\d{4})$/.test(phone);
	//alert(phone.length);
		if(!(phone.length>=10 && phone.length<=15))
			{
			    return false;
			}
			
	return true;
}

function isValidEmailAddress(emailAddress) {
    var pattern = new RegExp(/^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?$/i);
    return pattern.test(emailAddress);
}



function isSelected(param)
{	
	if(param.trim().toUpperCase()=="SELECT")
		{
		return false;
		}
	return true;
}



function isValidDate(dateVar)
{
//dateFormat=01-01-2000;
var validformat=/^\d{2}\-\d{2}\-\d{4}$/ //Basic check for format validity
var returnval=false

if (!validformat.test(dateVar))
alert("Invalid Date Format. Please correct and submit again.")
else{ //Detailed check for valid date ranges
var dayfield=dateVar.split("-")[0]
var monthfield=dateVar.split("-")[1]
var yearfield=dateVar.split("-")[2]
var dayobj = new Date(yearfield, monthfield-1, dayfield)
if ((dayobj.getMonth()+1!=monthfield)||(dayobj.getDate()!=dayfield)||(dayobj.getFullYear()!=yearfield))
alert("Invalid Day, Month, or Year range detected. Please correct and submit again.")
else{
	//alert("day : "+dateVar.substring(0,2)+" || month : "+dateVar.substring(3,5)+" || year : "+dateVar.substring(6,10));
	year=dateVar.substring(6,10)
	month=dateVar.substring(3,5)
	day=dateVar.substring(0,2)
	dj_utc = Date.UTC( year, month-1, day,0,0,0,0);
	var curdate = new Date();
	// get system date
	// convert system date to milliseconds from 1-1-1970 using  UTC function of Date object
	curdate_utc = Date.UTC( curdate.getFullYear (), curdate.getMonth(), curdate.getDate(),0,0,0,0);
	if ( dj_utc > curdate_utc)
	{
	    alert("Sorry! Date cannot be after system date!");
	    return false;
	}
	returnval=true;
}
	


}
return returnval;
}


function compareDate(stDate,edDate)
{
//dateFormat=01-01-2000;
var validformat=/^\d{2}\-\d{2}\-\d{4}$/ //Basic check for format validity
var returnval=false
	styear=stDate.substring(6,10)
	stmonth=stDate.substring(3,5)
	stday=stDate.substring(0,2)
	stdj_utc = Date.UTC( styear, stmonth-1, stday,0,0,0,0);

	edyear=edDate.substring(6,10)
	edmonth=edDate.substring(3,5)
	edday=edDate.substring(0,2)
	eddj_utc = Date.UTC( edyear, edmonth-1, edday,0,0,0,0);
	
	if ( stdj_utc > eddj_utc)
	{
	    alert("Start date cannot be greater than end date");
	    return false;
	}
	
	returnval=true;
	
return returnval;
}



function checkDeletion(elementName)
{
    var maintain=0;
    // alert("In the Function");
          var checkboxName = document.getElementsByName(elementName);
      var n = checkboxName.length;
      //alert("length is "+n);
      for(var ctr=0;ctr<n;ctr++)
      {
         //alert("In for loop");
         if(checkboxName[ctr].checked)
        {
         //alert("In if ")
            maintain++;
         }
      }
      //alert("Array Length Value is "+maintain);
      if(maintain==0)
      {
         alert('<s:property value="getText(\'delEmpty\')"/>');
         return false;
      }
      else
      {

                         var r=confirm('<s:property value="getText(\'delConfirm\')"/>');
                         if (r==true)
                         {
                                 return true;
                         }
                         else
                         {
                                 return false;
                         }

    }
      return true;

}





