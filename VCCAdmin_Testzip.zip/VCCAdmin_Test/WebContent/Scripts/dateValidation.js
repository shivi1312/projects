function validate()
	{
		var st;
		var ed;	
		var dt;

		
		
			st = document.form1.start.value;
			ed = document.form1.end.value;
			
			stdate = st.substring(0,2);
			stmonth = st.substring(3,5);
			styear = st.substring(6,10);
			
			eddate = ed.substring(0,2);
			edmonth = ed.substring(3,5);
			edyear = ed.substring(6,10);
			
			dt = new Date();
			nowday = dt.getDate();
			nowmonth = dt.getMonth();
			nowyear = dt.getYear();
			nowmonth = nowmonth+1;
			nowyear += (nowyear<1900)? 1900:0
			
			
			var sday = nowday.toString();
			var smonth = nowmonth.toString();
			var syear = nowyear.toString();
			
			if(sday <= 9)
			{
				sday= '0'+sday;
			}
			if(smonth <= 9)
			{
				smonth = '0'+smonth;
			}	
		var Date_today = sday+'-'+smonth+'-'+syear;
		if ((ed == "") || (st == ""))
			{
				alert("Enter start date and end date");
				return false;
				document.form1.start.focus();
				
			}

		if (st == "")
			{
				alert("Enter start date");
				return false;
				document.form1.start.focus();
				
			}
			
		if (ed == "")
			{
				alert("Enter end date");
				return false;
				document.form1.end.focus();
				
			}
		
		if ( parseInt(styear+stmonth+stdate) > parseInt(edyear+edmonth+eddate) )
			{
				alert("Start date must be less than end date");
				return false;
				document.form1.start.focus();
				
			}
	
		if ( parseInt(edyear+edmonth+eddate) > parseInt(syear+smonth+sday) )
			{
				alert("End date cannot be greater than current date"+Date_today);
				end="";	
				document.form1.end.focus();
				return false;
			}
		
	} //validate

function getLastWeek(){
	
	//alert("data is: " + reportinterval.innerHTML);
    var length = reportinterval.innerHTML;
	var today = new Date();
    var lastWeek = new Date(today.getFullYear(), today.getMonth(), today.getDate() - length);
   
    return lastWeek ;
    
}
function validateEnteredDate(st, ed)
{
	var dt;
	
		stdate = st.substring(0,2);
		stmonth = st.substring(3,5);
		styear = st.substring(6,10);
		
		eddate = ed.substring(0,2);
		edmonth = ed.substring(3,5);
		edyear = ed.substring(6,10);
		
		
		
		
		
		
		/*styear = st.substring(0,2);
		stmonth = st.substring(3,5);
		stdate = st.substring(6,10);

	
		edyear = ed.substring(0,2);
		edmonth = ed.substring(3,5);
		eddate = ed.substring(6,10);*/
		
		
		
		dt = new Date();
		nowday = dt.getDate();
		nowmonth = dt.getMonth();
		nowyear = dt.getYear();
		nowmonth = nowmonth+1;
		nowyear += (nowyear<1900)? 1900:0
		
		
		var sday = nowday.toString();
		var smonth = nowmonth.toString();
		var syear = nowyear.toString();
		
		
		if(sday <= 9)
		{
			sday= '0'+sday;
		}
		if(smonth <= 9)
		{
			smonth = '0'+smonth;
		}	
	var Date_today = sday+'-'+smonth+'-'+syear;
	if ((ed == "") || (st == ""))
		{
			alert("Enter start date and end date");
			return false;
			document.getElementById('f_date_c1').focus();
			
		}

	if ( parseInt(styear+stmonth+stdate) < parseInt(syear.substring(2,4)+smonth+sday) )
	{
		alert("Start date cannot be less than current date"+Date_today);
		st="";
		document.getElementById('f_date_c1').focus();
		return false;
	}
	
	if (st == "")
		{
			alert("Enter start date");
			return false;
			document.getElementById('f_date_c1').focus();
			
		}
		
	if (ed == "")
		{
			alert("Enter end date");
			return false;
			document.getElementById('f_date_c2').focus();
			
		}
	
	if ( parseInt(styear+stmonth+stdate) > parseInt(edyear+edmonth+eddate) )
		{
			alert("Start date must be less than end date");
			return false;
			document.getElementById('f_date_c1').focus();
			
		}
	
   // alert("ed : "+ed+"end date: "+edyear+edmonth+eddate+" current date: "+syear.substring(2,4)+smonth+sday);
	var lastWeek = getLastWeek();
	var lastWeekMonth = lastWeek.getMonth() + 1;
	var lastWeekDay = lastWeek.getDate();
	var lastWeekYear = lastWeek.getFullYear();
	
	var weekdate=("00" + lastWeekDay .toString()).slice(-2);
	var weekmonth=("00" + lastWeekMonth.toString()).slice(-2);
	var weekyear=("0000" + lastWeekYear .toString()).slice(-4);
	var length = reportinterval.innerHTML;
	if(parseInt(styear+stmonth+stdate) < parseInt(weekyear+weekmonth+weekdate)){
		alert("Start date can not be less than "+length+" days from current date !!");
		return false;
		document.getElementById('f_date_c1').focus();
	}
	
    if ( parseInt(edyear+edmonth+eddate) > parseInt(syear+smonth+sday) )
		{
			alert("End date cannot be greater than current date"+Date_today);
			end="";
			document.getElementById('f_date_c2').focus();
			return false;
		}
	
} //validate



//Added By AbhiShek Rana
function validateDate(st,ed){
	
		var dt;
	
		stdate = st.substring(0,2);
		stmonth = st.substring(3,5);
		styear = st.substring(6,10);
		
		eddate = ed.substring(0,2);
		edmonth = ed.substring(3,5);
		edyear = ed.substring(6,10);
		
		
		
		dt = new Date();
		nowday = dt.getDate();
		nowmonth = dt.getMonth();
		nowyear = dt.getYear();
		nowmonth = nowmonth+1;
		nowyear += (nowyear<1900)? 1900:0
		
		
		var sday = nowday.toString();
		var smonth = nowmonth.toString();
		var syear = nowyear.toString();
		
		var Date_today = sday+'-'+smonth+'-'+syear;
		//alert("inside validating ");
		if(sday <= 9)
		{
			sday= '0'+sday;
		}
		if(smonth <= 9)
		{
			smonth = '0'+smonth;
		}	
	if (st == "")
	{
		alert("Enter Start date");
		return false;
		document.getElementById('f_date_c1').focus();
			
	}
	if (ed == "")
	{
		alert("Enter End date");
		return false;
		document.getElementById('f_date_c2').focus();
			
	}
	if ( parseInt(styear+stmonth+stdate) > parseInt(edyear+edmonth+eddate) )
	{
		alert("Start date must be less than end date");
		return false;
		document.getElementById('f_date_c1').focus();
		
	}
	//alert("date : "+styear+stmonth+stdate+" current -- "+syear+smonth+sday);
	 if( parseInt(styear+stmonth+stdate) > parseInt(syear+smonth+sday))
		{
			alert("Start Date cannot be greater than current date "+Date_today);
			document.getElementById('f_date_c1').focus();
			return false;
		}
	 if ( parseInt(edyear+edmonth+eddate) > parseInt(syear+smonth+sday) )
		{
			alert("End date cannot be greater than current date "+Date_today);
			end="";
			document.getElementById('f_date_c2').focus();
			return false;
		}
	
}

// Code of Code by Abhishek


function validatemonth()
{
				var dt;
				var st;
				var ed;
				if (document.form1.reportType[1].checked == true)
				{
								var theindex = document.getElementById("aggre");

								if (theindex.selectedIndex == 0)
								{
												st = document.getElementById("f_date_c1").value;
												ed = document.getElementById("f_date_c2").value;

												stmonth = st.substring(0,2);
												styear = st.substring(3,7);

												edmonth = ed.substring(0,2);
												edyear = ed.substring(3,7);

												dt = new Date();
												nowday = dt.getDate();
												nowmonth = dt.getMonth();
												nowyear = dt.getYear();
												nowmonth = nowmonth+1;
												nowyear += (nowyear<1900)? 1900:0


																var smonth = nowmonth.toString();
												var syear = nowyear.toString();

												if(smonth <= 9)
												{
																smonth = '0'+smonth;
												}
												var Date_today = smonth+'-'+syear;
												if (st == "")
												{
																alert("Enter start month");
																document.form1.start.focus();
																return false;

												}

												if (ed == "")
												{
																alert("Enter end month");
																document.form1.end.focus();
																return false;

												}

												if ( parseInt(styear+stmonth) > parseInt(edyear+edmonth) )
												{
																alert("Start month must be less than or equal to end month");
																document.form1.start.focus();
																return false;

												}

												if ( parseInt(edyear+edmonth) > parseInt(syear+smonth) )
												{
																alert("End month cannot be greater than current month= "+Date_today);
																end="";
																document.form1.end.focus();
																return false;
												}
												if ( parseInt(edyear+edmonth) == parseInt(syear+smonth) )
												{
																alert("End month cannot be equal to current month= "+Date_today);
																end="";
																document.form1.end.focus();
																return false;
												}

												if ( parseInt(edyear) != parseInt(styear) )
												{
																alert("Year must be same for monthly report");
																end="";
																document.form1.end.focus();
																return false;
												}
								}
								else if(theindex.selectedIndex==1)
								{
												st = document.getElementById("f_date_c1").value;
												ed = document.getElementById("f_date_c2").value;

												styear = st.substring(3,7);
												edyear = ed.substring(3,7);

												dt = new Date();
												nowday = dt.getDate();
												nowmonth = dt.getMonth();
												nowyear = dt.getYear();
												nowmonth = nowmonth+1;
												nowyear += (nowyear<1900)? 1900:0


																var syear = nowyear.toString();

												var Date_today = syear;
												if ((ed == "") && (st == ""))
												{
																alert("Enter start year and end year");
																document.form1.start.focus();
																return false;

												}

												if (st == "")
												{
																alert("Enter start year");
																document.form1.start.focus();
																return false;

												}

												if (ed == "")
												{
																alert("Enter end year");
																document.form1.end.focus();
																return false;

												}

												if ( parseInt(styear) > parseInt(edyear) )
												{
																alert("Start year must be less than or equal to end year");
																document.form1.start.focus();
																return false;

												}

												if ( parseInt(edyear) > parseInt(syear) )
												{
																alert("End year cannot be greater than current year= "+Date_today);
																end="";
																document.form1.end.focus();
																return false;
												}
								}

				}
} //validatemonth





function validatemonth(st,ed)
{
				var dt;
						var theindex = document.getElementById("aggre");

								if (theindex.selectedIndex == 0)
								{
												st = document.getElementById("f_date_c1").value;
												ed = document.getElementById("f_date_c2").value;

												stmonth = st.substring(0,2);
												styear = st.substring(3,7);

												edmonth = ed.substring(0,2);
												edyear = ed.substring(3,7);

												dt = new Date();
												nowday = dt.getDate();
												nowmonth = dt.getMonth();
												nowyear = dt.getYear();
												nowmonth = nowmonth+1;
												nowyear += (nowyear<1900)? 1900:0


																var smonth = nowmonth.toString();
												var syear = nowyear.toString();

												if(smonth <= 9)
												{
																smonth = '0'+smonth;
												}
												var Date_today = smonth+'-'+syear;
												if (st == "")
												{
																alert("Enter start month");
																document.getElementById('f_date_c1').focus();
																return false;

												}

												if (ed == "")
												{
																alert("Enter end month");
																document.getElementById('f_date_c2').focus();
																return false;

												}

												if ( parseInt(styear+stmonth) > parseInt(edyear+edmonth) )
												{
																alert("Start month must be less than or equal to end month");
																document.getElementById('f_date_c1').focus();
																return false;

												}

												if ( parseInt(edyear+edmonth) > parseInt(syear+smonth) )
												{
																alert("End month cannot be greater than current month= "+Date_today);
																end="";
																document.getElementById('f_date_c2').focus();
																return false;
												}
												if ( parseInt(edyear+edmonth) == parseInt(syear+smonth) )
												{
																alert("End month cannot be equal to current month= "+Date_today);
																end="";
																document.getElementById('f_date_c2').focus();
																return false;
												}

												if ( parseInt(edyear) != parseInt(styear) )
												{
																alert("Year must be same for monthly report");
																end="";
																document.getElementById('f_date_c2').focus();
																return false;
												}
								}
								else if(theindex.selectedIndex==1)
								{
												st = document.getElementById("f_date_c1").value;
												ed = document.getElementById("f_date_c2").value;

												styear = st.substring(3,7);
												edyear = ed.substring(3,7);

												dt = new Date();
												nowday = dt.getDate();
												nowmonth = dt.getMonth();
												nowyear = dt.getYear();
												nowmonth = nowmonth+1;
												nowyear += (nowyear<1900)? 1900:0


																var syear = nowyear.toString();

												var Date_today = syear;
												if ((ed == "") && (st == ""))
												{
																alert("Enter start year and end year");
																document.getElementById('f_date_c1').focus();
																return false;

												}

												if (st == "")
												{
																alert("Enter start year");
																document.getElementById('f_date_c1').focus();
																return false;

												}

												if (ed == "")
												{
																alert("Enter end year");
																document.getElementById('f_date_c2').focus();
																return false;

												}

												if ( parseInt(styear) > parseInt(edyear) )
												{
																alert("Start year must be less than or equal to end year");
																document.getElementById('f_date_c1').focus();
																return false;

												}

												if ( parseInt(edyear) > parseInt(syear) )
												{
																alert("End year cannot be greater than current year= "+Date_today);
																end="";
																document.getElementById('f_date_c2').focus();
																return false;
												}
								}

				
} //validatemonth







function validate1()
{
		var st;
		var ed;	
		var dt;

		
	//	if (document.form1.reportType[1].checked == true)
	//	{
			st = document.form1.start.value;
			ed = document.form1.end.value;
			
			stdate = st.substring(0,2);
			stmonth = st.substring(3,5);
			styear = st.substring(6,10);
			
			eddate = ed.substring(0,2);
			edmonth = ed.substring(3,5);
			edyear = ed.substring(6,10);
			
			dt = new Date();
			nowday = dt.getDate();
			nowmonth = dt.getMonth();
			nowyear = dt.getYear();
			nowmonth = nowmonth+1;
			nowyear += (nowyear<1900)? 1900:0
			
			
			var sday = nowday.toString();
			var smonth = nowmonth.toString();
			var syear = nowyear.toString();
			
			if(sday <= 9)
			{
				sday= '0'+sday;
			}
			if(smonth <= 9)
			{
				smonth = '0'+smonth;
			}	
		var Date_today = sday+'-'+smonth+'-'+syear;
		if ((ed == "") || (st == ""))
			{
				alert("Enter start date and end date");
				return false;
				document.form1.start.focus();
				
			}

		if (st == "")
			{
				alert("Enter start date");
				return false;
				document.form1.start.focus();
				
			}
			
		if (ed == "")
			{
				alert("Enter end date");
				return false;
				document.form1.end.focus();
				
			}
		
		if ( parseInt(styear+stmonth+stdate) > parseInt(edyear+edmonth+eddate) )
			{
				alert("Start date must be less than end date");
				return false;
				document.form1.start.focus();
				
			}
	
		if ( parseInt(edyear+edmonth+eddate) > parseInt(syear+smonth+sday) )
			{
				alert("End date cannot be greater than current date"+Date_today);
				end="";
				document.form1.end.focus();
				return false;
			}
		//}
	} //validate1

function disablefield()
	{
		document.form1.start.disabled=true;
		document.form1.end.disabled=true;
		document.form1.aggre.disabled=true;	
		if(document.getElementById)
		{
							document.getElementById("f_trigger_c1").style.visibility="hidden";
							document.getElementById("f_trigger_c2").style.visibility="hidden";
		}
		else
		{
							document.f_trigger_c1.visibility="hidden";
							document.f_trigger_c2.visibility="hidden";
		}

	} //disablefield

function enablefield()
	{
		document.form1.start.disabled=false;
		document.form1.end.disabled=false;
		document.form1.aggre.disabled=false;
		if(document.getElementById)
		{
							document.getElementById("f_trigger_c1").style.visibility="visible";
							document.getElementById("f_trigger_c2").style.visibility="visible";
		}
		else
		{
							document.f_trigger_c1.visibility="visible";
							document.f_trigger_c2.visibility="visible";
		}
	//	document.form1.c1.disabled=false;
	//	document.form1.c2.disabled=false;
	}//enablefield

