var browser  = navigator.appName ;  //check for browser type

function numberOnly(e)
{
	if(window.event ) // IE
	{

		if( (e.keyCode < 48 || e.keyCode > 57) && e.keyCode != 8)
		{
			e.returnValue = false;
		}
	}
	else if(e.which) // Netscape/Firefox
	{
		if( (e.which < 48 || e.which > 57) && e.which != 8)
		{		
			return false;
		}
	}

}// numberOnly()

function floatOnly(e)
{
	if(window.event ) // IE
	{

		if( (e.keyCode < 48 || e.keyCode > 57) && e.keyCode != 8  && e.keyCode != 46)
		{
			e.returnValue = false
		}
	}
	else if(e.which) // Netscape/Firefox
	{
		if( (e.which < 48 || e.which > 57) && e.which != 8  && e.which != 46)
		{		
			return false
		}
	}
	else if(e.which == 46
			    && $(this).val().indexOf('.') != -1) {
			e.returnValue = false
			       // e.preventDefault();
			    } // prevent if already dot

}// numberOnly()


function StringOnly(e)
{
	if(window.event ) // IE
	{

		if( (e.keyCode < 65 || e.keyCode > 90) && (e.keyCode < 97 || e.keyCode > 122) && e.keyCode != 8  && e.keyCode != 46 && e.keyCode != 32)
		{
			e.returnValue = false
		}
	}
	else if(e.which) // Netscape/Firefox
	{
		if( (e.which < 65 || e.which > 90) && (e.which < 97 || e.which > 122) && e.which != 8 && e.which != 46 && e.which != 32)
		{		
			return false
		}
	}

}// StringOnly()



function disableReturnKey(e)
{
	if(window.event ) // IE
	{

		if( e.keyCode == 13  )
		{
			e.returnValue = false
		}
	}
	else if(e.which) // Netscape/Firefox
	{
		if( e.which == 13  )
		{		
			return false
		}
	}

}// disableReturnKey()

function ipCheck(e)
{
	if(window.event ) // IE
	{

		if( (e.keyCode < 48 || e.keyCode > 57) && e.keyCode != 8 && e.keyCode != 46 )
		{
			e.returnValue = false
		}
	}
	else if(e.which) // Netscape/Firefox
	{
		if( (e.which < 48 || e.which > 57) && e.which != 8 && e.which != 46 )
		{		
			return false
		}
	}

} // ipCheck() 

function exclusionRange(e)
{
	if(window.event ) // IE
	{

		if( (e.keyCode < 48 || e.keyCode > 57) && e.keyCode != 8 && e.keyCode != 32 && e.keyCode !=13 )
		{
			e.returnValue = false
		}
	}
	else if(e.which) // Netscape/Firefox
	{
		if( (e.which < 48 || e.which > 57) && e.which != 8 && e.which != 32 && e.which != 13 )
		{		
			return false
		}
	}

} //exclusionRange() 

function addressOnly(e)
{
	if(window.event ) // IE
	{

		if(e.keyCode ==13)
		{
			e.returnValue = false
		}
	}
	else if(e.which) // Netscape/Firefox
	{
		if( e.which ==13)
		{		
			return false
		}
	}

}// enterOnly






function RbtNameOnly(e)
{
	if(window.event ) // IE
	{

		if( (e.keyCode < 65 || e.keyCode > 90) && (e.keyCode < 97 || e.keyCode > 122) && e.keyCode != 8  && e.keyCode != 32 && (e.keyCode < 48 || e.keyCode > 57) && e.keyCode!=95)
		{
			e.returnValue = false
		}
	}
	else if(e.which) // Netscape/Firefox
	{
		if( (e.which < 65 || e.which > 90) && (e.which < 97 || e.which > 122) && e.which != 8 && e.which != 32 && (e.which < 48 || e.which > 57 ) && e.which!=95)
		{		
			return false
		}
	}

}// RbtNameOnly

function RbtNickNameOnly(e)
{
	if(window.event ) // IE
	{

		if( (e.keyCode < 65 || e.keyCode > 90) && (e.keyCode < 97 || e.keyCode > 122) && e.keyCode != 8 && (e.keyCode < 48 || e.keyCode > 57) && e.keyCode!=95)
		{
			e.returnValue = false
		}
	}
	else if(e.which) // Netscape/Firefox
	{
		if( (e.which < 65 || e.which > 90) && (e.which < 97 || e.which > 122) && e.which != 8 && (e.which < 48 || e.which > 57 ) && e.which!=95)
		{		
			return false
		}
	}

}// RbtNickNameOnly


function ArtistNameOnly(e)
{
	if(window.event ) // IE
	{

		if( (e.keyCode < 65 || e.keyCode > 90) && (e.keyCode < 97 || e.keyCode > 122) && e.keyCode != 8  && e.keyCode != 46 && (e.keyCode < 48 || e.keyCode > 57) && e.keyCode!=95)
		{
			e.returnValue = false
		}
	}
	else if(e.which) // Netscape/Firefox
	{
		if( (e.which < 65 || e.which > 90) && (e.which < 97 || e.which > 122) && e.which != 8 && e.which != 46 && (e.which < 48 || e.which > 57 ) && e.which!=95)
		{		
			return false
		}
	}

}// RbtNickNameOnly


function msisdnListOnly(e)
{
	if(window.event ) // IE
	{

		if( (e.keyCode < 48 || e.keyCode > 57) && e.keyCode != 8 && e.keyCode != 32 && e.keyCode != 13)
		{
			e.returnValue = false;
		}
	}
	else if(e.which) // Netscape/Firefox
	{
		if( (e.which < 48 || e.which > 57) && e.which != 8 && e.which != 32 && e.which != 13)
		{		
			return false;
		}
	}

}// numberOnly()
