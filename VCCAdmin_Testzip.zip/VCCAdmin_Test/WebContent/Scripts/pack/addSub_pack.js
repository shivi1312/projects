/////////////////////// yyyyyyyyyyyyyy
////////// pankaj mishra R&D ///////////////////
////////////manoj
$(document).ready(function(){
	

	$("#subPromo").fadeOut(200).hide();
	$("#rbtPurchasePromo").fadeOut(200).hide();
	$("#subRenewal").fadeOut(200).hide();
	$("#rbtPurchaseRenew").fadeOut(200).hide();
	$("#recordingRenew").fadeOut(200).hide();
	
	$("#enable_subPromo").click(function(){
		if($(this).prop('checked')){
			$("#subPromo").fadeIn(500).show();
		}else{
			
				$("#subPromo").fadeIn(500).hide();
				$("#rateplan_subPrepaidPromo").attr('checked', false);
				$("#rateplan_subPostpaidPromo").attr('checked', false); 
		}
	});
	
	$("#enable_rbtPurchasePromo").click(function(){
		if($(this).prop('checked')){
			$("#rbtPurchasePromo").fadeIn(500).show();
		}else{
				$("#rbtPurchasePromo").fadeIn(500).hide();
				$("#rateplan_rbtPurchasePrepaidPromo").attr('checked', false);
				$("#rateplan_rbtPurchasePostpaidPromo").attr('checked', false);
		}
	});

	$("#enable_subRenew").click(function(){
		if($(this).prop('checked')){
			$("#subRenewal").fadeIn(500).show();
		}else{
				$("#subRenewal").fadeIn(500).hide();
				$("#rateplan_enableSubAutoRenewPrepaid").attr('checked',false);
				$("#rateplan_enableSubAutoRenewPostpaid").attr('checked',false);
		}
	});

	$("#enable_rbtAutoRenew").click(function(){
		if($(this).prop('checked')){
			$("#rbtPurchaseRenew").fadeIn(500).show();
		}else{
				$("#rbtPurchaseRenew").fadeIn(500).hide();
				$("#rateplan_enableRbtAutoRenewPrepaid").attr('checked',false);
				$("rateplan_enableRbtAutoRenewPostpaid").attr('checked',false);
			}
	});

	$("#enable_recordAutoRenew").click(function(){
		if($(this).prop('checked')){
			$("#recordingRenew").fadeIn(500).show();
		}else{
				$("#recordingRenew").fadeIn(500).hide();
			}
	});
	
	
	$("#maskedName").blur(function(){
		var maskedName=$("#maskedName").val();
		maskedName=maskedName.trim();
		//alert(" value is MASKED_NAME="+maskedName);

		var qrString="rateplan.maskedName="+maskedName;//+"&linkName=webadmin";
		if(maskedName==''){
			$("#packNameStatus_ok").fadeIn(300).hide();
		    $("#packNameStatus_failed").fadeIn(300).show();
		}else{
		 var request=$.ajax({
			 type :"POST",
			 url  :"isPackNameExists.action",
			 data :qrString,
			 success:function(data,textStatus,jqXHR){
				 if(jqXHR.status==200){
				       //alert('success');
				       $("#packNameStatus_ok").fadeIn(300).show();
				       $("#packNameStatus_failed").fadeIn(300).hide();
				   }else if(jqXHR.status==201){
					    //alert('failure '+textStatus);
					    $("#packNameStatus_failed").fadeIn(300).show();
						$("#packNameStatus_ok").fadeIn(300).hide();
						$("#maskedName").val('');
				  }else if(jqXHR.status==500){
					 // alert( "Request failed: " + textStatus );
					  $("#packNameStatus_failed").fadeIn(300).show();
					  $("#packNameStatus_ok").fadeIn(300).hide();
					  $("#maskedName").val('');
					}
			  }
		});
	 }	 
	});
	
	
	
	//added by harjinder
	$("#packName").blur(function(){
		
		var packName=$("#packName").val();
		packName=packName.trim();
		
		var qrString="packsub.packName="+packName;//+"&linkName=webadmin";
		if(packName==''){
			$("#packNameStatus_ok").fadeIn(300).hide();
		    $("#packNameStatus_failed").fadeIn(300).show();
		}else{
		 var request=$.ajax({
			 
			 type :"POST",
			 url  :"isPackNameExist.action",
			 data :qrString,
			 success:function(data,textStatus,jqXHR){
				 if(jqXHR.status==200){
	//			       alert('success');
				       $("#packNameStatus_ok").fadeIn(300).show();
				       $("#packNameStatus_failed").fadeIn(300).hide();
				   }else if(jqXHR.status==201){
					    //alert('failure '+textStatus);
					    $("#packNameStatus_failed").fadeIn(300).show();
						$("#packNameStatus_ok").fadeIn(300).hide();
						$("#packName").val('');
				  }else if(jqXHR.status==500){
					 // alert( "Request failed: " + textStatus );
					  $("#packNameStatus_failed").fadeIn(300).show();
					  $("#packNameStatus_ok").fadeIn(300).hide();
					  $("#packName").val('');
					}
			  }
		});
	 }	 
	});
	
});	
	//end 
	

	
//############ add fall back started ##########
//*********************************************
function addSubFallback(divID){
	//var list=${packsub.subscriptionDetails.size();}
	//alert("Lis size is ["+list+"]");
	
	
 	// alert("STATU= sub_DIV_Array ="+sub_DIV_Array+", FB_CHG_CODES="+FB_CHG_CODES);
 	 if(!validateFieldMe(divID)){
 	 	 return;
 	 }
	 if(sub_DIV_Array.length<=0){
		 alert(rangeExceedAlert);
		 return;
	 }
	 
	//    alert("sub_DIV_Array[0] "+sub_DIV_Array[0]);
	    var subSelectID="rateplan_"+sub_DIV_Array[0]+"_chargingCode";
		var subValidityID="rateplan_"+sub_DIV_Array[0]+"_validity";
		var inputIndex=(sub_DIV_Array[0].split("_")[1]);
		
	//	alert(subSelectID);
	//	alert(subValidityID);
	//	alert("Index["+inputIndex+"]");
		var subSelectName='packsub.subscriptionDetails['+inputIndex+'].chargingCode';
		var subValidityName='packsub.subscriptionDetails['+inputIndex+'].validity';
		var newDivID=sub_DIV_Array[0];
	//	alert("subSelectName "+subSelectName);
	//	alert("subValidityName "+subValidityName);
	//	alert("newDivID "+newDivID);
	//	alert(" SUB_CODE_NAME ="+subSelectName+", SUB_VALIDITY_NAME ="+subValidityName+", New DIV ID="+newDivID);
		
		var newDIV=$('<div/>',{"id":newDivID});
		var newTable=$('<table/>').attr({border:"1",width:"100%",cellspacing:"0"});
		
		var t_row=$('<tr/>');

		var subCodeStr=chargingCodeLabel;
				
		//######## Creating Select Option
		subCodeStr+='<select name="'+subSelectName+'" id="'+subSelectID+'" onchange="validateOption(';
		subCodeStr+="'"+newDivID+"');";
		subCodeStr+='">';
		subCodeStr+='<option value="0">select</option>';
		var chg_array=null;
		for(var i=0;i<FB_CHG_CODES.length;i++){
			chg_array=FB_CHG_CODES[i].split("#");
			subCodeStr+='<option value="'+chg_array[0]+'">'+chg_array[1]+'</option>';
		}
		subCodeStr+='</select>';
		//alert("CHARGE_CODES  ==== "+subCodeStr);
		$('<td/>').html(subCodeStr).appendTo(t_row);
		
		//######## Creating Validity text Field
		var validityStr=validityLabel+' : &nbsp;&nbsp; <input type="text" name="'+subValidityName+'"  id="'+subValidityID+'" size="10" maxlength="5" value="0" onkeypress="return numberOnly(event);" >-'+daysLabel;
		//alert(validityStr);
		$('<td/>').html(validityStr).appendTo(t_row);

		//######## Creating addButton Field
		var addBtnStr='<input type="button" value="'+addButtonLabel+'" class="subadd" onclick="addSubFallback(';
		addBtnStr+="'"+sub_DIV_Array[0]+"')";
		addBtnStr+='"/>';
		//alert(addBtnStr);
		$('<td/>').html(addBtnStr).appendTo(t_row);
		
		//######## Creating deleteButton Field
		var deleteBtnStr='<input type="button" value="'+deleteButtonLabel+'" data-divid="'+newDivID+'" onclick="deleteMe(';
		deleteBtnStr+="'"+newDivID.trim()+"')";
		deleteBtnStr+='"/>';
		
		//alert(deleteBtnStr);
		$('<td/>').html(deleteBtnStr).appendTo(t_row);

		//##### appending row to newTable
		newTable.append(t_row);
		
		//##### appending table to newDiv
		newDIV.append(newTable);
		
		//##### appending newDiv to subDiv
		$("#subDiv").append(newDIV);

		//#### Managing sub_DIV_Array array
		//alert("old Array="+sub_DIV_Array);
		//### Removing 1st index from sub_DIV_Array
		sub_DIV_Array.splice(0,1);
		
		subList=subList+1;
		//sub_DIV_Array.sort();
		//alert("New Array="+sub_DIV_Array);
}
 // *************** FOR SUBSCRIPTION RENEW ************************** 
 
 function addSubRenewFallback(divID)
 {
	 //alert("inside Subscription Renew");
 	 
	 if(!validateFieldMe(divID)){
 	 	 return;
 	 }
	 if(subRenew_DIV_Array.length<=0){
		 alert(rangeExceedAlert);
		 
		 return;
	 }
	    var subRenewSelectID="rateplan_"+subRenew_DIV_Array[0]+"_chargingCode";
		var subRenewValidityID="rateplan_"+subRenew_DIV_Array[0]+"_validity";
		var subRenewSTID="rateplan_"+subRenew_DIV_Array[0]+"_STID";
		var subRenewFTID="rateplan_"+subRenew_DIV_Array[0]+"_FTID";
		
		var inputIndex=(subRenew_DIV_Array[0].split("_")[1]);
		
		//alert(subRenewSelectID);
		//alert(subRenewValidityID);
		//alert(inputIndex);
		//alert(subRenewSTID);
		//alert(subRenewFTID);
		
		
		//alert(" SUB_CODE_ID ="+subRenewSelectID+", SUB_RenewVALIDITY_ID ="+subRenewValidityID+", INPUT INDEX ="+inputIndex);

		var subRenewSelectName='packsub.subscriptionRenewDetails['+inputIndex+'].chargingCode';
		var subRenewValidityName='packsub.subscriptionRenewDetails['+inputIndex+'].validity';
		var stIDName='packsub.subscriptionRenewDetails['+inputIndex+'].renewSuccessTemplateID';
		var ftIDName='packsub.subscriptionRenewDetails['+inputIndex+'].renewFailedTemplateID';
		
		var newDivID=subRenew_DIV_Array[0];
		
		//alert("subRenewSelectName "+subRenewSelectName);
		//alert("subRenewValidityName "+subRenewValidityName);
		//alert("stIDName "+stIDName);
		//alert("ftIDName "+ftIDName);
		
	//	alert("newDivID "+newDivID);
		
		
		//alert(" SUB_CODE_NAME ="+subRenewSelectName+", SUB_RenewVALIDITY_NAME ="+subRenewValidityName+", New DIV ID="+newDivID);
		var newDIV=$('<div/>',{"id":newDivID});
		var newTable=$('<table/>').attr({border:"1",width:"100%",cellspacing:"0"});
		var t_row=$('<tr/>');

		var subRenewCodeStr=chargingCodeLabel;
				
		//######## Creating Select Option
		subRenewCodeStr+='<select name="'+subRenewSelectName+'" id="'+subRenewSelectID+'" onchange="validateOption(';
		subRenewCodeStr+="'"+newDivID+"');";
		subRenewCodeStr+='" style="width:60px;">';
		subRenewCodeStr+='<option value="0">select</option>';
		var chg_arr=null;
		for(var i=0;i<FB_CHG_CODES.length;i++){
			chg_array=FB_CHG_CODES[i].split("#");
			subRenewCodeStr+='<option value="'+chg_array[0]+'">'+chg_array[1]+'</option>';
		}
		subRenewCodeStr+='</select>';
		//alert("CHARGE_CODES  ==== "+subRenewCodeStr);
		$('<td/>').html(subRenewCodeStr).appendTo(t_row);
		
		//######## Creating Validity text Field
		var validityStr=validityLabel+' : &nbsp;&nbsp;<input type="text" name="'+subRenewValidityName+'"  id="'+subRenewValidityID+'" size="10" maxlength="5" value="0" onkeypress="return numberOnly(event);" >-'+daysLabel;
		//alert(validityStr);
		$('<td/>').html(validityStr).appendTo(t_row);

		//######## creating select option TEMPLATE_IDS
		//
		
		//alert("TemplateId Length["+TEMPLATE_IDS.length+"]");
		
		var stidStr='Select Template ID: </br> <select	name="'+stIDName+'" id="'+subRenewSTID+'"  style="width:90px" >';
		stidStr+='<option value="0">SUCCESS TEMPLATE-ID</option>';				
		for(var i=0;i<TEMPLATE_IDS.length;i++){
			stidStr+='<option value="'+TEMPLATE_IDS[i]+'">'+TEMPLATE_IDS[i]+'</option>';			
		}
		stidStr+="</select>";
		var ftidStr='<select	name="'+ftIDName+'" id="'+subRenewFTID+'"  style="width:90px" >';
		ftidStr+='<option value="0">FAILURE TEMPLATE-ID</option>';				
		for(var i=0;i<TEMPLATE_IDS.length;i++){
			ftidStr+='<option value="'+TEMPLATE_IDS[i]+'">'+TEMPLATE_IDS[i]+'</option>';			
		}

		
		ftidStr+="</select>";
		//alert(stidStr);
		
		$('<td/>').html(stidStr+ftidStr).appendTo(t_row);
		//######## Creating addButton Field
		var addBtnStr='<input type="button" value="'+addButtonLabel+'" class="subadd" onclick="addSubRenewFallback(';
		addBtnStr+="'"+subRenew_DIV_Array[0]+"')";
		addBtnStr+='"/>';
		//alert(addBtnStr);
		$('<td/>').html(addBtnStr).appendTo(t_row);
		
		//######## Creating deleteButton Field
		var deleteBtnStr='<input type="button" value="'+deleteButtonLabel+'" data-divid="'+newDivID+'" onclick="deleteMe(';
		deleteBtnStr+="'"+newDivID.trim()+"')";
		deleteBtnStr+='"/>';
		
		//alert(deleteBtnStr);
		$('<td/>').html(deleteBtnStr).appendTo(t_row);

		//##### appending row to newTable
		newTable.append(t_row);
		
		//##### appending table to newDiv
		newDIV.append(newTable);
		
		//##### appending newDiv to subDiv
		$("#subRenewDiv").append(newDIV);

		//#### Managing sub_DIV_Array array
		//alert("old Array="+subRenew_DIV_Array);
		//### Removing 1st index from sub_DIV_Array
		subRenew_DIV_Array.splice(0,1);
		subReList=subReList+1;
		//subRenew_DIV_Array.sort();
		//alert("New Array="+subRenew_DIV_Array);
}
// *********************** End ******************************** 
// ********************** Added by manoj ********************* 

function addRbtPurchaseFallback(divID){
	
	 
	 if(!validateFieldMe(divID)){
	 	 return;
	 }
	 if(rbtp_DIV_Array.length<=0){
		 alert(rangeExceedAlert);
		 return;
	 }
	 
	    //var rbtPurSelectID="rateplan_"+rbtp_DIV_Array[0]+"_chargingCode";
		//var rbtPurValidityID="rateplan_"+rbtp_DIV_Array[0]+"_validity";
		var rbtPurNoOfRbtID="rateplan_"+rbtp_DIV_Array[0]+"_noOfRbt";
		var rbtPurNoOfFreeRbtID="rateplan_"+rbtp_DIV_Array[0]+"_noOfFreeRbt";
		
		
		var inputIndex=(rbtp_DIV_Array[0].split("_")[1]);
		
		//alert(" SUB_CODE_ID ="+subSelectID+", SUB_VALIDITY_ID ="+subValidityID+", INPUT INDEX ="+inputIndex);

		//var rbtPurSelectName='packsub.rbtPurchaseDetails['+inputIndex+'].chargingCode';
		//var rbtPurValidityName='packsub.rbtPurchaseDetails['+inputIndex+'].validity';
		var rbtPurNoOfRbtName='packsub.rbtPurchaseDetails['+inputIndex+'].noOfRbt';
		var rbtPurNoOfFreeRbtName='packsub.rbtPurchaseDetails['+inputIndex+'].noOfFreeRbt';
		
		
		var newDivID=rbtp_DIV_Array[0];
		$("#rateplan_subPostPaidTemplateId").css("border-color:","lightyellow");
		//alert(" SUB_CODE_NAME ="+subSelectName+", SUB_VALIDITY_NAME ="+subValidityName+", New DIV ID="+newDivID);
		var newDIV=$('<div/>',{"id":newDivID});
		var newTable=$('<table/>').attr({border:"1",width:"100%",cellspacing:"0"});
		var t_row=$('<tr/>');

		//var rbtPurCodeStr=chargingCodeLabel;
				
		//######## Creating Select Option
		//rbtPurCodeStr+='<select name="'+rbtPurSelectName+'" id="'+rbtPurSelectID+'" onchange="validateOption(';
		//rbtPurCodeStr+="'"+newDivID+"');";
		//rbtPurCodeStr+='">';
		
		//rbtPurCodeStr+='<option value="0">select</option>';
		//var chg_array=null;
		//for(var i=0;i<FB_CHG_CODES.length;i++){
		//	chg_array=FB_CHG_CODES[i].split("#");
		//	rbtPurCodeStr+='<option value="'+chg_array[0]+'">'+chg_array[1]+'</option>';
		//}
		//rbtPurCodeStr+='</select>';
		//alert("CHARGE_CODES  ==== "+rbtPurCodeStr);
		//$('<td/>').html(rbtPurCodeStr).appendTo(t_row);
		
		//######## Creating Validity text Field
		//var validityStr=validityLabel+' : &nbsp;&nbsp;<input type="text" name="'+rbtPurValidityName+'"  id="'+rbtPurValidityID+'" size="10" maxlength="5" value="0"  onkeypress="return numberOnly(event);" />-'+daysLabel;
		//alert(validityStr);
		//$('<td/>').html(validityStr).appendTo(t_row);
        
		//######## Creating NOR text Field
		var noOfRbt=noOfRbtLabel+' : &nbsp;&nbsp;<input type="text" name="'+rbtPurNoOfRbtName+'"  id="'+rbtPurNoOfRbtID+'" size="10" maxlength="5" value="0"  onkeypress="return numberOnly(event);" />';
		
		$('<td/>').html(noOfRbt).appendTo(t_row);
        
        var noOfFreeRbt=noOfFreeRbtLabel+' : &nbsp;&nbsp;<input type="text" name="'+rbtPurNoOfFreeRbtName+'"  id="'+rbtPurNoOfFreeRbtID+'" size="10" maxlength="5" value="0"  onkeypress="return numberOnly(event);" />';
		
		$('<td/>').html(noOfFreeRbt).appendTo(t_row);
        
		
		
		//######## Creating addButton Field
		var addBtnStr='<input type="button" value="'+addButtonLabel+'" class="subadd" onclick="addRbtPurchaseFallback(';
		addBtnStr+="'"+rbtp_DIV_Array[0]+"')";
		addBtnStr+='"/>';
		//alert(addBtnStr);
		$('<td/>').html(addBtnStr).appendTo(t_row);
		
		//######## Creating deleteButton Field
		var deleteBtnStr='<input type="button" value="'+deleteButtonLabel+'" data-divid="'+newDivID+'" onclick="deleteMe(';
		deleteBtnStr+="'"+newDivID.trim()+"')";
		deleteBtnStr+='"/>';
		//alert(deleteBtnStr);
		$('<td/>').html(deleteBtnStr).appendTo(t_row);

		//##### appending row to newTable
		newTable.append(t_row);
		
		//##### appending table to newDiv
		newDIV.append(newTable);
		
		//##### appending newDiv to subDiv
		$("#rbtPurchaseDiv").append(newDIV);

		//#### Managing rbtp_DIV_Array array
		//alert("old Array="+rbtp_DIV_Array);
		//### Removing 1st index from rbtp_DIV_Array
		 rbtp_DIV_Array.splice(0,1);
		 
		 rbtList=rbtList+1;
		 //rbtp_DIV_Array.sort();
		// alert("New Array="+rbtp_DIV_Array);
}


// ************** Rbt Purchase Renewal **************************** 
function addRbtPurRenewFallback(divID){
	
	 if(!validateFieldMe(divID)){
	 	 return;
	 }
	 if(rbtpRenew_DIV_Array.length<=0){
		 alert(rangeExceedAlert);
		 return;
	 }
	 
	    var rbtPurRenewSelectID="rateplan_"+rbtpRenew_DIV_Array[0]+"_chargingCode";
		var rbtPurRenewValidityID="rateplan_"+rbtpRenew_DIV_Array[0]+"_validity";

		var rbtRenewSTID="rateplan_"+rbtpRenew_DIV_Array[0]+"_STID";
		var rbtRenewFTID="rateplan_"+rbtpRenew_DIV_Array[0]+"_FTID";
		
		var inputIndex=(rbtpRenew_DIV_Array[0].split("_")[1]);
		
		//alert(" SUB_CODE_ID ="+subSelectID+", SUB_VALIDITY_ID ="+subValidityID+", INPUT INDEX ="+inputIndex);

		var rbtPurRenewSelectName='rateplan.rbtRenewDetails['+inputIndex+'].chargingCode';
		var rbtPurRenewValidityName='rateplan.rbtRenewDetails['+inputIndex+'].validity';

		var stIDName='rateplan.rbtRenewDetails['+inputIndex+'].renewSuccessTemplateID';
		var ftIDName='rateplan.rbtRenewDetails['+inputIndex+'].renewFailedTemplateID';
		
		var newDivID=rbtpRenew_DIV_Array[0];
		
		//alert(" SUB_CODE_NAME ="+subSelectName+", SUB_VALIDITY_NAME ="+subValidityName+", New DIV ID="+newDivID);
		var newDIV=$('<div/>',{"id":newDivID});
		var newTable=$('<table/>').attr({border:"1",width:"100%",cellspacing:"0"});
		var t_row=$('<tr/>');

		var rbtPurRenewCodeStr=chargingCodeLabel;
				
		//######## Creating Select Option
		rbtPurRenewCodeStr+='<select name="'+rbtPurRenewSelectName+'" id="'+rbtPurRenewSelectID+'" onchange="validateOption(';
		rbtPurRenewCodeStr+="'"+newDivID+"');";
		rbtPurRenewCodeStr+='" style="width:60px;">';
		rbtPurRenewCodeStr+='">';
		
		rbtPurRenewCodeStr+='<option value="0">select</option>';
		var chg_array=null;
		for(var i=0;i<FB_CHG_CODES.length;i++){
			chg_array=FB_CHG_CODES[i].split("#");
			rbtPurRenewCodeStr+='<option value="'+chg_array[0]+'">'+chg_array[1]+'</option>';
		}
		rbtPurRenewCodeStr+='</select>';
		//alert("CHARGE_CODES  ==== "+rbtPurCodeStr);
		$('<td/>').html(rbtPurRenewCodeStr).appendTo(t_row);
		
		//######## Creating Validity text Field
		var validityStr=validityLabel+' : &nbsp;&nbsp; <input type="text" name="'+rbtPurRenewValidityName+'"  id="'+rbtPurRenewValidityID+'" size="10" maxlength="5" value="0"  onkeypress="return numberOnly(event);" />';
		//alert(validity$("#rateplan_subPostPaidTemplateId").css("border-color:","lightyellow");Str);
		$('<td/>').html(validityStr).appendTo(t_row);
		
		var stidStr='Select Template ID: </br> <select	name="'+stIDName+'" id="'+rbtRenewSTID+'"  style="width:90px" >';
		stidStr+='<option value="0">SUCCESS TEMPLATE-ID</option>';				
		for(var i=0;i<TEMPLATE_IDS.length;i++){
			stidStr+='<option value="'+TEMPLATE_IDS[i]+'">'+TEMPLATE_IDS[i]+'</option>';			
		}
		stidStr+="</select>";
		var ftidStr='<select	name="'+ftIDName+'" id="'+rbtRenewFTID+'"  style="width:90px" >';
		ftidStr+='<option value="0">FAILURE TEMPLATE-ID</option>';				
		for(var i=0;i<TEMPLATE_IDS.length;i++){
			ftidStr+='<option value="'+TEMPLATE_IDS[i]+'">'+TEMPLATE_IDS[i]+'</option>';			
		}
		ftidStr+="</select>";
		$('<td/>').html(stidStr+ftidStr).appendTo(t_row);

		
		//######## Creating addButton Field
		var addBtnStr='<input type="button" value="'+addButtonLabel+'" class="subadd" onclick="addRbtPurRenewFallback(';
		addBtnStr+="'"+rbtpRenew_DIV_Array[0]+"')";
		addBtnStr+='"/>';
		//alert(addBtnStr);
		$('<td/>').html(addBtnStr).appendTo(t_row);
		
		//######## Creating deleteButton Field
		var deleteBtnStr='<input type="button" value="'+deleteButtonLabel+'" data-divid="'+newDivID+'" onclick="deleteMe(';
		deleteBtnStr+="'"+newDivID.trim()+"')";
		deleteBtnStr+='"/>';
		//alert(deleteBtnStr);
		$('<td/>').html(deleteBtnStr).appendTo(t_row);

		//##### appending row to newTable
		newTable.append(t_row);
		
		//##### appending table to newDiv
		newDIV.append(newTable);
		
		//##### appending newDiv to subDiv
		$("#rbtRenewDiv").append(newDIV);
    
		//#### Managing rbtp_DIV_Array array
		//alert("old Array="+rbtpRenew_DIV_Array);
		//### Removing 1st index from rbtp_DIV_Array
		 rbtpRenew_DIV_Array.splice(0,1);
		 //rbtpRenew_DIV_Array.sort();
		 
		 //alert("New Array===="+rbtpRenew_DIV_Array);
}
 
// ************** End Of Rbt Purchase Renewal *********************** 
 
//  *****************for Recording ******************** 
function addRecordingFallback(divID){
	
	 
	 if(!validateFieldMe(divID)){
	 	 return;
	 }
	 if(recordp_DIV_Array.length<=0){
		 alert(rangeExceedAlert);
		 return;
	 }
	 
	    //var rbtPurSelectID="rateplan_"+rbtp_DIV_Array[0]+"_chargingCode";
	    //var recordSelectID="rateplan_"+recordp_DIV_Array[0]+"_chargingCode";
		//var rbtPurValidityID="rateplan_"+rbtp_DIV_Array[0]+"_validity";
		//var recordValidityID="rateplan_"+recordp_DIV_Array[0]+"_validity";
		var recordingNoOfRbtID="rateplan_"+recordp_DIV_Array[0]+"_noOfRbt";
		var recordingNoOfFreeRbtID="rateplan_"+recordp_DIV_Array[0]+"_noOfFreeRbt";
		
		
		var inputIndex=(recordp_DIV_Array[0].split("_")[1]);
		
		//alert(" SUB_CODE_ID ="+subSelectID+", SUB_VALIDITY_ID ="+subValidityID+", INPUT INDEX ="+inputIndex);

		//var recordSelectName='packsub.rbtRecordingDetails['+inputIndex+'].chargingCode';
		//var recordValidityName='packsub.rbtRecordingDetails['+inputIndex+'].validity';
		var recordNoOfRbtName='packsub.rbtRecordingDetails['+inputIndex+'].noOfRbt';
		var recordNoOfFreeRbtName='packsub.rbtRecordingDetails['+inputIndex+'].noOfFreeRbt';
		
		
		var newDivID=recordp_DIV_Array[0];
		
		//alert(" SUB_CODE_NAME ="+subSelectName+", SUB_VALIDITY_NAME ="+subValidityName+", New DIV ID="+newDivID);
		var newDIV=$('<div/>',{"id":newDivID});
		var newTable=$('<table/>').attr({border:"1",width:"100%",cellspacing:"0"});
		var t_row=$('<tr/>');

		//var recordCodeStr=chargingCodeLabel;
				
		//######## Creating Select Option
		//recordCodeStr+='<select name="'+recordSelectName+'" id="'+recordSelectID+'" onchange="validateOption(';
		//recordCodeStr+="'"+newDivID+"');";
		//recordCodeStr+='">';
		
		//recordCodeStr+='<option value="0">select</option>';
		//var chg_array=null;
		//for(var i=0;i<FB_CHG_CODES.length;i++){
		//	chg_array=FB_CHG_CODES[i].split("#");
		//	recordCodeStr+='<option value="'+chg_array[0]+'">'+chg_array[1]+'</option>';
		//}
		//recordCodeStr+='</select>';
		//alert("CHARGE_CODES  ==== "+rbtPurCodeStr);
		//$('<td/>').html(recordCodeStr).appendTo(t_row);
		
		//######## Creating Validity text Field
		//var validityStr=validityLabel+' : &nbsp;&nbsp;<input type="text" name="'+recordValidityName+'"  id="'+recordValidityID+'" size="10" maxlength="5" value="0"  onkeypress="return numberOnly(event);" >-'+daysLabel;
		//alert(validityStr);
	//	$('<td/>').html(validityStr).appendTo(t_row);

		//##### Creating NOR ##################
		var noOfRbtStr=noOfRbtLabel+' : &nbsp;&nbsp;<input type="text" name="'+recordNoOfRbtName+'"  id="'+recordingNoOfRbtID+'" size="10" maxlength="5" value="0"  onkeypress="return numberOnly(event);" >';
		//alert(validityStr);
		$('<td/>').html(noOfRbtStr).appendTo(t_row);

		var noOfFreeRbtStr=noOfFreeRbtLabel+' : &nbsp;&nbsp;<input type="text" name="'+recordNoOfFreeRbtName+'"  id="'+recordingNoOfFreeRbtID+'" size="10" maxlength="5" value="0"  onkeypress="return numberOnly(event);" >';
		//alert(validityStr);
		$('<td/>').html(noOfFreeRbtStr).appendTo(t_row);

		
		
		//######## Creating addButton Field
		var addBtnStr='<input type="button" value="'+addButtonLabel+'" class="subadd" onclick="addRecordingFallback(';
		addBtnStr+="'"+recordp_DIV_Array[0]+"')";
		addBtnStr+='"/>';
		//alert(addBtnStr);
		$('<td/>').html(addBtnStr).appendTo(t_row);
		
		//######## Creating deleteButton Field
		var deleteBtnStr='<input type="button" value="'+deleteButtonLabel+'" data-divid="'+newDivID+'" onclick="deleteMe(';
		deleteBtnStr+="'"+newDivID.trim()+"')";
		deleteBtnStr+='"/>';
		//alert(deleteBtnStr);
		$('<td/>').html(deleteBtnStr).appendTo(t_row);

		//##### appending row to newTable
		newTable.append(t_row);
		
		//##### appending table to newDiv
		newDIV.append(newTable);
		
		//##### appending newDiv to subDiv
		$("#recordDiv").append(newDIV);

		//#### Managing rbtp_DIV_Array array
		//alert("old Array="+recordp_DIV_Array);
		//### Removing 1st index from rbtp_DIV_Array
		 recordp_DIV_Array.splice(0,1);
		 
		 recordingList=recordingList+1;
		// recordp_DIV_Array.sort();
		 //alert("New Array="+recordp_DIV_Array);
}

// ************************* Recording Renew ************************ 
function addRecordingRenewFallback(divID){
	
	 if(!validateFieldMe(divID)){
	 	 return;
	 }
	 if(recordRenew_DIV_Array.length<=0){
		 alert(rangeExceedAlert);
		 return;
	 }
	 
	    var recordingRenewSelectID="rateplan_"+recordRenew_DIV_Array[0]+"_chargingCode";
		var recordingRenewValidityID="rateplan_"+recordRenew_DIV_Array[0]+"_validity";

		var recordingRenewSTID="rateplan_"+recordRenew_DIV_Array[0]+"_STID";
		var recordingRenewFTID="rateplan_"+recordRenew_DIV_Array[0]+"_FTID";
		
		var inputIndex=(recordRenew_DIV_Array[0].split("_")[1]);
		
		//alert(" SUB_CODE_ID ="+subSelectID+", SUB_VALIDITY_ID ="+subValidityID+", INPUT INDEX ="+inputIndex);

		var recordingRenewSelectName='rateplan.recordingRenewDetails['+inputIndex+'].chargingCode';
		var recordingRenewValidityName='rateplan.recordingRenewDetails['+inputIndex+'].validity';

		var stIDName='rateplan.recordingRenewDetails['+inputIndex+'].renewSuccessTemplateID';
		var ftIDName='rateplan.recordingRenewDetails['+inputIndex+'].renewFailedTemplateID';
		
		var newDivID=recordRenew_DIV_Array[0];
		
		//alert(" SUB_CODE_NAME ="+subSelectName+", SUB_VALIDITY_NAME ="+subValidityName+", New DIV ID="+newDivID);
		var newDIV=$('<div/>',{"id":newDivID});
		var newTable=$('<table/>').attr({border:"1",width:"100%",cellspacing:"0"});
		var t_row=$('<tr/>');

		var recordingRenewCodeStr=chargingCodeLabel;
				
		//######## Creating Select Option
		recordingRenewCodeStr+='<select name="'+recordingRenewSelectName+'" id="'+recordingRenewSelectID+'" onchange="validateOption(';
		recordingRenewCodeStr+="'"+newDivID+"');";
		recordingRenewCodeStr+='" style="width:60px;">';
		recordingRenewCodeStr+='">';
		
		recordingRenewCodeStr+='<option value="0">select</option>';
		var chg_array=null;
		for(var i=0;i<FB_CHG_CODES.length;i++){
			chg_array=FB_CHG_CODES[i].split("#");
			recordingRenewCodeStr+='<option value="'+chg_array[0]+'">'+chg_array[1]+'</option>';
		}
		recordingRenewCodeStr+='</select>';
		//alert("CHARGE_CODES  ==== "+rbtPurCodeStr);
		$('<td/>').html(recordingRenewCodeStr).appendTo(t_row);
		
		//######## Creating Validity text Field
		var validityStr=validityLabel+' :&nbsp;&nbsp;  <input type="text" name="'+recordingRenewValidityName+'"  id="'+recordingRenewValidityID+'" size="10" maxlength="5" value="0"  onkeypress="return numberOnly(event);"/>';
		//alert(validity$("#rateplan_subPostPaidTemplateId").css("border-color:","lightyellow");Str);
		$('<td/>').html(validityStr).appendTo(t_row);
		
		var stidStr='Select Template ID: </br> <select	name="'+stIDName+'" id="'+recordingRenewSTID+'"  style="width:90px" >';
		stidStr+='<option value="0">SUCCESS TEMPLATE-ID</option>';				
		for(var i=0;i<TEMPLATE_IDS.length;i++){
			stidStr+='<option value="'+TEMPLATE_IDS[i]+'">'+TEMPLATE_IDS[i]+'</option>';			
		}
		stidStr+="</select>";
		var ftidStr='<select	name="'+ftIDName+'" id="'+recordingRenewFTID+'"  style="width:90px" >';
		ftidStr+='<option value="0">FAILURE TEMPLATE-ID</option>';				
		for(var i=0;i<TEMPLATE_IDS.length;i++){
			ftidStr+='<option value="'+TEMPLATE_IDS[i]+'">'+TEMPLATE_IDS[i]+'</option>';			
		}
		ftidStr+="</select>";
		$('<td/>').html(stidStr+ftidStr).appendTo(t_row);

		
		//######## Creating addButton Field
		var addBtnStr='<input type="button" value="'+addButtonLabel+'" class="subadd" onclick="addRecordingRenewFallback(';
		addBtnStr+="'"+recordRenew_DIV_Array[0]+"')";
		addBtnStr+='"/>';
		//alert(addBtnStr);
		$('<td/>').html(addBtnStr).appendTo(t_row);
		
		//######## Creating deleteButton Field
		var deleteBtnStr='<input type="button" value="'+deleteButtonLabel+'" data-divid="'+newDivID+'" onclick="deleteMe(';
		deleteBtnStr+="'"+newDivID.trim()+"')";
		deleteBtnStr+='"/>';
		//alert(deleteBtnStr);
		$('<td/>').html(deleteBtnStr).appendTo(t_row);

		//##### appending row to newTable
		newTable.append(t_row);
		
		//##### appending table to newDiv
		newDIV.append(newTable);
		
		//##### appending newDiv to subDiv
		$("#recordRenewDiv").append(newDIV);
   
		//#### Managing rbtp_DIV_Array array
		//alert("old Array="+rbtpRenew_DIV_Array);
		//### Removing 1st index from rbtp_DIV_Array
		 recordRenew_DIV_Array.splice(0,1);
		 
		 
		 //recordRenew_DIV_Array.sort();
		 
		 //alert("New Array===="+rbtpRenew_DIV_Array);
}


// ******************************* End Of Recording ***************************** -->

   
function addGiftFallback(divID){
	
	/// alert("Gift");
	 if(!validateFieldMe(divID)){
	 	 return;
	 }
	 if(giftp_DIV_Array.length<=0){
		 alert(rangeExceedAlert);
		 return;
	 }
	 
	// alert("size["+giftp_DIV_Array.length+"]");
	 
	 
	 
		//var giftSelectID="rateplan_"+giftp_DIV_Array[0]+"_chargingCode";
		//var giftValidityID="rateplan_"+giftp_DIV_Array[0]+"_validity";
		var giftpNoOfRbtID="rateplan_"+giftp_DIV_Array[0]+"_noOfRbt";
		var giftpNoOfFreeRbtID="rateplan_"+giftp_DIV_Array[0]+"_noOfFreeRbt";
		
		var inputIndex=(giftp_DIV_Array[0].split("_")[1]);
		
		//var giftSelectName='packsub.rbtGiftDetails['+inputIndex+'].chargingCode';
		//var giftValidityName='packsub.rbtGiftDetails['+inputIndex+'].validity';
		var giftpNoOfRbtName='packsub.rbtGiftDetails['+inputIndex+'].noOfRbt';
		var giftpNoOfFreeRbtName='packsub.rbtGiftDetails['+inputIndex+'].noOfFreeRbt';
		
		
		
		var newDivID=giftp_DIV_Array[0];
	    var newDIV=$('<div/>',{"id":newDivID});
		var newTable=$('<table/>').attr({border:"1",width:"100%",cellspacing:"0"});
		var t_row=$('<tr/>');
        		
		//var giftCodeStr=chargingCodeLabel;
				
		//######## Creating Select Option
		//giftCodeStr+='<select name="'+giftSelectName+'" id="'+giftSelectID+'" onchange="validateOption(';
		//giftCodeStr+="'"+newDivID+"');";
		//giftCodeStr+='">';
		
		//giftCodeStr+='<option value="0">select</option>';
		//var chg_array=null;
		//for(var i=0;i<FB_CHG_CODES.length;i++){
		//	chg_array=FB_CHG_CODES[i].split("#");
		//	giftCodeStr+='<option value="'+chg_array[0]+'">'+chg_array[1]+'</option>';
		//}
		//giftCodeStr+='</select>';
		//$('<td/>').html(giftCodeStr).appendTo(t_row);
		
		//######## Creating Validity text Field
		//var validityStr=validityLabel+' : &nbsp;&nbsp; <input type="text" name="'+giftValidityName+'"  id="'+giftValidityID+'" size="10" maxlength="5" value="0" onkeypress="return numberOnly(event);" >-'+daysLabel;
		//$('<td/>').html(validityStr).appendTo(t_row);

		//######## Creating Validity text Field
		var noOfRbtStr=noOfRbtLabel+' : &nbsp;&nbsp; <input type="text" name="'+giftpNoOfRbtName+'"  id="'+giftpNoOfRbtID+'" size="10" maxlength="5" value="0" onkeypress="return numberOnly(event);" >';
		$('<td/>').html(noOfRbtStr).appendTo(t_row);
		
		var noOfFreeRbtStr=noOfFreeRbtLabel+' : &nbsp;&nbsp; <input type="text" name="'+giftpNoOfFreeRbtName+'"  id="'+giftpNoOfFreeRbtID+'" size="10" maxlength="5" value="0" onkeypress="return numberOnly(event);" >';
		$('<td/>').html(noOfFreeRbtStr).appendTo(t_row);
		

		//######## Creating addButton Field
		var addBtnStr='<input type="button" value="'+addButtonLabel+'" class="subadd" onclick="addGiftFallback(';
		addBtnStr+="'"+giftp_DIV_Array[0]+"')";
		addBtnStr+='"/>';
		//alert(addBtnStr);
		$('<td/>').html(addBtnStr).appendTo(t_row);
		
		//######## Creating deleteButton Field
		var deleteBtnStr='<input type="button" value="'+deleteButtonLabel+'" data-divid="'+newDivID+'" onclick="deleteMe(';
		deleteBtnStr+="'"+newDivID.trim()+"')";
		deleteBtnStr+='"/>';
		$('<td/>').html(deleteBtnStr).appendTo(t_row);

		//##### appending row to newTable
		newTable.append(t_row);
		
		//##### appending table to newDiv
		newDIV.append(newTable);
		
		//##### appending newDiv to subDiv
		$("#giftDiv").append(newDIV);

		//#### Managing rbtp_DIV_Array array
		//alert("old Array="+giftp_DIV_Array);
		//### Removing 1st index from rbtp_DIV_Array
		giftp_DIV_Array.splice(0,1);
		
		giftList=giftList+1;
		 //giftp_DIV_Array.sort();
		 //alert("New Array="+giftp_DIV_Array);
}
  
//********************** end of GIFT ************************** 



//**********************Free Rbt ********************************

function addFreeRbtFallback(divID){
	
	
    // alert("free");
	 if(!validateFieldMe(divID)){
		  return;
	 }
	
	  
	 if(free_DIV_Array.length<=0){
		 alert(rangeExceedAlert);
		 return;
	 }
	// alert("size "+free_DIV_Array.length);
	 
	 
	 	var freeSelectID="rateplan_"+free_DIV_Array[0]+"_chargingCode";
		var freeValidityID="rateplan_"+free_DIV_Array[0]+"_validity";
		//var freeNoOfRbtID="rateplan_"+free_DIV_Array[0]+"_noOfRbt";
		//var freeNoOfFreeRbtID="rateplan_"+free_DIV_Array[0]+"_noOfFreeRbt";
		
		
		
		var inputIndex=(free_DIV_Array[0].split("_")[1]);
		
		var freeSelectName='packsub.freeRbtDetails['+inputIndex+'].chargingCode';
		
		var freeValidityName='packsub.freeRbtDetails['+inputIndex+'].validity';
		//var freeNoOfRbtName='packsub.freeRbtDetails['+inputIndex+'].noOfRbt';
		//var freeNoOfFreeRbtName='packsub.freeRbtDetails['+inputIndex+'].NoOfFreeRbt';
		
		
		var newDivID=free_DIV_Array[0];
		
		//alert("new divId "+newDivID);
		
	    var newDIV=$('<div/>',{"id":newDivID});
		var newTable=$('<table/>').attr({border:"1",width:"100%",cellspacing:"0"});
		var t_row=$('<tr/>');

		var freeCodeStr=chargingCodeLabel;
				
		//######## Creating Select Option
		freeCodeStr+='<select name="'+freeSelectName+'" id="'+freeSelectID+'" onchange="validateOption(';
		freeCodeStr+="'"+newDivID+"');";
		freeCodeStr+='">';
		
		freeCodeStr+='<option value="0">select</option>';
		var chg_array=null;
		for(var i=0;i<FB_CHG_CODES.length;i++){
			chg_array=FB_CHG_CODES[i].split("#");
			freeCodeStr+='<option value="'+chg_array[0]+'">'+chg_array[1]+'</option>';
		}
		freeCodeStr+='</select>';
		$('<td/>').html(freeCodeStr).appendTo(t_row);
		
		//######## Creating Validity text Field
		var validityStr=validityLabel+' : &nbsp;&nbsp; <input type="text" name="'+freeValidityName+'"  id="'+freeValidityID+'" size="10" maxlength="5" value="0" onkeypress="return numberOnly(event);" >-'+daysLabel;
		$('<td/>').html(validityStr).appendTo(t_row);

		
		// ##### NOR ################### //
	//	var noOfRbtStr=noOfRbtLabel+' : &nbsp;&nbsp; <input type="text" name="'+freeNoOfRbtName+'"  id="'+freeNoOfRbtID+'" size="10" maxlength="5" value="0" onkeypress="return numberOnly(event);" >';
	//	$('<td/>').html(noOfRbtStr).appendTo(t_row);
       
		// ############################# //
		
		// ##### NOFR ################### //
	//	var noOfFreeRbtStr=noOfFreeRbtLabel+' : &nbsp;&nbsp; <input type="text" name="'+freeNoOfFreeRbtName+'"  id="'+freeNoOfFreeRbtID+'" size="10" maxlength="5" value="0" onkeypress="return numberOnly(event);" >';
	//	$('<td/>').html(noOfFreeRbtStr).appendTo(t_row);
       
		// ############################# //
		
		
		
		
		
		//######## Creating addButton Field
		var addBtnStr='<input type="button" value="'+addButtonLabel+'" class="subadd" onclick="addFreeRbtFallback(';
		addBtnStr+="'"+free_DIV_Array[0]+"')";
		addBtnStr+='"/>';
		//alert(addBtnStr);
		$('<td/>').html(addBtnStr).appendTo(t_row);
		
		//######## Creating deleteButton Field
		var deleteBtnStr='<input type="button" value="'+deleteButtonLabel+'" data-divid="'+newDivID+'" onclick="deleteMe(';
		deleteBtnStr+="'"+newDivID.trim()+"')";
		deleteBtnStr+='"/>';
		$('<td/>').html(deleteBtnStr).appendTo(t_row);

		//##### appending row to newTable
		newTable.append(t_row);
		
		//##### appending table to newDiv
		newDIV.append(newTable);
		
		//##### appending newDiv to subDiv
		$("#freeDiv").append(newDIV);

		//#### Managing rbtp_DIV_Array array
		//alert("old Array="+giftp_DIV_Array);
		//### Removing 1st index from rbtp_DIV_Array
		 free_DIV_Array.splice(0,1);
		 
		 freeList=freeList+1;
		 //giftp_DIV_Array.sort();
		 //alert("New Array="+giftp_DIV_Array);
}





//********************End Free Rbt ****************************

function validateFieldMe(divID){

	
	var optionId=divID.split("_");
	//alert(optionId);
	var numbers = /^[-+]?[0-9]+$/;
	
	if(optionId[0]=="sub"){
		
		var subSelectID="rateplan_"+divID+"_chargingCode";
		var subValidityID="rateplan_"+divID+"_validity";

		var chgCode=$("#"+subSelectID+" option:selected").val();
		var validity=$("#"+subValidityID).val();
		
		
		//alert("validity:"+validity);
	
		//var chgCode=$('#rateplan.sub_0.chargingCode option:selected').attr('value');
		//var validity=$("input[id$=rateplan.sub_0.validity]").val()
		//var validity=$('#rateplan.sub_0.validity').val();
		//var validity=$('#'+subValidityID).val();
		
		//$("#"+subValidityID).val(0);
		//$("#"+subValidityID).focus();
		
		//var chgCode=doc$("#rateplan_subPostPaidTemplateId").css("border-color:","lightyellow");ument.getElementById(subSelectID).options[document.getElementById(subSelectID).selectedIndex].value;
		//var validity=document.getElementById(subValidityID).value;
				
	//	alert("Validation CHG_CODE="+chgCode);
		//alert("Validation VALIDITY="+validity);
		
		
		if( chgCode==0 ){
			
			
			alert("No Charge code is selcted, Please Select Proper Code!");
			document.getElementById(subSelectID).focus();
			return false;
		}else if(!validity.match(numbers)){
			alert("Invalid Validty Value Only Numeric Allowed");
			document.getElementById(subValidityID).focus();
			return false;	
		}else if(validity==0){
			
			alert("Please Enter Validty Value greater than zero");
			document.getElementById(subValidityID).focus();
			
			}
		
		else{
			//alert("Add validation is cleared!!");
			return true;
		}
		
	}else if(optionId[0]=="rbtp"){
		//var rbtpSelectID="rateplan_"+divID+"_chargingCode";
		//var rbtpValidityID="rateplan_"+divID+"_validity";
		var noOfRbtID="rateplan_"+divID+"_noOfRbt";
		var noOfFreeRbtID="rateplan_"+divID+"_noOfFreeRbt";
		
	      
		//alert(rbtpSelectID+" ########### "+rbtpValidityID);

		//var chgCode=$("#"+rbtpSelectID+" option:selected").val();
		//var validity=$("#"+rbtpValidityID).val();
		var noOfRbt=$("#"+noOfRbtID).val();  
		var noOfFreeRbt=$("#"+noOfFreeRbtID).val(); 
		
		//alert("Validation CHG_CODE="+chgCode);
		//alert("Validation VALIDITY="+validity);
		//alert("Validation NOR="+noOfRbt);
		//alert("Validation NOFR="+noOfFreeRbt);
	
		
		
		/*if( chgCode==0 ){
			alert("No Charge code is selcted, Please Select Proper Code!");
			$("#"+rbtpSelectID).focus();
				//document.getElementById(rbtpSelectID).focus();
			return false;
		}else if(!validity.match(numbers)){
			alert("Invalid Validty Value Only Numeric Allowed");
			$("#"+rbtpValidityID).focus();
			//document.getElementById(rbtpValidityID).focus();
			return false;	
		}else if(validity==0){
			alert("Please Enter Validty Value greater than zero");
			$("#"+rbtpValidityID).focus();
			//document.getElementById(rbtpValidityID).focus();
			return false;	
		}*/
		if(!noOfRbt.match(numbers)){
			alert("Invalid Value Only Numeric Allowed");
			$("#"+noOfRbtID).focus();
			//document.getElementById(rbtpValidityID).focus();
			return false;	
		}
		else if(!noOfFreeRbt.match(numbers)){
			alert("Invalid Value Only Numeric Allowed");
			$("#"+noOfFreeRbtID).focus();
			//document.getElementById(rbtpValidityID).focus();
			return false;	
		}
			
		else{
			//alert("Add validation is cleared!!");
			return true;
		}
	}
	
	//added by harjinder
	else if(optionId[0]=="free"){
		
		
		var rbtpSelectID="rateplan_"+divID+"_chargingCode";
		var rbtpValidityID="rateplan_"+divID+"_validity";
		//var noOfRbtID="rateplan_"+divID+"_noOfRbt";
		//var noOfFreeRbtID="rateplan_"+divID+"_noOfFreeRbt";
		

		
		//alert(rbtpSelectID+" ########### "+rbtpValidityID);

		var chgCode=$("#"+rbtpSelectID+" option:selected").val();
		var validity=$("#"+rbtpValidityID).val();
		//var noOfRbt=$("#"+noOfRbtID).val();  
		//var noOfFreeRbt=$("#"+noOfFreeRbtID).val(); 
		

		
		if( chgCode==0 ){
			alert("No Charge code is selcted, Please Select Proper Code!");
			$("#"+rbtpSelectID).focus();
				//document.getElementById(rbtpSelectID).focus();
			return false;
		}else if(!validity.match(numbers)){
			alert("Invalid Validty Value Only Numeric Allowed");
			$("#"+rbtpValidityID).focus();
			//document.getElementById(rbtpValidityID).focus();
			return false;	
		}else if(validity==0){
			alert("Please Enter Validty Value greater than zero");
			$("#"+rbtpValidityID).focus();
			//document.getElementById(rbtpValidityID).focus();
			return false;	
		}
		
		 /*if(!noOfRbt.match(numbers)){
			alert("Invalid Value Only Numeric Allowed");
			$("#"+noOfRbtID).focus();
			//document.getElementById(rbtpValidityID).focus();
			return false;	
		}
		else if(!noOfFreeRbt.match(numbers)){
			alert("Invalid Value Only Numeric Allowed");
			$("#"+noOfFreeRbtID).focus();
			//document.getElementById(rbtpValidityID).focus();
			return false;	
		}	*/
		else{
			//alert("Add validation is cleared!!");
			return true;
		}
	}
	
	//

	else if(optionId[0]=="recordp"){
			//var recordpSelectID="rateplan_"+divID+"_chargingCode";
			//var recordpValidityID="rateplan_"+divID+"_validity";
			var noOfRbtID="rateplan_"+divID+"_noOfRbt";
			var noOfFreeRbtID="rateplan_"+divID+"_noOfFreeRbt";
			
			
			//alert(rbtpSelectID+" ########### "+rbtpValidityID);

			//var chgCode=$("#"+recordpSelectID+" option:selected").val();
			//var validity=$("#"+recordpValidityID).val();
			var noOfRbt=$("#"+noOfRbtID).val();  
			var noOfFreeRbt=$("#"+noOfFreeRbtID).val();
			

		//	alert("Validation CHG_CODE="+chgCode);
			//alert("Validation VALIDITY="+validity);
		//	alert("Validation NOR="+noOfRbt);
		//	alert("Validation NOFR="+noOfFreeRbt);
			
			
			//alert("Validation CHG_CODE="+chgCode);
			//alert("Validation VALIDITY="+validity);
			
		/*	if( chgCode==0 ){
				alert("No Charge code is selcted, Please Select Proper Code!");
				$("#"+recordpSelectID).focus();
					//document.getElementById(rbtpSelectID).focus();
				return false;
			}else if(!validity.match(numbers)){
				alert("Invalid Validty Value Only Numeric Allowed");
				$("#"+recordpValidityID).focus();
				//document.getElementById(rbtpValidityID).focus();
				return false;	
			}else if(validity==0){
				alert("Please Enter Validty Value greater than zero");
				$("#"+recordpValidityID).focus();
				//document.getElementById(rbtpValidityID).focus();
				return false;	
			}*/
			
			if(!noOfRbt.match(numbers)){
				alert("Invalid Value Only Numeric Allowed");
				$("#"+noOfRbtID).focus();
				//document.getElementById(rbtpValidityID).focus();
				return false;	
			}
			else if(!noOfFreeRbt.match(numbers)){
				alert("Invalid Value Only Numeric Allowed");
				$("#"+noOfFreeRbtID).focus();
				//document.getElementById(rbtpValidityID).focus();
				return false;	
			}	
			else{
				//alert("Add validation is cleared!!");
				return true;
			}			
	}
	else if(optionId[0]=="giftp"){
			//var giftpSelectID="rateplan_"+divID+"_chargingCode";
			//var giftpValidityID="rateplan_"+divID+"_validity";
			var noOfRbtID="rateplan_"+divID+"_noOfRbt";
			var noOfFreeRbtID="rateplan_"+divID+"_noOfFreeRbt";
			
			
			

			//alert(rbtpSelectID+" ########### "+rbtpValidityID);

			//var chgCode=$("#"+giftpSelectID+" option:selected").val();
			//var validity=$("#"+giftpValidityID).val();
			var noOfRbt=$("#"+noOfRbtID).val();
			var noOfFreeRbt=$("#"+noOfFreeRbtID).val();
			

			/*if( chgCode==0 ){
				alert("No Charge code is selcted, Please Select Proper Code!");
				$("#"+giftpSelectID).focus();
				return false;
			}else if(!validity.match(numbers)){
				alert("Invalid Validty Value Only Numeric Allowed");
				$("#"+giftpValidityID).focus();
				//document.getElementById(rbtpValidityID).focus();
				return false;	
			}else if(validity==0){
				alert("Please Enter Validty Value greater than zero");
				$("#"+giftpValidityID).focus();
				//document.getElementById(rbtpValidityID).focus();
				return false;	
			}*/
			if(!noOfRbt.match(numbers)){
				alert("Invalid Value Only Numeric Allowed");
				$("#"+noOfRbtID).focus();
				//document.getElementById(rbtpValidityID).focus();
				return false;	
			}
			else if(!noOfFreeRbt.match(numbers)){
				alert("Invalid Value Only Numeric Allowed");
				$("#"+noOfFreeRbtID).focus();
				//document.getElementById(rbtpValidityID).focus();
				return false;	
			}				
			else{
				//alert("Add validation is cleared!!");
				return true;
			}

	} /// **************** for subscription Renew *********************** 
	else if(optionId[0]=="subRenew"){
			
		var subRenewSelectID="rateplan_"+divID+"_chargingCode";
		var subRenewValidityID="rateplan_"+divID+"_validity";
		//var stid="rateplan_"+divID+"_STID";
		//var ftid="rateplan_"+divID+"_FTID";

		var chgCode=$("#"+subRenewSelectID+" option:selected").val();
		var validity=$("#"+subRenewValidityID).val();
		//alert("Validation CHG_CODE="+chgCode);
		//alert("Validation VALIDITY="+validity);
		
		var stidVal=$("#"+stid).val();
		var ftidVal=$("#"+ftid).val();
		
		if( chgCode==0 ){
			alert("No Charge code is selcted, Please Select Proper Code!");
			document.getElementById(subRenewSelectID).focus();
			return false;
		}else if(!validity.match(numbers)){
			alert("Invalid Validty Value Only Numeric Allowed");
			document.getElementById(subRenewValidityID).focus();
			return false;	
		}else if(validity==0){
			alert("Please Enter Validty Value greater than zero");
			document.getElementById(subRenewValidityID).focus();
			return false;	
		}
		/*else if(stidVal==0){
			 alert(" Please select SUCCESS SMS Template ID!");
			 $("#"+stid).css("background-color","lightyellow");
			 $("#"+stid).focus();
			 return false;	 
		}else if(ftidVal==0){
			 alert(" Please select FAILURE SMS Template ID!");
			 $("#"+ftid).css("background-color","lightyellow");
			 $("#"+ftid).focus();
			 return false;	 
		}*/
		else{

			return true;
		}
  }else if(optionId[0]=="rbtpRenew"){
		var rbtpRenewSelectID="rateplan_"+divID+"_chargingCode";
		var rbtpRenewValidityID="rateplan_"+divID+"_validity";
		var stid="rateplan_"+divID+"_STID";
		var ftid="rateplan_"+divID+"_FTID";
	

		var chgCode=$("#"+rbtpRenewSelectID+" option:selected").val();
		var validity=$("#"+rbtpRenewValidityID).val();

				
		var stidVal=$("#"+stid).val();
		var ftidVal=$("#"+ftid).val();

		//alert("ID==> STID="+stid+", FTID="+ftid);
		//alert(" STID="+stidVal+", FTID="+ftidVal);
		
		if( chgCode==0 ){
			alert("No Charge code is selcted, Please Select Proper Code!");
			$("#"+rbtpRenewSelectID).focus();
				
			return false;
		}else if(!validity.match(numbers)){
			alert("Invalid Validty Value Only Numeric Allowed");
			$("#"+rbtpRenewValidityID).focus();
			return false;	
		}else if(stidVal==0){
			 alert(" Please select SUCCESS SMS Template ID!");
			 $("#"+stid).css("background-color","lightyellow");
			 $("#"+stid).focus();
			 return false;	 
		}else if(ftidVal==0){
			 alert(" Please select FAILURE SMS Template ID!");
			 $("#"+ftid).css("background-color","lightyellow");
			 $("#"+ftid).focus();
			 return false;	 
		}
		else{
			return true;
		}
	}
  // *************************** end ************************** -->
  // ******************** FOR RECORDING RENEW ********************** -->
	else if(optionId[0]=="recordRenew"){
		var recordRenewSelectID="rateplan_"+divID+"_chargingCode";
		var recordRenewValidityID="rateplan_"+divID+"_validity";
		var stid="rateplan_"+divID+"_STID";
		var ftid="rateplan_"+divID+"_FTID";
	

		var chgCode=$("#"+recordRenewSelectID+" option:selected").val();
		var validity=$("#"+recordRenewValidityID).val();

				
		var stidVal=$("#"+stid).val();
		var ftidVal=$("#"+ftid).val();
		if( chgCode==0 ){
			alert("No Charge code is selcted, Please Select Proper Code!");
			$("#"+recordRenewSelectID).focus();
				
			return false;
		}else if(!validity.match(numbers)){
			alert("Invalid Validty Value Only Numeric Allowed");
			$("#"+recordRenewValidityID).focus();
			return false;	
		}else if(stidVal==0){
			 alert(" Please select SUCCESS SMS Template ID!");
			 $("#"+stid).css("background-color","lightyellow");
			 $("#"+stid).focus();
			 return false;	 
		}else if(ftidVal==0){
			 alert(" Please select FAILURE SMS Template ID!");
			 $("#"+ftid).css("background-color","lightyellow");
			 $("#"+ftid).focus();
			 return false;	 
		}
		else{
			return true;
		}
	}// *************************** END ******************************* -->
	else{
		alert("No Match Found!!");
	}	
}

function deleteMe(divID){
	
	//alert("in delete "+divID);
	var id_arr=divID.split("_");
		
	//alert("id_arr[0] "+id_arr[0]);
	
	if(id_arr[0]=='sub'){
		//alert("DEL DIV ID ="+divID+", id_request="+id_arr);
         subList=subList-1;   
		//alert("old sub_DIV_Array="+sub_DIV_Array);
		if(sub_DIV_Array.length<=0){
			sub_DIV_Array.splice(0,0,divID);
		}else{
			sub_DIV_Array.splice(sub_DIV_Array.length,0,divID);
		}
		//sub_DIV_Array.sort();
		//alert("new sub_DIV_Array="+sub_DIV_Array);
		$('#'+divID).remove();
		//alert("Removed div is ["+divID +"]");
		
	}else if(id_arr[0]=='rbtp'){
		
		//alert("DEL DIV ID ="+divID+", id_request="+id_arr);
		rbtList=rbtList-1;
		//alert("old DIV_Array="+rbtp_DIV_Array);
		if(rbtp_DIV_Array.length<=0){
			rbtp_DIV_Array.splice(0,0,divID);
		}else{
			rbtp_DIV_Array.splice(rbtp_DIV_Array.length,0,divID);
		}
		//rbtp_DIV_Array.sort();
		//alert("new DIV_Array="+rbtp_DIV_Array);
		$('#'+divID).remove();		
	}


else if(id_arr[0]=='rbtpRenew'){
		
		//alert("DEL DIV ID ="+divID+", id_request="+id_arr);

		//alert("old DIV_Array="+rbtpRenew_DIV_Array);
		if(rbtpRenew_DIV_Array.length<=0){
			rbtpRenew_DIV_Array.splice(0,0,divID);
		}else{
			rbtpRenew_DIV_Array.splice(rbtpRenew_DIV_Array.length,0,divID);
		}
		//rbtpRenew_DIV_Array.sort();
		//alert("new DIV_Array="+rbtpRenew_DIV_Array);
		$('#'+divID).remove();		
	}

else if(id_arr[0]=='recordp'){
		
		//alert("DEL DIV ID ="+divID+", id_request="+id_arr);
	    recordingList=recordingList-1;
		//alert("old DIV_Array="+recordp_DIV_Array);
		if(recordp_DIV_Array.length<=0){
			recordp_DIV_Array.splice(0,0,divID);
		}else{
			recordp_DIV_Array.splice(recordp_DIV_Array.length,0,divID);
		}
		//recordp_DIV_Array.sort();
		//alert("new DIV_Array="+recordp_DIV_Array);
		$('#'+divID).remove();		
	}
else if(id_arr[0]=='recordRenew'){
	
		if(recordRenew_DIV_Array.length<=0){
		recordRenew_DIV_Array.splice(0,0,divID);
	}else{
		recordRenew_DIV_Array.splice(recordRenew_DIV_Array.length,0,divID);
	}
	//recordRenew_DIV_Array.sort();
	//alert("new DIV_Array="+rbtpRenew_DIV_Array);
	$('#'+divID).remove();		
}

	
else if(id_arr[0]=='giftp'){
	
	//alert("DEL DIV ID ="+divID+", id_request="+id_arr);
    giftList=giftList-1;
	//alert("old DIV_Array="+giftp_DIV_Array);
	if(giftp_DIV_Array.length<=0){
		giftp_DIV_Array.splice(0,0,divID);
	}else{
		giftp_DIV_Array.splice(giftp_DIV_Array.length,0,divID);
	}
	//giftp_DIV_Array.sort();
	//alert("new DIV_Array="+giftp_DIV_Array);
	$('#'+divID).remove();		
 }
 // ******************* FOR SUBSCRIPTION RENEW ********************* -->
 else if(id_arr[0]=='subRenew'){
	//alert("DEL DIV ID ="+divID+", id_request="+id_arr);
	 subReList=subReList-1;	
	//alert("old subRenew_DIV_Array="+subRenew_DIV_Array);
	if(subRenew_DIV_Array.length<=0){
		subRenew_DIV_Array.splice(0,0,divID);
	}else{
		subRenew_DIV_Array.splice(subRenew_DIV_Array.length,0,divID);
	}
	//subRenew_DIV_Array.sort();
	//alert("new subRe$("#rateplan_subPostPaidTemplateId").css("border-color:","lightyellow");new_DIV_Array="+subRenew_DIV_Array);
	$('#'+divID).remove();
	
 }// subRenew Ends Here
 
//************************FOR FREE RBT ********************//
	
 else if(id_arr[0]=='free'){
		//alert("DEL DIV ID ="+divID+", id_request="+id_arr);
	     freeList=freeList-1;
		//alert("old subRenew_DIV_Array="+subRenew_DIV_Array);
		if(free_DIV_Array.length<=0){
			free_DIV_Array.splice(0,0,divID);
		}else{
			free_DIV_Array.splice(free_DIV_Array.length,0,divID);
		}
		//subRenew_DIV_Array.sort();
		//alert("new subRe$("#rateplan_subPostPaidTemplateId").css("border-color:","lightyellow");new_DIV_Array="+subRenew_DIV_Array);
		$('#'+divID).remove();
		
	 }
	
	
//**************************END  RBT ****************//	
	
	
}// ********************** END  deleteMe ****************************

 function validateOption(divID){
	
	 
	var id_arr=divID.split("_");
	
	var inputID='rateplan_'+divID+'_chargingCode';
	
	   var chgCode=0;
	   var chgCode1=0;
	   var divID1="";
	   var inputID1="";
	   var codeOptions;

	   //chgCode=document.getElementById(inputID).options[document.getElementById(inputID).selectedIndex].value;
	   chgCode=$("#"+inputID).val();
		   
  	  if(id_arr[0]=="sub")
  	  {
  	  	
  	    //alert(" current sub_DIV_Array ="+sub_DIV_Array);
 	    for(var i=0;i<DIV_MAX_INDEX;i++)
 	 	    {
			divID1="sub_"+i;
			if(i==id_arr[1])
				{
				//alert("Self Div Index ["+divID1+"] ");
				continue;
			}  

			inputID1='rateplan_'+divID1+'_chargingCode';
			
			//codeOptions=document.getElementById(inputID1);
			codeOptions=$("#"+inputID1);
			
			if(codeOptions!=null)
				{
				//alert(" validating ID ="+inputID1);
				//chgCode1=codeOptions.options[document.getElementById(inputID1).selectedIndex].value;
                 chgCode1=codeOptions.val();
			 	if(chgCode==chgCode1)
				 {
					alert("Selected Charging Code= ["+chgCode+"-"+ $("#"+inputID+" option:selected").text()+"] is All-ready in use!");
				 	//document.getElementById(inputID).options[0].selected=true;
				 	 $("#"+inputID).val('0');
				 	break;
		     	}
		   }				  	    
  	  	 }
  	 } 
  	 else if(id_arr[0]=="subRenew")
     {
    	// ************* for subscription renew *********************
   	  	    for(var i=0;i<DIV_MAX_INDEX;i++)
  	  	    {
 			divID1="subRenew_"+i;
 			if(i==id_arr[1])
 	 			{
 			 continue;
 			    }  

 			inputID1='rateplan_'+divID1+'_chargingCode';
 			
 			codeOptions=$("#"+inputID1);
 			if(codeOptions!=null)
 	 			{
 				//alert(" validating ID ="+inputID1);
 				//chgCode1=codeOptions.options[document.getElementById(inputID1).selectedIndex].value;
                  chgCode1=codeOptions.val();
 			 	if(chgCode==chgCode1)
 	 			 	{
 					alert("Selected Charging Code=["+chgCode+"-"+ $("#"+inputID+" option:selected").text()+"] is All-ready in use!");
 				 	//document.getElementById(inputID).options[0].selected=true;
 				 	 $("#"+inputID).val('0');
 				 	break;
 		     	   }
 		     }				  	    
   	  	}
     }
     else if(id_arr[0]=="rbtp")
  	 {
 		//################### RBT Purchase validation 
 		
 		 for(var i=0;i<DIV_MAX_INDEX;i++)
  	  	 {
 			divID1="rbtp_"+i;
 			if(i==id_arr[1])
 	 			{
 				//alert("Self Div Index ["+divID1+"] ");
 				continue;
 			}  

 			inputID1='rateplan_'+divID1+'_chargingCode';
 			//codeOptions=document.getElementById(inputID1);
 			 codeOptions=$("#"+inputID1);
 			if(codeOptions!=null)
 	 			{
 				//alert(" validating ID ="+inputID1);
 				//chgCode1=codeOptions.options[document.getElementById(inputID1).selectedIndex].value;
 				chgCode1=codeOptions.val();
 			 	if(chgCode==chgCode1)
 	 			 	{
 					alert("Selected Charging Code=["+chgCode+"-"+ $("#"+inputID+" option:selected").text()+"] is All-ready in use!");
 				 	//document.getElementById(inputID).options[0].selected=true;
 				 	$("#"+inputID).val('0');
 				 	break;
 		     	}
 		   }				  	    
   	   }
  	  	
  	}
	else if(id_arr[0]=="rbtpRenew")
	{
 		// ************* For Rbt purchase Renewal ***************** 

		//alert(" current rbtp_DIV_Array ="+rbtp_DIV_Array);
	    for(var i=0;i<DIV_MAX_INDEX;i++)
	  	    {
			divID1="rbtpRenew_"+i;
			if(i==id_arr[1])
	 			{
				//alert("Self Div Index ["+divID1+"] ");
				continue;
			}  

			inputID1='rateplan_'+divID1+'_chargingCode';
			//codeOptions=document.getElementById(inputID1);
			 codeOptions=$("#"+inputID1);
			if(codeOptions!=null)
	 			{
				//alert(" validating ID ="+inputID1);
				//chgCode1=codeOptions.options[document.getElementById(inputID1).selectedIndex].value;
				chgCode1=codeOptions.val();
			 	if(chgCode==chgCode1)
	 			 	{
					alert("Selected Charging Code=["+chgCode+"-"+ $("#"+inputID+" option:selected").text()+"] is All-ready in use!");
				 	//document.getElementById(inputID).options[0].selected=true;
				 	$("#"+inputID).val('0');
				 	break;
		     	}
		   }				  	    
	   }
	  	
	}
 	else if(id_arr[0]=="recordp")
  	{$("#rateplan_subPostPaidTemplateId").css("border-color:","lightyellow");
 		//alert(" current recordp_DIV_Array ="+recordp_DIV_Array);
  	    for(var i=0;i<DIV_MAX_INDEX;i++){
 			divID1="recordp_"+i;
 			if(i==id_arr[1]){
 				//alert("Self Div Index ["+divID1+"] ");
 				continue;
 			}  

 			inputID1='rateplan_'+divID1+'_chargingCode';
 			
 			codeOptions=$("#"+inputID1);
 			
 			
 			//codeOptions=document.getElementById(inputID1);
 			if(codeOptions!=null){
 				//alert(" validating ID ="+inputID1);
 				//chgCode1=codeOptions.options[document.getElementById(inputID1).selectedIndex].value;
 				chgCode1=codeOptions.val();
 				if(chgCode==chgCode1){
 					alert("Selected Charging Code=["+chgCode+"-"+ $("#"+inputID+" option:selected").text()+"] is All-ready in use!");
 				 	//document.getElementById(inputID).options[0].selected=true;
 					$("#"+inputID).val('0');
 				 	break;
 		     	}
 		   }				  	    
   	   }
  	  	
  	}
 	else if(id_arr[0]=="recordRenew")
	{
 		    for(var i=0;i<DIV_MAX_INDEX;i++)
	  	    {
			divID1="recordRenew_"+i;
			if(i==id_arr[1])
	 			{
				
				continue;
			}  

			inputID1='rateplan_'+divID1+'_chargingCode';
			//codeOptions=document.getElementById(inputID1);
			 codeOptions=$("#"+inputID1);
			if(codeOptions!=null)
	 			{
				
				chgCode1=codeOptions.val();
			 	if(chgCode==chgCode1)
	 			{
			 			alert("Selected Charging Code=["+chgCode+"-"+ $("#"+inputID+" option:selected").text()+"] is All-ready in use!");
				 		$("#"+inputID).val('0');
				 		break;
		     	}
		   }				  	    
	   }
	  	
	}
  	else if(id_arr[0]=="giftp"){

 		//alert(" current giftp_DIV_Array ="+giftp_DIV_Array);
  	    for(var i=0;i<DIV_MAX_INDEX;i++){
  	    	
 			divID1="giftp_"+i;
 			if(i==id_arr[1]){
 			continue;
 			}  

 			inputID1='rateplan_'+divID1+'_chargingCode';
 			//codeOptions=document.getElementById(inputID1);
 			codeOptions=$("#"+inputID1);
 			if(codeOptions!=null){
 				 //chgCode1=codeOptions.options[document.getElementById(inputID1).selectedIndex].value;
 				 chgCode1=codeOptions.val();
 			 	if(chgCode==chgCode1){
 					alert("Selected Charging Code=["+chgCode+"-"+ $("#"+inputID+" option:selected").text()+"] is All-ready in use!");
 				 	//document.getElementById(inputID).options[0].selected=true;
 				 	 $("#"+inputID).val('0');
 				 	break;
 		     	}
 		   }				  	    
   	   }
  	}
  	else if(id_arr[0]=="free"){

  		//alert("free");
 		//alert(" current giftp_DIV_Array ="+free_DIV_Array);
  	    for(var i=0;i<DIV_MAX_INDEX;i++){
  	    	
 			divID1="free_"+i;
 			if(i==id_arr[1]){
 			continue;
 			}  

 			inputID1='rateplan_'+divID1+'_chargingCode';
 			//alert(inputId1);
 			//codeOptions=document.getElementById(inputID1);
 			codeOptions=$("#"+inputID1);
 			if(codeOptions!=null){
 				 //chgCode1=codeOptions.options[document.getElementById(inputID1).selectedIndex].value;
 				 chgCode1=codeOptions.val();
 			 	if(chgCode==chgCode1){
 					alert("Selected Charging Code=["+chgCode+"-"+ $("#"+inputID+" option:selected").text()+"] is All-ready in use!");
 				 	//document.getElementById(inputID).options[0].selected=true;
 				 	 $("#"+inputID).val('0');
 				 	break;
 		     	}
 		   }				  	    
   	   }
  	} 	else{
  	  	alert(" Error in Operation!!");
  	}
  }//######## END of validateOption() method
 
 
 
 //############ For Modify ##########//
 function addSubFallbackM(divID){
		
		
		
	 	// alert("STATU= sub_DIV_Array ="+sub_DIV_Array+", FB_CHG_CODES="+FB_CHG_CODES);
	 	 if(!validateFieldMe(divID)){
	 	 	 return;
	 	 }
		 if(sub_DIV_Array.length<=0){
			 alert(rangeExceedAlert);
			 return;
		 }
		 
		   
		    
		  //  alert("sub_DIV_Array[0] "+sub_DIV_Array[0]);
		   /* var subSelectID="rateplan_"+sub_DIV_Array[0]+"_chargingCode";
			var subValidityID="rateplan_"+sub_DIV_Array[0]+"_validity";
			var inputIndex=(sub_DIV_Array[0].split("_")[1]);
			var intVal=parseInt(inputIndex);*/
		    
		    intVal=SubListSize;
		    var subSelectID="rateplan_"+"sub_"+intVal+"_chargingCode";
			var subValidityID="rateplan_"+"sub_"+intVal+"_validity";
			//var inputIndex=(sub_DIV_Array[0].split("_")[1]);
			
		   
			
			
			
			
			
			//alert(subSelectID);
			//alert(subValidityID);
			//alert("Index["+inputIndex+"]");
			
			
			
			var subSelectName='packsub.subscriptionDetails['+intVal+'].chargingCode';
			var subValidityName='packsub.subscriptionDetails['+intVal+'].validity';
			var newDivID="sub_"+intVal;
			
			//alert("subSelectName "+subSelectName);
			//alert("subValidityName "+subValidityName);
			//alert("newDivID "+newDivID);
			//alert(" SUB_CODE_NAME ="+subSelectName+", SUB_VALIDITY_NAME ="+subValidityName+", New DIV ID="+newDivID);
			
			var newDIV=$('<div/>',{"id":newDivID});
			var newTable=$('<table/>').attr({border:"1",width:"100%",cellspacing:"0"});
			
			var t_row=$('<tr/>');

			var subCodeStr=chargingCodeLabel;
					
			//######## Creating Select Option
			subCodeStr+='<select name="'+subSelectName+'" id="'+subSelectID+'" onchange="validateOption(';
			subCodeStr+="'"+newDivID+"');";
			subCodeStr+='">';
			subCodeStr+='<option value="0">select</option>';
			var chg_array=null;
			for(var i=0;i<FB_CHG_CODES.length;i++){
				chg_array=FB_CHG_CODES[i].split("#");
				subCodeStr+='<option value="'+chg_array[0]+'">'+chg_array[1]+'</option>';
			}
			subCodeStr+='</select>';
			//alert("CHARGE_CODES  ==== "+subCodeStr);
			$('<td/>').html(subCodeStr).appendTo(t_row);
			
			//######## Creating Validity text Field
			var validityStr=validityLabel+' : &nbsp;&nbsp; <input type="text" name="'+subValidityName+'"  id="'+subValidityID+'" size="10" maxlength="5" value="0" onkeypress="return numberOnly(event);" >-'+daysLabel;
			//alert(validityStr);
			$('<td/>').html(validityStr).appendTo(t_row);

			//######## Creating addButton Field
			var addBtnStr='<input type="button" value="'+addButtonLabel+'" class="subadd" onclick="addSubFallbackM(';
			addBtnStr+="'"+newDivID+"')";//sub_DIV_Array[0] old
			addBtnStr+='"/>';
			//alert(addBtnStr);
			$('<td/>').html(addBtnStr).appendTo(t_row);
			
			//######## Creating deleteButton Field
			var deleteBtnStr='<input type="button" value="'+deleteButtonLabel+'" data-divid="'+newDivID+'" onclick="deleteMe(';
			deleteBtnStr+="'"+newDivID.trim()+"')";
			deleteBtnStr+='"/>';
			
			//alert(deleteBtnStr);
			$('<td/>').html(deleteBtnStr).appendTo(t_row);

			//##### appending row to newTable
			newTable.append(t_row);
			
			//##### appending table to newDiv
			newDIV.append(newTable);
			
			//##### appending newDiv to subDiv
			$("#subDiv").append(newDIV);

			//#### Managing sub_DIV_Array array
			//alert("old Array="+sub_DIV_Array);
			//### Removing 1st index from sub_DIV_Array
			sub_DIV_Array.splice(0,1);
			SubListSize++;
			subList=subList+1;
			
			//sub_DIV_Array.sort();
			//alert("New Array="+sub_DIV_Array);
	}
	 // *************** FOR SUBSCRIPTION RENEW ************************** 

 
 //############# addSubRenew ###############//
 function addSubRenewFallbackM(divID)
 {
	 //alert("inside Subscription Renew");
	 
	 
	 
	 
 	 if(!validateFieldMe(divID)){
 	 	 return;
 	 }
	 if(subRenew_DIV_Array.length<=0){
		 alert(rangeExceedAlert);
		 
		 return;
	 }
	    
	    /*var subRenewSelectID="rateplan_"+subRenew_DIV_Array[0]+"_chargingCode";
		var subRenewValidityID="rateplan_"+subRenew_DIV_Array[0]+"_validity";
		var subRenewSTID="rateplan_"+subRenew_DIV_Array[0]+"_STID";
		var subRenewFTID="rateplan_"+subRenew_DIV_Array[0]+"_FTID";
		
		var inputIndex=(subRenew_DIV_Array[0].split("_")[1]);
		
		var intVal=parseInt(inputIndex);
		*/
	 
		intVal=SubRenewListSize;
		var subRenewSelectID="rateplan_"+"subRenew_"+intVal+"_chargingCode";
		var subRenewValidityID="rateplan_"+"subRenew_"+intVal+"_validity";
		var subRenewSTID="rateplan_"+"subRenew_"+intVal+"_STID";
		var subRenewFTID="rateplan_"+"subRenew_"+intVal+"_FTID";
	
		
		//alert(subRenewSelectID);
		//alert(subRenewValidityID);
		//alert(inputIndex);
		//alert(subRenewSTID);
		//alert(subRenewFTID);
		
		
		//alert(" SUB_CODE_ID ="+subRenewSelectID+", SUB_RenewVALIDITY_ID ="+subRenewValidityID+", INPUT INDEX ="+inputIndex);

		var subRenewSelectName='packsub.subscriptionRenewDetails['+intVal+'].chargingCode';
		var subRenewValidityName='packsub.subscriptionRenewDetails['+intVal+'].validity';
		var stIDName='packsub.subscriptionRenewDetails['+intVal+'].renewSuccessTemplateID';
		var ftIDName='packsub.subscriptionRenewDetails['+intVal+'].renewFailedTemplateID';
		
		var newDivID="subRenew_"+intVal;
		
		//alert("subRenewSelectName "+subRenewSelectName);
		//alert("subRenewValidityName "+subRenewValidityName);
		//alert("stIDName "+stIDName);
		//alert("ftIDName "+ftIDName);
		
	//	alert("newDivID "+newDivID);
		
		
		//alert(" SUB_CODE_NAME ="+subRenewSelectName+", SUB_RenewVALIDITY_NAME ="+subRenewValidityName+", New DIV ID="+newDivID);
		var newDIV=$('<div/>',{"id":newDivID});
		var newTable=$('<table/>').attr({border:"1",width:"100%",cellspacing:"0"});
		var t_row=$('<tr/>');

		var subRenewCodeStr=chargingCodeLabel;
				
		//######## Creating Select Option
		subRenewCodeStr+='<select name="'+subRenewSelectName+'" id="'+subRenewSelectID+'" onchange="validateOption(';
		subRenewCodeStr+="'"+newDivID+"');";
		subRenewCodeStr+='" style="width:40px;">';
		subRenewCodeStr+='<option value="0">select</option>';
		var chg_arr=null;
		for(var i=0;i<FB_CHG_CODES.length;i++){
			chg_array=FB_CHG_CODES[i].split("#");
			subRenewCodeStr+='<option value="'+chg_array[0]+'">'+chg_array[1]+'</option>';
		}
		subRenewCodeStr+='</select>';
		//alert("CHARGE_CODES  ==== "+subRenewCodeStr);
		$('<td/>').html(subRenewCodeStr).appendTo(t_row);
		
		//######## Creating Validity text Field
		var validityStr=validityLabel+' : &nbsp;&nbsp;<input type="text" name="'+subRenewValidityName+'"  id="'+subRenewValidityID+'" size="10" maxlength="5" value="0" onkeypress="return numberOnly(event);" >-'+daysLabel;
		//alert(validityStr);
		$('<td/>').html(validityStr).appendTo(t_row);

		//######## creating select option TEMPLATE_IDS
		//
		
		//alert("TemplateId Length["+TEMPLATE_IDS.length+"]");
		
		var stidStr='Select Template ID: </br> <select	name="'+stIDName+'" id="'+subRenewSTID+'"  style="width:90px" >';
		stidStr+='<option value="0">SUCCESS TEMPLATE-ID</option>';				
		for(var i=0;i<TEMPLATE_IDS.length;i++){
			stidStr+='<option value="'+TEMPLATE_IDS[i]+'">'+TEMPLATE_IDS[i]+'</option>';			
		}
		stidStr+="</select>";
		var ftidStr='<select	name="'+ftIDName+'" id="'+subRenewFTID+'"  style="width:90px" >';
		ftidStr+='<option value="0">FAILURE TEMPLATE-ID</option>';				
		for(var i=0;i<TEMPLATE_IDS.length;i++){
			ftidStr+='<option value="'+TEMPLATE_IDS[i]+'">'+TEMPLATE_IDS[i]+'</option>';			
		}

		
		ftidStr+="</select>";
		//alert(stidStr);
		
		$('<td/>').html(stidStr+ftidStr).appendTo(t_row);
		//######## Creating addButton Field
		var addBtnStr='<input type="button" value="'+addButtonLabel+'" class="subadd" onclick="addSubRenewFallbackM(';
		addBtnStr+="'"+"subRenew_"+intVal+"')";
		addBtnStr+='"/>';
		//alert(addBtnStr);
		$('<td/>').html(addBtnStr).appendTo(t_row);
		
		//######## Creating deleteButton Field
		var deleteBtnStr='<input type="button" value="'+deleteButtonLabel+'" data-divid="'+newDivID+'" onclick="deleteMe(';
		deleteBtnStr+="'"+newDivID.trim()+"')";
		deleteBtnStr+='"/>';
		
		//alert(deleteBtnStr);
		$('<td/>').html(deleteBtnStr).appendTo(t_row);

		//##### appending row to newTable
		newTable.append(t_row);
		
		//##### appending table to newDiv
		newDIV.append(newTable);
		
		//##### appending newDiv to subDiv
		$("#subRenewDiv").append(newDIV);

		//#### Managing sub_DIV_Array array
		//alert("old Array="+subRenew_DIV_Array);
		//### Removing 1st index from sub_DIV_Array
		subRenew_DIV_Array.splice(0,1);
		SubRenewListSize++;
		
		subReList=subReList+1;
		//subRenew_DIV_Array.sort();
		//alert("New Array="+subRenew_DIV_Array);
}
 //#################### End here ###############//
 
function addRbtPurchaseFallbackM(divID){
	
	 
	 if(!validateFieldMe(divID)){
	 	 return;
	 }
	 if(rbtp_DIV_Array.length<=0){
		 alert(rangeExceedAlert);
		 return;
	 }
	 
	   	var intVal=RbtPurchaseListSize;
	    /*var rbtPurSelectID="rateplan_"+rbtp_DIV_Array[0]+"_chargingCode";
		var rbtPurValidityID="rateplan_"+rbtp_DIV_Array[0]+"_validity";
		var rbtPurNoOfRbtID="rateplan_"+rbtp_DIV_Array[0]+"_noOfRbt";
		var rbtPurNoOfFreeRbtID="rateplan_"+rbtp_DIV_Array[0]+"_noOfFreeRbt";
			*/
	  //var rbtPurSelectID="rateplan_"+"rbtp_"+intVal+"_chargingCode";
	  //var rbtPurValidityID="rateplan_"+"rbtp_"+intVal+"_validity";
		var rbtPurNoOfRbtID="rateplan_"+"rbtp_"+intVal+"_noOfRbt";
		var rbtPurNoOfFreeRbtID="rateplan_"+"rbtp_"+intVal+"_noOfFreeRbt";
		
	 
		var inputIndex=(rbtp_DIV_Array[0].split("_")[1]);
		
		//alert(" SUB_CODE_ID ="+subSelectID+", SUB_VALIDITY_ID ="+subValidityID+", INPUT INDEX ="+inputIndex);

	//	var rbtPurSelectName='packsub.rbtPurchaseDetails['+intVal+'].chargingCode';
	//	var rbtPurValidityName='packsub.rbtPurchaseDetails['+intVal+'].validity';
		var rbtPurNoOfRbtName='packsub.rbtPurchaseDetails['+intVal+'].noOfRbt';
		var rbtPurNoOfFreeRbtName='packsub.rbtPurchaseDetails['+intVal+'].noOfFreeRbt';
		
		
		var newDivID="rbtp_"+intVal;
		$("#rateplan_subPostPaidTemplateId").css("border-color:","lightyellow");
		//alert(" SUB_CODE_NAME ="+subSelectName+", SUB_VALIDITY_NAME ="+subValidityName+", New DIV ID="+newDivID);
		var newDIV=$('<div/>',{"id":newDivID});
		var newTable=$('<table/>').attr({border:"1",width:"100%",cellspacing:"0"});
		var t_row=$('<tr/>');

	//	var rbtPurCodeStr=chargingCodeLabel;
				
		//######## Creating Select Option
	//	rbtPurCodeStr+='<select name="'+rbtPurSelectName+'" id="'+rbtPurSelectID+'" onchange="validateOption(';
	//	rbtPurCodeStr+="'"+newDivID+"');";
	//	rbtPurCodeStr+='">';
		
	//	rbtPurCodeStr+='<option value="0">select</option>';
	//	var chg_array=null;
	//	for(var i=0;i<FB_CHG_CODES.length;i++){
	//		chg_array=FB_CHG_CODES[i].split("#");
	//		rbtPurCodeStr+='<option value="'+chg_array[0]+'">'+chg_array[1]+'</option>';
	//	}
	//	rbtPurCodeStr+='</select>';
		//alert("CHARGE_CODES  ==== "+rbtPurCodeStr);
	//	$('<td/>').html(rbtPurCodeStr).appendTo(t_row);
		
		//######## Creating Validity text Field
	//	var validityStr=validityLabel+' : &nbsp;&nbsp;<input type="text" name="'+rbtPurValidityName+'"  id="'+rbtPurValidityID+'" size="10" maxlength="5" value="0"  onkeypress="return numberOnly(event);" />-'+daysLabel;
		//alert(validityStr);
	//	$('<td/>').html(validityStr).appendTo(t_row);
        
		//######## Creating NOR text Field
		var noOfRbt=noOfRbtLabel+' : &nbsp;&nbsp;<input type="text" name="'+rbtPurNoOfRbtName+'"  id="'+rbtPurNoOfRbtID+'" size="10" maxlength="5" value="0"  onkeypress="return numberOnly(event);" />';
		
		$('<td/>').html(noOfRbt).appendTo(t_row);
        
        var noOfFreeRbt=noOfFreeRbtLabel+' : &nbsp;&nbsp;<input type="text" name="'+rbtPurNoOfFreeRbtName+'"  id="'+rbtPurNoOfFreeRbtID+'" size="10" maxlength="5" value="0"  onkeypress="return numberOnly(event);" />';
		
		$('<td/>').html(noOfFreeRbt).appendTo(t_row);
        
		
		
		//######## Creating addButton Field
		var addBtnStr='<input type="button" value="'+addButtonLabel+'" class="subadd" onclick="addRbtPurchaseFallbackM(';
		addBtnStr+="'"+"rbtp_"+intVal+"')";
		addBtnStr+='"/>';
		//alert(addBtnStr);
		$('<td/>').html(addBtnStr).appendTo(t_row);
		
		//######## Creating deleteButton Field
		var deleteBtnStr='<input type="button" value="'+deleteButtonLabel+'" data-divid="'+newDivID+'" onclick="deleteMe(';
		deleteBtnStr+="'"+newDivID.trim()+"')";
		deleteBtnStr+='"/>';
		//alert(deleteBtnStr);
		$('<td/>').html(deleteBtnStr).appendTo(t_row);

		//##### appending row to newTable
		newTable.append(t_row);
		
		//##### appending table to newDiv
		newDIV.append(newTable);
		
		//##### appending newDiv to subDiv
		$("#rbtPurchaseDiv").append(newDIV);

		//#### Managing rbtp_DIV_Array array
		//alert("old Array="+rbtp_DIV_Array);
		//### Removing 1st index from rbtp_DIV_Array
		 rbtp_DIV_Array.splice(0,1);
		 RbtPurchaseListSize++;
		 
		 rbtList=rbtList+1;
		 //rbtp_DIV_Array.sort();
		// alert("New Array="+rbtp_DIV_Array);
}

//################   Recording           ##################//
function addRecordingFallbackM(divID){
	
	 
	 if(!validateFieldMe(divID)){
	 	 return;
	 }
	 if(recordp_DIV_Array.length<=0){
		 alert(rangeExceedAlert);
		 return;
	 }
	 
	    //var rbtPurSelectID="rateplan_"+rbtp_DIV_Array[0]+"_chargingCode";
	 
	   /* var recordSelectID="rateplan_"+recordp_DIV_Array[0]+"_chargingCode";
		var recordValidityID="rateplan_"+recordp_DIV_Array[0]+"_validity";
		var recordingNoOfRbtID="rateplan_"+recordp_DIV_Array[0]+"_noOfRbt";
		var recordingNoOfFreeRbtID="rateplan_"+recordp_DIV_Array[0]+"_noOfFreeRbt";
		
		*/
	 var intVal=RbtRecordingListSize;
		
	   // var recordSelectID="rateplan_"+"recordp_"+intVal+"_chargingCode";
		//var recordValidityID="rateplan_"+"recordp_"+intVal+"_validity";
		var recordingNoOfRbtID="rateplan_"+"recordp_"+intVal+"_noOfRbt";
		var recordingNoOfFreeRbtID="rateplan_"+"recordp_"+intVal+"_noOfFreeRbt";
	
		var inputIndex=(recordp_DIV_Array[0].split("_")[1]);
		
		//alert(" SUB_CODE_ID ="+subSelectID+", SUB_VALIDITY_ID ="+subValidityID+", INPUT INDEX ="+inputIndex);

		//var recordSelectName='packsub.rbtRecordingDetails['+intVal+'].chargingCode';
		//var recordValidityName='packsub.rbtRecordingDetails['+intVal+'].validity';
		var recordNoOfRbtName='packsub.rbtRecordingDetails['+intVal+'].noOfRbt';
		var recordNoOfFreeRbtName='packsub.rbtRecordingDetails['+intVal+'].noOfFreeRbt';
		
		
		var newDivID="recordp_"+intVal;
		
		//alert(" SUB_CODE_NAME ="+subSelectName+", SUB_VALIDITY_NAME ="+subValidityName+", New DIV ID="+newDivID);
		var newDIV=$('<div/>',{"id":newDivID});
		var newTable=$('<table/>').attr({border:"1",width:"100%",cellspacing:"0"});
		var t_row=$('<tr/>');

		var recordCodeStr=chargingCodeLabel;
				
		//######## Creating Select Option
		//recordCodeStr+='<select name="'+recordSelectName+'" id="'+recordSelectID+'" onchange="validateOption(';
		//recordCodeStr+="'"+newDivID+"');";
		//recordCodeStr+='">';
		
		//recordCodeStr+='<option value="0">select</option>';
	//	var chg_array=null;
		//for(var i=0;i<FB_CHG_CODES.length;i++){
		//	chg_array=FB_CHG_CODES[i].split("#");
		//	recordCodeStr+='<option value="'+chg_array[0]+'">'+chg_array[1]+'</option>';
	//	}
		//recordCodeStr+='</select>';
		//alert("CHARGE_CODES  ==== "+rbtPurCodeStr);
	//	$('<td/>').html(recordCodeStr).appendTo(t_row);
		
		//######## Creating Validity text Field
	//	var validityStr=validityLabel+' : &nbsp;&nbsp;<input type="text" name="'+recordValidityName+'"  id="'+recordValidityID+'" size="10" maxlength="5" value="0"  onkeypress="return numberOnly(event);" >-'+daysLabel;
		//alert(validityStr);
	//	$('<td/>').html(validityStr).appendTo(t_row);

		//##### Creating NOR ##################
		var noOfRbtStr=noOfRbtLabel+' : &nbsp;&nbsp;<input type="text" name="'+recordNoOfRbtName+'"  id="'+recordingNoOfRbtID+'" size="10" maxlength="5" value="0"  onkeypress="return numberOnly(event);" >';
		//alert(validityStr);
		$('<td/>').html(noOfRbtStr).appendTo(t_row);

		var noOfFreeRbtStr=noOfFreeRbtLabel+' : &nbsp;&nbsp;<input type="text" name="'+recordNoOfFreeRbtName+'"  id="'+recordingNoOfFreeRbtID+'" size="10" maxlength="5" value="0"  onkeypress="return numberOnly(event);" >';
		//alert(validityStr);
		$('<td/>').html(noOfFreeRbtStr).appendTo(t_row);

		
		
		//######## Creating addButton Field
		var addBtnStr='<input type="button" value="'+addButtonLabel+'" class="subadd" onclick="addRecordingFallbackM(';
		addBtnStr+="'"+"recordp_"+intVal+"')";
		addBtnStr+='"/>';
		//alert(addBtnStr);
		$('<td/>').html(addBtnStr).appendTo(t_row);
		
		//######## Creating deleteButton Field
		var deleteBtnStr='<input type="button" value="'+deleteButtonLabel+'" data-divid="'+newDivID+'" onclick="deleteMe(';
		deleteBtnStr+="'"+newDivID.trim()+"')";
		deleteBtnStr+='"/>';
		//alert(deleteBtnStr);
		$('<td/>').html(deleteBtnStr).appendTo(t_row);

		//##### appending row to newTable
		newTable.append(t_row);
		
		//##### appending table to newDiv
		newDIV.append(newTable);
		
		//##### appending newDiv to subDiv
		$("#recordDiv").append(newDIV);

		//#### Managing rbtp_DIV_Array array
		//alert("old Array="+recordp_DIV_Array);
		//### Removing 1st index from rbtp_DIV_Array
		 recordp_DIV_Array.splice(0,1);
		 RbtRecordingListSize++;
		 
		 recordingList=recordingList+1;
		// recordp_DIV_Array.sort();
		 //alert("New Array="+recordp_DIV_Array);
}

//##############################   #############//

function addFreeRbtFallbackM(divID){
	
	
     //alert("free=["+divID+"]");
	 if(!validateFieldMe(divID)){
		  return;
	 }
	
	  
	 if(free_DIV_Array.length<=0){
		 alert(rangeExceedAlert);
		 return;
	 }
	 //alert("size "+free_DIV_Array.length);
	 
	 free_0
	 
	 	/*var freeSelectID="rateplan_"+free_DIV_Array[0]+"_chargingCode";
		var freeValidityID="rateplan_"+free_DIV_Array[0]+"_validity";
		var freeNoOfRbtID="rateplan_"+free_DIV_Array[0]+"_noOfRbt";
		var freeNoOfFreeRbtID="rateplan_"+free_DIV_Array[0]+"_noOfFreeRbt";
		var intVal=RbtFreeListSize;
		*/
		var intVal=RbtFreeListSize;
		var freeSelectID="rateplan_"+"free_"+intVal+"_chargingCode";
		var freeValidityID="rateplan_"+"free_"+intVal+"_validity";
		//var freeNoOfRbtID="rateplan_"+"free_"+intVal+"_noOfRbt";
		//var freeNoOfFreeRbtID="rateplan_"+"free_"+intVal+"_noOfFreeRbt";
		
		
		
		
		
		
		
		var inputIndex=(free_DIV_Array[0].split("_")[1]);
		
		var freeSelectName='packsub.freeRbtDetails['+intVal+'].chargingCode';
		
		var freeValidityName='packsub.freeRbtDetails['+intVal+'].validity';
		//var freeNoOfRbtName='packsub.freeRbtDetails['+intVal+'].noOfRbt';
		//var freeNoOfFreeRbtName='packsub.freeRbtDetails['+intVal+'].NoOfFreeRbt';
		
		
		
		
		
		var newDivID="free_"+intVal;
		
		
		
		//alert("new divId "+newDivID);
		
	    var newDIV=$('<div/>',{"id":newDivID});
		var newTable=$('<table/>').attr({border:"1",width:"100%",cellspacing:"0"});
		var t_row=$('<tr/>');

		var freeCodeStr=chargingCodeLabel;
				
		//######## Creating Select Option
		freeCodeStr+='<select name="'+freeSelectName+'" id="'+freeSelectID+'" onchange="validateOption(';
		freeCodeStr+="'"+newDivID+"');";
		freeCodeStr+='">';
		
		freeCodeStr+='<option value="0">select</option>';
		var chg_array=null;
		for(var i=0;i<FB_CHG_CODES.length;i++){
			chg_array=FB_CHG_CODES[i].split("#");
			freeCodeStr+='<option value="'+chg_array[0]+'">'+chg_array[1]+'</option>';
		}
		freeCodeStr+='</select>';
		$('<td/>').html(freeCodeStr).appendTo(t_row);
		
		//######## Creating Validity text Field
		var validityStr=validityLabel+' : &nbsp;&nbsp; <input type="text" name="'+freeValidityName+'"  id="'+freeValidityID+'" size="10" maxlength="5" value="0" onkeypress="return numberOnly(event);" >-'+daysLabel;
		$('<td/>').html(validityStr).appendTo(t_row);

		
		// ##### NOR ################### //
		//var noOfRbtStr=noOfRbtLabel+' : &nbsp;&nbsp; <input type="text" name="'+freeNoOfRbtName+'"  id="'+freeNoOfRbtID+'" size="10" maxlength="5" value="0" onkeypress="return numberOnly(event);" >';
		//$('<td/>').html(noOfRbtStr).appendTo(t_row);
       
		// ############################# //
		
		// ##### NOFR ################### //
		//var noOfFreeRbtStr=noOfFreeRbtLabel+' : &nbsp;&nbsp; <input type="text" name="'+freeNoOfFreeRbtName+'"  id="'+freeNoOfFreeRbtID+'" size="10" maxlength="5" value="0" onkeypress="return numberOnly(event);" >';
		//$('<td/>').html(noOfFreeRbtStr).appendTo(t_row);
       
		// ############################# //
		
		
		
		
		
		//######## Creating addButton Field
		var addBtnStr='<input type="button" value="'+addButtonLabel+'" class="subadd" onclick="addFreeRbtFallbackM(';
		addBtnStr+="'"+"free_"+intVal+"')";
		addBtnStr+='"/>';
		//alert(addBtnStr);
		$('<td/>').html(addBtnStr).appendTo(t_row);
		
		//######## Creating deleteButton Field
		var deleteBtnStr='<input type="button" value="'+deleteButtonLabel+'" data-divid="'+newDivID+'" onclick="deleteMe(';
		deleteBtnStr+="'"+newDivID.trim()+"')";
		deleteBtnStr+='"/>';
		$('<td/>').html(deleteBtnStr).appendTo(t_row);

		//##### appending row to newTable
		newTable.append(t_row);
		
		//##### appending table to newDiv
		newDIV.append(newTable);
		
		//##### appending newDiv to subDiv
		$("#freeDiv").append(newDIV);

		//#### Managing rbtp_DIV_Array array
		//alert("old Array="+giftp_DIV_Array);
		//### Removing 1st index from rbtp_DIV_Array
		 free_DIV_Array.splice(0,1);
		 RbtFreeListSize++;
		 
		 freeList=freeList+1;
		 
		 //giftp_DIV_Array.sort();
		 //alert("New Array="+giftp_DIV_Array);
}



function addGiftFallbackM(divID){
	
	
	 if(!validateFieldMe(divID)){
	 	 return;
	 }
	 if(giftp_DIV_Array.length<=0){
		 alert(rangeExceedAlert);
		 return;
	 }
	 
	 
	 
	 
		
	    /*var giftSelectID="rateplan_"+giftp_DIV_Array[0]+"_chargingCode";
		var giftValidityID="rateplan_"+giftp_DIV_Array[0]+"_validity";
		var giftpNoOfRbtID="rateplan_"+giftp_DIV_Array[0]+"_noOfRbt";
		var giftpNoOfFreeRbtID="rateplan_"+giftp_DIV_Array[0]+"_noOfFreeRbt";
		var intVal=RbtGiftListSize;
		var inputIndex=(giftp_DIV_Array[0].split("_")[1]);
		*/
	  
	    var intVal=RbtGiftListSize;
		//var giftSelectID="rateplan_"+"giftp_"+intVal+"_chargingCode";
		//var giftValidityID="rateplan_"+"giftp_"+intVal+"_validity";
		var giftpNoOfRbtID="rateplan_"+"giftp_"+intVal+"_noOfRbt";
		var giftpNoOfFreeRbtID="rateplan_"+"giftp_"+intVal+"_noOfFreeRbt";
		var inputIndex=(giftp_DIV_Array[0].split("_")[1]);
		
		
		//var giftSelectName='packsub.rbtGiftDetails['+intVal+'].chargingCode';
		//var giftValidityName='packsub.rbtGiftDetails['+intVal+'].validity';
		var giftpNoOfRbtName='packsub.rbtGiftDetails['+intVal+'].noOfRbt';
		var giftpNoOfFreeRbtName='packsub.rbtGiftDetails['+intVal+'].noOfFreeRbt';
		
		
		
		var newDivID="giftp_"+intVal;
	    var newDIV=$('<div/>',{"id":newDivID});
		var newTable=$('<table/>').attr({border:"1",width:"100%",cellspacing:"0"});
		var t_row=$('<tr/>');
        		
		var giftCodeStr=chargingCodeLabel;
				
		//######## Creating Select Option
		//giftCodeStr+='<select name="'+giftSelectName+'" id="'+giftSelectID+'" onchange="validateOption(';
		//giftCodeStr+="'"+newDivID+"');";
		//giftCodeStr+='">';
		
		//giftCodeStr+='<option value="0">select</option>';
		//var chg_array=null;
		//for(var i=0;i<FB_CHG_CODES.length;i++){
		//	chg_array=FB_CHG_CODES[i].split("#");
		//	giftCodeStr+='<option value="'+chg_array[0]+'">'+chg_array[1]+'</option>';
		//}
		//giftCodeStr+='</select>';
		//$('<td/>').html(giftCodeStr).appendTo(t_row);
		
		//######## Creating Validity text Field
		//var validityStr=validityLabel+' : &nbsp;&nbsp; <input type="text" name="'+giftValidityName+'"  id="'+giftValidityID+'" size="10" maxlength="5" value="0" onkeypress="return numberOnly(event);" >-'+daysLabel;
		//$('<td/>').html(validityStr).appendTo(t_row);

		//######## Creating Validity text Field
		var noOfRbtStr=noOfRbtLabel+' : &nbsp;&nbsp; <input type="text" name="'+giftpNoOfRbtName+'"  id="'+giftpNoOfRbtID+'" size="10" maxlength="5" value="0" onkeypress="return numberOnly(event);" >';
		$('<td/>').html(noOfRbtStr).appendTo(t_row);
		
		var noOfFreeRbtStr=noOfFreeRbtLabel+' : &nbsp;&nbsp; <input type="text" name="'+giftpNoOfFreeRbtName+'"  id="'+giftpNoOfFreeRbtID+'" size="10" maxlength="5" value="0" onkeypress="return numberOnly(event);" >';
		$('<td/>').html(noOfFreeRbtStr).appendTo(t_row);
		

		//######## Creating addButton Field
		var addBtnStr='<input type="button" value="'+addButtonLabel+'" class="subadd" onclick="addGiftFallbackM(';
		addBtnStr+="'"+"giftp_"+intVal+"')";
		addBtnStr+='"/>';
		//alert(addBtnStr);
		$('<td/>').html(addBtnStr).appendTo(t_row);
		
		//######## Creating deleteButton Field
		var deleteBtnStr='<input type="button" value="'+deleteButtonLabel+'" data-divid="'+newDivID+'" onclick="deleteMe(';
		deleteBtnStr+="'"+newDivID.trim()+"')";
		deleteBtnStr+='"/>';
		$('<td/>').html(deleteBtnStr).appendTo(t_row);

		//##### appending row to newTable
		newTable.append(t_row);
		
		//##### appending table to newDiv
		newDIV.append(newTable);
		
		//##### appending newDiv to subDiv
		$("#giftDiv").append(newDIV);

		//#### Managing rbtp_DIV_Array array
		//alert("old Array="+giftp_DIV_Array);
		//### Removing 1st index from rbtp_DIV_Array
		giftp_DIV_Array.splice(0,1);
		RbtGiftListSize++;
		 //giftp_DIV_Array.sort();
		giftList=giftList+1;
		
		 //alert("New Array="+giftp_DIV_Array);
}

//********************** end of GIFT ************************** 

 
 