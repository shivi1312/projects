/////////////////////// yyyyyyyyyyyyyy
////////// pankaj mishra R&D ///////////////////
////////////manoj
$(document).ready(function(){

	$("#subPromo").fadeOut(200).hide();
	$("#rbtPurchasePromo").fadeOut(200).hide();
	$("#subRenewal").fadeOut(200).hide();
	$("#rbtPurchaseRenew").fadeOut(200).hide();
	$("#recordingRenew").fadeOut(200).hide();
	
	$("#enable_subPromo").click(function(){
		if($(this).prop('checked')){
			$("#subPromo").fadeIn(500).show();
		}else{
			
				$("#subPromo").fadeIn(500).hide();
				$("#rateplan_subPrepaidPromo").attr('checked', false);
				$("#rateplan_subPostpaidPromo").attr('checked', false); 
		}
	});
	
	$("#enable_rbtPurchasePromo").click(function(){
		if($(this).prop('checked')){
			$("#rbtPurchasePromo").fadeIn(500).show();
		}else{
				$("#rbtPurchasePromo").fadeIn(500).hide();
				$("#rateplan_rbtPurchasePrepaidPromo").attr('checked', false);
				$("#rateplan_rbtPurchasePostpaidPromo").attr('checked', false);
		}
	});

	$("#enable_subRenew").click(function(){
		if($(this).prop('checked')){
			$("#subRenewal").fadeIn(500).show();
		}else{
				$("#subRenewal").fadeIn(500).hide();
				$("#rateplan_enableSubAutoRenewPrepaid").attr('checked',false);
				$("#rateplan_enableSubAutoRenewPostpaid").attr('checked',false);
		}
	});

	$("#enable_rbtAutoRenew").click(function(){
		if($(this).prop('checked')){
			$("#rbtPurchaseRenew").fadeIn(500).show();
		}else{
				$("#rbtPurchaseRenew").fadeIn(500).hide();
				$("#rateplan_enableRbtAutoRenewPrepaid").attr('checked',false);
				$("rateplan_enableRbtAutoRenewPostpaid").attr('checked',false);
			}
	});

	$("#enable_recordAutoRenew").click(function(){
		if($(this).prop('checked')){
			$("#recordingRenew").fadeIn(500).show();
		}else{
				$("#recordingRenew").fadeIn(500).hide();
			}
	});
	
	
	$("#maskedName").blur(function(){
		var maskedName=$("#maskedName").val();
		maskedName=maskedName.trim();
		//alert(" value is MASKED_NAME="+maskedName);

		var qrString="rateplan.maskedName="+maskedName;//+"&linkName=webadmin";
		if(maskedName==''){
			$("#packNameStatus_ok").fadeIn(300).hide();
		    $("#packNameStatus_failed").fadeIn(300).show();
		}else{
		 var request=$.ajax({
			 type :"POST",
			 url  :"isPackNameExists.action",
			 data :qrString,
			 success:function(data,textStatus,jqXHR){
				 if(jqXHR.status==200){
				       //alert('success');
				       $("#packNameStatus_ok").fadeIn(300).show();
				       $("#packNameStatus_failed").fadeIn(300).hide();
				   }else if(jqXHR.status==201){
					    //alert('failure '+textStatus);
					    $("#packNameStatus_failed").fadeIn(300).show();
						$("#packNameStatus_ok").fadeIn(300).hide();
						$("#maskedName").val('');
				  }else if(jqXHR.status==500){
					 // alert( "Request failed: " + textStatus );
					  $("#packNameStatus_failed").fadeIn(300).show();
					  $("#packNameStatus_ok").fadeIn(300).hide();
					  $("#maskedName").val('');
					}
			  }
		});
	 }	 
	});
	
	
	
	//added by harjinder
	$("#packName").blur(function(){
		
		var maskedName=$("#packName").val();
		maskedName=maskedName.trim();
		//alert(" value is MASKED_NAME="+maskedName);

		var qrString="rateplan.maskedName="+maskedName;//+"&linkName=webadmin";
		if(maskedName==''){
			$("#packNameStatus_ok").fadeIn(300).hide();
		    $("#packNameStatus_failed").fadeIn(300).show();
		}else{
		 var request=$.ajax({
			 type :"POST",
			 url  :"isPackNameExists.action",
			 data :qrString,
			 success:function(data,textStatus,jqXHR){
				 if(jqXHR.status==200){
				       alert('success');
				       $("#packNameStatus_ok").fadeIn(300).show();
				       $("#packNameStatus_failed").fadeIn(300).hide();
				   }else if(jqXHR.status==201){
					    //alert('failure '+textStatus);
					    $("#packNameStatus_failed").fadeIn(300).show();
						$("#packNameStatus_ok").fadeIn(300).hide();
						$("#maskedName").val('');
				  }else if(jqXHR.status==500){
					 // alert( "Request failed: " + textStatus );
					  $("#packNameStatus_failed").fadeIn(300).show();
					  $("#packNameStatus_ok").fadeIn(300).hide();
					  $("#maskedName").val('');
					}
			  }
		});
	 }	 
	});
	
	
	//end 
	

	$("#addRatePlan").validate({
	  submitHandler: function(form) {
			var textElements=new Array();
			var numbers = /^[-+]?[0-9]+$/;
			var onlyLetters = /^[a-zA-Z]*$/;
			var validity=0;
			var check_status=true;
			
			$( "form :text" ).each(function(){
				textElements.push($(this));
				//alert(" ID =["+$(this).attr('id')+"]");
				validity=$(this).val();
				if($(this).attr('id')!='maskedName' && (!validity.match(numbers))){
					alert(" Not a valid value");
					$(this).css("background-color","lightyellow");
					$(this).focus();
					check_status= false;
				}else if( $(this).attr('id') =='maskedName'){
					var mskedName=$(this).val().trim();
					//alert(" Masked ID =["+$(this).attr('id')+"], STATUS="+(onlyLetters.test(mskedName)));
					
					if(mskedName=='' || (!onlyLetters.test(mskedName))){
						
						$(this).css("background-color","lightyellow");
						$(this).focus();
						check_status= false;
						alert("Masked Named always should be Text but not blank!");
					}
				}
			});
			//######## Subscription Promo Service ############
			if($("#enable_subPromo").prop('checked') && check_status==true){
				var tid=0;
				var status=true;
				if(!($("#rateplan_subPrepaidPromo").prop('checked') || $("#rateplan_subPostpaidPromo").prop('checked'))){
					status=confirm(" You have not selected any Promo-Option!\n If sure please press OK else press CANCEL!");
					if(status==false){
						$("#enable_subPromo").css("border","outset");
						$("#enable_subPromo").css("border-color","lightyellow");
						//$("#enable_subPromo").focus();
						check_status= false;;
					}
				}
				
				if($("#rateplan_subPrepaidPromo").prop('checked') && check_status==true){
					tid=$("#rateplan_subPrePaidTemplateId").val();
					if(tid==0){
						alert("Please select [Pre-paid Promo] SMS Template ID, else un-check the option!");
						$("#rateplan_subPrePaidTemplateId").css("border:","solid");
						$("#rateplan_subPrePaidTemplateId").css("border-width","2px");
						$("#rateplan_subPrePaidTemplateId").css("border-color","lightyellow");
						$("#rateplan_subPrePaidTemplateId").focus();
						check_status= false;;
					}
				}
				
				if($("#rateplan_subPostpaidPromo").prop('checked') && check_status==true){
					tid=$("#rateplan_subPostPaidTemplateId").val();
					if(tid==0){
						alert("Please select [Post-paid Promo] SMS Template ID, else un-check the option!");
						$("#rateplan_subPostPaidTemplateId").css("border-color:","solid 2px lightyellow");
						
						$("#rateplan_subPostPaidTemplateId").focus();
						check_status= false;
					}
				}	
			}
			//######## Subscription Auto Renewal-Validation Service ############
			if($("#enable_subRenew").prop('checked') && check_status== true){
				var status=true;
				if(! ($("#rateplan_enableSubAutoRenewPrepaid").prop('checked') || $("#rateplan_enableSubAutoRenewPostpaid").prop('checked') )){
					status=confirm(" You have not selected Auto-Renew for PrePaid or Post Paid!\n If sure please press OK  else press CANCELS and Un-check Enable Option");
					$("#enable_subRenew").css("border-color:","solid 2px lightyellow");
					if(status==false){
						check_status= false;
					}
				}
			}

			//######## RBT Purchage Promo Service ############
			if($("#enable_rbtPurchasePromo").prop('checked') && check_status==true){
				var tid=0;
				var status=true;
				if(!($("#rateplan_rbtPurchasePrepaidPromo").prop('checked') || $("#ratePlan_rbtPurchasePostpaidPromo").prop('checked'))){
					status=confirm(" You have not selected any Promo-Option!\n If sure please press OK else press CANCEL!");
					if(status==false){
						$("#enable_rbtPurchasePromo").css("border","solid 2px lightyellow");
						check_status= false;
					}
				}
				
				if($("#rateplan_rbtPurchasePrepaidPromo").prop('checked') && check_status==true){
					tid=$("#rateplan_rbtPurchasePrePaidTemplateId").val();
					if(tid==0){
						alert("Please select [Pre-paid Promo] SMS Template ID, else un-check the option!");
						$("#rateplan_rbtPurchasePrePaidTemplateId").css("border:","solid 2px lightyellow");
						$("#rateplan_rbtPurchasePrePaidTemplateId").focus();
						check_status= false;
					}
				}
				
				if($("#ratePlan_rbtPurchasePostpaidPromo").prop('checked') && check_status==true){
					tid=$("#rateplan_rbtPurchasePostPaidTemplateId").val();
					if(tid==0){
						alert("Please select [Post-paid Promo] SMS Template ID, else un-check the option!");
						$("#rateplan_rbtPurchasePostPaidTemplateId").css("border-color:","solid 2px lightyellow");
						
						$("#rateplan_rbtPurchasePostPaidTemplateId").focus();
						check_status= false;
					}
				}	
			}
			//######## RBT Auto Renewal-Validation Service ############
			
			if($("#enable_rbtAutoRenew").prop('checked') && check_status==true){
				var status=true;
				if(!($("#rateplan_enableRbtAutoRenewPostpaid").prop('checked')||$("#rateplan_enableRbtAutoRenewPrepaid").prop('checked'))){
					status=confirm(" You have not selected Auto-Renew for or  PrePaid!\n If sure please press OK  else press CANCELS and Un-check Enable Option");
					$("#enable_rbtAutoRenew").css("border-color:","solid 2px lightyellow");
					if(status==false){
						check_status= false;
					}
				}
			}
			
			/*
				alert("All Text ELEMENTS ="+textElements.length);
				for(var i=0;i<textElements.length;i++){
				 alert("textfield=["+i+"] and id=["+textElements[i].attr("id")+"]");
		  		}
		  	*/
		  	if(check_status==true){
			 	var st=confirm(" Rate Plan is going to submit!! If sure please press OK else CANCEL.");
			 	if(st==false){
					 return false;
			 	}else{
					 form.submit();
				 	return true;
			 	}
		  	}else{
				return false;
			} 
	 	  }//### END of submitFormHandler
	  });
});

//############ add fall back started ##########
//*********************************************
function addSubFallback(divID){
	
 	  alert("STATU= sub_DIV_Array ="+sub_DIV_Array+", FB_CHG_CODES="+FB_CHG_CODES);
 	 if(!validateFieldMe(divID)){
 	 	 return;
 	 }
	 if(sub_DIV_Array.length<=0){
		 alert(rangeExceedAlert);
		 return;
	 }
	 
	    alert("sub_DIV_Array[0] "+sub_DIV_Array[0]);
	    var subSelectID="rateplan_"+sub_DIV_Array[0]+"_chargingCode";
		var subValidityID="rateplan_"+sub_DIV_Array[0]+"_validity";
		var inputIndex=(sub_DIV_Array[0].split("_")[1]);
		
		alert(subSelectID);
		alert(subValidityID);
		alert(inputIndex);
		var subSelectName='rateplan.subscriptionDetails['+inputIndex+'].chargingCode';
		var subValidityName='rateplan.subscriptionDetails['+inputIndex+'].validity';
		var newDivID=sub_DIV_Array[0];
		alert("subSelectName "+subSelectName);
		alert("subValidityName "+subValidityName);
		alert("newDivID "+newDivID);
		//alert(" SUB_CODE_NAME ="+subSelectName+", SUB_VALIDITY_NAME ="+subValidityName+", New DIV ID="+newDivID);
		
		var newDIV=$('<div/>',{"id":newDivID});
		var newTable=$('<table/>').attr({border:"1",width:"100%",cellspacing:"0"});
		
		var t_row=$('<tr/>');

		var subCodeStr=chargingCodeLabel;
				
		//######## Creating Select Option
		subCodeStr+='<select name="'+subSelectName+'" id="'+subSelectID+'" onchange="validateOption(';
		subCodeStr+="'"+newDivID+"');";
		subCodeStr+='">';
		subCodeStr+='<option value="0">select</option>';
		var chg_array=null;
		for(var i=0;i<FB_CHG_CODES.length;i++){
			chg_array=FB_CHG_CODES[i].split("#");
			subCodeStr+='<option value="'+chg_array[0]+'">'+chg_array[1]+'</option>';
		}
		subCodeStr+='</select>';
		//alert("CHARGE_CODES  ==== "+subCodeStr);
		$('<td/>').html(subCodeStr).appendTo(t_row);
		
		//######## Creating Validity text Field
		var validityStr=validityLabel+' : &nbsp;&nbsp; <input type="text" name="'+subValidityName+'"  id="'+subValidityID+'" size="10" maxlength="5" value="0" onkeypress="return numberOnly(event);" >';
		//alert(validityStr);
		$('<td/>').html(validityStr).appendTo(t_row);

		//######## Creating addButton Field
		var addBtnStr='<input type="button" value="'+addButtonLabel+'" class="subadd" onclick="addSubFallback(';
		addBtnStr+="'"+sub_DIV_Array[0]+"')";
		addBtnStr+='"/>';
		//alert(addBtnStr);
		$('<td/>').html(addBtnStr).appendTo(t_row);
		
		//######## Creating deleteButton Field
		var deleteBtnStr='<input type="button" value="'+deleteButtonLabel+'" data-divid="'+newDivID+'" onclick="deleteMe(';
		deleteBtnStr+="'"+newDivID.trim()+"')";
		deleteBtnStr+='"/>';
		
		//alert(deleteBtnStr);
		$('<td/>').html(deleteBtnStr).appendTo(t_row);

		//##### appending row to newTable
		newTable.append(t_row);
		
		//##### appending table to newDiv
		newDIV.append(newTable);
		
		//##### appending newDiv to subDiv
		$("#subDiv").append(newDIV);

		//#### Managing sub_DIV_Array array
		//alert("old Array="+sub_DIV_Array);
		//### Removing 1st index from sub_DIV_Array
		sub_DIV_Array.splice(0,1);
		//sub_DIV_Array.sort();
		//alert("New Array="+sub_DIV_Array);
}
 // *************** FOR SUBSCRIPTION RENEW ************************** 
 
 function addSubRenewFallback(divID)
 {
	 //alert("inside Subscription Renew");
 	 if(!validateFieldMe(divID)){
 	 	 return;
 	 }
	 if(subRenew_DIV_Array.length<=0){
		 alert(rangeExceedAlert);
		 
		 return;
	 }
	    var subRenewSelectID="rateplan_"+subRenew_DIV_Array[0]+"_chargingCode";
		var subRenewValidityID="rateplan_"+subRenew_DIV_Array[0]+"_validity";
		var subRenewSTID="rateplan_"+subRenew_DIV_Array[0]+"_STID";
		var subRenewFTID="rateplan_"+subRenew_DIV_Array[0]+"_FTID";
		
		var inputIndex=(subRenew_DIV_Array[0].split("_")[1]);
		
		//alert(" SUB_CODE_ID ="+subRenewSelectID+", SUB_RenewVALIDITY_ID ="+subRenewValidityID+", INPUT INDEX ="+inputIndex);

		var subRenewSelectName='rateplan.subscriptionRenewDetails['+inputIndex+'].chargingCode';
		var subRenewValidityName='rateplan.subscriptionRenewDetails['+inputIndex+'].validity';
		var stIDName='rateplan.subscriptionRenewDetails['+inputIndex+'].renewSuccessTemplateID';
		var ftIDName='rateplan.subscriptionRenewDetails['+inputIndex+'].renewFailedTemplateID';
		
		var newDivID=subRenew_DIV_Array[0];
		
		//alert(" SUB_CODE_NAME ="+subRenewSelectName+", SUB_RenewVALIDITY_NAME ="+subRenewValidityName+", New DIV ID="+newDivID);
		var newDIV=$('<div/>',{"id":newDivID});
		var newTable=$('<table/>').attr({border:"1",width:"100%",cellspacing:"0"});
		var t_row=$('<tr/>');

		var subRenewCodeStr=chargingCodeLabel;
				
		//######## Creating Select Option
		subRenewCodeStr+='<select name="'+subRenewSelectName+'" id="'+subRenewSelectID+'" onchange="validateOption(';
		subRenewCodeStr+="'"+newDivID+"');";
		subRenewCodeStr+='" style="width:60px;">';
		subRenewCodeStr+='<option value="0">select</option>';
		var chg_arr=null;
		for(var i=0;i<FB_CHG_CODES.length;i++){
			chg_array=FB_CHG_CODES[i].split("#");
			subRenewCodeStr+='<option value="'+chg_array[0]+'">'+chg_array[1]+'</option>';
		}
		subRenewCodeStr+='</select>';
		//alert("CHARGE_CODES  ==== "+subRenewCodeStr);
		$('<td/>').html(subRenewCodeStr).appendTo(t_row);
		
		//######## Creating Validity text Field
		var validityStr=validityLabel+' : &nbsp;&nbsp;<input type="text" name="'+subRenewValidityName+'"  id="'+subRenewValidityID+'" size="10" maxlength="5" value="0" onkeypress="return numberOnly(event);" >';
		//alert(validityStr);
		$('<td/>').html(validityStr).appendTo(t_row);

		//######## creating select option TEMPLATE_IDS
		//
		var stidStr='Select Template ID: </br> <select	name="'+stIDName+'" id="'+subRenewSTID+'"  style="width:90px" >';
		stidStr+='<option value="0">SUCCESS TEMPLATE-ID</option>';				
		for(var i=0;i<TEMPLATE_IDS.length;i++){
			stidStr+='<option value="'+TEMPLATE_IDS[i]+'">'+TEMPLATE_IDS[i]+'</option>';			
		}
		stidStr+="</select>";
		var ftidStr='<select	name="'+ftIDName+'" id="'+subRenewFTID+'"  style="width:90px" >';
		ftidStr+='<option value="0">FAILURE TEMPLATE-ID</option>';				
		for(var i=0;i<TEMPLATE_IDS.length;i++){
			ftidStr+='<option value="'+TEMPLATE_IDS[i]+'">'+TEMPLATE_IDS[i]+'</option>';			
		}

		
		ftidStr+="</select>";
		//alert(stidStr);
		
		$('<td/>').html(stidStr+ftidStr).appendTo(t_row);
		//######## Creating addButton Field
		var addBtnStr='<input type="button" value="'+addButtonLabel+'" class="subadd" onclick="addSubRenewFallback(';
		addBtnStr+="'"+subRenew_DIV_Array[0]+"')";
		addBtnStr+='"/>';
		//alert(addBtnStr);
		$('<td/>').html(addBtnStr).appendTo(t_row);
		
		//######## Creating deleteButton Field
		var deleteBtnStr='<input type="button" value="'+deleteButtonLabel+'" data-divid="'+newDivID+'" onclick="deleteMe(';
		deleteBtnStr+="'"+newDivID.trim()+"')";
		deleteBtnStr+='"/>';
		
		//alert(deleteBtnStr);
		$('<td/>').html(deleteBtnStr).appendTo(t_row);

		//##### appending row to newTable
		newTable.append(t_row);
		
		//##### appending table to newDiv
		newDIV.append(newTable);
		
		//##### appending newDiv to subDiv
		$("#subRenewDiv").append(newDIV);

		//#### Managing sub_DIV_Array array
		//alert("old Array="+subRenew_DIV_Array);
		//### Removing 1st index from sub_DIV_Array
		subRenew_DIV_Array.splice(0,1);
		//subRenew_DIV_Array.sort();
		//alert("New Array="+subRenew_DIV_Array);
}
// *********************** End ******************************** 
// ********************** Added by manoj ********************* 

function addRbtPurchaseFallback(divID){
	
	 
	 if(!validateFieldMe(divID)){
	 	 return;
	 }
	 if(rbtp_DIV_Array.length<=0){
		 alert(rangeExceedAlert);
		 return;
	 }
	 
	    var rbtPurSelectID="rateplan_"+rbtp_DIV_Array[0]+"_chargingCode";
		var rbtPurValidityID="rateplan_"+rbtp_DIV_Array[0]+"_validity";
		
		var inputIndex=(rbtp_DIV_Array[0].split("_")[1]);
		
		//alert(" SUB_CODE_ID ="+subSelectID+", SUB_VALIDITY_ID ="+subValidityID+", INPUT INDEX ="+inputIndex);

		var rbtPurSelectName='rateplan.rbtPurchaseDetails['+inputIndex+'].chargingCode';
		var rbtPurValidityName='rateplan.rbtPurchaseDetails['+inputIndex+'].validity';
		var newDivID=rbtp_DIV_Array[0];
		$("#rateplan_subPostPaidTemplateId").css("border-color:","lightyellow");
		//alert(" SUB_CODE_NAME ="+subSelectName+", SUB_VALIDITY_NAME ="+subValidityName+", New DIV ID="+newDivID);
		var newDIV=$('<div/>',{"id":newDivID});
		var newTable=$('<table/>').attr({border:"1",width:"100%",cellspacing:"0"});
		var t_row=$('<tr/>');

		var rbtPurCodeStr=chargingCodeLabel;
				
		//######## Creating Select Option
		rbtPurCodeStr+='<select name="'+rbtPurSelectName+'" id="'+rbtPurSelectID+'" onchange="validateOption(';
		rbtPurCodeStr+="'"+newDivID+"');";
		rbtPurCodeStr+='">';
		
		rbtPurCodeStr+='<option value="0">select</option>';
		var chg_array=null;
		for(var i=0;i<FB_CHG_CODES.length;i++){
			chg_array=FB_CHG_CODES[i].split("#");
			rbtPurCodeStr+='<option value="'+chg_array[0]+'">'+chg_array[1]+'</option>';
		}
		rbtPurCodeStr+='</select>';
		//alert("CHARGE_CODES  ==== "+rbtPurCodeStr);
		$('<td/>').html(rbtPurCodeStr).appendTo(t_row);
		
		//######## Creating Validity text Field
		var validityStr=validityLabel+' : &nbsp;&nbsp;<input type="text" name="'+rbtPurValidityName+'"  id="'+rbtPurValidityID+'" size="10" maxlength="5" value="0"  onkeypress="return numberOnly(event);" />';
		//alert(validityStr);
		$('<td/>').html(validityStr).appendTo(t_row);

		//######## Creating addButton Field
		var addBtnStr='<input type="button" value="'+addButtonLabel+'" class="subadd" onclick="addRbtPurchaseFallback(';
		addBtnStr+="'"+rbtp_DIV_Array[0]+"')";
		addBtnStr+='"/>';
		//alert(addBtnStr);
		$('<td/>').html(addBtnStr).appendTo(t_row);
		
		//######## Creating deleteButton Field
		var deleteBtnStr='<input type="button" value="'+deleteButtonLabel+'" data-divid="'+newDivID+'" onclick="deleteMe(';
		deleteBtnStr+="'"+newDivID.trim()+"')";
		deleteBtnStr+='"/>';
		//alert(deleteBtnStr);
		$('<td/>').html(deleteBtnStr).appendTo(t_row);

		//##### appending row to newTable
		newTable.append(t_row);
		
		//##### appending table to newDiv
		newDIV.append(newTable);
		
		//##### appending newDiv to subDiv
		$("#rbtPurchaseDiv").append(newDIV);

		//#### Managing rbtp_DIV_Array array
		//alert("old Array="+rbtp_DIV_Array);
		//### Removing 1st index from rbtp_DIV_Array
		 rbtp_DIV_Array.splice(0,1);
		 //rbtp_DIV_Array.sort();
		// alert("New Array="+rbtp_DIV_Array);
}


// ************** Rbt Purchase Renewal **************************** 
function addRbtPurRenewFallback(divID){
	
	 if(!validateFieldMe(divID)){
	 	 return;
	 }
	 if(rbtpRenew_DIV_Array.length<=0){
		 alert(rangeExceedAlert);
		 return;
	 }
	 
	    var rbtPurRenewSelectID="rateplan_"+rbtpRenew_DIV_Array[0]+"_chargingCode";
		var rbtPurRenewValidityID="rateplan_"+rbtpRenew_DIV_Array[0]+"_validity";

		var rbtRenewSTID="rateplan_"+rbtpRenew_DIV_Array[0]+"_STID";
		var rbtRenewFTID="rateplan_"+rbtpRenew_DIV_Array[0]+"_FTID";
		
		var inputIndex=(rbtpRenew_DIV_Array[0].split("_")[1]);
		
		//alert(" SUB_CODE_ID ="+subSelectID+", SUB_VALIDITY_ID ="+subValidityID+", INPUT INDEX ="+inputIndex);

		var rbtPurRenewSelectName='rateplan.rbtRenewDetails['+inputIndex+'].chargingCode';
		var rbtPurRenewValidityName='rateplan.rbtRenewDetails['+inputIndex+'].validity';

		var stIDName='rateplan.rbtRenewDetails['+inputIndex+'].renewSuccessTemplateID';
		var ftIDName='rateplan.rbtRenewDetails['+inputIndex+'].renewFailedTemplateID';
		
		var newDivID=rbtpRenew_DIV_Array[0];
		
		//alert(" SUB_CODE_NAME ="+subSelectName+", SUB_VALIDITY_NAME ="+subValidityName+", New DIV ID="+newDivID);
		var newDIV=$('<div/>',{"id":newDivID});
		var newTable=$('<table/>').attr({border:"1",width:"100%",cellspacing:"0"});
		var t_row=$('<tr/>');

		var rbtPurRenewCodeStr=chargingCodeLabel;
				
		//######## Creating Select Option
		rbtPurRenewCodeStr+='<select name="'+rbtPurRenewSelectName+'" id="'+rbtPurRenewSelectID+'" onchange="validateOption(';
		rbtPurRenewCodeStr+="'"+newDivID+"');";
		rbtPurRenewCodeStr+='" style="width:60px;">';
		rbtPurRenewCodeStr+='">';
		
		rbtPurRenewCodeStr+='<option value="0">select</option>';
		var chg_array=null;
		for(var i=0;i<FB_CHG_CODES.length;i++){
			chg_array=FB_CHG_CODES[i].split("#");
			rbtPurRenewCodeStr+='<option value="'+chg_array[0]+'">'+chg_array[1]+'</option>';
		}
		rbtPurRenewCodeStr+='</select>';
		//alert("CHARGE_CODES  ==== "+rbtPurCodeStr);
		$('<td/>').html(rbtPurRenewCodeStr).appendTo(t_row);
		
		//######## Creating Validity text Field
		var validityStr=validityLabel+' : &nbsp;&nbsp; <input type="text" name="'+rbtPurRenewValidityName+'"  id="'+rbtPurRenewValidityID+'" size="10" maxlength="5" value="0"  onkeypress="return numberOnly(event);" />';
		//alert(validity$("#rateplan_subPostPaidTemplateId").css("border-color:","lightyellow");Str);
		$('<td/>').html(validityStr).appendTo(t_row);
		
		var stidStr='Select Template ID: </br> <select	name="'+stIDName+'" id="'+rbtRenewSTID+'"  style="width:90px" >';
		stidStr+='<option value="0">SUCCESS TEMPLATE-ID</option>';				
		for(var i=0;i<TEMPLATE_IDS.length;i++){
			stidStr+='<option value="'+TEMPLATE_IDS[i]+'">'+TEMPLATE_IDS[i]+'</option>';			
		}
		stidStr+="</select>";
		var ftidStr='<select	name="'+ftIDName+'" id="'+rbtRenewFTID+'"  style="width:90px" >';
		ftidStr+='<option value="0">FAILURE TEMPLATE-ID</option>';				
		for(var i=0;i<TEMPLATE_IDS.length;i++){
			ftidStr+='<option value="'+TEMPLATE_IDS[i]+'">'+TEMPLATE_IDS[i]+'</option>';			
		}
		ftidStr+="</select>";
		$('<td/>').html(stidStr+ftidStr).appendTo(t_row);

		
		//######## Creating addButton Field
		var addBtnStr='<input type="button" value="'+addButtonLabel+'" class="subadd" onclick="addRbtPurRenewFallback(';
		addBtnStr+="'"+rbtpRenew_DIV_Array[0]+"')";
		addBtnStr+='"/>';
		//alert(addBtnStr);
		$('<td/>').html(addBtnStr).appendTo(t_row);
		
		//######## Creating deleteButton Field
		var deleteBtnStr='<input type="button" value="'+deleteButtonLabel+'" data-divid="'+newDivID+'" onclick="deleteMe(';
		deleteBtnStr+="'"+newDivID.trim()+"')";
		deleteBtnStr+='"/>';
		//alert(deleteBtnStr);
		$('<td/>').html(deleteBtnStr).appendTo(t_row);

		//##### appending row to newTable
		newTable.append(t_row);
		
		//##### appending table to newDiv
		newDIV.append(newTable);
		
		//##### appending newDiv to subDiv
		$("#rbtRenewDiv").append(newDIV);
    
		//#### Managing rbtp_DIV_Array array
		//alert("old Array="+rbtpRenew_DIV_Array);
		//### Removing 1st index from rbtp_DIV_Array
		 rbtpRenew_DIV_Array.splice(0,1);
		 //rbtpRenew_DIV_Array.sort();
		 
		 //alert("New Array===="+rbtpRenew_DIV_Array);
}
 
// ************** End Of Rbt Purchase Renewal *********************** 
 
//  *****************for Recording ******************** 
function addRecordingFallback(divID){
	
	 
	 if(!validateFieldMe(divID)){
	 	 return;
	 }
	 if(recordp_DIV_Array.length<=0){
		 alert(rangeExceedAlert);
		 return;
	 }
	 
	    //var rbtPurSelectID="rateplan_"+rbtp_DIV_Array[0]+"_chargingCode";
	    var recordSelectID="rateplan_"+recordp_DIV_Array[0]+"_chargingCode";
		//var rbtPurValidityID="rateplan_"+rbtp_DIV_Array[0]+"_validity";
		var recordValidityID="rateplan_"+recordp_DIV_Array[0]+"_validity";
		var inputIndex=(recordp_DIV_Array[0].split("_")[1]);
		
		//alert(" SUB_CODE_ID ="+subSelectID+", SUB_VALIDITY_ID ="+subValidityID+", INPUT INDEX ="+inputIndex);

		var recordSelectName='rateplan.rbtRecordingDetails['+inputIndex+'].chargingCode';
		var recordValidityName='rateplan.rbtRecordingDetails['+inputIndex+'].validity';
		var newDivID=recordp_DIV_Array[0];
		
		//alert(" SUB_CODE_NAME ="+subSelectName+", SUB_VALIDITY_NAME ="+subValidityName+", New DIV ID="+newDivID);
		var newDIV=$('<div/>',{"id":newDivID});
		var newTable=$('<table/>').attr({border:"1",width:"100%",cellspacing:"0"});
		var t_row=$('<tr/>');

		var recordCodeStr=chargingCodeLabel;
				
		//######## Creating Select Option
		recordCodeStr+='<select name="'+recordSelectName+'" id="'+recordSelectID+'" onchange="validateOption(';
		recordCodeStr+="'"+newDivID+"');";
		recordCodeStr+='">';
		
		recordCodeStr+='<option value="0">select</option>';
		var chg_array=null;
		for(var i=0;i<FB_CHG_CODES.length;i++){
			chg_array=FB_CHG_CODES[i].split("#");
			recordCodeStr+='<option value="'+chg_array[0]+'">'+chg_array[1]+'</option>';
		}
		recordCodeStr+='</select>';
		//alert("CHARGE_CODES  ==== "+rbtPurCodeStr);
		$('<td/>').html(recordCodeStr).appendTo(t_row);
		
		//######## Creating Validity text Field
		var validityStr=validityLabel+' : &nbsp;&nbsp;<input type="text" name="'+recordValidityName+'"  id="'+recordValidityID+'" size="10" maxlength="5" value="0"  onkeypress="return numberOnly(event);" >';
		//alert(validityStr);
		$('<td/>').html(validityStr).appendTo(t_row);

		//######## Creating addButton Field
		var addBtnStr='<input type="button" value="'+addButtonLabel+'" class="subadd" onclick="addRecordingFallback(';
		addBtnStr+="'"+recordp_DIV_Array[0]+"')";
		addBtnStr+='"/>';
		//alert(addBtnStr);
		$('<td/>').html(addBtnStr).appendTo(t_row);
		
		//######## Creating deleteButton Field
		var deleteBtnStr='<input type="button" value="'+deleteButtonLabel+'" data-divid="'+newDivID+'" onclick="deleteMe(';
		deleteBtnStr+="'"+newDivID.trim()+"')";
		deleteBtnStr+='"/>';
		//alert(deleteBtnStr);
		$('<td/>').html(deleteBtnStr).appendTo(t_row);

		//##### appending row to newTable
		newTable.append(t_row);
		
		//##### appending table to newDiv
		newDIV.append(newTable);
		
		//##### appending newDiv to subDiv
		$("#recordDiv").append(newDIV);

		//#### Managing rbtp_DIV_Array array
		//alert("old Array="+recordp_DIV_Array);
		//### Removing 1st index from rbtp_DIV_Array
		 recordp_DIV_Array.splice(0,1);
		// recordp_DIV_Array.sort();
		 //alert("New Array="+recordp_DIV_Array);
}

// ************************* Recording Renew ************************ 
function addRecordingRenewFallback(divID){
	
	 if(!validateFieldMe(divID)){
	 	 return;
	 }
	 if(recordRenew_DIV_Array.length<=0){
		 alert(rangeExceedAlert);
		 return;
	 }
	 
	    var recordingRenewSelectID="rateplan_"+recordRenew_DIV_Array[0]+"_chargingCode";
		var recordingRenewValidityID="rateplan_"+recordRenew_DIV_Array[0]+"_validity";

		var recordingRenewSTID="rateplan_"+recordRenew_DIV_Array[0]+"_STID";
		var recordingRenewFTID="rateplan_"+recordRenew_DIV_Array[0]+"_FTID";
		
		var inputIndex=(recordRenew_DIV_Array[0].split("_")[1]);
		
		//alert(" SUB_CODE_ID ="+subSelectID+", SUB_VALIDITY_ID ="+subValidityID+", INPUT INDEX ="+inputIndex);

		var recordingRenewSelectName='rateplan.recordingRenewDetails['+inputIndex+'].chargingCode';
		var recordingRenewValidityName='rateplan.recordingRenewDetails['+inputIndex+'].validity';

		var stIDName='rateplan.recordingRenewDetails['+inputIndex+'].renewSuccessTemplateID';
		var ftIDName='rateplan.recordingRenewDetails['+inputIndex+'].renewFailedTemplateID';
		
		var newDivID=recordRenew_DIV_Array[0];
		
		//alert(" SUB_CODE_NAME ="+subSelectName+", SUB_VALIDITY_NAME ="+subValidityName+", New DIV ID="+newDivID);
		var newDIV=$('<div/>',{"id":newDivID});
		var newTable=$('<table/>').attr({border:"1",width:"100%",cellspacing:"0"});
		var t_row=$('<tr/>');

		var recordingRenewCodeStr=chargingCodeLabel;
				
		//######## Creating Select Option
		recordingRenewCodeStr+='<select name="'+recordingRenewSelectName+'" id="'+recordingRenewSelectID+'" onchange="validateOption(';
		recordingRenewCodeStr+="'"+newDivID+"');";
		recordingRenewCodeStr+='" style="width:60px;">';
		recordingRenewCodeStr+='">';
		
		recordingRenewCodeStr+='<option value="0">select</option>';
		var chg_array=null;
		for(var i=0;i<FB_CHG_CODES.length;i++){
			chg_array=FB_CHG_CODES[i].split("#");
			recordingRenewCodeStr+='<option value="'+chg_array[0]+'">'+chg_array[1]+'</option>';
		}
		recordingRenewCodeStr+='</select>';
		//alert("CHARGE_CODES  ==== "+rbtPurCodeStr);
		$('<td/>').html(recordingRenewCodeStr).appendTo(t_row);
		
		//######## Creating Validity text Field
		var validityStr=validityLabel+' :&nbsp;&nbsp;  <input type="text" name="'+recordingRenewValidityName+'"  id="'+recordingRenewValidityID+'" size="10" maxlength="5" value="0"  onkeypress="return numberOnly(event);"/>';
		//alert(validity$("#rateplan_subPostPaidTemplateId").css("border-color:","lightyellow");Str);
		$('<td/>').html(validityStr).appendTo(t_row);
		
		var stidStr='Select Template ID: </br> <select	name="'+stIDName+'" id="'+recordingRenewSTID+'"  style="width:90px" >';
		stidStr+='<option value="0">SUCCESS TEMPLATE-ID</option>';				
		for(var i=0;i<TEMPLATE_IDS.length;i++){
			stidStr+='<option value="'+TEMPLATE_IDS[i]+'">'+TEMPLATE_IDS[i]+'</option>';			
		}
		stidStr+="</select>";
		var ftidStr='<select	name="'+ftIDName+'" id="'+recordingRenewFTID+'"  style="width:90px" >';
		ftidStr+='<option value="0">FAILURE TEMPLATE-ID</option>';				
		for(var i=0;i<TEMPLATE_IDS.length;i++){
			ftidStr+='<option value="'+TEMPLATE_IDS[i]+'">'+TEMPLATE_IDS[i]+'</option>';			
		}
		ftidStr+="</select>";
		$('<td/>').html(stidStr+ftidStr).appendTo(t_row);

		
		//######## Creating addButton Field
		var addBtnStr='<input type="button" value="'+addButtonLabel+'" class="subadd" onclick="addRecordingRenewFallback(';
		addBtnStr+="'"+recordRenew_DIV_Array[0]+"')";
		addBtnStr+='"/>';
		//alert(addBtnStr);
		$('<td/>').html(addBtnStr).appendTo(t_row);
		
		//######## Creating deleteButton Field
		var deleteBtnStr='<input type="button" value="'+deleteButtonLabel+'" data-divid="'+newDivID+'" onclick="deleteMe(';
		deleteBtnStr+="'"+newDivID.trim()+"')";
		deleteBtnStr+='"/>';
		//alert(deleteBtnStr);
		$('<td/>').html(deleteBtnStr).appendTo(t_row);

		//##### appending row to newTable
		newTable.append(t_row);
		
		//##### appending table to newDiv
		newDIV.append(newTable);
		
		//##### appending newDiv to subDiv
		$("#recordRenewDiv").append(newDIV);
   
		//#### Managing rbtp_DIV_Array array
		//alert("old Array="+rbtpRenew_DIV_Array);
		//### Removing 1st index from rbtp_DIV_Array
		 recordRenew_DIV_Array.splice(0,1);
		 //recordRenew_DIV_Array.sort();
		 
		 //alert("New Array===="+rbtpRenew_DIV_Array);
}


// ******************************* End Of Recording ***************************** -->

   
function addGiftFallback(divID){
	
	 alert("fddg"+divID);
	 if(!validateFieldMe(divID)){
	 	 return;
	 }
	 if(giftp_DIV_Array.length<=0){
		 alert(rangeExceedAlert);
		 return;
	 }
	 
	 
	 
	 
		var giftSelectID="rateplan_"+giftp_DIV_Array[0]+"_chargingCode";
		var giftValidityID="rateplan_"+giftp_DIV_Array[0]+"_validity";
		var inputIndex=(giftp_DIV_Array[0].split("_")[1]);
		
		var giftSelectName='rateplan.rbtGiftDetails['+inputIndex+'].chargingCode';
		var giftValidityName='rateplan.rbtGiftDetails['+inputIndex+'].validity';
		var newDivID=giftp_DIV_Array[0];
	    var newDIV=$('<div/>',{"id":newDivID});
		var newTable=$('<table/>').attr({border:"1",width:"100%",cellspacing:"0"});
		var t_row=$('<tr/>');
        		
		var giftCodeStr=chargingCodeLabel;
				
		//######## Creating Select Option
		giftCodeStr+='<select name="'+giftSelectName+'" id="'+giftSelectID+'" onchange="validateOption(';
		giftCodeStr+="'"+newDivID+"');";
		giftCodeStr+='">';
		
		giftCodeStr+='<option value="0">select</option>';
		var chg_array=null;
		for(var i=0;i<FB_CHG_CODES.length;i++){
			chg_array=FB_CHG_CODES[i].split("#");
			giftCodeStr+='<option value="'+chg_array[0]+'">'+chg_array[1]+'</option>';
		}
		giftCodeStr+='</select>';
		$('<td/>').html(giftCodeStr).appendTo(t_row);
		
		//######## Creating Validity text Field
		var validityStr=validityLabel+' : &nbsp;&nbsp; <input type="text" name="'+giftValidityName+'"  id="'+giftValidityID+'" size="10" maxlength="5" value="0" onkeypress="return numberOnly(event);" >';
		$('<td/>').html(validityStr).appendTo(t_row);

		//######## Creating addButton Field
		var addBtnStr='<input type="button" value="'+addButtonLabel+'" class="subadd" onclick="addGiftFallback(';
		addBtnStr+="'"+giftp_DIV_Array[0]+"')";
		addBtnStr+='"/>';
		//alert(addBtnStr);
		$('<td/>').html(addBtnStr).appendTo(t_row);
		
		//######## Creating deleteButton Field
		var deleteBtnStr='<input type="button" value="'+deleteButtonLabel+'" data-divid="'+newDivID+'" onclick="deleteMe(';
		deleteBtnStr+="'"+newDivID.trim()+"')";
		deleteBtnStr+='"/>';
		$('<td/>').html(deleteBtnStr).appendTo(t_row);

		//##### appending row to newTable
		newTable.append(t_row);
		
		//##### appending table to newDiv
		newDIV.append(newTable);
		
		//##### appending newDiv to subDiv
		$("#giftDiv").append(newDIV);

		//#### Managing rbtp_DIV_Array array
		//alert("old Array="+giftp_DIV_Array);
		//### Removing 1st index from rbtp_DIV_Array
		giftp_DIV_Array.splice(0,1);
		 //giftp_DIV_Array.sort();
		 //alert("New Array="+giftp_DIV_Array);
}
  
//********************** end of GIFT ************************** 



//**********************Free Rbt ********************************

function addFreeRbtFallback(divID){
	
	
     alert("free");
	 
	 if(!validateFieldMe(divID)){
		  return;
	 }
	
	  
	 if(free_DIV_Array.length<=0){
		 alert(rangeExceedAlert);
		 return;
	 }
	 alert("size "+free_DIV_Array.length);
	 
	 
	 	var giftSelectID="rateplan_"+free_DIV_Array[0]+"_chargingCode";
		var giftValidityID="rateplan_"+free_DIV_Array[0]+"_validity";
		var inputIndex=(free_DIV_Array[0].split("_")[1]);
		
		var giftSelectName='rateplan.freeRbtDetails['+inputIndex+'].chargingCode';
		
		var giftValidityName='rateplan.freeRbtDetails['+inputIndex+'].validity';
		var newDivID=free_DIV_Array[0];
		
		alert("new divId "+newDivID);
		
	    var newDIV=$('<div/>',{"id":newDivID});
		var newTable=$('<table/>').attr({border:"1",width:"100%",cellspacing:"0"});
		var t_row=$('<tr/>');

		var giftCodeStr=chargingCodeLabel;
				
		//######## Creating Select Option
		giftCodeStr+='<select name="'+giftSelectName+'" id="'+giftSelectID+'" onchange="validateOption(';
		giftCodeStr+="'"+newDivID+"');";
		giftCodeStr+='">';
		
		giftCodeStr+='<option value="0">select</option>';
		var chg_array=null;
		for(var i=0;i<FB_CHG_CODES.length;i++){
			chg_array=FB_CHG_CODES[i].split("#");
			giftCodeStr+='<option value="'+chg_array[0]+'">'+chg_array[1]+'</option>';
		}
		giftCodeStr+='</select>';
		$('<td/>').html(giftCodeStr).appendTo(t_row);
		
		//######## Creating Validity text Field
		var validityStr=validityLabel+' : &nbsp;&nbsp; <input type="text" name="'+giftValidityName+'"  id="'+giftValidityID+'" size="10" maxlength="5" value="0" onkeypress="return numberOnly(event);" >';
		$('<td/>').html(validityStr).appendTo(t_row);

		//######## Creating addButton Field
		var addBtnStr='<input type="button" value="'+addButtonLabel+'" class="subadd" onclick="addFreeRbtFallback(';
		addBtnStr+="'"+free_DIV_Array[0]+"')";
		addBtnStr+='"/>';
		//alert(addBtnStr);
		$('<td/>').html(addBtnStr).appendTo(t_row);
		
		//######## Creating deleteButton Field
		var deleteBtnStr='<input type="button" value="'+deleteButtonLabel+'" data-divid="'+newDivID+'" onclick="deleteMe(';
		deleteBtnStr+="'"+newDivID.trim()+"')";
		deleteBtnStr+='"/>';
		$('<td/>').html(deleteBtnStr).appendTo(t_row);

		//##### appending row to newTable
		newTable.append(t_row);
		
		//##### appending table to newDiv
		newDIV.append(newTable);
		
		//##### appending newDiv to subDiv
		$("#freeDiv").append(newDIV);

		//#### Managing rbtp_DIV_Array array
		//alert("old Array="+giftp_DIV_Array);
		//### Removing 1st index from rbtp_DIV_Array
		 free_DIV_Array.splice(0,1);
		 //giftp_DIV_Array.sort();
		 //alert("New Array="+giftp_DIV_Array);
}





//********************End Free Rbt ****************************

function validateFieldMe(divID){

	
	var optionId=divID.split("_");
	alert(optionId);
	var numbers = /^[-+]?[0-9]+$/;
	
	if(optionId[0]=="sub"){TEMPLATE_IDS
		
		var subSelectID="rateplan_"+divID+"_chargingCode";
		var subValidityID="rateplan_"+divID+"_validity";

		var chgCode=$("#"+subSelectID+" option:selected").val();
		var validity=$("#"+subValidityID).val();
		
		
		alert("validity:"+validity)
		//var chgCode=$('#rateplan.sub_0.chargingCode option:selected').attr('value');
		//var validity=$("input[id$=rateplan.sub_0.validity]").val()
		//var validity=$('#rateplan.sub_0.validity').val();
		//var validity=$('#'+subValidityID).val();
		
		//$("#"+subValidityID).val(0);
		//$("#"+subValidityID).focus();
		
		//var chgCode=doc$("#rateplan_subPostPaidTemplateId").css("border-color:","lightyellow");ument.getElementById(subSelectID).options[document.getElementById(subSelectID).selectedIndex].value;
		//var validity=document.getElementById(subValidityID).value;
				
		//alert("Validation CHG_CODE="+chgCode);
		//alert("Validation VALIDITY="+validity);
		
		if( chgCode==0 ){
			
			
			alert("No Charge code is selcted, Please Select Proper Code!");
			document.getElementById(subSelectID).focus();
			return false;
		}else if(!validity.match(numbers)){
			alert("Invalid Validty Value Only Numeric Allowed");
			document.getElementById(subValidityID).focus();
			return false;	
		}else{
			//alert("Add validation is cleared!!");
			return true;
		}
		
	}else if(optionId[0]=="rbtp"){
		var rbtpSelectID="rateplan_"+divID+"_chargingCode";
		var rbtpValidityID="rateplan_"+divID+"_validity";

		//alert(rbtpSelectID+" ########### "+rbtpValidityID);

		var chgCode=$("#"+rbtpSelectID+" option:selected").val();
		var validity=$("#"+rbtpValidityID).val();

		alert("Validation CHG_CODE="+chgCode);
		alert("Validation VALIDITY="+validity);
		
		if( chgCode==0 ){
			alert("No Charge code is selcted, Please Select Proper Code!");
			$("#"+rbtpSelectID).focus();
				//document.getElementById(rbtpSelectID).focus();
			return false;
		}else if(!validity.match(numbers)){
			alert("Invalid Validty Value Only Numeric Allowed");
			$("#"+rbtpValidityID).focus();
			//document.getElementById(rbtpValidityID).focus();
			return false;	
		}else{
			//alert("Add validation is cleared!!");
			return true;
		}
	}
	
	//added by harjinder
	else if(optionId[0]=="free"){
		
		
		var rbtpSelectID="rateplan_"+divID+"_chargingCode";
		var rbtpValidityID="rateplan_"+divID+"_validity";

		//alert(rbtpSelectID+" ########### "+rbtpValidityID);

		var chgCode=$("#"+rbtpSelectID+" option:selected").val();
		var validity=$("#"+rbtpValidityID).val();

		alert("Validation CHG_CODE="+chgCode);
		alert("Validation VALIDITY="+validity);
		
		if( chgCode==0 ){
			alert("No Charge code is selcted, Please Select Proper Code!");
			$("#"+rbtpSelectID).focus();
				//document.getElementById(rbtpSelectID).focus();
			return false;
		}else if(!validity.match(numbers)){
			alert("Invalid Validty Value Only Numeric Allowed");
			$("#"+rbtpValidityID).focus();
			//document.getElementById(rbtpValidityID).focus();
			return false;	
		}else{
			//alert("Add validation is cleared!!");
			return true;
		}
	}
	
	//

	else if(optionId[0]=="recordp"){
			var recordpSelectID="rateplan_"+divID+"_chargingCode";
			var recordpValidityID="rateplan_"+divID+"_validity";

			//alert(rbtpSelectID+" ########### "+rbtpValidityID);

			var chgCode=$("#"+recordpSelectID+" option:selected").val();
			var validity=$("#"+recordpValidityID).val();

			//alert("Validation CHG_CODE="+chgCode);
			//alert("Validation VALIDITY="+validity);
			
			if( chgCode==0 ){
				alert("No Charge code is selcted, Please Select Proper Code!");
				$("#"+recordpSelectID).focus();
					//document.getElementById(rbtpSelectID).focus();
				return false;
			}else if(!validity.match(numbers)){
				alert("Invalid Validty Value Only Numeric Allowed");
				$("#"+recordpValidityID).focus();
				//document.getElementById(rbtpValidityID).focus();
				return false;	
			}else{
				//alert("Add validation is cleared!!");
				return true;
			}			
	}
	else if(optionId[0]=="giftp"){
			var giftpSelectID="rateplan_"+divID+"_chargingCode";
			var giftpValidityID="rateplan_"+divID+"_validity";

			//alert(rbtpSelectID+" ########### "+rbtpValidityID);

			var chgCode=$("#"+giftpSelectID+" option:selected").val();
			var validity=$("#"+giftpValidityID).val();

			if( chgCode==0 ){
				alert("No Charge code is selcted, Please Select Proper Code!");
				$("#"+giftpSelectID).focus();
				return false;
			}else if(!validity.match(numbers)){
				alert("Invalid Validty Value Only Numeric Allowed");
				$("#"+giftpValidityID).focus();
				//document.getElementById(rbtpValidityID).focus();
				return false;	
			}else{
				//alert("Add validation is cleared!!");
				return true;
			}

	} /// **************** for subscription Renew *********************** 
	else if(optionId[0]=="subRenew"){
		
		var subRenewSelectID="rateplan_"+divID+"_chargingCode";
		var subRenewValidityID="rateplan_"+divID+"_validity";
		var stid="rateplan_"+divID+"_STID";
		var ftid="rateplan_"+divID+"_FTID";

		var chgCode=$("#"+subRenewSelectID+" option:selected").val();
		var validity=$("#"+subRenewValidityID).val();
		//alert("Validation CHG_CODE="+chgCode);
		//alert("Validation VALIDITY="+validity);
		
		var stidVal=$("#"+stid).val();
		var ftidVal=$("#"+ftid).val();
		
		if( chgCode==0 ){
			alert("No Charge code is selcted, Please Select Proper Code!");
			document.getElementById(subRenewSelectID).focus();
			return false;
		}else if(!validity.match(numbers)){
			alert("Invalid Validty Value Only Numeric Allowed");
			document.getElementById(subRenewValidityID).focus();
			return false;	
		}else if(stidVal==0){
			 alert(" Please select SUCCESS SMS Template ID!");
			 $("#"+stid).css("background-color","lightyellow");
			 $("#"+stid).focus();
			 return false;	 
		}else if(ftidVal==0){
			 alert(" Please select FAILURE SMS Template ID!");
			 $("#"+ftid).css("background-color","lightyellow");
			 $("#"+ftid).focus();
			 return false;	 
		}else{

			return true;
		}
  }else if(optionId[0]=="rbtpRenew"){
		var rbtpRenewSelectID="rateplan_"+divID+"_chargingCode";
		var rbtpRenewValidityID="rateplan_"+divID+"_validity";
		var stid="rateplan_"+divID+"_STID";
		var ftid="rateplan_"+divID+"_FTID";
	

		var chgCode=$("#"+rbtpRenewSelectID+" option:selected").val();
		var validity=$("#"+rbtpRenewValidityID).val();

				
		var stidVal=$("#"+stid).val();
		var ftidVal=$("#"+ftid).val();

		//alert("ID==> STID="+stid+", FTID="+ftid);
		//alert(" STID="+stidVal+", FTID="+ftidVal);
		
		if( chgCode==0 ){
			alert("No Charge code is selcted, Please Select Proper Code!");
			$("#"+rbtpRenewSelectID).focus();
				
			return false;
		}else if(!validity.match(numbers)){
			alert("Invalid Validty Value Only Numeric Allowed");
			$("#"+rbtpRenewValidityID).focus();
			return false;	
		}else if(stidVal==0){
			 alert(" Please select SUCCESS SMS Template ID!");
			 $("#"+stid).css("background-color","lightyellow");
			 $("#"+stid).focus();
			 return false;	 
		}else if(ftidVal==0){
			 alert(" Please select FAILURE SMS Template ID!");
			 $("#"+ftid).css("background-color","lightyellow");
			 $("#"+ftid).focus();
			 return false;	 
		}
		else{
			return true;
		}
	}
  // *************************** end ************************** -->
  // ******************** FOR RECORDING RENEW ********************** -->
	else if(optionId[0]=="recordRenew"){
		var recordRenewSelectID="rateplan_"+divID+"_chargingCode";
		var recordRenewValidityID="rateplan_"+divID+"_validity";
		var stid="rateplan_"+divID+"_STID";
		var ftid="rateplan_"+divID+"_FTID";
	

		var chgCode=$("#"+recordRenewSelectID+" option:selected").val();
		var validity=$("#"+recordRenewValidityID).val();

				
		var stidVal=$("#"+stid).val();
		var ftidVal=$("#"+ftid).val();
		if( chgCode==0 ){
			alert("No Charge code is selcted, Please Select Proper Code!");
			$("#"+recordRenewSelectID).focus();
				
			return false;
		}else if(!validity.match(numbers)){
			alert("Invalid Validty Value Only Numeric Allowed");
			$("#"+recordRenewValidityID).focus();
			return false;	
		}else if(stidVal==0){
			 alert(" Please select SUCCESS SMS Template ID!");
			 $("#"+stid).css("background-color","lightyellow");
			 $("#"+stid).focus();
			 return false;	 
		}else if(ftidVal==0){
			 alert(" Please select FAILURE SMS Template ID!");
			 $("#"+ftid).css("background-color","lightyellow");
			 $("#"+ftid).focus();
			 return false;	 
		}
		else{
			return true;
		}
	}// *************************** END ******************************* -->
	else{
		alert("No Match Found!!");
	}	
}

function deleteMe(divID){
	
	alert("in delete "+divID);
	var id_arr=divID.split("_");
		
	alert("id_arr[0] "+id_arr[0]);
	
	if(id_arr[0]=='sub'){
		//alert("DEL DIV ID ="+divID+", id_request="+id_arr);

		//alert("old sub_DIV_Array="+sub_DIV_Array);
		if(sub_DIV_Array.length<=0){
			sub_DIV_Array.splice(0,0,divID);
		}else{
			sub_DIV_Array.splice(sub_DIV_Array.length,0,divID);
		}
		//sub_DIV_Array.sort();
		//alert("new sub_DIV_Array="+sub_DIV_Array);
		$('#'+divID).remove();
		
	}else if(id_arr[0]=='rbtp'){
		
		//alert("DEL DIV ID ="+divID+", id_request="+id_arr);

		//alert("old DIV_Array="+rbtp_DIV_Array);
		if(rbtp_DIV_Array.length<=0){
			rbtp_DIV_Array.splice(0,0,divID);
		}else{
			rbtp_DIV_Array.splice(rbtp_DIV_Array.length,0,divID);
		}
		//rbtp_DIV_Array.sort();
		//alert("new DIV_Array="+rbtp_DIV_Array);
		$('#'+divID).remove();		
	}


else if(id_arr[0]=='rbtpRenew'){
		
		//alert("DEL DIV ID ="+divID+", id_request="+id_arr);

		//alert("old DIV_Array="+rbtpRenew_DIV_Array);
		if(rbtpRenew_DIV_Array.length<=0){
			rbtpRenew_DIV_Array.splice(0,0,divID);
		}else{
			rbtpRenew_DIV_Array.splice(rbtpRenew_DIV_Array.length,0,divID);
		}
		//rbtpRenew_DIV_Array.sort();
		//alert("new DIV_Array="+rbtpRenew_DIV_Array);
		$('#'+divID).remove();		
	}

else if(id_arr[0]=='recordp'){
		
		//alert("DEL DIV ID ="+divID+", id_request="+id_arr);

		//alert("old DIV_Array="+recordp_DIV_Array);
		if(recordp_DIV_Array.length<=0){
			recordp_DIV_Array.splice(0,0,divID);
		}else{
			recordp_DIV_Array.splice(recordp_DIV_Array.length,0,divID);
		}
		//recordp_DIV_Array.sort();
		//alert("new DIV_Array="+recordp_DIV_Array);
		$('#'+divID).remove();		
	}
else if(id_arr[0]=='recordRenew'){
	
		if(recordRenew_DIV_Array.length<=0){
		recordRenew_DIV_Array.splice(0,0,divID);
	}else{
		recordRenew_DIV_Array.splice(recordRenew_DIV_Array.length,0,divID);
	}
	//recordRenew_DIV_Array.sort();
	//alert("new DIV_Array="+rbtpRenew_DIV_Array);
	$('#'+divID).remove();		
}

	
else if(id_arr[0]=='giftp'){
	
	//alert("DEL DIV ID ="+divID+", id_request="+id_arr);

	//alert("old DIV_Array="+giftp_DIV_Array);
	if(giftp_DIV_Array.length<=0){
		giftp_DIV_Array.splice(0,0,divID);
	}else{
		giftp_DIV_Array.splice(giftp_DIV_Array.length,0,divID);
	}
	//giftp_DIV_Array.sort();
	//alert("new DIV_Array="+giftp_DIV_Array);
	$('#'+divID).remove();		
 }
 // ******************* FOR SUBSCRIPTION RENEW ********************* -->
 else if(id_arr[0]=='subRenew'){
	//alert("DEL DIV ID ="+divID+", id_request="+id_arr);

	//alert("old subRenew_DIV_Array="+subRenew_DIV_Array);
	if(subRenew_DIV_Array.length<=0){
		subRenew_DIV_Array.splice(0,0,divID);
	}else{
		subRenew_DIV_Array.splice(subRenew_DIV_Array.length,0,divID);
	}
	//subRenew_DIV_Array.sort();
	//alert("new subRe$("#rateplan_subPostPaidTemplateId").css("border-color:","lightyellow");new_DIV_Array="+subRenew_DIV_Array);
	$('#'+divID).remove();
	
 }// subRenew Ends Here
 
//************************FOR FREE RBT ********************//
	
 else if(id_arr[0]=='free'){
		//alert("DEL DIV ID ="+divID+", id_request="+id_arr);

		//alert("old subRenew_DIV_Array="+subRenew_DIV_Array);
		if(free_DIV_Array.length<=0){
			free_DIV_Array.splice(0,0,divID);
		}else{
			free_DIV_Array.splice(free_DIV_Array.length,0,divID);
		}
		//subRenew_DIV_Array.sort();
		//alert("new subRe$("#rateplan_subPostPaidTemplateId").css("border-color:","lightyellow");new_DIV_Array="+subRenew_DIV_Array);
		$('#'+divID).remove();
		
	 }
	
	
//**************************END  RBT ****************//	
	
	
}// ********************** END  deleteMe ****************************

 function validateOption(divID){
	 
	 
	var id_arr=divID.split("_");
	
	var inputID='rateplan_'+divID+'_chargingCode';
	
	   var chgCode=0;
	   var chgCode1=0;
	   var divID1="";
	   var inputID1="";
	   var codeOptions;

	   //chgCode=document.getElementById(inputID).options[document.getElementById(inputID).selectedIndex].value;
	   chgCode=$("#"+inputID).val();
	   
  	  if(id_arr[0]=="sub")
  	  {
  	  	
  	    //alert(" current sub_DIV_Array ="+sub_DIV_Array);
 	    for(var i=0;i<DIV_MAX_INDEX;i++)
 	 	    {
			divID1="sub_"+i;
			if(i==id_arr[1])
				{
				//alert("Self Div Index ["+divID1+"] ");
				continue;
			}  

			inputID1='rateplan_'+divID1+'_chargingCode';
			//codeOptions=document.getElementById(inputID1);
			codeOptions=$("#"+inputID1);
			if(codeOptions!=null)
				{
				//alert(" validating ID ="+inputID1);
				//chgCode1=codeOptions.options[document.getElementById(inputID1).selectedIndex].value;
                 chgCode1=codeOptions.val();
			 	if(chgCode==chgCode1)
				 {
					alert("Selected Charging Code= ["+chgCode+"-"+ $("#"+inputID+" option:selected").text()+"] is All-ready in use!");
				 	//document.getElementById(inputID).options[0].selected=true;
				 	 $("#"+inputID).val('0');
				 	break;
		     	}
		   }				  	    
  	  	 }
  	 } 
  	 else if(id_arr[0]=="subRenew")
     {
    	// ************* for subscription renew *********************
   	  	    for(var i=0;i<DIV_MAX_INDEX;i++)
  	  	    {
 			divID1="subRenew_"+i;
 			if(i==id_arr[1])
 	 			{
 			 continue;
 			    }  

 			inputID1='rateplan_'+divID1+'_chargingCode';
 			
 			codeOptions=$("#"+inputID1);
 			if(codeOptions!=null)
 	 			{
 				//alert(" validating ID ="+inputID1);
 				//chgCode1=codeOptions.options[document.getElementById(inputID1).selectedIndex].value;
                  chgCode1=codeOptions.val();
 			 	if(chgCode==chgCode1)
 	 			 	{
 					alert("Selected Charging Code=["+chgCode+"-"+ $("#"+inputID+" option:selected").text()+"] is All-ready in use!");
 				 	//document.getElementById(inputID).options[0].selected=true;
 				 	 $("#"+inputID).val('0');
 				 	break;
 		     	   }
 		     }				  	    
   	  	}
     }
     else if(id_arr[0]=="rbtp")
  	 {
 		//################### RBT Purchase validation 
 		
 		 for(var i=0;i<DIV_MAX_INDEX;i++)
  	  	 {
 			divID1="rbtp_"+i;
 			if(i==id_arr[1])
 	 			{
 				//alert("Self Div Index ["+divID1+"] ");
 				continue;
 			}  

 			inputID1='rateplan_'+divID1+'_chargingCode';
 			//codeOptions=document.getElementById(inputID1);
 			 codeOptions=$("#"+inputID1);
 			if(codeOptions!=null)
 	 			{
 				//alert(" validating ID ="+inputID1);
 				//chgCode1=codeOptions.options[document.getElementById(inputID1).selectedIndex].value;
 				chgCode1=codeOptions.val();
 			 	if(chgCode==chgCode1)
 	 			 	{
 					alert("Selected Charging Code=["+chgCode+"-"+ $("#"+inputID+" option:selected").text()+"] is All-ready in use!");
 				 	//document.getElementById(inputID).options[0].selected=true;
 				 	$("#"+inputID).val('0');
 				 	break;
 		     	}
 		   }				  	    
   	   }
  	  	
  	}
	else if(id_arr[0]=="rbtpRenew")
	{
 		// ************* For Rbt purchase Renewal ***************** 

		//alert(" current rbtp_DIV_Array ="+rbtp_DIV_Array);
	    for(var i=0;i<DIV_MAX_INDEX;i++)
	  	    {
			divID1="rbtpRenew_"+i;
			if(i==id_arr[1])
	 			{
				//alert("Self Div Index ["+divID1+"] ");
				continue;
			}  

			inputID1='rateplan_'+divID1+'_chargingCode';
			//codeOptions=document.getElementById(inputID1);
			 codeOptions=$("#"+inputID1);
			if(codeOptions!=null)
	 			{
				//alert(" validating ID ="+inputID1);
				//chgCode1=codeOptions.options[document.getElementById(inputID1).selectedIndex].value;
				chgCode1=codeOptions.val();
			 	if(chgCode==chgCode1)
	 			 	{
					alert("Selected Charging Code=["+chgCode+"-"+ $("#"+inputID+" option:selected").text()+"] is All-ready in use!");
				 	//document.getElementById(inputID).options[0].selected=true;
				 	$("#"+inputID).val('0');
				 	break;
		     	}
		   }				  	    
	   }
	  	
	}
 	else if(id_arr[0]=="recordp")
  	{$("#rateplan_subPostPaidTemplateId").css("border-color:","lightyellow");
 		//alert(" current recordp_DIV_Array ="+recordp_DIV_Array);
  	    for(var i=0;i<DIV_MAX_INDEX;i++){
 			divID1="recordp_"+i;
 			if(i==id_arr[1]){
 				//alert("Self Div Index ["+divID1+"] ");
 				continue;
 			}  

 			inputID1='rateplan_'+divID1+'_chargingCode';
 			//codeOptions=document.getElementById(inputID1);
 			codeOptions=$("#"+inputID1);
 			if(codeOptions!=null){
 				//alert(" validating ID ="+inputID1);
 				//chgCode1=codeOptions.options[document.getElementById(inputID1).selectedIndex].value;
 				chgCode1=codeOptions.val();
 			 	if(chgCode==chgCode1){
 					alert("Selected Charging Code=["+chgCode+"-"+ $("#"+inputID+" option:selected").text()+"] is All-ready in use!");
 				 	//document.getElementById(inputID).options[0].selected=true;
 				 	 $("#"+inputID).val('0');
 				 	break;Pl
 		     	}
 		   }				  	    
   	   }
  	  	
  	}
 	else if(id_arr[0]=="recordRenew")
	{
 		    for(var i=0;i<DIV_MAX_INDEX;i++)
	  	    {
			divID1="recordRenew_"+i;
			if(i==id_arr[1])
	 			{
				
				continue;
			}  

			inputID1='rateplan_'+divID1+'_chargingCode';
			//codeOptions=document.getElementById(inputID1);
			 codeOptions=$("#"+inputID1);
			if(codeOptions!=null)
	 			{
				
				chgCode1=codeOptions.val();
			 	if(chgCode==chgCode1)
	 			{
			 			alert("Selected Charging Code=["+chgCode+"-"+ $("#"+inputID+" option:selected").text()+"] is All-ready in use!");
				 		$("#"+inputID).val('0');
				 		break;
		     	}
		   }				  	    
	   }
	  	
	}
  	else if(id_arr[0]=="giftp"){

 		//alert(" current giftp_DIV_Array ="+giftp_DIV_Array);
  	    for(var i=0;i<DIV_MAX_INDEX;i++){
  	    	
 			divID1="giftp_"+i;
 			if(i==id_arr[1]){
 			continue;
 			}  

 			inputID1='rateplan_'+divID1+'_chargingCode';
 			//codeOptions=document.getElementById(inputID1);
 			codeOptions=$("#"+inputID1);
 			if(codeOptions!=null){
 				 //chgCode1=codeOptions.options[document.getElementById(inputID1).selectedIndex].value;
 				 chgCode1=codeOptions.val();
 			 	if(chgCode==chgCode1){
 					alert("Selected Charging Code=["+chgCode+"-"+ $("#"+inputID+" option:selected").text()+"] is All-ready in use!");
 				 	//document.getElementById(inputID).options[0].selected=true;
 				 	 $("#"+inputID).val('0');
 				 	break;
 		     	}
 		   }				  	    
   	   }
  	}
  	else if(id_arr[0]=="free"){

  		alert("free");
 		//alert(" current giftp_DIV_Array ="+free_DIV_Array);
  	    for(var i=0;i<DIV_MAX_INDEX;i++){
  	    	
 			divID1="free_"+i;
 			if(i==id_arr[1]){
 			continue;
 			}  

 			inputID1='rateplan_'+divID1+'_chargingCode';
 			//alert(inputId1);
 			//codeOptions=document.getElementById(inputID1);
 			codeOptions=$("#"+inputID1);
 			if(codeOptions!=null){
 				 //chgCode1=codeOptions.options[document.getElementById(inputID1).selectedIndex].value;
 				 chgCode1=codeOptions.val();
 			 	if(chgCode==chgCode1){
 					alert("Selected Charging Code=["+chgCode+"-"+ $("#"+inputID+" option:selected").text()+"] is All-ready in use!");
 				 	//document.getElementById(inputID).options[0].selected=true;
 				 	 $("#"+inputID).val('0');
 				 	break;
 		     	}
 		   }				  	    
   	   }
  	} 	else{
  	  	alert(" Error in Operation!!");
  	}
  }//######## END of validateOption() method