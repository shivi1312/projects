function validate()
{
		
	    var x= document.getElementById("sthour");
	     var start_time = x.selectedIndex;
	    var y= document.getElementById("edhour");
	     var  end_time = y.selectedIndex;


	     if (end_time <= start_time)
	     {
	      alert("End time(hrs.) should be greater than Start Time(hrs.)");
	       return false;
	     }

	    var date1=document.getElementById("start");
	    var st=date1;
        
	     var date = st.substring(0,2);
	     var month = st.substring(3,5);
	     var year = st.substring(6,10);
	     
	     if (document.forms.form1.date.checked==true)
	     {
	    	
	      var retDate = false;
	       retDate = verifydate(date,month,year);

	       if(retDate == false)
	       {
	           alert("The Date setting should be the current date or after the current date");
	         return false;
	       }
	     }
	     
	    if(document.forms.form1.mobile.checked==true)
	    {
	     var mobile = document.forms.form1.mob.value;
	      var retValValid=false;
	      if(mobile=="")
	      {
	       alert("You must enter a mobile no.");
	        return false;
	      }
	     retValValid = valid(mobile)
	      if(retValValid==false)
	       return false;
	    }
	    if(document.forms.form1.friend.checked==true)
	    {
	     if(document.forms.form1.frn.value=="")
	     {
	      alert("You do not have any friends to set Crbt.");
	       return false;
	     }
	    }
	    if(document.forms.form1.group.checked==true)
	    {
	     if(document.forms.form1.grp.value=="")
	     {
	      alert("You do not have any groups to set Crbt.");
	       return false;
	     }
	    }
	    if(document.forms.form1.timings.checked==true)
	    {
	     if(start_time >= end_time)
	     {
	      alert("End time(hrs.) should be greater than Start Time(hrs.) ");
	       return false;
	     }
	    }

	    if(document.forms.form1.days.checked==true)
	    {
	     var testday = document.forms.form1.day;
	      var count=0;
	      var isSelected = "false";
	      while(count<testday.length)
	      {
	       if(testday[count].checked==true)
	       {
	        isSelected = "true";
	         break;
	       }
	       else
	       {
	        isSelected = "false";
	       }
	       count=count + 1;
	      }
	     if(isSelected=="false")
	     {
	      alert("You must select minimum one day.");
	       return false;
	     }
	    }
	     return ConfirmChoice();
	   }
	 
	      function ConfirmChoice()
	      {
	       if(confirm("Do you really want to set the selected Crbt?"))
	       {
	        return true;
	       }
	       else
	       {
	        return false;
	       }
	      }

	     function DefaultSelectEnable()
	     {
	      setEnable();
	       document.forms.form1.sendsms.disabled=true;
	     }
	     function GroupSelectEnable()
	     {
	      setEnable();
	       document.forms.form1.sendsms.disabled=true;
	     }
	     function FriendSelectEnable()
	     {
	      setEnable();
	       document.forms.form1.sendsms.disabled=false;
	     }
	     function MobileSelectEnable()
	     {
	    	 setEnable();
	    	   document.forms.form1.sendsms.disabled=false;
	    	 }
	    	 function TimeSelect()
	    	 {
	    	  document.forms.form1.timings.checked=true;
	    	 }
	    	 function DaySelect()
	    	 {
	    	  document.forms.form1.days.checked=true;
	    	 }
	    	 function GroupSelect()
	    	 {
	    	  document.forms.form1.group.checked=true;
	    	   document.forms.form1.sendsms.disabled=true;
	    	   setEnable();
	    	 }
	    	 function FriendSelect()
	    	 {
	    	  document.forms.form1.friend.checked=true;
	    	   document.forms.form1.sendsms.disabled=false;
	    	   setEnable();
	    	 }
	    	 function MobileSelect()
	    	 {
	    	  document.forms.form1.mob.checked=true;
	    	   document.forms.form1.sendsms.disabled=false;
	    	   setEnable();
	    	 }
	    	 function DateSelect()
	    	 {
	    	   document.forms.form1.sendsms.disabled=true;
	    	  document.forms.form1.date.checked=true;
	    	 
	    	  // document.forms.form1.settime[0].checked=true
	    	   document.forms.form1.timings.disabled=true;
	    	   document.forms.form1.sthour.disabled=true;
	    	   //    document.forms.form1.select1[1].disabled=true
	    	   document.forms.form1.edhour.disabled=true;
	    	   //    document.forms.form1.select2[1].disabled=true
	    	   document.forms.form1.fullday.disabled=true;
	    	   document.forms.form1.fullday.checked=false;
	    	   document.forms.form1.days.disabled=true;
	    	   for( i=0;i<7;i++)
	    	   {
	    	    document.forms.form1.day[i].disabled=true;
	    	   }
	    	 }
	    	 function OccasionSelect()
	    	 {
	    	   document.forms.form1.sendsms.disabled=true;
	    	     document.forms.form1.occasion.checked=true;
	    	                 document.forms.form1.timings.disabled=true;
	    	                 document.forms.form1.sthour.disabled=true;
	    	                 //    document.forms.form1.select1[1].disabled=true
	    	                 document.forms.form1.edhour.disabled=true;
	    	                 //    document.forms.form1.select2[1].disabled=true
	    	                 document.forms.form1.fullday.disabled=true;
	    	                 document.forms.form1.fullday.checked=false;
	    	                 document.forms.form1.days.disabled=true;
	    	                 for( i=0;i<7;i++)
	    	                 {
	    	                     document.forms.form1.day[i].disabled=true;
	    	                 }
	    	 }

	    	 function setEnable()
	    	 {
	    	   
	    	   document.forms.form1.timings.disabled=false;
	    	   document.forms.form1.sthour.disabled=false;
	    	   //document.forms.form1.select1[1].disabled=false
	    	   document.forms.form1.edhour.disabled=false;
	    	   //document.forms.form1.select2[1].disabled=false
	    	   document.forms.form1.fullday.disabled=false;
	    	   document.forms.form1.fullday.checked=true;
	    	   document.forms.form1.days.disabled=false;
	    	   for( i=0;i<7;i++)
	    	   {
	    	    document.forms.form1.day[i].disabled=false;
	    	   }
	    	 }
	    	 
	    	 
	    	 
	  function onbodyload()
	  {
		  document.forms.form1.setdefault.checked=true;
		  document.forms.form1.fullday.checked=true;
		  document.forms.form1.allday.checked=true;
		  document.forms.form1.sendsms.disabled=true;
		  var ddl = document.getElementById('edhour');
		  var opts = ddl.options.length;
		  for (var i=0; i<opts; i++){
		      if (ddl.options[i].value == "01"){
		          ddl.options[i].selected = true;
		          break;
		      }
		  }
		  
		  
	  }
	    	 
	    	 
