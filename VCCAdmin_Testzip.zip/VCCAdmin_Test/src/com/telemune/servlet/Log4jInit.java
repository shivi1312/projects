package com.telemune.servlet;

//import java.io.IOException;

//import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;


import org.apache.log4j.xml.DOMConfigurator;


//import com.opensymphony.xwork2.util.logging.Logger;
//import com.telemune.crbt.common.LoginAction;

import com.telemune.vcc.common.TSSJavaUtil;

//import org.apache.log4j.Logger;
/**
 * Servlet implementation class log4jInit
 */

public class Log4jInit extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	 @Override
	public  void init() {
	//	 Logger logger= Logger.getLogger(Log4jInit.class);
		// logger.info("In Log4jInit Servlet");
		    String prefix =  getServletContext().getRealPath("/");
		    TSSJavaUtil.instance(prefix);
		    System.out.println("Prefix : "+prefix);
		    String file = getInitParameter("log4j-init-file");
		    // if the log4j-init-file is not set, then no point in trying
		    if(file != null) {
		        DOMConfigurator.configureAndWatch(prefix+file, 1000);
		        //PropertyConfigurator.configure(prefix+file);
		    }
		  }


}
