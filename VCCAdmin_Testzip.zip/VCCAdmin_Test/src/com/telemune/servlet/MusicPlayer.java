package com.telemune.servlet;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.PrintWriter;

import com.telemune.vcc.common.PlayRbt;

import org.apache.log4j.*;


public class MusicPlayer extends HttpServlet
{

	 private static Logger logger=Logger.getLogger(MusicPlayer.class);

     public MusicPlayer() {
             super();
     }

     @Override
	public void destroy() {
             super.destroy();
     }

     @Override
	public void doGet(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException
     {


             //long startTime=System.currentTimeMillis();
             PlayRbt p = new PlayRbt();
             int code  = Integer.parseInt(request.getParameter("rbtid"));
             logger.info("In doGet() of MusicPlayer with RbtCode ["+code+"] to Play");
             //System.out.println("rbtCode ["+code+"]");
             //rbtCode [152765]
             int i = p.getFilePath(code);
             System.out.println("i==  "+i);
             if(i==99)
             {
                     ServletOutputStream stream = null;
                     BufferedInputStream buf = null;
                     try {
                         stream = response.getOutputStream();
                         logger.info("Playing music file In Servlet with Path:"+p.getMusicPath());
                         //System.out.println("Playing music file Servlet:"+p.getMusicPath());
                         File mp3 = new File(p.getMusicPath());
                         //File mp3 = new File("/home/rashmi/songs/rbt123.wav");

                         response.setContentType("audio/x-wav");
                         logger.info("mp3 of Rbt exists :  "+mp3.exists());
                         response.setContentLength((int) mp3.length());
                         //System.out.println("length of file -- "+mp3.length());
                         FileInputStream input = new FileInputStream(mp3);
                         buf = new BufferedInputStream(input);
                         int readBytes = 0;
                         while ((readBytes = buf.read()) != -1)
                                 stream.write(readBytes);
                 }
                 catch (IOException ioe) {
                	 logger.error("Error in Servlet:"+ioe);
                	 ioe.printStackTrace();
                         throw new ServletException(ioe.getMessage());
                 } finally {
                         if (stream != null)
                                 stream.close();
                         if (buf != null)
                                 buf.close();
                 }
         }
         else
         {
                 PrintWriter out = response.getWriter();
                 out.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
                 out.println("<HTML>");
                 out.println("  <HEAD><TITLE>A Servlet</TITLE></HEAD>");
                 out.println("  <BODY>");
                 out.println("Unknown Error");
                 out.println("");
                 out.println("  </BODY>");
                 out.println("</HTML>");
                 out.flush();
                 out.close();
         }

	
     }
}
