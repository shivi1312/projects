package com.telemune.vcc.common;

import java.applet.Applet;
import java.applet.AudioClip;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Event;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.MediaTracker;
import java.net.URL;

public class AudioButton extends Applet
{
	AudioClip sound = null;
	Color bgColor = Color.lightGray;
	URL url;
	Image imgOffscreenNormal = null;
	Image imgOffscreenBtnPressed = null;
	Image imgButton = null;
	Graphics gcOffscreen = null;
	boolean mouseOnBtn = false;
	boolean btnPressed = false;
	int imageWidth;
	int imageHeight;
	Dimension appletSize;
	int appletWidth;
	
	int appletHeight;


 
	@Override
	public void stop()
	{
		if (this.sound != null) this.sound.stop();
	}
	public void play(String newUrl)
	{
		this.sound = getAudioClip(getCodeBase(),newUrl);
		if (this.sound != null) this.sound.play();
	}

	@Override
	public boolean mouseEnter(Event e, int x, int y)
	{
		this.mouseOnBtn = true;
		repaint();
		return true;
	}

	@Override
	public boolean mouseExit(Event e, int x, int y)
	{
		this.mouseOnBtn = false;
		repaint();
		return true;
	}

	@Override
	public void paint(Graphics g)
	{
		if ((this.mouseOnBtn) && (this.btnPressed))
		{
			g.drawImage(this.imgOffscreenBtnPressed, 0, 0, this);
		}
		else
		{
			g.drawImage(this.imgOffscreenNormal, 0, 0, this);
		}
	}

	@Override
	public boolean mouseUp(Event evt, int x, int y)
	{
		if ((this.btnPressed) && (this.mouseOnBtn))
		{
			this.btnPressed = false;
			repaint();
		}
		else
		{
			this.btnPressed = false;
			repaint();
		}
		return true;
	}

	@Override
	public String[][] getParameterInfo()
	{
		String[][] info = { { 
			"image", "String", "image file name" }, { 
				"audio", "String", "sound file name" }, { 
					"bgcolor", "Hexadecimal color", "background color" } };

		return info;
	}

	@Override
	public void update(Graphics g)
	{
		paint(g);
	}

	@Override
	public void start()
	{
		repaint();
	}

	@Override
	public String getAppletInfo()
	{
		return "AudioButton v1.0 by Mark Huckvale, University College London";
	}

	@Override
	public boolean mouseDown(Event e, int x, int y)
	{
		this.btnPressed = true;
		repaint();
		if (this.sound != null) this.sound.play();
		return true;
	}
       /* public void toggleImage()
        {
        if(play)
         
       

       }*/

	@Override
	public void init()
	{
		try
		{
			MediaTracker tracker = new MediaTracker(this);


			String param = getParameter("image");
			if (param != null) {
				this.imgButton = getImage(getCodeBase(), param);
				tracker.addImage(this.imgButton, 0);
			}
			try {
				tracker.waitForAll();
			} catch (InterruptedException e) {
			}




			param = getParameter("bkgray");
			int graylevel = 127;
			if (param != null)
				graylevel = Integer.valueOf(param).intValue();
			if ((graylevel >= 0) && (graylevel <= 255)) {
				this.bgColor = new Color(graylevel, graylevel, graylevel);
			}
			this.imageWidth = this.imgButton.getWidth(this);
			this.imageHeight = this.imgButton.getHeight(this);
			this.appletSize = size();
			this.appletWidth = this.appletSize.width;
			this.appletHeight = this.appletSize.height;

			this.imgOffscreenNormal = createImage(this.appletWidth, this.appletHeight);
			this.imgOffscreenBtnPressed = createImage(this.appletWidth, this.appletHeight);

			int x = 0; int y = 0;
			if (this.appletWidth > this.imageWidth)
				x = (this.appletWidth - this.imageWidth) / 2;
			if (this.appletHeight > this.imageHeight) {
				y = (this.appletHeight - this.imageHeight) / 2;
			}

			this.gcOffscreen = this.imgOffscreenNormal.getGraphics();
			this.gcOffscreen.drawImage(this.imgButton, x, y, this);
			this.gcOffscreen.setColor(this.bgColor);
			this.gcOffscreen
				.draw3DRect(2, 2, 
						this.appletWidth - 5, this.appletHeight - 5, true);
			this.gcOffscreen
				.draw3DRect(1, 1, 
						this.appletWidth - 3, this.appletHeight - 3, true);
			this.gcOffscreen
				.draw3DRect(0, 0, 
						this.appletWidth - 1, this.appletHeight - 1, true);
			this.gcOffscreen.dispose();

			this.gcOffscreen = this.imgOffscreenBtnPressed.getGraphics();
			this.gcOffscreen.drawImage(this.imgButton, x + 2, y + 2, this);
			this.gcOffscreen.setColor(this.bgColor);
			this.gcOffscreen
				.draw3DRect(2, 2, 
						this.appletWidth - 5, this.appletHeight - 5, false);
			this.gcOffscreen
				.draw3DRect(1, 1, 
						this.appletWidth - 3, this.appletHeight - 3, false);
			this.gcOffscreen
				.draw3DRect(0, 0, 
						this.appletWidth - 1, this.appletHeight - 1, false);
			this.gcOffscreen.dispose();

		//	String soundName = getParameter("audio");
	//		if (soundName == null) return;
	//		this.sound = getAudioClip(getCodeBase(), soundName);
			//this.sound.play();
			System.out.println("song playeeeeeeeeed");
		}
		catch (Exception e)
		{
			System.out.println(e.toString());
			e.printStackTrace();
		}
	}
}

