/*
 * This class is used for user authentication for the web interface for CRBT. 
 */

package com.telemune.vcc.common;

import java.sql.ResultSet;
import com.telemune.dbutilities.*;
import org.apache.log4j.*;

public class AuthAdmin
{
    private static Logger logger=Logger.getLogger(AuthAdmin.class);
	private	String userId = "";
	private	int  userType = -1;
	private	String password = "";
	private Connection con = null;
//	private static int num_tries=0;
	private int id =-1;

	//private Hashtable hashtable= null;
	private SessionHistory sessionHistory =  null;

	public void AuthAdmin()
	{
	}	

	public  SessionHistory getSessionHistory()
	{
		return sessionHistory;
	}

	public	void setUserId(String userId)
	{	
		this.userId = userId;
	}

	public	void setPassword(String password)
	{
		this.password = password;			
	}
//	public void setNumTries(int num_tries)
//	{
//		this.num_tries=num_tries;
//	}
	public String  getUserId()
	{
		return userId;
	}

	public String getPassword()
	{
		return password;
	}

//	public int getNumTries()
//	{
//		return num_tries;
//	}


public int authenticate(Connection con)
{
	logger.info("Inside authenticate() For Login With usrename  ["+userId+"] password ["+password+"]");
	int retVal=-1;
	int totalAttempts= 3; 
	
//	if(userId.equals("") || password.equals(""))
//	{
//		return retVal;
//	}
	
	
	 
	
	
	
	
	if(userId.equals("") || password.equals(""))
	{
		return retVal;
	}
	
	
	
	
	
	
	
	
	
	
	
	PreparedStatement pstmt=null;
	ResultSet results=null;
	try
	{
		String query = "select A.ROLE_ID,B.ROLE_NAME from ADMIN_USER A,ROLES B where binary USER_NAME = ? and binary PASSWORD = ? and A.ROLE_ID=B.ROLE_ID";
		pstmt = con.prepareStatement(query);
		logger.info("DB Query::"+query);
		pstmt.setString(1, userId.trim());
		pstmt.setString(2, password.trim());

		results = pstmt.executeQuery();

		
		if (results.next())
		{//check for passwd match
			logger.info("User and Password are found in ADMIN_USER so return 1 for login");
			int userType = results.getInt("ROLE_ID");

			sessionHistory = new SessionHistory();

			sessionHistory.setConnection(con);
			sessionHistory.getLinks(userType);
			sessionHistory.setUser(userId);
			sessionHistory.setRoleId(results.getInt("ROLE_ID"));
			sessionHistory.setRoleName(results.getString("ROLE_NAME"));
			
			retVal=1;

			
		}
		else//some other kind of error.
		{
			logger.info("user and password are not found in ADMINUSER so return -2");
			retVal=-2;
		}
		results.close();
		pstmt.close();

	}
	catch (Exception e)
	{
		logger.error("Exception occured in authenticate() so return 0:::::"+e);
		e.printStackTrace();
		retVal=0;
	}finally
	{
		try{
			
			if(pstmt!=null)pstmt.close();
			if(results!=null)results.close();
		}catch(Exception exe)
		{
			logger.error(exe);
			exe.printStackTrace();
		}
	}
	return retVal;
}//authenticate() ends


public int changePassword(String user, String oldPass, String newPass,int roleId)
{
		logger.info("Inside changePassword() to change password with username:"+user+",old Pwd: "+oldPass+", new Pwd:"+newPass+", with Roll Id:"+roleId);
		try 
		{
			con = TSSJavaUtil.instance().getconnection();

			//String query = "select USER_NAME from CRBT_ADMINUSER where USER_NAME = ? and PASSWORD = ?"; 
			String query = "select USER_NAME, ROLE_ID from ADMIN_USER where USER_NAME = ? and PASSWORD = ?"; 

			PreparedStatement pstmt = con.prepareStatement(query);

			pstmt.setString(1, user);
			pstmt.setString(2, oldPass);
			logger.info(query);

			ResultSet results = pstmt.executeQuery();

			if(results.next())
			{
				logger.info("Username and password found in database to change");
				int roleid = results.getInt("ROLE_ID");

				query = "update ADMIN_USER set PASSWORD = ? , FIRST_LOGIN=1 where USER_NAME = ?";
				pstmt = con.prepareStatement(query);

				pstmt.setString(1, newPass);
				pstmt.setString(2, user);	

				pstmt.executeUpdate();
				logger.info(query);
				pstmt.close();

				/* Update password change date to sysdate, to check password expiry during login */
				if( roleId!= 1) //if User is not in Admin Role
				{
					logger.info("user not in ADMIN role so insert/update in ADMINUSER_PASSWORD_CHECK for record only");
					int pwd_number=1;
					query ="select max(PASSWORD_NUM) AA from ADMINUSER_PASSWORD_CHECK where USER_NAME=?";
					pstmt = con.prepareStatement (query);
					pstmt.setString (1, user);
					ResultSet rs = pstmt.executeQuery ();
					logger.info(query);
					if(rs.next ())
					{
						pwd_number = rs.getInt("AA")+1;
					}
					logger.info("password number= "+pwd_number);
					rs.close ();
					pstmt.close ();

					query = "INSERT INTO ADMINUSER_PASSWORD_CHECK (USER_NAME, PASSWORD, ROLE_ID, LAST_UPDATE,PASSWORD_NUM) VALUES (?, ?, ?,now(), ?)";
					pstmt = con.prepareStatement (query);
					pstmt.setString (1, user);
					pstmt.setString (2, newPass);
					pstmt.setInt (3, roleid);
					pstmt.setInt (4, pwd_number);
					pstmt.executeUpdate ();
					logger.info(query);
					pstmt.close ();
				}
			}

			else
			{
				logger.info("Username and password are not found in database to change");
				pstmt.close();
				return 12;
			}
		}
		catch(Exception e)
		{
			logger.error("Error while Changing pwd in changePassword():"+e);
			e.printStackTrace();
			return -1;
		}
		finally
		{
			if(con!=null) TSSJavaUtil.instance().freeConnection(con);
		}
		return 1;
}//changePassword()
	
}//class ends

