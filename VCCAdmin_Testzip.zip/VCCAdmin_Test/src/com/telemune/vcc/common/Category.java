package com.telemune.vcc.common;

public class Category
{
	private int catId = -1;
	private String maskName = "";
	private String description = "";
	private String ivrFilePath = "";
	private String ivrFilePath1 = null;
	private String playable = "";
	private String showweb = "";
	private String showsms = "";
	// adding one variable advance cat Id (Rinku)
	private int catAdv=-1;
	private String imagePath="";
	private String bannerImagePath="";
	
	public String getBannerImagePath() {
		return bannerImagePath;
	}

	public void setBannerImagePath(String bannerImagePath) {
		this.bannerImagePath = bannerImagePath;
	}

	public String getImagePath() {
		return imagePath;
	}

	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}

	public int getCatAdv() {
		return catAdv;
	}

	public void setCatAdv(int catAdv) {
		this.catAdv = catAdv;
	}

	public Category()
	{
	}
	
	public Category(int cId)
	{
		this.catId = cId;
	}

	public Category(int cId, String mName)
	{
		this.catId = cId;
		this.maskName = mName;
	}

	public int getCatId() {
		return catId;
	}

	public void setCatId(int catId) {
		this.catId = catId;
	}

	public String getMaskName() {
		return maskName;
	}

	public void setMaskName(String maskName) {
		this.maskName = maskName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getIvrFilePath() {
		if(ivrFilePath.contains(","))
		{
			System.out.println("contains comma");
			String[] ivrFilePathArray=ivrFilePath.split(",");
			ivrFilePath=ivrFilePathArray[0];
			ivrFilePath1=ivrFilePathArray[1];
		}
		return ivrFilePath;
	}

	public void setIvrFilePath(String ivrFilePath) {
		this.ivrFilePath = ivrFilePath;
	}
	
	public String getIvrFilePath1() {
		return ivrFilePath1;
	}

	public String getPlayable() {
		return playable;
	}

	public void setPlayable(String playable) {
		this.playable = playable;
	}

	public String getShowweb() {
		return showweb;
	}

	public void setShowweb(String showweb) {
		this.showweb = showweb;
	}

	public String getShowsms() {
		return showsms;
	}

	public void setShowsms(String showsms) {
		this.showsms = showsms;
	}
	
	
	
	

	

	
}
