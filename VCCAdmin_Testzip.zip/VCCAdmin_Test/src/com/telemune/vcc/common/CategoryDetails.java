package com.telemune.vcc.common;

import java.util.*;

public class CategoryDetails
{
	private int catId;
	private String catMaskName;
	private Vector rbtDt;

	
	public int getCatId() {
		return catId;
	}

	public void setCatId(int catId) {
		this.catId = catId;
	}

	public String getCatMaskName() {
		return catMaskName;
	}

	public void setCatMaskName(String catMaskName) {
		this.catMaskName = catMaskName;
	}

	public CategoryDetails()
	{
		this.catId = -1;
		this.catMaskName = "0";
		this.rbtDt = null;
	}

	public CategoryDetails(int cId, String mName)
	{
		this.catId = cId;
		this.catMaskName = mName;
		this.rbtDt = new Vector();
	}

	public Vector getRbts()
	{
		return rbtDt;
	}
	
	public void addRbtDetails(Rbt rbt)
	{
		rbtDt.addElement(rbt);
	}
	
	public int getCategoryId()
	{
		return catId;
	}

	public String getCatMaskedName()
	{
		return catMaskName;
	}

	public int getRbtCount()
	{
		return(rbtDt.size());
	}
	
	public RbtDetails getRbtDetails(int index)
	{
		return((RbtDetails)rbtDt.elementAt(index));
	}
	public RbtDetails getRbtDetailsById(int Id)
	{
		int i=0;
		for(i = 0; i< rbtDt.size(); i++)
		{
			if(((RbtDetails)rbtDt.elementAt(i)).getRbtId() == Id	)
			{
				return((RbtDetails)rbtDt.elementAt(i));
		//		break;
			}
		}
		return((RbtDetails)rbtDt.elementAt(0));
	}
}
