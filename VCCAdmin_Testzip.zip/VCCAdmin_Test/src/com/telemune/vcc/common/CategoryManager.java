
package com.telemune.vcc.common;

import com.telemune.dbutilities.*;

import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.*;

import org.apache.log4j.*;
public class CategoryManager
{
    static Logger logger=Logger.getLogger(CategoryManager.class);
	private Connection con;

	
/*
	public void setConnectionPool(ConnectionPool conPool)
	{
		this.conPool = conPool;			
	}

	public ConnectionPool getConnectionPool()
	{
		return conPool;		
	}
*/
	public int modifyCategory(int catId, String mName, String desc, String ivrFile, String play, String web, String sms,String imagefile,boolean showasbanner,String imagefile1,Connection con)
	{
		logger.info("inside modifyCategory() imagepath"+imagefile+"showasbanner"+showasbanner+"] banner file path"+imagefile1);
		try
		{	
			String query = "select CAT_ID, MASKED_NAME from CRBT_CATEGORY_MASTER";
			PreparedStatement pstmt = con.prepareStatement(query);
			logger.info("Select Query = "+query);

			ResultSet rs = pstmt.executeQuery();

			while (rs.next())
			{
				if(rs.getInt(1) == catId) continue;
				if(rs.getString(2).equalsIgnoreCase(mName)) return CrbtErrorCodes.CATEGORY_ALREADY_EXISTS;
			}
			pstmt.close();


			query = "update CRBT_CATEGORY_MASTER set MASKED_NAME = ?, DESCRIPTION = ?, IVR_FILEPATH = ?, PLAYABLE = ?, SHOW_ON_WEB = ?, SHOW_IN_SMS = ?,IMAGE_PATH=? where CAT_ID = ?";
			pstmt = con.prepareStatement(query);

			pstmt.setString(1, mName.trim());
			pstmt.setString(2, desc.trim());
			pstmt.setString(3, ivrFile.trim());
			pstmt.setString(4, play.trim());
			pstmt.setString(5, web.trim());
			pstmt.setString(6, sms.trim());
			pstmt.setString(7, imagefile.trim());
			pstmt.setInt(8, catId);

			int resp=pstmt.executeUpdate();
			pstmt.close();
			logger.info("Update query = "+query+"query executed with response ["+resp+"]");
			if(showasbanner && resp>0)
			{
				query="update crbtuser_category_detail set IMAGE_PATH=?, SCOPE=? where CAT_ID = ?";
				pstmt = con.prepareStatement(query);

				pstmt.setString(1, imagefile1.trim());
				pstmt.setString(2, "S");
				pstmt.setInt(3, catId);

				int res=pstmt.executeUpdate();
				pstmt.close();
				logger.info("Update query = "+query+"query executed with response ["+res+"]");
				
			}
			
			return CrbtErrorCodes.SUCCESS;
		}
		catch (Exception exp)
		{
			logger.error("Error in modifyCategory():"+exp);
			exp.printStackTrace();	
			return CrbtErrorCodes.FAILURE;
		}
		
	}//modifyCategory() ends
	
	
	// this function is for getting the list of categories 	
		
	public int getCategoryListForAddComercial(ArrayList catList,Connection con)
	{
		logger.info("In getCategoryListForAddComercial().....");
		 catList.clear();
	     PreparedStatement pstmt=null;
	     ResultSet rs= null;
	     String query="";
	     boolean showRecorded=false;
	     Category cat=null;
	     int retval=1;
	   
	     try{
	    	 String specialCatId   = TSSJavaUtil.instance().getAppConfigParam("SPECIAL_CONTROL_CATID");
	    	 String recordedCatId  =  TSSJavaUtil.instance().getAppConfigParam("CRBT_RECORDED_CATEGORY_ID");
	    	 String advCatId  =  TSSJavaUtil.instance().getAppConfigParam("ADVERTISEMENT_CAT_ID");
	    	 
	    	 //logger.info("specialCatId "+specialCatId+"recordedCatId "+recordedCatId+"advCatId "+advCatId);

	    	 query = "select CM.CAT_ID, MASKED_NAME from CRBT_CATEGORY_MASTER CM, CRBT_CATEGORY_ORDERING CO where CM.CAT_ID=CO.CAT_ID and CM.PLAYABLE='Y' " +
	    	 		"and SHOW_ON_WEB = 'Y' and not (CM.CAT_ID=?) and not (CM.CAT_ID=?) and not (CM.CAT_ID=?) order by CO.POSITION";
	     pstmt = con.prepareStatement(query);
	     logger.info("Select Query ||"+query);
	     pstmt.setString(1,specialCatId);
	     pstmt.setString(2,recordedCatId);
	     pstmt.setString(3,advCatId);
	     rs = pstmt.executeQuery();
	     	while(rs.next())
	     		{
	     		//logger.info("Catid: "+rs.getString("CAT_ID")+", Category Name:"+rs.getString("MASKED_NAME"));
	     		cat= new Category(rs.getInt("CAT_ID"),rs.getString("MASKED_NAME"));
	     		catList.add(cat);
	     		}
	     	rs.close();
	     	pstmt.close();
	     }catch(SQLException exe){
	      logger.error("Sql exception in getCategoryListForAddComercial():"+exe);
	      retval=-1;
	        }
	     catch(Exception exe){
		      logger.error("Exception in getCategoryListForAddComercial():"+exe);
		      retval=-1;
		        }
	     finally
	        {
	          try{
	             if(rs!=null)rs.close();
	             if(pstmt!=null)pstmt.close();
	             }catch(SQLException sqlexe)
	             {
	            	 sqlexe.printStackTrace();
	                 logger.error("sql exception getCategoryListForAddComercial" , sqlexe);
	             }
	       }
		return retval;
	}//getCategoryListForAddComercial() ends


	// this function is gettin the list of rbt for particular cat_id
	public int getRbtForComManage(int catId,ArrayList rbtList,Connection con)
	{
		logger.info("In getRbtForComManage() with catId [ "+catId+" ].");
		PreparedStatement pstmt= null;
		ResultSet rs= null;
		int retVal=-1;
		rbtList.clear();
		try{
			String query="select  rb.rbt_code as RBT_CODE,rb.ARTIST_NAME,rb.MASKED_NAME as RBT_NAME,cm.MASKED_NAME from crbt_rbt rb,crbt_category_master cm where rb.CAT_ID=cm.CAT_ID and cm.CAT_ID="+catId+" and rb.playable='Y' and rb.show_on_web='Y' and rb.rbt_code in(select rbt.rbt_code from crbt_category_master cms ,crbt_commercial_subscriber rbt,crbt_rbt n where n.rbt_code=rbt.rbt_code and cms.cat_id="+catId+" and cms.cat_id=n.cat_id) ";
			logger.info("Select QUERY :::"+query);
			pstmt=con.prepareStatement(query);
			rs=pstmt.executeQuery();
			while (rs.next()) {
				//RbtDetails details= new RbtDetails(rs.getInt("RBT_CODE"), rs.getString("RBT_NAME"));
				RbtDetails details= new RbtDetails(rs.getString("ARTIST_NAME"),rs.getInt("RBT_CODE"),rs.getString("RBT_NAME"));
				rbtList.add(details);
				}
			rs.close();
			pstmt.close();
			retVal=1;
		}catch(Exception exe)
		{
			logger.error("Exception in getRbtForComManage():"+exe);
			
		}finally
		{
			try{
			if(pstmt!=null)pstmt.close();
			if(rs!=null)rs.close();
			}catch(Exception ex){}
		}
		
	return retVal;	
		
	}// getrbtForComManage()..

	
public int searchRbtTonescom(String rbtName, int pageno, ArrayList rbtList,Connection con) 
	{
	logger.info("Inside searchRbtTonescom() where rbtname [ "+rbtName+" ] and pageno [ "+pageno+" ]");

		int srow = pageno*10;
		int erow = srow+11;
		//Connection con = null;
		PreparedStatement pstmt=null;
		ResultSet rs = null;
		String query = null;
		String specialCatId ="998";
		String recordedCatId="999";
		int ret = -1;
		try 
		{
			//con = conPool.getConnection();
			if(con == null) {
				logger.info("Connection is NULL");
				return -99;
			}
			specialCatId   = TSSJavaUtil.instance().getAppConfigParam("SPECIAL_CONTROL_CATID");
			recordedCatId  = TSSJavaUtil.instance().getAppConfigParam("CRBT_RECORDED_CATEGORY_ID");
			String advCatId  = TSSJavaUtil.instance().getAppConfigParam("ADVERTISEMENT_CAT_ID");

			query = "select * from (select * from (select RBT_CODE,RB.ARTIST_NAME,RB.MASKED_NAME RBT, RB.CAT_ID, CM.MASKED_NAME CAT, ROWNUM ROW_NUMBER from  CRBT_RBT RB, CRBT_CATEGORY_MASTER CM where RB.CAT_ID=CM.CAT_ID and UPPER(RB.MASKED_NAME) like ? and RB.SHOW_ON_WEB = 'Y' and RBT_CODE not in (select RBT_CODE from CRBT_RBT_CONTROL) and not(RB.CAT_ID = ?) and not(RB.CAT_ID = ?) and not(RB.CAT_ID = ?) order by RB.MASKED_NAME desc) where ROWNUM < ?) where ROW_NUMBER > ?"; 
			pstmt = con.prepareStatement(query);
			
			logger.info("Select Query:"+query);
			
			pstmt.setString(1,"%"+rbtName+"%");
			pstmt.setString(2, recordedCatId);
			pstmt.setString(3, specialCatId);
			pstmt.setString(4, advCatId);
			pstmt.setInt(5,erow);
			pstmt.setInt(6,srow);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				RbtDetails rbt = new RbtDetails(rs.getInt("RBT_CODE"),rs.getString("RBT"),rs.getInt("CAT_ID"),rs.getString("CAT"));				
				rbt.setArtistName(rs.getString("ARTIST_NAME"));
				rbtList.add(rbt);
			}			

			query = "select count(RBT_CODE) TOTAL from CRBT_RBT where UPPER(MASKED_NAME) like ? and SHOW_ON_WEB = 'Y' and RBT_CODE not in(select RBT_CODE from CRBT_RBT_CONTROL) and not(CAT_ID=?) and not(CAT_ID=?)";
			pstmt = con.prepareStatement(query);			
			logger.info("Select Query:"+query);
			
			pstmt.setString(1,"%"+rbtName+"%");
			pstmt.setString(2, recordedCatId);
			pstmt.setString(3, specialCatId);
			rs = pstmt.executeQuery();
			
			if (rs.next())
				ret = rs.getInt("TOTAL");

			if(rs != null) rs.close();
			if(pstmt != null) pstmt.close();
			return ret;
		}
		catch (SQLException e){
			logger.error("Error In searchRbtTones of CategoryManager, SQLException :"+e);
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
			} catch(Exception exp) {}
			e.printStackTrace();
			return -99;
		}
		catch (Exception e) {
			logger.error("Error In searchRbtTones of CategoryManager:"+e);
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
			} catch(Exception exp) {}                
			e.printStackTrace();
			return -99;
		}
		/*finally {
			conPool.free(con);
		}*/
	}//searchRbtTones()



public int searchRbtTonesView(String rbtName, int pageno, ArrayList rbtList,Connection con)
{
	logger.info("In searchRbtTonesView() where  RBTNAME [  "+rbtName+"  ]  AND PAGE NO [ "+pageno+" ]");
	int srow = pageno*10;
	int erow = srow+11;
	//Connection con = null;
	PreparedStatement pstmt=null;
	ResultSet rs = null;
	String query = null;
	String specialCatId ="998";
	String recordedCatId="999";
	int ret = -1;
			//logger.info("Viewing");
	try 
	{
		//con = conPool.getConnection();
		if(con == null) {
			logger.info("Connection is NULL");
			return -99;
		}
		specialCatId   = TSSJavaUtil.instance().getAppConfigParam("SPECIAL_CONTROL_CATID");
		recordedCatId  = TSSJavaUtil.instance().getAppConfigParam("CRBT_RECORDED_CATEGORY_ID");

		query = "select * from (select * from (select RBT_CODE,RB.ARTIST_NAME,RB.MASKED_NAME RBT, RB.CAT_ID, CM.MASKED_NAME CAT, ROWNUM ROW_NUMBER from  CRBT_RBT RB, CRBT_CATEGORY_MASTER CM where RB.CAT_ID=CM.CAT_ID and UPPER(RB.MASKED_NAME) like ? and RB.SHOW_ON_WEB = 'Y' and RBT_CODE not in (select RBT_CODE from CRBT_RBT_CONTROL) and not(RB.CAT_ID = ?) and not(RB.CAT_ID = ?) and RB.RBT_CODE IN (SELECT DISTINCT CRB.RBT_CODE FROM CRBT_COMMERCIAL_SUBSCRIBER CRB) order by RB.MASKED_NAME desc) where ROWNUM < ?) where ROW_NUMBER > ?"; 
		logger.info("Select Query = "+query);
		pstmt = con.prepareStatement(query);
		pstmt.setString(1,"%"+rbtName+"%");
		pstmt.setString(2, recordedCatId);
		pstmt.setString(3, specialCatId);
		pstmt.setInt(4,erow);
		pstmt.setInt(5,srow);
		rs = pstmt.executeQuery();
		while(rs.next()) {
			RbtDetails rbt = new RbtDetails(rs.getInt("RBT_CODE"),rs.getString("RBT"),rs.getInt("CAT_ID"),rs.getString("CAT"));
			rbt.setArtistName(rs.getString("ARTIST_NAME"));
			rbtList.add(rbt);
		}
		
		query = "select count(RBT_CODE) TOTAL from CRBT_RBT where UPPER(MASKED_NAME) like ? and SHOW_ON_WEB = 'Y' and RBT_CODE not in(select RBT_CODE from CRBT_RBT_CONTROL) and not(CAT_ID=?) and not(CAT_ID=?) and RBT_CODE IN (SELECT DISTINCT RBT_CODE FROM CRBT_COMMERCIAL_SUBSCRIBER CRB)";
		logger.info("Select Query = "+query);
		pstmt = con.prepareStatement(query);
		pstmt.setString(1,"%"+rbtName+"%");
		pstmt.setString(2, recordedCatId);
		pstmt.setString(3, specialCatId);
		rs = pstmt.executeQuery();
		
		if (rs.next())
			ret = rs.getInt("TOTAL");

		if(rs != null) rs.close();
		if(pstmt != null) pstmt.close();
		return ret;
	}
	catch (SQLException e) {
		logger.error("Error In searchRbtTonesView() of CategoryManager, SQLException :"+e);
		try {
			if(rs != null) rs.close();
			if(pstmt != null) pstmt.close();
		} catch(Exception exp) {}
		e.printStackTrace();
		return -99;
	}
	catch (Exception e) {
		logger.error("Error In searchRbtTonesView() of CategoryManager:"+e);
		try {
			if(rs != null) rs.close();
			if(pstmt != null) pstmt.close();
		} catch(Exception exp) {}                
		e.printStackTrace();
		return -99;
	}
	/*finally {
		conPool.free(con);
	}*/
}//searchRbtTonesView() ends

	
	public int getCategoryForComManage(ArrayList catList ,Connection con)
	{
		logger.info("In getCategoryForComManage()....");
		 try
	     {
	             PreparedStatement pstmt = null;
	             ResultSet rset = null;

	             if(con == null)
	             {
	                     return 0;
	             }

	             String query1 = "SELECT DISTINCT RBT_CODE FROM CRBT_COMMERCIAL_SUBSCRIBER";
	             logger.info("Select Query = "+query1);
	             pstmt = con.prepareStatement(query1);
	             rset = pstmt.executeQuery();
	             
	             if(!rset.next())
	             {
	             pstmt.close();
	             rset.close();
	             logger.info("Not Data found in crbt_commercial_subscriber table ");
	             return 0;
	             }

	             int specialCatId   = Integer.parseInt(TSSJavaUtil.instance().getAppConfigParam("SPECIAL_CONTROL_CATID"));
	             int recordedCatId  = Integer.parseInt(TSSJavaUtil.instance().getAppConfigParam("CRBT_RECORDED_CATEGORY_ID"));
	             String query = "select CM.CAT_ID, CM.MASKED_NAME, RB.RBT_CODE,RB.MASKED_NAME from CRBT_CATEGORY_MASTER CM, CRBT_RBT RB, CRBT_CATEGORY_ORDERING CO where CM.CAT_ID = RB.CAT_ID and CM.CAT_ID = CO.CAT_ID and CM.SHOW_ON_WEB ='Y' and RB.SHOW_ON_WEB = 'Y' and not (CM.CAT_ID = ?) and not (CM.CAT_ID = ?) and RB.RBT_CODE IN (SELECT DISTINCT RBT_CODE FROM CRBT_COMMERCIAL_SUBSCRIBER) order by CO.POSITION, RB.RBT_SCORE desc, RB.MASKED_NAME";
	             
	             logger.info("Select Query:::"+query+" where specialCatId ["+specialCatId+"] and recordedCatId ["+recordedCatId+"]");
	             pstmt = con.prepareStatement(query);
	             pstmt.setInt(1,specialCatId);
	             pstmt.setInt(2,recordedCatId);
	             rset = pstmt.executeQuery();
	             if(rset == null)
	             {
	                     return 0;
	             }
	             catList.clear();
	             int Id = -1;
	             boolean putMap = false;
	             CategoryDetails cat = new CategoryDetails();
	             while(rset.next())
	             {
	                     if (Id != rset.getInt(1))
	                     {
	                             if(putMap)
	                             {
	                            	 catList.add(cat);
	                             }
	                             cat = new CategoryDetails(rset.getInt(1),rset.getString(2));
	                             Id = rset.getInt(1);
	                             putMap = true;
	                     }
	             }
	             catList.add(cat);
//	           categoryMap.put(new Integer(cat.getCategoryId()), cat);
	             if(rset != null) rset.close();
	             pstmt.close();
	             
	             return 1;
	     }
	     catch (Exception e)
	     {
	    	 logger.error("Exception in getCategoryForComManage():"+e);
	             e.printStackTrace();
	             return 0;
	     }
}// getCategoryForComManage()....
	
	
       public int searchCode( ArrayList chgcode,Connection con)
        {
		logger.info("In searchcode() to search charging-codes");
                PreparedStatement pstmt=null;
                ResultSet rs = null;
                try
                {
                       // con = conPool.getConnection();
                        String query = "select CHARGING_CODE,DESCRIPTION from CRBT_CHARGING_CODE ";
                        logger.info("Select Query = "+query);
                        pstmt = con.prepareStatement(query);
                        rs = pstmt.executeQuery();
                        while(rs.next())
                        {
                                Category cat = new Category(rs.getInt("CHARGING_CODE"),rs.getString("DESCRIPTION"));
                                chgcode.add(cat);
                        }

                        if(rs != null) rs.close();
                        if(pstmt != null) pstmt.close();
                        return 1;
                }
                catch (Exception e)
                {
                	logger.error("Exception in searchCode()",e);
                    e.printStackTrace();
                        try {
                                if(rs != null) rs.close();
                                if(pstmt != null) pstmt.close();
                        } catch(Exception exp) {}                        
                        
                        return -99;
                }
        }//searchCode() ends
	

	public int addNewCategory(String mName, String desc, String ivrPath, String play, String web, String sms,String imagefile,boolean showAsBanner,String imageFile1,Connection con)

	{
		logger.info("In addNewCategory() image file ["+imagefile+"] show on banner ["+showAsBanner+"]");
		try
		{	
			//con = conPool.getConnection();
			con.setAutoCommit(false);
			boolean toExit=false;
			String validChars = "abcdefghijklmnopqrstuvwxyz1234567890 ";
			mName=mName.toLowerCase(); // make sure case is correct
			for (int i=0;i<mName.length();i++)
			{
				char c = mName.charAt(i);
				if (validChars.indexOf(c)== -1)
				{
					logger.info(mName+ " has Invalid character["+c+"] at position "+i+"\n");
					toExit=true;
				}
			}
			if(toExit)
			{
				logger.info("Exiting  addNewCategory() returns -25");
				return -25;
			}
			String query = "select MASKED_NAME from CRBT_CATEGORY_MASTER";
			logger.info("Select Query = "+query);
			PreparedStatement pstmt = con.prepareStatement(query);
			ResultSet rs = pstmt.executeQuery();
			
			while (rs.next())
			{
				if(rs.getString(1).equalsIgnoreCase(mName)) return CrbtErrorCodes.CATEGORY_ALREADY_EXISTS;
			}
			rs.close();
			pstmt.close();

			int catId = 0;
			query = "select CRBT_CAT_ID.NEXTVAL from dual";
			logger.info("Select Query:"+query);
			pstmt = con.prepareStatement(query);
			rs = pstmt.executeQuery();		
			if (rs.next())
			{
				catId = rs.getInt("NEXTVAL");
				logger.info("New catId from CRBT_CAT_ID seq is:"+catId);
			}
			else
			{
				logger.info("\n\nNew catId not found from CRBT_CAT_ID seq so check it, returns failure\n\n");
				return CrbtErrorCodes.FAILURE;
			}
			rs.close();
			pstmt.close();


			query = "insert into CRBT_CATEGORY_MASTER (CAT_ID, MASKED_NAME, DESCRIPTION, IVR_FILEPATH, PLAYABLE, SHOW_IN_SMS, SHOW_ON_WEB,IMAGE_PATH) values (?, ?, ?, ?, ?, ?, ?,?)";					
			logger.info("Insert Query = "+query);

			pstmt = con.prepareStatement(query);

			pstmt.setInt(1, catId);
			pstmt.setString(2, mName.toUpperCase().trim());
			pstmt.setString(3, desc.trim());
			pstmt.setString(4, ivrPath.trim());
			pstmt.setString(5, play.trim());
			pstmt.setString(6, web.trim());
			pstmt.setString(7, sms.trim());

			pstmt.setString(8, imagefile.trim());
			int exe=pstmt.executeUpdate();
			logger.info(query);
			pstmt.close();
			
               if(showAsBanner && exe>0)
               {
            	   query = "insert into CRBTUSER_CATEGORY_DETAIL (CAT_ID,IMAGE_PATH,SCOPE) values (?, ?, ?)";
       			pstmt = con.prepareStatement(query);
       			pstmt.setInt(1, catId);
       			pstmt.setString(2, imageFile1.trim());
       			pstmt.setString(3, "S");
       			
       			int ex=pstmt.executeUpdate();
       			logger.info("Response after executing query ["+ex+"] for query"+query);
       			pstmt.close();
            	   
               }	


		//	pstmt.executeUpdate();
			

			int position = 0;
			query = "select nvl(max(POSITION),0) from CRBT_CATEGORY_ORDERING";
			logger.info("Select Query = "+query);
			pstmt = con.prepareStatement(query);
			rs = pstmt.executeQuery();
			if (rs.next())
			{
				position = rs.getInt(1) +1;
			}
			else
			{	
				logger.info("No data found in CRBT_CATEGORY_ORDERING ");
				return CrbtErrorCodes.FAILURE;
			}
			rs.close();
			pstmt.close();

			query = "insert into CRBT_CATEGORY_ORDERING (CAT_ID, POSITION) values (?, ?)"; 
			logger.info("Insert Query = "+query);
			pstmt = con.prepareStatement(query);
			pstmt.setInt(1, catId);
			pstmt.setInt(2, position);
			pstmt.executeUpdate();			
			pstmt.close();

			int rbtId = 0;
			query = "select CRBT_RBT_CODE.NEXTVAL from dual";
			pstmt = con.prepareStatement(query);
			rs = pstmt.executeQuery();      
			logger.info("Select Query:"+query);
			if (rs.next())
			{
				rbtId = rs.getInt("NEXTVAL");
				logger.info("New RbtCode from CRBT_RBT_CODE SEQ is:"+rbtId);
			}
			else
			{
				logger.info("\n\n No value returned by table dual for new RbtCode so check CRBT_RBT_CODE sequence \n\n");
				return CrbtErrorCodes.FAILURE;
			}
			rs.close();
			pstmt.close();
			
			
			query = "insert into CRBT_RBT_CONTROL (CONTROL_ID, CONTROL_NAME, CAT_ID) values (?, ?, ?)";
			pstmt = con.prepareStatement(query);
			logger.info("Insert Query:"+query);

			pstmt.setInt(1, rbtId);
			pstmt.setString(2, "TOP");
			pstmt.setInt(3, catId);
			pstmt.executeUpdate();
			pstmt.close();

			rbtId = 0;
			query = "select CRBT_RBT_CODE.NEXTVAL from dual";
			pstmt = con.prepareStatement(query);
			logger.info("Select Query:"+query);
			rs = pstmt.executeQuery();      
			if (rs.next())
			{
				rbtId = rs.getInt("NEXTVAL");
			}
			else
			{
				logger.info("\n\n No value returned by table dual for new RbtCode so check CRBT_RBT_CODE sequence \n\n");
				return CrbtErrorCodes.FAILURE;
			}
			rs.close();
			pstmt.close();
			
			query = "insert into CRBT_RBT_CONTROL (CONTROL_ID, CONTROL_NAME, CAT_ID) values (?, ?, ?)";
			pstmt = con.prepareStatement(query);
			logger.info("Insert Query:"+query);
			pstmt.setInt(1, rbtId);
			pstmt.setString(2, "SEQ");
			pstmt.setInt(3, catId);
			pstmt.executeUpdate();
			pstmt.close();

			rbtId = 0;
			query = "select CRBT_RBT_CODE.NEXTVAL from dual";
			pstmt = con.prepareStatement(query);
			rs = pstmt.executeQuery();      
			logger.info("Selec Query:"+query);
			if (rs.next())
			{
				rbtId = rs.getInt("NEXTVAL");
			}
			else
			{
				return CrbtErrorCodes.FAILURE;
			}
			rs.close();
			pstmt.close();

			query = "insert into CRBT_RBT_CONTROL (CONTROL_ID, CONTROL_NAME, CAT_ID) values (?, ?, ?)";
			pstmt = con.prepareStatement(query);
			logger.info("Insert Query:"+query);
			pstmt.setInt(1, rbtId);
			pstmt.setString(2,"RANDOM");
			pstmt.setInt(3, catId);
			pstmt.executeUpdate();
			pstmt.close();
			con.commit();
			return CrbtErrorCodes.SUCCESS;
		}
		catch (java.sql.SQLException sql) {
			logger.error("SQL Error Occure while Inserting new Category in addNewCategory():"+sql);
			return CrbtErrorCodes.FAILURE;
		}
		catch (Exception exp)
		{
			logger.error("Error Occure while Inserting new Category in addNewCategory():"+exp);
			exp.printStackTrace();
			return CrbtErrorCodes.FAILURE;
		}
		
	}//addNewCategory()ends

	public int getCategoryDetails(Category cat,Connection con)
	{

		logger.info("Inside getCategoryDetails() to get info of catId:"+cat.getCatId());
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		String query="";
		
		try
		{	
			//con = conPool.getConnection();

			query = "select MASKED_NAME, DESCRIPTION, IVR_FILEPATH, PLAYABLE, SHOW_ON_WEB, SHOW_IN_SMS,IMAGE_PATH from CRBT_CATEGORY_MASTER where CAT_ID = ?";
			logger.info("Select Query = "+query);
			pstmt = con.prepareStatement(query);

			pstmt.setInt(1, cat.getCatId());
			rs = pstmt.executeQuery();

			if (rs.next())

			{
				logger.info("Category Detail Name"+rs.getString("MASKED_NAME")+"IMAGE_PATH"+rs.getString("IMAGE_PATH"));		

				cat.setMaskName(rs.getString("MASKED_NAME"));
				cat.setDescription(rs.getString("DESCRIPTION"));
				cat.setIvrFilePath(rs.getString("IVR_FILEPATH"));
				cat.setPlayable(rs.getString("PLAYABLE"));
				cat.setShowweb(rs.getString("SHOW_ON_WEB"));
				cat.setShowsms(rs.getString("SHOW_IN_SMS"));
				cat.setImagePath(rs.getString("IMAGE_PATH"));
			}
			else
			{				
				rs.close();
				pstmt.close();				
				logger.info("data not found in crbt_category_master for catId:"+cat.getCatId());
				return CrbtErrorCodes.FAILURE;
			}

			rs.close();
			pstmt.close();
			query = "select IMAGE_PATH  from CRBTUSER_CATEGORY_DETAIL where CAT_ID = ? and SCOPE='S'";
			
			 pstmt = con.prepareStatement(query);

			pstmt.setInt(1, cat.getCatId());

			rs = pstmt.executeQuery();
			logger.info(query);

			if (rs.next())
			{
		logger.info("Category Detail IMAGE_PATH"+rs.getString("IMAGE_PATH"));		
				
				cat.setBannerImagePath(rs.getString("IMAGE_PATH"));
			}
			else
			{
				logger.info("data not found in CRBTUSER_CATEGORY_DETAIL");
				cat.setBannerImagePath("NA");								
			}			
			rs.close();
			pstmt.close();	
			return CrbtErrorCodes.SUCCESS;
		}
		catch (Exception exp)
		{
			  logger.error("Exception in getCategoryDetails()",exp);
			exp.printStackTrace();
			return CrbtErrorCodes.FAILURE;
		}
	 /*	finally
		{
			conPool.free(con);
		}
		*/
	}//getCategoryDetails() ends

//	public int searchCategory (String catName, ArrayList catList ,Connection con) 
//	{		
//		PreparedStatement pstmt=null;
//		ResultSet rs = null;
//		try
//		{	
//			//con = conPool.getConnection();
//			int specialCatId=-1;
//			int recordedCatId =-1;
//			try{
//			specialCatId   =Integer.parseInt(TSSJavaUtil.instance().getAppConfigParam("SPECIAL_CONTROL_CATID"));
//			recordedCatId  = Integer.parseInt(TSSJavaUtil.instance().getAppConfigParam("CRBT_RECORDED_CATEGORY_ID"));
//			}
//			catch (Exception e) {
//				logger.error(""+e);
//			}
//			String query = "select CAT_ID, MASKED_NAME from CRBT_CATEGORY_MASTER where UPPER(MASKED_NAME) " +
//					"like ? and not (CAT_ID=?) and not (CAT_ID=?) order by CAT_ID";
//
//			pstmt = con.prepareStatement(query);
//			pstmt.setString(1,"%"+catName+"%");
//			pstmt.setInt(2,specialCatId);
//			pstmt.setInt(3,recordedCatId);
//			
//			rs = pstmt.executeQuery();
//			logger.info(query);
//			while(rs.next()) 
//			{
//				Category cat = new Category(rs.getInt("CAT_ID"),rs.getString("MASKED_NAME"));
//				catList.add(cat);
//			}
//
//			if(rs != null) rs.close();
//			if(pstmt != null) pstmt.close();
//			return 1;
//		}
//		catch (Exception e) 
//		{
//			try {
//				if(rs != null) rs.close();
//				if(pstmt != null) pstmt.close();
//			} catch(Exception exp) {}                
//			e.printStackTrace();
//			  logger.error("Exception in searchCategory()",e);
//			return -99;
//		}
//		finally {
//			//conPool.free(con);
//		}
//	}

	
	
	
	
	public int searchCategory (String catName, ArrayList catList ,Connection con) 
	{
		logger.info("In searchCategory() to search data of category name:"+catName);
		PreparedStatement pstmt=null;
		ResultSet rs = null;
		try
		{	int catIdParam=Integer.parseInt(TSSJavaUtil.instance().getAppConfigParam("ADVERTISEMENT_CAT_ID"));
		
			//con = conPool.getConnection();
			int specialCatId=-1;
			int recordedCatId =-1;
			int advcatIdenable =-1;
			
			specialCatId   =Integer.parseInt(TSSJavaUtil.instance().getAppConfigParam("SPECIAL_CONTROL_CATID"));
			recordedCatId  = Integer.parseInt(TSSJavaUtil.instance().getAppConfigParam("CRBT_RECORDED_CATEGORY_ID"));
			
			//advcatIdenable=TSSJavaUtil.instance().advcatidenable;	//have to look here
			advcatIdenable=Integer.parseInt(TSSJavaUtil.instance().getKeyValue("ADVERTISEMENT_CAT_ID_ENABLE"));//changed by vpsingh for above code-line			
			String query = "select a.CAT_ID as CAT_ID,a.MASKED_NAME as MASKED_NAME from crbt_category_master a,CRBT_CATEGORY_ORDERING b where a.MASKED_NAME like ? and a.CAT_ID!=? and a.CAT_ID!=? and a.CAT_ID=b.CAT_ID  order by b.POSITION";
			logger.info("Select Query = "+query);
			pstmt = con.prepareStatement(query);
			pstmt.setString(1,"%"+catName+"%");
			pstmt.setInt(2,specialCatId);
			pstmt.setInt(3,recordedCatId);			
			rs = pstmt.executeQuery();
			
			while(rs.next()) 
			{
				Category cat = new Category(rs.getInt("CAT_ID"),rs.getString("MASKED_NAME"));
				
				if(advcatIdenable==1)
				{
				catList.add(cat);
				}
				else
				{
					if(cat.getCatId()!=catIdParam)
					{
						catList.add(cat);
					}					
				}
			}

			if(rs != null) rs.close();
			if(pstmt != null) pstmt.close();
			return 1;
		}
		catch (Exception e) 
		{
			logger.error("Exception in searchCategory():"+e);
			e.printStackTrace();
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
			} catch(Exception exp){}
			return -99;
		}
		finally {
			//conPool.free(con);
		}
	}//searchCategory() ends

	
	public int deleteCategory(int catId,Connection con)
	{
		logger.info("In deleteCategory() with catId= "+catId);
		PreparedStatement pstmt=null;
		ResultSet rs = null;
		String query = "";
		int position = -1;
		try
		{	
			int rbtCode = Integer.parseInt(TSSJavaUtil.instance().getAppConfigParam("DEFAULT_RBT"));
			//con = conPool.getConnection();	
			con.setAutoCommit(false);			
			
			query = "update CRBT_SUBSCRIBER_MASTER set RBT_CODE = ? where RBT_CODE in (select RBT_CODE from CRBT_RBT where CAT_ID = ?)";
			logger.info("Update Query:"+query);
			pstmt = con.prepareStatement(query);
			pstmt.setInt(1, rbtCode);
			pstmt.setInt(2, catId);
			pstmt.executeUpdate();
			pstmt.close();

			query = "update CRBT_SUBSCRIBER_MASTER set RBT_CODE = ? where RBT_CODE in (select CONTROL_ID from CRBT_RBT_CONTROL where CAT_ID = ?)";
			logger.info("Update Query:"+query);
			pstmt = con.prepareStatement(query);
			pstmt.setInt(1, rbtCode);
			pstmt.setInt(2, catId);
			pstmt.executeUpdate();
				pstmt.close();

			query = "update CRBT_DEFAULT_DETAIL set RBT_CODE = ? where DAY='8' and START_AT='2500' and ENDS_AT='2500' and RBT_CODE in (select RBT_CODE from CRBT_RBT where CAT_ID = ?)";
			logger.info("Update Query:"+query);
			pstmt = con.prepareStatement(query);
			pstmt.setInt(1, rbtCode);
			pstmt.setInt(2, catId);
			pstmt.executeUpdate();
				pstmt.close();

			query = "update CRBT_GROUP_DETAIL set CONTROL_RBT_CODE = ? where CONTROL_RBT_CODE in (select CONTROL_ID from CRBT_RBT_CONTROL where CAT_ID = ?)";
			logger.info("Update Query:"+query);
			pstmt = con.prepareStatement(query);
			pstmt.setInt(1, rbtCode);
			pstmt.setInt(2, catId);
			pstmt.executeUpdate();
				pstmt.close();

			query = "update CRBT_FRIEND_DETAIL set CONTROL_RBT_CODE = ? where CONTROL_RBT_CODE in (select CONTROL_ID from CRBT_RBT_CONTROL where CAT_ID = ?)";
			logger.info("Update Query:"+query);
			pstmt = con.prepareStatement(query);
			pstmt.setInt(1, rbtCode);
			pstmt.setInt(2, catId);
			pstmt.executeUpdate();
				pstmt.close();

			query="delete from CRBT_FRIEND_SETTING where RBT_CODE in (select RBT_CODE from CRBT_RBT where CAT_ID=?)";	 
			logger.info("Delete Query:"+query);
			pstmt = con.prepareStatement(query);
			pstmt.setInt(1, catId);
			pstmt.executeUpdate();
				pstmt.close();

			query="delete from CRBT_GROUP_SETTING where RBT_CODE in (select RBT_CODE from CRBT_RBT where CAT_ID=?)";	 
			logger.info("Delete Query:"+query);
			pstmt = con.prepareStatement(query);
			pstmt.setInt(1, catId);
			pstmt.executeUpdate();
				pstmt.close();
			
			query = "select POSITION from CRBT_CATEGORY_ORDERING where CAT_ID = ?";
			logger.info("Select Query:"+query);
			pstmt = con.prepareStatement(query);
			pstmt.setLong(1, catId);
			rs = pstmt.executeQuery();
			if (rs.next())
			{
				position = rs.getInt("POSITION");
			}
			rs.close();	
			pstmt.close();

			query = "delete from CRBT_CATEGORY_ORDERING where CAT_ID = ?"; 
			logger.info("Delete Query:"+query);
			pstmt = con.prepareStatement(query);
			pstmt.setInt(1, catId);
			pstmt.executeUpdate();
				pstmt.close();

			query = "update CRBT_CATEGORY_ORDERING set POSITION = POSITION-1 where POSITION > ?";
			logger.info("Update Query:"+query);
			pstmt = con.prepareStatement(query);
			pstmt.setInt(1, position);
			pstmt.executeUpdate();
				pstmt.close();

			query = "delete from CRBT_RBT_CONTROL where CAT_ID = ?"; 
			logger.info("Delete Query:"+query);
			pstmt = con.prepareStatement(query);
			pstmt.setInt(1, catId);
			pstmt.executeUpdate();
				pstmt.close();

			/*query = "delete from CRBT_CATEGORY_MASTER cascade where CAT_ID = ?";
			logger.info(query);
			pstmt = con.prepareStatement(query);
			pstmt.setInt(1, catId);
			pstmt.executeUpdate();
			*/
				
				query="update CRBT_CATEGORY_MASTER set PLAYABLE='N',SHOW_IN_SMS='N',SHOW_ON_WEB='N' where CAT_ID=?";
				logger.info("Update Query:"+query);
				pstmt = con.prepareStatement(query);
				pstmt.setInt(1, catId);
				pstmt.executeUpdate();
				pstmt.close();
				con.commit();
				
			logger.info("All queries executed");
			return CrbtErrorCodes.SUCCESS;
		}
		catch (SQLException sqle)
		{
			logger.error("SQL Exception in deleteCategory():"+sqle);
			sqle.printStackTrace();
			try {
				con.rollback();
			} catch (Exception e1) {
				e1.printStackTrace();
				  logger.error("Exception in deleteCategory()",e1);
			}
			if (sqle.getErrorCode() == 2292)
			{
				return -7;
			}
			return CrbtErrorCodes.FAILURE;
		}
		catch (Exception ex)
		{
			  logger.error("Exception in deleteCategory()"+ex);
			ex.printStackTrace();
			return CrbtErrorCodes.FAILURE;
		}	
	}//deleteCategory()

	
	public int orderCategory(int[] order,Connection con)
	{
		logger.info("In orderCategory()");
		try
		{	
			//con = conPool.getConnection();
			con.setAutoCommit(false);

			String query = "delete from CRBT_CATEGORY_ORDERING";
			logger.info("Delete Query = "+query);
			PreparedStatement pstmt = con.prepareStatement(query);

			pstmt.executeUpdate();

			query = "insert into CRBT_CATEGORY_ORDERING (CAT_ID, POSITION) values (?,?)";	
			logger.info("Insert Query = "+query);
			pstmt = con.prepareStatement(query);

			for(int i =0; i<order.length; i++)
			{
				pstmt.setInt(1, order[i]);
				pstmt.setInt(2, i+1);
				pstmt.executeUpdate();
			}
			pstmt.close();
			con.commit();
/*			for(int i=0;i<order.length;i++)
			System.out.println("order["+i+"]"+order[i]);  */
			return CrbtErrorCodes.SUCCESS;
		}
		catch (Exception e)
		{
			logger.error("Exception in orderCategory()",e);
			e.printStackTrace();
			try {
				con.rollback();
			} catch (Exception exp) {
				exp.printStackTrace();
			} 	
			return CrbtErrorCodes.FAILURE;
		}		
	}//orderCategory() ends

	public int  getCategoryOrder(Vector order,Connection con)
	{
		logger.info("In getCategoryOrder()");
		try
		{	
			//con = conPool.getConnection();
			int specialCatId=-1;
			int recordedCatId =-1;		
			specialCatId   =Integer.parseInt(TSSJavaUtil.instance().getAppConfigParam("SPECIAL_CONTROL_CATID"));
			recordedCatId  = Integer.parseInt(TSSJavaUtil.instance().getAppConfigParam("CRBT_RECORDED_CATEGORY_ID"));
			
//			String query = "select CAT_ID from CRBT_CATEGORY_ORDERING order by POSITION";
			String query = "select co.CAT_ID from CRBT_CATEGORY_MASTER cm , CRBT_CATEGORY_ORDERING co where cm.cat_id!=? and cm.cat_id!=? and cm.cat_id=co.cat_id order by position";
			logger.info("Select Query = "+query);
			PreparedStatement pstmt = con.prepareStatement(query);
			pstmt.setInt(1,specialCatId);
			pstmt.setInt(2,recordedCatId);
			ResultSet rs = pstmt.executeQuery();

			while(rs.next()){
				order.add(new Integer(rs.getInt(1)));
			//logger.info(rs.getInt(1));
			}         
			pstmt.close();
		}
		catch (Exception e)
		{ 
			  logger.error("Exception in getCategoryOrder()",e);
			e.printStackTrace();
			return CrbtErrorCodes.FAILURE;
		}
		finally
		{
			//conPool.free(con);
		}
		return CrbtErrorCodes.SUCCESS;
	}//getCategoryOrder() ends
	
	/**
	 * Added by MoHit 5 March 2015 for COMMON
	 * @param msisdn
	 * @param catId
	 * @param pageno
	 * @param rbtList
	 * @param con
	 * @return
	 */
	public int viewAllTones(String msisdn, int catId, int pageno,ArrayList<RbtDetails> rbtList, Connection con) 
	{
		logger.info("In viewAllTones().....");
		int s_row = pageno * 10;
		int e_row = s_row + 11;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String query = null;
		int ret = -1;
		String recordedCatId ="-1";
		try 
		{
            if (con == null) return -99;                    
            
            recordedCatId = TSSJavaUtil.instance().getAppConfigParam("CRBT_RECORDED_CATEGORY_ID");

            if (Integer.parseInt(recordedCatId) == catId) 
            {
                    query = "select * from (select  MASKED_NAME, RBT_CODE,ARTIST_NAME, ROWNUM ROW_NUMBER from (select MASKED_NAME, RBT_CODE,ARTIST_NAME from CRBT_RBT where  RBT_CODE in (select RBT_CODE from CRBT_RBT_OWNER where MSISDN = ?) order by MASKED_NAME desc)  where ROWNUM < ?) where ROW_NUMBER > ?";
                    pstmt = con.prepareStatement(query);
                    pstmt.setString(1, msisdn);
            }
            else 
            {       
                    query = "select * from (select  MASKED_NAME, RBT_CODE,ARTIST_NAME, ROWNUM ROW_NUMBER from (select MASKED_NAME, RBT_CODE,ARTIST_NAME from CRBT_RBT where  CAT_ID = ? order by RBT_SCORE desc, RBT_CODE)  where ROWNUM < ?) where ROW_NUMBER > ?";
                    pstmt = con.prepareStatement(query);
                    pstmt.setInt(1, catId);
            }
            
            logger.info("Select Query:"+query+"cat  [" + catId + "] row 1 [" + e_row + "] row 2 ["+ s_row + "]");
            pstmt.setInt(2, e_row);
            pstmt.setInt(3, s_row);
            rs = pstmt.executeQuery();
            
            while (rs.next()) 
            {
                    //RbtDetails rbt = new RbtDetails(rs.getInt("RBT_CODE"),rs.getString("MASKED_NAME"));
            	RbtDetails rbt = new RbtDetails(rs.getString("ARTIST_NAME"),rs.getInt("RBT_CODE"),rs.getString("MASKED_NAME"));
                    //rbt.setArtName(rs.getString("ARTIST_NAME"));
                    rbtList.add(rbt);
            }

            if (Integer.parseInt(recordedCatId) == catId) 
            {
                    query = "select count(RBT_CODE) TOTAL from CRBT_RBT where RBT_CODE in (select RBT_CODE from CRBT_RBT_OWNER where MSISDN = ?)";
                    pstmt = con.prepareStatement(query);
                    pstmt.setString(1, msisdn);
            }
            else 
            {
                    query = "select count(RBT_CODE) TOTAL from CRBT_RBT where  CAT_ID = ?";
                    pstmt = con.prepareStatement(query);
                    pstmt.setInt(1, catId);
            }
            logger.info("Select Query:"+query);

            rs = pstmt.executeQuery();
            if (rs.next())
                    ret = rs.getInt("TOTAL");

            if (rs != null)
                    rs.close();
            if (pstmt != null)
                    pstmt.close();

            return ret;
		} 
		catch (SQLException e) 
		{
            logger.error("Error In viewAllTones() of CategoryManager, SQLException :"+e);
            e.printStackTrace();
            try 
            {
                    if (rs != null)
                            rs.close();
                    if (pstmt != null)
                            pstmt.close();
            }
            catch (Exception exp) 
            {
            }
            return -99;
		} 
		catch (Exception e) 
		{
			logger.error("Error In viewAllTones() of CategoryManager:"+e);
            try {
                    if (rs != null)
                            rs.close();
                    if (pstmt != null)
                            pstmt.close();
            } catch (Exception exp) {
            }
            e.printStackTrace();
            return -99;
		} 
		finally 
		{
			try{
			if (rs != null)
                rs.close();
			if (pstmt != null)
                pstmt.close();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
	}//viewAllTones() ends
	
	/**
	 * 
	 * @param catId
	 * @param rbtList
	 * @param con
	 * @return
	 */
	public int getRbtForCat(int catId,ArrayList<Rbt> rbtList,Connection con, int pageno)
	{
		int s_row = pageno * 10;
        int e_row = s_row + 11;
		logger.info("In getRbtForCat() to getRbts of catId ["+catId+"] s_row ["+s_row+"] e_row ["+e_row+"]");        
		PreparedStatement pstmt= null;
		ResultSet rs= null;
		int retVal=-1;
		rbtList.clear();
		try{
			String query="select * from (select * from (select  rb.rbt_code as RBT_CODE,rb.ARTIST_NAME,rb.MASKED_NAME as RBT_NAME, ROWNUM ROW_NUMBER from crbt_rbt rb,crbt_category_master cm where rb.CAT_ID=cm.CAT_ID and cm.CAT_ID=? and rb.playable='Y' and rb.show_on_web='Y') where rownum < ?) where ROW_NUMBER > ?";
			logger.info("Select QUERY:"+query);
			pstmt=con.prepareStatement(query);
			pstmt.setInt(1, catId);
			pstmt.setInt(2, e_row);
			pstmt.setInt(3, s_row);
			rs=pstmt.executeQuery();
			while (rs.next()) {
				Rbt rbt= new Rbt(rs.getInt("RBT_CODE"), rs.getString("RBT_NAME"));
				rbt.setArtName(rs.getString("ARTIST_NAME"));
				rbtList.add(rbt);
			}
			//logger.info("list size="+rbtList.size());
			rs.close();
			pstmt.close();
			
			String query1="select count(*) as TOTAL from crbt_rbt rb,crbt_category_master cm where rb.CAT_ID=cm.CAT_ID and cm.CAT_ID=? and rb.playable='Y' and rb.show_on_web='Y'";
			logger.info("Select QUERY :::"+query1);
			pstmt=con.prepareStatement(query1);
			pstmt.setInt(1, catId);
			rs=pstmt.executeQuery();
			if(rs.next())
			{
				retVal=rs.getInt("TOTAL");
			}
			//logger.info("total rbts in this category="+retVal);
			rs.close();
			pstmt.close();
		}catch(Exception exe)
		{
			retVal=-1;
			logger.error("Exception in getRbtForCat()... "+exe);
			
		}finally
		{
			try{
			if(pstmt!=null)pstmt.close();
			if(rs!=null)rs.close();
			}catch(Exception ex){}
		}		
	return retVal;
	}//getRbtForCat() ends

}//class ends




