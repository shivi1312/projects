package com.telemune.vcc.common;

public interface Global {
	public static int SAME_RBT_TYPE=0;
	public static int RBT_TYPE=1;
	public static int CAT_TYPE=2;
	public static int ALBUM_TYPE=3;
	public static int ARTIST_TYPE=4;	
	public static int DEFAULT_TYPE=99;

	public static int SAME_RBT_TEMPLATE_ID=0;
	public static int DEAFULT_TEMPLATE_ID=0;

}
