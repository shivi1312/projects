package com.telemune.vcc.common;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.telemune.dbutilities.Connection;
import com.telemune.dbutilities.PreparedStatement;
import com.telemune.vcc.model.HistoryDataBean;

public class HistoryGenerator {
	static Logger logger = Logger.getLogger(HistoryGenerator.class);
	private PreparedStatement pstmt = null;
	// private Connection con = null;
	private ResultSet rs = null;
	private String query = null;

	public String getRoleName(int roleId, Connection con) {
		String roleName = "";
		try {
			query = " SELECT ROLE_NAME from ROLES where ROLE_ID=?";
			pstmt = con.prepareStatement(query);
			pstmt.setInt(1, roleId);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				roleName = rs.getString(1);
			}

		} catch (Exception ex) {
			try {
				if (pstmt != null)
					pstmt.close();
			} catch (SQLException sqle) {
				logger.error("Exception in getting roleName, Exception is : "
						+ sqle.getMessage());
			}
			ex.printStackTrace();
		}
		return roleName;
	}

	public int insertHistoryData(HistoryDataBean historyDataBean, Connection con) {

		logger.info("in function inserthistoryData");
		try {
			// con = TSSJavaUtil.instance().getconnection();
			query = "INSERT INTO VCC_HISTORY_DATA (TIME,USER_NAME,ACTION,EVENT,ROLE,MSG) values(now(),?,?,?,?,?)";
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, historyDataBean.getUser());
			pstmt.setString(2, historyDataBean.getAction());
			pstmt.setString(3, historyDataBean.getEvent());
			pstmt.setString(4, historyDataBean.getRole());
			pstmt.setString(5, historyDataBean.getMsg());
			pstmt.executeUpdate();
			pstmt.close();
		} catch (Exception e) {
			try {
				if (pstmt != null)
					pstmt.close();
			} catch (SQLException sqle) {
				logger.error("Exception in inserting historyData, Exception is : "
						+ sqle.getMessage());
			}
			e.printStackTrace();
			return -1;
		} finally {
			try {
				if (con != null)
					TSSJavaUtil.instance().freeConnection(con);
			} catch (Exception e2) {
				logger.error("Error in closing connection ", e2);
			}
		}
		return 0;
	}

}
