package com.telemune.vcc.common;

import java.util.ArrayList;

import javax.servlet.ServletContext;

import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.util.ServletContextAware;

import com.telemune.dbutilities.Connection;
import com.telemune.vcc.model.HistoryDataBean;


public class LoginAction extends ValidateAction implements ServletContextAware{

	LoginBean bean=null;
	Logger logger= Logger.getLogger(LoginAction.class);
	private String message;
	private ArrayList<LanguageBean> languageBean = null;
	
	private ServletContext context;
	//int totalAttempts= 3; 
	
	
	static int attempt;
 

	// this function is just to load the valuestack 

	public LoginBean getBean() {
		return bean;
	}


	public void setBean(LoginBean bean) {
		this.bean = bean;
	}


	public ArrayList<LanguageBean> getLanguageBean() {
		return languageBean;
	}


	public void setLanguageBean(ArrayList<LanguageBean> languageBean) {
		this.languageBean = languageBean;
	}


	public String getMessage() {
		return message;
	}


	public void setMessage(String message) {
		this.message = message;
	}


	public String firstHit()
	{
		logger.info("Inside firsthit()......");
		return SUCCESS;
	}


	// this function is for authenticate()...............

	public String login() 
	{	
		logger.info("Inside login() of LoginAction.");		
		String retVal="error";
		String username="NA";
		String pass="NA";
		Connection con= null;
		HistoryDataBean historyDataBean =null;
		HistoryGenerator historyGenerator =null;
		try{
			username=bean.getUserName();//were out of try without default so was a bug,modified by vpsingh on 19-june
			pass=bean.getPassword();
			
			
			//String path = context.getRealPath("/");

			con=TSSJavaUtil.instance().getconnection();
			logger.info("Going To Login With username ["+username+"] password  ["+pass+"]");
			AuthAdmin authenticate= new AuthAdmin();
			authenticate.setUserId(username);
			authenticate.setPassword(pass);
			int res=authenticate.authenticate(con);
			//logger.info("Response From AuthAdmin.authenticate():["+res+"]");
			
			//ArrayList linkAl= new ArrayList();
			//linkAl.clear();
			String val="";
			int link=0;
			
		//	if(totalAttempts !=0)
		//	{
			if(res==1)//ie login okkk
			{
				SessionHistory sessionHistory= authenticate.getSessionHistory();				
				sessionMap.put("sessionHistory",sessionHistory);
				sessionMap.put("user",sessionHistory.getUser());
				sessionMap.put("pass",pass);
				sessionMap.put("roleId", sessionHistory.getRoleId());
				ServletContext context=ServletActionContext.getServletContext();
				int totMsisdnL=-1;
				int countryCode=-1;
				totMsisdnL=TSSJavaUtil.instance().getTotalMsisdnLength();
				countryCode=TSSJavaUtil.instance().getCountryCode();
				//context.setAttribute("msisdnLength",TSSJavaUtil.instance().getTotalMsisdnLength());
				//context.setAttribute("countryCode",TSSJavaUtil.instance().getCountryCode());				
				context.setAttribute("msisdnLength",totMsisdnL);
				context.setAttribute("countryCode",countryCode);
				logger.info("msisdnLength: ["+totMsisdnL+"], countryCode:["+countryCode+"]");
				
				
				//saved by vpsingh starts on 12-june
				context.setAttribute("userName",authenticate.getSessionHistory().getUser());
				//saved by vpsingh ends
				
				
				for(int i=0;i<sessionHistory.getLinksDetails().size();i++)
				{	
					sessionMap.put(sessionHistory.getLinksDetails().get(i).toString(),sessionHistory.getLinksDetails().get(i));
				}
				
				
			/*	ReportMetadataCache.reload();
				ReportMetadataCache metadataCache= ReportMetadataCache.getInstance(); 
				 for(int i=0;i<metadataCache.getReportCount();i++)
				 {
				 	ReportMetadata rm=metadataCache.getReportMetadata(i);
				 	rm.setReportTitle(getText(rm.getReportTitle()));
				 	
				 	String[] temp1=rm.getReportHeaders();
				 	String[] temp2=new String[temp1.length];
				 	for(int x=0;x<temp1.length;x++)
				 	{
				 		temp2[x]=getText(temp1[x]);
				 	}
				 	rm.setReportHeaders(temp2);
				 }
*/
				
				// Added By AbhiShek Rana for creating user history.
				
				historyDataBean = new HistoryDataBean();
				historyDataBean.setUser(username);
				historyDataBean.setAction(getText("login"));
				historyDataBean.setEvent("Log In");
				historyDataBean.setRole(sessionHistory.getRoleName());
				historyDataBean.setMsg("["+username+"] Log In into System");
				historyGenerator = new HistoryGenerator();
				historyGenerator.insertHistoryData(historyDataBean,
						con);
				TSSJavaUtil.instance().freeConnection(con);
				///////////////////// END ////////////////////////
				retVal="success";
			}else //ie login failed
			{
//				logger.info("Login Failed Message:"+getText("alert1"));
//				this.setMessage(getText("alert1"));
//				retVal="failure";
				attempt++;
				
				
				//time_forlock=10000
						//alert2=You are ristricted for some time 
						
						
				if(attempt>3)
				{
				this.setMessage(getText("Please try after sometime"));
					
					
					
					//logger.info("Restriction Message:"+getText("alert2"));
				Thread.sleep(5000);
				
					
					
				}
				
				
				else
				{
					
				logger.info("Login Failed Message:"+getText("alert1"));
				this.setMessage(getText("alert1"));
				}
				//System.out.println(totalAttempts);
			//totalAttempts--;	
			retVal="failure";
				
			}
			
//			}
//			else
//			{System.out.println("after 3 attempts");
//				this.setMessage("Maximum number of attempts exceeded....Login after 5 minutes");
//				retVal="failure";
//			}
			
			

			
		}catch(Exception exe)
		{
			
			
			logger.error("Exception in login() of LoginAction.java: "+exe);
			exe.printStackTrace();
			this.setMessage(getText("alertunknown"));			
			retVal="error";
		}finally
		{
				if(con!=null)
					TSSJavaUtil.instance().freeConnection(con);
				
				
		}

		//logger.info("This is the value of retVal in Action ["+retVal+"]");	
		return retVal;
	}//login() ends

	
	
	public String changePass()
	{
		logger.info("Inside changePass() of LoginAction..........");
		setActionName("Home.action");
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
			}else{
				
		try {
			logger.info("inside changepass user is ["+(String)sessionMap.get("user")+"] password ["+bean.getPassword()+"] new password ["+bean.getNewpassword()+"] role id"+sessionMap.get("roleId"));
			AuthAdmin authAdmin= new AuthAdmin();
			int retvalue=authAdmin.changePassword((String)sessionMap.get("user"),bean.getPassword(), bean.getNewpassword(),(Integer)sessionMap.get("roleId"));
			
			if(retvalue==1)
			{	
				setMessage(getText("passchangeSuccessfully"));
			}
			else if(retvalue==12)
			{	
				setMessage(getText("invalidNamePass"));
			}
			else
			{	
				setMessage(getText("tryLater"));
			}
			
			logger.info("Response Message From authAdmin.changePassword(): "+getMessage());
		}		
		catch (Exception e){
			logger.error("Error in changePass():"+e);
			e.printStackTrace();
		return "failure";
		}
			}
		return "success";
	}//changePass() ends
	
	
	
	@Override
	public void setServletContext(ServletContext arg0) {
		// TODO Auto-generated method stub
		  this.context = arg0;
		
	}
	//Added by MoHit for Cache reload 30 Dec 14
	public String reloadCache()
	{	
		logger.info("Reload TSSJavaUtil instance......... inside reloadCache()");
		if(TSSJavaUtil.reload()!=null)
			return "success";
		return "error";
	}
}
