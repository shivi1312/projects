package com.telemune.vcc.common;

public class MainClass {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	//	Connection con=TSSJavaUtil.instance().getconnection();
		/*System.out.println("con----> : "+con);
		CategoryManager catManager=new CategoryManager();
		CategoryDetails categoryDetails=new CategoryDetails();
		Category cat=new Category();
		cat.setCatId(-1);
		//categoryDetails = catManager.getCategoryDetails(cat, con);
		Vector rbtId= categoryDetails.getRbts();
		System.out.println("---->"+rbtId.size());*/
		//RbtManager rbtmanager=new RbtManager();
		//rbtmanager.getRbtdetailsForCom(con, rbtlist, catId, pageid)
	}

}
