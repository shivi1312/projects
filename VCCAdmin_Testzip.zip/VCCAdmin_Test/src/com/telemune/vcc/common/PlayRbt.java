package com.telemune.vcc.common;

import com.telemune.dbutilities.*;
import java.io.*;
import java.sql.ResultSet;
import org.apache.log4j.*;
public class PlayRbt {

	private static Logger logger=Logger.getLogger(PlayRbt.class);
	private Connection con;
	private  String musicPath = "";

	public String getMusicPath()
	{
		return musicPath;
	}

	public int getFilePath(int rbtcode)
	{
		logger.info("In PlayRbt.java's getFilePath()");
		ResultSet rs=null;
		PreparedStatement pstmt =null;
		musicPath = "";
		try {
			String query = "select file_path from crbt_rbt where rbt_code = ?";
			String query1 = "select file_path from crbt_rbt_approve_pending where rbt_code = ?";
			PreparedStatement pstmt1=null;
			ResultSet rs1=null;
			
			con = TSSJavaUtil.instance().getconnection();
			pstmt = con.prepareStatement(query);
			logger.info("Select Query = "+query);
			pstmt.setInt(1, rbtcode);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				musicPath = rs.getString("FILE_PATH");
				logger.info("MusicPath of File to Play: "+musicPath);
				if(rs != null) rs.close();
				pstmt.close();
			}
			else 
			{
				logger.error("\n\n musicPath not found in crbt_rbt table's FILE_PATH column so check it  now going to get file path from crbt_rbt_approve_pending tbl \n\n");
				
				pstmt1 = con.prepareStatement(query1);
				logger.info("Select query1 = "+query1);
				pstmt1.setInt(1, rbtcode);
				rs1 = pstmt1.executeQuery();
				if(rs1.next())
				{
					musicPath = rs1.getString("FILE_PATH");
					logger.info("MusicPath of File from crbt_rbt_approve_pending tbl= "+musicPath);
					if(rs1 != null) rs1.close();
				}
				else
				{
					logger.error("\n\n MusicPath of File not found in crbt_rbt_approve_pending table also so check it \n\n");
					if(rs1 != null) rs1.close();
					pstmt1.close();
					return -10;
				}
					
				if(rs1 != null) rs1.close();
				pstmt1.close();
			}
			
			if(rs != null) rs.close();
			pstmt.close();
		}
		catch(Exception e) {
			logger.error("Error in getFilePath() of PlayRbt.java so returns -99:"+e);
			e.printStackTrace();
			return -99;
		}
		finally
		{
			try
			{
				if(rs != null) rs.close();
				if(pstmt!=null)pstmt.close();
			}
			catch(Exception exp){exp.printStackTrace();}

			if(con!=null)
				TSSJavaUtil.instance().freeConnection(con);
		}
		return 99;
	}

	public int playRbt(int rbtcode, Writer out) {
			logger.info("inside playRbt() of PlayRbt.java to get filePath and then  get inputStream");
		String musicPath = "";
		try {
			String query = "select file_path from crbt_rbt where rbt_code = ?";
			String query1 = "select file_path from crbt_rbt_approve_pending where rbt_code = ?";
			PreparedStatement pstmt1=null;
			ResultSet rs1=null;
			
			con = TSSJavaUtil.instance().getconnection();
			PreparedStatement pstmt = con.prepareStatement(query);
			logger.info("Select Query = "+query);
			pstmt.setInt(1,rbtcode);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next()) {
				musicPath = rs.getString("FILE_PATH");				
			}
			else 
			{
				logger.error("\n\n musicPath not found in crbt_rbt table's FILE_PATH column so check it  now going to get file path from crbt_rbt_approve_pending tbl \n\n");
				logger.info("Select query1 = "+query1);
				pstmt1 = con.prepareStatement(query1);
				pstmt1.setInt(1, rbtcode);
				rs1 = pstmt1.executeQuery();
				if(rs1.next())
				{
					musicPath = rs1.getString("FILE_PATH");					
					if(rs1 != null) rs1.close();
				}
				else
				{
					logger.error("\n\n MusicPath of File not found in crbt_rbt_approve_pending table also so check it \n\n");
					if(rs1 != null) rs1.close();
					pstmt1.close();
					return -10;
				}					
				if(rs1 != null) rs1.close();
				pstmt1.close();
				try {
					if(con!=null) TSSJavaUtil.instance().freeConnection(con);
				} catch (Exception e) {
					// TODO: handle exception
				}
				
			}			
			logger.info("Fetched musicpath= "+musicPath);
			if(rs != null) rs.close();
			pstmt.close();
			try {
				if(con!=null) TSSJavaUtil.instance().freeConnection(con);
			} catch (Exception e) {
				// TODO: handle exception
			}
		}
		catch(Exception e){
			logger.error("Error in playRbt() of PlayRbt.java so returning -99:"+e);
			try {
				if(con!=null) TSSJavaUtil.instance().freeConnection(con);
			} catch (Exception ex) {
				// TODO: handle exception
			}
			e.printStackTrace();
			return -99;
		}

		try {
			File file = new File(musicPath);
			FileInputStream fis = new FileInputStream(file);

			int i = fis.read();
			while(i != -1) {
				out.write(i);
				i = fis.read();
			}
			fis.close();
		}
		catch(FileNotFoundException exp){
			logger.error("Error in playRbt(): RbtFile Not Found on Given musicPath to play so check it,returning -3:"+exp);			
			exp.printStackTrace();
			return -3;
		}
		catch(Exception e) {
			e.printStackTrace();
			return -99;
		}
		return 99;
	}

	public int checkvalidity(String msisdn,int rbtcode){
			logger.info("inside checkvalidity()");
		try {
			con = TSSJavaUtil.instance().getconnection();
			String query = "select CAT_ID from CRBT_RBT where RBT_CODE = ?";
			logger.info("Select Query = "+query);
			PreparedStatement statement = con.prepareStatement(query);
			statement.setInt(1,rbtcode);
			int categoryId = -1;
			ResultSet rs = statement.executeQuery();
			if(rs.next()) {
				categoryId = rs.getInt(1);
				if(rs != null) rs.close();
			}
			else {
				if(rs != null) rs.close();
				statement.close();
				try {
					if(con!=null) TSSJavaUtil.instance().freeConnection(con);
				} catch (Exception e) {
					logger.error("Error in checkvalidity() while closing con:"+e);
				}
				return -10;
			}
			int recorderCatID = -1;
			recorderCatID  = Integer.parseInt(TSSJavaUtil.instance().getAppConfigParam("CRBT_RECORDED_CATEGORY_ID"));
			if( categoryId == recorderCatID)
			{
				String dbmsidn ="";
				query = "select msisdn from crbt_rbt_owner  where rbt_code = ?";
				logger.info("Select Query:"+query);
				statement = con.prepareStatement(query);
				statement.setInt(1,rbtcode);
				rs = statement.executeQuery();
				if(rs.next())
				{
					dbmsidn = rs.getString(1);
				}
				else
				{
					logger.info("\nData not found in crbt_rbt_owner \n");
				}
				if(rs != null) rs.close();
				logger.info("Fetched MSISDN-"+msisdn+", DBMSISDN-"+dbmsidn);
				
				if(!dbmsidn.equals(msisdn) ){					
					if(rs != null) rs.close();
					statement.close();
					if(con!=null)
						TSSJavaUtil.instance().freeConnection(con);
					return -20;
				}
			}
			statement.close();
			if(con!=null)
				TSSJavaUtil.instance().freeConnection(con);		
		}
		catch(Exception e){
			logger.error("Error in checkvalidity(),returning -1:"+e);
			if(con!=null)
				TSSJavaUtil.instance().freeConnection(con);
			e.printStackTrace();
			return -1;
		}
		return 99;
	}
}
