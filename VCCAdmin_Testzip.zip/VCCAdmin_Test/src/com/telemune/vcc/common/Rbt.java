package com.telemune.vcc.common;

public class Rbt
{
 private int rbtId = -1;
 private String rbtMaskName = "";
 private String ivrFileName = "";
 private String musicPath = "";
 private String nickname = "";
 private String nokia = "";
 private String others = "";
 private String playable = "";
 private String showweb = "";
 private String showsms = "";
 private String chgdesc = "";
 private int score = 0;
 private int catId = -1;
 private int chgCode=-1;
 private int contentProviderCode = -1;
 private double preCost=-1;
 private double postCost=-1;
 private boolean approved=false;
 private String createDate="";
 private String artName="";
 private long corpId = 0;
 private String catName;
 private boolean checkDay;
 private String cp;
 private String msisdn="";
 private String albumName="";

 private String imagePath="";//added by shambhavi for image uploading

 private String approvedBy="";
 private int rbtOrder = -1;

 

 //added by varinderpal to show artistname on web

 
	//Pankaj----->

//Pankaj----->

	private String exist="NO"; //to check existance of rbt in album
	public String getImagePath() {
		return imagePath;
	}

	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}

	public String getExist() {
		return exist;
	}

	public void setExist(String exist) {
		this.exist = exist;
	}
	//Pankaj------->
		
 public Rbt()
 {
 }

 public Rbt(int rId)
 {
  this.rbtId = rId;
 }

 public Rbt(int rId, String mName)
 {
  this.rbtId = rId;
  this.rbtMaskName = mName;
 }
 
 public Rbt(int rId, String mName, int catId)
 {
  this.rbtId = rId;
  this.rbtMaskName = mName;
  this.catId = catId;
 }
 
 //added by vpsingh on 18-june
 public Rbt(String artName,int rId, String mName, int catId)
 {
	 this.artName=artName;
	 this.rbtId = rId;
	 this.rbtMaskName = mName;
	 this.catId = catId;
 }
 
 public Rbt(int rId, String mName, int catId,String catname)
 {
  this.rbtId = rId;
  this.rbtMaskName = mName;
  this.catId = catId;
  this.catName=catname;
 }
 
 
 
//added by varinderpal on 1 april 15
 public Rbt(String artName,int rId, String mName, int catId,String catname)
 {
	 this.artName=artName;
  this.rbtId = rId;
  this.rbtMaskName = mName;
  this.catId = catId;
  this.catName=catname;
 }
 
 //added by vpsingh on 15-june
 public Rbt(int rId, String mName, int catId,String approve,String artName,String approvedBy)
 {
         this.rbtId = rId;
         this.rbtMaskName = mName;
         this.catId = catId;
         this.artName=artName;
         this.approved=( approve.equalsIgnoreCase("YES") ? true : false );
         this.approvedBy=approvedBy;
         //System.out.println("Inside rbt.java==  "+rbtId+" , "+ rbtMaskName+" approvedBy: "+this.approvedBy);
 }
 
 public Rbt(int rId, String mName, int catId,String approve,String artName)
 {
         this.rbtId = rId;
         this.rbtMaskName = mName;
         this.catId = catId;
         this.artName=artName;
         this.approved=( approve.equalsIgnoreCase("YES") ? true : false );         
  //       System.out.println("Inside rbt.java==  "+rbtId+" , "+ rbtMaskName+  " , "+catId+" , "+artName+" , "+approved);
 }
 
 public Rbt(int rId, String mName, int catId,String approve,String artName,int chgCode)
 {
         this.rbtId = rId;
         this.rbtMaskName = mName;
         this.catId = catId;
         this.artName=artName;
         this.chgCode=chgCode;
         this.approved=( approve.equalsIgnoreCase("YES") ? true : false );         
  //       System.out.println("Inside rbt.java==  "+rbtId+" , "+ rbtMaskName+  " , "+catId+" , "+artName+" , "+approved);
 }
 
 public Rbt(int rId, String mName, int catId,String approve,String artName,int chgCode,int corpId,int cpId)
 {
         this.rbtId = rId;
         this.rbtMaskName = mName;
         this.catId = catId;
         this.artName=artName;
         this.chgCode=chgCode;
         this.corpId=corpId;
         this.contentProviderCode=cpId;
         this.approved=( approve.equalsIgnoreCase("YES") ? true : false );         
  //       System.out.println("Inside rbt.java==  "+rbtId+" , "+ rbtMaskName+  " , "+catId+" , "+artName+" , "+approved);
 }
 
 public Rbt(int rId,int rbtOrder,String mName)
 {
         this.rbtId = rId;
         this.rbtMaskName = mName;         
         this.rbtOrder=rbtOrder;
         //System.out.println("Inside rbt.java==  "+rbtId+" , "+ rbtMaskName+  " , "+catId+", "+rbtOrder);
 }
 
 public int getRbtOrder() {
	return rbtOrder;
}

public void setRbtOrder(int rbtOrder) {
	this.rbtOrder = rbtOrder;
}

public String getMsisdn() {
	return msisdn;
}

public void setMsisdn(String msisdn) {
	this.msisdn = msisdn;
}

public String getAlbumName() {
	return albumName;
}

public void setAlbumName(String albumName) {
	this.albumName = albumName;
}

public String getCatName() {
		return catName;
	}

	public void setCatName(String catName) {
		this.catName = catName;
	}
		 public boolean isCheckDay() {
	         return checkDay;
	 }

	 public void setCheckDay(boolean checkDay) {
	         this.checkDay = checkDay;
	 }


public int getRbtId() {
	return rbtId;
}

public void setRbtId(int rbtId) {
	this.rbtId = rbtId;
}

public String getRbtMaskName() {
	return rbtMaskName;
}

public void setRbtMaskName(String rbtMaskName) {
	this.rbtMaskName = rbtMaskName;
}

public String getIvrFileName() {
	return ivrFileName;
}

public void setIvrFileName(String ivrFileName) {
	this.ivrFileName = ivrFileName;
}

public String getMusicPath() {
	return musicPath;
}

public void setMusicPath(String musicPath) {
	this.musicPath = musicPath;
}

public String getNickname() {
	return nickname;
}

public void setNickname(String nickname) {
	this.nickname = nickname;
}

public String getNokia() {
	return nokia;
}

public void setNokia(String nokia) {
	this.nokia = nokia;
}

public String getOthers() {
	return others;
}

public void setOthers(String others) {
	this.others = others;
}

public String getPlayable() {
	return playable;
}

public void setPlayable(String playable) {
	this.playable = playable;
}

public String getShowweb() {
	return showweb;
}

public void setShowweb(String showweb) {
	this.showweb = showweb;
}

public String getShowsms() {
	return showsms;
}

public void setShowsms(String showsms) {
	this.showsms = showsms;
}

public String getChgdesc() {
	return chgdesc;
}

public void setChgdesc(String chgdesc) {
	this.chgdesc = chgdesc;
}

public int getScore() {
	return score;
}

public void setScore(int score) {
	this.score = score;
}

public int getCatId() {
	return catId;
}

public void setCatId(int catId) {
	this.catId = catId;
}

public int getChgCode() {
	return chgCode;
}

public void setChgCode(int chgCode) {
	this.chgCode = chgCode;
}

public int getContentProviderCode() {
	return contentProviderCode;
}

public void setContentProviderCode(int contentProviderCode) {
	this.contentProviderCode = contentProviderCode;
}

public double getPreCost() {
	return preCost;
}

public void setPreCost(double preCost) {
	this.preCost = preCost;
}

public double getPostCost() {
	return postCost;
}

public void setPostCost(double postCost) {
	this.postCost = postCost;
}

public boolean isApproved() {
	return approved;
}

public void setApproved(boolean approved) {
	this.approved = approved;
}

public String getCreateDate() {
	return createDate;
}

public void setCreateDate(String createDate) {
	this.createDate = createDate;
}

public String getArtName() {
	return artName;
}

public void setArtName(String artName) {
	this.artName = artName;
}

public long getCorpId() {
	return corpId;
}

public void setCorpId(long corpId) {
	this.corpId = corpId;
}


public void setApproved(String approved) {
	this.approved = (approved.equals("YES")?true :false);
}


public String getApprovedBy() {
	return approvedBy;
}

public void setApprovedBy(String approvedBy) {
	this.approvedBy = approvedBy;
}

public String getCp() {
	return cp;
}

public void setCp(String cp) {
	this.cp = cp;
}

@Override
public String toString() {
	return "Rbt [rbtId=" + rbtId + ", rbtMaskName=" + rbtMaskName
			+ ", ivrFileName=" + ivrFileName + ", musicPath=" + musicPath
			+ ", nickname=" + nickname + ", nokia=" + nokia + ", others="
			+ others + ", playable=" + playable + ", showweb=" + showweb
			+ ", showsms=" + showsms + ", chgdesc=" + chgdesc + ", score="
			+ score + ", catId=" + catId + ", chgCode=" + chgCode
			+ ", contentProviderCode=" + contentProviderCode + ", preCost="
			+ preCost + ", postCost=" + postCost + ", approved=" + approved
			+ ", createDate=" + createDate + ", artName=" + artName
			+ ", corpId=" + corpId + ", catName=" + catName + ", checkDay="
			+ checkDay + "]";
}
 
}

