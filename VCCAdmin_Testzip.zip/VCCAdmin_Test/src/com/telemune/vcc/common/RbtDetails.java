package com.telemune.vcc.common;

public class RbtDetails
{
	private int rbtId;
	private int catId;
	private String rbtMaskName;
	private String categoryMaskedName;
	private String createDate;
	private String expiryDate;
	private String artistName;
	
	
	public String getArtistName() {
		return artistName;
	}

	public void setArtistName(String artistName) {
		this.artistName = artistName;
	}

	public void setCategoryMaskedName(String categoryMaskedName) {
		this.categoryMaskedName = categoryMaskedName;
	}

	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getRbtMaskName() {
		return rbtMaskName;
	}

	public RbtDetails()
	{
		this.rbtId = -1;
		this.catId = -1;
		this.rbtMaskName = "0";
		this.categoryMaskedName = "";
		this.createDate = "";
		this.expiryDate = "";
	}
  
	public RbtDetails(int rId, String mName)
	{
		this.rbtId = rId;
		this.rbtMaskName = mName;
		this.categoryMaskedName = "";
	}
	
	public RbtDetails(String artName,int rId, String mName)
	{
		this.artistName=artName;
		this.rbtId = rId;
		this.rbtMaskName = mName;
		this.categoryMaskedName = "";
	}
	
	public RbtDetails(int rId, String mName, int catId, String categoryMaskedName)
	{
		this.rbtId = rId;
		this.rbtMaskName = mName;
		this.catId = catId;
		this.categoryMaskedName = categoryMaskedName;
	}
	public RbtDetails(int rId, String mName, int catId, String categoryMaskedName,String createDate, String expiryDate)
	{
		this.rbtId = rId;
		this.rbtMaskName = mName;
		this.catId = catId;
		this.categoryMaskedName = categoryMaskedName;
		this.createDate = createDate;
		this.expiryDate = expiryDate;
	}

	public void setRbtId(int rbtId)
	{
		this.rbtId = rbtId;
	}
	public void setCatId(int catId)
	{
		this.catId = catId;
	}
	public void setRbtMaskName(String rbtMaskName)
	{
		this.rbtMaskName = rbtMaskName;
	}
	public void setCatMaskName(String catMaskName)
	{
		this.categoryMaskedName = catMaskName;
	}
	public int getRbtId()
	{
		return rbtId;
	}

	public int getCatId()
	{
		return catId;
	}

	public String getRbtMaskedName()
	{
		return rbtMaskName;
	}

	public String getCategoryMaskedName()
	{
		return categoryMaskedName;
	}
	public String getCreateDate()
	{
		return createDate;
	}
	public String getExpiryDate()
	{
		return expiryDate;
	}
	public void setCreateDate(String createDate)
	{
		this.createDate=createDate;
	}
}
