
package com.telemune.vcc.common;

import com.telemune.dbutilities.*;
import com.telemune.vcc.custcare.NametuneBean;

import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.*;
import java.io.*;

import javax.servlet.ServletContext;

import org.apache.log4j.*;
import org.apache.struts2.ServletActionContext;

public class RbtManager
{
	static Logger logger=Logger.getLogger(RbtManager.class);
	private Connection con;
	//	private Connection con;
	private PreparedStatement pstmt=null;
	private ResultSet rs=null;
	private String startDate="";
	private String endDate="";
	private int cp=0;
	
	
	public int diffRbtChg=0;
	public void setDiffRbtChg(int c)
	{
		diffRbtChg=c;
	}
	
	// this fucntion is added by ekansh -----------------------------------

	public int addNewRbt(String origin_address, String filepath, String startdate, String enddate,Connection con)
	{
		try
		{	
			logger.info("Inside addNewRbt() :: origin address ["+origin_address+"]  filepath ["+filepath+"] startdate ["+startdate+"]  enddate  ["+enddate+"] ");
			con = TSSJavaUtil.instance().getconnection();			

			String	query = "insert into OUT_DIAL_DATA  (ORIGINATION_ADDRESS,FILE_PATH, OUTDIAL_START_TIME, OUTDIAL_END_TIME, CREATION_DATE)  values (?, ?, to_date(?,'DD-MM-YYYY HH24'),to_date(?,'DD-MM-YYYY HH24'), sysdate)";
			logger.info("Insert Query = "+query);
			pstmt = con.prepareStatement(query);

			pstmt.setString(1, origin_address.trim());
			pstmt.setString(2, filepath.trim());
			pstmt.setString(3, startdate.trim());
			pstmt.setString(4, enddate.trim());

			pstmt.executeUpdate();
			pstmt.close();

			return 0;
		}
		catch (Exception exp)
		{
			logger.error("Error in addNewRbt() while adding new rbt,returning -1:"+exp);
			try {
				con.rollback();
			}	catch (Exception e) {
				  logger.error("Exception in addNewRbt() while rollback",e);
				e.printStackTrace();
			}
			exp.printStackTrace();
			return -1;
		}
    		finally
    		{
    			if(con!=null)
    			TSSJavaUtil.instance().freeConnection(con);
    		}
	}//addNewRbt() ends


	// this function is for getting the data for Rbt details coresponding the id EKansh
	//public int getRbtdetailsForCom(Connection con ,ArrayList rbtlist,int catId,int pageid)//edited by pankaj to remove pageId
	public int getRbtdetailsForCom(Connection con ,ArrayList rbtlist,int catId,String searchWord)
	{
		logger.info("inside getRbtdetailsForCom().......... catid ["+catId+"] ");
		PreparedStatement pstmt= null;
		PreparedStatement pstmt2= null;
		ResultSet rs= null;
		ResultSet rs1= null;
		int retVal=-1;
		rbtlist.clear();
		String query="";
		String query2="";
		//int pageid=0;
		///int srow = pageid*20;
		//int erow = srow+21;
		//Start of Updated by MoHit for not showing Recorded and special Categories on 13 Nov 14		
		String specialCatId ="998";
        String recordedCatId="999";		
		specialCatId   = TSSJavaUtil.instance().getAppConfigParam("SPECIAL_CONTROL_CATID");
        recordedCatId  = TSSJavaUtil.instance().getAppConfigParam("CRBT_RECORDED_CATEGORY_ID");	
		try{
			if(catId==-1)
			{
				//query="select * from (select RBT_CODE,a.MASKED_NAME,a.CAT_ID ,b.MASKED_NAME as CAT_NAME,rownum as ROW_NUMBER from crbt_rbt a,crbt_category_master b where a.PLAYABLE='Y' and a.SHOW_ON_WEB='Y' and RBT_CODE!=0 and a.CAT_ID=b.CAT_ID  and rownum<?) where ROW_NUMBER>?";
				if(searchWord=="")
				{
					query="select RBT_CODE,a.ARTIST_NAME,a.MASKED_NAME,a.CAT_ID ,b.MASKED_NAME as CAT_NAME,rownum as ROW_NUMBER from crbt_rbt a,crbt_category_master b where a.PLAYABLE='Y' and a.SHOW_ON_WEB='Y' and RBT_CODE!=0 and a.CAT_ID=b.CAT_ID and not(b.CAT_ID = ?) and not(b.CAT_ID = ?)";//edited by pankaj to remove pageId
				}	
				else
				{
					query="select RBT_CODE,a.ARTIST_NAME,a.MASKED_NAME,a.CAT_ID ,b.MASKED_NAME as CAT_NAME,rownum as ROW_NUMBER from crbt_rbt a,crbt_category_master b where a.PLAYABLE='Y' and a.SHOW_ON_WEB='Y' and RBT_CODE!=0 and a.CAT_ID=b.CAT_ID and not(b.CAT_ID = ?) and not(b.CAT_ID = ?) and LOWER(a.MASKED_NAME) like '%"+searchWord.toLowerCase()+"%'";//edited by pankaj to remove pageId
				}	

				pstmt=con.prepareStatement(query);
				pstmt.setString(1,specialCatId);
				pstmt.setString(2,recordedCatId);
				//pstmt.setInt(1, erow);
				//pstmt.setInt(2, srow);
				logger.info("Select query ["+query+"]");
//				System.out.println("catId ["+catId+"] query ["+query+"]");
				query2="select count(*) Total from (select a.RBT_CODE,a.MASKED_NAME,a.CAT_ID ,b.MASKED_NAME as CAT_NAME from crbt_rbt a,crbt_category_master b where a.PLAYABLE='Y' and a.SHOW_ON_WEB='Y' and RBT_CODE!=0 and a.CAT_ID=b.CAT_ID and not(b.CAT_ID = ?) and not(b.CAT_ID = ?))";
				pstmt2=con.prepareStatement(query2);
				pstmt2.setString(1,specialCatId);
				pstmt2.setString(2,recordedCatId);
			}else
			{	
				//query="select * from (select RBT_CODE,a.MASKED_NAME,a.CAT_ID ,b.MASKED_NAME as CAT_NAME,rownum as ROW_NUMBER  from crbt_rbt a,crbt_category_master b where a.PLAYABLE='Y' and a.SHOW_ON_WEB='Y' and RBT_CODE!=0 and a.CAT_ID=b.CAT_ID  and  a.cat_id=? and rownum<?) where ROW_NUMBER>?";

				if(searchWord=="")
				{
					query="select a.RBT_CODE,a.ARTIST_NAME,a.MASKED_NAME,a.CAT_ID ,b.MASKED_NAME as CAT_NAME,rownum as ROW_NUMBER  from crbt_rbt a,crbt_category_master b where a.PLAYABLE='Y' and a.SHOW_ON_WEB='Y' and RBT_CODE!=0 and a.CAT_ID=b.CAT_ID  and  a.cat_id=? and not(b.CAT_ID = ?) and not(b.CAT_ID = ?)";//edited by pankaj to remove pageId
				}
				else
				{
					query="select a.RBT_CODE,a.ARTIST_NAME,a.MASKED_NAME,a.CAT_ID ,b.MASKED_NAME as CAT_NAME,rownum as ROW_NUMBER  from crbt_rbt a,crbt_category_master b where a.PLAYABLE='Y' and a.SHOW_ON_WEB='Y' and RBT_CODE!=0 and a.CAT_ID=b.CAT_ID  and  a.cat_id=? and not(b.CAT_ID = ?) and not(b.CAT_ID = ?) and LOWER(a.MASKED_NAME) like '%"+searchWord.toLowerCase()+"%'";//edited by pankaj to remove pageId
				}
				
				pstmt=con.prepareStatement(query);
				pstmt.setInt(1,catId);
				pstmt.setString(2,specialCatId);
				pstmt.setString(3,recordedCatId);
				//pstmt.setInt(2, erow);
				//pstmt.setInt(3, srow);
				logger.info("Select Query ["+query+"]");				

				query2="select count(*)  Total from (select a.RBT_CODE,a.MASKED_NAME,a.CAT_ID ,b.MASKED_NAME as CAT_NAME  from crbt_rbt a,crbt_category_master b where a.PLAYABLE='Y' and a.SHOW_ON_WEB='Y' and RBT_CODE!=0 and a.CAT_ID=b.CAT_ID  and  a.cat_id=? and not(b.CAT_ID = ?) and not(b.CAT_ID = ?))";
				pstmt2=con.prepareStatement(query2);
				pstmt2.setInt(1,catId);
				pstmt2.setString(2,specialCatId);
				pstmt2.setString(3,recordedCatId);

			}
			//End of Updated by MoHit for not showing Recorded and special Categories on 13 Nov 14			
			rs=pstmt.executeQuery();
			while (rs.next())
			{
				Rbt rbt= new Rbt(rs.getString("ARTIST_NAME"),rs.getInt("RBT_CODE"),rs.getString("MASKED_NAME"),rs.getInt("cat_id"),rs.getString("CAT_NAME"));
				rbtlist.add(rbt);
			}
			rs1=pstmt2.executeQuery();
			if(rs1.next())
			{
				retVal=rs1.getInt("Total");
			}
			else
			{
				logger.info("No data found from query2");
			}
			//logger.info("Number of rbt's  ["+rbtlist.size()+"]");
			rs.close();
			pstmt.close();
			rs1.close();
			pstmt2.close();
		}catch(Exception exe)
		{
			exe.printStackTrace();
			logger.error("Exception in getRbtdetailsForCom(),returning -1...",exe);
			return -1;
		}finally
		{
			try{
				if(pstmt!=null)pstmt.close();
				if(rs!=null)rs.close();
				if(pstmt2!=null)pstmt2.close();
				if(rs1!=null)rs1.close();
			}catch(Exception exe)
			{
				exe.printStackTrace();
			}
		}
		return retVal;
	}//getRbtdetailsForCom() ends

	
	//added by varinderpal to search by artist name starts
	public int getRbtdetailsForArtist(ArrayList rbtlist,String searchWord)
	{
		logger.info("inside getRbtdetailsForArtist() to get rbtDetail by searching artistname word:["+searchWord+"]");
		con=TSSJavaUtil.instance().getconnection();
		PreparedStatement pstmt= null;
		PreparedStatement pstmt2= null;
		ResultSet rs= null;
		ResultSet rs1= null;
		int retVal=-1;
		rbtlist.clear();
		String query="";
		String query2="";
		//Start of Updated by MoHit for not showing Recorded and special Categories on 13 Nov 14		
		String specialCatId ="998";
        String recordedCatId="999";		
		specialCatId   = TSSJavaUtil.instance().getAppConfigParam("SPECIAL_CONTROL_CATID");
        recordedCatId  = TSSJavaUtil.instance().getAppConfigParam("CRBT_RECORDED_CATEGORY_ID");		
		try{
	
				if(searchWord=="")
				{
					query="select RBT_CODE,a.MASKED_NAME,a.ARTIST_NAME,a.CAT_ID ,b.MASKED_NAME as CAT_NAME,rownum as ROW_NUMBER from crbt_rbt a,crbt_category_master b where a.PLAYABLE='Y' and a.SHOW_ON_WEB='Y' and RBT_CODE!=0 and a.CAT_ID=b.CAT_ID and not(b.CAT_ID = ?) and not(b.CAT_ID = ?)";
				}
				else
				{				
					query="select RBT_CODE,a.MASKED_NAME,a.ARTIST_NAME,a.CAT_ID ,b.MASKED_NAME as CAT_NAME,rownum as ROW_NUMBER from crbt_rbt a,crbt_category_master b where a.PLAYABLE='Y' and a.SHOW_ON_WEB='Y' and RBT_CODE!=0 and a.CAT_ID=b.CAT_ID and not(b.CAT_ID = ?) and not(b.CAT_ID = ?) and LOWER(a.ARTIST_NAME) like '%"+searchWord.toLowerCase()+"%'";
				}
				pstmt=con.prepareStatement(query);
				pstmt.setString(1,specialCatId);
				pstmt.setString(2,recordedCatId);

				query2="select count(*) Total from (select a.RBT_CODE,a.MASKED_NAME,a.CAT_ID ,b.MASKED_NAME as CAT_NAME from crbt_rbt a,crbt_category_master b where a.PLAYABLE='Y' and a.SHOW_ON_WEB='Y' and RBT_CODE!=0 and a.CAT_ID=b.CAT_ID and not(b.CAT_ID = ?) and not(b.CAT_ID = ?) and LOWER(a.ARTIST_NAME) like '%"+searchWord.toLowerCase()+"%')";
				pstmt2=con.prepareStatement(query2);
				pstmt2.setString(1,specialCatId);
				pstmt2.setString(2,recordedCatId);
				//End of Updated by MoHit for not showing Recorded and special Categories on 13 Nov 14
			
				logger.info("Select Query = "+query+" , Select Query2 = "+query2);
				
				rs=pstmt.executeQuery();
				while (rs.next())
				{
					Rbt rbt= new Rbt(rs.getString("ARTIST_NAME"),rs.getInt("RBT_CODE"),rs.getString("MASKED_NAME"),rs.getInt("cat_id"),rs.getString("CAT_NAME"));
					rbtlist.add(rbt);
				}				
				rs1=pstmt2.executeQuery();
				if(rs1.next())
				{
					retVal=rs1.getInt("Total");
				}
				else
				{
					logger.info("No data found from query2 to get Total");
				}				
				rs.close();
				pstmt.close();
				rs1.close();
				pstmt2.close();
		}catch(Exception exe)
		{
			exe.printStackTrace();
			logger.error("Exception in getRbtdetailsForArtist()..."+exe);
			return -1;
		}finally
		{
			try{
				if(pstmt!=null)pstmt.close();
				if(rs!=null)rs.close();
				if(pstmt2!=null)pstmt2.close();
				if(rs1!=null)rs1.close();
				if(con!=null) TSSJavaUtil.instance().freeConnection(con);
			}catch(Exception exe)
			{
				exe.printStackTrace();
			}
		}
		return retVal;
	}//getRbtdetailsForArtist() ends

	//added by varinderpal to search by artist name ends

	public int getRbtdetailsForCom(Connection con,ArrayList rbtlist,int catId,int pageid)
	{
		logger.info("inside getRbtdetailsForCom().......... catid ["+catId+"] ");
		PreparedStatement pstmt= null;
		PreparedStatement pstmt2= null;
		ResultSet rs= null;
		ResultSet rs1= null;
		int retVal=-1;
		rbtlist.clear();
		String query="";
		String query2="";
		//int pageid=0;
		int srow = pageid*20;
		int erow = srow+21;
		try{
			if(catId==-1)
			{
				query="select * from (select a.RBT_CODE,a.ARTIST_NAME,a.MASKED_NAME,a.CAT_ID ,b.MASKED_NAME as CAT_NAME,rownum as ROW_NUMBER from crbt_rbt a,crbt_category_master b where a.PLAYABLE='Y' and a.SHOW_ON_WEB='Y' and RBT_CODE!=0 and a.CAT_ID=b.CAT_ID  and rownum<?) where ROW_NUMBER>?";

				pstmt=con.prepareStatement(query);
				pstmt.setInt(1, erow);
				pstmt.setInt(2, srow);
				logger.info("catId ["+catId+"] erow ["+erow+"] srow ["+srow+"] query ["+query+"]");				

				query2="select count(*) Total from (select a.RBT_CODE,a.MASKED_NAME,a.CAT_ID ,b.MASKED_NAME as CAT_NAME from crbt_rbt a,crbt_category_master b where a.PLAYABLE='Y' and a.SHOW_ON_WEB='Y' and RBT_CODE!=0 and a.CAT_ID=b.CAT_ID )";
				pstmt2=con.prepareStatement(query2);
			}else
			{
				query="select * from (select RBT_CODE,a.ARTIST_NAME,a.MASKED_NAME,a.CAT_ID ,b.MASKED_NAME as CAT_NAME,rownum as ROW_NUMBER  from crbt_rbt a,crbt_category_master b where a.PLAYABLE='Y' and a.SHOW_ON_WEB='Y' and RBT_CODE!=0 and a.CAT_ID=b.CAT_ID  and  a.cat_id=? and rownum<?) where ROW_NUMBER>?";

				pstmt=con.prepareStatement(query);
				pstmt.setInt(1,catId);
				pstmt.setInt(2, erow);
				pstmt.setInt(3, srow);
				logger.info("catId ["+catId+"] erow ["+erow+"] srow ["+srow+"] query ["+query+"]");				

				query2="select count(*)  Total from (select a.RBT_CODE,a.MASKED_NAME,a.CAT_ID ,b.MASKED_NAME as CAT_NAME  from crbt_rbt a,crbt_category_master b where a.PLAYABLE='Y' and a.SHOW_ON_WEB='Y' and RBT_CODE!=0 and a.CAT_ID=b.CAT_ID  and  a.cat_id=?)";
				pstmt2=con.prepareStatement(query2);
				pstmt2.setInt(1,catId);
			}			
			rs=pstmt.executeQuery();
			while (rs.next())
			{
				//Rbt rbt= new Rbt(rs.getInt("RBT_CODE"),rs.getString("MASKED_NAME"),rs.getInt("cat_id"),rs.getString("CAT_NAME"));
				Rbt rbt= new Rbt(rs.getString("ARTIST_NAME"),rs.getInt("RBT_CODE"),rs.getString("MASKED_NAME"),rs.getInt("cat_id"),rs.getString("CAT_NAME"));
				rbtlist.add(rbt);
			}
			rs1=pstmt2.executeQuery();
			if(rs1.next())
			{
				retVal=rs1.getInt("Total");
			}
			else
			{
				logger.info("No data found from query2 to get total");
			}
			rs.close();
			pstmt.close();
			rs1.close();
			pstmt2.close();
		}catch(Exception exe)
		{
			exe.printStackTrace();
			logger.error("Exception in getRbtdetailsForCom()..."+exe);
			return -1;
		}finally
		{
			try{
				if(pstmt!=null)pstmt.close();
				if(rs!=null)rs.close();
				if(pstmt2!=null)pstmt2.close();
				if(rs1!=null)rs1.close();
			}catch(Exception exe)
			{
				exe.printStackTrace();
			}
		}
		return retVal;
	}//getRbtdetailsForCom() ends


	

	//added by varinderpal on 1 april 15
	//this function ll get artist name to search and ll fill in arraylist
	public int getRbtdetailsForArtist(Connection con ,ArrayList rbtlist,String searchWord)
	{
		logger.info("In getRbtdetailsForArtist() of RbtManager.java.......... Artist to Search["+searchWord+"] ");		
		PreparedStatement pstmt= null;
		PreparedStatement pstmt2= null;
		ResultSet rs= null;
		ResultSet rs1= null;
		int retVal=-1;
		rbtlist.clear();
		String query="";
		String query2="";
		//Start of Updated by MoHit for not showing Recorded and special Categories on 13 Nov 14		
		String specialCatId ="998";
        String recordedCatId="999";
		specialCatId   = TSSJavaUtil.instance().getAppConfigParam("SPECIAL_CONTROL_CATID");
        recordedCatId  = TSSJavaUtil.instance().getAppConfigParam("CRBT_RECORDED_CATEGORY_ID");
		try{				
				if(searchWord=="")
				{
					query="select RBT_CODE,a.ARTIST_NAME,a.MASKED_NAME,a.CAT_ID ,b.MASKED_NAME as CAT_NAME,rownum as ROW_NUMBER from crbt_rbt a,crbt_category_master b where a.PLAYABLE='Y' and a.SHOW_ON_WEB='Y' and RBT_CODE!=0 and a.CAT_ID=b.CAT_ID and not(b.CAT_ID = ?) and not(b.CAT_ID = ?)";
				}
				else
				{
					query="select RBT_CODE,a.ARTIST_NAME,a.MASKED_NAME,a.CAT_ID ,b.MASKED_NAME as CAT_NAME,rownum as ROW_NUMBER from crbt_rbt a,crbt_category_master b where a.PLAYABLE='Y' and a.SHOW_ON_WEB='Y' and RBT_CODE!=0 and a.CAT_ID=b.CAT_ID and not(b.CAT_ID = ?) and not(b.CAT_ID = ?) and LOWER(a.ARTIST_NAME) like '%"+searchWord.toLowerCase()+"%'";
				}
				pstmt=con.prepareStatement(query);
				pstmt.setString(1,specialCatId);
				pstmt.setString(2,recordedCatId);
				
				query2="select count(*) Total from (select a.RBT_CODE,a.MASKED_NAME,a.CAT_ID ,b.MASKED_NAME as CAT_NAME from crbt_rbt a,crbt_category_master b where a.PLAYABLE='Y' and a.SHOW_ON_WEB='Y' and RBT_CODE!=0 and a.CAT_ID=b.CAT_ID and not(b.CAT_ID = ?) and not(b.CAT_ID = ?))";
				pstmt2=con.prepareStatement(query2);
				pstmt2.setString(1,specialCatId);
				pstmt2.setString(2,recordedCatId);
			
			logger.info("query = "+query+" \n\n Query2 = "+query2);			
			
			rs=pstmt.executeQuery();
			while (rs.next())
			{
				Rbt rbt= new Rbt(rs.getString("ARTIST_NAME"),rs.getInt("RBT_CODE"),rs.getString("MASKED_NAME"),rs.getInt("cat_id"),rs.getString("CAT_NAME"));
				rbtlist.add(rbt);
			}
			rs1=pstmt2.executeQuery();
			if(rs1.next())
			{
				retVal=rs1.getInt("Total");
			}
			else
			{
				logger.info("No data found from query2");				
			}
			logger.info("Number of Fetched rbt's are: ["+rbtlist.size()+"]");
			
			rs.close();
			pstmt.close();
			rs1.close();
			pstmt2.close();
		}catch(Exception exe)
		{
			exe.printStackTrace();
			logger.error("Exception in getRbtdetailsForArtist()...",exe);			
			return -1;
		}finally
		{
			try{
				if(pstmt!=null)pstmt.close();
				if(rs!=null)rs.close();
				if(pstmt2!=null)pstmt2.close();
				if(rs1!=null)rs1.close();
			}catch(Exception exe)
			{
				exe.printStackTrace();
			}
		}
		return retVal;
	}//getRbtdetailsForArtist() ends

	

	



	
	public int addNewRbt(String mname, String filepath, String ivrPath ,int catId, String nokia, String others, int score, String play, int cpCode, String web, String sms, String sendsms,SubscriberProfile sub,int chgcode,int valdays,String artName,String imagePath, String fileExt,Connection con)

	{		
		mname=mname.toUpperCase();

		logger.info("addNewRbt() "+mname+"filepath="+filepath+"ivrPath="+ivrPath+"catId="+catId+"nokia="+nokia+"others="+others+"score="+score+"play="+play+"cpCode="+cpCode+"web="+web+"sms="+sms+"sendsms="+sendsms+"sub="+sub+"chgcode="+chgcode+"valdays="+valdays+"artName="+artName+"imagePath"+imagePath+"fileExt"+fileExt);

		int isnokia = 0;
		int isother = 0;
		

		try
		{	
			//con = conPool.getConnection();
			//con.setAutoCommit(false);
			boolean toExit=false;
			
			String mname1=mname.toLowerCase(); // make sure case is correct
			//	mname=mname.toLowerCase(); // make sure case is correct
			
			String query = "select MASKED_NAME from CRBT_RBT where lower(MASKED_NAME) = ? or upper(MASKED_NAME)=?";
			logger.info("Select Query = "+query);
			pstmt = con.prepareStatement(query);
			pstmt.setString(1,mname1);
			pstmt.setString(2,mname1);
			rs = pstmt.executeQuery();

			if(rs.next())
			{
				rs.close();
				pstmt.close();
				//return CrbtErrorCodes.RBT_ALREADY_EXISTS;
				logger.info("Rbt Name Already Exist in crbt_rbt, return -99 for rbt-name: "+mname);
				return -99;
			}
			else
			{
				logger.info("No Duplicate Rbt Name found in crbt_rbt for name: "+mname);
			}
			rs.close();
			pstmt.close();

			int rbtCode = -1;
			query = "select CRBT_RBT_CODE.NEXTVAL from dual";
			pstmt = con.prepareStatement(query);
			rs = pstmt.executeQuery();
			if (rs.next())
			{
				rbtCode = rs.getInt("NEXTVAL");
			}
			else
			{
				logger.error("\n\n No Value returned by CRBT_RBT_CODE.NEXTVAL so check  CRBT_RBT_CODE sequence,retuned -1 \n\n");
				return -1;
			}
			rs.close();
			pstmt.close();
			nokia = nokia.trim();
			others = others.trim();
			if ((nokia != null) && !(nokia.equals("")))
			{
				isnokia = 1;
			}
			if ((others != null) && !(others.equals("")))
			{
				isother = 1;
			}
			// kartikey
			//Query updated by MoHit 28 Jan 2015 for QCELL (initcap is added)

			query = "insert into CRBT_RBT (RBT_CODE, MASKED_NAME, FILE_PATH, CREATE_DATE, RBT_SCORE, IVR_FILEPATH, RBT_NICK, PLAYABLE, SHOW_ON_WEB, SHOW_IN_SMS, CONTENT_PROVIDER_CODE, CAT_ID, NOKIA, OTHER ,CHARGING_CODE,VALIDITY_PERIOD,ARTIST_NAME,IMAGE_PATH)  values (?, initcap(?), ?, sysdate, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?,initcap(?),?)";
			
			logger.info("Insert Query"+query);

			pstmt = con.prepareStatement(query);

			pstmt.setInt(1, rbtCode);
			pstmt.setString(2, mname.trim());
			pstmt.setString(3, filepath+"/"+rbtCode+".wav");
			pstmt.setInt(4, score);
			pstmt.setString(5, ivrPath+"/"+rbtCode+".wav");
			pstmt.setString(6, "XXX");
			pstmt.setString(7, play.trim());
			pstmt.setString(8, web.trim());
			pstmt.setString(9, sms.trim());
			pstmt.setInt(10, cpCode);
			pstmt.setInt(11, catId);
			pstmt.setInt(12, isnokia);
			pstmt.setInt(13, isother);
			pstmt.setInt(14, chgcode);
			pstmt.setInt(15, valdays); 
			pstmt.setString(16,artName.trim());
			
			if(!(fileExt.equalsIgnoreCase("NA")))
			{
			pstmt.setString(17, imagePath+"/"+rbtCode+fileExt);
			}else{
				pstmt.setString(17,"NA");
			}
       
			pstmt.executeUpdate();
			pstmt.close();
			
			//Query updated by MoHit 28 Jan 2015 for QCELL (initcap is added)
			String querylog="insert into crbt_rbt_logs (rbt_code,masked_name,update_time,cat_id,corp_id,cp_code,op_code,ARTIST_NAME,description,updated_by) values(?,initcap(?),sysdate,?,0,?,1,initcap(?),'Rbt Added',?)";
			logger.info("Insert Query = "+querylog);
			PreparedStatement pstmtInsert = con.prepareStatement(querylog);
			pstmtInsert.setInt(1, rbtCode);
			pstmtInsert.setString(2, mname.trim());	
			pstmtInsert.setInt(3, catId);
			pstmtInsert.setInt(4, cpCode);
			pstmtInsert.setString(5,artName.trim());
			pstmtInsert.setString(6, sub.getUsername().trim());
			pstmtInsert.executeUpdate();	
			pstmtInsert.close();
			

//			query = "insert into CRBT_MONOTONE_MASTER(RBT_CODE, RINGTONE_TYPE, RINGTONE_DATA) values(?, ?, ?)";
//			pstmt = con.prepareStatement(query);
//			logger.info("query = "+query);
//
//			if ((nokia != null) && !(nokia.equals("")))
//			{
//				pstmt.setInt(1, rbtCode);
//				pstmt.setString(2, "nokia");
//				pstmt.setString(3, nokia);				
//				pstmt.executeUpdate();
//			}
//			if ((others != null) && !(others.equals("")))
//			{
//				pstmt.setInt(1, rbtCode);
//				pstmt.setString(2, "others");
//				pstmt.setString(3, others);
//				pstmt.executeUpdate();
//			}
//
//			pstmt.close();	

			/*
			   query = "select PARAM_VALUE from CRBT_APP_CONFIG_PARAMS where PARAM_TAG = ?";
			   pstmt = con.prepareStatement(query);
			   pstmt.setString(1, "SEND_CONTENT_SMS");

			   rs = pstmt.executeQuery();
			   String appsend = "0";
			   if(rs.next())
			   {
			   appsend = rs.getString(1);
			   }
			   rs.close();
			   pstmt.close();
			   if (sendsms != null && sendsms.equalsIgnoreCase("Y") && appsend.equals("1"))
			   {
			   sendPromotionSMS(rbtCode, mname);
			   }			
			 */
			con.commit();
			//return CrbtErrorCodes.SUCCESS;
			return rbtCode;
		}
		catch (Exception exp)
		{
			logger.error("Exception in addNewRbt() of RbtManager.java:"+exp);
			try {
				con.rollback();
			}	catch (Exception e) {
				e.printStackTrace();
			}			
			exp.printStackTrace();
			return -1;
		}
		finally
		{
			try
			{
				 if(con!=null) TSSJavaUtil.instance().freeConnection(con);
			}
			catch(Exception e){				
			}
			//conPool.free(con);
		}
	}//addNewRbt() ends

	
	

	
	
	public int addCorpRbt(String mname, String filepath, String ivrPath ,int catId, String nokia, String others, int score, String play, int cpCode, String web, String sms, String sendsms,long corpid,SubscriberProfile sub,String artName,String imagePath, String fileExt,Connection con)

	{
		logger.info("In addCorpRbt() mname:"+mname+", filePath:"+filepath+" ivrPath:"+ivrPath+", catId:"+catId+" nokia:"+nokia+", others:"+others+" play:"+play+" cpCode="+cpCode+" web:"+web+" sms:"+sms+" corpid="+corpid+" atristName:"+artName+" Imagefile path ["+imagePath+"] file ext["+fileExt+"]");
		mname=mname.toUpperCase();

		boolean toExit=false;
		String mname1="";
		int rbtCode = -1;
		int isnokia = 0;
		int isother = 0;

		try
		{	
			mname1=mname.toLowerCase(); // make sure case is correct
			//con = conPool.getConnection();
			con.setAutoCommit(false);
			String query = "select MASKED_NAME from CRBT_RBT where lower(MASKED_NAME) = ? or upper(MASKED_NAME)=?";
			logger.info("Select Query = "+query);
			pstmt = con.prepareStatement(query);
			pstmt.setString(1,mname1);
			pstmt.setString(2,mname1);
			rs = pstmt.executeQuery();
			if(rs.next())
			{
				logger.info("Rbt Name Already Exist in crbt_rbt, return -99 for rbt-name: "+mname);
				rs.close();
				pstmt.close();
//				return CrbtErrorCodes.RBT_ALREADY_EXISTS;
				return -99;
			}
			else
			{
				logger.info("No Duplicate Rbt Name found in crbt_rbt for name: "+mname);
			}
			rs.close();
			pstmt.close();
			
			query = "select CRBT_RBT_CODE.NEXTVAL from dual";
			pstmt = con.prepareStatement(query);
			rs = pstmt.executeQuery();

			if (rs.next())
			{
				rbtCode = rs.getInt("NEXTVAL");
				logger.info("New Generated rbtCode from CRBT_RBT_CODE.NEXTVAL = "+rbtCode);
			}
			else
			{
//				return CrbtErrorCodes.FAILURE;
				logger.error("\n\n No Value returned by CRBT_RBT_CODE.NEXTVAL so check  CRBT_RBT_CODE sequence,retuned -1 \n\n");
				return -1;
			}
			rs.close();
			pstmt.close();
			nokia = nokia.trim();
			others = others.trim();
			if ((nokia != null) && !(nokia.equals("")))
			{
				isnokia = 1;
			}
			if ((others != null) && !(others.equals("")))
			{
				isother = 1;
			}


			query = "insert into CRBT_RBT (RBT_CODE, MASKED_NAME, FILE_PATH, CREATE_DATE, RBT_SCORE, IVR_FILEPATH, RBT_NICK, PLAYABLE, SHOW_ON_WEB, SHOW_IN_SMS, CONTENT_PROVIDER_CODE, CAT_ID, NOKIA, OTHER, CORP_ID,ARTIST_NAME,IMAGE_PATH)  values (?, initcap(?), ?, sysdate, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,initcap(?),?)";
			logger.info("query = "+query);

			pstmt = con.prepareStatement(query);

			pstmt.setInt(1, rbtCode);
			pstmt.setString(2, mname.trim());
			pstmt.setString(3, filepath+"/"+rbtCode+".wav");
			pstmt.setInt(4, score);
			pstmt.setString(5, ivrPath+"/"+rbtCode+".wav");
			pstmt.setString(6, "XXX");
			pstmt.setString(7, play.trim());
			pstmt.setString(8, web.trim());
			pstmt.setString(9, sms.trim());
			pstmt.setInt(10, cpCode);
			pstmt.setInt(11, catId);
			pstmt.setInt(12, isnokia);
			pstmt.setInt(13, isother);
			pstmt.setLong(14, corpid);
			pstmt.setString(15,artName.trim());
			if(!(fileExt.equalsIgnoreCase("NA")))
			{
			pstmt.setString(16, imagePath+"/"+rbtCode+fileExt);
			}else{
				pstmt.setString(16,"NA");
			}
			pstmt.executeUpdate();
			
			String querylog="insert into crbt_rbt_logs (rbt_code,masked_name,update_time,cat_id,corp_id,cp_code,op_code,ARTIST_NAME,description,updated_by) values(?,initcap(?),sysdate,?,0,?,1,initcap(?),'Rbt Added',?)";
			logger.info("Insert querylog = "+querylog);
			PreparedStatement pstmtInsert = con.prepareStatement(querylog);
			pstmtInsert.setInt(1, rbtCode);
			pstmtInsert.setString(2, mname.trim());	
			pstmtInsert.setInt(3, catId);
			pstmtInsert.setInt(4, cpCode);
			pstmtInsert.setString(5,artName.trim());
			pstmtInsert.setString(6, sub.getUsername().trim());
			pstmtInsert.executeUpdate();	
			pstmtInsert.close();
			
//			query = "insert into CRBT_MONOTONE_MASTER(RBT_CODE, RINGTONE_TYPE, RINGTONE_DATA) values(?, ?, ?)";
//			logger.info("query = "+query);
//			pstmt = con.prepareStatement(query);
//
//			if ((nokia != null) && !(nokia.equals("")))
//			{
//				pstmt.setInt(1, rbtCode);
//				pstmt.setString(2, "nokia");
//				pstmt.setString(3, nokia);				
//				pstmt.executeUpdate();
//			}
//			if ((others != null) && !(others.equals("")))
//			{
//				pstmt.setInt(1, rbtCode);
//				pstmt.setString(2, "others");
//				pstmt.setString(3, others);
//				pstmt.executeUpdate();
//			}
//
//			pstmt.close();	

			// track this corporate's subscribers and add new RBT to their album
			/*
			   if(corpid != 0)
			   {

			   logger.info("Corporate id= "+corpid+" adding new rbt to Subscibers album");
			   long  walletId = 0;
			   query = "select msisdn from crbt_subscriber_master where corp_id=?";
			   pstmt = con.prepareStatement(query);
			   pstmt.setLong(1, corpid);

			   rs = pstmt.executeQuery();

			   if(rs.next())
			   {
			   String msisdn=rs.getString("msisdn");

			   String query1 = "select WALLET_ID_SEQ.nextval from dual";
			   PreparedStatement pstmt1 = con.prepareStatement(query1);
			   ResultSet rs1 = pstmt1.executeQuery();
			   if (rs1.next())
			   {
			   walletId = rs1.getLong("NEXTVAL");
			   }
			   rs1.close();
			   pstmt1.close();

			   query1 = "insert into CRBT_WALLET_MASTER (MSISDN, WALLET_ID, IVR_NAME, WALLET_NAME) values(?, ?, ?, 'DEFAULT')";
			   pstmt1 = con.prepareStatement(query1);
			   pstmt1.setString(1, msisdn);
			   pstmt1.setLong(2, walletId);
			   pstmt1.setInt(3, 0);
			   pstmt1.executeUpdate();
			   pstmt1.close();

			//query = "insert into CRBT_WALLET_CONTENT (WALLET_ID, RBT_CODE) values(?, ?)";
			query1 = "insert into CRBT_WALLET_CONTENT (WALLET_ID, RBT_CODE, MSISDN, IS_RBT_GIFTED) values(?, ?,?,2)";
			pstmt1 = con.prepareStatement(query1);
			pstmt1.setLong(1, walletId);
			pstmt1.setInt(2, rbtCode);
			pstmt1.setString(3, msisdn);
			pstmt1.executeUpdate();
			pstmt1.close();
			}
			else
			{
			//this Corporate has no Subscribers added, Add subscriber
			logger.info("Corporate id= "+corpid+" does not have any Subscribers, Add subscriber first");
			return -50;
			}
			}// if(!corpid)
			 */

			/*
			   query = "select PARAM_VALUE from CRBT_APP_CONFIG_PARAMS where PARAM_TAG = ?";
			   pstmt = con.prepareStatement(query);
			   pstmt.setString(1, "SEND_CONTENT_SMS");

			   rs = pstmt.executeQuery();
			   String appsend = "0";
			   if(rs.next())
			   {
			   appsend = rs.getString(1);
			   }
			   rs.close();
			   pstmt.close();
			   if (sendsms != null && sendsms.equalsIgnoreCase("Y") && appsend.equals("1"))
			   {
			   sendPromotionSMS(rbtCode, mname);
			   }			
			 */
			con.commit();
//			return CrbtErrorCodes.SUCCESS;
			return rbtCode;
		}
		catch (Exception exp)
		{
			logger.error("Exception in addCorpRbt(): "+exp);
			exp.printStackTrace();
			try {
				con.rollback();
			}	catch (Exception e) {
				e.printStackTrace();
			}
//			return CrbtErrorCodes.FAILURE;
			return -1;
		}

	} //addCorpRbt() ends


	// this function changes the system default RBT for all subscribers.

	public int modifyDefaultRbt(String mname, int rbtId, String ivrPath, String musicpath,String nokia, String others, int score, String play, int cpCode, String web, String sms,int catId,String imageFile,Connection con)
	{
		//logger.info("in modifyDefaultRbt() mname="+mname+" rbtId="+rbtId+" ivrPath="+ivrPath+" musicPath="+musicPath+" nick="+nick+" score="+score+" cpCode="+cpCode+" web="+web" sms="+sms+" catId="+catId);

	logger.info("In modifyDefaultRbt() mname="+mname+" rbtId="+rbtId+" ivrPath="+ivrPath+" musicPath="+musicpath+" nokia="+nokia+" others:"+others+" score="+score+" play:"+play+" cpCode="+cpCode+" web="+web+" sms="+sms+" catId="+catId);

		try
		{	
			//con = conPool.getConnection();
			con.setAutoCommit(false);


			String	query = "update CRBT_RBT set MASKED_NAME = initcap(?), FILE_PATH = ?, CREATE_DATE = sysdate, IVR_FILEPATH = ?, PLAYABLE = ?, SHOW_ON_WEB = ?, SHOW_IN_SMS = ?, CONTENT_PROVIDER_CODE = ?, CAT_ID = ?, IMAGE_PATH=? where RBT_CODE = ?";
			logger.info("Update uery = "+query);

			pstmt = con.prepareStatement(query);
			pstmt.setString(1, mname.trim().toUpperCase());
			pstmt.setString(2, musicpath.trim());
			//			pstmt.setInt(3, score);
			pstmt.setString(3, ivrPath.trim());
			pstmt.setString(4, play.trim());
			pstmt.setString(5, web.trim());
			pstmt.setString(6, sms.trim());
			pstmt.setInt(7, cpCode);
			pstmt.setInt(8, catId);
			pstmt.setString(9,imageFile);
			pstmt.setInt(10, rbtId);
			
			pstmt.executeUpdate();
			/*
			   query = "update CRBT_RBT_approve_pending set MASKED_NAME = ?, FILE_PATH = ?, CREATE_DATE = sysdate, IVR_FILEPATH = ?, RBT_NICK = ?, PLAYABLE = ?, SHOW_ON_WEB = ?, SHOW_IN_SMS = ?, CONTENT_PROVIDER_CODE = ?, CAT_ID = ? where RBT_CODE = ?";
			   pstmt = con.prepareStatement(query);
			   pstmt.setString(1, mname.trim());
			   pstmt.setString(2, musicpath);
			//                      pstmt.setInt(3, score);
			pstmt.setString(3, ivrPath);
			pstmt.setString(4, nick);
			pstmt.setString(5, play);
			pstmt.setString(6, web);
			pstmt.setString(7, sms);
			pstmt.setInt(8, cpCode);
			pstmt.setInt(9, catId);
			pstmt.setInt(10, rbtId);
			pstmt.executeUpdate();
			 */
			pstmt.close();				
			con.commit();			
			return CrbtErrorCodes.SUCCESS;
		}
		catch (Exception exp)
		{
			logger.error("Exception in modifyDefaultRbt"+exp);
			exp.printStackTrace();
			try {
				con.rollback();
			}	catch (Exception e){
				e.printStackTrace();
			}			
			return CrbtErrorCodes.FAILURE;
		}
}//modifyDefaultRbt





	public int modifyRbt(String mname, int rbtId, String ivrPath, String musicpath, String nokia, String others, int score, String play, int cpCode, String web, String sms,int catId, long corpId,SubscriberProfile sub,String isApproved,String artName,String imageFile,Connection con)
	{	
		logger.info("in modifyRbt():"+mname+ " ," +rbtId+ " , "+ivrPath+" , "+musicpath+" , "+nokia+" , "+others+" , "+score+" , "+play+" , "+cpCode+" , "+web+ " , "+ sms+" , "+catId+" , "+corpId+" , "+isApproved+" , "+artName+"imagefile ["+imageFile+"]");
		boolean ISAPPROVED=false;
		boolean toExit=false;

		try
		{
			ISAPPROVED=(isApproved.equalsIgnoreCase("false"))?false:true;			
			//con = conPool.getConnection();
			con.setAutoCommit(false);
			String mname1=mname.toLowerCase(); // make sure case is correct
			//	mname=mname.toLowerCase(); // make sure case is correct
			String query = "select MASKED_NAME, RBT_CODE from CRBT_RBT where lower(MASKED_NAME) = ? or upper(MASKED_NAME)=? union  select MASKED_NAME, RBT_CODE from CRBT_RBT_APPROVE_PENDING where lower(MASKED_NAME) = ? or upper(MASKED_NAME)=?  ";
			logger.info("Select Query = "+query);
			pstmt = con.prepareStatement(query);
			pstmt.setString(1,mname1);
			pstmt.setString(2,mname1);
			pstmt.setString(3,mname1);
			pstmt.setString(4,mname1);
			rs = pstmt.executeQuery();			
			
			if(rs.next())
			{
				if (!(rs.getInt(2) == rbtId))
				{
					rs.close();
					pstmt.close();
					return CrbtErrorCodes.RBT_ALREADY_EXISTS;
				}
			}
			else
			{
				logger.info("No data found in crbt_rbt_approve_pending for query so check it");
			}
			rs.close();
			pstmt.close();
			
			//Start of updated by MoHit for SUDAN 30 Dec 14
			logger.info("setting charging code ["+sub.getChgCode()+"] differential charging= ["+diffRbtChg+"]");
			//Query updated by MoHit 28 Jan 2015 for QCELL (initcap is added)
			if(diffRbtChg==1)
			{
				if(!ISAPPROVED)
				{
					query = "update CRBT_RBT_APPROVE_PENDING  set MASKED_NAME = initcap(?), FILE_PATH = ?, CREATE_DATE = sysdate, RBT_SCORE = ?, IVR_FILEPATH = ?, PLAYABLE = ?, SHOW_ON_WEB = ?, SHOW_IN_SMS = ?, CONTENT_PROVIDER_CODE = ?, CAT_ID = ?, CORP_ID=?,ARTIST_NAME= initcap(?),IMAGE_PATH=?, CHARGING_CODE=? where RBT_CODE = ?";
				}
				else
				{
					query = "update CRBT_RBT set MASKED_NAME = initcap(?), FILE_PATH = ?, CREATE_DATE = sysdate, RBT_SCORE = ?, IVR_FILEPATH = ?, PLAYABLE = ?, SHOW_ON_WEB = ?, SHOW_IN_SMS = ?, CONTENT_PROVIDER_CODE = ?, CAT_ID = ?, CORP_ID=?,ARTIST_NAME= initcap(?),IMAGE_PATH=?,CHARGING_CODE=? where RBT_CODE = ?";
				}
			}
			else
			{
				if(!ISAPPROVED)

				{
					
					query = "update CRBT_RBT_APPROVE_PENDING  set MASKED_NAME = initcap(?), FILE_PATH = ?, CREATE_DATE = sysdate, RBT_SCORE = ?, IVR_FILEPATH = ?, PLAYABLE = ?, SHOW_ON_WEB = ?, SHOW_IN_SMS = ?, CONTENT_PROVIDER_CODE = ?, CAT_ID = ?, CORP_ID=?,ARTIST_NAME= initcap(?),IMAGE_PATH=? where RBT_CODE = ?";

				}					
				else
				{
					query = "update CRBT_RBT set MASKED_NAME = initcap(?), FILE_PATH = ?, CREATE_DATE = sysdate, RBT_SCORE = ?, IVR_FILEPATH = ?, PLAYABLE = ?, SHOW_ON_WEB = ?, SHOW_IN_SMS = ?, CONTENT_PROVIDER_CODE = ?, CAT_ID = ?, CORP_ID=?,ARTIST_NAME= initcap(?),IMAGE_PATH=? where RBT_CODE = ?";
				}
			}			
			logger.info("Update Query = "+query);
			pstmt = con.prepareStatement(query);

			pstmt.setString(1, mname.trim().toUpperCase());
			pstmt.setString(2, musicpath.trim());
			pstmt.setInt(3, score);
			pstmt.setString(4, ivrPath.trim());
			pstmt.setString(5, play.trim());
			pstmt.setString(6, web.trim());
			pstmt.setString(7, sms.trim());
			pstmt.setInt(8, cpCode);
			pstmt.setInt(9, catId);
			pstmt.setLong(10, corpId);
			pstmt.setString(11,artName.trim());
			pstmt.setString(12, imageFile);
			
			if(diffRbtChg==1)
			{
				pstmt.setInt(13,sub.getChgCode());
				pstmt.setInt(14, rbtId);
			}
			else
			{

				pstmt.setInt(13, rbtId);
			}
			
			//End of updated by MoHit for SUDAN 30 Dec 14

			
			//			if(!ISAPPROVED)
			//			{
			//				query = "update CRBT_RBT_approve_pending set MASKED_NAME = ?, FILE_PATH = ?, CREATE_DATE = sysdate, RBT_SCORE = ?, IVR_FILEPATH = ?, RBT_NICK = ?, PLAYABLE = ?, SHOW_ON_WEB = ?, SHOW_IN_SMS = ?, CONTENT_PROVIDER_CODE = ?, CAT_ID = ?, CORP_ID=?, ARTIST_NAME= ? where RBT_CODE = ?";
			//			}
			//			else
			//			{
			//
			//				query = "update CRBT_RBT set MASKED_NAME = ?, FILE_PATH = ?, CREATE_DATE = sysdate, RBT_SCORE = ?, IVR_FILEPATH = ?, RBT_NICK = ?, PLAYABLE = ?, SHOW_ON_WEB = ?, SHOW_IN_SMS = ?, CONTENT_PROVIDER_CODE = ?, CAT_ID = ?, CORP_ID=? ,ARTIST_NAME= ? where RBT_CODE = ?";
			//			}
			//			pstmt = con.prepareStatement(query);
			//
			//			pstmt.setString(1, mname.trim());
			//			pstmt.setString(2, musicpath);
			//			pstmt.setInt(3, score);
			//			pstmt.setString(4, ivrPath);
			//			pstmt.setString(5, nick);
			//			pstmt.setString(6, play);
			//			pstmt.setString(7, web);
			//			pstmt.setString(8, sms);
			//			logger.info(query);
			//			pstmt.setInt(9, cpCode);
			//			pstmt.setInt(10, catId);
			//			pstmt.setLong(11, corpId);
			//			pstmt.setString(12,artName);
			//			pstmt.setInt(13, rbtId);
			//
			//			System.out.println(query+"result---->  "+pstmt.executeUpdate());
			//			logger.info(query);
			
			pstmt.executeUpdate(); //added by harjinder on 14-july			
			pstmt.close();

//			query = "update CRBT_MONOTONE_MASTER set RINGTONE_DATA = ? where RBT_CODE = ? and RINGTONE_TYPE = ?";
//			logger.info("query = "+query);
//			pstmt = con.prepareStatement(query);

//			String queryInsert = "insert into CRBT_MONOTONE_MASTER(RBT_CODE, RINGTONE_TYPE, RINGTONE_DATA) values(?, ?, ?)";
//			logger.info("queryInsert = "+queryInsert);
//			logger.info("nokia= "+nokia+" others="+ others);
//			System.out.println("nokia= "+nokia+" others="+ others);
//			nokia = nokia.trim();
//			others = others.trim();
//			int isnokia = 0;
//			int isother = 0;
//
//			if ((nokia != null) && !(nokia.equals("")))
//			{
//				logger.info("nokia= "+nokia+" others="+ others);
//				System.out.println("nokia= "+nokia+" others="+ others);
//				pstmt.setString(1, nokia);
//				pstmt.setInt(2, rbtId);
//				pstmt.setString(3, "nokia");
//
//				if (pstmt.executeUpdate() >= 1)
//				{
//				}
//				else
//				{
//					PreparedStatement pstmtInsert = con.prepareStatement(queryInsert);
//					pstmtInsert.setInt(1, rbtId);
//					pstmtInsert.setString(2, "nokia");					
//					pstmtInsert.setString(3, nokia);
//					System.out.println(queryInsert+"result---->  "+pstmtInsert.executeUpdate());	
//					logger.info(queryInsert);
//					pstmtInsert.close();
//					isnokia = 1;	
//				}
//				logger.info(query);
//				System.out.println(query);
//			}
//
//			if ((others != null) && !(others.equals("")))
//			{
//				pstmt.setString(1, others);
//				pstmt.setInt(2, rbtId);
//				pstmt.setString(3, "others");
//
//				if (pstmt.executeUpdate() >= 1)
//				{
//				}
//				else
//				{
//					PreparedStatement pstmtInsert = con.prepareStatement(queryInsert);
//					pstmtInsert.setInt(1, rbtId);
//					pstmtInsert.setString(2, "others");	
//					pstmtInsert.setString(3, others);
//					System.out.println(queryInsert+"result---->  "+pstmtInsert.executeUpdate());	
//					pstmtInsert.close();
//					isother = 1;
//				}
//			}
//			pstmt.close();
			String querylog="insert into crbt_rbt_logs (rbt_code,masked_name,update_time,cat_id,corp_id,cp_code,op_code,ARTIST_NAME,description,updated_by) values(?,initcap(?),sysdate,?,0,?,2,initcap(?),'Rbt Modified',?)";
			logger.info("Insert querylog = "+querylog);
			PreparedStatement pstmtInsert = con.prepareStatement(querylog);
			pstmtInsert.setInt(1, rbtId);
			pstmtInsert.setString(2, mname.trim());	
			pstmtInsert.setInt(3, catId);
			pstmtInsert.setInt(4, cpCode);
			pstmtInsert.setString(5,artName.trim());
			pstmtInsert.setString(6, sub.getUsername().trim());
				
			pstmtInsert.executeUpdate();//added by harjinder on 14-july
			pstmtInsert.close();
//			if (isnokia == 1)
//			{
//				if(!ISAPPROVED)
//					query = "update CRBT_RBT_approve_pending set NOKIA = 1 where RBT_CODE = ?";
//				else
//					query = "update CRBT_RBT set NOKIA = 1 where RBT_CODE = ?";
//				pstmt = con.prepareStatement(query);
//				pstmt.setInt(1, rbtId);
//				pstmt.executeUpdate();
//				logger.info(query);
//				System.out.println(query);
//			}
//			if (isother == 1)
//			{
//				if(!ISAPPROVED)
//					query = "update CRBT_RBT_approve_pending set OTHER = 1 where RBT_CODE = ?";
//				else
//					query = "update CRBT_RBT set OTHER = 1 where RBT_CODE = ?";
//				pstmt = con.prepareStatement(query);
//				pstmt.setInt(1, rbtId);
//				pstmt.executeUpdate();
//				logger.info(query);
//				System.out.println(query);
//			}
//			pstmt.close();
			con.commit();			
			return CrbtErrorCodes.SUCCESS;
		}
		catch (Exception exp)
		{
			logger.error("Exception in modifyRbt():"+exp);
			exp.printStackTrace();
			try {
				con.rollback();
			}	catch (Exception e) {
				e.printStackTrace();
			}
			return CrbtErrorCodes.FAILURE;
		}
}//modifyRbt() ends


public int deleteRbt(int rbtId,String mname,int catId,int cpCode,SubscriberProfile sub,Connection con)
{
		logger.info("In deleteRbt() with rbtId:"+rbtId+", mname:"+mname+", catId:"+catId+", cpCode:"+cpCode);
		ResultSet rs=null;
		boolean isApproved=false;
		int rbtCode =-1;
		String query = null;
		int delCount=-1;
		try
		{     
			isApproved=true; //isApproved=true means rbt lies in CRBT_RBT
			rbtCode=Integer.parseInt(TSSJavaUtil.instance().getAppConfigParam("DEFAULT_RBT"));
			//con = conPool.getConnection();
			con.setAutoCommit(false);
			pstmt = null;			

			query="delete from crbt_rbt_approve_pending where RBT_CODE = ?";
			logger.info("Select Query = "+query);
			pstmt = con.prepareStatement(query);
			pstmt.setInt(1,rbtId);
			delCount=pstmt.executeUpdate();
			logger.info("Total RbtDeleted from CRBT_RBT_approve_pending "+delCount);  
			if(delCount>=1)
			{
				isApproved=false;
			}				
			pstmt.close();

			if(isApproved)
			{ 
				query = "update CRBT_SUBSCRIBER_MASTER set RBT_CODE = ? where RBT_CODE = ?";
				logger.info("Select Query = "+query);
				pstmt = con.prepareStatement(query);
				pstmt.setInt(1, rbtCode);
				pstmt.setInt(2, rbtId);
				pstmt.executeUpdate();

				query = "update CRBT_DEFAULT_DETAIL set RBT_CODE = ? where DAY='8' and START_AT='2500' and ENDS_AT='2500' and RBT_CODE = ?";
				logger.info("Select Query = "+query);
				pstmt = con.prepareStatement(query);
				pstmt.setInt(1, rbtCode);
				pstmt.setInt(2, rbtId);
				pstmt.executeUpdate();
//				query = "delete from CRBT_MONOTONE_MASTER cascade where RBT_CODE = ?";
//				logger.info("query = "+query);
//				pstmt = con.prepareStatement(query);
//				pstmt.setInt(1, rbtId);
//				pstmt.executeUpdate();
				query = "delete from CRBT_RBT cascade where RBT_CODE = ?";
				logger.info("Delete Query = "+query);
				pstmt = con.prepareStatement(query);
				pstmt.setInt(1, rbtId);
				pstmt.executeUpdate();
				pstmt.close();
			}
			String querylog="insert into crbt_rbt_logs (rbt_code,masked_name,update_time,cat_id,corp_id,cp_code,op_code,description,updated_by) values(?,?,sysdate,?,0,?,3,'Rbt Deleted',?)";
			logger.info("Insert querylog = "+querylog);
			PreparedStatement pstmtInsert = con.prepareStatement(querylog);
			pstmtInsert.setInt(1, rbtId);
			pstmtInsert.setString(2, mname.trim());	
			pstmtInsert.setInt(3, catId);
			pstmtInsert.setInt(4, cpCode);
			pstmtInsert.setString(5, sub.getUsername().trim());
			pstmtInsert.executeUpdate();	
			pstmtInsert.close();

			con.commit();			
			return CrbtErrorCodes.SUCCESS;
		}
		catch (Exception exp)
		{
			logger.error("Exception in deleteRbt():"+exp);
			exp.printStackTrace();
			try {
				con.rollback();
			}	catch (Exception e) {
				e.printStackTrace();
			}			
			return CrbtErrorCodes.FAILURE;
		}
}//deleteRbt() ends


	public int playRbt(String musicPath, Writer out)
	{
		logger.info("In playRbt() with musicPath:"+musicPath);
		try
		{
			File filename = new File(musicPath);
			FileInputStream fis = new FileInputStream(filename);
			logger.info("Total file size to read (in bytes) : "+fis.available());
			int i = fis.read();
			int count=i;
			while(i != -1)
			{
				out.write(i);
				i = fis.read();
				count+=i;
			}
			fis.close();
		}
		catch(FileNotFoundException fne )
		{
			logger.error("Error Rbt File Not Found on Path:"+musicPath+", check it: "+fne);
			fne.printStackTrace();
			return CrbtErrorCodes.FILE_NOT_FOUND;
		}
		catch(Exception e)
		{
			logger.error("Error in playRbt():"+e);
			e.printStackTrace();
			return CrbtErrorCodes.FAILURE;
		}
		return CrbtErrorCodes.SUCCESS;	
}// playRbt() ENDS

public int getRbtDetails(Rbt rbt,Connection con)
{
	logger.info("In getRbtDetails()....");
	int advcatId=-1;
		try
		{
			advcatId =Integer.parseInt(TSSJavaUtil.instance().getAppConfigParam("ADVERTISEMENT_CAT_ID"));
			String query = "select * from (select RBT_CODE,MASKED_NAME, FILE_PATH, RBT_SCORE, IVR_FILEPATH, RBT_NICK, PLAYABLE, SHOW_ON_WEB, SHOW_IN_SMS, " +
					"CONTENT_PROVIDER_CODE, CAT_ID,CHARGING_CODE, CORP_ID ,ARTIST_NAME,IMAGE_PATH,'YES' as VALID from CRBT_RBT UNION" +
					" select RBT_CODE,MASKED_NAME, FILE_PATH, RBT_SCORE, IVR_FILEPATH, RBT_NICK, PLAYABLE, SHOW_ON_WEB, SHOW_IN_SMS, CONTENT_PROVIDER_CODE, CAT_ID," +

					"CHARGING_CODE, CORP_ID ,ARTIST_NAME,IMAGE_PATH,'NO' as VALID  from CRBT_RBT_approve_pending) where RBT_CODE = ? ";
			logger.info("query = "+query);

			pstmt = con.prepareStatement(query);
			pstmt.setInt(1, rbt.getRbtId());
			rs = pstmt.executeQuery();
			if(rs.next())
			{	
				if(advcatId!=rs.getInt("CAT_ID"))
				{	
					rbt.setRbtMaskName(rs.getString("MASKED_NAME"));					
					rbt.setMusicPath(rs.getString("FILE_PATH"));
					rbt.setScore(rs.getInt("RBT_SCORE"));
					rbt.setIvrFileName(rs.getString("IVR_FILEPATH"));
					rbt.setNickname(rs.getString("RBT_NICK"));
					rbt.setPlayable(rs.getString("PLAYABLE"));
					rbt.setShowweb(rs.getString("SHOW_ON_WEB"));
					rbt.setShowsms(rs.getString("SHOW_IN_SMS"));
					rbt.setContentProviderCode(rs.getInt("CONTENT_PROVIDER_CODE"));
					rbt.setCatId(rs.getInt("CAT_ID"));					
					rbt.setChgCode(rs.getInt("CHARGING_CODE"));	
					rbt.setCorpId(rs.getLong("CORP_ID"));
					rbt.setApproved(rs.getString("VALID"));

					rbt.setArtName(rs.getString("ARTIST_NAME"));  
					rbt.setImagePath(rs.getString("IMAGE_PATH"));			

				}
				else
				{	
					rs.close();
					pstmt.close();	
					query = "select a.MASKED_NAME,a.ARTIST_NAME, a.FILE_PATH, a.RBT_SCORE, a.IVR_FILEPATH, a.RBT_NICK, a.PLAYABLE, a.SHOW_ON_WEB, " +
							"a.SHOW_IN_SMS, a.CONTENT_PROVIDER_CODE, a.CAT_ID, a.CORP_ID,a.IMAGE_PATH,b.AMOUNT_PRE,b.AMOUNT_POST,b.CHARGING_CODE,b.DESCRIPTION ," +
							"a.VALID AS VALID from (select RBT_CODE,MASKED_NAME,FILE_PATH,RBT_SCORE,IVR_FILEPATH,RBT_NICK,PLAYABLE,SHOW_ON_WEB,SHOW_IN_SMS," +
							"CONTENT_PROVIDER_CODE,CAT_ID,CORP_ID,CHARGING_CODE ,ARTIST_NAME,IMAGE_PATH,'YES' as VALID from CRBT_RBT UNION " +
							"select RBT_CODE,MASKED_NAME,FILE_PATH,RBT_SCORE,IVR_FILEPATH,RBT_NICK,PLAYABLE,SHOW_ON_WEB,SHOW_IN_SMS,CONTENT_PROVIDER_CODE,CAT_ID," +
							"CORP_ID,CHARGING_CODE,ARTIST_NAME,IMAGE_PATH,'NO' as VALID  from CRBT_RBT_approve_pending )a, CRBT_CHARGING_CODE b " +
							" where RBT_CODE = ? and a.CHARGING_CODE=b.CHARGING_CODE";
					pstmt = con.prepareStatement(query);
					logger.info("Select Query:"+query);
					pstmt.setInt(1, rbt.getRbtId());
					rs = pstmt.executeQuery();
					if(rs.next())
					{	
						rbt.setRbtMaskName(rs.getString("MASKED_NAME"));
						rbt.setMusicPath(rs.getString("FILE_PATH"));
						rbt.setScore(rs.getInt("RBT_SCORE"));
						rbt.setIvrFileName(rs.getString("IVR_FILEPATH"));
						rbt.setNickname(rs.getString("RBT_NICK"));
						rbt.setPlayable(rs.getString("PLAYABLE"));
						rbt.setShowweb(rs.getString("SHOW_ON_WEB"));
						rbt.setShowsms(rs.getString("SHOW_IN_SMS"));
						rbt.setContentProviderCode(rs.getInt("CONTENT_PROVIDER_CODE"));
						rbt.setCatId(rs.getInt("CAT_ID"));
						rbt.setCorpId(rs.getLong("CORP_ID"));
						rbt.setPreCost(rs.getDouble("AMOUNT_PRE"));
						rbt.setPostCost(rs.getDouble("AMOUNT_POST"));						
						rbt.setChgCode(rs.getInt("CHARGING_CODE"));
						rbt.setChgdesc(rs.getString("DESCRIPTION"));
						rbt.setApproved(rs.getString("VALID"));
						rbt.setArtName(rs.getString("ARTIST_NAME"));
						rbt.setImagePath(rs.getString("IMAGE_PATH"));
					}
				}
			}
			rs.close();
			pstmt.close();
//			query = "select RINGTONE_DATA from CRBT_MONOTONE_MASTER where RBT_CODE = ? and RINGTONE_TYPE = ?";
//			pstmt = con.prepareStatement(query);
//
//			pstmt.setInt(1, rbt.getRbtId());
//			pstmt.setString(2, "nokia");
//
//			rs = pstmt.executeQuery();
//
//			if (rs.next())
//			{
//				rbt.setNokia(rs.getString("RINGTONE_DATA"));
//			}
//
//			pstmt.setInt(1, rbt.getRbtId());
//			pstmt.setString(2, "others");
//
//			rs = pstmt.executeQuery();
//
//			if (rs.next())
//			{
//				rbt.setOthers(rs.getString("RINGTONE_DATA"));
//			}
//			System.out.println("RBT---------->  "+rbt);
//			pstmt.close();	
			con.commit();			
			return CrbtErrorCodes.SUCCESS;
		}
		catch (Exception exp)
		{
			logger.error("Error in getRbtDetails():"+exp);
			exp.printStackTrace();
			return CrbtErrorCodes.FAILURE;
		}
}//getRbtDetails() ends


	//select queries changed by vpsingh on 15-june to get approved_by as approved from crbt_rbt and rejected_by as approved from crbt_rbt_approve_pending only
public int searchRbtByCode(String rbtName,String rbtCode , int catId, int cpId, ArrayList rbtList, int pageno,String artName,Connection con)
{	
		logger.info("In searchRbtByCode() rbtname ["+rbtName+"] rbtcode ["+rbtCode+"] catId ["+catId+"] cpId ["+cpId+"] pageNo ["+pageno+"] artistName ["+artName+"] con ["+con+"]");			
		int srow = pageno*10;
		int erow = srow+11;
		//Connection con = null;
		PreparedStatement pstmt1=null;
		PreparedStatement pstmt2=null;
		String query = null;
		String cquery = null;
		String specialCatId ="998";
		String recordedCatId="999";
		int ret = -1;
		int advcatIdenable=-1;
		int catIdParam=-1;
		try
		{
			//con = conPool.getConnection();
			 //int advcatIdenable=TSSJavaUtil.instance().advcatidenable;											//have to look here 
			 advcatIdenable=Integer.parseInt(TSSJavaUtil.instance().getKeyValue("ADVERTISEMENT_CAT_ID_ENABLE"));//corrected by vpsingh
			 catIdParam=Integer.parseInt(TSSJavaUtil.instance().getAppConfigParam("ADVERTISEMENT_CAT_ID"));	       
			specialCatId   = TSSJavaUtil.instance().getAppConfigParam("SPECIAL_CONTROL_CATID");
			recordedCatId  = TSSJavaUtil.instance().getAppConfigParam("CRBT_RECORDED_CATEGORY_ID");
			if (catId == -1 && cpId == -1)
			{
				//logger.info("<---in catId & cpId=-1---->");				
				//query = "select * from (select RBT_CODE, MASKED_NAME,ARTIST_NAME, RBT_NICK, CAT_ID,valid, ROWNUM ROW_NUMBER from (select * from (select CREATE_DATE,RBT_CODE, MASKED_NAME, RBT_NICK, CAT_ID,ARTIST_NAME,'YES' as valid from CRBT_RBT UNION select CREATE_DATE,RBT_CODE, MASKED_NAME, RBT_NICK, CAT_ID,ARTIST_NAME,'NO' as valid from CRBT_RBT_approve_pending) where UPPER(MASKED_NAME) like ? and TO_CHAR(RBT_CODE) like ? and UPPER(ARTIST_NAME) like ? and RBT_CODE not in (select RBT_CODE from CRBT_RBT_CONTROL) and not(CAT_ID = ?) and not(CAT_ID = ?) order by CREATE_DATE desc) where ROWNUM < ?) where ROW_NUMBER > ?";
				query = "select * from (select RBT_CODE, MASKED_NAME,ARTIST_NAME, RBT_NICK, CAT_ID,approved,valid, ROWNUM ROW_NUMBER from (select * from (select CREATE_DATE,RBT_CODE, MASKED_NAME, RBT_NICK, CAT_ID,ARTIST_NAME,APPROVED_BY as approved,'YES' as valid from CRBT_RBT UNION select CREATE_DATE,RBT_CODE, MASKED_NAME, RBT_NICK, CAT_ID,ARTIST_NAME,REJECTED_BY as approved,'NO' as valid from CRBT_RBT_approve_pending) where UPPER(MASKED_NAME) like ? and TO_CHAR(RBT_CODE) like ? and UPPER(ARTIST_NAME) like ? and RBT_CODE not in (select RBT_CODE from CRBT_RBT_CONTROL) and not(CAT_ID = ?) and not(CAT_ID = ?) order by CREATE_DATE desc) where ROWNUM < ?) where ROW_NUMBER > ?";
				pstmt1 = con.prepareStatement(query);
				pstmt1.setString(1,"%"+rbtName+"%");
				pstmt1.setString(2,"%"+rbtCode+"%");
				pstmt1.setString(3,"%"+artName+"%");
				pstmt1.setString(4, recordedCatId);
				pstmt1.setString(5, specialCatId);
				pstmt1.setInt(6,erow);
				pstmt1.setInt(7,srow);

				cquery = "select count(RBT_CODE) TOTAL from (select RBT_CODE,CAT_ID,MASKED_NAME,ARTIST_NAME from CRBT_RBT UNION select RBT_CODE,CAT_ID,MASKED_NAME,ARTIST_NAME from CRBT_RBT_approve_pending) where UPPER(MASKED_NAME) like ? and RBT_CODE like ? and UPPER(ARTIST_NAME) like ?  and RBT_CODE not in(select RBT_CODE from CRBT_RBT_CONTROL) and not(CAT_ID=?) and not(CAT_ID=?)";
				pstmt2 = con.prepareStatement(cquery);
				pstmt2.setString(1,"%"+rbtName+"%");
				pstmt2.setString(2,"%"+rbtCode+"%");
				pstmt2.setString(3,"%"+artName+"%");
				pstmt2.setString(4, recordedCatId);
				pstmt2.setString(5, specialCatId);
			}
			else if (cpId == -1)
			{
				//logger.info("in cpId==-1=====>");				
				//query = "select * from (select RBT_CODE, MASKED_NAME,ARTIST_NAME, RBT_NICK, CAT_ID,valid, ROWNUM ROW_NUMBER from ( select * from (select CREATE_DATE,RBT_CODE, MASKED_NAME, RBT_NICK, CAT_ID,ARTIST_NAME,'YES' as valid from CRBT_RBT UNION select CREATE_DATE,RBT_CODE, MASKED_NAME,RBT_NICK, CAT_ID,ARTIST_NAME,'NO' as  valid from CRBT_RBT_approve_pending) where UPPER(MASKED_NAME) like ? and TO_CHAR(RBT_CODE) like ? and UPPER(ARTIST_NAME) like ? and RBT_CODE not in (select RBT_CODE from CRBT_RBT_CONTROL) and CAT_ID = ? order by CREATE_DATE desc) where ROWNUM < ?) where ROW_NUMBER > ?";
				query = "select * from (select RBT_CODE, MASKED_NAME,ARTIST_NAME, RBT_NICK, CAT_ID,approved,valid, ROWNUM ROW_NUMBER from ( select * from (select CREATE_DATE,RBT_CODE, MASKED_NAME, RBT_NICK, CAT_ID,ARTIST_NAME,APPROVED_BY as approved,'YES' as valid from CRBT_RBT UNION select CREATE_DATE,RBT_CODE, MASKED_NAME,RBT_NICK, CAT_ID,ARTIST_NAME,REJECTED_BY as approved,'NO' as  valid from CRBT_RBT_approve_pending) where UPPER(MASKED_NAME) like ? and TO_CHAR(RBT_CODE) like ? and UPPER(ARTIST_NAME) like ? and RBT_CODE not in (select RBT_CODE from CRBT_RBT_CONTROL) and CAT_ID = ? order by CREATE_DATE desc) where ROWNUM < ?) where ROW_NUMBER > ?";
				pstmt1 = con.prepareStatement(query);
				pstmt1.setString(1,"%"+rbtName+"%");
				pstmt1.setString(2,"%"+rbtCode+"%");
				pstmt1.setString(3,"%"+artName+"%");
				pstmt1.setInt(4, catId);
				pstmt1.setInt(5,erow);
				pstmt1.setInt(6,srow);

				cquery = "select count(RBT_CODE) TOTAL from (select RBT_CODE,CAT_ID,MASKED_NAME,ARTIST_NAME from CRBT_RBT UNION select RBT_CODE,CAT_ID,MASKED_NAME,ARTIST_NAME from CRBT_RBT_approve_pending )where UPPER(MASKED_NAME) like ? and RBT_CODE like ? and UPPER(ARTIST_NAME) like ?  and RBT_CODE not in(select RBT_CODE from CRBT_RBT_CONTROL) and CAT_ID=?";
				pstmt2 = con.prepareStatement(cquery);
				pstmt2.setString(1,"%"+rbtName+"%");
				pstmt2.setString(2,"%"+rbtCode+"%");
				pstmt2.setString(3,"%"+artName+"%");
				pstmt2.setInt(4, catId);
			}

			else if (catId == -1)
			{
				//logger.info("in catId=-2 --------->");				
				//query = "select * from (select RBT_CODE, MASKED_NAME,ARTIST_NAME, RBT_NICK, CAT_ID,VALID, ROWNUM ROW_NUMBER from ( select * from (select CREATE_DATE,RBT_CODE, MASKED_NAME, RBT_NICK, CAT_ID,ARTIST_NAME,'YES' as valid,CONTENT_PROVIDER_CODE from CRBT_RBT UNION select CREATE_DATE,RBT_CODE, MASKED_NAME, RBT_NICK, CAT_ID,ARTIST_NAME,'NO' as  valid,CONTENT_PROVIDER_CODE from CRBT_RBT_approve_pending) where UPPER(MASKED_NAME) like ? and TO_CHAR(RBT_CODE)like ? and UPPER(ARTIST_NAME) like ? and RBT_CODE not in (select RBT_CODE from CRBT_RBT_CONTROL) and not(CAT_ID = ?) and not(CAT_ID = ?) and CONTENT_PROVIDER_CODE = ? order by CREATE_DATE desc) where ROWNUM < ?) where ROW_NUMBER > ?";
				query = "select * from (select RBT_CODE, MASKED_NAME,ARTIST_NAME, RBT_NICK, CAT_ID,approved,VALID, ROWNUM ROW_NUMBER from ( select * from (select CREATE_DATE,RBT_CODE, MASKED_NAME, RBT_NICK, CAT_ID,ARTIST_NAME,APPROVED_BY as approved,'YES' as valid,CONTENT_PROVIDER_CODE from CRBT_RBT UNION select CREATE_DATE,RBT_CODE, MASKED_NAME, RBT_NICK, CAT_ID,ARTIST_NAME,REJECTED_BY as approved,'NO' as  valid,CONTENT_PROVIDER_CODE from CRBT_RBT_approve_pending) where UPPER(MASKED_NAME) like ? and TO_CHAR(RBT_CODE)like ? and UPPER(ARTIST_NAME) like ? and RBT_CODE not in (select RBT_CODE from CRBT_RBT_CONTROL) and not(CAT_ID = ?) and not(CAT_ID = ?) and CONTENT_PROVIDER_CODE = ? order by CREATE_DATE desc) where ROWNUM < ?) where ROW_NUMBER > ?";
				pstmt1 = con.prepareStatement(query);
				pstmt1.setString(1,"%"+rbtName+"%");
				pstmt1.setString(2,"%"+rbtCode+"%");
				pstmt1.setString(3,"%"+artName+"%");
				pstmt1.setString(4, recordedCatId);
				pstmt1.setString(5, specialCatId);
				pstmt1.setInt(6,cpId);
				pstmt1.setInt(7,erow);
				pstmt1.setInt(8,srow);

				cquery = "select count(RBT_CODE) TOTAL from (select RBT_CODE,CONTENT_PROVIDER_CODE,CAT_ID,MASKED_NAME,ARTIST_NAME from CRBT_RBT UNION select RBT_CODE,CONTENT_PROVIDER_CODE,CAT_ID,MASKED_NAME,ARTIST_NAME from CRBT_RBT_approve_pending ) where UPPER(MASKED_NAME) like ?  and RBT_CODE like ? and UPPER(ARTIST_NAME) like ?  and RBT_CODE not in(select RBT_CODE from CRBT_RBT_CONTROL) and not(CAT_ID=?) and not(CAT_ID=?) and CONTENT_PROVIDER_CODE = ?";
				pstmt2 = con.prepareStatement(cquery);
				pstmt2.setString(1,"%"+rbtName+"%");
				pstmt2.setString(2,"%"+rbtCode+"%");
				pstmt2.setString(3,"%"+artName+"%");
				pstmt2.setString(4, recordedCatId);
				pstmt2.setString(5, specialCatId);
				pstmt2.setInt(6, cpId);
			}
			else
			{
				//logger.info("In else statement--------------->");				
				//query = "select * from (select RBT_CODE, MASKED_NAME,ARTIST_NAME, RBT_NICK, CAT_ID,VALID, ROWNUM ROW_NUMBER from ( select * from (select CREATE_DATE,RBT_CODE, MASKED_NAME, RBT_NICK, CAT_ID,ARTIST_NAME,'YES' as valid,CONTENT_PROVIDER_CODE from CRBT_RBT UNION select CREATE_DATE,RBT_CODE, MASKED_NAME, RBT_NICK, CAT_ID,ARTIST_NAME,'NO' as  valid,CONTENT_PROVIDER_CODE from CRBT_RBT_approve_pending )where UPPER(MASKED_NAME) like ? and TO_CHAR(RBT_CODE) like ? and UPPER(ARTIST_NAME) like ? and RBT_CODE not in (select RBT_CODE from CRBT_RBT_CONTROL) and CAT_ID = ? and CONTENT_PROVIDER_CODE = ? order by CREATE_DATE desc) where ROWNUM < ?) where ROW_NUMBER > ?";
				query = "select * from (select RBT_CODE, MASKED_NAME,ARTIST_NAME, RBT_NICK, CAT_ID,approved,VALID, ROWNUM ROW_NUMBER from ( select * from (select CREATE_DATE,RBT_CODE, MASKED_NAME, RBT_NICK, CAT_ID,ARTIST_NAME,APPROVED_BY as approved,'YES' as valid,CONTENT_PROVIDER_CODE from CRBT_RBT UNION select CREATE_DATE,RBT_CODE, MASKED_NAME, RBT_NICK, CAT_ID,ARTIST_NAME,REJECTED_BY as approved,'NO' as  valid,CONTENT_PROVIDER_CODE from CRBT_RBT_approve_pending )where UPPER(MASKED_NAME) like ? and TO_CHAR(RBT_CODE) like ? and UPPER(ARTIST_NAME) like ? and RBT_CODE not in (select RBT_CODE from CRBT_RBT_CONTROL) and CAT_ID = ? and CONTENT_PROVIDER_CODE = ? order by CREATE_DATE desc) where ROWNUM < ?) where ROW_NUMBER > ?";
				pstmt1 = con.prepareStatement(query);
				pstmt1.setString(1,"%"+rbtName+"%");
				pstmt1.setString(2,"%"+rbtCode+"%");
				pstmt1.setString(3,"%"+artName+"%");
				pstmt1.setInt(4, catId);
				pstmt1.setInt(5, cpId);
				pstmt1.setInt(6, erow);
				pstmt1.setInt(7, srow);

				cquery = "select count(RBT_CODE) TOTAL from (select RBT_CODE,CONTENT_PROVIDER_CODE,CAT_ID,MASKED_NAME,ARTIST_NAME from CRBT_RBT UNION select RBT_CODE,CONTENT_PROVIDER_CODE,CAT_ID,MASKED_NAME,ARTIST_NAME from CRBT_RBT_approve_pending ) where UPPER(MASKED_NAME) like ? and RBT_CODE like ? and UPPER(ARTIST_NAME)  like ? and RBT_CODE not in(select RBT_CODE from CRBT_RBT_CONTROL) and CAT_ID = ? and CONTENT_PROVIDER_CODE = ?";
				pstmt2 = con.prepareStatement(cquery);
				pstmt2.setString(1,"%"+rbtName+"%");
				pstmt2.setString(2,"%"+rbtCode+"%");
				pstmt2.setString(3,"%"+artName+"%");
				pstmt2.setInt(4, catId);
				pstmt2.setInt(5, cpId);
			}
			logger.info("Select Query===="+query);
			//logger.info("cquery = "+cquery);			
			rs = pstmt1.executeQuery();
			while(rs.next()) {				
				//Rbt rbt = new Rbt(rs.getInt("RBT_CODE"),rs.getString("MASKED_NAME"),rs.getInt("CAT_ID"),rs.getString("VALID"),rs.getString("ARTIST_NAME"));
				//by vps on 15-june
				Rbt rbt = new Rbt(rs.getInt("RBT_CODE"),rs.getString("MASKED_NAME"),rs.getInt("CAT_ID"),rs.getString("VALID"),rs.getString("ARTIST_NAME"),rs.getString("APPROVED"));
				if(advcatIdenable==1)
				{	
				rbtList.add(rbt);				
				}
				else
				{
					if(rbt.getCatId()!=catIdParam)
					{
						rbtList.add(rbt);						
					}
				}	
			}//while ends

			rs = pstmt2.executeQuery();
			if (rs.next())
			{
				ret = rs.getInt("TOTAL");
			}				
			else
			{
				logger.info("no data found from cquery");
			}
			if(rs != null) rs.close();
			if(pstmt1 != null) pstmt1.close();
			if(pstmt2 != null) pstmt2.close();
			return ret;
		}
		catch (SQLException e)
		{
			logger.error("Error In searchRbtByCode() of RBTManager, SQLException :"+e);
			try {
				if(rs != null) rs.close();
				if(pstmt1 != null) pstmt1.close();
				if(pstmt2 != null) pstmt2.close();
			} catch(Exception exp) {}
			e.printStackTrace();
			return -99;
		}
		catch (Exception e)
		{
			logger.error("Error In searchRbtByCode() of RBTManager, Exception :"+e);
			try {
				if(rs != null) rs.close();
				if(pstmt1 != null) pstmt1.close();
				if(pstmt2 != null) pstmt2.close();
			} catch(Exception exp) {}
			e.printStackTrace();
			return -99;
		}
	}//searchRbtByCode() ends


	/* sendPromotionalSMS method is used for sending promotional SMS
	 * added connection Object in this method
	 */
	public int sendPromotionalSMS(String smsText,Connection con)
	{
		logger.info("Inside sendPromotionalSMS() smsText="+smsText);		
		String query=null;
		String query1=null;
		PreparedStatement pstmt1 = null;
		ResultSet rs1 = null;
		try 
		{
			//con = conPool.getConnection();
			con.setAutoCommit(false);
			String sms_origin_number="4444288";
			sms_origin_number= TSSJavaUtil.instance().getAppConfigParam("SMS_ORIGINATION_NUMBER");

			/* start by vpsingh on 22-june bcause it can be fetched from TssJavaUtil.instance
			query="select param_value from CRBT_APP_CONFIG_PARAMS where PARAM_TAG=?";
			logger.info("query = "+query);
			pstmt = con.prepareStatement(query);
			pstmt.setString(1,"SMS_ORIGINATION_NUMBER");

			rs = pstmt.executeQuery();			
			if(rs.next()) 
			{
				sms_origin_number  = rs.getString(1);
				logger.info("SMS_ORIGINATION_NUMBER from crbt_app_config_params = "+sms_origin_number);			
				
			}
			rs.close();
			pstmt.close();
			
			*/			
			query="select msisdn from crbt_subscriber_master";
			logger.info("Select Query = "+query);
			//query="select msisdn from crbt_subscriber_master where msisdn in (18767994347,18767991831)";
			query1= "insert into GMAT_MESSAGE_STORE (RESPONSE_ID, REQUEST_ID, ORIGINATING_NUMBER, DESTINATION_NUMBER, MESSAGE_TEXT, SUBMIT_TIME, STATUS) values (GMAT_RESPONSE_ID_SEQ.nextval, 0, ?, ?, ?, sysdate, ?)";
			logger.info("Insert Query1 = "+query1);
			pstmt = con.prepareStatement(query);
			pstmt1 = con.prepareStatement(query1);
			rs = pstmt.executeQuery();			
			int count=0;
			while (rs.next())
			{
				count++;
				pstmt1.setString(1, sms_origin_number.trim());
				pstmt1.setString(3,  smsText.trim());
				pstmt1.setString(4, "R");
				pstmt1.setString(2, rs.getString(1).trim());
				pstmt1.addBatch();
				if(count%2000==0)
				{
					//System.out.println("count --> "+count);
					//System.out.println("Entry in GMAT_MESSAGE_STORE....");
					pstmt1.executeBatch();
				}
			}
			pstmt1.executeBatch();
			pstmt1.close(); 
			rs.close();
			pstmt.close();
			con.commit();
			return 1;
		}
		catch (Exception e)
		{
			logger.error("Error in sendPromotionalSMS() while sending promotional sms, returns -99:"+e);
			e.printStackTrace();
			try {
				con.rollback();
				if(rs != null) rs.close();
				if(pstmt1 != null) pstmt1.close();
				if(pstmt != null) pstmt.close();
			} catch(Exception exp) {exp.printStackTrace();}
			return -99;
		}
}//sendPromotionalSMS(smsText) ends



	public int sendPromotionSMS(int rbtCode, String mname,Connection con)
	{
		logger.info("In sendPromotionSMS() with rbtCode:"+rbtCode+", mname:"+mname);
		String query="";
		String query1="";
		PreparedStatement pstmt1 = null;
		ResultSet rs1 = null;
		String dest = "1111";
		//String message = "A new blingback tune "+mname+"("+rbtCode+") has been added to the System";
		String MESSAGE_TEXT= "More blingback tunes are available";
		String sms_origin_number="4444288";
		try 
		{
			
			//String Message_Text= "hi! new blingback tune "+mname+" with code "+rbtCode+ "has been added to crbt system";			
			query = "select TEMPLATE_MESSAGE from LBS_TEMPLATES where TEMPLATE_ID = ? and TEMPLATE_TYPE = ? and language_id=?";
			logger.info("Select Query = "+query);
			pstmt = con.prepareStatement(query);
			pstmt.setInt(1, 210);
			pstmt.setInt(2, 10);
			pstmt.setInt(3, 1);
			rs = pstmt.executeQuery();
			if(rs.next()) 
			{
				//String message_string = rs.getString(1);
				MESSAGE_TEXT = rs.getString(1);
				logger.info("MESSAGE_TEXT to Send = "+MESSAGE_TEXT);
				/*	int tempPos = 0;
				tempPos = message_string.indexOf("$(rbt_name)");
				if(tempPos !=-1) 
				{
				Message_Text = message_string.substring(0,tempPos);
				Message_Text = Message_Text + mname;
				}

				int tempPos2 = message_string.indexOf("$(rbt_code)");
				if(tempPos2 !=-1) 
				{
				Message_Text = Message_Text + message_string.substring(tempPos+11, tempPos2);
				Message_Text = Message_Text + rbtCode;
				Message_Text = Message_Text + message_string.substring(tempPos2+11, message_string.length());
				}*/
			} 
			else
			{
				logger.info("\n No template message found from the query so check lbs_template tbl for template_id:210,template_type:10,language_id:1 \n");
			}
			rs.close();
			pstmt.close();			
			
			sms_origin_number=TSSJavaUtil.instance().getAppConfigParam("SMS_ORIGINATION_NUMBER");
			/* by vpsingh because can done with above line
			 * 			
			query="select param_value from CRBT_APP_CONFIG_PARAMS where PARAM_TAG=?";
			pstmt = con.prepareStatement(query);
			pstmt.setString(1,"SMS_ORIGINATION_NUMBER");
			rs = pstmt.executeQuery();
			
			if(rs.next()) 
			{
				sms_origin_number  = rs.getString(1);				
			}
			logger.info("sms_origin_number = "+sms_origin_number);
			System.out.println("org no indirect:"+sms_origin_number);
			rs.close();
			pstmt.close();			
			*/
			
			query="select msisdn from crbt_subscriber_master";
			query1= "insert into GMAT_MESSAGE_STORE (RESPONSE_ID, REQUEST_ID, ORIGINATING_NUMBER, DESTINATION_NUMBER, MESSAGE_TEXT, SUBMIT_TIME, STATUS) values (GMAT_RESPONSE_ID_SEQ.nextval, 0, ?, ?, ?, sysdate, ?)";

			logger.info("query1 = "+query1);

			pstmt = con.prepareStatement(query);
			pstmt1 = con.prepareStatement(query1);

			rs = pstmt.executeQuery();
			while (rs.next())
			{
				pstmt1.setString(1, sms_origin_number.trim());
				pstmt1.setString(3, MESSAGE_TEXT.trim());
				pstmt1.setString(4, "R");
				pstmt1.setString(2, rs.getString(1));
				pstmt1.executeUpdate();           
			}
			pstmt1.close(); 
			rs.close();
			pstmt.close();
			return 1;
		}
		catch (SQLException sqle) 
		{
			logger.error("Sql Error in sendPromotionSMS():"+sqle);
			sqle.printStackTrace();
			return 0;
		}
		catch (Exception e) 
		{
			logger.error("Error in sendPromotionSMS():"+e);
			e.printStackTrace();
			return 0;
		}
}//sendPromotionSMS() ends
	
	
	
	public int approveRbt(String[] rbtlist)
	{
		logger.info("In approveRbt() with listSize to approve: ["+rbtlist.length+"]");
		//Connection con = null;
		PreparedStatement pstmt_add=null;
		PreparedStatement pstmt_delete=null;
		int ret=-1;
		int[] addcnt=null;
		int[] delcnt=null;
		try
		{
			if(rbtlist.length<=0) 
			{	
				return -1;
			}			
			//changes starts by vpsungh on 12-june 15
			ServletContext context=ServletActionContext.getServletContext();
			String uName=context.getAttribute("userName").toString();			
			con = TSSJavaUtil.instance().getconnection();
			//String query_add="insert into CRBT_RBT(RBT_CODE,MASKED_NAME,FILE_PATH,CREATE_DATE,RBT_SCORE,IVR_FILEPATH,RBT_NICK,PLAYABLE,SHOW_ON_WEB,SHOW_IN_SMS,CONTENT_PROVIDER_CODE,CAT_ID,NOKIA,OTHER,CORP_ID,PREV_CAT_ID,CHARGING_CODE,VALIDITY_PERIOD,ARTIST_NAME) (select RBT_CODE,MASKED_NAME,FILE_PATH,CREATE_DATE,RBT_SCORE,IVR_FILEPATH,RBT_NICK,PLAYABLE,SHOW_ON_WEB,SHOW_IN_SMS,CONTENT_PROVIDER_CODE,CAT_ID,NOKIA,OTHER,CORP_ID,PREV_CAT_ID,CHARGING_CODE,VALIDITY_PERIOD,ARTIST_NAME from CRBT_RBT_approve_pending where RBT_CODE=?)";
			String query_add="insert into CRBT_RBT(RBT_CODE,MASKED_NAME,FILE_PATH,CREATE_DATE,RBT_SCORE,IVR_FILEPATH,RBT_NICK,PLAYABLE,SHOW_ON_WEB,SHOW_IN_SMS,CONTENT_PROVIDER_CODE,CAT_ID,NOKIA,OTHER,CORP_ID,PREV_CAT_ID,CHARGING_CODE,VALIDITY_PERIOD,ARTIST_NAME,APPROVED_BY) (select RBT_CODE,MASKED_NAME,FILE_PATH,CREATE_DATE,RBT_SCORE,IVR_FILEPATH,RBT_NICK,PLAYABLE,SHOW_ON_WEB,SHOW_IN_SMS,CONTENT_PROVIDER_CODE,CAT_ID,NOKIA,OTHER,CORP_ID,PREV_CAT_ID,CHARGING_CODE,VALIDITY_PERIOD,ARTIST_NAME,'"+uName+"' from CRBT_RBT_approve_pending where RBT_CODE=?)";
			//changes ends by vpsungh on 12-june 15
			
			String query_del="delete  from CRBT_RBT_approve_pending where RBT_CODE=?";
			logger.info("Insert Query= "+query_add+" \n ,Delete Query= "+query_del);
			pstmt_add = con.prepareStatement(query_add);
			pstmt_delete = con.prepareStatement(query_del);
			for(int i=0;i<rbtlist.length;i++)
			{
				pstmt_add.setInt(1,Integer.parseInt(rbtlist[i]));
				pstmt_add.addBatch(); 
				pstmt_delete.setInt(1,Integer.parseInt(rbtlist[i]));
				pstmt_delete.addBatch(); 
			}
			addcnt=pstmt_add.executeBatch();
			delcnt=pstmt_delete.executeBatch();  
			//logger.info("addcnt "+addcnt.length+"  delcnt "+delcnt.length); 
			if(addcnt.length==delcnt.length)
			{
				ret=addcnt.length;
			}
			else
			{
				return ret;
			}
		}
		catch (SQLException e)
		{
			logger.error("Error in approveRbt(), SQLException :"+e);
			e.printStackTrace();
			try{
				if(pstmt_add !=null) pstmt_add.close();
				if(pstmt_delete!=null)pstmt_delete.close();
			}catch(Exception exp){}
			e.printStackTrace();
			return -1;
		}
		catch(Exception exp)
		{
			logger.error("Error in approveRbt(), Exception :"+exp);
			exp.printStackTrace();
			try{
				if(pstmt_add !=null) pstmt_add.close();
				if(pstmt_delete!=null)pstmt_delete.close();
			}catch(Exception exp1){}
		}
		finally
		{
			if(con!=null)
				TSSJavaUtil.instance().freeConnection(con);
		}
		return ret;
	}//approveRbt

	
	public int searchApproveRbt(ArrayList listApprove,int pageno,String startDate,String endDate,int cp,Connection con)
	{
		logger.info("In searchApproveRbt() with pageno:"+pageno+", startDate:"+startDate+", endDate:"+endDate+", cp:"+cp);
		int srow = pageno*10;
		int erow = srow+11;
		//Connection con = null;
		PreparedStatement pstmt1=null;
		String specialCatId ="998";
		String recordedCatId="999";
		int ret=-1;
		try
		{
			//con = conPool.getConnection();
			String query="";
			specialCatId   = TSSJavaUtil.instance().getAppConfigParam("SPECIAL_CONTROL_CATID");
			recordedCatId  = TSSJavaUtil.instance().getAppConfigParam("CRBT_RECORDED_CATEGORY_ID");			

			//String query="select * from (select RBT_CODE,CREATE_DATE, MASKED_NAME, RBT_NICK, CAT_ID,ROWNUM ROW_NUMBER from (select RBT_CODE,to_char(CREATE_DATE,'dd-mm-yyyy') CREATE_DATE, MASKED_NAME, RBT_NICK, CAT_ID from CRBT_RBT_approve_pending where RBT_CODE not in (select RBT_CODE from CRBT_RBT_CONTROL) and not(CAT_ID = ?) and not(CAT_ID = ?) order by to_date(CREATE_DATE,'dd-mm-yyyy') desc) where ROWNUM < ?) where ROW_NUMBER > ?";
			if(cp!=-1)
			{
				//query="select * from (select RBT_CODE,CREATE_DATE, MASKED_NAME, RBT_NICK, CAT_ID,ROWNUM ROW_NUMBER from (select RBT_CODE,to_char(CREATE_DATE,'dd-mm-yyyy') CREATE_DATE, MASKED_NAME, RBT_NICK, CAT_ID from CRBT_RBT_approve_pending where RBT_CODE not in (select RBT_CODE from CRBT_RBT_CONTROL) and not(CAT_ID = ?) and not(CAT_ID = ?) and CREATE_DATE>=to_date(?,'dd-mm-yyyy') and CREATE_DATE<=to_date(?,'dd-mm-yyyy') and CONTENT_PROVIDER_CODE=?  order by to_date(CREATE_DATE,'dd-mm-yyyy') desc) where ROWNUM < ?) where ROW_NUMBER > ?";
				query="select * from (select RBT_CODE,ARTIST_NAME,CREATE_DATE,MASKED_NAME, RBT_NICK, CAT_ID,ROWNUM ROW_NUMBER from (select RBT_CODE,ARTIST_NAME,to_char(CREATE_DATE,'dd-mm-yyyy') CREATE_DATE, MASKED_NAME, RBT_NICK, CAT_ID from CRBT_RBT_approve_pending where STATUS!='D' and RBT_CODE not in (select RBT_CODE from CRBT_RBT_CONTROL) and not(CAT_ID = ?) and not(CAT_ID = ?) and trunc(CREATE_DATE)>=to_date(?,'dd-mm-yyyy') and trunc(CREATE_DATE)<=to_date(?,'dd-mm-yyyy') and CONTENT_PROVIDER_CODE=?  order by to_date(CREATE_DATE,'dd-mm-yyyy') desc) where ROWNUM < ?) where ROW_NUMBER > ?";
			}
			else
			{
				query="select * from (select RBT_CODE,ARTIST_NAME,CREATE_DATE, MASKED_NAME, RBT_NICK, CAT_ID,ROWNUM ROW_NUMBER from (select RBT_CODE,ARTIST_NAME,to_char(CREATE_DATE,'dd-mm-yyyy') CREATE_DATE, MASKED_NAME, RBT_NICK, CAT_ID from CRBT_RBT_approve_pending where STATUS!='D'and RBT_CODE not in (select RBT_CODE from CRBT_RBT_CONTROL) and not(CAT_ID = ?) and not(CAT_ID = ?) and trunc(CREATE_DATE)>=to_date(?,'dd-mm-yyyy') and trunc(CREATE_DATE)<=to_date(?,'dd-mm-yyyy')  order by to_date(CREATE_DATE,'dd-mm-yyyy') desc) where ROWNUM < ?) where ROW_NUMBER > ?";
			}
			logger.info("Select Query = "+query);
			pstmt1 = con.prepareStatement(query);
			pstmt1.setString(1,specialCatId);	
			pstmt1.setString(2,recordedCatId);
			pstmt1.setString(3,startDate);
			pstmt1.setString(4,endDate);
			if(cp!=-1)
			{
				pstmt1.setInt(5,cp);
				pstmt1.setInt(6,erow);
				pstmt1.setInt(7,srow);
			}
			else
			{
				pstmt1.setInt(5,erow);
				pstmt1.setInt(6,srow);
			}
			rs=pstmt1.executeQuery();
			while(rs.next()) 
			{	
				//Rbt rbt = new Rbt(rs.getInt("RBT_CODE"),rs.getString("MASKED_NAME"),rs.getInt("CAT_ID"));
				Rbt rbt = new Rbt(rs.getString("ARTIST_NAME"),rs.getInt("RBT_CODE"),rs.getString("MASKED_NAME"),rs.getInt("CAT_ID"));//by vpsingh on 18-june for atrist name
				rbt.setCreateDate(rs.getString("CREATE_DATE"));
				listApprove.add(rbt);
			}
			listApprove.trimToSize();
			pstmt1.close();
			rs.close();
			if(cp!=-1)
			{
				pstmt1=con.prepareStatement("Select count(RBT_CODE) as Total from CRBT_RBT_approve_pending where rbt_code not in ( select RBT_CODE from CRBT_RBT_CONTROL) and  STATUS!='D' and not(CAT_ID = ?) and not(CAT_ID = ?) and trunc(CREATE_DATE)>=to_date(?,'dd-mm-yyyy') and trunc(CREATE_DATE)<=to_date(?,'dd-mm-yyyy') and CONTENT_PROVIDER_CODE=? ");
			}
			else
			{
				pstmt1=con.prepareStatement("Select count(RBT_CODE) as Total from CRBT_RBT_approve_pending where rbt_code not in ( select RBT_CODE from CRBT_RBT_CONTROL) and  STATUS!='D' and not(CAT_ID = ?) and not(CAT_ID = ?) and trunc(CREATE_DATE)>=to_date(?,'dd-mm-yyyy') and trunc(CREATE_DATE)<=to_date(?,'dd-mm-yyyy') ");
			}
			pstmt1.setString(1,specialCatId);	
			pstmt1.setString(2,recordedCatId);
			pstmt1.setString(3,startDate);
			pstmt1.setString(4,endDate);
			if(cp!=-1)
				pstmt1.setInt(5,cp);

			rs=pstmt1.executeQuery();
			if(rs.next())
				ret=rs.getInt("TOTAL");

			if(rs !=null) rs.close();
			if(pstmt1!=null)pstmt1.close();
			return ret;
		}
		catch(Exception exp)
		{
			logger.error("Error in searchApproveRbt():"+exp);
			exp.printStackTrace();
			try{
				if(rs !=null) rs.close();
				if(pstmt1!=null)pstmt1.close();
			}
			catch(Exception exp1){}
		}
		return ret;
	}//searchApproveRbt() ends


	public int searchAllApproveRbt(ArrayList listApprove,int pageno,int cp,Connection con)
	{
		logger.info("In searchAllApproveRbt() with cp:"+cp+", pageno:"+pageno);
		//Connection con = null;
		int srow = pageno*10;
		int erow = srow+11;
		PreparedStatement pstmt1=null;
		String specialCatId ="998";
		String recordedCatId="999";
		int ret=-1;
		try
		{
			//con = conPool.getConnection();
			String query="";
			specialCatId   = TSSJavaUtil.instance().getAppConfigParam("SPECIAL_CONTROL_CATID");
			recordedCatId  = TSSJavaUtil.instance().getAppConfigParam("CRBT_RECORDED_CATEGORY_ID");			

			//String query="select * from (select RBT_CODE,CREATE_DATE, MASKED_NAME, RBT_NICK, CAT_ID,ROWNUM ROW_NUMBER from (select RBT_CODE,to_char(CREATE_DATE,'dd-mm-yyyy') CREATE_DATE, MASKED_NAME, RBT_NICK, CAT_ID from CRBT_RBT_approve_pending where RBT_CODE not in (select RBT_CODE from CRBT_RBT_CONTROL) and not(CAT_ID = ?) and not(CAT_ID = ?) order by to_date(CREATE_DATE,'dd-mm-yyyy') desc) where ROWNUM < ?) where ROW_NUMBER > ?";
			if(cp!=-1)
			{
				//query="select * from (select RBT_CODE,CREATE_DATE, MASKED_NAME, RBT_NICK, CAT_ID,ROWNUM ROW_NUMBER from (select RBT_CODE,to_char(CREATE_DATE,'dd-mm-yyyy') CREATE_DATE, MASKED_NAME, RBT_NICK, CAT_ID from CRBT_RBT_approve_pending where RBT_CODE not in (select RBT_CODE from CRBT_RBT_CONTROL) and not(CAT_ID = ?) and not(CAT_ID = ?) and CREATE_DATE>=to_date(?,'dd-mm-yyyy') and CREATE_DATE<=to_date(?,'dd-mm-yyyy') and CONTENT_PROVIDER_CODE=?  order by to_date(CREATE_DATE,'dd-mm-yyyy') desc) where ROWNUM < ?) where ROW_NUMBER > ?";
				query="select * from (select RBT_CODE,MASKED_NAME,ARTIST_NAME,CREATE_DATE,RBT_NICK,CAT_ID,ROWNUM ROW_NUMBER from (select RBT_CODE,ARTIST_NAME,to_char(CREATE_DATE,'dd-mm-yyyy') CREATE_DATE, MASKED_NAME, RBT_NICK, CAT_ID from CRBT_RBT_approve_pending where STATUS!='D' and RBT_CODE not in (select RBT_CODE from CRBT_RBT_CONTROL) and not(CAT_ID = ?) and not(CAT_ID = ?) and CONTENT_PROVIDER_CODE=?  order by to_date(CREATE_DATE,'dd-mm-yyyy') desc) where ROWNUM < ?) where ROW_NUMBER > ?";
			}
			else
			{
				query="select * from (select RBT_CODE,MASKED_NAME,ARTIST_NAME,CREATE_DATE,RBT_NICK,CAT_ID,ROWNUM ROW_NUMBER from (select RBT_CODE,ARTIST_NAME,to_char(CREATE_DATE,'dd-mm-yyyy') CREATE_DATE, MASKED_NAME, RBT_NICK, CAT_ID from CRBT_RBT_approve_pending where STATUS!='D'and RBT_CODE not in (select RBT_CODE from CRBT_RBT_CONTROL) and not(CAT_ID = ?) and not(CAT_ID = ?) order by to_date(CREATE_DATE,'dd-mm-yyyy') desc) where ROWNUM < ?) where ROW_NUMBER > ?";
			}
			logger.info("Select Query = "+query);
			pstmt1 = con.prepareStatement(query);
			pstmt1.setString(1,specialCatId);	
			pstmt1.setString(2,recordedCatId);
			
			if(cp!=-1)
			{
				pstmt1.setInt(3,cp);
				pstmt1.setInt(4,erow);
				pstmt1.setInt(5,srow);
			}
			else
			{
				pstmt1.setInt(3,erow);
				pstmt1.setInt(4,srow);
			}
			rs=pstmt1.executeQuery();
			while(rs.next()) 
			{
				//Rbt rbt = new Rbt(rs.getInt("RBT_CODE"),rs.getString("MASKED_NAME"),rs.getInt("CAT_ID"));
				Rbt rbt = new Rbt(rs.getString("ARTIST_NAME"),rs.getInt("RBT_CODE"),rs.getString("MASKED_NAME"),rs.getInt("CAT_ID"));//by vpsingh on 18-june for artist name
				rbt.setCreateDate(rs.getString("CREATE_DATE"));
				listApprove.add(rbt);
			}
			listApprove.trimToSize();
			pstmt1.close();
			rs.close();
			if(cp!=-1)
			{
				pstmt1=con.prepareStatement("Select count(RBT_CODE) as Total from CRBT_RBT_approve_pending where rbt_code not in ( select RBT_CODE from CRBT_RBT_CONTROL) and  STATUS!='D' and not(CAT_ID = ?) and not(CAT_ID = ?) and CONTENT_PROVIDER_CODE=? ");
			}
			else
			{
				pstmt1=con.prepareStatement("Select count(RBT_CODE) as Total from CRBT_RBT_approve_pending where rbt_code not in ( select RBT_CODE from CRBT_RBT_CONTROL) and  STATUS!='D' and not(CAT_ID = ?) and not(CAT_ID = ?)");
			}
			pstmt1.setString(1,specialCatId);	
			pstmt1.setString(2,recordedCatId);
			if(cp!=-1)
				pstmt1.setInt(3,cp);

			rs=pstmt1.executeQuery();
			if(rs.next())
				ret=rs.getInt("TOTAL");

			if(rs !=null) rs.close();
			if(pstmt1!=null)pstmt1.close();
			return ret;
		}
		catch(Exception exp)
		{
			logger.error("Error in searchAllApproveRbt():"+exp);
			exp.printStackTrace();
			try{
				if(rs !=null) rs.close();
				if(pstmt1!=null)pstmt1.close();
			}
			catch(Exception exp1){}
		}
		return ret;
}//searchAllApproveRbt() ends



	public int searchRbtCP(int catId, int cpId, ArrayList rbtList)
	{
		logger.info("In searchRbtCP(): search rbt per category");
		Connection con = null;
		PreparedStatement pstmt1=null;
		PreparedStatement pstmt2=null;
		ResultSet rs = null;
		String query = null;
		String cquery = null;
		String specialCatId ="998";
		String recordedCatId="999";
		int ret = -1;
		try
		{
			con = TSSJavaUtil.instance().getconnection();
			specialCatId=TSSJavaUtil.instance().getAppConfigParam("SPECIAL_CONTROL_CATID");
			recordedCatId=TSSJavaUtil.instance().getAppConfigParam("CRBT_RECORDED_CATEGORY_ID");
			query = "select * from (select RBT_CODE, MASKED_NAME,ARTIST_NAME, RBT_NICK, CAT_ID from (select RBT_CODE, MASKED_NAME,ARTIST_NAME, RBT_NICK, CAT_ID from CRBT_RBT where RBT_CODE not in (select RBT_CODE from CRBT_RBT_CONTROL) and not(CAT_ID = ?) and not(CAT_ID = ?) and CONTENT_PROVIDER_CODE = ? and CAT_ID=? order by MASKED_NAME) )";
			logger.info("Select Query = "+query);
			pstmt1 = con.prepareStatement(query);
			pstmt1.setString(1, recordedCatId);
			pstmt1.setString(2, specialCatId);
			pstmt1.setInt(3,cpId);
			pstmt1.setInt(4,catId);

			rs = pstmt1.executeQuery();
			while(rs.next())
			{
				//Rbt rbt = new Rbt(rs.getInt("RBT_CODE"),rs.getString("MASKED_NAME"),rs.getInt("CAT_ID"));
				Rbt rbt = new Rbt(rs.getString("ARTIST_NAME"),rs.getInt("RBT_CODE"),rs.getString("MASKED_NAME"),rs.getInt("CAT_ID"));//by vpsingh on 15-june
				rbtList.add(rbt);
			}
			if(rs != null) rs.close();
			if(pstmt1 != null) pstmt1.close();
			if(pstmt2 != null) pstmt2.close();
			return 1;
		}//try
		catch (SQLException e)
		{
			logger.error("Error in searchRbtCP(), SQLException :"+e);
			e.printStackTrace();
			try {
				if(rs != null) rs.close();
				if(pstmt1 != null) pstmt1.close();
				//      if(pstmt2 != null) pstmt2.close();
			} catch(Exception exp) {}
			e.printStackTrace();
			return -99;
		}
		catch (Exception e)
		{
			logger.error("Error in searchRbtCP(), SQLException :"+e);
			try {
				if(rs != null) rs.close();
				if(pstmt1 != null) pstmt1.close();
			} catch(Exception exp) {}                
			e.printStackTrace();
			return -99;
		}
		finally {
			try{
				 if(con!=null) TSSJavaUtil.instance().freeConnection(con);
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}

	}//searchRbtCP()


//not using so can remove?
	public InputStream getRbt() throws Exception
	{
		return new FileInputStream("D:/crbt/home/tomcat/development/priyanka/test/65/RbtMusicFiles/mytest_rbt123.wav");
	}



//////////////////  getting MRBT Subscription List
public int searchRbtCP(int catId, int cpId, ArrayList rbtList,String rbtName, int pageno){
		logger.info("In searchRbtCP() with catid:"+catId+", cpId:"+cpId+", rbtname:"+rbtName+", pagno:"+pageno);		
		int srow = pageno*10;
		int erow = srow+11;
		Connection con = null;
		PreparedStatement pstmt1=null;
		PreparedStatement pstmt2=null;
		ResultSet rs = null;
		String query = null;
		String cquery = null;
		String specialCatId ="998";
		String recordedCatId="999";
		int ret = -1;		
		try
		{
			con = TSSJavaUtil.instance().getconnection();			
			specialCatId   = TSSJavaUtil.instance().getAppConfigParam("SPECIAL_CONTROL_CATID");
			recordedCatId  = TSSJavaUtil.instance().getAppConfigParam("CRBT_RECORDED_CATEGORY_ID");
			if(catId ==-1 && !rbtName.equalsIgnoreCase(""))
			{					
				query = "select * from (select RBT_CODE, MASKED_NAME, RBT_NICK, CAT_ID, ROWNUM ROW_NUMBER from (select RBT_CODE, MASKED_NAME, RBT_NICK, CAT_ID from CRBT_RBT where RBT_CODE not in (select RBT_CODE from CRBT_RBT_CONTROL) and not(CAT_ID = ?) and not(CAT_ID = ?) and CONTENT_PROVIDER_CODE = ? and MASKED_NAME like '"+rbtName.toUpperCase()+"%' order by MASKED_NAME))";
				logger.info("Searching for matching RBTNAME= " +rbtName+", Select Query ---------> "+query+", recordedCatId ------> "+recordedCatId+  "  specialCatId--> "+specialCatId+ "  cpId---> "+cpId);
				pstmt1 = con.prepareStatement(query);
				pstmt1.setString(1, recordedCatId);
				pstmt1.setString(2, specialCatId);
				pstmt1.setInt(3,cpId);
			//	pstmt1.setString(4,rbtName);
				rs = pstmt1.executeQuery();
				while(rs.next())
				{
					Rbt rbt = new Rbt(rs.getInt("RBT_CODE"),rs.getString("MASKED_NAME"),rs.getInt("CAT_ID"));
					//logger.info("RBTNAME= " +rs.getString("MASKED_NAME")+" cat_id= "+rs.getInt("CAT_ID")+" rbt_code="+rs.getInt("rbt_code"));					
					rbtList.add(rbt);
				}
				ret = 2;
				if(rs != null) rs.close();
				if(pstmt1 != null) pstmt1.close();
			}//if
			else
			{	
				query = "select * from (select RBT_CODE, MASKED_NAME, RBT_NICK, CAT_ID, ROWNUM ROW_NUMBER from (select RBT_CODE, MASKED_NAME, RBT_NICK, CAT_ID from CRBT_RBT where RBT_CODE not in (select RBT_CODE from CRBT_RBT_CONTROL) and not(CAT_ID = ?) and not(CAT_ID = ?) and CONTENT_PROVIDER_CODE = ? and CAT_ID=? order by MASKED_NAME) where ROWNUM < ?) where ROW_NUMBER > ?";
				logger.info("Get rbt list for given category and content provider ,Select Query = "+query);
				pstmt1 = con.prepareStatement(query);
				pstmt1.setString(1, recordedCatId);
				pstmt1.setString(2, specialCatId);
				pstmt1.setInt(3,cpId);
				pstmt1.setInt(4,catId);
				pstmt1.setInt(5,erow);
				pstmt1.setInt(6,srow);

				cquery = "select count(RBT_CODE) TOTAL from CRBT_RBT where RBT_CODE not in(select RBT_CODE from CRBT_RBT_CONTROL) and not(CAT_ID=?) and not(CAT_ID=?) and CONTENT_PROVIDER_CODE = ? and CAT_ID=?";
				logger.info("Select cquery = "+cquery);
				pstmt2 = con.prepareStatement(cquery);
				pstmt2.setString(1, recordedCatId);
				pstmt2.setString(2, specialCatId);
				pstmt2.setInt(3, cpId);
				pstmt2.setInt(4, catId);

				rs = pstmt1.executeQuery();
				while(rs.next())
				{
					Rbt rbt = new Rbt(rs.getInt("RBT_CODE"),rs.getString("MASKED_NAME"),rs.getInt("CAT_ID"));
					rbtList.add(rbt);
				}

				rs = pstmt2.executeQuery();
				if (rs.next())
					ret = rs.getInt("TOTAL");
				else
					logger.info("No data found from cquery");

				if(rs != null) rs.close();
				if(pstmt1 != null) pstmt1.close();
				if(pstmt2 != null) pstmt2.close();
			}//else
			return ret;
		}//try
		catch (SQLException e)
		{
			logger.error("Error in searchRbtCP(), SQLException :"+e);
			e.printStackTrace();
			try {
				if(rs != null) rs.close();
				if(pstmt1 != null) pstmt1.close();
				if(pstmt2 != null) pstmt2.close();
			} catch(Exception exp) {}
			e.printStackTrace();
			return -99;
		}
		catch (Exception e)
		{
			logger.error("Error in searchRbtCP():"+e);
			try {
				if(rs != null) rs.close();
				if(pstmt1 != null) pstmt1.close();
				if(pstmt2 != null) pstmt2.close();
			} catch(Exception exp) {}                
			e.printStackTrace();
			return -99;
		}
		finally {
			try{
			 if(con!=null) TSSJavaUtil.instance().freeConnection(con);
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}
}//searchRbtCP() ends

	
public int rejectunapproveRbt(String[] rejectlist)
{
		logger.info("In rejectunapproveRbt(): rjection list >   "+rejectlist);
		Connection con = null;
		PreparedStatement pstmt=null;
		ResultSet rs = null;
		String query = null;
		String rjcCodes="";
		try
		{
			con = TSSJavaUtil.instance().getconnection();			
			for(int i=0;i<rejectlist.length;i++)
			{
				rjcCodes=rejectlist[i]+",";
			}
			rjcCodes= rjcCodes.substring(0,rjcCodes.length()-1);
			
			//changes by vpsingh on 12-june 15 starts
			ServletContext context=ServletActionContext.getServletContext();
			String uName=context.getAttribute("userName").toString();
			//query = "update CRBT_RBT_approve_pending set STATUS = 'D' where RBT_CODE in ("+rjcCodes+")";
			query = "update CRBT_RBT_approve_pending set STATUS = 'D',REJECTED_BY='"+uName+"' where RBT_CODE in ("+rjcCodes+")";			
			logger.info("Update Query = "+query);
			//changes by vpsingh on 12-june 15 ends
			pstmt=con.prepareStatement(query);
			rs = pstmt.executeQuery();
			if(rs != null) rs.close();
			if(pstmt != null) pstmt.close();
			return 1;
		}//try
		catch (SQLException e)
		{
			logger.error("Sql Error in rejectunapproveRbt(), SQLException :"+e);
			e.printStackTrace();
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
			} catch(Exception exp) {}
			e.printStackTrace();
			return -1;
		}
		catch (Exception exp)
		{
			logger.error("Error in rejectunapproveRbt(),Exception :"+exp);
			exp.printStackTrace();
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
			} catch(Exception exp1) {}
			return -1;
		}
		finally {
			try{
				 if(con!=null) TSSJavaUtil.instance().freeConnection(con);
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}
}//rejectunapproveRbt()m ends

	
	
public int getRequestedRbt(String startdt, String enddt, ArrayList reqrbtAl){
	logger.info("In getRequestedRbt(): Start dt ["+startdt+"] end date ["+enddt+"]");
	Connection con = null;
	PreparedStatement pstmt=null;
	ResultSet rs = null;
	String query = null;
		try
		{
			con = TSSJavaUtil.instance().getconnection();			
			if(startdt==null && enddt==null||startdt=="" && enddt==""){				
				query="select MSISDN, REQ_ID, RBT_NAME, RBT_ARTIST, RBT_ALBUM, REQ_DATE from Request_New_Crbt order by REQ_DATE";				
			}
			else{				
				query="select MSISDN, REQ_ID, RBT_NAME, RBT_ARTIST, RBT_ALBUM, REQ_DATE from Request_New_Crbt where trunc(REQ_DATE) between to_date(?,'dd-mm-yyyy') and to_date(?,'dd-mm-yyyy') order by REQ_DATE";
			}			
			logger.info("Select Query = "+query);
			pstmt=con.prepareStatement(query);
			if(!(startdt==null && enddt==null||startdt=="" && enddt=="")){				
				pstmt.setString(1, startdt);
				pstmt.setString(2, enddt);				
			}			
			rs = pstmt.executeQuery();
			while(rs.next())
			{
				Rbt rbt = new Rbt();
				rbt.setMsisdn(rs.getString("MSISDN"));
				rbt.setRbtMaskName(rs.getString("RBT_NAME"));
				rbt.setArtName(rs.getString("RBT_ARTIST"));
				rbt.setAlbumName(rs.getString("RBT_ALBUM"));				
				reqrbtAl.add(rbt);
			}
			logger.info("Successfully inserted into the arraylist...size is  ["+reqrbtAl.size()+"]");
			if(rs != null) rs.close();
			if(pstmt != null) pstmt.close();
			return 1;
		}//try
		catch (SQLException e)
		{
			logger.error("Sql Error in getRequestedRbt():"+e);
			e.printStackTrace();
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
			} catch(Exception exp) {}
			e.printStackTrace();
			return -1;
		}
		catch (Exception e)
		{
			logger.error("Error in getRequestedRbt():"+e);
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
			} catch(Exception exp) {}                
			e.printStackTrace();
			return -1;
		}
		finally {
			try{
				 if(con!=null) TSSJavaUtil.instance().freeConnection(con);
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}		
}//getRequestedRbt() ends
	
	//artist name selected by vpsingh on 18-june
public int searchNameTunes(String nametune,ArrayList rbtList,int pageno,boolean show,int  catId){
		 logger.info("In searchNameTunes() ");
         PreparedStatement pstmt = null;
         ResultSet rs = null;
         String query="";
         int s_row = pageno*10;
         int e_row = s_row+11;
         int ret=-1;
         try
         {
                 con=TSSJavaUtil.instance().getconnection();
                 if(nametune==null||nametune.equalsIgnoreCase(""))
                 {
                         logger.error("Nametune=NULL so returns -99");
                         return -99;
                 }
                 else{                 
                	// catId=65;                         
                         if(show)
                         {
                             //query=" select * from (select MASKED_NAME,RBT_CODE, ROWNUM ROW_NUMBER from(select MASKED_NAME,RBT_CODE from CRBT_RBT where CAT_ID=? and UPPER(MASKED_NAME) like UPPER(?) order by MASKED_NAME desc) where ROWNUM<?)where ROW_NUMBER>?";
                        	 query=" select * from (select MASKED_NAME,RBT_CODE,ARTIST_NAME, ROWNUM ROW_NUMBER from(select MASKED_NAME,RBT_CODE,ARTIST_NAME from CRBT_RBT where CAT_ID=? and UPPER(MASKED_NAME) like UPPER(?) order by MASKED_NAME desc))";
                             //query="select RBT_CODE,MASKED_NAME from crbt_rbt where MASKED_NAME like ? and CAT_ID=?";                             
                             pstmt = con.prepareStatement(query);
                             pstmt.setInt(1,catId);
                             pstmt.setString(2,"%"+nametune+"%");
                         }
                         else{
                             //query="select RBT_CODE,MASKED_NAME from crbt_rbt where  MASKED_NAME like ? and CAT_ID=?";
                             //query="select * from (select MASKED_NAME,RBT_CODE, ROWNUM ROW_NUMBER from(select MASKED_NAME,RBT_CODE from CRBT_RBT where CAT_ID=? and (UPPER(MASKED_NAME) like UPPER(?)) order by MASKED_NAME desc) where ROWNUM<?) where ROW_NUMBER>? ";
                        	 query="select * from (select MASKED_NAME,RBT_CODE,ARTIST_NAME, ROWNUM ROW_NUMBER from(select MASKED_NAME,RBT_CODE,ARTIST_NAME from CRBT_RBT where CAT_ID=? and (UPPER(MASKED_NAME) like UPPER(?)) order by MASKED_NAME desc))";
                             pstmt = con.prepareStatement(query);
                             pstmt.setInt(1,catId);
                             pstmt.setString(2,nametune+"%");
                        }
                         //pstmt.setInt(3,e_row);
                         //pstmt.setInt(4,s_row);
                         logger.info("In searchNameTunes()  Select QUERY -- ["+query+"]  Nametune ["+nametune+"]"+"s_row"+s_row+"e_row"+e_row);
                         rs = pstmt.executeQuery();
                         while(rs.next()){
                        	 NametuneBean nametunebean = new NametuneBean();
                             //logger.debug("RBT_CODE["+rs.getInt("RBT_CODE")+"]"+"MASKED_NAME  [ "+rs.getString("MASKED_NAME")+"]");
                             nametunebean.setMaskedName(rs.getString("MASKED_NAME"));
                             nametunebean.setRbtCode(rs.getInt("RBT_CODE"));
                             nametunebean.setArtistName(rs.getString("ARTIST_NAME"));
                             rbtList.add(nametunebean);
                         }
                         rs.close();
                         pstmt.close();
                         query = "select count(RBT_CODE) TOTAL from CRBT_RBT where UPPER(MASKED_NAME) like UPPER(?)  and CAT_ID=?";                         
                         pstmt = con.prepareStatement(query);                         
                         if(show){
                        	 pstmt.setString(1,"%"+nametune+"%");
                         }
                         else{
                        	 pstmt.setString(1,nametune+"%");
                         }
                         pstmt.setInt(2,catId);
                         rs = pstmt.executeQuery();
                         if (rs.next()){
                        	 ret = rs.getInt("TOTAL");                             
                         }                         
                         logger.info("TOTAL DATA Selected is:"+ret);                          
                         if(rs != null) rs.close();
                         if(pstmt != null) pstmt.close();                                               
                         return ret;
                 }//else ends
         }
         catch(Exception e){
        	 e.printStackTrace();
             logger.error("Error in searchNameTunes() so returns -99: "+e);
             try{
            	 if(rs != null) rs.close();
                 if(pstmt != null) pstmt.close();
             }catch(Exception exp) {}
             return -99;
         }
         finally{
        	 try{
        		 if(con!=null) TSSJavaUtil.instance().freeConnection(con);
                }
                catch(Exception e){
                	e.printStackTrace();
                }
         }//finally ends
	}//searchNameTunes() ends
	
	
}//class ends

