/*
 * Maintains every user's session history
 *
 *
 *
 */


package com.telemune.vcc.common;
import com.telemune.dbutilities.*;
import java.util.*;
import java.sql.ResultSet;
import org.apache.log4j.*;
public class SessionHistory
{
	static Logger logger=Logger.getLogger(SessionHistory.class);
	private String strUser;
	private int roleId;
	private int firstLogin;
	private int passwd_expire;
	private ArrayList links=null;
	private Connection con;
	private String roleName;
	

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public void SessionHistory()
	{
		this.strUser = "";
	}	

	public void setUser(String strUser)
	{
		this.strUser = strUser;
	}
	public void setFirstLogin(int firstLogin)
	{
		this.firstLogin = firstLogin;
	}
	public void setRoleId(int roleId)
	{
		this.roleId = roleId;
	}
	public void setPasswdExpire(int passwd_expire)
	{
		this.passwd_expire = passwd_expire;
	}

	public String getUser()
	{
		return strUser;
	}
	public int getFirstLogin()
	{
		return firstLogin;
	}
	public int getRoleId()
	{
		return roleId;
	}
	public int getPasswdExpire()
	{
		return passwd_expire;
	}

	public boolean isAllowed(int linkId)
	{
		return links.contains(new Integer(linkId));
	}
	
	public ArrayList getLinksDetails()
	{
		return links;
	}

	public void getLinks(int usertype)
	{
		logger.info("inside getLinks() of SessionHistory usertype ie roll_id = "+usertype);
		links = new ArrayList();
		try		
		{
			
			String query = "select LINK_ID from WEB_ACCESS where ROLE_ID = ?";
			logger.info("Select Query = "+query);
			PreparedStatement pstmt = con.prepareStatement(query);
			pstmt.setInt(1, usertype);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next())
			{
				links.add(new Integer(rs.getInt(1)));
			}			
			pstmt.close();
			rs.close();
			if(rs != null)rs.close();
		}
		catch (Exception e)
		{	
			logger.error("Error in getLinks() of SessionHistory:"+e);
			e.printStackTrace();			
		}
	}
	
	public void setConnection(Connection con)
	{
		this.con = con;
	}
}
