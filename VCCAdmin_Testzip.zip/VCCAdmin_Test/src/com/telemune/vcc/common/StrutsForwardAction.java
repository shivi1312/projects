package com.telemune.vcc.common;

import org.apache.log4j.Logger;

public class StrutsForwardAction extends ValidateAction
{	
	Logger logger=Logger.getLogger(StrutsForwardAction.class);
	String message;
	
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String onlySuccess()
	{	logger.info("Hello I m Checking For not Running in onlySuccess() of StrutsForwardAction");
		return "success";
	}


}
