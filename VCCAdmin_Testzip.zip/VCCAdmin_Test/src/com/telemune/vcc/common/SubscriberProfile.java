
package com.telemune.vcc.common;

import java.util.Date;
import java.text.DateFormat;
import org.apache.log4j.*;

public class SubscriberProfile
{
                private static Logger logger=Logger.getLogger(SubscriberProfile.class);
				private DateFormat df = DateFormat.getDateInstance();

				private String msisdn = "0";
				private String corpName = "";
				private String chargingMsisdn = "0";
				private long corpId=0;
				private Date date = null;
				private int planIndicator= -1;
				private String status = "0";		
				private int rbtCode = -1;
				private String sub_type = "N";
				private int lang = 0;
				private String username="";
				
				//Start of updated by MoHit for SUDAN 30 Dec 14
				private int chgCode = -1;
				public void setChgCode(int chgCode) {
					this.chgCode = chgCode;
				}
				public int getChgCode() {
					return chgCode;
				}
				//End of updated by MoHit for SUDAN 30 Dec 14
				
				public String getUsername() {
					return username;
				}
				public void setUsername(String username) {
					this.username = username;
				}
				public void setLang(int lang)
				{
								this.lang = lang;
				}
				public int getLang()
				{
								return this.lang;
				}


				public void SubscriberProfile()
				{
				}	

				public boolean isPrepaid()
				{
								if (sub_type == "P")
												return true;
								else 
												return false;
				}

				public String getSubType()
				{
								return sub_type;
				}

				public void setSubType(String subType)
				{
								sub_type = subType;
				}

				public int getPlanIndicator()
				{
								return planIndicator;			
				}	

				public void setPlanIndicator(int pi)
				{
								this.planIndicator = pi;			
				}

				public void setPlanIndicator(String pi)
				{
								try{
												planIndicator = Integer.parseInt(pi);
								}
								catch (Exception e)
								{
									logger.error("Error in setPlanIndicator() of  SubscriberProfile.java" + e);
												planIndicator = -1;
												e.printStackTrace();
												
								}
				}
				public void setCorpName(String corpName)
				{
								this.corpName = corpName;
				}

				public String getCorpName()
				{
								return corpName;			
				}	


				public int getRbtCode()
				{
								return rbtCode;			
				}	

				public void setRbtCode(int rc)
				{
								rbtCode = rc;			
				}

				public void setRbtCode(String rc)
				{
								try
								{
												rbtCode = Integer.parseInt(rc);			
								}
								catch (Exception e)
								{
									logger.error("Error in setRbtCode of SubscriberProfile with rbtCode: ["+rc+"], " + e);
												rbtCode = -1;	
												e.printStackTrace();
								}
				}

				public String getStatus()
				{
								return status;			
				}

				public void setStatus(String s)
				{
								status = s;			
				}

				public void setDate(Date date)
				{
								this.date = date;
				}

				public void setDate(String strDate) throws java.text.ParseException
				{
								this.date = df.parse(strDate);
				}

				public Date getDate()
				{
								return date;
				}

				public String getStrDate()
				{
								return df.format(date);
				}

				public void setMsisdn(String msisdn)
				{	
								this.msisdn = msisdn;			
				}

				public String  getMsisdn()
				{
								return TSSJavaUtil.instance().getInternationalNumber(msisdn);				
				}

				public void setChargingMsisdn(String msisdn)
				{	
								this.chargingMsisdn = msisdn;			
				}
				public void setCorpId(long corpId)
				{	
								this.corpId = corpId;			
				}

				public String getChargingMsisdn()
				{	
								return chargingMsisdn;			
				}
				public long getCorpId()
				{	
								return corpId;			
				}
}
