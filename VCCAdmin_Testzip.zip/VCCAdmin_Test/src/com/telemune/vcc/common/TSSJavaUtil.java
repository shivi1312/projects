package com.telemune.vcc.common;
import com.telemune.dbutilities.Connection;
import com.telemune.dbutilities.ConnectionPool;
import com.telemune.operationAndMaintainance.logConfigurator.util.GlobalParam;
import com.telemune.reports.ReportConnectionPool;
import com.telemune.vcc.common.LanguageBean;
import com.telemune.vcc.common.MsisdnVal;
import com.telemune.vcc.common.TSSJavaUtil;
import com.telemune.vcc.custcare.Country;
import java.io.FileInputStream;
import java.io.IOException;
//import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Properties;
import org.apache.log4j.Logger;

public class TSSJavaUtil {
  private static Logger logger = Logger.getLogger(TSSJavaUtil.class);
  
  private static TSSJavaUtil instance_ = null;
  
  private static int multicountry = 0;
  
  private static String countryCode = "263";
  
  private static Properties properties = null;
  
  private static Hashtable<String, String> app_params = null;
  
  private static Hashtable rbt_params = null;
  
  private static Hashtable category_params = null;
  
  private static Properties propFile = null;
  
  private static ArrayList<LanguageBean> languageBean = null;
  
  private static ConnectionPool conPool = null;
  
  private String propfileName = "";
  
  private static ArrayList alMsisdnRange = new ArrayList();
  
  private static long time = 0L;
  
  public static int advcatidenable = 0;
  
  private ArrayList<Country> countryCodeList = null;
  
  private static String propfilePath = "";
  
  private static String currentPath = "";
  
  private ArrayList<String> m_artistNameList = null;
  
  private ArrayList<String> m_albumNameList = null;
  
  private static HashMap<String, String> serviceMap = new HashMap<String, String>();
  
  public static HashMap<String, String> getServiceMap() {
    if (serviceMap.size() <= 0)
      logger.info("No Country Available " + serviceMap.size()); 
    return serviceMap;
  }
  
  public static Hashtable getRbt_params() {
    return rbt_params;
  }
  
  public static Hashtable getCategory_params() {
    return category_params;
  }
  
  public ArrayList<String> getM_artistNameList() {
    return this.m_artistNameList;
  }
  
  public void setM_artistNameList(ArrayList<String> mArtistNameList) {
    this.m_artistNameList = mArtistNameList;
  }
  
  public ArrayList<String> getM_albumNameList() {
    return this.m_albumNameList;
  }
  
  public void setM_albumNameList(ArrayList<String> mAlbumNameList) {
    this.m_albumNameList = mAlbumNameList;
  }
  
  public static synchronized TSSJavaUtil instance(String _currentPath) {
    long newtime = (new Date()).getTime();
    logger.info("Inside instance method with argument NewTime[" + newtime + "] instance[" + instance_ + "]");
    if (instance_ == null || newtime - time > 3600000L) {
      logger.info("In instance(String _currentPath),This is the  time || [" + time + "] >1000*60*60 Or when Cache made fist time So _currentPath = " + _currentPath + " HOME IS = " + System.getenv("HOME"));
      currentPath = _currentPath;
      propfilePath = System.getenv("PROPERTY_FILE_PATH");
      System.out.println("In instance(String _currentPath), propfilePath = " + propfilePath);
      instance_ = new TSSJavaUtil();
      time = newtime;
    } 
    logger.info("In instance(String _currentPath), This is the  time || [" + time + "] when not reload");
    return instance_;
  }
  
  public static synchronized TSSJavaUtil instance() {
    long newtime = (new Date()).getTime();
    if (instance_ == null || newtime - time > 3600000L) {
      logger.info("Inside instance(),This is the  time || [" + time + "] >1000*60*60 Or when Chache made fist time ");
      instance_ = new TSSJavaUtil();
      time = newtime;
    } 
    logger.info("Inside instance(), This is the  time || [" + time + "] when not reload ");
    return instance_;
  }
  
  public String getKeyValue(String key) {
    String value = properties.getProperty(key);
    if (value == null) {
      logger.error("\n\nReturning value for KEY:[" + key + "] from telemune_vccadmin.properties not found so check it \n\n");
    } else {
      logger.info("Returning value for KEY:[" + key + "] from telemune_vccadmin.properties: [" + value + "]");
    } 
    return value;
  }
  
  private TSSJavaUtil() {
    java.sql.Connection con = null;
    Statement stmt = null;
    ResultSet rs = null;
    String driver = "oracle.jdbc.OracleDriver";
    FileInputStream fis1 = null;
    properties = new Properties();
    try {
      if (propfilePath == null) {
        propfilePath = System.getenv("PROPERTY_FILE_PATH");
        fis1 = new FileInputStream(String.valueOf(propfilePath) + "/telemune_vccadmin.properties");
      } else {
        fis1 = new FileInputStream(String.valueOf(propfilePath) + "/telemune_vccadmin.properties");
      } 
      logger.info("properties file path= " + propfilePath);
      properties.load(fis1);
      fis1.close();
      GlobalParam.loadConfigurations(properties);
    } catch (IOException e) {
      logger.error("\n\n Error While Loading telemune_vccadmin.properties from properties file path so check it \n\n" + e);
      e.printStackTrace();
      return;
    } 
    String strUser = "";
    String strPass = "";
    String strUrl = "";
    try {
      strUser = properties.getProperty("USER");
      strPass = properties.getProperty("PASS");
      strUrl = properties.getProperty("URL");
      driver = properties.getProperty("DRIVER");
      logger.info("Fetched Properties: db user = [" + strUser + "] pass= [" + strPass + "] url= [" + strUrl + "]");
    } catch (Exception e) {
      logger.error("\n\n\t Some Param_types are Not defined in telemune_vccadmin.properties file\n\n");
      e.printStackTrace();
    } 
    try {
      Class.forName(driver);
      con = DriverManager.getConnection(strUrl, strUser, strPass);
    } catch (ClassNotFoundException cnfe) {
      logger.error("Can t find class for driver: " + driver);
      return;
    } catch (SQLException ex) {
      ex.printStackTrace();
      logger.error("SQLException in TssJavaUtil.java:" + ex);
      return;
    } 
    try {
      setLanguageList();
      stmt = con.createStatement();
      String query = "select PARAM_NAME, PARAM_VALUE from APP_CONFIG_PARAMS";
      logger.info("Loading App Config params from  APP_CONFIG_PARAMS table with Select Query: " + query);
      rs = stmt.executeQuery(query);
      logger.info(query);
      app_params = new Hashtable<String, String>();
      while (rs.next())
        app_params.put(rs.getString("PARAM_NAME").toUpperCase(), rs.getString("PARAM_VALUE")); 
      logger.info("Total data from crbt_app_config_params:" + app_params.size());
      rs.close();
      stmt.close();
    } catch (SQLException exp) {
      exp.printStackTrace();
    } 
    try {
      countryCode = ((String)app_params.get("COUNTRY_CODE")).toString();
      logger.info("countryCode " + countryCode);
      getServices(con);
    } catch (Exception e) {
      logger.error("\n\n\tparam_type LOCAL_COUNTRY  is not defined in  telemune_vccadmin.properties file\n\n");
    } 
    try {
      if (rs != null)
        rs.close(); 
      stmt.close();
      con.close();
    } catch (Exception exp) {
      logger.error("Exception While closing rs,stmt or con:" + exp);
      exp.printStackTrace();
    } 
  }
  
  public String getAppConfigParam(String paramName) {
    try {
      String retVal = "";
      String param = paramName.toUpperCase();
      retVal = app_params.get(param);
      logger.info("param name is" + param + " value is" + retVal);
      if (retVal == null)
        logger.error("\n\n\t PARAM_VALUE for PARAM_TAG:[" + paramName + "] not Defined or null in app_config_params table so Check it \n\n"); 
      return retVal;
    } catch (Exception e) {
      logger.error("\n\n\t PARAM_VALUE for PARAM_TAG:[" + paramName + "] not Defined or null in app_config_params table so Check it \n\n" + e);
      e.printStackTrace();
      return "Null";
    } 
  }
  
  public void setLanguageList() {
    try {
      int cnt = Integer.parseInt(properties.getProperty("LANG_COUNT"));
      languageBean = new ArrayList<LanguageBean>();
      LanguageBean bean = null;
      for (int i = 1; i <= cnt; i++) {
        bean = new LanguageBean();
        bean.setCode(properties.getProperty("LCODE" + i).toLowerCase());
        bean.setName(properties.getProperty("LNAME" + i));
        languageBean.add(bean);
      } 
    } catch (Exception e) {
      logger.error("\n\n\t Languages are not configured in telemune_vccadmin.properties file\n\n" + e);
      e.printStackTrace();
    } 
  }
  
  public ArrayList<LanguageBean> getLanguageList() {
    return languageBean;
  }
  
  public static synchronized TSSJavaUtil reload() {
    logger.info("Reload TSSJavaUtil instance.........");
    properties = null;
    app_params = null;
    rbt_params = null;
    category_params = null;
    propFile = null;
    languageBean = null;
    conPool = null;
    alMsisdnRange = new ArrayList();
    instance_ = new TSSJavaUtil();
    return instance_;
  }
  
  public String getInternationalNumber(String number) {
    logger.info("Inside getInternationalNumber To Convert MSISDN To International Format, MSISDN: " + number);
    String retVal = "";
    if (multicountry == 1) {
      boolean a = true;
      if (number.startsWith("00"))
        number = number.substring(2); 
      if (number.startsWith("0") || number.startsWith("+"))
        number = number.substring(1); 
      for (int k = 0; k < alMsisdnRange.size(); k++) {
        MsisdnVal msvals = (MsisdnVal)alMsisdnRange.get(k);
        logger.info("multicountry=1 So start range --->  " + msvals.getstmsisdn() + "end range -->  " + msvals.getedmsisdn());
        if (Double.parseDouble(number) > Double.parseDouble(msvals.getstmsisdn()) && Double.parseDouble(number) < Double.parseDouble(msvals.getedmsisdn())) {
          if (number.startsWith(msvals.getcountrycode())) {
            retVal = number;
            a = false;
            break;
          } 
          retVal = String.valueOf(msvals.getcountrycode()) + number;
          a = false;
          break;
        } 
      } 
      if (a)
        retVal = number; 
    } else {
      logger.info("Multicountry=0 So MSISDN LENGTH:" + getMSISDNLength() + "   TOTAL MSISDN LENGTH:" + getTotalMsisdnLength() + "   COUNTRY CODE: " + countryCode);
      if (number.length() == getMSISDNLength()) {
        retVal = String.valueOf(countryCode) + number;
      } else if (number.length() == getTotalMsisdnLength() && number.startsWith(countryCode)) {
        retVal = number;
      } else {
        retVal = number;
      } 
      logger.info("==MSISDN in International Format [" + retVal + "]===");
    } 
    return retVal;
  }
  
  public String getNationalNumber(String number) {
    String retVal = "";
    if (number.startsWith("00") || number.startsWith(countryCode)) {
      retVal = number.substring(2);
    } else if (number.startsWith("0")) {
      retVal = number.substring(1);
    } else {
      retVal = number;
    } 
    return retVal;
  }
  
  public int isChargingEnabled() {
    try {
      int i = Integer.parseInt(properties.getProperty("DOCHARGING"));
      return i;
    } catch (Exception e) {
      logger.error("\n\n\tParam_type DOCHARGING  is not defined in telemune_vccadmin.properties file\n\n" + e);
      e.printStackTrace();
      return -1;
    } 
  }
  
  public int isActDeactEnabled() {
    try {
      int i = Integer.parseInt(properties.getProperty("DOACTDEACT"));
      return i;
    } catch (Exception e) {
      logger.error("\n\n\tParam_type DOACTDEACT  is not defined in telemune_vccadmin.properties file\n\n" + e);
      e.printStackTrace();
      return -1;
    } 
  }
  
  public String getSSFServer() {
    try {
      String strSSFServer = properties.getProperty("SSF_SERVER_HOST");
      return strSSFServer;
    } catch (Exception e) {
      logger.error("\n\n\tParam_type SSF_SERVER_HOST  is not defined in telemune_vccadmin.properties file\n\n" + e);
      e.printStackTrace();
      return "";
    } 
  }
  
  public short getSSFPort() {
    try {
      short shSSFPort = Short.parseShort(properties.getProperty("SSF_SERVER_PORT"));
      return shSSFPort;
    } catch (Exception e) {
      logger.error("\n\n\tParam_type SSF_SERVER_PORT  is not defined in telemune_vccadmin.properties file\n\n" + e);
      e.printStackTrace();
      return -1;
    } 
  }
  
  public String getSSFServerCre() {
    try {
      String strSSFServer = properties.getProperty("SSF_SERVER_HOST_CRE");
      return strSSFServer;
    } catch (Exception e) {
      logger.error("\n\n\tParam_type SSF_SERVER_HOST_CRE  is not defined in telemune_vccadmin.properties file\n\n" + e);
      e.printStackTrace();
      return "";
    } 
  }
  
  public short getSSFPortCre() {
    try {
      short shSSFPort = Short.parseShort(properties.getProperty("SSF_SERVER_PORT_CRE"));
      return shSSFPort;
    } catch (Exception e) {
      logger.error("\n\n\tParam_type SSF_SERVER_PORT_CRE  is not defined in telemune_vccadmin.properties file\n\n" + e);
      e.printStackTrace();
      return -1;
    } 
  }
  
  public ConnectionPool getconnectionPool() {
    if (conPool == null) {
      conPool = new ConnectionPool();
      ReportConnectionPool.dbUtilConPool = conPool;
      ReportConnectionPool.databaseType = 1;
      ReportConnectionPool.conPoolType = 2;
      logger.info("This is new conPool object in TSSJavaUtil..." + conPool.hashCode());
      return conPool;
    } 
    logger.info("This is old conPool object in TSSJavaUtil. " + conPool.hashCode());
    return conPool;
  }
  
  public Connection getconnection() {
    Connection con = null;
    con = getconnectionPool().getConnection();
    logger.info("This is the single con object..|| " + con.hashCode());
    return con;
  }
  
  public void freeConnection(Connection con) {
    getconnectionPool().free(con);
  }
  
  public String getCategoryName(String paramName) {
    try {
      String retVal = "";
      String param = paramName.toUpperCase();
      retVal = (String)category_params.get(param);
      return retVal;
    } catch (Exception exception) {
      logger.error("Error in getCategoryName():" + exception);
      return "Null";
    } 
  }
  
  public String getRbtName(String paramName) {
    try {
      String retVal = "";
      String param = paramName.toUpperCase();
      retVal = (String)rbt_params.get(param);
      return retVal;
    } catch (Exception exception) {
      logger.error("Error in getRbtName():" + exception);
      return "Null";
    } 
  }
  
  public ArrayList<String> getTotalServer() {
    int server = -1;
    try {
      server = Integer.parseInt(properties.getProperty("SERVER.COUNT"));
    } catch (Exception e) {
      logger.error("\n\n property SERVER.COUNT not defined in telemune_vccadmin.properties so check it \n\n" + e);
    } 
    ArrayList<String> serverlist = new ArrayList<String>();
    try {
      for (int i = 0; i < server; i++)
        serverlist.add(properties.getProperty("SERVER" + i)); 
    } catch (Exception e) {
      logger.error("\n\n\tParam_type related to SERVER.COUNT like SERVER1 etc  are not defined in telemune_vccadmin.properties file\n\n");
      e.printStackTrace();
    } 
    return serverlist;
  }
  
  public int getMSISDNLength() {
    int len = 10;
    try {
      len = Integer.parseInt(app_params.get("MSISDN_LENGTH"));
      logger.info("MSISDN_LENGTH from properties file:" + len);
    } catch (Exception e) {
      e.printStackTrace();
      logger.error("\n\nparam_type MSISDN_LENGTH  is not defined in telemune_vccadmin.properties file\n\n");
    } 
    return len;
  }
  
  public int getTotalMsisdnLength() {
    logger.info("In getTotalMsisdnLength()");
    int code = 971;
    int len = 9;
    try {
      code = Integer.parseInt(((String)app_params.get("COUNTRY_CODE")).toString());
    } catch (Exception e) {
      logger.error("\n\nparam_type LOCAL_COUNTRY  is not defined in  telemune_vccadmin.properties file\n\n");
    } 
    try {
      len = Integer.parseInt(app_params.get("MSISDN_LENGTH"));
    } catch (Exception e) {
      e.printStackTrace();
      logger.error("\n\n param_type MSISDN_LENGTH  is not defined in crbt_app_config_params tbl so check it \n\n");
    } 
    int count = 0;
    while (code > 0) {
      count++;
      int res = code % 10;
      code /= 10;
    } 
    logger.info("Total Msisdn length to return:" + (count + len) + ", Length of msisdn without country-code:" + len);
    return count + len;
  }
  
  public int getCountryCode() {
    int code = 971;
    try {
      code = Integer.parseInt(((String)app_params.get("COUNTRY_CODE")).toString());
    } catch (Exception e) {
      logger.error("\n\nparam_type LOCAL_COUNTRY  is not defined in  telemune_vccadmin.properties file\n\n");
    } 
    return code;
  }
  
  public int getMultiLangCatEnable() {
    int len = 10;
    try {
      len = Integer.parseInt(properties.getProperty("MULTI_LANG_CATEGORY_ENABLE"));
    } catch (Exception e) {
      e.printStackTrace();
      logger.error("\n\n param_type MULTI_LANG_CATEGORY_ENABLE  is not defined in telemune_vccadmin.properties file\n\n");
    } 
    return len;
  }
  
  public void EmptyParams() {
    properties = null;
    app_params = null;
    rbt_params = null;
    category_params = null;
    propFile = null;
    languageBean = null;
    conPool = null;
    this.propfileName = "";
    alMsisdnRange = null;
  }
  
  public ArrayList<Country> getCountryCodeList() {
    return this.countryCodeList;
  }
  
  public HashMap<String, String> getServices(java.sql.Connection con) {
    logger.info("inside getServices()");
    HashMap<String, String> serviceMap_l = null;
    Statement stmt = null;
    ResultSet rs = null;
    String query = "select SERVICE_OFFER from SERVICE_PROVIDER where SUBSCRIPTION in ('S','N')";
    logger.info("Query >>[ " + query + "]");
    try {
      stmt = con.createStatement();
      logger.info("Loading SERVICE PROVIDER Select Query: " + query);
      rs = stmt.executeQuery(query);
      if (serviceMap.size() > 0)
        serviceMap.clear(); 
      while (rs.next() && rs != null) {
        if (rs.getString("SERVICE_OFFER").equalsIgnoreCase("VM")) {
          serviceMap.put(rs.getString("SERVICE_OFFER"), "Voice Mail");
          continue;
        } 
        if (rs.getString("SERVICE_OFFER").equalsIgnoreCase("VN")) {
          serviceMap.put(rs.getString("SERVICE_OFFER"), "Voice Note");
          continue;
        } 
        if (rs.getString("SERVICE_OFFER").equalsIgnoreCase("MCA")) {
          serviceMap.put(rs.getString("SERVICE_OFFER"), "MCA");
          continue;
        } 
        serviceMap.put(rs.getString("SERVICE_OFFER"), 
            rs.getString("SERVICE_OFFER"));
      } 
      stmt.close();
      rs.close();
    } catch (Exception e) {
      logger.info("Exception in getting Service " + e);
    } finally {
      try {
        if (rs != null)
          rs.close(); 
        if (stmt != null)
          stmt.close(); 
      } catch (Exception e) {
        logger.info("Exception while closing");
        e.printStackTrace();
      } 
    } 
    logger.info("SERVICE PROVIDER loaded size [" + serviceMap.size() + "]");
    return serviceMap;
  }
}
