package com.telemune.vcc.common;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.dispatcher.SessionMap;
import org.apache.struts2.interceptor.SessionAware;

import com.opensymphony.xwork2.ActionSupport;
import com.telemune.dbutilities.Connection;
import com.telemune.vcc.model.HistoryDataBean;

public class ValidateAction extends ActionSupport implements SessionAware
{
	Logger logger= Logger.getLogger(ValidateAction.class);
	public String logoutMessage="";
	public String linkName="";
	public String actionName="";
	public String message="";
	
	public String getActionName() {
		return actionName;
	}

	public void setActionName(String actionName) {
		this.actionName = actionName;
	}

	public String getLinkName() {
		return linkName;
	}

	public void setLinkName(String linkName) {
		this.linkName = linkName;
	}

	public String getLogoutMessage() {
		return logoutMessage;
	}

	public void setLogoutMessage(String logoutMessage) {
		this.logoutMessage = logoutMessage;
	}

	public Map<String,Object> sessionMap;
	@Override
	public void setSession(Map<String, Object> arg0) {
		this.sessionMap=arg0;		
	}
	
	
public boolean isLinkAssigned(int linkId)
{
	if(((SessionHistory)sessionMap.get("sessionHistory")).isAllowed(linkId))
		return true;
	else
		return false;
}

public String invalidParam() 
{
	logoutMessage=getText("emptyParams");//"Some parameter is empty or not valid. Please check entered parameter";
	return "success";
}



public String checkSession()
{
	logger.info("In checkSession() of ValidateAction.java");
	try{
		HttpServletRequest request=ServletActionContext.getRequest();
		HttpSession session=request.getSession();
		String sess=((SessionHistory)session.getAttribute("sessionHistory")).getUser();
		
		//logger.info(" inside AccountInfo session : " +sess);
		//System.out.println(" inside AccountInfo session : " +sess);
		
		if ( sess == null || sess.isEmpty()) {
			logger.info("\n\n SESSION EXPIRED !!!!!\n\n");			
			return "error";
		}else
		{	 
			return "success";
		}
	}
	catch (Exception e) {
		logger.error("Error in checkSession() of ValidateAction.java:: "+e);
		e.printStackTrace();
		setLogoutMessage(getText("sessionExpire"));
		return "error";
	}

}//checkSession() ends

public String logout() throws Exception
{
	logger.info("In logout() of ValidateAction.java");
	try{
		
		HttpServletRequest request=ServletActionContext.getRequest();
		HttpServletResponse response=ServletActionContext.getResponse();
		HttpSession session=request.getSession();
		
		// Added By AbhiShek Rana for creating user history.
		
		String user=((SessionHistory) session.getAttribute("sessionHistory")).getUser();
		String roleName = ((SessionHistory) session.getAttribute("sessionHistory")).getRoleName();
		HistoryDataBean historyDataBean =null;
		HistoryGenerator historyGenerator =null;
		historyDataBean = new HistoryDataBean();
		historyDataBean.setUser(user);
		historyDataBean.setAction(getText("logout"));
		historyDataBean.setEvent("Log Out");
		historyDataBean.setRole(roleName);
		historyDataBean.setMsg("["+user+"] Logged out from System");
		historyGenerator = new HistoryGenerator();
		Connection con = TSSJavaUtil.instance().getconnection();
		historyGenerator.insertHistoryData(historyDataBean,
				con);
		
		//////////////////////// END ////////////////////////
		this.logoutMessage=getText("logoutsuccess");
		if (sessionMap == null || sessionMap.isEmpty()) {
			logger.info("\n\n SESSION EXPIRED !!!!!\n\n");			
			//this.message = "Your Session Expired, Please Login Again !!";
			response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
			response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
			response.setDateHeader("Expires", 0);
			if (sessionMap instanceof SessionMap) {
				((SessionMap) sessionMap).invalidate();
			}
			return "success";
		}

		// this.message = "You Are Successfully Logged Out !";
		response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
		response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
		response.setDateHeader("Expires", 0);
		if (sessionMap instanceof SessionMap) {
			((SessionMap) sessionMap).invalidate();			
			logger.info("\n\n SESSION EXPIRED !!!!!\n\n");
		}
		logger.info("<----------------------------Logged out successfully---------------------------------->");
		
		return "success";


	}catch (Exception e) {
		logger.error("Error in logout() of ValidateAction.java:"+e);
		return "failure";
	}
}//logout() ends



}//class ends

