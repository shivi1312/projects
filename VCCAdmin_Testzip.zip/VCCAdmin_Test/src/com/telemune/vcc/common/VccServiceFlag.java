package com.telemune.vcc.common;

public class VccServiceFlag {

	public final static int recording_enable_disable = 1;//1 is position service flag and flag value are 0 for active 1 for de-active
	public final static int blacklist_enable_disable = 2;//2 is position service flag and flag value are 0 for active 1 for de-active
	public final static int time_setting_enable_disable = 3;//3 is position service flag and flag value are 0 for active 1 for de-active
	public final static int friend_limit_enable_disable =4;//4 is position service flag and flag value are 0 for active 1 for de-active
	public final static int transfer_mail_enable_disable = 5;//5 is position service flag and flag value are 0 for active 1 for de-active
	public final static int follow_me_enable_disable = 6; //6 is position service flag and flag value are 0 for active 1 for de-active
	public final static int auto_sms_enable_disable = 7; //7 is position service flag and flag value are 0 for active 1 for de-active
	public final static int alternative_msisdn_enable_disable = 8; //8 is position service flag and flag value are 0 for active 1 for de-active
	public final static int notification_enable_disable = 9; //9 is position service flag and flag value are 0 for active 1 for de-active
	public final static int message_header_enable_disable = 10; // 10 is position service flag and flag value are 0 for active 1 for de-active
	
	
}
