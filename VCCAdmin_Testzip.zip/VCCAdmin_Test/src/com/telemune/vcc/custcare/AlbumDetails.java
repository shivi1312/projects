package com.telemune.vcc.custcare;

import com.telemune.vcc.common.RbtDetails;

public class AlbumDetails
{
    private String msisdn = null;
    private long albumId = -1;
    private long rbtId = -1;
    private String albumName = null;
    private String creationDate = null;
    private String ivrName = null;
    private RbtDetails[] rbts = null;
    private boolean deleteFlag;
	
    
    public boolean isDeleteFlag() {
		return deleteFlag;
	}

	public void setDeleteFlag(boolean deleteFlag) {
		this.deleteFlag = deleteFlag;
	}

	public AlbumDetails(){ }

    public String getMsisdn() {
	return msisdn;
    }
    public long getAlbumId() {
        return albumId;
    }
    public long getRbtId() {
        return rbtId;
    }
    public void setRbtId(long rbtId) {
        this.rbtId = rbtId;
    }
    public String getAlbumName() {
	return albumName;
    }
    public String getIvrName() {
	return ivrName;
    }
    public String getCreationDate() {
	return creationDate;
    }
    public RbtDetails[] getRbts() {
	return rbts;
    }
    
    public void setMsisdn(String msisdn) {
        this.msisdn = msisdn;
    }
    public void setAlbumId(long albumId ) {
        this.albumId = albumId;
    }
    public void setAlbumName(String albumName) {
        this.albumName = albumName;
    }
    public void setIvrName(String ivrName) {
        this.ivrName = ivrName;
    }
    public void setCreationDate(String creationDate) {
        this.creationDate = creationDate;
    }
    public void setRbts(RbtDetails[] rbts) {
        this.rbts = rbts;
    }
}
