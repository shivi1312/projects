package com.telemune.vcc.custcare;
import com.telemune.dbutilities.*;
import com.telemune.vcc.common.*;

import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.*;

import org.apache.log4j.*;
public class AlbumManager 
{
        private static Logger logger=Logger.getLogger(AlbumManager.class);
	private Connection con;
	private ConnectionPool conPool;
	private String subProfile = null;
	//private SessionHistory sessionHistory = null;
	private String interfaceType="C";
	private String user;
	public AlbumManager() 
	{
		conPool = null;
	}

	public void setConnectionPool(ConnectionPool conPool) 
	{
		this.conPool = conPool;
	}

	public ConnectionPool getConnectionPool() 
	{
		return conPool;
	}

	public void setSubscriberProfile(String sp)
	{
		//this.subProfile = sp;	
		this.subProfile = "P";	
	}

	public void setUser(String user)
	{
		this.user=user;
	}
/*	public void setSessionHistory(SessionHistory sh)
	{
		this.sessionHistory = sh;	
	}
*///Hide By ekansh
	
	public int addAlbum(String msisdn, String albumName,Connection con) 
	{
		logger.info("inside function addAlbum()  where MSISDN ["+msisdn+"] and albumName [ "+albumName+" ]");
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String query = null;
		boolean autoCommit = false;
		try 
		{
			if(albumName.toLowerCase().startsWith("my album") || albumName.toLowerCase().startsWith("myalbum") || albumName.toLowerCase().startsWith("album"))
			{
				return 2;
			}
			//con = conPool.getConnection();
			if(con == null) {
				logger.info("Connection is NULL");
				return -99;
			}
			query = "select WALLET_ID from CRBT_WALLET_MASTER where MSISDN = ? and UPPER(WALLET_NAME) = ?";	
			logger.info("query is "+query);
			pstmt = con.prepareStatement(query);
			pstmt.setString(1,msisdn);
			pstmt.setString(2,albumName.toUpperCase());
			rs = pstmt.executeQuery();
			if(rs.next()) //if record already existing
			{
				logger.info("found wallet id in table");
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				return 0;
			}
			else
			{
				logger.info("wallet id not found in table");
			}

			query = "select max(IVR_NAME) TOTAL from CRBT_WALLET_MASTER where MSISDN = ?";
			logger.info("query is "+query);
			pstmt = con.prepareStatement(query);
			pstmt.setString(1,msisdn);
			rs = pstmt.executeQuery();
			rs.next();// will always have the record
			int count = rs.getInt("TOTAL");
			logger.info("TOTAL = "+count);
			autoCommit = con.getAutoCommit();
			con.setAutoCommit(false);

			long walletId = 0;
			query = "select wallet_id_seq.nextval from dual";
			pstmt = con.prepareStatement(query);
			rs = pstmt.executeQuery();
			if (rs.next())
			{
				walletId = rs.getLong("NEXTVAL");
			}

			query = "insert into CRBT_WALLET_MASTER (MSISDN, WALLET_ID, CREATE_DATE, WALLET_NAME, IVR_NAME) values(?, ?, sysdate, ?, ?)";
			logger.info("query is "+query);
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, msisdn.trim());
			pstmt.setLong(2, walletId);
			pstmt.setString(3, albumName.trim());
			pstmt.setInt(4, count+1);
			pstmt.executeUpdate();
			logger.info("query is executed");
			con.commit();
			con.setAutoCommit(autoCommit);

			insertIntoAlbumLog(msisdn, 0, walletId, 1, "N",con);
			insertIntoSubscriberAudit(msisdn, 1, "Album added",con);

			if(rs != null) rs.close();
			if(pstmt != null) pstmt.close();
		}
		catch(SQLException sqle)
		{
			try {
				con.rollback();
				con.setAutoCommit(autoCommit);
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
			} catch(Exception exp) {}                
			sqle.printStackTrace();
			logger.error("Exception in addAlbum",sqle);
			return -99;
		}
		/*finally 
		{
			if(con != null) conPool.free(con);
		}*/
		return 1;
	}

	public int removeAlbum(String msisdn, long albumId,Connection con) {
		logger.info("inside removeAlbum() msisdn="+msisdn+" albumId="+albumId);
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String query = null, queryUpdate = null;
		boolean autoCommit = false;
		try 
		{
			//con = conPool.getConnection();
			if(con == null) {
				logger.info("Connection is NULL");
				return -99;
			}

			query = "select WALLET_ID from CRBT_WALLET_CONTENT where WALLET_ID = ?";
			logger.info("query is "+query);
			pstmt = con.prepareStatement(query);
			pstmt.setLong(1, albumId);
			rs = pstmt.executeQuery();
			if(rs.next()) //if record already existing
			{
				logger.info("wallet id is found in table");
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				return 0;
			}
			else
			{
				logger.info("no wallet id is found");
			}

			autoCommit = con.getAutoCommit();
			con.setAutoCommit(false);

			int ivrName = -1;
			query = "select IVR_NAME from CRBT_WALLET_MASTER where WALLET_ID = ?";
			logger.info("query = "+query);
			pstmt = con.prepareStatement(query);
			pstmt.setLong(1, albumId);
			rs = pstmt.executeQuery();
			if (rs.next())
			{	
				ivrName = rs.getInt("IVR_NAME");
				logger.info("ivrNamw = "+ivrName);
			}
			else
			{
				logger.info("ivr_name not found for this wallet_id");
			}

			query = "delete from CRBT_WALLET_MASTER where WALLET_ID = ?";
			logger.info("query is "+query);
			pstmt = con.prepareStatement(query);
			pstmt.setLong(1, albumId);
			pstmt.executeUpdate();

			query = "update CRBT_WALLET_MASTER set IVR_NAME = IVR_NAME-1 where MSISDN = ? and IVR_NAME > ?";	
			logger.info("query is "+query);
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, msisdn.trim());
			pstmt.setInt(2, ivrName);
			pstmt.executeUpdate();

			con.commit();
			con.setAutoCommit(autoCommit);

			insertIntoAlbumLog(msisdn, 0, albumId, 2, "N",con);
			insertIntoSubscriberAudit(msisdn, 1, "Album Removed",con);

			if(rs != null) rs.close();
			if(pstmt != null) pstmt.close();
		}
		catch(SQLException sqle)
		{
			try {
				con.rollback();
				con.setAutoCommit(autoCommit);
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
			} catch(Exception exp) {}                
			sqle.printStackTrace();
			logger.error("Exception in removeAlbum",sqle);
			return -99;
		}
		/*
		finally 
		{
			if(con != null) conPool.free(con);
		}*/
		return 1;
	}

	public int updateAlbum(String msisdn, long albumId, String albumName,Connection con) 
	{
		logger.info("Inside function updateAlbum().....where MSISDN ["+msisdn+"] AND ALBID ["+albumId+"] AND ALBUMNAME ["+albumName+"]");
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String query = null;
		boolean autoCommit = false;
		try 
		{
			if(albumName.toLowerCase().startsWith("my album") || albumName.toLowerCase().startsWith("myalbum") || albumName.toLowerCase().startsWith("album"))
			{
				return 2;
			}
			//con = conPool.getConnection();
			if(con == null) {
				logger.info("Connection is NULL");
				return -99;
			}
			autoCommit = con.getAutoCommit();
			con.setAutoCommit(false);
			query = "select WALLET_ID from CRBT_WALLET_MASTER where MSISDN = ? and upper(WALLET_NAME) = ?";
			pstmt = con.prepareStatement(query);
			pstmt.setString(1,msisdn);
			pstmt.setString(2,albumName.toUpperCase());
			rs = pstmt.executeQuery();
			if(rs.next()) //if record already existing
				return 0;
			else
				logger.info("wallet does not exists");
			query = "update CRBT_WALLET_MASTER set WALLET_NAME=? where WALLET_ID=? and MSISDN=?";
			logger.info("query is "+query);
			pstmt = con.prepareStatement(query);
			pstmt.setString(1,albumName.trim());
			pstmt.setLong(2,albumId);
			pstmt.setString(3,msisdn.trim());
			pstmt.executeUpdate();


			con.commit();
			con.setAutoCommit(autoCommit);

			insertIntoAlbumLog(msisdn, 0, albumId, 3, "N",con);
			insertIntoSubscriberAudit(msisdn, 1, "Album Modified",con);

			if(rs != null) rs.close();
			if(pstmt != null) pstmt.close();
		}
		catch(SQLException sqle)
		{
			try {
				con.rollback();
				con.setAutoCommit(autoCommit);
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
			} catch(Exception exp) {}                
			sqle.printStackTrace();
			logger.error("Exception in updateAlbum",sqle);
			return -99;
		}
		/*finally 
		{
			if(con != null) conPool.free(con);
		}*/
		return 1;
	}

	//public int getAlbumDetails(String msisdn, long albumId, AlbumDetails albumDetails, ArrayList album1) 
	public int getAlbumDetails(String msisdn, long albumId, AlbumDetails albumDetails,Connection con) 
	{
		logger.info("Inside  getAlbumDetails()   msisdn ["+msisdn+"]  albumId  ["+albumId+"] ");
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String query = null;
		int specialCatId=998;
		int recordedCatId=999;

		try 
		{
			//con = conPool.getConnection();
			if(con == null) {
				logger.info("Connection is NULL");
				return -99;
			}

			query = "SELECT wallet_name, ivr_name FROM crbt_wallet_master WHERE msisdn=? and wallet_id=?";
			pstmt = con.prepareStatement(query);
			pstmt.setString(1,msisdn);
			pstmt.setLong(2,albumId);
			rs = pstmt.executeQuery();
			while(rs.next())
			{
				albumDetails.setAlbumId(albumId);
				albumDetails.setAlbumName(rs.getString("wallet_name"));
				albumDetails.setIvrName(rs.getString("ivr_name"));
				albumDetails.setMsisdn(msisdn);
			}
			if(rs != null) rs.close();
			if(pstmt != null) pstmt.close();

			specialCatId   = Integer.parseInt(TSSJavaUtil.instance().getAppConfigParam("SPECIAL_CONTROL_CATID"));
			recordedCatId  = Integer.parseInt(TSSJavaUtil.instance().getAppConfigParam("CRBT_RECORDED_CATEGORY_ID"));

		//	query = "select RB.MASKED_NAME, RB.RBT_CODE, RB.CAT_ID, CM.MASKED_NAME CM_MASKED_NAME from CRBT_CATEGORY_MASTER CM, CRBT_RBT RB where RB.RBT_CODE in (select RBT_CODE from CRBT_WALLET_CONTENT where WALLET_ID = ?) and RB.SHOW_ON_WEB = 'Y' and RB.CAT_ID = CM.CAT_ID";
			query = "select RB.MASKED_NAME, RB.RBT_CODE, RB.CAT_ID, CM.MASKED_NAME CM_MASKED_NAME, to_char(CWC.CREATE_DATE,'dd-mm-yyyy')CREATE_DATE , to_char(add_months(CWC.CREATE_DATE,12),'dd-mm-yyyy') Expiry_DATE from CRBT_WALLET_CONTENT CWC, CRBT_CATEGORY_MASTER CM, CRBT_RBT RB where RB.RBT_CODE in (select RBT_CODE from CRBT_WALLET_CONTENT where WALLET_ID = ? and CWC.MSISDN=?) and RB.SHOW_ON_WEB = 'Y' and RB.CAT_ID = CM.CAT_ID and RB.RBT_CODE = CWC.RBT_CODE order by CREATE_DATE desc" ;
			
			//            query = "select cm.masked_name cm_masked_name, rm.categoryid, rm.rbt_code, rb.masked_name, rb.rbt_nick from crbt_category_master cm, crbt_ringtone_map rm, crbt_rbt rb where rb.rbt_code in(select cwc.rbt_code from crbt_wallet_content cwc where cwc.wallet_id = ? ) and rb.show_on_web='Y' and rm.categoryid=cm.categoryid and rb.rbt_code=rm.rbt_code and rb.rbt_code not in(select rbt_code from crbt_rbt_control) and not(cm.categoryid = ?) order by cm.masked_name, rb.rbt_score desc";
			logger.info("query is "+query);
			pstmt = con.prepareStatement(query);
			pstmt.setLong(1, albumId);
			pstmt.setString(2, msisdn);
			//pstmt.setInt(2, specialCatId);
			rs = pstmt.executeQuery();
			ArrayList rbtList = new ArrayList();
			while(rs.next()) {
				if(albumId!=rs.getInt("RBT_CODE"))
				{
			//	RbtDetails rbt = new RbtDetails(rs.getInt("RBT_CODE"),rs.getString("MASKED_NAME"),rs.getInt("CAT_ID"),rs.getString("CM_MASKED_NAME"));
				RbtDetails rbt = new RbtDetails(rs.getInt("RBT_CODE"),rs.getString("MASKED_NAME"),rs.getInt("CAT_ID"),rs.getString("CM_MASKED_NAME"), rs.getString("CREATE_DATE"),rs.getString("Expiry_DATE"));
				rbtList.add(rbt);
				}
			}
			RbtDetails[] rbts = new RbtDetails[rbtList.size()];
			Iterator itr = rbtList.iterator();
			short index=0;
			while(itr.hasNext())
			{
				rbts[index] = (RbtDetails)itr.next();
				index++;
			}
			albumDetails.setRbts(rbts);
			if(rs != null) rs.close();
			if(pstmt != null) pstmt.close();
			
		}
		catch(SQLException sqle)
		{
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
			} catch(Exception exp) {}                
			sqle.printStackTrace();
			logger.error("Exception in getAlbumDetails",sqle);
			return -99;
		}
		/*finally 
		{
			if(con != null) conPool.free(con);
		}*/
		return 1;
	}

	public int getAlbumIdNames(String msisdn, String name, java.util.ArrayList albumIdName,Connection con) 
	{
		logger.info("Inside function getAlbumIdNames() where MSISDN [ "+msisdn+" ] SEARCHTEXT [ "+name+" ]");
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String query = null;
		try 
		{
			//con = conPool.getConnection();
			if(con == null) {
				logger.info("Connection is NULL");
				return -99;
			}

			query = "SELECT wallet_id, wallet_name, ivr_name FROM crbt_wallet_master WHERE msisdn = ? and UPPER(wallet_name) like ? order by ivr_name";
			logger.info("query = "+query);
			pstmt = con.prepareStatement(query);
			pstmt.setString(1,msisdn);
			pstmt.setString(2,"%"+name.toUpperCase()+"%");//true:false
			rs = pstmt.executeQuery();
			if(!rs.next())
			{
				logger.info("wallet does not exists");
				return 0;
			}
			do
			{
				AlbumDetails album = new AlbumDetails();
				album.setAlbumId(rs.getLong("wallet_id"));
				album.setAlbumName(rs.getString("wallet_name"));
				album.setIvrName(rs.getString("ivr_name"));
				albumIdName.add(album);
//		albumIdName.put(new Long(rs.getLong("wallet_id")), rs.getString("ivr_name")+","+rs.getString("wallet_name"));
			}while(rs.next());
			if(rs != null) rs.close();
			if(pstmt != null) pstmt.close();
		}
		catch(SQLException sqle)
		{
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
			} catch(Exception exp) {}                
			sqle.printStackTrace();
			logger.error("Exception in getAlbumIdNames",sqle);
			return -99;
		}
		/*finally 
		{
			if(con != null) conPool.free(con);
		}*/
		return 1;
	}

	/*public int addRbtAlbum(String msisdn, long albumId, int rbtId, StringBuffer albumName) 
	{
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String query = null;
		boolean autoCommit = false;
		try 
		{
			con = conPool.getConnection();
			if(con == null) {
				logger.info("Connection is NULL");
				return -99;
			}
			int ret = findRbt(con, msisdn, rbtId, albumName);

			if(ret == 1)
			{
				logger.info("Rbt "+rbtId+" is present in some album");
				return 99; // rbt present in some album
			}
			else if(ret == -99)
			{
				logger.info("Exception in findRbt()");
				return -99; //  exception in findRbt() method
			}
			autoCommit = con.getAutoCommit();
			con.setAutoCommit(false);

			long walletId = 0;

			if(albumName.toString().equalsIgnoreCase("null"))
			{
				//query = "insert into CRBT_WALLET_CONTENT(WALLET_ID, RBT_CODE, CREATE_DATE) values(?, ?, sysdate)";
				query = "insert into CRBT_WALLET_CONTENT(WALLET_ID, RBT_CODE, CREATE_DATE, MSISDN) values(?, ?, sysdate,?)";
				pstmt = con.prepareStatement(query);
				pstmt.setLong(1, albumId);
				pstmt.setInt(2, rbtId);
				pstmt.setString(3, msisdn); //to add MSISDN in table
				pstmt.executeUpdate();
				walletId = albumId;
			}
			else
			{
				query = "select wallet_id_seq.nextval from dual";
				pstmt = con.prepareStatement(query);
				rs = pstmt.executeQuery();
				if (rs.next())
				{
					walletId = rs.getLong("NEXTVAL");
				}

				query = "select max(IVR_NAME) TOTAL from CRBT_WALLET_MASTER where MSISDN = ?";
				pstmt = con.prepareStatement(query);
				pstmt.setString(1,msisdn);
				rs = pstmt.executeQuery();
				rs.next();// will always have the record
				int count = rs.getInt("total");
				query = "insert into CRBT_WALLET_MASTER (MSISDN, WALLET_ID, CREATE_DATE, WALLET_NAME, IVR_NAME) values(?, ?, sysdate, ?, ?)";
				pstmt = con.prepareStatement(query);
				pstmt.setString(1, msisdn);
				pstmt.setLong(2, walletId);
				pstmt.setString(3, albumName.toString().toUpperCase());
				pstmt.setInt(4, count+1);
				pstmt.executeUpdate();

				// ALBUM SUCCESSFULLY ADDED
				query = "insert into CRBT_WALLET_CONTENT (WALLET_ID, RBT_CODE, CREATE_DATE, MSISDN) values(?, ?, sysdate,?)";
				pstmt = con.prepareStatement(query);
				pstmt.setLong(1, walletId);
				pstmt.setInt(2, rbtId);
				pstmt.setString(3, msisdn); //to add MSISDN in table
				pstmt.executeUpdate();
			}

			//		if (updateFreeEventsUsed(msisdn) != 1)
			//		{	
			//		con.rollback();
			//		return 0;
			//		}

			if (updateRbtScore(rbtId) != 1)
			{	
				con.rollback();
				return 0;
			}

			int rbt_charge_code=-1;
			int freeEvents=-1;
	int advCat = Integer.parseInt(TSSJavaUtil.instance().getAppConfigParam("ADVERTISEMENT_CAT_ID")); 
			logger.info("Charging code------ "+advCat);
		//	int chr = doCharging(msisdn, rbtId);
		query = "select CHARGING_CODE from CRBT_RBT where RBT_CODE = ? and CAT_ID=?";
			pstmt = con.prepareStatement(query);
			pstmt.setInt(1, rbtId);
			pstmt.setInt(2, advCat);
			logger.info("Charging code------ "+rbt_charge_code);

			rs = pstmt.executeQuery();
			if(rs.next())
			{
				rbt_charge_code=Integer.parseInt(rs.getString("CHARGING_CODE"));
			logger.info("Charging code------ "+rbt_charge_code);
				
				logger.info("RBT_CHARGE_CODE= "+rbt_charge_code);
			}

			if(rs != null) rs.close();
			pstmt.close();

			int planIndicator = Integer.parseInt(TSSJavaUtil.instance().getAppConfigParam("DEFAULT_RATE_PLAN")); 

if(rbt_charge_code==-1)
{
			//	int chr = doCharging(msisdn, rbtId);
			query = "select FREE_RINGTONES, RBT_CHARGE_CODE from CRBT_RATE_PLANS where PLAN_INDICATOR = ?";
			pstmt = con.prepareStatement(query);
			pstmt.setInt(1, planIndicator);
			//logger.info(query);

			rs = pstmt.executeQuery();
			if(rs.next())
			{
				freeEvents=rs.getInt("FREE_RINGTONES");
				rbt_charge_code=Integer.parseInt(rs.getString("RBT_CHARGE_CODE"));
				logger.info("RBT_CHARGE_CODE= "+rbt_charge_code);
			}

			if(rs != null) rs.close();
			pstmt.close();
}
			TCPPacketCharging tcpCharge = new TCPPacketCharging();
		logger.info("addRbtAlbum(): msisdn="+msisdn);
			int chr = tcpCharge.doEventBasedCharging(msisdn, rbt_charge_code, rbtId,"-1",3, interfaceType); //action=1 for SUB // interfacetype='C' for custcare
			logger.info("AlbumManager: chr="+chr);
			if (chr != 1)
			{
				con.rollback();
				return ret;
			}

			con.commit();
			con.setAutoCommit(autoCommit);

				 insertIntoSettingCdr(msisdn, planIndicator, rbtId, 1);
			insertIntoAlbumLog(msisdn, rbtId, walletId, 4, "Y");
			insertIntoSubscriberAudit(msisdn, 0, "Rbt added to Album");

			if(rs != null) rs.close();
			if(pstmt != null) pstmt.close();
		}
		catch(SQLException sqle)
		{

			try {
				con.rollback();
				con.setAutoCommit(autoCommit);
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
			} catch(Exception exp) {}                
			sqle.printStackTrace();
			return -99;
		}
		finally 
		{
			if(con != null) conPool.free(con);
		}
		return 1;
	}*/
public int addRbtAlbum(String msisdn, long albumId, int rbtId, StringBuffer albumName,Connection con) 
	{
	logger.info("Inside addRbtAlbum()  msisdn  ["+msisdn+"]  albumId  ["+albumId+"]  rbtId ["+rbtId+"]  albumName  ["+albumName+"]");
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String query = null;
		boolean autoCommit = false;
		try 
		{
			//con = conPool.getConnection();
			if(con == null) {
				logger.info("Connection is NULL");
				return -99;
			}
			int ret = findRbt(con, msisdn, rbtId, albumName);
			logger.info("rbt found or not --> "+ret);
	
			if(ret == 1)
				return 0; // rbt present in some album
			else 
				return 1; //  exception in findRbt() method
/*
			autoCommit = con.getAutoCommit();
			con.setAutoCommit(false);

			long walletId = 0;

			if(albumName.toString().equalsIgnoreCase("null"))
			{
				//query = "insert into CRBT_WALLET_CONTENT(WALLET_ID, RBT_CODE, CREATE_DATE) values(?, ?, sysdate)";
				query = "insert into CRBT_WALLET_CONTENT(WALLET_ID, RBT_CODE, CREATE_DATE, MSISDN) values(?, ?, sysdate,?)";
				pstmt = con.prepareStatement(query);
				pstmt.setLong(1, albumId);
				pstmt.setInt(2, rbtId);
				pstmt.setString(3, msisdn); //to add MSISDN in table
				pstmt.executeUpdate();
				walletId = albumId;
			}
			else
			{
				query = "select wallet_id_seq.nextval from dual";
				pstmt = con.prepareStatement(query);
				rs = pstmt.executeQuery();
				if (rs.next())
				{
					walletId = rs.getLong("NEXTVAL");
				}

				query = "select max(IVR_NAME) TOTAL from CRBT_WALLET_MASTER where MSISDN = ?";
				pstmt = con.prepareStatement(query);
				pstmt.setString(1,msisdn);
				rs = pstmt.executeQuery();
				rs.next();// will always have the record
				int count = rs.getInt("total");
				query = "insert into CRBT_WALLET_MASTER (MSISDN, WALLET_ID, CREATE_DATE, WALLET_NAME, IVR_NAME) values(?, ?, sysdate, ?, ?)";
				pstmt = con.prepareStatement(query);
				pstmt.setString(1, msisdn);
				pstmt.setLong(2, walletId);
				pstmt.setString(3, albumName.toString().toUpperCase());
				pstmt.setInt(4, count+1);
				pstmt.executeUpdate();

				// ALBUM SUCCESSFULLY ADDED
				query = "insert into CRBT_WALLET_CONTENT (WALLET_ID, RBT_CODE, CREATE_DATE, MSISDN) values(?, ?, sysdate,?)";
				pstmt = con.prepareStatement(query);
				pstmt.setLong(1, walletId);
				pstmt.setInt(2, rbtId);
				pstmt.setString(3, msisdn); //to add MSISDN in table
				pstmt.executeUpdate();
			}


			if (updateRbtScore(rbtId) != 1)
			{	
				con.rollback();
				return 0;
			}

			int chr = doCharging(msisdn, rbtId);
			if (chr != 1)
			{
				con.rollback();
				return ret;
			}

			con.commit();
			con.setAutoCommit(autoCommit);

			insertIntoAlbumLog(msisdn, rbtId, walletId, 4, "Y");
			insertIntoSubscriberAudit(msisdn, 0, "Rbt added to Album");

			if(rs != null) rs.close();
			if(pstmt != null) pstmt.close();*/
		}
		catch(Exception sqle)
		{

			try {
				con.rollback();
				con.setAutoCommit(autoCommit);
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
			} catch(Exception exp) {}                
			sqle.printStackTrace();
			logger.error("Exception in addRbtAlbum",sqle);
			return -99;
		}
	/*	finally 
		{
			if(con != null) conPool.free(con);
		}*/
	}
	public int removeRbtAlbum(String msisdn, String action, long oldaid, long newaid, int[] rbtIds,Connection con) 
	{
		logger.info("Inside removeRbtAlbum()  msisdn  ["+msisdn+"]  action  ["+action+"] oldaid ["+oldaid+"]  newaid  ["+newaid+"]  rbtIds ["+rbtIds+"]");
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String query = null;
		boolean autoCommit = false;
		try 
		{
			//con = conPool.getConnection();
			if(con == null) {
				logger.info("Connection is NULL");
				return -99;
			}

			if(action.equalsIgnoreCase("move"))
			{
				query = "update CRBT_WALLET_CONTENT set WALLET_ID=? where WALLET_ID=? and RBT_CODE=?";
				logger.info("query is "+query);
				pstmt = con.prepareStatement(query);
				pstmt.setLong(1, newaid);
				pstmt.setLong(2, oldaid);
				for(int i=0; i<rbtIds.length; i++)
				{
					pstmt.setInt(3, rbtIds[i]);
					pstmt.executeUpdate();
					insertIntoAlbumLog (msisdn, rbtIds[i], newaid, 6, "N",con);
					insertIntoSubscriberAudit(msisdn, 1, "Rbt Moved",con);
				}

			}
			else
			{
				query = "delete from CRBT_WALLET_CONTENT where WALLET_ID=? and RBT_CODE=?";
				logger.info("query is "+query);
				pstmt = con.prepareStatement(query);
				pstmt.setLong(1, oldaid);
				for(int i=0; i<rbtIds.length; i++)
				{
					pstmt.setInt(2, rbtIds[i]);
					pstmt.executeUpdate();
					insertIntoAlbumLog (msisdn, rbtIds[i], oldaid, 5, "N",con);
					insertIntoSubscriberAudit(msisdn, 1, "Rbt deleted",con);
				}
			}
			if(rs != null) rs.close();
			if(pstmt != null) pstmt.close();
		}
		catch(SQLException sqle)
		{
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
			} catch(Exception exp) {}                
			sqle.printStackTrace();
			logger.error("Exception in removeRbtAlbum",sqle);
			if (sqle.getErrorCode() == 1)
			{
				return 2;
			}
			else
			{
				return -99;
			}
		}
		/*finally 
		{
			if(con != null) conPool.free(con);
		}*/
		return 1;
	}

	public int findRbtInAlbums(String msisdn, long rbtId, StringBuffer strbuff,Connection con) 
	{
		logger.info("findRbtInAlbum msisdn="+msisdn+" rbtId="+rbtId);
		try 
		{
			//con = conPool.getConnection();
			if(con == null) {
				logger.info("Connection is NULL");
				return -99;
			}
			return findRbt(con, msisdn, rbtId, strbuff);//-99 error,0 rbt not found, 1 rbt found in album(see strbuff)
		}catch (Exception e) {
			// TODO: handle exception
			logger.error("Exception in findRbtInAlbums()....",e);
			return -99;
		}
	/*	finally 
		{
			if(con != null) conPool.free(con);
		}*/
	}

	private int findRbt(Connection con, String msisdn, long rbtId, StringBuffer strbuff) 
	{
		logger.info("inside findrbt() msisdn="+msisdn+" rbtId="+rbtId);
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String query = null;
		try 
		{
			//query = "select WALLET_NAME from CRBT_WALLET_MASTER CWM, CRBT_WALLET_CONTENT CWC where MSISDN=? and CWM.WALLET_ID=CWC.WALLET_ID and CWC.RBT_CODE=?";
			query = "select WALLET_NAME from CRBT_WALLET_MASTER CWM, CRBT_WALLET_CONTENT CWC where CWM.MSISDN=? and CWM.WALLET_ID=CWC.WALLET_ID and CWC.RBT_CODE=?";
			logger.info("query = "+query);
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, msisdn);
			pstmt.setLong(2, rbtId);
			rs = pstmt.executeQuery();
			if(rs.next()) //if record already existing
			{
				strbuff.setLength(0);
				logger.info("Album name in database : "+rs.getString("wallet_name"));
				strbuff.append(rs.getString("wallet_name"));
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				return 1; // rbt present in album
			}
			else
			{
				logger.info("data not found from the query");
			}
		}
		catch(Exception e)
		{
			try
			{
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
			}catch(Exception exp){}
			return -99; // return exception eode
		}
		return 0; // not present in any album
	}

	public int getAllRbts(String msisdn, java.util.ArrayList rbtsArr) 
	{
		logger.info("inside getAllRbts() msisdn"+msisdn);
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String query = null;
		
		try 
		{
			con = conPool.getConnection();
			if(con == null) {
				logger.info("Connection is NULL");
				return -99;
			}
			query = "SELECT rbt_code FROM crbt_wallet_content WHERE wallet_id IN(SELECT wallet_id FROM crbt_wallet_master WHERE msisdn=?)";
			logger.info("query = "+query);
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, msisdn);
			rs = pstmt.executeQuery();
			while(rs.next()) //if record already existing
			{
				rbtsArr.add(new Long(rs.getLong("rbt_code")));
			}
			if(rs != null) rs.close();
			if(pstmt != null) pstmt.close();
			return rbtsArr.size();
		}
		catch(Exception e)
		{
			try
			{
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
			}catch(Exception exp){}
			return -99; // return exception eode
		}
		finally 
		{
			if(con != null) conPool.free(con);
		}
	}

	private int insertIntoAlbumLog(String msisdn, int rbtCode, long album, int op, String charge,Connection con)
	{
		logger.info("inside insertIntoAlnumLog()");
		PreparedStatement pstmt = null;
		try
		{
			String sub_type = subProfile;

			String query = "insert into CRBT_ALBUM_OP_LOG (MSISDN, SUBSCRIBER_TYPE, EVENT_TIME, INTERFACE_TYPE, RBT_CODE, ALBUM_ID, OP_CODE, EVENT_CHARGED, UPDATED_BY, CALL_ID) values (?,?,sysdate,'C',?,?,?,?,?,0)";
			logger.info("query = "+query);
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, msisdn.trim());
			pstmt.setString(2, sub_type.trim());
			pstmt.setInt(3, rbtCode);
			pstmt.setLong(4, album);
			pstmt.setInt(5, op);
			pstmt.setString(6, charge.trim());
			pstmt.setString(7, this.user);

			pstmt.executeUpdate();
			pstmt.close();
			return 1; //Success inserted in CCAudit 
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
	}

	private int insertIntoSubscriberAudit(String interMsisdn, int actType, String strActDetail,Connection con)
	{
		logger.info("inside insertIntoSubscriberAudit()  ");
		PreparedStatement pstmt = null;
		try
		{
			String sub_type = subProfile;
			/*		String subscriber_type = "P";
					String query ="Select msisdn from postpaid_subscribers where msisdn='"+interMsisdn+"'";
					ResultSet rs = stmt.executeQuery(query);
					if(rs.next())
					{
					subscriber_type="O";
					rs.close();                  
					}*/

			String query = "insert into CRBT_WEB_DETAIL_LOG (MSISDN, START_TIME, REQUEST_TYPE, REQUEST_DATA, SUBSCRIBER_TYPE, REQUEST_FROM, UPDATED_BY) values(?,sysdate,?,?,?,?,?)";
			logger.info("query = "+query);
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, interMsisdn.trim());
			pstmt.setInt(2, actType);
			pstmt.setString(3, strActDetail.trim());
			pstmt.setString(4, sub_type.trim());
			pstmt.setString(5, "C");
			pstmt.setString(6, this.user);
			pstmt.executeUpdate();
			pstmt.close();
			return 1; //Success inserted in CCAudit 
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
	}

	private int prepaidCharging(String interMsisdn, int chargeCode)
	{
		logger.info("inside prepaidCharging");
		int ret = TSSJavaUtil.instance().isChargingEnabled();
		if (ret == 1) 
		{
			StringBuffer stat = new StringBuffer();
			SSFClient ssfClient = new SSFClient();

			int announcementID = SSFClient.doEventBasedCharging(chargeCode, interMsisdn, stat);
			if (announcementID < 0)
			{
				logger.info("SSF Error");
				return 0;
			}
		//	logger.info("AnnouncementID : " + announcementID);
		//	logger.info("Status ID : " + stat);

			if(stat.toString().equalsIgnoreCase("true"))
			{
				if(announcementID == 502)//recharge reminder
				{
					return 502;
				}
				else if(announcementID == 510)
				{
					return 510;
				}
				return 1;
			}
			else if (stat.toString().equalsIgnoreCase("false"))
			{
				switch(announcementID)
				{
					case 501:
					case 503:
					case 507:
						return -2;
					default:
						return -2;
				}
			}
			else
			{
				logger.info("Unexpexted results from SSF ");
				return 0;
			}
		}
		else 
		{
			logger.info("Charging Disabled");
			return 1;
		} 
	}  

	private int prepaidCharging(String interMsisdn, int rbtCode, int planId)
	{
	   logger.info("prepaidCharging() -- Logs Entry --"+interMsisdn);
		if (con == null)
		{
			logger.info("CON NULL");
			return 0;	
		}

		try
		{
			String query = "insert into CRBT_PREPAID_SETTING_CDR (PRE_SECDR_ID, MSISDN, INTERFACE_USED, UPDATE_TIME, STATUS, PLAN_INDICATOR, RBT_CODE) values (PRE_SECDR_ID.nextval, ?, ?, sysdate, ?, ?, ?)"; 
			logger.info("query = "+query);
			PreparedStatement pstmt = con.prepareStatement(query);

			pstmt.setString(1, interMsisdn.trim());
			pstmt.setString(2, "C");
			pstmt.setString(3, "N");
			pstmt.setInt(4, planId);
			pstmt.setInt(5, rbtCode);
			pstmt.executeUpdate();
			pstmt.close();	
			return 1; //Success inserted in CDR 
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
	}

	private int postpaidCharging(String interMsisdn, int rbtCode, int planId)
	{
		logger.info("inside postpain charging");
		if (con == null)
		{
			logger.info("CON NULL");
			return 0;	
		}

		try
		{
			String query = "insert into CRBT_SETTING_CDR (SECDR_ID, MSISDN, INTERFACE_USED, UPDATE_TIME, STATUS, PLAN_INDICATOR, RBT_CODE) values (SECDR_ID.nextval, ?, ?, sysdate, ?, ?, ?)"; 
			logger.info("query = "+query);
			PreparedStatement pstmt = con.prepareStatement(query);

			pstmt.setString(1, interMsisdn.trim());
			pstmt.setString(2, "C");
			pstmt.setString(3, "N");
			pstmt.setInt(4, planId);
			pstmt.setInt(5, rbtCode);
			pstmt.executeUpdate();
			pstmt.close();	
			return 1; //Success inserted in CDR 
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
	}

	public int updateFreeEventsUsed(String interMsisdn)
	{
		logger.info("inside updateFreeEventsUsed()");
		if (con == null)
		{
			logger.info("CON NULL");
			return 0;
		}

		try
		{
			PreparedStatement pstmt = null;

			String query="update CRBT_SUBSCRIBER_MASTER set FREE_EVENTS_USED = FREE_EVENTS_USED+1 where MSISDN = ?";
			logger.info("query = "+query);
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, interMsisdn.trim());
			pstmt.executeUpdate();
			pstmt.close();
			return 1;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
	}

	public int updateRbtScore(int rbtCode)
	{
		logger.info("inside updateRbtScore()");
		if (con == null)
		{
			logger.info("CON NULL");
			return 0;
		}
		try
		{	
			PreparedStatement pstmt = null;

			String query= "update CRBT_RBT set RBT_SCORE = RBT_SCORE+1 where RBT_CODE = ?";
			logger.info("query = "+query);
			pstmt = con.prepareStatement(query);
			pstmt.setInt(1, rbtCode);
			pstmt.executeUpdate();
			pstmt.close();
			return 1;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
	}	

	// ****************************** Charging *********************************************
	private int doCharging(String interMsisdn, int rbtCode)
	{
	   logger.info(" doCharging(), for "+interMsisdn+"and RbtCode= "+ rbtCode);
		if (con == null)
		{
			logger.info("CON NULL");
			return 0;
		}

		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String query = null;

		int freeEvents=0;
		int freeEventsUsed=0;	
		int rbt_charge_code=0;	
		int planIndicator=0;

		try
		{
			query = "select PLAN_INDICATOR, FREE_EVENTS_USED from CRBT_SUBSCRIBER_MASTER where MSISDN = ?";
			logger.info("query = "+query);
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, interMsisdn);
	   //logger.info(query);

			rs = pstmt.executeQuery();

			if(rs.next())
			{	
				planIndicator=rs.getInt("PLAN_INDICATOR");
				freeEventsUsed=rs.getInt("FREE_EVENTS_USED");
				logger.info("planIndicator = "+planIndicator);
				logger.info("freeEventsUsed = "+freeEventsUsed);
			}
			else
			{	
				logger.info("no data found from query");
			}

			query = "select FREE_RINGTONES, RBT_CHARGE_CODE from CRBT_RATE_PLANS where PLAN_INDICATOR = ?";	
			logger.info("query = "+query);
			pstmt = con.prepareStatement(query);
			pstmt.setInt(1, planIndicator);
	   //logger.info(query);

			rs = pstmt.executeQuery();

			if(rs.next())
			{
				freeEvents=rs.getInt("FREE_RINGTONES");
				rbt_charge_code=Integer.parseInt(rs.getString("RBT_CHARGE_CODE"));
	   			logger.info("RBT_CHARGE_CODE= "+rbt_charge_code);
			}
			else
			{
				logger.info("no data found from the query");
			}

			if(rs != null) rs.close();
			pstmt.close();

		//	if(freeEventsUsed > freeEvents)			
		//	{
				if (subProfile.equalsIgnoreCase("P"))
				{
					int retVal = prepaidCharging(interMsisdn, rbt_charge_code);
//					int retVal = prepaidCharging(interMsisdn, rbtCode, planIndicator);
					if (retVal == 1 || retVal == 502 || retVal == 510)
					{
					  int retVal1 = prepaidCharging(interMsisdn, rbtCode, planIndicator);
						logger.info("Done Prepaid Charging");
						return 1;
					}
					else 
					{
						logger.info("Error In Prepaid Charging");
						return retVal;
					}
				}
				else
				{
					if (postpaidCharging(interMsisdn, rbtCode, planIndicator) != 1)
					{
						logger.info("Error In Postpaid Cahrging");
						return 0;
					}
					return 1;
				}
		//	}
		}
		catch(Exception exp)
		{
			exp.printStackTrace();
			return 0;
		}	
//		return 1;
	}
 public int getSubscriberDefaultSettingRbt(String msisdn,Connection con)
{
    logger.info("getSubscriberDefaultSettingRbt() "+msisdn);
     PreparedStatement pstmt = null;
  ResultSet rs = null;
  String query = null;
  int rbtcode=0;

  try
  {
   //con = conPool.getConnection();
   if(con == null) {
    logger.info("Connection is NULL");
    return -99;
   }
   query = "SELECT rbt_code FROM crbt_default_detail where msisdn=? and DAY=8 and START_AT=2500 and ENDS_AT=2500";
		logger.info("query = "+query);
   pstmt = con.prepareStatement(query);
   pstmt.setString(1, msisdn);
   rs = pstmt.executeQuery();
   if(rs.next())
 {
    rbtcode= rs.getInt("rbt_code");
	logger.info("rbtcode = "+rbtcode);
   }
	else
	{
		logger.info("no data found from the query");
	}

   if(rs != null) rs.close();
   if(pstmt != null) pstmt.close();
  }
  catch(Exception e)
  {
   try
   {
    if(rs != null) rs.close();
    if(pstmt != null) pstmt.close();
   }catch(Exception exp){}
   return -99; // return exception eode
  }
  /*finally
  {
   if(con != null) conPool.free(con);
  }*/
 return rbtcode;
}//getSubscriberDefaultSettingRbt


private int insertIntoSettingCdr(String interMsisdn, int planId, int rbtCode, int charge)
{
		logger.info("inside insertIntoSettingCdr");
				if (con == null)
				{
								logger.info("CON NULL");
								return 0;
				}

				try
				{
								String query = "";
								if (charge == 1)
								{
												query = "insert into CRBT_PREPAID_SETTING_CDR (PRE_SECDR_ID, MSISDN, INTERFACE_USED, UPDATE_TIME, STATUS, PLAN_INDICATOR, RBT_CODE) values (PRE_SECDR_ID.nextval, ?, ?, sysdate, ?, ?, ?)";
								}
								else
								{
												query = "insert into CRBT_PREPAID_GIFTING_CDR (PRE_GICDR_ID, MSISDN, INTERFACE_USED, UPDATE_TIME, STATUS, PLAN_INDICATOR, RBT_CODE) values (PRE_GICDR_ID.nextval, ?, ?, sysdate, ?, ?, ?)";
								}
								PreparedStatement pstmt = con.prepareStatement(query);
								logger.info("query = "+query);
								pstmt.setString(1, interMsisdn.trim());
								pstmt.setString(2, "C");
								pstmt.setString(3, "N");
								pstmt.setInt(4, planId);
								pstmt.setInt(5, rbtCode);
								pstmt.executeUpdate();
								pstmt.close();
								logger.info(query);
								return 1; //Success inserted in CDR
				}
				catch (Exception e)
				{
								e.printStackTrace();
								return 0;
				}
}//insertIntoSettingCdr



private int insertIntoSettingCdr(String interMsisdn, int rbtCode, int planId)
{
				logger.info("inside insertIntoSettingCdr() ---- prepaidCharging() -- Logs Entry --"+interMsisdn);
				if (con == null)
				{
								logger.info("CON NULL");
								return 0;
				}

				try
				{
								String query = "insert into CRBT_PREPAID_SETTING_CDR (PRE_SECDR_ID, MSISDN, INTERFACE_USED, UPDATE_TIME, STATUS, PLAN_INDICATOR, RBT_CODE) values (PRE_SECDR_ID.nextval, ?, ?, sysdate, ?, ?, ?)";
								logger.info("query = "+query);
								PreparedStatement pstmt = con.prepareStatement(query);

								pstmt.setString(1, interMsisdn.trim());
								pstmt.setString(2, "C");
								pstmt.setString(3, "N");
								pstmt.setInt(4, planId);
								pstmt.setInt(5, rbtCode);
								pstmt.executeUpdate();
								pstmt.close();
								return 1; //Success inserted in CDR
				}
				catch (Exception e)
				{
								e.printStackTrace();
								return 0;
				}
}


}
