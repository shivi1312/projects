/*
 * This class is used for user authentication for the web interface for CRBT. 
 *
 *
 *
 */


package com.telemune.vcc.custcare;

import java.util.ArrayList;

import com.telemune.vcc.common.TSSJavaUtil;

public class Blacklist 
{
	private String userMsisdn=null;
	private String blacklistNum=null;
	private String blacklistDate=null;
	private ArrayList blacklist = null;//msisdns in this group

	/*public void setMsisdn(String msisdn )
	{
		this.msisdn = msisdn;
	}
	public String getMsisdn()
	{
		return TSSJavaUtil.instance().getInternationalNumber(msisdn);
	}*/
	
	
	
	
	
	public ArrayList getBlacklist()
  {
	    return blacklist;
	}
	public String getUserMsisdn()  {
		return TSSJavaUtil.instance().getInternationalNumber(userMsisdn);
	}
	public void setUserMsisdn(String userMsisdn) {
		this.userMsisdn = userMsisdn;
	}
	public void setBlacklist(String []blacklist)
	{
		this.blacklist = new ArrayList();
		
		for(int i=0; i < blacklist.length; i++)
		{
			this.blacklist.add(blacklist[i]);	
		}
	}
	public void setBlacklist(ArrayList blacklist)
	{
		this.blacklist = blacklist;
	}

	public void setBlacklistNum(String blist)
{	
		this.blacklistNum = blist;
	}
	public String getBlacklistNum()
{
		return this.blacklistNum;
	}
	public void setBlacklistDate(String blistDate)
	{
		this.blacklistDate = blistDate;
	}
	public String getBlacklistDate()
	{
		return this.blacklistDate;
	}

}

