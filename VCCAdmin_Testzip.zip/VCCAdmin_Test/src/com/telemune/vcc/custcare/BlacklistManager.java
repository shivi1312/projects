
package com.telemune.vcc.custcare;
import com.telemune.dbutilities.*;
import com.telemune.vcc.common.*;

import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.*;

import org.apache.log4j.*;

public class BlacklistManager 
{
        private static Logger logger=Logger.getLogger(BlacklistManager.class);
	private ConnectionPool conPool;
	private Connection con;
	private String subscriberProfile =  "";

	//private SessionHistory sessionHistory =  null;
	private			PreparedStatement pstmt = null;
	private			PreparedStatement pstmt1 = null;
	private			ResultSet rset = null;
	private			String query=null;
	private			String user="";

	public BlacklistManager() 
	{
		conPool = new ConnectionPool();
	}

	public void setUser(String usr)
	{
		this.user=usr;
	}
	public void setConnectionPool(ConnectionPool conPool) 
	{
		this.conPool = conPool;
	}
	public void setSubscriberProfile(String sp)
	{
		this.subscriberProfile = sp;	
		logger.info("subscriberProfile="+subscriberProfile+"   "+sp);
	}

/*	public void setSessionHistory(SessionHistory sh)
	{
		this.sessionHistory = sh;	
	}*/

	public int addBlacklist(Blacklist bl,Connection con)
	{
		logger.info("inside addBlacklist() request from msisdn="+bl.getUserMsisdn());
		ArrayList blAr=new ArrayList();
		try 
		{
			blAr=bl.getBlacklist();
			//con = conPool.getConnection();

			if(con == null) 
			{
				logger.info("connection is null");
				return 0;
			}
			query="SELECT BLACK_LISTED from CRBT_SUBSCRIBER_MASTER where MSISDN=?";
			pstmt = con.prepareStatement (query);
			pstmt.setString(1,bl.getUserMsisdn());
			rset=pstmt.executeQuery();
			rset.next();

			if(rset.getInt("BLACK_LISTED")==0)
			{
				String query1="update CRBT_SUBSCRIBER_MASTER set BLACK_LISTED=1 where MSISDN=?";

				logger.info(query1);
				pstmt1= con.prepareStatement (query1);
				pstmt1.setString(1,bl.getUserMsisdn().trim());
				pstmt1.executeUpdate();
				pstmt1.close();
			}
			rset.close();
			pstmt.close();
			for(int i=0;i<blAr.size();i++)	
			{
				query="select BLACKLIST_NUMBER from CRBT_SUBSCRIBER_BLACKLIST where MSISDN=? and BLACKLIST_NUMBER=?";

				logger.info(query);
				pstmt = con.prepareStatement (query);
				pstmt.setString(1,bl.getUserMsisdn().trim());
				pstmt.setString(2,TSSJavaUtil.instance().getInternationalNumber((String)blAr.get(i)).trim());
				rset=pstmt.executeQuery();
				if(rset.next())
				{
					logger.info("msisdn= "+TSSJavaUtil.instance().getInternationalNumber((String)blAr.get(i))+" is already blacklisted so returning and no other msisdn is processed for this request");
					rset.close();
					pstmt.close();
					return -3;
				}
				rset.close();
				pstmt.close();

			}
			for(int i=0;i<blAr.size();i++)
			{
				query="insert into CRBT_SUBSCRIBER_BLACKLIST (MSISDN,BLACKLIST_NUMBER,CREATE_DATE) values(?,?,sysdate)";
				logger.info(query);
				pstmt = con.prepareStatement (query);
				pstmt.setString(1,bl.getUserMsisdn().trim());
				pstmt.setString(2,TSSJavaUtil.instance().getInternationalNumber((String)blAr.get(i)).trim());
				pstmt.executeUpdate();
				logger.info("msisdn "+TSSJavaUtil.instance().getInternationalNumber((String)blAr.get(i))+" is blacklisted");
			}
			pstmt.close();
			insertIntoSubscriberAudit(bl.getUserMsisdn(), 1, "Blacklist Added",con);
		}
		catch (SQLException e) {
			logger.error("In searchTones not found :"+e.getMessage());
			try {
				if(pstmt != null) pstmt.close();
				if(pstmt1 != null) pstmt1.close();
				if(rset != null) rset.close();
			} catch(Exception exp) {}
			e.printStackTrace();
			return 0;
		}
		catch (Exception e) {
			try {
				if(pstmt != null) pstmt.close();
				if(pstmt1 != null) pstmt1.close();
				if(rset != null) rset.close();
			} catch(Exception exp) {}                
			e.printStackTrace();
			return 0;
		}
		/*finally {
			conPool.free(con);
		}*/
		return 1;

	}//addBlacklist
	public int deleteBlackList(String msisdn,String[] blistmsisdns ,Connection con)
	{
		logger.info("inside deleteBlackList() request from msisdn="+msisdn);
		try 
		{
			//con = conPool.getConnection();
			String query=null;

			if(con == null) 
			{
				return 0;
			}
			for(int i=0; i<blistmsisdns.length;i++)
			{
				query="DELETE FROM CRBT_SUBSCRIBER_BLACKLIST WHERE MSISDN=? AND BLACKLIST_NUMBER=?";
				logger.info(query);
				pstmt = con.prepareStatement (query);
				pstmt.setString(1,msisdn);
				pstmt.setString(2,blistmsisdns[i]);
				pstmt.executeUpdate();
				logger.info("msisdn "+blistmsisdns[i]+" is deleted from blacklist");
			}
			query="SELECT BLACKLIST_NUMBER FROM CRBT_SUBSCRIBER_BLACKLIST WHERE MSISDN=?";
			logger.info(query);
			pstmt = con.prepareStatement (query);
			pstmt.setString(1,msisdn);
			rset=pstmt.executeQuery();
			if(!rset.next())
			{
				String query1="update CRBT_SUBSCRIBER_MASTER SET BLACK_LISTED=0 where MSISDN=?";
				logger.info(query1);
				pstmt1 = con.prepareStatement (query1);
				pstmt1.setString(1,msisdn.trim());
				pstmt1.executeUpdate();
				pstmt1.close();
				logger.info("BLACK_LISTED flag is down in crbt_subscriber_master");
			}
			else
			{
				logger.info("BLACK_LISTED flag is still up in crbt_subscriber_master as some more numbers are blacklisted by this msisdn");
			}
			rset.close();
			pstmt.close();
			insertIntoSubscriberAudit(msisdn, 1, "Blacklist Deleted",con);

		}
		catch (SQLException e) {
			logger.error("In deleteBlackList :"+e.getMessage());
			try {
				if(pstmt != null) pstmt.close();
				if(pstmt1 != null) pstmt1.close();
				if(rset != null) rset.close();

			} catch(Exception exp) {}
			e.printStackTrace();
			return 0;
		}
		catch (Exception e) {
			try {
				if(pstmt != null) pstmt.close();
				if(pstmt1 != null) pstmt1.close();
				if(rset != null) rset.close();
			} catch(Exception exp) {}                
			e.printStackTrace();
			return 0;
		}
		/*finally {
			conPool.free(con);
		}*/
		return 1;

	}//deleteBlacklist
	public int modifyBlackList(String msisdn,String blmsisdn,String blistnumber,Connection con)
	{
		logger.info("Inside function modifyBlackList().... request from msisdn= "+msisdn);
		try 
		{
			//con = conPool.getConnection();
			String query=null;

			if(con == null) 
			{
				return 0;
			}
			
			//****** Changes done by pankaj to check existance of modified blacklist number*************//
			query="select BLACKLIST_NUMBER from CRBT_SUBSCRIBER_BLACKLIST where MSISDN=? and BLACKLIST_NUMBER=?";

			logger.info(query);
			pstmt = con.prepareStatement (query);
			pstmt.setString(1,msisdn);
			pstmt.setString(2,TSSJavaUtil.instance().getInternationalNumber(blistnumber));
			rset=pstmt.executeQuery();
			if(rset.next())
			{
				logger.info("msisdn is already blacklisted so returning");
				rset.close();
				pstmt.close();
				return -3;
			}
			rset.close();
			pstmt.close();
			//****** Changes done by pankaj to check existance of modified blacklist number*************//
			
			query="UPDATE CRBT_SUBSCRIBER_BLACKLIST SET BLACKLIST_NUMBER=? WHERE MSISDN=? AND BLACKLIST_NUMBER=?";
			logger.info(query);
			pstmt = con.prepareStatement (query);
			pstmt.setString(1,TSSJavaUtil.instance().getInternationalNumber(blistnumber).trim());
			pstmt.setString(2,msisdn.trim());
			pstmt.setString(3,blmsisdn.trim());
			pstmt.executeUpdate();
			insertIntoSubscriberAudit(msisdn, 1, "Blacklist Modified",con);
		}
		catch (SQLException e) {
			try {
				if(pstmt != null) pstmt.close();
			} catch(Exception exp) {}
			e.printStackTrace();
			return 0;
		}
		catch (Exception e) {
			try {
				if(pstmt != null) pstmt.close();
			} catch(Exception exp) {}                
			e.printStackTrace();
			return 0;
		}/*
		finally {
			conPool.free(con);
		}*/
		return 1;

	}//modifyBlacklist
	public int getBlackList(Blacklist bl,ArrayList blNumAr,Connection con)  
	{
		logger.info("Inside function getBlackList().. ");
		String msisdn_1 = bl.getUserMsisdn();
		try 
		{
			//con = conPool.getConnection();
			String query=null;

			if(con == null) 
			{
				return 0;
			}
			query="SELECT BLACK_LISTED from CRBT_SUBSCRIBER_MASTER where MSISDN=?";
			logger.info(query);
			pstmt = con.prepareStatement (query);
			pstmt.setString(1,msisdn_1);
			rset=pstmt.executeQuery();
			rset.next();
			if(rset.getInt("BLACK_LISTED")==0)
			{
				rset.close();
				pstmt.close();
				return -1;
			}
			rset.close();
			pstmt.close();

			query="SELECT BLACKLIST_NUMBER,CREATE_DATE FROM CRBT_SUBSCRIBER_BLACKLIST WHERE MSISDN=?";
			pstmt = con.prepareStatement (query);
			logger.info(query);
			pstmt.setString(1,msisdn_1);
			rset=pstmt.executeQuery();
			/*if(!rset.next())
			  {
			  pstmt1 = null;
			  String query1="update CRBT_SUBSCRIBER_MASTER SET BLACKLIST=0 where MSISDN=?";
			  logger.info(query1);
			  pstmt1 = con.prepareStatement (query);
			  pstmt1.setString(1,bl.getMsisdn());
			  pstmt1.executeUpdate();
			  pstmt1.close();
			  rset.close();
			  pstmt.close();
			  return -3;
			  }*/
			while(rset.next())
			{
				Blacklist blobj=new Blacklist();
				blobj.setBlacklistNum(rset.getString("BLACKLIST_NUMBER"));
				blobj.setBlacklistDate(rset.getString("CREATE_DATE"));
				blNumAr.add(blobj);
			}


		}
		catch (SQLException e) {
			try {
				if(pstmt != null) pstmt.close();
				if(rset != null) rset.close();
			} catch(Exception exp) {}
			e.printStackTrace();
			return 0;
		}
		catch (Exception e) {
			try {
				if(pstmt != null) pstmt.close();
				if(rset != null) rset.close();
			} catch(Exception exp) {}                
			e.printStackTrace();
			return 0;
		}
		/*
		finally {
			conPool.free(con);
		}*/
		return 1;

	}//getBlacklist


	private int insertIntoSubscriberAudit(String interMsisdn, int actType, String strActDetail,Connection con)
	{
		logger.info("insertIntoSubscriberAudit()- "+interMsisdn+"  "+strActDetail);

		//			PreparedStatement pstmt = null;
		try
		{
			String sub_type = subscriberProfile;
			logger.info("insertIntoSubscriberAudit()- "+interMsisdn+"  "+strActDetail+" "+sub_type);
			/*		String subscriber_type = "P";
					String query ="Select msisdn from postpaid_subscribers where msisdn='"+interMsisdn+"'";
					ResultSet rs = stmt.executeQuery(query);
					if(rs.next())
					{
					subscriber_type="O";
					rs.close();                  
					}*/

			String query = "insert into CRBT_WEB_DETAIL_LOG (MSISDN, START_TIME, REQUEST_TYPE, REQUEST_DATA, SUBSCRIBER_TYPE, REQUEST_FROM, UPDATED_BY) values(?,sysdate,?,?,?,?,?)";

			pstmt = con.prepareStatement(query);
			pstmt.setString(1, interMsisdn.trim());
			pstmt.setInt(2, actType);
			pstmt.setString(3, strActDetail.trim());
			pstmt.setString(4, sub_type.trim());
			pstmt.setString(5, "C");
			pstmt.setString(6, this.user);
			pstmt.executeUpdate();
			pstmt.close();
			return 1; //Success inserted in CCAudit 
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
	}//insertIntoSubscriberAudit

}

