package com.telemune.vcc.custcare;
import com.telemune.vcc.common.*;

import java.io.*;
import java.net.*;

import org.apache.log4j.*;
public class CRBTRequest
{
       private static Logger logger=Logger.getLogger(CRBTRequest.class);
	private int resp;
	private Socket socket = null;
	private	DataOutputStream writer = null;
	private DataInputStream reader = null;
	private ByteArrayInputStream inbuf = null;
	//private	ByteArrayOutputStream buf = new ByteArrayOutputStream();
	private	ByteArrayOutputStream buf = null;
	public int err_code = 0;
	public String err_string = "";
	public CREMessage cre;
	public CRBTRequest()
	{
		cre = new CREMessage();
		resp=0;
		buf = new ByteArrayOutputStream();
	}

	public int constructQuery(int actID,SetVariable sv)
	{
		logger.info("selected ACTID is "+actID);
		switch(actID)
		{
			case 1:
				{	
					cre.reqID = 1;
					cre.actID = actID;
					cre.priority = 0x01;
					cre.m_no = 6;

					cre.m_Data[0].type = datatype.D_STRING;
					cre.m_Data[0].svalue = sv.getMsisdn();
					cre.m_Data[0].len = cre.m_Data[0].svalue.length();

					cre.m_Data[1].type = datatype.D_STRING;
					cre.m_Data[1].svalue = sv.getInterface();
					cre.m_Data[1].len = cre.m_Data[1].svalue.length();

					cre.m_Data[2].type = datatype.D_INT;
					cre.m_Data[2].ivalue = sv.getPlan();
					cre.m_Data[2].len = 4;

					cre.m_Data[3].type = datatype.D_INT;
					cre.m_Data[3].ivalue = sv.getLang();
					cre.m_Data[3].len = 4;

					cre.m_Data[4].type = datatype.D_STRING;
					cre.m_Data[4].svalue = sv.getUpdatedBy();
					cre.m_Data[4].len = cre.m_Data[4].svalue.length();

					cre.m_Data[5].type = datatype.D_STRING;
					cre.m_Data[5].svalue = sv.getSubType();
					cre.m_Data[5].len = cre.m_Data[5].svalue.length();
				}
				break;
			case 2:
				{	
					cre.reqID = 1;
					cre.actID = actID;
					cre.priority = 0x01;
					cre.m_no = 6;

					cre.m_Data[0].type = datatype.D_STRING;
					cre.m_Data[0].svalue = sv.getMsisdn();
					cre.m_Data[0].len = cre.m_Data[0].svalue.length();

					cre.m_Data[1].type = datatype.D_STRING;
					cre.m_Data[1].svalue = sv.getInterface();
					cre.m_Data[1].len = cre.m_Data[1].svalue.length();

					cre.m_Data[2].type = datatype.D_INT;
					cre.m_Data[2].ivalue = sv.getPlan();
					cre.m_Data[2].len = 4;

					cre.m_Data[3].type = datatype.D_INT;
					cre.m_Data[3].ivalue = sv.getLang();
					cre.m_Data[3].len = 4;

					cre.m_Data[4].type = datatype.D_STRING;
					cre.m_Data[4].svalue = sv.getUpdatedBy();
					cre.m_Data[4].len = cre.m_Data[4].svalue.length();

					cre.m_Data[5].type = datatype.D_STRING;
					cre.m_Data[5].svalue = sv.getSubType();
					cre.m_Data[5].len = cre.m_Data[5].svalue.length();
				}
				break;
			case 3:
				{	
					cre.reqID = 1;
					cre.actID = actID;
					cre.priority = 0x01;
					cre.m_no = 11;

					cre.m_Data[0].type = datatype.D_STRING;
					cre.m_Data[0].svalue = sv.getMsisdn();
					cre.m_Data[0].len = cre.m_Data[0].svalue.length();

					cre.m_Data[1].type = datatype.D_STRING;
					cre.m_Data[1].svalue = sv.getInterface();
					cre.m_Data[1].len = cre.m_Data[1].svalue.length();

					cre.m_Data[2].type = datatype.D_INT;
					cre.m_Data[2].ivalue = sv.getPlan();
					cre.m_Data[2].len = 4;

					cre.m_Data[3].type = datatype.D_INT;
					cre.m_Data[3].ivalue = sv.getLang();
					cre.m_Data[3].len = 4;

					cre.m_Data[4].type = datatype.D_STRING;
					cre.m_Data[4].svalue = sv.getUpdatedBy();
					cre.m_Data[4].len = cre.m_Data[4].svalue.length();

					cre.m_Data[5].type = datatype.D_STRING;
					cre.m_Data[5].svalue = sv.getSubType();
					cre.m_Data[5].len = cre.m_Data[5].svalue.length();

					cre.m_Data[6].type = datatype.D_INT;
					cre.m_Data[6].ivalue = sv.rbt_code;
					cre.m_Data[6].len = 4;

					cre.m_Data[7].type = datatype.D_STRING;
					cre.m_Data[7].svalue = sv.days;
					cre.m_Data[7].len = cre.m_Data[7].svalue.length();

					cre.m_Data[8].type = datatype.D_INT;
					cre.m_Data[8].ivalue = sv.start_t;
					cre.m_Data[8].len = 4;

					cre.m_Data[9].type = datatype.D_INT;
					cre.m_Data[9].ivalue = sv.end_t;
					cre.m_Data[9].len = 4;

					cre.m_Data[10].type = datatype.D_INT;
					cre.m_Data[10].ivalue = sv.check_rbt;
					cre.m_Data[10].len = 4;
				}
				break;
			case 4:
				{	
					cre.reqID = 1;
					cre.actID = actID;
					cre.priority = 0x01;
					cre.m_no = 12;

					cre.m_Data[0].type = datatype.D_STRING;
					cre.m_Data[0].svalue = sv.getMsisdn();
					cre.m_Data[0].len = cre.m_Data[0].svalue.length();

					cre.m_Data[1].type = datatype.D_STRING;
					cre.m_Data[1].svalue = sv.getInterface();
					cre.m_Data[1].len = cre.m_Data[1].svalue.length();

					cre.m_Data[2].type = datatype.D_INT;
					cre.m_Data[2].ivalue = sv.getPlan();
					cre.m_Data[2].len = 4;

					cre.m_Data[3].type = datatype.D_INT;
					cre.m_Data[3].ivalue = sv.getLang();
					cre.m_Data[3].len = 4;

					cre.m_Data[4].type = datatype.D_STRING;
					cre.m_Data[4].svalue = sv.getUpdatedBy();
					cre.m_Data[4].len = cre.m_Data[4].svalue.length();

					cre.m_Data[5].type = datatype.D_STRING;
					cre.m_Data[5].svalue = sv.getSubType();
					cre.m_Data[5].len = cre.m_Data[5].svalue.length();

					cre.m_Data[6].type = datatype.D_INT;
					cre.m_Data[6].ivalue = sv.rbt_code;
					cre.m_Data[6].len = 4;

					cre.m_Data[7].type = datatype.D_STRING;
					cre.m_Data[7].svalue = sv.days;
					cre.m_Data[7].len = cre.m_Data[7].svalue.length();

					cre.m_Data[8].type = datatype.D_INT;
					cre.m_Data[8].ivalue = sv.start_t;
					cre.m_Data[8].len = 4;

					cre.m_Data[9].type = datatype.D_INT;
					cre.m_Data[9].ivalue = sv.end_t;
					cre.m_Data[9].len = 4;

					cre.m_Data[10].type = datatype.D_INT;
					cre.m_Data[10].ivalue = sv.check_rbt;
					cre.m_Data[10].len = 4;

					cre.m_Data[11].type = datatype.D_STRING;
					cre.m_Data[11].svalue = sv.fmsisdn;
					cre.m_Data[11].len = cre.m_Data[11].svalue.length();
				}
				break;
			case 5:
				{	
					cre.reqID = 1;
					cre.actID = actID;
					cre.priority = 0x01;
					cre.m_no = 12;

					cre.m_Data[0].type = datatype.D_STRING;
					cre.m_Data[0].svalue = sv.getMsisdn();
					cre.m_Data[0].len = cre.m_Data[0].svalue.length();

					cre.m_Data[1].type = datatype.D_STRING;
					cre.m_Data[1].svalue = sv.getInterface();
					cre.m_Data[1].len = cre.m_Data[1].svalue.length();

					cre.m_Data[2].type = datatype.D_INT;
					cre.m_Data[2].ivalue = sv.getPlan();
					cre.m_Data[2].len = 4;

					cre.m_Data[3].type = datatype.D_INT;
					cre.m_Data[3].ivalue = sv.getLang();
					cre.m_Data[3].len = 4;

					cre.m_Data[4].type = datatype.D_STRING;
					cre.m_Data[4].svalue = sv.getUpdatedBy();
					cre.m_Data[4].len = cre.m_Data[4].svalue.length();

					cre.m_Data[5].type = datatype.D_STRING;
					cre.m_Data[5].svalue = sv.getSubType();
					cre.m_Data[5].len = cre.m_Data[5].svalue.length();

					cre.m_Data[6].type = datatype.D_INT;
					cre.m_Data[6].ivalue = sv.rbt_code;
					cre.m_Data[6].len = 4;

					cre.m_Data[7].type = datatype.D_STRING;
					cre.m_Data[7].svalue = sv.days;
					cre.m_Data[7].len = cre.m_Data[7].svalue.length();

					cre.m_Data[8].type = datatype.D_INT;
					cre.m_Data[8].ivalue = sv.start_t;
					cre.m_Data[8].len = 4;

					cre.m_Data[9].type = datatype.D_INT;
					cre.m_Data[9].ivalue = sv.end_t;
					cre.m_Data[9].len = 4;

					cre.m_Data[10].type = datatype.D_INT;
					cre.m_Data[10].ivalue = sv.check_rbt;
					cre.m_Data[10].len = 4;

					cre.m_Data[11].type = datatype.D_STRING;
					cre.m_Data[11].svalue = sv.groupName;
					cre.m_Data[11].len = cre.m_Data[11].svalue.length();
				}
				break;
				//-------------->done by pankaj starts---->
			case 6:
			{	
				cre.reqID = 1;
				cre.actID = actID;
				cre.priority = 0x01;
				cre.m_no = 8;

				cre.m_Data[0].type = datatype.D_STRING;
				cre.m_Data[0].svalue = sv.getMsisdn();
				cre.m_Data[0].len = cre.m_Data[0].svalue.length();

				cre.m_Data[1].type = datatype.D_STRING;
				cre.m_Data[1].svalue = sv.getInterface();
				cre.m_Data[1].len = cre.m_Data[1].svalue.length();

				cre.m_Data[2].type = datatype.D_INT;
				cre.m_Data[2].ivalue = sv.getPlan();
				cre.m_Data[2].len = 4;

				cre.m_Data[3].type = datatype.D_INT;
				cre.m_Data[3].ivalue = sv.getLang();
				cre.m_Data[3].len = 4;

				cre.m_Data[4].type = datatype.D_STRING;
				cre.m_Data[4].svalue = sv.getUpdatedBy();
				cre.m_Data[4].len = cre.m_Data[4].svalue.length();

				cre.m_Data[5].type = datatype.D_STRING;
				cre.m_Data[5].svalue = sv.getSubType();
				cre.m_Data[5].len = cre.m_Data[5].svalue.length();

				cre.m_Data[6].type = datatype.D_INT;
				cre.m_Data[6].ivalue = sv.rbt_code;
				cre.m_Data[6].len = 4;

				cre.m_Data[7].type = datatype.D_STRING;
				cre.m_Data[7].svalue = sv.fmsisdn;
				cre.m_Data[7].len = cre.m_Data[7].svalue.length();
				
				}
			break;
			//-------------->done by pankaj ends---->
			case 7:
				{	
					cre.reqID = 1;
					cre.actID = actID;
					cre.priority = 0x01;
					cre.m_no = 8;

					cre.m_Data[0].type = datatype.D_STRING;
					cre.m_Data[0].svalue = sv.getMsisdn();
					cre.m_Data[0].len = cre.m_Data[0].svalue.length();

					cre.m_Data[1].type = datatype.D_STRING;
					cre.m_Data[1].svalue = sv.getInterface();
					cre.m_Data[1].len = cre.m_Data[1].svalue.length();

					cre.m_Data[2].type = datatype.D_INT;
					cre.m_Data[2].ivalue = sv.getPlan();
					cre.m_Data[2].len = 4;

					cre.m_Data[3].type = datatype.D_INT;
					cre.m_Data[3].ivalue = sv.getLang();
					cre.m_Data[3].len = 4;

					cre.m_Data[4].type = datatype.D_STRING;
					cre.m_Data[4].svalue = sv.getUpdatedBy();
					cre.m_Data[4].len = cre.m_Data[4].svalue.length();

					cre.m_Data[5].type = datatype.D_STRING;
					cre.m_Data[5].svalue = sv.getSubType();
					cre.m_Data[5].len = cre.m_Data[5].svalue.length();

					cre.m_Data[6].type = datatype.D_INT;
					cre.m_Data[6].ivalue = sv.rbt_code;
					cre.m_Data[6].len = 4;

					cre.m_Data[7].type = datatype.D_INT;
					cre.m_Data[7].ivalue = sv.albumId;
					cre.m_Data[7].len = 4;

					//cre.m_Data[8].type = datatype.D_STRING;
					//cre.m_Data[8].svalue = sv.albumName;
					//cre.m_Data[8].len = cre.m_Data[8].svalue.length();

				}
				break;
			case 8:
				{	
					cre.reqID = 1;
					cre.actID = actID;
					cre.priority = 0x01;
					cre.m_no = 8;

					cre.m_Data[0].type = datatype.D_STRING;
					cre.m_Data[0].svalue = sv.getMsisdn();
					cre.m_Data[0].len = cre.m_Data[0].svalue.length();

					cre.m_Data[1].type = datatype.D_STRING;
					cre.m_Data[1].svalue = sv.getInterface();
					cre.m_Data[1].len = cre.m_Data[1].svalue.length();

					cre.m_Data[2].type = datatype.D_INT;
					cre.m_Data[2].ivalue = sv.getPlan();
					cre.m_Data[2].len = 4;

					cre.m_Data[3].type = datatype.D_INT;
					cre.m_Data[3].ivalue = sv.getLang();
					cre.m_Data[3].len = 4;

					cre.m_Data[4].type = datatype.D_STRING;
					cre.m_Data[4].svalue = sv.getUpdatedBy();
					cre.m_Data[4].len = cre.m_Data[4].svalue.length();

					cre.m_Data[5].type = datatype.D_STRING;
					cre.m_Data[5].svalue = sv.getSubType();
					cre.m_Data[5].len = cre.m_Data[5].svalue.length();

					cre.m_Data[6].type = datatype.D_INT;
					cre.m_Data[6].ivalue = sv.rbt_code;
					cre.m_Data[6].len = 4;

					//cre.m_Data[7].type = datatype.D_INT;
					//cre.m_Data[7].ivalue = sv.albumId;
					//cre.m_Data[7].len = 4;

					cre.m_Data[7].type = datatype.D_STRING;
					cre.m_Data[7].svalue = sv.albumName;
					cre.m_Data[7].len = cre.m_Data[8].svalue.length();

				}
				break;

			case 9:
				{	
					cre.reqID = 1;
					cre.actID = actID;
					cre.priority = 0x01;
					cre.m_no = 8;

					cre.m_Data[0].type = datatype.D_STRING;
					cre.m_Data[0].svalue = sv.getMsisdn();
					cre.m_Data[0].len = cre.m_Data[0].svalue.length();

					cre.m_Data[1].type = datatype.D_STRING;
					cre.m_Data[1].svalue = sv.getInterface();
					cre.m_Data[1].len = cre.m_Data[1].svalue.length();

					cre.m_Data[2].type = datatype.D_INT;
					cre.m_Data[2].ivalue = sv.getPlan();
					cre.m_Data[2].len = 4;

					cre.m_Data[3].type = datatype.D_INT;
					cre.m_Data[3].ivalue = sv.getLang();
					cre.m_Data[3].len = 4;

					cre.m_Data[4].type = datatype.D_STRING;
					cre.m_Data[4].svalue = sv.getUpdatedBy();
					cre.m_Data[4].len = cre.m_Data[4].svalue.length();

					cre.m_Data[5].type = datatype.D_STRING;
					cre.m_Data[5].svalue = sv.getSubType();
					cre.m_Data[5].len = cre.m_Data[5].svalue.length();

					cre.m_Data[6].type = datatype.D_STRING;
					cre.m_Data[6].svalue = sv.control_name;
					cre.m_Data[6].len = cre.m_Data[6].svalue.length();

					cre.m_Data[7].type = datatype.D_STRING;
					cre.m_Data[7].svalue = "Default";
					cre.m_Data[7].len = cre.m_Data[7].svalue.length();
				}
				break;
			case 10:
				{	
					cre.reqID = 1;
					cre.actID = actID;
					cre.priority = 0x01;
					cre.m_no = 8;

					cre.m_Data[0].type = datatype.D_STRING;
					cre.m_Data[0].svalue = sv.getMsisdn();
					cre.m_Data[0].len = cre.m_Data[0].svalue.length();

					cre.m_Data[1].type = datatype.D_STRING;
					cre.m_Data[1].svalue = sv.getInterface();
					cre.m_Data[1].len = cre.m_Data[1].svalue.length();

					cre.m_Data[2].type = datatype.D_INT;
					cre.m_Data[2].ivalue = sv.getPlan();
					cre.m_Data[2].len = 4;

					cre.m_Data[3].type = datatype.D_INT;
					cre.m_Data[3].ivalue = sv.getLang();
					cre.m_Data[3].len = 4;

					cre.m_Data[4].type = datatype.D_STRING;
					cre.m_Data[4].svalue = sv.getUpdatedBy();
					cre.m_Data[4].len = cre.m_Data[4].svalue.length();

					cre.m_Data[5].type = datatype.D_STRING;
					cre.m_Data[5].svalue = sv.getSubType();
					cre.m_Data[5].len = cre.m_Data[5].svalue.length();

					cre.m_Data[6].type = datatype.D_STRING;
					cre.m_Data[6].svalue = sv.control_name;
					cre.m_Data[6].len = cre.m_Data[6].svalue.length();

					cre.m_Data[7].type = datatype.D_STRING;
					cre.m_Data[7].svalue = sv.fmsisdn;
					cre.m_Data[7].len = cre.m_Data[7].svalue.length();

				}
				break;

			case 11:
				{	
					cre.reqID = 1;
					cre.actID = actID;
					cre.priority = 0x01;
					cre.m_no = 8;

					cre.m_Data[0].type = datatype.D_STRING;
					cre.m_Data[0].svalue = sv.getMsisdn();
					cre.m_Data[0].len = cre.m_Data[0].svalue.length();

					cre.m_Data[1].type = datatype.D_STRING;
					cre.m_Data[1].svalue = sv.getInterface();
					cre.m_Data[1].len = cre.m_Data[1].svalue.length();

					cre.m_Data[2].type = datatype.D_INT;
					cre.m_Data[2].ivalue = sv.getPlan();
					cre.m_Data[2].len = 4;

					cre.m_Data[3].type = datatype.D_INT;
					cre.m_Data[3].ivalue = sv.getLang();
					cre.m_Data[3].len = 4;

					cre.m_Data[4].type = datatype.D_STRING;
					cre.m_Data[4].svalue = sv.getUpdatedBy();
					cre.m_Data[4].len = cre.m_Data[4].svalue.length();

					cre.m_Data[5].type = datatype.D_STRING;
					cre.m_Data[5].svalue = sv.getSubType();
					cre.m_Data[5].len = cre.m_Data[5].svalue.length();

					cre.m_Data[6].type = datatype.D_STRING;
					cre.m_Data[6].svalue = sv.control_name;
					cre.m_Data[6].len = cre.m_Data[6].svalue.length();

					cre.m_Data[7].type = datatype.D_STRING;
					cre.m_Data[7].svalue = sv.groupName;
					cre.m_Data[7].len = cre.m_Data[7].svalue.length();

				}
				break;

			case 12:
				{	
					cre.reqID = 1;
					cre.actID = actID;
					cre.priority = 0x01;
					cre.m_no = 9;

					cre.m_Data[0].type = datatype.D_STRING;
					cre.m_Data[0].svalue = sv.getMsisdn();
					cre.m_Data[0].len = cre.m_Data[0].svalue.length();

					cre.m_Data[1].type = datatype.D_STRING;
					cre.m_Data[1].svalue = sv.getInterface();
					cre.m_Data[1].len = cre.m_Data[1].svalue.length();

					cre.m_Data[2].type = datatype.D_INT;
					cre.m_Data[2].ivalue = sv.getPlan();
					cre.m_Data[2].len = 4;

					cre.m_Data[3].type = datatype.D_INT;
					cre.m_Data[3].ivalue = sv.getLang();
					cre.m_Data[3].len = 4;

					cre.m_Data[4].type = datatype.D_STRING;
					cre.m_Data[4].svalue = sv.getUpdatedBy();
					cre.m_Data[4].len = cre.m_Data[4].svalue.length();

					cre.m_Data[5].type = datatype.D_STRING;
					cre.m_Data[5].svalue = sv.getSubType();
					cre.m_Data[5].len = cre.m_Data[5].svalue.length();

					cre.m_Data[6].type = datatype.D_INT;
					cre.m_Data[6].ivalue = sv.rbt_code;
					cre.m_Data[6].len = 4;

					cre.m_Data[7].type = datatype.D_STRING;
					cre.m_Data[7].svalue = sv.date;
					cre.m_Data[7].len = cre.m_Data[7].svalue.length();

					cre.m_Data[8].type = datatype.D_INT;
					cre.m_Data[8].ivalue = sv.check_rbt;
					cre.m_Data[8].len = 4;
				}
				break;
			case 13:         //default delete
				{	
					cre.reqID = 1;
					cre.actID = actID;
					cre.priority = 0x01;
					cre.m_no = 10;

					cre.m_Data[0].type = datatype.D_STRING;
					cre.m_Data[0].svalue = sv.getMsisdn();
					cre.m_Data[0].len = cre.m_Data[0].svalue.length();

					cre.m_Data[1].type = datatype.D_STRING;
					cre.m_Data[1].svalue = sv.getInterface();
					cre.m_Data[1].len = cre.m_Data[1].svalue.length();

					cre.m_Data[2].type = datatype.D_INT;
					cre.m_Data[2].ivalue = sv.getPlan();
					cre.m_Data[2].len = 4;

					cre.m_Data[3].type = datatype.D_INT;
					cre.m_Data[3].ivalue = sv.getLang();
					cre.m_Data[3].len = 4;

					cre.m_Data[4].type = datatype.D_STRING;
					cre.m_Data[4].svalue = sv.getUpdatedBy();
					cre.m_Data[4].len = cre.m_Data[4].svalue.length();

					cre.m_Data[5].type = datatype.D_STRING;
					cre.m_Data[5].svalue = sv.getSubType();
					cre.m_Data[5].len = cre.m_Data[5].svalue.length();

					cre.m_Data[6].type = datatype.D_INT;
					cre.m_Data[6].ivalue = sv.rbt_code;
					cre.m_Data[6].len = 4;

					cre.m_Data[7].type = datatype.D_STRING;
					cre.m_Data[7].svalue = sv.days;
					cre.m_Data[7].len = cre.m_Data[7].svalue.length();

					cre.m_Data[8].type = datatype.D_INT;
					cre.m_Data[8].ivalue = sv.start_t;
					cre.m_Data[8].len = 4;

					cre.m_Data[9].type = datatype.D_INT;
					cre.m_Data[9].ivalue = sv.end_t;
					cre.m_Data[9].len = 4;

				}
				break;
			case 14:
				{	
					cre.reqID = 1;
					cre.actID = actID;
					cre.priority = 0x01;
					cre.m_no = 11;

					cre.m_Data[0].type = datatype.D_STRING;
					cre.m_Data[0].svalue = sv.getMsisdn();
					cre.m_Data[0].len = cre.m_Data[0].svalue.length();

					cre.m_Data[1].type = datatype.D_STRING;
					cre.m_Data[1].svalue = sv.getInterface();
					cre.m_Data[1].len = cre.m_Data[1].svalue.length();

					cre.m_Data[2].type = datatype.D_INT;
					cre.m_Data[2].ivalue = sv.getPlan();
					cre.m_Data[2].len = 4;

					cre.m_Data[3].type = datatype.D_INT;
					cre.m_Data[3].ivalue = sv.getLang();
					cre.m_Data[3].len = 4;

					cre.m_Data[4].type = datatype.D_STRING;
					cre.m_Data[4].svalue = sv.getUpdatedBy();
					cre.m_Data[4].len = cre.m_Data[4].svalue.length();

					cre.m_Data[5].type = datatype.D_STRING;
					cre.m_Data[5].svalue = sv.getSubType();
					cre.m_Data[5].len = cre.m_Data[5].svalue.length();

					cre.m_Data[6].type = datatype.D_INT;
					cre.m_Data[6].ivalue = sv.rbt_code;
					cre.m_Data[6].len = 4;

					cre.m_Data[7].type = datatype.D_STRING;
					cre.m_Data[7].svalue = sv.days;
					cre.m_Data[7].len = cre.m_Data[7].svalue.length();

					cre.m_Data[8].type = datatype.D_INT;
					cre.m_Data[8].ivalue = sv.start_t;
					cre.m_Data[8].len = 4;

					cre.m_Data[9].type = datatype.D_INT;
					cre.m_Data[9].ivalue = sv.end_t;
					cre.m_Data[9].len = 4;

					cre.m_Data[10].type = datatype.D_STRING;
					cre.m_Data[10].svalue = sv.fmsisdn;
					cre.m_Data[10].len = cre.m_Data[10].svalue.length();
				}
				break;
			case 15:
				{	
					cre.reqID = 1;
					cre.actID = actID;
					cre.priority = 0x01;
					cre.m_no = 11;

					cre.m_Data[0].type = datatype.D_STRING;
					cre.m_Data[0].svalue = sv.getMsisdn();
					cre.m_Data[0].len = cre.m_Data[0].svalue.length();

					cre.m_Data[1].type = datatype.D_STRING;
					cre.m_Data[1].svalue = sv.getInterface();
					cre.m_Data[1].len = cre.m_Data[1].svalue.length();

					cre.m_Data[2].type = datatype.D_INT;
					cre.m_Data[2].ivalue = sv.getPlan();
					cre.m_Data[2].len = 4;

					cre.m_Data[3].type = datatype.D_INT;
					cre.m_Data[3].ivalue = sv.getLang();
					cre.m_Data[3].len = 4;

					cre.m_Data[4].type = datatype.D_STRING;
					cre.m_Data[4].svalue = sv.getUpdatedBy();
					cre.m_Data[4].len = cre.m_Data[4].svalue.length();

					cre.m_Data[5].type = datatype.D_STRING;
					cre.m_Data[5].svalue = sv.getSubType();
					cre.m_Data[5].len = cre.m_Data[5].svalue.length();

					cre.m_Data[6].type = datatype.D_INT;
					cre.m_Data[6].ivalue = sv.rbt_code;
					cre.m_Data[6].len = 4;

					cre.m_Data[7].type = datatype.D_STRING;
					cre.m_Data[7].svalue = sv.days;
					cre.m_Data[7].len = cre.m_Data[7].svalue.length();

					cre.m_Data[8].type = datatype.D_INT;
					cre.m_Data[8].ivalue = sv.start_t;
					cre.m_Data[8].len = 4;

					cre.m_Data[9].type = datatype.D_INT;
					cre.m_Data[9].ivalue = sv.end_t;
					cre.m_Data[9].len = 4;


					cre.m_Data[10].type = datatype.D_STRING;
					cre.m_Data[10].svalue = sv.groupName;
					cre.m_Data[10].len = cre.m_Data[10].svalue.length();
				}
				break;
			case 18:
				{	
					cre.reqID = 1;
					cre.actID = actID;
					cre.priority = 0x01;
					cre.m_no = 7;

					cre.m_Data[0].type = datatype.D_STRING;
					cre.m_Data[0].svalue = sv.getMsisdn();
					cre.m_Data[0].len = cre.m_Data[0].svalue.length();

					cre.m_Data[1].type = datatype.D_STRING;
					cre.m_Data[1].svalue = sv.getInterface();
					cre.m_Data[1].len = cre.m_Data[1].svalue.length();

					cre.m_Data[2].type = datatype.D_INT;
					cre.m_Data[2].ivalue = sv.getPlan();
					cre.m_Data[2].len = 4;

					cre.m_Data[3].type = datatype.D_INT;
					cre.m_Data[3].ivalue = sv.getLang();
					cre.m_Data[3].len = 4;

					cre.m_Data[4].type = datatype.D_STRING;
					cre.m_Data[4].svalue = sv.getUpdatedBy();
					cre.m_Data[4].len = cre.m_Data[4].svalue.length();

					cre.m_Data[5].type = datatype.D_STRING;
					cre.m_Data[5].svalue = sv.getSubType();
					cre.m_Data[5].len = cre.m_Data[5].svalue.length();

					cre.m_Data[6].type = datatype.D_STRING;
					cre.m_Data[6].svalue = sv.groupName;
					cre.m_Data[6].len = cre.m_Data[6].svalue.length();
				}
				break;
			case 17:
				{	
					cre.reqID = 1;
					cre.actID = actID;
					cre.priority = 0x01;
					cre.m_no = 7;

					cre.m_Data[0].type = datatype.D_STRING;
					cre.m_Data[0].svalue = sv.getMsisdn();
					cre.m_Data[0].len = cre.m_Data[0].svalue.length();

					cre.m_Data[1].type = datatype.D_STRING;
					cre.m_Data[1].svalue = sv.getInterface();
					cre.m_Data[1].len = cre.m_Data[1].svalue.length();

					cre.m_Data[2].type = datatype.D_INT;
					cre.m_Data[2].ivalue = sv.getPlan();
					cre.m_Data[2].len = 4;

					cre.m_Data[3].type = datatype.D_INT;
					cre.m_Data[3].ivalue = sv.getLang();
					cre.m_Data[3].len = 4;

					cre.m_Data[4].type = datatype.D_STRING;
					cre.m_Data[4].svalue = sv.getUpdatedBy();
					cre.m_Data[4].len = cre.m_Data[4].svalue.length();

					cre.m_Data[5].type = datatype.D_STRING;
					cre.m_Data[5].svalue = sv.getSubType();
					cre.m_Data[5].len = cre.m_Data[5].svalue.length();

					cre.m_Data[6].type = datatype.D_STRING;
					cre.m_Data[6].svalue = sv.fmsisdn;
					cre.m_Data[6].len = cre.m_Data[6].svalue.length();
				}
				break;
			case 16:
				{	
					cre.reqID = 1;
					cre.actID = actID;
					cre.priority = 0x01;
					cre.m_no = 6;

					cre.m_Data[0].type = datatype.D_STRING;
					cre.m_Data[0].svalue = sv.getMsisdn();
					cre.m_Data[0].len = cre.m_Data[0].svalue.length();

					cre.m_Data[1].type = datatype.D_STRING;
					cre.m_Data[1].svalue = sv.getInterface();
					cre.m_Data[1].len = cre.m_Data[1].svalue.length();

					cre.m_Data[2].type = datatype.D_INT;
					cre.m_Data[2].ivalue = sv.getPlan();
					cre.m_Data[2].len = 4;

					cre.m_Data[3].type = datatype.D_INT;
					cre.m_Data[3].ivalue = sv.getLang();
					cre.m_Data[3].len = 4;

					cre.m_Data[4].type = datatype.D_STRING;
					cre.m_Data[4].svalue = sv.getUpdatedBy();
					cre.m_Data[4].len = cre.m_Data[4].svalue.length();

					cre.m_Data[5].type = datatype.D_STRING;
					cre.m_Data[5].svalue = sv.getSubType();
					cre.m_Data[5].len = cre.m_Data[5].svalue.length();

					cre.m_Data[6].type = datatype.D_INT;
					cre.m_Data[6].ivalue = sv.rbt_code;
					cre.m_Data[6].len = 4;
				}
				break;

			case 19:
				{	
					cre.reqID = 1;
					cre.actID = actID;
					cre.priority = 0x01;
					cre.m_no = 7;

					cre.m_Data[0].type = datatype.D_STRING;
					cre.m_Data[0].svalue = sv.getMsisdn();
					cre.m_Data[0].len = cre.m_Data[0].svalue.length();

					cre.m_Data[1].type = datatype.D_STRING;
					cre.m_Data[1].svalue = sv.getInterface();
					cre.m_Data[1].len = cre.m_Data[1].svalue.length();

					cre.m_Data[2].type = datatype.D_INT;
					cre.m_Data[2].ivalue = sv.getPlan();
					cre.m_Data[2].len = 4;

					cre.m_Data[3].type = datatype.D_INT;
					cre.m_Data[3].ivalue = sv.getLang();
					cre.m_Data[3].len = 4;

					cre.m_Data[4].type = datatype.D_STRING;
					cre.m_Data[4].svalue = sv.getUpdatedBy();
					cre.m_Data[4].len = cre.m_Data[4].svalue.length();

					cre.m_Data[5].type = datatype.D_STRING;
					cre.m_Data[5].svalue = sv.getSubType();
					cre.m_Data[5].len = cre.m_Data[5].svalue.length();

					cre.m_Data[6].type = datatype.D_INT;
					cre.m_Data[6].ivalue = sv.rbt_code;
					cre.m_Data[6].len = 4;
				}
				break;
			case 23:
				{	
					cre.reqID = 1;
					cre.actID = actID;
					cre.priority = 0x01;
					cre.m_no = 10;

					cre.m_Data[0].type = datatype.D_STRING;
					cre.m_Data[0].svalue = sv.getMsisdn();
					cre.m_Data[0].len = cre.m_Data[0].svalue.length();

					cre.m_Data[1].type = datatype.D_STRING;
					cre.m_Data[1].svalue = sv.getInterface();
					cre.m_Data[1].len = cre.m_Data[1].svalue.length();

					cre.m_Data[2].type = datatype.D_INT;
					cre.m_Data[2].ivalue = sv.getPlan();
					cre.m_Data[2].len = 4;

					cre.m_Data[3].type = datatype.D_INT;
					cre.m_Data[3].ivalue = sv.getLang();
					cre.m_Data[3].len = 4;

					cre.m_Data[4].type = datatype.D_STRING;
					cre.m_Data[4].svalue = sv.getUpdatedBy();
					cre.m_Data[4].len = cre.m_Data[4].svalue.length();

					cre.m_Data[5].type = datatype.D_STRING;
					cre.m_Data[5].svalue = sv.getSubType();
					cre.m_Data[5].len = cre.m_Data[5].svalue.length();

					cre.m_Data[6].type = datatype.D_INT;
					cre.m_Data[6].ivalue = sv.rbt_code;
					cre.m_Data[6].len = 4;

					cre.m_Data[7].type = datatype.D_STRING;
					cre.m_Data[7].svalue = sv.days;
					cre.m_Data[7].len = cre.m_Data[7].svalue.length();

					cre.m_Data[8].type = datatype.D_INT;
					cre.m_Data[8].ivalue = sv.start_t;
					cre.m_Data[8].len = 4;

					cre.m_Data[9].type = datatype.D_INT;
					cre.m_Data[9].ivalue = sv.end_t;
					cre.m_Data[9].len = 4;

				}
				break;
			case 25:
				{	
					cre.reqID = 1;
					cre.actID = actID;
					cre.priority = 0x01;
					cre.m_no = 8;

					cre.m_Data[0].type = datatype.D_STRING;
					cre.m_Data[0].svalue = sv.getMsisdn();
					cre.m_Data[0].len = cre.m_Data[0].svalue.length();

					cre.m_Data[1].type = datatype.D_STRING;
					cre.m_Data[1].svalue = sv.getInterface();
					cre.m_Data[1].len = cre.m_Data[1].svalue.length();

					cre.m_Data[2].type = datatype.D_INT;
					cre.m_Data[2].ivalue = sv.getPlan();
					cre.m_Data[2].len = 4;

					cre.m_Data[3].type = datatype.D_INT;
					cre.m_Data[3].ivalue = sv.getLang();
					cre.m_Data[3].len = 4;

					cre.m_Data[4].type = datatype.D_STRING;
					cre.m_Data[4].svalue = sv.getUpdatedBy();
					cre.m_Data[4].len = cre.m_Data[4].svalue.length();

					cre.m_Data[5].type = datatype.D_STRING;
					cre.m_Data[5].svalue = sv.getSubType();
					cre.m_Data[5].len = cre.m_Data[5].svalue.length();

					cre.m_Data[6].type = datatype.D_INT;
					cre.m_Data[6].ivalue = sv.rbt_code;
					cre.m_Data[6].len = 4;

					cre.m_Data[7].type = datatype.D_STRING;
					cre.m_Data[7].svalue = sv.date;
					cre.m_Data[7].len = cre.m_Data[7].svalue.length();

				}
				break;
			case 26:
				{	
					cre.reqID = 1;
					cre.actID = actID;
					cre.priority = 0x01;
					cre.m_no = 10;

					cre.m_Data[0].type = datatype.D_STRING;
					cre.m_Data[0].svalue = sv.getMsisdn();
					cre.m_Data[0].len = cre.m_Data[0].svalue.length();

					cre.m_Data[1].type = datatype.D_STRING;
					cre.m_Data[1].svalue = sv.getInterface();
					cre.m_Data[1].len = cre.m_Data[1].svalue.length();

					cre.m_Data[2].type = datatype.D_INT;
					cre.m_Data[2].ivalue = sv.getPlan();
					cre.m_Data[2].len = 4;

					cre.m_Data[3].type = datatype.D_INT;
					cre.m_Data[3].ivalue = sv.getLang();
					cre.m_Data[3].len = 4;

					cre.m_Data[4].type = datatype.D_STRING;
					cre.m_Data[4].svalue = sv.getUpdatedBy();
					cre.m_Data[4].len = cre.m_Data[4].svalue.length();

					cre.m_Data[5].type = datatype.D_STRING;
					cre.m_Data[5].svalue = sv.getSubType();
					cre.m_Data[5].len = cre.m_Data[5].svalue.length();

					cre.m_Data[6].type = datatype.D_INT;
					cre.m_Data[6].ivalue = sv.rbt_code;
					cre.m_Data[6].len = 4;

					cre.m_Data[7].type = datatype.D_STRING;
					cre.m_Data[7].svalue = sv.date;
					cre.m_Data[7].len = cre.m_Data[7].svalue.length();

					cre.m_Data[8].type = datatype.D_INT;
					cre.m_Data[8].ivalue = sv.check_rbt;
					cre.m_Data[8].len = 4;

					cre.m_Data[9].type = datatype.D_STRING;
					cre.m_Data[9].svalue = sv.getOcc();
					cre.m_Data[9].len = cre.m_Data[9].svalue.length();

				}
				break;



			default:
				return -1;
		}
		return 0;
	}

	public int send()
	{
		err_string = "";
		try
		{
			cre.encode(buf);
			int requestLen =buf.size();
			logger.info("Data length is "+requestLen);
			logger.info("CRBT Rule Engine IP"+TSSJavaUtil.instance().getSSFServerCre()+"  Port"+TSSJavaUtil.instance().getSSFPortCre());

			int ret = Prepare_TCP();
			if (ret < 0)
			{
				logger.info("Error in Socket Connection");
				err_string = "Error in Socket Connection";
				return -1;
			}
			byte[] len =    new byte[4];
			len[3] = (byte)(requestLen );
			len[2] = (byte)((requestLen >> 8));
			len[1] = (byte)((requestLen >> 16));
			len[0] = (byte)((requestLen >> 24));
			logger.info("Data length is"+requestLen);
			writer.write(len,0,4);
			writer.write(buf.toByteArray(),0, buf.toByteArray().length);

			//		byte []buff = buf.toByteArray();
			//	for (int i = 0; i<buf.size();i++)
			//			System.out.print(Integer.toHexString(buff[i])+" ");
			int dataLen =0;
			try
			{
				byte dataBuf1[] = new byte[4];
				if(reader.read(dataBuf1,0,4)==-1)
				{
					logger.info("reader.read == -1 ...");
					try
					{

						logger.info("stream closed");
						logger.info("Destroy");


					}
					catch(Exception e)
					{
						logger.error(e);
					}
				}
				for(int i= 0; i<4;i++)
					logger.info(Integer.toHexString(dataBuf1[i]));
				dataLen = 0;
				int test=0;

				dataLen = dataLen | (dataBuf1[0] << 24);
				dataLen = dataLen  | (dataBuf1[1] << 16);
				dataLen = dataLen | (dataBuf1[2] << 8);
				test=(0x000000ff & dataBuf1[3]);
				dataLen = dataLen | test;
				logger.info("reading Info ......data len.."+dataLen);
			}
			catch (Exception e)
			{
				logger.error("Getting exception in reading...."+e.toString());
			}

			logger.info("recieved tcp_req size="+dataLen);

			//int responseLen = reader.readInt();
			//logger.info("recieved response size="+responseLen);
			byte responseBuf[] = new byte[dataLen];
			reader.read(responseBuf, 0, dataLen);
			//	for (int i = 0; i<responseLen;i++)
			//			System.out.print(Integer.toHexString(responseBuf[i])+" ");
			inbuf = new ByteArrayInputStream(responseBuf);
			cre.decode(inbuf);
			this.err_string = cre.res_String;

			socket.close();
		}
		catch (SocketException se)
		{
			logger.error("Error in opening socket\n");
			se.printStackTrace();
			this.err_string = "Error in opening Port";
			return -1;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			this.err_string = "Error Occured try after some time";
			return -1;
		}

		return cre.errcode;
	}
	/*
	   public int doEventBasedCharging(String msisdn, int tariffID, int rbtcode, String fmsisdn, int action, String interfaceType)
	   {
	   logger.info("doEventBasedCharging()"+msisdn+"  "+action+" "+interfaceType);
	   Socket socket = null;
	   DataOutputStream writer = null;
	   DataInputStream reader = null;
	   String packetData="";
	   StringBuffer chStatus=null;
	   try
	   {
	   logger.info("opening socket to..="+SSF_SERVER_HOST+" Port="+SSF_SERVER_PORT);
	   socket = new Socket (SSF_SERVER_HOST, SSF_SERVER_PORT);
	//		socket.setSoTimeout(100); //100ms
	}
	catch (SocketException se)
	{
	logger.error("Error in opening socket\n");
	se.printStackTrace();
	return -1;
	}
	catch (Exception e)
	{
	e.printStackTrace();
	return -1;
	}

	try
	{
	logger.info("opening read/write stream");
	reader = new DataInputStream(socket.getInputStream());
	writer = new DataOutputStream(socket.getOutputStream());
	}
	catch (IOException ioe)
	{
	logger.error("Failed to get input/output stream\n");
	ioe.printStackTrace();
	return -1;
	}

	try
	{
	//	socket.setSoTimeout(100); //100ms
	switch(action)
	{
	case 1: //Subscription 
	packetData="ACT:"+action+";TAR:"+tariffID+";INT:"+interfaceType;
	break;
	case 2: //Subscription renew
	break;
	case 3: //RBT purchase
	packetData="ACT:"+action+";TAR:"+tariffID+";RBT:"+rbtcode+";INT:"+interfaceType;
	break;
	case 4: //RBT Gift
	packetData="ACT:"+action+";TAR:"+tariffID+";RBT:"+rbtcode+";FMSISDN:"+fmsisdn+";INT:"+interfaceType;
	break;
	default:
	break;
	}
	logger.info("packet ="+packetData);
	TCPRequest request = new TCPRequest();
	TCPRequest response= new TCPRequest();
	ByteArrayOutputStream buf = new ByteArrayOutputStream();
	ByteArrayInputStream inbuf = null;
	request.setMsisdn(msisdn);
	//request.setTariffID(tariffID);
	request.setPacketData(packetData);

	request.encode(buf);

	int requestLen = buf.size();
	logger.info("request:packetData info buf size="+requestLen+" .... sending" );
	writer.writeInt(requestLen);
	writer.write(buf.toByteArray(), 0, buf.toByteArray().length);

	//logger.info("reading Info from SSFResponse");
	logger.info("response: reading info ....");
	int responseLen = reader.readInt();
	logger.info("recieved response size="+responseLen);
	byte responseBuf[] = new byte[responseLen];
	reader.read(responseBuf, 0, responseLen);

	inbuf = new ByteArrayInputStream(responseBuf);
	response.decode(inbuf);

	// String packetDataRes = response.getPacketData();
	resp = 	response.getResponseId();

	logger.info("response: ="+resp);
	socket.close();
	return resp;
}
catch(InterruptedIOException ioEx)
{

	logger.error("Socket TimeOut occurred");
	ioEx.printStackTrace();
	return -5;
}
catch (IOException ioe)
{
	logger.error("Failed to read / write\n");
	ioe.printStackTrace();
	return -6;
}
}//doEventBasedCharging*/

int Prepare_TCP()
{  
	int i = 0;
	for (i = 0; i<3;i++)
	{
		try
		{
			socket = new Socket (TSSJavaUtil.instance().getSSFServerCre(), TSSJavaUtil.instance().getSSFPortCre());
			break;
		}
		catch (SocketException se)
		{
			logger.error("Error in opening socket\n");
			se.printStackTrace();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
	if (i == 3)
		return -1;
	for (i = 0; i<3;i++)
	{
		try
		{
			writer = new DataOutputStream(socket.getOutputStream());
			break;
		}
		catch (IOException ioe)
		{
			logger.error("Failed to get input/output stream\n");
			ioe.printStackTrace();
		}
	}
	if (i == 3)
		return -1;
	for (i = 0; i<3;i++)
	{
		try
		{
			reader = new DataInputStream(socket.getInputStream());
			break;
		}
		catch (IOException ioe)
		{
			logger.error("Failed to get input/output stream\n");
			ioe.printStackTrace();
		}
	}
	if (i == 3)
		return -1;

	return 0;
}


}//class
