package com.telemune.vcc.custcare;
import java.io.*;
import java.util.*;
import java.net.*;

import org.apache.log4j.*;
enum datatype
				{ D_INT,D_STRING,D_FLOAT,D_DATE,D_NONE	}

class Paramstore
{
           static Logger logger=Logger.getLogger(Paramstore.class);
			//	public enum datatype
			//	{ D_INiT,D_STRING,D_FLOAT,D_DATE,D_NONE	}
				public int ivalue=0;
				public String svalue="";
				public Date dvalue=null;
				public int len;
				public int position;
				public int nvind;
    public datatype type;
				
				public Paramstore()
				{
				ivalue = -1;
				svalue = "";
				len = -1;
				position = -1;
				}

			 int getIvalue()
				{
								return ivalue;
				}
				String getSvalue()
				{
								return svalue;
				}
				Date getDvalue()
				{
								return dvalue;
				}
				
}

class CREMessage extends Paramstore
{
 public Paramstore[] m_Data;  // array for storing the parameters in request...
 public int reqID;
 public int actID;
 public int res_reqID;
 public int res_actID;
	public String res_String="";
 public int errcode;
 public int m_no;   // number of parameters in request.
	public	int priority;
 public boolean processed;
	public CREMessage()
	{
					m_no=0;
					m_Data = new Paramstore[20];
					for (int i=0;i<20;i++)
									m_Data[i] = new Paramstore();
	}

	public int encode(ByteArrayOutputStream buf)
	{
 writeInt(reqID,buf);
 writeInt(actID,buf);
	byte b1 = (byte)(priority);
	buf.write(b1);
 writeInt(m_no,buf);

	for (int i = 0; i < m_no;i++)
				{
		//System.out.println(i+" : ----------------------------------------->"+m_Data[i].type+" || "+m_Data[i].svalue);
				switch (m_Data[i].type)
				{
								case D_INT:
												{
												b1 = 1;
												buf.write(b1);
												writeInt(4,buf);
												writeInt(m_Data[i].getIvalue(),buf);
												}
												break;
								case D_STRING:
												{
												b1 = 2;
												buf.write(b1);
												String data = m_Data[i].getSvalue();
												writeInt(data.length(),buf);
												buf.write(data.getBytes(),0,data.length());
												}
												break;
								case D_DATE:
												{
												b1 = 4;
												buf.write(b1);
												writeInt(4,buf);
												int date_sec =(int) (m_Data[i].getDvalue().getTime()/1000);
												writeInt(date_sec,buf);
												}
											break;
								default:
												break;
				}
				}
	

 return 0;	
	}
	public int decode(ByteArrayInputStream buf)
	{
					int dataLen = 0;
					int test = 0;
					byte[] dataBuf1 = new byte[4];
					buf.read(dataBuf1,0,4);
					dataLen = dataLen | (dataBuf1[0] << 24);
					dataLen = dataLen  | (dataBuf1[1] << 16);
					dataLen = dataLen | (dataBuf1[2] << 8);
					test=(0x000000ff & dataBuf1[3]);
					dataLen = dataLen | test;

					res_reqID = dataLen;

					dataLen = 0; test = 0;
				 buf.read(dataBuf1,0,4);
					dataLen = dataLen | (dataBuf1[0] << 24);
					dataLen = dataLen  | (dataBuf1[1] << 16);
					dataLen = dataLen | (dataBuf1[2] << 8);
					test=(0x000000ff & dataBuf1[3]);
					dataLen = dataLen | test;

					res_actID = dataLen;
					
					dataLen = 0; test = 0;
				 buf.read(dataBuf1,0,4);
					dataLen = dataLen | (dataBuf1[0] << 24);
					dataLen = dataLen  | (dataBuf1[1] << 16);
					dataLen = dataLen | (dataBuf1[2] << 8);
					test=(0x000000ff & dataBuf1[3]);
					dataLen = dataLen | test;

				 errcode = dataLen;
					
					dataLen = 0; test = 0;
				 buf.read(dataBuf1,0,4);
					dataLen = dataLen | (dataBuf1[0] << 24);
					dataLen = dataLen  | (dataBuf1[1] << 16);
					dataLen = dataLen | (dataBuf1[2] << 8);
					test=(0x000000ff & dataBuf1[3]);
					dataLen = dataLen | test;

					byte[] dbuf=new byte[dataLen];
					buf.read(dbuf,0,dataLen);
					res_String = new String(dbuf); 

					return 0;
	}

	public int writeInt(int value,ByteArrayOutputStream buf)
	{
  int i2send = value;
		byte buffer[] = new byte[4];
		buffer[0] = (byte) ((i2send >> 24) & 0xff);
		buffer[1] = (byte) ((i2send >> 16) & 0xff);
		buffer[2] = (byte) ((i2send >> 8) & 0xff);
		buffer[3] = (byte) ((i2send) & 0xff);
		buf.write(buffer,0,4);
		return 0;
	}
	public static void main (String args[]) throws Exception
	{
					Socket socket = null;
					DataOutputStream writer = null;
					DataInputStream reader = null;
     ByteArrayInputStream inbuf = null;
					ByteArrayOutputStream buf = new ByteArrayOutputStream();
					try
					{
									socket = new Socket ("192.168.57.25",8780);
					}
					catch (SocketException se)
					{
									logger.error("Error in opening socket\n");
									se.printStackTrace();
					}
					catch (Exception e)
					{
									e.printStackTrace();
					}
					try
					{
									writer = new DataOutputStream(socket.getOutputStream());
									reader = new DataInputStream(socket.getInputStream());
					}
					catch (IOException ioe)
					{
									logger.error("Failed to get input/output stream\n");
									ioe.printStackTrace();
					}

					CREMessage cre = new CREMessage();
					cre.reqID = 1;
					cre.actID = 1;
					cre.priority = 0x01;
					cre.m_no = 6;

					//cre.m_Data[0].type = datatype.D_STRING;
					cre.m_Data[0].type = datatype.D_STRING;
					cre.m_Data[0].svalue = "919818523544";
					cre.m_Data[0].len = cre.m_Data[0].svalue.length();

					cre.m_Data[1].type = datatype.D_STRING;
					cre.m_Data[1].svalue = "U";
					cre.m_Data[1].len = cre.m_Data[1].svalue.length();

					cre.m_Data[2].type = datatype.D_INT;
					cre.m_Data[2].ivalue = 1;
					cre.m_Data[2].len = 4;

					cre.m_Data[3].type = datatype.D_INT;
					cre.m_Data[3].ivalue = 1;
					cre.m_Data[3].len = 4;

					cre.m_Data[4].type = datatype.D_STRING;
					cre.m_Data[4].svalue = "919818523544";
					cre.m_Data[4].len = cre.m_Data[4].svalue.length();

				 cre.m_Data[5].type = datatype.D_STRING;
						            cre.m_Data[5].svalue = "P";
																		            cre.m_Data[5].len = cre.m_Data[5].svalue.length();

     cre.encode(buf);
					int requestLen =buf.size();
					logger.info("Data length is "+requestLen);
					byte[] len =    new byte[4];
					len[3] = (byte)(requestLen & 0xff);
					len[2] = (byte)((requestLen >> 8) & 0xff);
					len[1] = (byte)((requestLen >> 16) & 0xff);
					len[0] = (byte)((requestLen >> 24) & 0xff);
					writer.write(len,0,4);
					writer.write(buf.toByteArray(),0, buf.toByteArray().length);
		   byte []buff = buf.toByteArray();
					for (int i = 0; i<buf.size();i++)
					System.out.print(Integer.toHexString(buff[i])+" ");

									int responseLen = reader.readInt();
									logger.info("recieved response size="+responseLen);
									byte responseBuf[] = new byte[responseLen];
									reader.read(responseBuf, 0, responseLen);
					 			for (int i = 0; i<responseLen;i++)
						 		System.out.print(Integer.toHexString(responseBuf[i])+" ");
									inbuf = new ByteArrayInputStream(responseBuf);
									cre.decode(inbuf);

									logger.info("req_id:"+cre.res_reqID+"act_id"+cre.res_actID+"errcode:"+cre.errcode+"status:"+cre.res_String);

					try
					{
					socket.close();
					}
					catch (SocketException se)
					{
									logger.error("Error in opening socket\n");
									se.printStackTrace();
					}
	}
}
