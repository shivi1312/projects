/*
 *
 *
 *
 */
package com.telemune.vcc.custcare;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.StringTokenizer;

import com.telemune.dbutilities.*;
import com.telemune.vcc.common.*;

import org.apache.log4j.*;

public class CallCenterManagerBean
{
   private static Logger logger=Logger.getLogger(CallCenterManagerBean.class);
  
	//to be set by caller
	private ConnectionPool conPool = null;

	//will be used internally
	private Connection con = null;


	//to be received from caller, wont work if these fields are not set
	private SubscriberCallerManager scm =  null;
	//to be received from caller, wont work if these fields are not set
	private String subscriberProfile =  null;
	private String query="";
	private String interfaceType="C";
	private PreparedStatement pstmt=null;
	private ResultSet rs=null;
	//private SessionHistory sessionHistory =  null;
	private String user="";
	//to be set in this class (on first access)
	private ArrayList groupDetails = null;
	private ArrayList friendDetails = null;

	//to be set in this class (on first access)
	private ArrayList groupSettings = null;
	private ArrayList friendSettings = null;
	private ArrayList defaultSettings = null;
	private ArrayList dateSettings = null;
	private ArrayList occSettings = null;
	private ArrayList advanceSettings = null;
	private ArrayList groupAdvanceSettings = null;

	public CallCenterManagerBean()
	{
		scm = new SubscriberCallerManager();
	}	

	public void setConnectionPool(ConnectionPool conPool)
	{
		this.conPool = conPool;			
	}

	public void setSubscriberProfile(String sp)
	{
		this.subscriberProfile = sp;	
	}

	// update by ekansh
	/*public void setSessionHistory(SessionHistory sh)
	{
		this.sessionHistory = sh;	
	}*/
	
	public void setUser(String name)
	{
		this.user=name;
	}

	public ArrayList getGroupSettings()
	{
		return groupSettings;
	}

	public ArrayList getFriendSettings()
	{
		return friendSettings;
	}

	public ArrayList getDefaultSettings()
	{
		return defaultSettings;
	}

	public ArrayList getDateSettings()
	{
		return dateSettings;
	}
	public ArrayList getOccSettings()
	{
		return occSettings;
	}

	public ArrayList getAdvanceSettings()
	{
		return advanceSettings;
	}

	public ArrayList getGroupAdvanceSettings()
	{
		return groupAdvanceSettings;
	}

	public int getSubscriberCallerInfo(String msisdn,Connection con)
	{
		logger.info("getSubscriberCallerInfo()"+msisdn);
		try
		{

		
			SubscriberCallerManager scam = new SubscriberCallerManager(con);

			groupSettings = new ArrayList();
			friendSettings = new ArrayList();
			defaultSettings = new ArrayList();
			dateSettings = new ArrayList();				
			occSettings = new ArrayList();				
			advanceSettings = new ArrayList();				
			groupAdvanceSettings = new ArrayList();				

			if (scam.getSubscriberOccSettings(msisdn,occSettings) != 1 )
			{
				logger.info("Error In Getting Date");
				return 0;
			}
			if (scam.getSubscriberDateSettings(msisdn,dateSettings) != 1 )
			{
				logger.info("Error In Getting Date");
				return 0;
			}
			if (scam.getSubscriberFriendSettings(msisdn, friendSettings, advanceSettings) != 1) 
			{
				logger.info("Error In Getting Friends");
				return 0;
			}
			if (scam.getSubscriberGroupSettings(msisdn,groupSettings, groupAdvanceSettings) != 1)
			{
				logger.info("Error In Getting Groups");
				return 0;
			}
			if (scam.getSubscriberDefaultSettings(msisdn,defaultSettings) != 1)
			{
				logger.info("Error In Getting Defaults");
				return 0;
			}			
			return 1;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
		/*finally
		{
			conPool.free(con);
		}*/		
	}

	public int addNewFriend(String msisdn, ArrayList friends, ArrayList friendsNickAl,Connection con)
	{
		logger.info("Inside function addNewFriend() where [ "+msisdn+"]");
		try
		{
			String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(msisdn);
			
			con.setAutoCommit(false);

			FriendManager fm = new FriendManager(con);
			/* converting all Friends number to International format*/
			ArrayList interFriends = new ArrayList();
			Iterator ite = friends.iterator();
			while(ite.hasNext())
			{
				String interFriend = TSSJavaUtil.instance().getInternationalNumber((String)ite.next());
				interFriends.add(interFriend);
				insertIntoFriendOpLog(interMsisdn, 1, interFriend,con);
			}

			int i = fm.addFriends(interMsisdn, interFriends, friendsNickAl);

			if (i != 1) 
			{
				con.rollback();
				return i;
			}

			insertIntoSubscriberAudit(interMsisdn, 1, "Friends Added",con);

			con.commit();
			return 1;				
		}
		catch (Exception e)
		{
			try {
				con.rollback();
			} catch (Exception exp) {}
			e.printStackTrace();
			return 0;
		}
		/*finally
		{
			conPool.free(con);
		}*/
	}//addNewFriend

	public int modifyFriend(String msisdn, String friendMsisdn, String nick,Connection con)
	{
		logger.info("modifyFriend()"+msisdn);
		try
		{
			//data not loaded, load it				
			String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(msisdn);	
			String interFriendMsisdn = TSSJavaUtil.instance().getInternationalNumber(friendMsisdn);

			//con = conPool.getConnection();

			con.setAutoCommit(false);

			FriendManager fm = new FriendManager(con);

			int ret = fm.updateFriend(interMsisdn, interFriendMsisdn, nick);
			if (ret != 1)
			{
				con.rollback();
				return ret;
			}
			insertIntoFriendOpLog(interMsisdn, 3, interFriendMsisdn,con);
			insertIntoSubscriberAudit (interMsisdn, 1, "Friend modified",con);
			con.commit();	
			return 1;
		}
		catch (Exception e)
		{
			try {
				con.rollback();
			} catch(Exception exp) {}
			e.printStackTrace();
			return 0;
		}
		/*finally
		{
			conPool.free(con);
		}*/
	}//modifyFriend

	public int deleteFriends(String msisdn, String  friendMsisdns[],Connection con)
	{
		logger.info("deleteFriends()"+msisdn);
		try
		{
			String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(msisdn);	
			//con = conPool.getConnection();

			con.setAutoCommit(false);

			FriendManager fm = new FriendManager(con);

			for(int i =0; i<friendMsisdns.length; i++)
			{
				String interFriendMsisdn = TSSJavaUtil.instance().getInternationalNumber(friendMsisdns[i]);	
				if(fm.deleteFriend(interMsisdn,interFriendMsisdn) != 1)
				{
					con.rollback();
					return 0;
				}

				insertIntoFriendOpLog(interMsisdn, 2, interFriendMsisdn,con);
			}

			insertIntoSubscriberAudit(interMsisdn, 1, "Friends Deleted",con);

			con.commit();
			return 1;
		}
		catch (Exception e)
		{
			try {
				con.rollback();
			} catch (Exception exp) {}
			e.printStackTrace();
			return 0;
		}
		/*finally
		{
			conPool.free(con);
		}*/
	}//deleteFriends
	
	public ArrayList getFriendsList(String msisdn,Connection con)
	{
		logger.info("inside callcentermanagerBean --> getFriendsList()");
		try
		{
			//data not loaded, load it

			//con = conPool.getConnection();

			FriendManager fm = new FriendManager(con);

			friendDetails = new ArrayList();
			logger.info("fm.getFriendDetails(msisdn, friendDetails)  ----->"+fm.getFriendDetails(msisdn, friendDetails));
			if (fm.getFriendDetails(msisdn, friendDetails) != 1) 
			{
				logger.info("Error In Getting Friends");
				System.out.println("Error In Getting Friends");
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		/*finally
		{
			conPool.free(con);
		}*/
		return friendDetails;
	}

	public int addSubscriberGroup(String groupName, String msisdn, ArrayList friends,Connection con) 	{
		logger.info("addSubscriberGroup()");
		String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(msisdn);	
		/* converting all Friends number to International format*/
		ArrayList interFriends = new ArrayList();
		Iterator ite = friends.iterator();
		while(ite.hasNext())
		{
			interFriends.add(TSSJavaUtil.instance().getInternationalNumber((String)ite.next()));
		}

		SubscriberGroup sg = new SubscriberGroup();
		sg.setGroupName(groupName);
		sg.setMsisdn(interMsisdn);
		sg.setFriends(interFriends);
		try
		{
			//con = conPool.getConnection();

			con.setAutoCommit(false);

			GroupManager gm = new GroupManager(con);

			int ret = gm.addGroup(sg);
			logger.info("return value from addGroup() is = "+ret);
			if (ret != 1)
			{
				con.rollback();
				return ret;
			}

			insertIntoGroupOpLog(interMsisdn, 1, sg.getGroupId(),con);
			insertIntoSubscriberAudit(interMsisdn, 1, "Group Added",con); 
			con.commit();
			return 1;	
		}
		catch (Exception e)
		{
			try {
				con.rollback();
			} catch (Exception exp) {}
			e.printStackTrace();
			return 0;
		}
		/*finally
		{
			conPool.free(con);
		}*/
	}//addSubscriberGroup

	public int modifySubscriberGroup(String groupName, long groupId, String msisdn, ArrayList friends,Connection con) 
	{
		logger.info("modifySubscriberGroup()");

		String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(msisdn);	
		/* converting all Friends number to International format*/
		ArrayList interFriends = new ArrayList();
		Iterator ite = friends.iterator();
		while(ite.hasNext())
		{
			interFriends.add(TSSJavaUtil.instance().getInternationalNumber((String)ite.next()));
		}
		SubscriberGroup sg = new SubscriberGroup();
		sg.setGroupName(groupName.toUpperCase());
		sg.setMsisdn(interMsisdn);
		sg.setFriends(interFriends);
		sg.setGroupId(groupId);

		try
		{
			//con = conPool.getConnection();
			con.setAutoCommit(false);

			GroupManager gm = new GroupManager(con);

			int ret = gm.modifyGroup(sg);
			logger.info("return value from modifyGroup() is "+ret);
			if(ret != 1 )
			{
				con.rollback();	
				return ret;
			}

			insertIntoGroupOpLog(interMsisdn, 3, groupId,con);
			insertIntoSubscriberAudit(interMsisdn, 1, "Group Modified",con);

			con.commit();
			return 1;				
		}
		catch (Exception e)
		{
			try
			{
				con.rollback();
			} catch (Exception exp) {}
			e.printStackTrace();
			return 0;
		}
//		finally
//		{
//			conPool.free(con);
//		}
	}//modifySubscriberGroup

	public int deleteGroups(String msisdn, String  groupId[],Connection con)
	{
		logger.info("deleteGroups()");

		try
		{
			//con = conPool.getConnection();

			String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(msisdn);	

			GroupManager gm = new GroupManager(con);

			con.setAutoCommit(false);

			for(int i =0; i<groupId.length; i++)
			{
				long gId = Long.parseLong(groupId[i]);

				if (gm.deleteGroup(interMsisdn, gId) != 1)
				{
					logger.info("group is not deleted");
					con.rollback();
					return 0;
				}

				insertIntoGroupOpLog (interMsisdn, 2, gId,con);
			}

			insertIntoSubscriberAudit(interMsisdn, 1, "Groups Deleted",con);

			con.commit();
			return 1;
		}
		catch (Exception e)
		{
			try
			{
				con.rollback();
			} catch (Exception exp) {}
			e.printStackTrace();
			return 0;
		}
		/*finally
		{
			conPool.free(con);
		}*/
	}//deleteGroups

	public ArrayList getGroupsList(String msisdn,Connection con)
	{
		logger.info("inside getGroupList()");
		try
		{
			//con = conPool.getConnection();

			GroupManager gm = new GroupManager(con);

			groupDetails = new ArrayList();

			if (gm.getGroupDetails(msisdn, groupDetails) != 1) 
			{
				logger.info("Error In Getting Groups");
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		/*finally
		{
			conPool.free(con);
		}*/
		return groupDetails;
	}
	public String setSubscriberDefaultTone(SubscriberProfile sub, ArrayList toneSettingsAl, int rbtCode , int rbt_check,String userId)
	{
		logger.info("setSubscriberDefaultTone()"+sub.getMsisdn());

		String changeType="DEFAULT_RINGTONE";
		String interMsisdn = sub.getMsisdn();

		Iterator ite = toneSettingsAl.iterator();
		String day = "";
		int start_t = 0;
		int end_t = 0;
		while(ite.hasNext())
		{
			ToneSetting toneSetting = (ToneSetting)ite.next();
			day = day + toneSetting.getDay();
			start_t = toneSetting.getStartTime();
			end_t = toneSetting.getEndTime();
		}

		if ((day.compareTo("1234567") == 0))
			day = "8";

		String ret_str = "";
		SetVariable sv = new SetVariable();
		sv.setMsisdn(interMsisdn);
		sv.setPlan(sub.getPlanIndicator());
		sv.setLang(sub.getLang());
		sv.setInterface("C");
		sv.setUpdatedBy(userId);
		sv.setSubType(sub.getSubType());
		sv.rbt_code = rbtCode;
		sv.days = day;
		sv.start_t = start_t;
		sv.end_t = end_t;
		sv.check_rbt = rbt_check;

		CRBTRequest crbt_req = new CRBTRequest();
		crbt_req.constructQuery(3,sv);
		logger.info("sending request to rule engine");
		int ret_val = crbt_req.send();
		if (ret_val == 0)
		{
			ret_str = "SuccessFul";
		}
		else
		{
			ret_str = crbt_req.err_string;
		}

		//	insertIntoRbtOpLog(interMsisdn, rbtCode, 1, "Default", "N", 1);
		//	insertIntoSubscriberAudit(interMsisdn, 1, "Default RBT is set");
		return ret_str;// retVal;
	}//setSubscriberDefaultTone

	public String setSubscriberGroupTone(SubscriberProfile sub, ArrayList toneSettingsAl, int rbtCode , int rbt_check,String userId,String groupName)
	{
		logger.info("setSubscriberDefaultTone()"+sub.getMsisdn());

		String changeType="DEFAULT_RINGTONE";
		String interMsisdn = sub.getMsisdn();

		Iterator ite = toneSettingsAl.iterator();
		String day = "";
		int start_t = 0;
		int end_t = 0;
		while(ite.hasNext())
		{
			ToneSetting toneSetting = (ToneSetting)ite.next();
			day = day + toneSetting.getDay();
			start_t = toneSetting.getStartTime();
			end_t = toneSetting.getEndTime();
		}

		if ((day.compareTo("1234567") == 0))
			day = "8";

		String ret_str = "";
		SetVariable sv = new SetVariable();
		sv.setMsisdn(interMsisdn);
		sv.setPlan(sub.getPlanIndicator());
		sv.setLang(sub.getLang());
		sv.setInterface("C");
		sv.setUpdatedBy(userId);
		sv.setSubType(sub.getSubType());
		sv.rbt_code = rbtCode;
		sv.days = day;
		sv.start_t = start_t;
		sv.end_t = end_t;
		sv.check_rbt = rbt_check;
		sv.groupName  = groupName;

		CRBTRequest crbt_req = new CRBTRequest();
		crbt_req.constructQuery(5,sv);
		logger.info("sending reqoest to rule engine");
		int ret_val = crbt_req.send();
		if (ret_val == 0)
		{
			ret_str = "SuccessFull";
		}
		else
		{
			ret_str = crbt_req.err_string;
		}

		//	insertIntoRbtOpLog(interMsisdn, rbtCode, 1, "Default", "N", 1);
		//	insertIntoSubscriberAudit(interMsisdn, 1, "Default RBT is set");
		return ret_str;// retVal;
	}//setSubscriberGroupTone

	public int setSubscriberGroupTone(String msisdn, long groupId, ArrayList toneSettingsAl, int rbtCode,Connection con) 
	{
		logger.info("setSubscriberGroupTone()");

		String changeType="RINGTONE_FOR_GROUP";
		String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(msisdn);

		try
		{
			//con = conPool.getConnection();
			con.setAutoCommit(false);

			SubscriberCallerManager scam = new SubscriberCallerManager(con);

			int ret = scam.setGroupTone(groupId, msisdn, toneSettingsAl, rbtCode);
			logger.info("reurn value from setGroupTone() is "+ret);
			if (ret != 1)
			{
				con.rollback();
				return ret;
			}

			insertIntoRbtOpLog(interMsisdn, rbtCode, 1, "Group:"+groupId, "N", 1,con);
			insertIntoSubscriberAudit(interMsisdn, 1, "Group RBT is set",con);

			con.commit();
		}
		catch (Exception e)
		{
			try {
				con.rollback();
			} catch(Exception exp) {}
			e.printStackTrace();
			return 0;
		}
		/*finally
		{
			conPool.free(con);
		}*/
		
		return 1;
	}//setSubscriberGroupTone

	public String setSubscriberFriendTone(SubscriberProfile sub, ArrayList toneSettingsAl, int rbtCode , int rbt_check,String userId,String fmsisdn) 
	{
		logger.info("setSubscriberDefaultTone()"+sub.getMsisdn());

		String interFriendMsisdn = TSSJavaUtil.instance().getInternationalNumber(fmsisdn);
		String changeType="FRIEND_RINGTONE";
		String interMsisdn = sub.getMsisdn();

		Iterator ite = toneSettingsAl.iterator();
		String day = "";
		int start_t = 0;
		int end_t = 0;
		while(ite.hasNext())
		{
			ToneSetting toneSetting = (ToneSetting)ite.next();
			day = day + toneSetting.getDay();
			start_t = toneSetting.getStartTime();
			end_t = toneSetting.getEndTime();
		}

		if ((day.compareTo("1234567") == 0))
			day = "8";

		String ret_str = "";
		SetVariable sv = new SetVariable();
		sv.setMsisdn(interMsisdn);
		sv.setPlan(sub.getPlanIndicator());
		sv.setLang(sub.getLang());
		sv.setInterface("C");
		sv.setUpdatedBy(userId);
		sv.setSubType(sub.getSubType());
		sv.rbt_code = rbtCode;
		sv.days = day;
		sv.start_t = start_t;
		sv.end_t = end_t;
		sv.check_rbt = rbt_check;
		sv.fmsisdn = interFriendMsisdn;

		CRBTRequest crbt_req = new CRBTRequest();
		crbt_req.constructQuery(4,sv);
		logger.info("sending request to rule engine");
		int ret_val = crbt_req.send();
		if (ret_val == 0)
		{
			ret_str = "SuccessFull";
		}
		else
		{
			ret_str = crbt_req.err_string;
		}

		//	insertIntoRbtOpLog(interMsisdn, rbtCode, 1, "Default", "N", 1);
		//	insertIntoSubscriberAudit(interMsisdn, 1, "Default RBT is set");
		return ret_str;// retVal;
	}//setSubscriberDefaultTone

	/*public int setSubscriberFriendTone(String msisdn, String friendMsisdn, ArrayList toneSettingsAl, int rbtCode)
	  {
	  logger.info("setSubscriberFriendTone()");

	  String changeType = "RINGTONE_FOR "+friendMsisdn;
	  String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(msisdn);
	  String interFriendMsisdn = TSSJavaUtil.instance().getInternationalNumber(friendMsisdn);

	  ArrayList frndsList = new ArrayList();
	  ArrayList nickList = new ArrayList();

	  nickList.add(new String(""));
	  frndsList.add(interFriendMsisdn);
	  this.addNewFriend(interMsisdn, frndsList, nickList);

	  try
	  {
	//data not loaded, load it

	con = conPool.getConnection();
	con.setAutoCommit(false);

	SubscriberCallerManager scam = new SubscriberCallerManager(con);

	int ret = scam.setFriendTone(interFriendMsisdn, interMsisdn, toneSettingsAl, rbtCode);
	if (ret != 1)
	{
	con.rollback();
	return ret;
	}
	//uncommented by JP
	if (updateFreeEventsUsed(interMsisdn) != 1)
	{
	con.rollback();
	return 0;
	}

	if(updateCRBTScore(rbtCode) !=1)
	{
	con.rollback();
	return 0;
	}

	//int chr = doCharging(interMsisdn, rbtCode, changeType); //JP
	int chr = doCharging(interMsisdn, rbtCode, 1);
	if (chr != 1)
	{
	con.rollback();
	return chr;
	}

	//uncommented by JP
	insertIntoRbtOpLog(interMsisdn, rbtCode, 1, interFriendMsisdn, "N", 1);
	insertIntoSubscriberAudit(interMsisdn, 1, "Friend RBT is set");

	con.commit();
	return 1;
	}
	catch (Exception e)
	{
	try {
	con.rollback();
	} catch(Exception exp) { }
	e.printStackTrace();
	return 0;
	}
	finally
	{
	conPool.free(con);
	}
	}//setSubscriberFriendTone*/
	public String setSubscriberDateTone(SubscriberProfile sub, int rbtCode , int rbt_check,String userId,String date[],String occName) 
	{
		logger.info("setSubscriberDateTone()"+sub.getMsisdn());

		String date_str = date[0]+date[1]+date[2];
		logger.info("For Occasion "+date_str);
		String ret_str = "";
		SetVariable sv = new SetVariable();
		sv.setMsisdn(sub.getMsisdn());
		sv.setPlan(sub.getPlanIndicator());
		sv.setLang(sub.getLang());
		sv.setInterface("C");
		sv.setUpdatedBy(userId);
		sv.setSubType(sub.getSubType());
		sv.rbt_code = rbtCode;
		sv.check_rbt = rbt_check;
		sv.date = date_str;
		sv.occ_name = occName;

		CRBTRequest crbt_req = new CRBTRequest();
		crbt_req.constructQuery(26,sv);
		logger.info("seding request to rule engine");
		int ret_val = crbt_req.send();
		if (ret_val == 0)
		{
			ret_str = "SuccessFull";
		}
		else
		{
			ret_str = crbt_req.err_string;
		}

		return ret_str;// retVal;
	}
	public String setSubscriberDateTone(SubscriberProfile sub, int rbtCode , int rbt_check,String userId,String date[]) 
	{
		logger.info("setSubscriberDateTone()"+sub.getMsisdn());

		String date_str = date[0]+date[1]+date[2];
		logger.info("For date "+date_str);
		String ret_str = "";
		SetVariable sv = new SetVariable();
		sv.setMsisdn(sub.getMsisdn());
		sv.setPlan(sub.getPlanIndicator());
		sv.setLang(sub.getLang());
		sv.setInterface("C");
		sv.setUpdatedBy(userId);
		sv.setSubType(sub.getSubType());
		sv.rbt_code = rbtCode;
		sv.check_rbt = rbt_check;
		sv.date = date_str;

		CRBTRequest crbt_req = new CRBTRequest();
		crbt_req.constructQuery(12,sv);
		logger.info("sending request to rule engine");
		int ret_val = crbt_req.send();
		if (ret_val == 0)
		{
			ret_str = "SuccessFull";
		}
		else
		{
			ret_str = crbt_req.err_string;
		}

		return ret_str;// retVal;
	}

	/*public int setSubscriberDateTone(String msisdn, String date[], int rbtCode)
	  {

	  logger.info("setSubscriberDateTone()");

	  String changeType="RINGTONE_FOR_DATE";
	  String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(msisdn);

	  try
	  {
	  con = conPool.getConnection();
	  con.setAutoCommit(false);

	  SubscriberCallerManager scam = new  SubscriberCallerManager(con);

	  int ret = scam.setDateTone(interMsisdn, date, rbtCode);
	  if(ret != 1)
	  {
	  con.rollback();
	  return ret;
	  }
	//////uncommented by JP
	if (updateFreeEventsUsed(interMsisdn) != 1)
	{
	con.rollback();
	return 0;
	}
	if(updateCRBTScore(rbtCode) !=1)
	{
	con.rollback();
	return 0;
	}
	//				int chr = doCharging(interMsisdn, rbtCode, changeType);//JP
	int chr = doCharging(interMsisdn, rbtCode, 1);
	if (chr != 1)
	{
	con.rollback();
	return chr;
	}
	//////uncommented by JP
	StringBuffer opFor = new StringBuffer();
	opFor.append(date[0]);
	opFor.append("-");
	opFor.append(date[1]);
	opFor.append("-");
	opFor.append(date[2]);
	insertIntoRbtOpLog(interMsisdn, rbtCode, 1, opFor.toString(), "N", 1);
	insertIntoSubscriberAudit(interMsisdn, 1, "Date RBT is set");

	con.commit();
	return 1;
	}
	catch (Exception e)
	{
	try {
	con.rollback();
	} catch(Exception exp) {}
	e.printStackTrace();
	return 0;
	}
	finally
	{
	conPool.free(con);
	}
	}//setSubscriberDateTone*/
	/*public int setSubscriberOccTone(String msisdn, String date[], int rbtCode, String occName)
	  {

	  logger.info("setSubscriberDateTone()");

	  String changeType="RINGTONE_FOR_DATE";
	  String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(msisdn);

	  try
	  {
	  con = conPool.getConnection();
	  con.setAutoCommit(false);

	  SubscriberCallerManager scam = new  SubscriberCallerManager(con);

	  int ret = scam.setOccTone(interMsisdn, date, rbtCode, occName);
	  if(ret != 1)
	  {
	  con.rollback();
	  return ret;
	  }
	//////uncommented by JP
	if (updateFreeEventsUsed(interMsisdn) != 1)
	{
	con.rollback();
	return 0;
	}
	if(updateCRBTScore(rbtCode) !=1)
	{
	con.rollback();
	return 0;
	}
	//				int chr = doCharging(interMsisdn, rbtCode, changeType);//JP
	int chr = doCharging(interMsisdn, rbtCode, 1);
	if (chr != 1)
	{
	con.rollback();
	return chr;
	}
	//////uncommented by JP
	StringBuffer opFor = new StringBuffer();
	opFor.append(date[0]);
	opFor.append("-");
	opFor.append(date[1]);
	opFor.append("-");
	opFor.append(date[2]);
	insertIntoRbtOpLog(interMsisdn, rbtCode, 1, opFor.toString(), "N", 1);
	insertIntoSubscriberAudit(interMsisdn, 1, "Occassion RBT "+occName+" is set");

	con.commit();
	return 1;
	}
	catch (Exception e)
	{
	try {
	con.rollback();
	} catch(Exception exp) {}
	e.printStackTrace();
	return 0;
	}
	finally
	{
	conPool.free(con);
	}
	}//setSubscriberOccTone*/

	public String deleteSubscriberProfile(SubscriberProfile sub, String[] delStrings,String userId)
	{
		logger.info("deleteSubscriberProfile()");

		try
		{
			String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(sub.getMsisdn());	

			//data....0 RBT, 1 Start, 2 End, 3 Grou ID, 4 Friend Msisdn

			int retVal=0;

			String ret_str = "Unknown Error Occured Please Try Later";
			for(int z=0; z<delStrings.length; z++)
			{
				CRBTRequest crbt_req = new CRBTRequest();
				SetVariable sv = new SetVariable();
				sv.setMsisdn(interMsisdn);
				sv.setPlan(sub.getPlanIndicator());
				sv.setLang(sub.getLang());
				sv.setInterface("C");
				sv.setUpdatedBy(userId);
				sv.setSubType(sub.getSubType());

				StringTokenizer st = new StringTokenizer(delStrings[z], "&");
				String data[] = new String[6];
				int count =0;
				String request_data = "";
				String request_for = "";

				while(st.hasMoreTokens())
				{
					data[count++]=st.nextToken();
				}


				logger.info(data[0]+","+data[1]+","+data[2]+","+data[3]+","+data[4]+","+data[5]);
				logger.info("DAY"+data[5]);
				if(!data[3].equals("0") && data[1].equals("3000")) //Default
				{
					sv.groupName = data[4];
					logger.info("1.1");
					crbt_req.constructQuery(18,sv);
				}

				else if(data[1].equals("3000") && data[4].equals("Default")) //Default
				{
					logger.info("1.2");
					//					String interFriendMsisdn = TSSJavaUtil.instance().getInternationalNumber(data[4]);
					//data....0 RBT, 1 Start, 2 End, 3 Grou ID, 4 Friend Msisdn
					crbt_req.constructQuery(16,sv);
				}

				else if(data[1].equals("3000")) //Default
				{
					logger.info("1.3");
					String interFriendMsisdn = TSSJavaUtil.instance().getInternationalNumber(data[4]);
					//data....0 RBT, 1 Start, 2 End, 3 Grou ID, 4 Friend Msisdn
					sv.fmsisdn = interFriendMsisdn;
					crbt_req.constructQuery(17,sv);
				}

				else if(data[3].equals("0") && data[4].equals("Default")) //Default
				{
					logger.info("1.4");
					logger.info("DAY"+data[5]);
					String day = "";
					if (data[5].length()  == 7)
					{
						day = "8";
					}
					else
					{
						for (int i = 0;i<((data[5].length())-1);i++)
						{
							day += Integer.parseInt(data[5].substring(i,i+1)) +1;
							logger.info("DAY"+day);
						}
						day += Integer.parseInt(data[5].substring((data[5].length())-1))+1; 
					}
					logger.info("DAY"+day);

					sv.rbt_code = Integer.parseInt(data[0]);
					sv.days = day;
					sv.start_t = Integer.parseInt(data[1]);
					sv.end_t =  Integer.parseInt(data[2]);
					crbt_req.constructQuery(13,sv);
				}

				else if(data[3].equals("0") && data[4].equals("Date"))
				{
					logger.info("1.5");
					String date1=data[1].substring(0,10);
					String day=date1.substring(0,2);
					String mon=date1.substring(3,5);
					String yyy=date1.substring(6,10);
					date1=day+""+mon+""+yyy;

					logger.info("date  "+date1);
					sv.rbt_code=Integer.parseInt(data[0]);
					sv.date=date1;
					crbt_req.constructQuery(25,sv);

					/*			retVal = scam.deleteSubscriberDateSetting(interMsisdn, data[1],  Integer.parseInt(data[0]));
								if(retVal != 1) 
								{
								con.rollback();
								return retVal;
								}
					// *************************** Insert details in Web Stats ************************
					request_data = "Setting for date "+data[1]+" is deleted";
					request_for = data[1]; */
				}
				else if(data[3].equals("0") && data[4].equals("Occassion"))
				{
					logger.info("1.6");
					String date1=data[1].substring(0,10);
					String day=date1.substring(0,2);
					String mon=date1.substring(3,5);
					String yyy=date1.substring(6,10);
					date1=day+""+mon+""+yyy;

					logger.info("date  "+date1);
					sv.rbt_code=Integer.parseInt(data[0]);
					sv.date=date1;
					crbt_req.constructQuery(25,sv);

					/*				retVal = scam.deleteSubscriberDateSetting(interMsisdn, data[1].substring(0,10),  Integer.parseInt(data[0]));
									if(retVal != 1) 
									{
									con.rollback();
									return retVal;
									}
					// *************************** Insert details in Web Stats ************************
					request_data = "Setting for Occassion "+data[1].substring(10)+" is deleted";
					request_for = data[1].substring(10); */
				}

				else if(data[3].equals("0")) //Friends
				{
					logger.info("1.7");
					//data....0 RBT, 1 Start, 2 End, 3 Grou ID, 4 Friend Msisdn
					String interFriendMsisdn = TSSJavaUtil.instance().getInternationalNumber(data[4]);
					String day = "";
					if (data[5].length()  == 7)
						day = "8";
					else
					{
						for (int i = 0;i<((data[5].length())-1);i++)
						{
							day += Integer.parseInt(data[5].substring(i,i+1)) +1;
						}
						day += Integer.parseInt(data[5].substring((data[5].length())-1))+1; 
					}
					sv.rbt_code = Integer.parseInt(data[0]);
					sv.days = day;
					sv.start_t = Integer.parseInt(data[1]);
					sv.end_t =  Integer.parseInt(data[2]);
					sv.fmsisdn = interFriendMsisdn;
					crbt_req.constructQuery(14,sv);
				}

				else //Group
				{
					logger.info("1.8");
					String day = "";
					if (data[5].length()  == 7)
						day = "8";
					else
					{
						for (int i = 0;i<((data[5].length())-1);i++)
						{
							day += Integer.parseInt(data[5].substring(i,i+1)) +1;
						}
						day += Integer.parseInt(data[5].substring((data[5].length())-1))+1; 
					}

					sv.rbt_code = Integer.parseInt(data[0]);
					sv.days = day;
					sv.start_t = Integer.parseInt(data[1]);
					sv.end_t =  Integer.parseInt(data[2]);
					sv.groupName = data[4];
					crbt_req.constructQuery(15,sv);
				}
				logger.info("sending request to rule engine");
				int ret_val = crbt_req.send();
				if (ret_val == 0)
				{
					ret_str = "SuccessFull";
				}
				else
				{
					ret_str = crbt_req.err_string;
				}

			}
			return ret_str;		
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return "Please Try Later";
		}
		finally
		{
		}
	}//

	public String updateSubscriberProfile(String msisdn, ArrayList toneSettingsAl, int startTime, int endTime, int rbtCode,int groupId, String groupName, String friendsMsisdn,SubscriberProfile sub,String userId,Connection con)
	{
		logger.info("updateSubscriberProfile()"+msisdn);

		String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(msisdn);
		String ret_str = "Unknown error occured please try later";

		try
		{
		
			SubscriberCallerManager	scam = new SubscriberCallerManager(con);
			logger.info("groupId is "+groupId);
			if ((groupId == 0) && friendsMsisdn.equals("Default"))
			{
				int ret = scam.updateDefaultTone(interMsisdn, toneSettingsAl, startTime, endTime, rbtCode);
				if (ret != 1)
				{
					return ret_str;
				}

				ret_str = setSubscriberDefaultTone(sub,toneSettingsAl,rbtCode,0,userId);
			}

			else if (groupId == 0)
			{
				String interFriendMsisdn = TSSJavaUtil.instance().getInternationalNumber(friendsMsisdn);
				int ret = scam.updateFriendTone(interMsisdn, interFriendMsisdn, toneSettingsAl, startTime, endTime, rbtCode);
				if (ret != 1)
				{
					return ret_str;
				}
				ret_str = setSubscriberFriendTone(sub,toneSettingsAl,rbtCode,0,userId,interFriendMsisdn);
			}

			else
			{
				int ret = scam.updateGroupTone(interMsisdn, groupId, toneSettingsAl, startTime, endTime, rbtCode);
				if (ret != 1)
				{
					return ret_str;
				}
				ret_str = setSubscriberGroupTone(sub,toneSettingsAl,rbtCode,0,userId,groupName);
			}
			con.commit();
		}
		catch (Exception e)
		{
			try {
				con.rollback();
			} catch(Exception exp) {}
			e.printStackTrace();
			return ret_str;
		}
		/*
		finally
		{
			conPool.free(con);
		}*/
		return ret_str;
	}//updateSubscriberProfile

	public int setSubscriberDefaultTone(String msisdn, ArrayList toneSettingsAl, int rbtCode,Connection con) 
	{
		logger.info("setSubscriberDefaultTone()"+msisdn);

		String changeType="DEFAULT_RINGTONE";
		String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(msisdn);

		try
		{
			//con = conPool.getConnection();
			con.setAutoCommit(false);

			SubscriberCallerManager scam = new SubscriberCallerManager(con);

			int ret = scam.setDefaultTone(interMsisdn, toneSettingsAl, rbtCode);
			logger.info("return value from setDefaultTone is  "+ret);
			if (ret != 1)
			{
				con.rollback();
				return ret;
			}

			insertIntoRbtOpLog(interMsisdn, rbtCode, 1, "Default", "N", 1,con);
			insertIntoSubscriberAudit(interMsisdn, 1, "Default RBT is set",con);

			con.commit();
			return 1;
		}
		catch (Exception e)
		{
			try {
				con.rollback();
			} catch(Exception exp) {}
			e.printStackTrace();
			return 0;
		}
		
		/*finally
		{
			conPool.free(con);
		}*/
		
	}//setSubscriberDefaultTone

	//public int setSubscriberGroupTone(String msisdn, long groupId, ArrayList toneSettingsAl, int rbtCode)
	//setSubscriberGroupTone

	public int setSubscriberFriendTone(String msisdn, String friendMsisdn, ArrayList toneSettingsAl, int rbtCode,Connection con) 
	{
		logger.info("setSubscriberFriendTone()");

		String changeType = "RINGTONE_FOR "+friendMsisdn;
		String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(msisdn);
		String interFriendMsisdn = TSSJavaUtil.instance().getInternationalNumber(friendMsisdn);

		ArrayList frndsList = new ArrayList();
		ArrayList nickList = new ArrayList();

		nickList.add(new String(""));
		frndsList.add(interFriendMsisdn);
		this.addNewFriend(interMsisdn, frndsList, nickList,con);

		try
		{
			//data not loaded, load it

			//con = conPool.getConnection();
			con.setAutoCommit(false);

			SubscriberCallerManager scam = new SubscriberCallerManager(con);

			int ret = scam.setFriendTone(interFriendMsisdn, interMsisdn, toneSettingsAl, rbtCode);
			if (ret != 1)
			{
				con.rollback();
				return ret;
			}
			//uncommented by JP
			/*			if (updateFreeEventsUsed(interMsisdn) != 1)
						{
						con.rollback();
						return 0;
						}
			 */
			if(updateCRBTScore(rbtCode) !=1)
			{
				con.rollback();
				return 0;
			}

			//int chr = doCharging(interMsisdn, rbtCode, changeType); //JP
			//						int chr = doCharging(interMsisdn, rbtCode, 1);

			/*
			   int planIndicator = Integer.parseInt(TSSJavaUtil.instance().getAppConfigParam("DEFAULT_RATE_PLAN"));
			   query = "select FREE_RINGTONES, RBT_CHARGE_CODE from CRBT_RATE_PLANS where PLAN_INDICATOR = ?";
			   pstmt = con.prepareStatement(query);
			   pstmt.setInt(1, planIndicator);
			//logger.info(query);

			rs = pstmt.executeQuery();
			int rbt_charge_code=0;
			int freeEvents=0;
			if(rs.next())
			{
			freeEvents=rs.getInt("FREE_RINGTONES");
			rbt_charge_code=Integer.parseInt(rs.getString("RBT_CHARGE_CODE"));
			logger.info("RBT_CHARGE_CODE= "+rbt_charge_code);
			}

			if(rs != null) rs.close();
			pstmt.close();

			TCPPacketCharging tcpCharge = new TCPPacketCharging();
			int chr = tcpCharge.doEventBasedCharging(interMsisdn, rbt_charge_code, rbtCode,"-1",3, interfaceType); //action=1 for SUB // interfacetype='C' for custcare
			logger.info("setSubscriberFriendTone: chr="+chr);				if (chr != 1)
			{
			con.rollback();
			return chr;
			}
			 */
			//uncommented by JP
			insertIntoRbtOpLog(interMsisdn, rbtCode, 1, interFriendMsisdn, "N", 1,con);
			insertIntoSubscriberAudit(interMsisdn, 1, "Friend RBT is set",con);

			con.commit();
			return 1;
		}
		catch (Exception e)
		{
			try {
				con.rollback();
			} catch(Exception exp) { }
			e.printStackTrace();
			return 0;
		}
		/*finally
		{
			conPool.free(con);
		}*/
	}//setSubscriberFriendTone

	public int setSubscriberDateTone(String msisdn, String date[], int rbtCode,Connection con) 
	{

		logger.info("setSubscriberDateTone()");

		String changeType="RINGTONE_FOR_DATE";
		String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(msisdn);

		try
		{
			//con = conPool.getConnection();
			con.setAutoCommit(false);

			SubscriberCallerManager scam = new  SubscriberCallerManager(con);

			int ret = scam.setDateTone(interMsisdn, date, rbtCode);
			if(ret != 1)
			{
				con.rollback();
				return ret;
			}
			//////uncommented by JP
			/*
			   if (updateFreeEventsUsed(interMsisdn) != 1)
			   {
			   con.rollback();
			   return 0;
			   }*/
			if(updateCRBTScore(rbtCode) !=1)
			{
				con.rollback();
				return 0;
			}
			//				int chr = doCharging(interMsisdn, rbtCode, changeType);//JP
			//	int chr = doCharging(interMsisdn, rbtCode, 1);
			/*
			   int planIndicator = Integer.parseInt(TSSJavaUtil.instance().getAppConfigParam("DEFAULT_RATE_PLAN"));
			   query = "select FREE_RINGTONES, RBT_CHARGE_CODE from CRBT_RATE_PLANS where PLAN_INDICATOR = ?";
			   pstmt = con.prepareStatement(query);
			   pstmt.setInt(1, planIndicator);
			//logger.info(query);

			rs = pstmt.executeQuery();
			int rbt_charge_code=0;
			int freeEvents=0;
			if(rs.next())
			{
			freeEvents=rs.getInt("FREE_RINGTONES");
			rbt_charge_code=Integer.parseInt(rs.getString("RBT_CHARGE_CODE"));
			logger.info("RBT_CHARGE_CODE= "+rbt_charge_code);
			}

			if(rs != null) rs.close();
			pstmt.close();

			TCPPacketCharging tcpCharge = new TCPPacketCharging();
			int chr = tcpCharge.doEventBasedCharging(interMsisdn, rbt_charge_code, rbtCode,"-1",3, interfaceType); //action=1 for SUB // interfacetype='C' for custcare
			logger.info("setSubscriberDateTone: chr="+chr);
			if (chr != 1)
			{
			con.rollback();
			return chr;
			}
			 */
			//////uncommented by JP
			StringBuffer opFor = new StringBuffer();
			opFor.append(date[0]);
			opFor.append("-");
			opFor.append(date[1]);
			opFor.append("-");
			opFor.append(date[2]);
			insertIntoRbtOpLog(interMsisdn, rbtCode, 1, opFor.toString(), "N", 1,con);
			insertIntoSubscriberAudit(interMsisdn, 1, "Date RBT is set",con);

			con.commit();
			return 1;
		}
		catch (Exception e)
		{
			try {
				con.rollback();
			} catch(Exception exp) {}
			e.printStackTrace();
			return 0;
		}
		
	/*	finally
		{
			conPool.free(con);
		}
		*/
	}//setSubscriberDateTone
	public int setSubscriberOccTone(String msisdn, String date[], int rbtCode, String occName,Connection con) 
	{

		logger.info("setSubscriberDateTone()");

		String changeType="RINGTONE_FOR_DATE";
		String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(msisdn);

		try
		{
			//con = conPool.getConnection();
			con.setAutoCommit(false);

			SubscriberCallerManager scam = new  SubscriberCallerManager(con);

			int ret = scam.setOccTone(interMsisdn, date, rbtCode, occName);
			if(ret != 1)
			{
				con.rollback();
				return ret;
			}
			//////uncommented by JP
			/*			if (updateFreeEventsUsed(interMsisdn) != 1)
						{
						con.rollback();
						return 0;
						}
			 */
			if(updateCRBTScore(rbtCode) !=1)
			{
				con.rollback();
				return 0;
			}
			//				int chr = doCharging(interMsisdn, rbtCode, changeType);//JP
			//	int chr = doCharging(interMsisdn, rbtCode, 1);
			/*
			   int planIndicator = Integer.parseInt(TSSJavaUtil.instance().getAppConfigParam("DEFAULT_RATE_PLAN"));
			   query = "select FREE_RINGTONES, RBT_CHARGE_CODE from CRBT_RATE_PLANS where PLAN_INDICATOR = ?";
			   pstmt = con.prepareStatement(query);
			   pstmt.setInt(1, planIndicator);
			//logger.info(query);

			rs = pstmt.executeQuery();
			int rbt_charge_code=0;
			int freeEvents=0;
			if(rs.next())
			{
			freeEvents=rs.getInt("FREE_RINGTONES");
			rbt_charge_code=Integer.parseInt(rs.getString("RBT_CHARGE_CODE"));
			logger.info("RBT_CHARGE_CODE= "+rbt_charge_code);
			}

			if(rs != null) rs.close();
			pstmt.close();

			TCPPacketCharging tcpCharge = new TCPPacketCharging();
			int chr = tcpCharge.doEventBasedCharging(interMsisdn, rbt_charge_code, rbtCode,"-1",3, interfaceType); //action=1 for SUB // interfacetype='C' for custcare
			logger.info("setAdvanceTone: chr="+chr);
			if (chr != 1)
			{
			con.rollback();
			return chr;
			}
			 */
			//////uncommented by JP
			StringBuffer opFor = new StringBuffer();
			opFor.append(date[0]);
			opFor.append("-");
			opFor.append(date[1]);
			opFor.append("-");
			opFor.append(date[2]);
			insertIntoRbtOpLog(interMsisdn, rbtCode, 1, opFor.toString(), "N", 1,con);
			insertIntoSubscriberAudit(interMsisdn, 1, "Occassion RBT "+occName+" is set",con);

			con.commit();
			return 1;
		}
		catch (Exception e)
		{
			try {
				con.rollback();
			} catch(Exception exp) {}
			e.printStackTrace();
			return 0;
		}
		
	/*	finally
		{
			conPool.free(con);
		}*/
	}//setSubscriberOccTone

	public int deleteSubscriberProfile(String msisdn, String[] delStrings,Connection con)
	{
		logger.info("deleteSubscriberProfile()");

		try
		{
			//con = conPool.getConnection();
			con.setAutoCommit(false);

			String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(msisdn);	

			SubscriberCallerManager	scam = new SubscriberCallerManager(con);

			//data....0 RBT, 1 Start, 2 End, 3 Grou ID, 4 Friend Msisdn

			int retVal=0;

			for(int z=0; z<delStrings.length; z++)
			{
				StringTokenizer st = new StringTokenizer(delStrings[z], "&");
				String data[] = new String[6];
				int count =0;
				String request_data = "";
				String request_for = "";

				while(st.hasMoreTokens())
				{
					data[count++]=st.nextToken();
				}

				if(!data[3].equals("0") && data[1].equals("3000")) //Default
				{
					//					String interFriendMsisdn = TSSJavaUtil.instance().getInternationalNumber(data[4]);
					//data....0 RBT, 1 Start, 2 End, 3 Grou ID, 4 Friend Msisdn
					retVal = scam.removeGroupAdvancedTone(Long.parseLong(data[3]));
					if(retVal != 1) 
					{
						con.rollback();
						return retVal;
					}
					// *************************** Insert details in Web Stats ************************
					request_data = "An advanced Profile is deleted"; 
					request_for = data[3]; 
				}

				else if(data[1].equals("3000") && data[4].equals("Default")) //Default
				{
					String interFriendMsisdn = TSSJavaUtil.instance().getInternationalNumber(data[4]);
					//data....0 RBT, 1 Start, 2 End, 3 Grou ID, 4 Friend Msisdn
					retVal = scam.removeAdvancedTone(interMsisdn);
					if(retVal != 1) 
					{
						con.rollback();
						return retVal;
					}
					// *************************** Insert details in Web Stats ************************
					request_data = "An advanced Profile is deleted"; 
					request_for = "Default"; 
				}

				else if(data[1].equals("3000")) //Default
				{
					String interFriendMsisdn = TSSJavaUtil.instance().getInternationalNumber(data[4]);
					//data....0 RBT, 1 Start, 2 End, 3 Grou ID, 4 Friend Msisdn
					retVal = scam.removeFriendAdvancedTone(interMsisdn, interFriendMsisdn);
					if(retVal != 1) 
					{
						con.rollback();
						return retVal;
					}
					// *************************** Insert details in Web Stats ************************
					request_data = "An advanced Profile is deleted"; 
					request_for = interFriendMsisdn; 
				}

				else if(data[3].equals("0") && data[4].equals("Default")) //Default
				{
					//data....0 RBT, 1 Start, 2 End, 3 Grou ID, 4 Friend Msisdn
					retVal = scam.deleteSubscriberDefaultSetting(interMsisdn, Integer.parseInt(data[1]), Integer.parseInt(data[2]), Integer.parseInt(data[0]));
					if(retVal != 1) 
					{
						con.rollback();
						return retVal;
					}
					// *************************** Insert details in Web Stats ************************
					request_data = "A Default Profile is deleted"; 
					request_for = "Default"; 
				}

				else if(data[3].equals("0") && data[4].equals("Date"))
				{
					retVal = scam.deleteSubscriberDateSetting(interMsisdn, data[1],  Integer.parseInt(data[0]));
					if(retVal != 1) 
					{
						con.rollback();
						return retVal;
					}
					// *************************** Insert details in Web Stats ************************
					request_data = "Setting for date "+data[1]+" is deleted";
					request_for = data[1]; 
				}
				else if(data[3].equals("0") && data[4].equals("Occassion"))
				{
					retVal = scam.deleteSubscriberDateSetting(interMsisdn, data[1].substring(0,10),  Integer.parseInt(data[0]));
					if(retVal != 1) 
					{
						con.rollback();
						return retVal;
					}
					// *************************** Insert details in Web Stats ************************
					request_data = "Setting for Occassion "+data[1].substring(10)+" is deleted";
					request_for = data[1].substring(10); 
				}

				else if(data[3].equals("0")) //Friends
				{
					//data....0 RBT, 1 Start, 2 End, 3 Grou ID, 4 Friend Msisdn
					String interFriendMsisdn = TSSJavaUtil.instance().getInternationalNumber(data[4]);

					retVal = scam.deleteSubscriberFriendSetting(interMsisdn, Integer.parseInt(data[1]), Integer.parseInt(data[2]), interFriendMsisdn, Integer.parseInt(data[0]));
					if(retVal != 1) 
					{
						con.rollback();
						return retVal;
					}
					// *************************** Insert details in Web Stats ************************
					request_data = "Setting of friend "+interFriendMsisdn+" is deleted"; 
					request_for = interFriendMsisdn; 
				}

				else //Group
				{
					//data....0 RBT, 1 Start, 2 End, 3 Grou ID, 4 Friend Msisdn
					retVal = scam.deleteSubscriberGroupSetting(interMsisdn, Long.parseLong(data[3]), Integer.parseInt(data[1]), Integer.parseInt(data[2]),Integer.parseInt(data[0]));
					if(retVal != 1) 
					{
						con.rollback();
						return retVal;
					}
					// *************************** Insert details in Web Stats ************************
					request_data = "Settings Group "+data[0]+" is deleted"; 
					request_for = data[3]; 
				}

				insertIntoRbtOpLog(interMsisdn, Integer.parseInt(data[0]), 5, request_for, "N", 1,con);
				insertIntoSubscriberAudit(interMsisdn, 1, request_data,con);
			}
			con.commit();
			return 1;		
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
		/*
		finally
		{
			conPool.free(con);
		}*/
		
	}//deleteSubscriberProfile

	public int updateSubscriberProfile(String msisdn, ArrayList toneSettingsAl, int startTime, int endTime, int rbtCode, long groupId, String friendsMsisdn,Connection con)
	{
		logger.info("updateSubscriberProfile()"+msisdn);

		String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(msisdn);

		try
		{
			//con = conPool.getConnection();
			con.setAutoCommit(false);

			SubscriberCallerManager	scam = new SubscriberCallerManager(con);
			String changeType = "";
			String request_data = "";
			String request_for = "";

			if ((groupId == 0) && friendsMsisdn.equals("Default"))
			{
				int ret = scam.updateDefaultTone(interMsisdn, toneSettingsAl, startTime, endTime, rbtCode);
				if (ret != 1)
				{
					con.rollback();
					return ret;
				}

				changeType="DEFAULT_RINGTONE";
				request_data = "Updated a default RBT";
				request_for = "Default";
			}

			else if (groupId == 0)
			{
				String interFriendMsisdn = TSSJavaUtil.instance().getInternationalNumber(friendsMsisdn);

				int ret = scam.updateFriendTone(interMsisdn, interFriendMsisdn, toneSettingsAl, startTime, endTime, rbtCode);
				if (ret != 1)
				{
					con.rollback();
					return ret;
				}

				changeType= "RINGTONE for"+interFriendMsisdn;
				request_data = "Updated RBT for"+interFriendMsisdn;
				request_for = interFriendMsisdn;
			}

			else
			{
				int ret = scam.updateGroupTone(interMsisdn, groupId, toneSettingsAl, startTime, endTime, rbtCode);
				if (ret != 1)
				{
					con.rollback();
					return ret;
				}

				changeType= "RINGTONE for Group"+groupId;
				request_data = "Updated RBT for group"+groupId;
				request_for = groupId+"";
			}
			//uncommented by JP	
			/*
			   if (updateFreeEventsUsed(interMsisdn) != 1)
			   {
			   con.rollback();
			   return 0;
			   }
			 */
			if(updateCRBTScore(rbtCode) !=1)
			{
				con.rollback();
				return 0;
			}

			//JP int chr = doCharging(interMsisdn, rbtCode, changeType); //JP
			//						int chr = doCharging(interMsisdn, rbtCode, 1);
			/*   int planIndicator = Integer.parseInt(TSSJavaUtil.instance().getAppConfigParam("DEFAULT_RATE_PLAN"));
			     query = "select FREE_RINGTONES, RBT_CHARGE_CODE from CRBT_RATE_PLANS where PLAN_INDICATOR = ?";
			     pstmt = con.prepareStatement(query);
			     pstmt.setInt(1, planIndicator);
			//logger.info(query);

			rs = pstmt.executeQuery();
			int rbt_charge_code=0;
			int freeEvents=0;
			if(rs.next())
			{
			freeEvents=rs.getInt("FREE_RINGTONES");
			rbt_charge_code=Integer.parseInt(rs.getString("RBT_CHARGE_CODE"));
			logger.info("RBT_CHARGE_CODE= "+rbt_charge_code);
			}

			if(rs != null) rs.close();
			pstmt.close();

			TCPPacketCharging tcpCharge = new TCPPacketCharging();
			int chr = tcpCharge.doEventBasedCharging(interMsisdn, rbt_charge_code, rbtCode,"-1",3, interfaceType); //action=1 for SUB // interfacetype='C' for custcare
			logger.info("setAdvanceTone: chr="+chr);
			if (chr != 1)
			{
			con.rollback();
			return chr;
			}*/
			//////uncommented by JP

			insertIntoRbtOpLog(interMsisdn, rbtCode, 6, request_for, "N", 1,con);
			insertIntoSubscriberAudit(interMsisdn, 1, request_data,con);

			con.commit();
		}
		catch (Exception e)
		{
			try {
				con.rollback();
			} catch(Exception exp) {}
			e.printStackTrace();
			return 0;
		}
		
		/*finally
		{
			conPool.free(con);
		}*/
		return 1;
	}//updateSubscriberProfile

	private int prepaidCharging(String interMsisdn, int chargeCode)
	{
		logger.info("prepaidCharging(interMsisdn,chargeCode),"+interMsisdn+" "+chargeCode);
		int ret = TSSJavaUtil.instance().isChargingEnabled();
		logger.info(ret);
		if (ret == 1) 
		{
			StringBuffer stat = new StringBuffer();
			SSFClient ssfClient = new SSFClient();

			int announcementID = SSFClient.doEventBasedCharging(chargeCode, interMsisdn, stat);
			if (announcementID < 0)
			{
				logger.info("SSF Error");
				return 0;
			}
			logger.info("AnnouncementID : " + announcementID);
			logger.info("Status ID : " + stat);

			if(stat.toString().equalsIgnoreCase("true"))
			{
				if(announcementID == 502)//recharge reminder
				{
					return 502;
				}
				else if(announcementID == 510)
				{
					return 510;
				}
				return 1;
			}
			else if (stat.toString().equalsIgnoreCase("false"))
			{
				switch(announcementID)
				{
					case 501:
					case 503:
					case 507:
						return -2;
					default:
						return -2;
				}
			}
			else
			{
				logger.info("Unexpexted results from SSF ");
				return 0;
			}
		}
		else 
		{
			logger.info("Charging Disabled");
			return 1;
		} 
	} //prepaidCharging 

	private int prepaidCharging(String interMsisdn, int planId, int rbtCode, int charge)
	{
		if (con == null)
		{
			logger.info("CON NULL");
			return 0;	
		}

		try
		{
			query = "";
			if (charge == 1)
			{
				query = "insert into CRBT_PREPAID_SETTING_CDR (PRE_SECDR_ID, MSISDN, INTERFACE_USED, UPDATE_TIME, STATUS, PLAN_INDICATOR, RBT_CODE) values (PRE_SECDR_ID.nextval, ?, ?, sysdate, ?, ?, ?)"; 
			}
			else
			{
				query = "insert into CRBT_PREPAID_GIFTING_CDR (PRE_GICDR_ID, MSISDN, INTERFACE_USED, UPDATE_TIME, STATUS, PLAN_INDICATOR, RBT_CODE) values (PRE_GICDR_ID.nextval, ?, ?, sysdate, ?, ?, ?)"; 
			}
			pstmt = con.prepareStatement(query);

			pstmt.setString(1, interMsisdn);
			pstmt.setString(2, "C");
			pstmt.setString(3, "N");
			pstmt.setInt(4, planId);
			pstmt.setInt(5, rbtCode);
			pstmt.executeUpdate();
			pstmt.close();	
			return 1; //Success inserted in CDR 
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
	}//prepaidCharging  

	private int postpaidCharging(String interMsisdn, int planId, int rbtCode, int charge)
	{
		logger.info("postpaidCharging()");

		if (con == null)
		{
			logger.info("CON NULL");
			return 0;	
		}

		try
		{
			query = "";
			if (charge == 1)
			{
				query = "insert into CRBT_SETTING_CDR (SECDR_ID, MSISDN, INTERFACE_USED, UPDATE_TIME, STATUS, PLAN_INDICATOR, RBT_CODE) values (SECDR_ID.nextval, ?, ?, sysdate, ?, ?, ?)"; 
			}
			else
			{
				query = "insert into CRBT_GIFTING_CDR (GICDR_ID, MSISDN, INTERFACE_USED, UPDATE_TIME, STATUS, PLAN_INDICATOR, RBT_CODE) values (GICDR_ID.nextval, ?, ?, sysdate, ?, ?, ?)"; 
			}
			pstmt = con.prepareStatement(query);

			pstmt.setString(1, interMsisdn);
			pstmt.setString(2, "C");
			pstmt.setString(3, "N");
			pstmt.setInt(4, planId);
			pstmt.setInt(5, rbtCode);
			pstmt.executeUpdate();
			pstmt.close();	
			return 1; //Success inserted in CDR 
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
	} //postpaidCharging

	private int insertIntoSubscriberAudit(String interMsisdn, int actType, String strActDetail,Connection con)
	{
		logger.info("insertIntoSubscriberAudit()");

		pstmt = null;
		try
		{
			String sub_type = subscriberProfile;
			/*		String subscriber_type = "P";
					query ="Select msisdn from postpaid_subscribers where msisdn='"+interMsisdn+"'";
					rs = stmt.executeQuery(query);
					if(rs.next())
					{
					subscriber_type="O";
					rs.close();                  
					}*/

			query = "insert into CRBT_WEB_DETAIL_LOG (MSISDN, START_TIME, REQUEST_TYPE, REQUEST_DATA, SUBSCRIBER_TYPE, REQUEST_FROM, UPDATED_BY) values(?,sysdate,?,?,?,?,?)";

			pstmt = con.prepareStatement(query);
			pstmt.setString(1, interMsisdn);
			pstmt.setInt(2, actType);
			pstmt.setString(3, strActDetail);
			pstmt.setString(4, sub_type);
			pstmt.setString(5, "C");
			pstmt.setString(6, user);
			pstmt.executeUpdate();
			pstmt.close();
			return 1; //Success inserted in CCAudit 
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
	}//insertIntoSubscriberAudit

	public int updateFreeEventsUsed(String interMsisdn)
	{
		if (con == null)
		{
			logger.info("CON NULL");
			return 0;
		}

		try
		{
			pstmt = null;

			query="update CRBT_SUBSCRIBER_MASTER set FREE_EVENTS_USED = FREE_EVENTS_USED+1 where MSISDN = ?";
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, interMsisdn);
			pstmt.executeUpdate();
			pstmt.close();
			//	return 1;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
		return 1;
	}

	public int updateCRBTScore(int rbtCode)
	{
		if (con == null)
		{
			logger.info("CON NULL");
			return 0;
		}
		try
		{	
			pstmt = null;

			query= "update CRBT_RBT set RBT_SCORE = RBT_SCORE+1 where RBT_CODE = ?";
			pstmt = con.prepareStatement(query);
			pstmt.setInt(1, rbtCode);
			pstmt.executeUpdate();
			pstmt.close();
			//		return 1;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
		return 1;
	}	

	// ****************************** Charging *********************************************
	private int doCharging(String interMsisdn, int rbtCode, int charge)
	{
		logger.info("doCharging(), for "+interMsisdn);
		if (con == null)
		{
			logger.info("CON NULL");
			return 0;
		}

		pstmt = null;
		rs = null;
		query = null;

		int charge_code=0;	
		int planIndicator=0;

		try
		{
			query = "select PLAN_INDICATOR from CRBT_SUBSCRIBER_MASTER where MSISDN = ?";
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, interMsisdn);

			rs = pstmt.executeQuery();

			if(rs.next())
			{	
				planIndicator=rs.getInt("PLAN_INDICATOR");
			}

			if (charge == 1)
			{
				query = "select RBT_CHARGE_CODE from CRBT_RATE_PLANS where PLAN_INDICATOR = ?";
			}
			else
			{
				query = "select GIFT_CHARGE_CODE from CRBT_RATE_PLANS where PLAN_INDICATOR = ?";
			}

			pstmt = con.prepareStatement(query);
			pstmt.setInt(1, planIndicator);

			rs = pstmt.executeQuery();

			if(rs.next())
			{
				charge_code=Integer.parseInt(rs.getString(1));
			}

			if(rs != null) rs.close();
			pstmt.close();

			if (subscriberProfile.equalsIgnoreCase("P"))
			{
				int retVal = prepaidCharging(interMsisdn, charge_code);
				//		int retVal = prepaidCharging(interMsisdn, planIndicator, rbtCode, charge);
				if (retVal == 1 || retVal == 502 || retVal == 510)
				{
					logger.info("Done Prepaid Cahrging");
					return 1;
				}
				else 
				{
					logger.info("Error In Prepaid Cahrging");
					return retVal;
				}
			}
			else
			{
				if (postpaidCharging(interMsisdn, planIndicator, rbtCode, charge) != 1)
				{
					logger.info("Error In Postpaid Cahrging");
					return 0;
				}
				return 1;
			}
		}
		catch(Exception exp)
		{
			exp.printStackTrace();
			return 0;
		}	
	}

	public int setAdvancedTone(String msisdn, String control_name, int catId, String friendMsisdn, long groupId,Connection con)
	{
		logger.info("setAdvancedTone()"+msisdn+" control_name="+control_name);
		String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(msisdn);

		try
		{
			String request_data = "";
			String opFor = "";
			int ret = -1;
			if (groupId != 0)
			{
				logger.info(">>>>>>groupID!=0");
				//con = conPool.getConnection();
				con.setAutoCommit(false);
				SubscriberCallerManager	scam = new SubscriberCallerManager(con);
				ret = scam.setGroupAdvanceTone(interMsisdn, control_name, catId, groupId);
				request_data = "Set Advance rbt for group";
				opFor = ""+groupId;
			}
			else if (friendMsisdn.equalsIgnoreCase("Default"))
			{ 
				logger.debug(">>>>>>1");
				//con = conPool.getConnection();
				con.setAutoCommit(false);
				SubscriberCallerManager	scam = new SubscriberCallerManager(con);
				ret = scam.setAdvanceTone(interMsisdn, control_name, catId);
				request_data = "Set Advance rbt for Default";
				opFor = "Default";				
			}
			else 
			{
				logger.debug(">>>>>>2");
				String interFriendMsisdn = TSSJavaUtil.instance().getInternationalNumber(friendMsisdn);
				logger.info("friendMsisdn="+interFriendMsisdn);

				ArrayList frndsList = new ArrayList();
				ArrayList nickList = new ArrayList();

				nickList.add(new String(""));
				frndsList.add(interFriendMsisdn);
				this.addNewFriend(interMsisdn, frndsList, nickList,con);

				//con = conPool.getConnection();
				con.setAutoCommit(false);
				SubscriberCallerManager	scam = new SubscriberCallerManager(con);
				ret = scam.setFriendAdvanceTone(interMsisdn, control_name, catId, interFriendMsisdn);
				request_data = "Set Advance rbt for friend";
				opFor = interFriendMsisdn;
			}
			if (ret < 1)
			{
				con.rollback();
				return ret;
			}

			//			int chr = doCharging(interMsisdn, ret, 1);
			/*
			   int planIndicator = Integer.parseInt(TSSJavaUtil.instance().getAppConfigParam("DEFAULT_RATE_PLAN")); 
			   query = "select FREE_RINGTONES, RBT_CHARGE_CODE from CRBT_RATE_PLANS where PLAN_INDICATOR = ?";
			   pstmt = con.prepareStatement(query);
			   pstmt.setInt(1, planIndicator);
			//logger.info(query);

			rs = pstmt.executeQuery();
			int rbt_charge_code=0;
			int freeEvents=0;
			if(rs.next())
			{
			freeEvents=rs.getInt("FREE_RINGTONES");
			rbt_charge_code=Integer.parseInt(rs.getString("RBT_CHARGE_CODE"));
			logger.info("RBT_CHARGE_CODE= "+rbt_charge_code);
			}

			if(rs != null) rs.close();
			pstmt.close();

			TCPPacketCharging tcpCharge = new TCPPacketCharging();
			int chr = tcpCharge.doEventBasedCharging(interMsisdn, rbt_charge_code, ret,"-1",3, interfaceType); //action=1 for SUB // interfacetype='C' for custcare
			logger.info("setAdvanceTone: chr="+chr);

			if (chr != 1)
			{
			con.rollback();
			return chr;
			}
			 */
			insertIntoRbtOpLog(interMsisdn, ret, 1, opFor, "N", 1,con);
			insertIntoSubscriberAudit(interMsisdn, 1, request_data,con);

			con.commit();
		}
		catch (Exception e)
		{
			try {
				con.rollback();
			} catch(Exception exp) {}
			e.printStackTrace();
			return 0;
		}
		/*finally
		
		{
			conPool.free(con);
		}
		*/
		return 1;
	}//setAdvancedTone
	public int getSpecialCat(String catName)
	{

		logger.info("setSpecialCat() control_name="+catName);
		int catId = 0;
		rs=null;
		pstmt=null;
		try
		{
			con = conPool.getConnection();
			query = "select CAT_ID from CRBT_RBT_CONTROL where CONTROL_NAME=?";
			pstmt = con.prepareStatement(query);

			pstmt.setString(1, catName);

			rs = pstmt.executeQuery();

			if (rs.next())
			{
				catId = rs.getInt("CAT_ID");
			}
			else
			{
				catId=-1;
			}
			rs.close();
			pstmt.close();
		}
		catch (Exception e)
		{
			try {
				rs.close();
				pstmt.close();
			} catch(Exception exp) {}
			e.printStackTrace();
			return 0;
		}
		finally
		{
			conPool.free(con);
		}
		return catId;

	}//getSpecialCategoryId
	public int isAdvancedSet(String msisdn, Rbt rbt,Connection con)
	{
		try
		{

			//con = conPool.getConnection();
			SubscriberCallerManager scam = new SubscriberCallerManager(con);

			return (scam.getAdvancedTone(msisdn, rbt));
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
		/*finally
		{
			conPool.free(con);
		}*/		
	}

	public int deleteAdvanceSetting(String msisdn)
	{
		try
		{

			con = conPool.getConnection();
			SubscriberCallerManager scam = new SubscriberCallerManager(con);

			return (scam.removeAdvancedTone(msisdn));
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
		finally
		{
			conPool.free(con);
		}		
	}

	/*public int giftTone(String msisdn, String friendMsisdn, int rbtCode,Connection con)
	{
		logger.info("giftTone()"+msisdn);
		String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(msisdn);

		try
		{
			//data not loaded, load it
			String interFriendMsisdn = TSSJavaUtil.instance().getInternationalNumber(friendMsisdn);

			//con = conPool.getConnection();
			con.setAutoCommit(false);

			SubscriberCallerManager scam = new SubscriberCallerManager(con);

			int ret = scam.giftToneToFriend(interMsisdn, interFriendMsisdn, rbtCode);
			if (ret != 1)
			{
				insertIntoRBTGiftLog (interMsisdn, ret, interFriendMsisdn,con);
				con.rollback();
				return ret;
			}

			//			int chr = doCharging(interMsisdn, rbtCode, 0);
			int planIndicator = Integer.parseInt(TSSJavaUtil.instance().getAppConfigParam("DEFAULT_RATE_PLAN"));
			query = "select GIFT_CHARGE_CODE, RBT_CHARGE_CODE from CRBT_RATE_PLANS where PLAN_INDICATOR = ?";
			pstmt = con.prepareStatement(query);
			pstmt.setInt(1, planIndicator);
			//logger.info(query);

			rs = pstmt.executeQuery();
			int rbt_charge_code=0;
			int gift_charge_code=0;
			if(rs.next())
			{
				gift_charge_code=Integer.parseInt(rs.getString("GIFT_CHARGE_CODE"));
				rbt_charge_code=Integer.parseInt(rs.getString("RBT_CHARGE_CODE"));
				logger.info("GIFT_CHARGE_CODEE= "+gift_charge_code);
			}

			if(rs != null) rs.close();
			pstmt.close();

			TCPPacketCharging tcpCharge = new TCPPacketCharging();
			int chr = tcpCharge.doEventBasedCharging(interMsisdn, gift_charge_code, rbtCode,interFriendMsisdn,4, interfaceType); //action=1 for SUB // interfacetype='C' for custcare
			logger.info("giftTone: chr="+chr);
			if (chr != 1)
			{
				insertIntoRBTGiftLog (interMsisdn, 5, interFriendMsisdn,con);
				con.rollback();
				return chr;
			}
			insertIntoSettingCdr(interMsisdn, planIndicator, rbtCode, 2,con);
			insertIntoRBTGiftLog (interMsisdn, 1, interFriendMsisdn,con);
			insertIntoSubscriberAudit(interMsisdn, 0, "Gifted RBT",con);

			con.commit();
			return 1;
		}
		catch (Exception e)
		{
			try {
				con.rollback();
			} catch(Exception exp) {}
			e.printStackTrace();
			return 0;
		}
		finally
		{
			conPool.free(con);
		}
	}*/

//giftTone

	 public String giftTone(String msisdn, String friendMsisdn, int rbtCode,SubscriberProfile subProfile) 
     {
             {
                    // System.out.println("giftTone()"+subscriberProfile.getMsisdn());
logger.info("Inside function giftTone()... where MSISDN ["+msisdn+"] AND FRIEND MSISDN ["+friendMsisdn+"] AND FOR RBT ["+rbtCode+"]");
                     friendMsisdn = TSSJavaUtil.instance().getInternationalNumber(friendMsisdn);
                     String changeType="GIFT_RINGTONE";
                     String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(msisdn);

                     String ret_str = "";
                     SetVariable sv = new SetVariable();
                     sv.setMsisdn(interMsisdn);
                     sv.setPlan(subProfile.getPlanIndicator());
                     sv.setLang(subProfile.getLang());
                     sv.setInterface("W");
                     sv.setUpdatedBy(interMsisdn);
                     sv.setSubType(subProfile.getSubType());
                     sv.rbt_code = rbtCode;
                     sv.fmsisdn=friendMsisdn;

                     logger.info("Gifting MSISDN["+interMsisdn+"] RBT["+rbtCode+"] FRIEND["+friendMsisdn+"] LANG["+subProfile.getLang()+"] PLAN ID["+subProfile.getPlanIndicator()+"] SUB-TYPE["+subProfile.getSubType()+"]");
                     
                     CRBTRequest crbt_req = new CRBTRequest();
                     crbt_req.constructQuery(6,sv);
                     int ret_val = crbt_req.send();
                     if (ret_val == 0)
                     {
                             ret_str = "SuccessFul";
                     }
                     else
                     {
                             ret_str = crbt_req.err_string;
                     }

                 logger.info("THIS IS THE RETURN STRING GETTING FROM RULE ENGINE  [ "+ret_str+" ]");
                     
                     return ret_str;// retVal;

             }
     }

	
	
	
	private int insertIntoFriendOpLog(String interMsisdn, int opCode, String friendMsisdn,Connection con)
	{
		logger.info("insertIntoFriendOpLog()"+interMsisdn);
		pstmt = null;
		try
		{
			String sub_type = subscriberProfile;
			/*		String subscriber_type = "P";
					String query ="Select msisdn from postpaid_subscribers where msisdn='"+interMsisdn+"'";
					rs = stmt.executeQuery(query);
					if(rs.next())
					{
					subscriber_type="O";
					rs.close();                  
					}*/

			query = "insert into CRBT_FRIEND_OP_LOG (MSISDN, SUBSCRIBER_TYPE, EVENT_TIME, INTERFACE_TYPE, OP_CODE, FRIEND_MSISDN, EVENT_CHARGED, UPDATED_BY, CALL_ID) values (?,?,sysdate,?,?,?,?,?,?)";

			pstmt = con.prepareStatement(query);
			pstmt.setString(1, interMsisdn);
			pstmt.setString(2, sub_type);
			pstmt.setString(3, "C");
			pstmt.setInt(4, opCode);
			pstmt.setString(5, friendMsisdn);
			pstmt.setString(6, "N");
			pstmt.setString(7, user);
			pstmt.setInt(8, 0);
			pstmt.executeUpdate();
			pstmt.close();
			return 1; //Success inserted in CCAudit 
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
	}//insertIntoFriendOpLog

	private int insertIntoGroupOpLog(String interMsisdn, int opCode, long groupId,Connection con)
	{
		logger.info("insertIntoGroupOpLog()"+interMsisdn);
		pstmt = null;
		try
		{
			String sub_type = subscriberProfile;
			/*		String subscriber_type = "P";
					query ="Select msisdn from postpaid_subscribers where msisdn='"+interMsisdn+"'";
					rs = stmt.executeQuery(query);
					if(rs.next())
					{
					subscriber_type="O";
					rs.close();                  
					}*/

			query = "insert into CRBT_GROUP_OP_LOG (MSISDN, SUBSCRIBER_TYPE, EVENT_TIME, INTERFACE_TYPE, OP_CODE, GROUP_ID, EVENT_CHARGED, UPDATED_BY, CALL_ID) values (?,?,sysdate,?,?,?,?,?,?)";

			pstmt = con.prepareStatement(query);
			pstmt.setString(1, interMsisdn);
			pstmt.setString(2, sub_type);
			pstmt.setString(3, "C");
			pstmt.setInt(4, opCode);
			pstmt.setLong(5, groupId);
			pstmt.setString(6, "N");
			pstmt.setString(7, user);
			pstmt.setInt(8, 0);
			pstmt.executeUpdate();
			pstmt.close();
			return 1; //Success inserted in CCAudit 
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
	}//insertIntoGroupOpLog

	private int insertIntoRBTGiftLog(String interMsisdn, int opCode, String friendMsisdn,Connection con)
	{
		logger.info("insertIntoRBTGiftOpLog()"+interMsisdn);
		pstmt = null;
		try
		{
			String sub_type = subscriberProfile;
			/*		String subscriber_type = "P";
					query ="Select msisdn from postpaid_subscribers where msisdn='"+interMsisdn+"'";
					rs = stmt.executeQuery(query);
					if(rs.next())
					{
					subscriber_type="O";
					rs.close();                  
					}*/

			query = "insert into CRBT_RBT_GIFT_LOG (MSISDN, SUBSCRIBER_TYPE, EVENT_TIME, INTERFACE_TYPE, OP_CODE, FRIEND_MSISDN, EVENT_CHARGED, UPDATED_BY, CALL_ID) values (?,?,sysdate,?,?,?,?,?,?)";

			pstmt = con.prepareStatement(query);
			pstmt.setString(1, interMsisdn);
			pstmt.setString(2, sub_type);
			pstmt.setString(3, "C");
			pstmt.setInt(4, opCode);
			pstmt.setString(5, friendMsisdn);
			pstmt.setString(6, "Y");
			pstmt.setString(7, user);
			pstmt.setInt(8, 0);
			pstmt.executeUpdate();
			pstmt.close();
			return 1; //Success inserted in CCAudit 
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
	}//insertIntoRBTGiftOpLog

	private int insertIntoRbtOpLog(String interMsisdn, int rbtcode, int opCode, String opFor, String charged, int treatment,Connection con)
	{
		logger.info("insertIntoRbtOpLog()"+interMsisdn);
		pstmt = null;
		try
		{
			String sub_type = subscriberProfile;
			/*		String subscriber_type = "P";
					query ="Select msisdn from postpaid_subscribers where msisdn='"+interMsisdn+"'";
					rs = stmt.executeQuery(query);
					if(rs.next())
					{
					subscriber_type="O";
					rs.close();                  
					}*/

			query = "insert into CRBT_RBT_OP_LOG (MSISDN, SUBSCRIBER_TYPE, EVENT_TIME, RBT_CODE, INTERFACE_TYPE, OP_CODE, OP_FOR, EVENT_CHARGED, UPDATED_BY, CALL_ID, OP_TREATMENT) values (?,?,sysdate,?,?,?,?,?,?,?,?)";

			pstmt = con.prepareStatement(query);
			pstmt.setString(1, interMsisdn);
			pstmt.setString(2, sub_type);
			pstmt.setInt(3, rbtcode);
			pstmt.setString(4, "C");
			pstmt.setInt(5, opCode);
			pstmt.setString(6, opFor);
			pstmt.setString(7, charged);
			pstmt.setString(8, user);
			pstmt.setInt(9, 0);
			pstmt.setInt(10, treatment);
			pstmt.executeUpdate();
			pstmt.close();
			return 1; //Success inserted in CCAudit 
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
	}// insertIntoRbtOpLog

	private int insertIntoSettingCdr(String interMsisdn, int planId, int rbtCode, int charge,Connection con)
	{
		if (con == null)
		{
			logger.info("CON NULL");
			return 0;
		}

		try
		{
			String query = "";
			if (charge == 1)
			{
				query = "insert into CRBT_PREPAID_SETTING_CDR (PRE_SECDR_ID, MSISDN, INTERFACE_USED, UPDATE_TIME, STATUS, PLAN_INDICATOR, RBT_CODE) values (PRE_SECDR_ID.nextval, ?, ?, sysdate, ?, ?, ?)";
			}
			else
			{
				query = "insert into CRBT_PREPAID_GIFTING_CDR (PRE_GICDR_ID, MSISDN, INTERFACE_USED, UPDATE_TIME, STATUS, PLAN_INDICATOR, RBT_CODE) values (PRE_GICDR_ID.nextval, ?, ?, sysdate, ?, ?, ?)";
			}
			PreparedStatement pstmt = con.prepareStatement(query);

			pstmt.setString(1, interMsisdn);
			pstmt.setString(2, "C");
			pstmt.setString(3, "N");
			pstmt.setInt(4, planId);
			pstmt.setInt(5, rbtCode);
			pstmt.executeUpdate();
			pstmt.close();
			return 1; //Success inserted in CDR
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
	}//insertIntoSettingCdr


	public String setAdvancedTone(SubscriberProfile sub, String control_name, String friendMsisdn, String groupName, String userId)
	{
		logger.info("control"+control_name+"groupName"+groupName+"userId"+userId+"friend"+friendMsisdn);
		System.out.println("control"+control_name+"groupName"+groupName+"userId"+userId+"friend"+friendMsisdn);
		String ret_str = "Please Try Later";
		CRBTRequest crbt_req = new CRBTRequest();
		SetVariable sv = new SetVariable();
		sv.setMsisdn(sub.getMsisdn());
		sv.setPlan(sub.getPlanIndicator());
		sv.setLang(sub.getLang());
		sv.setInterface("C");
		sv.setUpdatedBy(userId);
		sv.setSubType(sub.getSubType());
		sv.control_name = control_name;
		try
		{
			if (!(groupName.equals("--")))
			{
				sv.groupName = groupName;
				crbt_req.constructQuery(11,sv);
			}
			else if (friendMsisdn.equalsIgnoreCase("Default"))
			{ 
				crbt_req.constructQuery(9,sv);
			}
			else 
			{
				String interFriendMsisdn = TSSJavaUtil.instance().getInternationalNumber(friendMsisdn);
				sv.fmsisdn = interFriendMsisdn;
				crbt_req.constructQuery(10,sv);
			}
			int ret_val = crbt_req.send();
			if (ret_val == 0)
			{
				ret_str = "SuccessFull";
			}
			else
			{
				ret_str = crbt_req.err_string;
			}
			logger.info(ret_str);

		}
		catch (Exception e)
		{
			try {
			} catch(Exception exp) {}
			e.printStackTrace();
			return ret_str;
		}
		finally
		{
		}
		return ret_str;
	}//setAdvancedTone
	public String addRbtAlbum(SubscriberProfile sub, int albumId , int rbtCode,String albumName,String userId)
	{
		logger.info("addRbtAlbum()"+sub.getMsisdn());

		String interMsisdn = sub.getMsisdn();

		String ret_str = "";
		SetVariable sv = new SetVariable();
		sv.setMsisdn(interMsisdn);
		sv.setPlan(sub.getPlanIndicator());
		sv.setLang(sub.getLang());
		sv.setInterface("C");
		sv.setUpdatedBy(userId);
		sv.setSubType(sub.getSubType());
		sv.rbt_code = rbtCode;
		sv.albumId = albumId;
		sv.albumName = albumName;

		CRBTRequest crbt_req = new CRBTRequest();
		if(albumId==-1)
		{
			crbt_req.constructQuery(8,sv);
		}
		else
		{
			crbt_req.constructQuery(7,sv);

		}



		int ret_val = crbt_req.send();
		if (ret_val == 0)
		{
			ret_str = "SuccessFul";
		}
		else
		{
			ret_str = crbt_req.err_string;
		}

		return ret_str;// retVal;
	}
	public String removeRbtAlbum(SubscriberProfile sub,int[] rbtIds,String userId,String action,long oldaid ,long newaid,Connection con)  
	{

		String ret_str = "";
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String query = "";
		boolean autoCommit = false;
		String ret="-1";
		String msisdn=sub.getMsisdn();
		try 
		{
			//con = conPool.getConnection();
			if(con == null) {
				logger.info("Connection is NULL");
				return "-99";
			}
			if(action.equalsIgnoreCase("move"))
			{
				query = "update CRBT_WALLET_CONTENT set WALLET_ID=? where WALLET_ID=? and RBT_CODE=?";
				pstmt = con.prepareStatement(query);
				pstmt.setLong(1, newaid);
				pstmt.setLong(2, oldaid);
				for(int i=0; i<rbtIds.length; i++)
				{
					pstmt.setInt(3, rbtIds[i]);
					pstmt.executeUpdate();
					insertIntoAlbumLog (msisdn, rbtIds[i], newaid, 6, "N",con);
					insertIntoSubscriberAudit(msisdn, 1, "Rbt Moved",con);
				}
				pstmt.close();
				ret_str="Successful";
			}
			else{	
				for(int i=0; i<rbtIds.length; i++)
				{
					CRBTRequest crbt_req = new CRBTRequest();
					logger.info("Rbt Code"+rbtIds[i]);
					SetVariable sv = new SetVariable();
					sv.setMsisdn(sub.getMsisdn());
					sv.setPlan(sub.getPlanIndicator());
					sv.setLang(sub.getLang());
					sv.setInterface("C");
					sv.setUpdatedBy(userId);
					sv.setSubType(sub.getSubType());

					sv.rbt_code = rbtIds[i];
					crbt_req.constructQuery(19,sv);
					int ret_val = crbt_req.send();
					if (ret_val == 0)
					{
						ret_str = "SuccessFull";
					}
					else
					{
						ret_str = crbt_req.err_string;
					}
					logger.info(ret_str);
				}
			}
		}
		catch(SQLException sqle)
		{
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
			} catch(Exception exp) {}                
			sqle.printStackTrace();
			if (sqle.getErrorCode() == 1)
			{
				return "UNKNOWN ERROR";
			}
			else
			{
				return "UNKNOWN ERROR";
			}
		}
		/*
		finally 
		{
			conPool.free(con);
		}*/
		return ret_str;
	}//class 
	
	private int insertIntoAlbumLog(String msisdn, int rbtCode, long album, int op, String charge,Connection con)
	{
		PreparedStatement pstmt = null;
		try
		{
			String sub_type = subscriberProfile;

			String query = "insert into CRBT_ALBUM_OP_LOG (MSISDN, SUBSCRIBER_TYPE, EVENT_TIME, INTERFACE_TYPE, RBT_CODE, ALBUM_ID, OP_CODE, EVENT_CHARGED, UPDATED_BY, CALL_ID) values (?,?,sysdate,'C',?,?,?,?,?,0)";

			pstmt = con.prepareStatement(query);
			pstmt.setString(1, msisdn);
			pstmt.setString(2, sub_type);
			pstmt.setInt(3, rbtCode);
			pstmt.setLong(4, album);
			pstmt.setInt(5, op);
			pstmt.setString(6, charge);
			pstmt.setString(7, user);

			pstmt.executeUpdate();
			pstmt.close();
			return 1; //Success inserted in CCAudit
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
	}

}//class 
