/*
 * This class is used for user authentication for the web interface for CRBT. 
 *
 *
 *
 */


package com.telemune.vcc.custcare;
import java.util.ArrayList;

public class CommercialSub 
{
	private int rbtCode=0;
	private String member=null;
	private String memDate=null;
	private ArrayList members = null;//msisdns in this group

	public void setrbtCode(int rbtCode )
	{
		this.rbtCode = rbtCode;
	}

	
	public int getrbtCode ()
	{
		return rbtCode;
	}
	public ArrayList getMembers()
  {
	    return members;
	}
				

	public void setMembers(String []member)
	{
		this.members = new ArrayList();
		
		for(int i=0; i < member.length; i++)
		{
			this.members.add(member[i]);	
		}
	}


	public void setMembers(ArrayList members)
	{
		this.members = members;
	}

	public void setMember(String member)
	{
		this.member = member;
	}
	public String getMember()
	{
		return this.member;
	}
	
	public void setMemberDate(String memDate)
	{
		this.memDate = memDate;
	}
	public String getMemberDate()
	{
		return this.memDate;
	}

}

