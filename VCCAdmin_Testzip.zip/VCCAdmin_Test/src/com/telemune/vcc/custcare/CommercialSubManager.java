
package com.telemune.vcc.custcare;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import com.telemune.dbutilities.*;
import com.telemune.vcc.common.*;

import org.apache.log4j.*;
public class CommercialSubManager

{
           private static Logger logger=Logger.getLogger(CommercialSubManager.class);
	private ConnectionPool conPool = null;
	private PreparedStatement pstmt = null;
	private PreparedStatement pstmt1 = null;
	private Connection con = null;
	private ResultSet rs =null;
	private ResultSet rs1 =null;
	private String query = null;
final static int SERVICE_ACTIVATE_SS = 3;
	final static int SERVICE_DEACTIVATE_SS = 4;
	final static int SERVICE_RETRIEVE_IMSI = 9;
	final static int SERVICE_INTERROGATE_SS = 15;

	public CommercialSubManager()				 
	{
		conPool = new ConnectionPool();
	}
	
	public void setConnectionPool(ConnectionPool conpool)
	{
		this.conPool=conpool;
	}
	
	
	
	public int addCommercialSub ( int rbtCode, ArrayList Members, ArrayList excludeAr,Connection con)
	{
		logger.info("Inside function addCommercialSub().......");
		int check=0;
		try
		{
			String query1=null;
			//con = conPool.getConnection();
			String msisdn ="";

			for (int i=0; i<Members.size(); i++)
			{
				query1 = "select MSISDN from CRBT_COMMERCIAL_SUBSCRIBER where MSISDN = ?";
				logger.info("query = "+query);
				msisdn=  TSSJavaUtil.instance().getInternationalNumber((String)Members.get(i));
				pstmt1 = con.prepareStatement(query1);
				pstmt1.setString(1, msisdn);
				rs1 = pstmt1.executeQuery();
				if(rs1.next())
				{
					logger.info("msisdn "+msisdn+" already in CRBT_COMERCIAL_SUBSCRIBER");
					excludeAr.add(msisdn);
				}
				else
				{
					query = "insert into CRBT_COMMERCIAL_SUBSCRIBER (RBT_CODE ,MSISDN, CREATE_DATE) values (?, ?, sysdate)";
					logger.info("query = "+query);
					pstmt = con.prepareStatement (query);
					pstmt.setInt(1, rbtCode);
					pstmt.setString(2, msisdn.trim());
					pstmt.executeUpdate();
					pstmt.close();

					query="select param_value from CRBT_APP_CONFIG_PARAMS where PARAM_TAG=?";
					logger.info("query = "+query);
					pstmt = con.prepareStatement(query);
					pstmt.setString(1,"SMS_ORIGINATION_NUMBER");

					rs = pstmt.executeQuery();
					String sms_origin_number="7464";
					if(rs.next()) 
					{
						sms_origin_number  = rs.getString(1);
						logger.info("sms_origin_number = "+sms_origin_number);
					}
					rs.close();
					pstmt.close();
					//				logger.info(sms_origin_number);
		String imsi = "123456781011121";
		String subscriber_type="P" ; // O=postpaid, P=prepaid
		   StringBuffer imsiBuf = new StringBuffer();
			if (cfuProcess(msisdn, imsiBuf, SERVICE_ACTIVATE_SS) != 1)
			{
				logger.info("CFU Could not be activated for commercailsub = " +msisdn );	
				logger.info("deleting entry ");	
				//	unsubscribe(interMsisdn,"xx");  //CFU was not activated.
				query="delete from CRBT_COMMERCIAL_SUBSCRIBER where msisdn=?";
				logger.info("query = "+query);
				pstmt = con.prepareStatement (query);
				pstmt.setString(1, msisdn);
				pstmt.executeUpdate();
				pstmt.close();
				excludeAr.add(msisdn);

							return -5;
			}
					String Message_Text="Hi, You are selected to commercial service of tele tunes";
					query = "select TEMPLATE_MESSAGE from LBS_TEMPLATES where TEMPLATE_ID = 307 and TEMPLATE_TYPE = 10 and language_id = 1";
					logger.info("query = "+query);
					pstmt = con.prepareStatement(query);
					rs = pstmt.executeQuery();
					if(rs.next()) 
					{
						String message_string = rs.getString(1);
						int tempPos =0;
						tempPos = message_string.indexOf("$(msisdn)");
						if(tempPos !=-1) 
						{
							Message_Text = message_string.substring(0,tempPos);
							Message_Text = Message_Text +msisdn+message_string.substring(tempPos+9,message_string.length());
						}
					}	

					logger.info("1. "+Message_Text);
					rs.close();
					pstmt.close();

					query= "insert into GMAT_MESSAGE_STORE (RESPONSE_ID, REQUEST_ID, ORIGINATING_NUMBER, DESTINATION_NUMBER, MESSAGE_TEXT, SUBMIT_TIME, STATUS) values (GMAT_RESPONSE_ID_SEQ.nextval, 0, ?, ?, ?, sysdate, ?)";
					logger.info("query = "+query);
					logger.info("Message_Text = "+Message_Text);
					pstmt = con.prepareStatement(query);
					pstmt.setString(1, sms_origin_number.trim());
					pstmt.setString(2, msisdn.trim());
					pstmt.setString(3, Message_Text.trim());
					pstmt.setString(4, "R");
					pstmt.executeUpdate();
					pstmt.close();
				}
				rs1.close();
				pstmt1.close();

			}
		}
		catch (Exception e)
		{
			try
			{
				if(pstmt != null) pstmt.close ();
				if(pstmt1 != null) pstmt1.close ();
				if(rs != null) rs.close ();
			}catch(SQLException sqle)
			{
				logger.error ( sqle.getMessage ());
			}
			e.printStackTrace ();
			return -5;
		}
		//finally{ conPool.free(con); }
		return 1;
	} // add

	public int getMembers (ArrayList MemAr,String rbtCodes,Connection con)
	{
		logger.info("Inside function getMembers()... where rbtCode is  [ "+rbtCodes+" ]");
		int rbtCode=Integer.parseInt(rbtCodes);

		int check=0;
		logger.debug ("");
		try
		{
			//con = conPool.getConnection();
			/* 
			   query = "select MSISDN from CRBT_COMMERCIAL_SUBSCRIBER where N = ?";
			   logger.info (query);
			   pstmt = con.prepareStatement(query);
			   pstmt.setString(1, bl.getMsisdn());
			   rs=pstmt.executeQuery();
			   if(rs.next())
			   {
			   check=rs.getInt(1);
			   if(rs != null) rs.close();
			   }
			   if(rs != null) rs.close();
			   pstmt.close();

			   if(check==0)
			   {
			   return(-1);
			   }
			   else
			   {
			 */						
			query = "select CREATE_DATE,MSISDN from CRBT_COMMERCIAL_SUBSCRIBER where RBT_CODE=?";
			logger.info("query = "+query);
			pstmt = con.prepareStatement(query);
			pstmt.setInt(1, rbtCode);
			rs=pstmt.executeQuery();

			while(rs.next ())
			{
				CommercialSub comObj=new CommercialSub();
				comObj.setMember(rs.getString("MSISDN"));
				comObj.setMemberDate (rs.getString ("CREATE_DATE"));
				MemAr.add(comObj);
			}
			rs.close ();
			pstmt.close ();
			//}
		}//try
		catch (Exception e)
		{
			try
			{
				if(rs != null) rs.close ();
				if(pstmt != null) pstmt.close ();
			}catch(SQLException sqle)
			{
				logger.error ("Exception in getHLRConfig, Exception is : " + sqle.getMessage ());
			}
			logger.error ("Exception caught "+e);
			e.printStackTrace ();
			return -2;
		}//catch
	//	finally{ conPool.free(con); }

		return 1;
	}//getMembers
	public int deleteMembers (String[] Numbers,Connection con)
	{
		logger.info("inside function  deleteMembers() ....");
		int check=0;
		//logger.debug ("Deletion");
		try
		{
			if(Numbers.length==0)
			{
				return 0;
			}
		}catch(NullPointerException nex)
		{
			return 0;

		}

		try
		{
			//con = conPool.getConnection();
			for (int i=0; i<Numbers.length;i++)
			{
				query = "delete from CRBT_COMMERCIAL_SUBSCRIBER where MSISDN=? ";
				logger.info("query = "+query+" :: msisdn= "+Numbers[i]);
				pstmt = con.prepareStatement(query);
				pstmt.setString(1, Numbers[i]);
				pstmt.executeQuery();
				pstmt.close ();
			}	



		}//try
		catch (Exception e)
		{
			try
			{
				if(rs != null) rs.close ();
				if(pstmt != null) pstmt.close ();
			}catch(SQLException sqle)
			{
				logger.error ("Exception in delete member : ",sqle);
			}
			logger.error ("Exception caught ",e);
			e.printStackTrace ();
			return -2;
		}//catch
		//finally{ conPool.free(con); }

		return 1;
	}//
	public int modifyMember (String Numbers,String changeNum,Connection con) 
	{
		logger.info("Inside function modifyMember(),,,, where oldNum ["+Numbers+"] and newNum ["+changeNum+"]");
		String query1=null;
		String msisdn		=  TSSJavaUtil.instance().getInternationalNumber(changeNum);
		try
		{
			//con = conPool.getConnection();
			query1 = "select MSISDN from CRBT_Commercial_SUBSCRIBER where MSISDN = ?";
			pstmt1 = con.prepareStatement(query1);
			pstmt1.setString(1, msisdn);
			rs = pstmt1.executeQuery();
			if(rs.next())
			{
				logger.info("msisdn "+msisdn+" is already in CRBT_COMMERCIAL_SUBSCRIBER");
				rs.close();
				pstmt1.close();
				return -3;
			}
			else
			{
				query = "update CRBT_COMMERCIAL_SUBSCRIBER set MSISDN=? where MSISDN=?";
				logger.info("query = "+query);
				pstmt = con.prepareStatement(query);

				pstmt.setString(2, Numbers);
				pstmt.setString(1, msisdn);
				pstmt.executeUpdate();
			}
			rs.close();
			pstmt1.close();
			pstmt.close ();
		}//try
		catch (Exception e)
		{
			try
			{
				if(rs != null) rs.close ();
				if(pstmt != null) pstmt.close ();
			}catch(SQLException sqle)
			{
				logger.error ("Exception in getHLRConfig, Exception is : " + sqle.getMessage ());
			}
			logger.error ("Exception caught "+e);
			e.printStackTrace ();
			return -2;
		}//catch
		//finally{ conPool.free(con); }

		return 1;
	}//get

	private int cfuProcess(String interMsisdn, StringBuffer imsi, int service)
	{
		logger.info(" In function cfuProcess() interMsisdn "+interMsisdn);
		/* Calling Fecth MSRN to Activate */
		if(TSSJavaUtil.instance().isActDeactEnabled() == 1) 
		{
			logger.info("ActDeactEnabled");
			String vlr = "",  scfAddress = "", busyNumber = "", noReplyNumber = "", unreachableNumber = "";

			StringBuffer msrn = new StringBuffer();
			StringBuffer cfuActiveStr = new StringBuffer();
			Integer serviceKey = new Integer(0);
			Boolean isRoaming = new Boolean(true);
			Boolean isPrepaid = new Boolean(true);
			Boolean cfuActive = new Boolean(true);
			Integer msrnError = new Integer(0);

			int activateStatus = FetchMsrn.fetchmsrn(service, interMsisdn, msrn, vlr, imsi, scfAddress, serviceKey, isRoaming, isPrepaid, msrnError, busyNumber, noReplyNumber, unreachableNumber, cfuActive, cfuActiveStr);
			logger.info("activateStatus= "+activateStatus);

			if (activateStatus !=0)
			{
				logger.info("\nThere was some error [" + msrnError.intValue() +"] in activate/deactivateSS\n");
				return 0;
			}
			return 1;
		}
		return 1;
	}//
} //class 
