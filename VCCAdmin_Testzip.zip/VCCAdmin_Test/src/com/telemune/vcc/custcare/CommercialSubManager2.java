
package com.telemune.vcc.custcare;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import com.telemune.dbutilities.*;
import com.telemune.vcc.common.*;

import org.apache.log4j.*;
public class CommercialSubManager2

{ 
	private static Logger logger=Logger.getLogger(CommercialSubManager2.class);
	private ConnectionPool conPool = null;
	private PreparedStatement pstmt = null;
	private PreparedStatement pstmt1 = null;
	private Connection con = null;
	private ResultSet rs =null;
	private String query = null;
	public CommercialSubManager2()				 
	{
		conPool = new ConnectionPool();
	}
	public void setConnectionPool(ConnectionPool conpool)
	{
		this.conPool=conpool;
	}
	public int addCommercialSub ( int rbtCode, ArrayList Members, ArrayList excludeAr)
	{
		logger.info("inside addCommercialSub()");
		int check=0;
		try
		{
			String query1=null;
			con = conPool.getConnection();
			String msisdn ="";

			for (int i=0; i<Members.size(); i++)
			{
				query1 = "select MSISDN from CRBT_COMMERCIAL_SUBSCRIBER where MSISDN = ?";
				logger.info("query = "+query);
				msisdn=  TSSJavaUtil.instance().getInternationalNumber((String)Members.get(i));
				pstmt1 = con.prepareStatement(query1);
				pstmt1.setString(1, msisdn);
				rs = pstmt1.executeQuery();
				if(rs.next())
				{
					excludeAr.add(msisdn);
				}
				else
				{
					query = "insert into CRBT_COMMERCIAL_SUBSCRIBER (RBT_CODE ,MSISDN, CREATE_DATE) values (?, ?, sysdate)";
					logger.info("query = "+query);
					pstmt = con.prepareStatement (query);
					pstmt.setInt(1, rbtCode);
					pstmt.setString(2, msisdn);
					pstmt.executeUpdate();
					pstmt.close();
				}
				rs.close();
				pstmt1.close();

			}
		}
		catch (Exception e)
		{
			try
			{
				if(pstmt != null) pstmt.close ();
				if(pstmt1 != null) pstmt1.close ();
				if(rs != null) rs.close ();
			}catch(SQLException sqle)
			{
				logger.error ( sqle.getMessage ());
			}
			e.printStackTrace ();
			return -5;
		}
		finally{ conPool.free(con); }
		return 1;
	} // add

	public int getMembers (ArrayList MemAr,String rbtCodes)
	{
		logger.info("inside getMembers()");
		int rbtCode=Integer.parseInt(rbtCodes);

		int check=0;
		logger.info ("");
		try
		{
			con = conPool.getConnection();
			/* 
			   query = "select MSISDN from CRBT_COMMERCIAL_SUBSCRIBER where N = ?";
			   logger.info (query);
			   pstmt = con.prepareStatement(query);
			   pstmt.setString(1, bl.getMsisdn());
			   rs=pstmt.executeQuery();
			   if(rs.next())
			   {
			   check=rs.getInt(1);
			   if(rs != null) rs.close();
			   }
			   if(rs != null) rs.close();
			   pstmt.close();

			   if(check==0)
			   {
			   return(-1);
			   }
			   else
			   {
			 */						
			query = "select CREATE_DATE,MSISDN from CRBT_COMMERCIAL_SUBSCRIBER where RBT_CODE=?";
			logger.info("query = "+query);
			pstmt = con.prepareStatement(query);
			pstmt.setInt(1, rbtCode);
			rs=pstmt.executeQuery();

			while(rs.next ())
			{
				CommercialSub comObj=new CommercialSub();
				comObj.setMember(rs.getString("MSISDN"));
				comObj.setMemberDate (rs.getString ("CREATE_DATE"));
				MemAr.add(comObj);
			}
			rs.close ();
			pstmt.close ();
			//}
		}//try
		catch (Exception e)
		{
			try
			{
				if(rs != null) rs.close ();
				if(pstmt != null) pstmt.close ();
			}catch(SQLException sqle)
			{
				logger.error ("Exception in getHLRConfig, Exception is : " + sqle.getMessage ());
			}
			logger.error ("Exception caught "+e);
			e.printStackTrace ();
			return -2;
		}//catch
		finally{ conPool.free(con); }

		return 1;
	}//getMembers
	public int deleteMembers (String[] Numbers)
	{
		logger.info("inside deleteMembers()");
		int check=0;
		logger.info ("Deletion");
		try
		{
			if(Numbers.length==0)
			{
				return 0;
			}
		}catch(NullPointerException nex)
		{
			return 0;

		}

		try
		{
			con = conPool.getConnection();
			for (int i=0; i<Numbers.length;i++)
			{
				query = "delete from CRBT_COMMERCIAL_SUBSCRIBER where MSISDN=? ";
				logger.info("query = "+query);
				pstmt = con.prepareStatement(query);
				pstmt.setString(1, Numbers[i]);
				pstmt.executeQuery();
				pstmt.close ();
			}	



		}//try
		catch (Exception e)
		{
			try
			{
				if(rs != null) rs.close ();
				if(pstmt != null) pstmt.close ();
			}catch(SQLException sqle)
			{
				logger.error ("Exception in getHLRConfig, Exception is : " + sqle.getMessage ());
			}
			logger.error ("Exception caught "+e);
			e.printStackTrace ();
			return -2;
		}//catch
		finally{ conPool.free(con); }

		return 1;
	}//
	public int modifyMember (String Numbers,String changeNum)
	{
		logger.info ("iniside modifyMember()");
		logger.info (Numbers);
		logger.info (changeNum);
		String query1=null;
		String msisdn		=  TSSJavaUtil.instance().getInternationalNumber(changeNum);
		try
		{
			con = conPool.getConnection();
			query1 = "select MSISDN from CRBT_Commercial_SUBSCRIBER where MSISDN = ?";
			logger.info("query = "+query);
			pstmt1 = con.prepareStatement(query1);
			pstmt1.setString(1, msisdn);
			rs = pstmt1.executeQuery();
			if(rs.next())
			{
				logger.info("already exists");
				rs.close();
				pstmt1.close();
				return -3;
			}
			else
			{
				query = "update CRBT_COMMERCIAL_SUBSCRIBER set MSISDN=? where MSISDN=?";
				logger.info("query = "+query);
				pstmt = con.prepareStatement(query);

				pstmt.setString(2, Numbers);
				pstmt.setString(1, msisdn);
				pstmt.executeUpdate();
			}
			rs.close();
			pstmt1.close();
			pstmt.close ();
		}//try
		catch (Exception e)
		{
			try
			{
				if(rs != null) rs.close ();
				if(pstmt != null) pstmt.close ();
			}catch(SQLException sqle)
			{
				logger.error ("Exception in getHLRConfig, Exception is : " + sqle.getMessage ());
			}
			logger.error ("Exception caught "+e);
			e.printStackTrace ();
			return -2;
		}//catch
		finally{ conPool.free(con); }

		return 1;
	}//get

} //class 
