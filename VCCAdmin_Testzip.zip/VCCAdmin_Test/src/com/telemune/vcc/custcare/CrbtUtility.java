/*
 * This class is used for general utility for the web interface for CRBT.
 *
 * subscriber type is detemined from IMSI, 
 *  **  9th digit of IMSI = 1 or 3 - PREPAID
 *  **  9th digit of IMSI = 2 	   - POSTPAID
 * ** @JP July 21,2007 Kingston ***
 *
 *
 */
package com.telemune.vcc.custcare;
import java.sql.SQLException;
import java.sql.ResultSet;

import com.telemune.dbutilities.*;
import com.telemune.vcc.common.*;

import java.util.*;

import org.apache.log4j.*;
public class CrbtUtility
{
         private static Logger logger=Logger.getLogger(CrbtUtility.class);

	private ConnectionPool conPool;
	private Connection con;

	final static int SERVICE_ACTIVATE_SS = 3;
	final static int SERVICE_DEACTIVATE_SS = 4;
	final static int SERVICE_RETRIEVE_IMSI = 9;
	final static int SERVICE_INTERROGATE_SS = 15;
	private static String digit9_imsi="0";
	private static String subscriber_type="N";
	private static String interfaceType="C";
	private int retVal=0; 
	private int multi_table_enable=-1; // added by Avishkar
	public void CrbtUtility() 
	{
		this.conPool =  null;
		this.con = null;
	}

	public void setConnectionPool(ConnectionPool conPool)
	{
		this.conPool = conPool;
	}

	private int doPrepaidCharging (String interMsisdn, int chargeCode)
	{
		logger.info("doPrepaidCharging()");
		int ret = TSSJavaUtil.instance().isChargingEnabled();
		if (ret == 1)
		{
			logger.info("Charging Enabled, chargeCode="+chargeCode);
			StringBuffer stat = new StringBuffer();
			SSFClient ssfClient = new SSFClient();
			int announcementID = SSFClient.doEventBasedCharging(chargeCode, interMsisdn, stat);
			if (announcementID == -1)
			{
				return -1;
			}		

			if (stat.toString().equalsIgnoreCase("true"))
			{
				if(announcementID == 502)
				{
					return 502;
				}
				else if(announcementID == 510)
				{
					return 510;
				}
				return 1;
			}
			else if (stat.toString().equalsIgnoreCase("false"))
			{
				switch(announcementID)
				{
					case 501:
					case 503:
					case 507:
						return 2;
					default:
						return -2;
				}
			}
			else 
			{
				return -1;
			}
		}
		else 
		{
			logger.info("Charging Disabled");
			return 1;
		}
	} //doPrepaidCharging

	private int genPrePaidCDR (String interMsisdn, int planId, String action)
	{
		logger.info("genPrePaidCDR(): ");
		String query = "insert into CRBT_PREPAID_SUBSCRIPTION_CDR (PRE_SCDR_ID, MSISDN, INTERFACE_USED, UPDATE_TIME, ACTION, PLAN_INDICATOR, STATUS) values (PRE_SCDR_ID.nextval, ?, 'C', sysdate, ?, ?, ?)";
		try
		{
			PreparedStatement pstmt = con.prepareStatement(query);
			pstmt.setString(1, interMsisdn);
			pstmt.setString(2, action);
			pstmt.setInt(3, planId);
			pstmt.setString(4, "N");
			pstmt.executeUpdate();
			pstmt.close();
			return 1; //Success inserted in CDR
		}
		catch (SQLException sqle) 
		{
			sqle.printStackTrace();
			return -1;
		}
	} //genPrePaidCDR

	private int genPostPaidCDR (String interMsisdn, int planId, String action)
	{
		logger.info("genPostPaidCDR() ");
		String query = "insert into CRBT_SUBSCRIPTION_CDR (SCDR_ID, MSISDN, INTERFACE_USED, UPDATE_TIME, ACTION, PLAN_INDICATOR, STATUS) values (SCDR_ID.nextval, ?, 'C', sysdate, ?, ?, ?)";
		try
		{
			PreparedStatement pstmt = con.prepareStatement(query);
			pstmt.setString(1, interMsisdn);
			pstmt.setString(2, action);
			pstmt.setInt(3, planId);
			pstmt.setString(4, "N");
			pstmt.executeUpdate();
			pstmt.close();
			return 1; //Success inserted in CDR
		}
		catch (SQLException sqle) 
		{
			sqle.printStackTrace();
			return -1;
		}
	} //genPostPaidCDR

	private int cfuProcess(String interMsisdn, StringBuffer imsi, int service)
	{
		logger.info(" In function cfuProcess() ");
		/* Calling Fecth MSRN to Activate */
		if(TSSJavaUtil.instance().isActDeactEnabled() == 1) 
		{
			logger.info("ActDeactEnabled");
			String vlr = "",  scfAddress = "", busyNumber = "", noReplyNumber = "", unreachableNumber = "";

			StringBuffer msrn = new StringBuffer();
			StringBuffer cfuActiveStr = new StringBuffer();
			Integer serviceKey = new Integer(0);
			Boolean isRoaming = new Boolean(true);
			Boolean isPrepaid = new Boolean(true);
			Boolean cfuActive = new Boolean(true);
			Integer msrnError = new Integer(0);

			int activateStatus = FetchMsrn.fetchmsrn(service, interMsisdn, msrn, vlr, imsi, scfAddress, serviceKey, isRoaming, isPrepaid, msrnError, busyNumber, noReplyNumber, unreachableNumber, cfuActive, cfuActiveStr);
			logger.info("activateStatus= "+activateStatus);
			logger.info("activateStatus= "+activateStatus);

			if (activateStatus !=0)
			{
				logger.info("\nThere was some error [" + msrnError.intValue() +"] in activate/deactivateSS\n");
				return 0;
			}
			return 1;
		}
		return 1;
	}//cfuProcess

	public int addsubscriber(String Msisdn, String userId) 
	{
		String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(Msisdn);
		logger.info("addsubscriber Number="+interMsisdn);
		int planId = Integer.parseInt(TSSJavaUtil.instance().getAppConfigParam("DEFAULT_RATE_PLAN")); 

		int totalSubs = 0;
		String imsi = "123456781011121";
		String subscriber_type="N" ; // O=postpaid, P=prepaid
		String query = "";

		StringBuffer imsiBuf = new StringBuffer();
		/*
		   if (cfuProcess(interMsisdn, imsiBuf, SERVICE_RETRIEVE_IMSI) != 1)
		   {
		   return 0;
		   }
		   imsi = imsiBuf.toString();
		 */	
		logger.info("imsi = "+ imsi);

		con = conPool.getConnection();

		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try 
		{
			con.setAutoCommit(false);

			query = "select count(MSISDN) SUBS from CRBT_SUBSCRIBER_MASTER";
			pstmt = con.prepareStatement(query);
			rs = pstmt.executeQuery();
			if (rs.next()) 
			{
				totalSubs = rs.getInt("SUBS");
				logger.info("total subscribers: "+totalSubs);
			}
			rs.close();
			pstmt.close();

			if (totalSubs >= getMaxSubs(con))
			{
				return -3;
			}

			/*
			   query = "select * from OPERATOR_SUBSCRIBER where (to_number(STARTS_AT) <=to_number(?) and to_number(ENDS_AT) >=to_number(?) and to_number(?) not in (select to_number(EXCLUDE_NUM) from OPERATOR_SUBSCRIBER_EXCLUDE)) or to_number(?) in(select to_number(INCLUDE_NUM) from OPERATOR_SUBSCRIBER_INCLUDE)";
			   pstmt = con.prepareStatement(query);
			   pstmt.setString(1, interMsisdn);
			   pstmt.setString(2, interMsisdn);
			   pstmt.setString(3, interMsisdn);
			   pstmt.setString(4, interMsisdn);

			   rs = pstmt.executeQuery();

			   if (!rs.next())
			   {
			   return -2;
			   }
			   rs.close();
			   pstmt.close();
			 */

			query = "select STATUS,SUB_TYPE from CRBT_SUBSCRIBER_MASTER where MSISDN = ?";

			pstmt = con.prepareStatement(query);
			pstmt.setString(1, interMsisdn);

			rs = pstmt.executeQuery();

			if(rs.next()) 
			{
				logger.info("Status = "+rs.getString("STATUS") );
                                subscriber_type=rs.getString("SUB_TYPE");
                               logger.info("subscriber_type.........."+subscriber_type);
				logger.info(interMsisdn+" is already a subscriber");
				return -1;
			}
			rs.close();
			pstmt.close();

			//*** @JP July 21,2007 Kingston
			int rbtCode = Integer.parseInt(TSSJavaUtil.instance().getAppConfigParam("DEFAULT_RBT"));
			logger.info("DEFAULT_RBT .. Code= "+rbtCode);

			Random no_generator = new Random();
			String passwd = "" + (no_generator.nextInt(8999) + 1000);
			String tpin = passwd;

			query = "insert into crbt_subscriber_master (MSISDN,STATUS,PLAN_INDICATOR,RBT_CODE,PASSWORD,TPIN,IMSI,LANGUAGE) values (?, 'A', ?, ?, ?, ?, ?,2)";
			//		query = "insert into crbt_subscriber_master (MSISDN,STATUS,PLAN_INDICATOR,RBT_CODE,PASSWORD,TPIN,IMSI, CORP_ID) values (?, 'A', ?, ?, ?, ?, ?,0)"; //corpId is 0 by default for non-corp users
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, interMsisdn);
			pstmt.setInt(2, planId);
			pstmt.setInt(3, rbtCode);
			pstmt.setString(4, passwd);
			pstmt.setString(5, tpin);
			pstmt.setString(6, imsi);

			pstmt.executeUpdate();
			pstmt.close();

			long walletId = 0;
			query = "select WALLET_ID_SEQ.nextval from dual";	
			pstmt = con.prepareStatement(query);

			rs = pstmt.executeQuery();

			if (rs.next()) 
			{
				walletId = rs.getLong("NEXTVAL");
			}
			rs.close();
			pstmt.close();

			query = "insert into CRBT_WALLET_MASTER (MSISDN, WALLET_ID, IVR_NAME, WALLET_NAME) values(?, ?, ?, 'DEFAULT')";
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, interMsisdn);
			pstmt.setLong(2, walletId);
			pstmt.setInt(3, 0);
			pstmt.executeUpdate();
			pstmt.close();

			//query = "insert into CRBT_WALLET_CONTENT (WALLET_ID, RBT_CODE) values(?, ?)";
			query = "insert into CRBT_WALLET_CONTENT (WALLET_ID, RBT_CODE, MSISDN) values(?, ?,?)";
			pstmt = con.prepareStatement(query);
			pstmt.setLong(1, walletId);
			pstmt.setInt(2, rbtCode);
			pstmt.setString(3, interMsisdn);
			pstmt.executeUpdate();
			pstmt.close();

			query = "insert into CRBT_DEFAULT_DETAIL (MSISDN, DAY, START_AT, ENDS_AT, RBT_CODE) values (?, ?, ?, ?, ?)";
			ToneSetting ts = new ToneSetting();
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, interMsisdn);
			pstmt.setInt(2, ts.getDay());
			pstmt.setInt(3, ts.getStartTime());
			pstmt.setInt(4, ts.getEndTime());
			pstmt.setInt(5, rbtCode);


			pstmt.executeUpdate();
			pstmt.close();

			int chargeCode = 0;
			query = "select SUBSCRIPTION_CHARGE_CODE SUB_CHARGE from CRBT_RATE_PLANS where PLAN_INDICATOR = ?";
			pstmt = con.prepareStatement(query);
			pstmt.setInt(1, planId);

			rs = pstmt.executeQuery();
			if (rs.next())
			{
				chargeCode = Integer.parseInt(rs.getString("SUB_CHARGE"));
				logger.info("SUBSCRIPTION: CHARGE_CODE="+chargeCode);
			}
			rs.close();    
			pstmt.close();

			/*
			   if (subscriber_type.equalsIgnoreCase("P"))
			   {
			//	retVal = genPrePaidCDR (interMsisdn, planId, "S");
			// retVal = doPrepaidCharging (interMsisdn, chargeCode);
			//if (retVal == 1 || retVal == 502 || retVal == 510) 
			//	  {
			//		  logger.info("charging success now generating cdrs");
			//		  retVal = genPrePaidCDR (interMsisdn, planId, "S");
			//		  }
			//		  else 
			//		  {
			//		  pstmt.close();
			//		  con.rollback();
			//		  return 0;
			//		  }
			//		 

			}//subtype="Prepaid"
			 */

			TCPPacketCharging tcpCharge = new TCPPacketCharging();
			retVal= tcpCharge.doEventBasedCharging(interMsisdn, chargeCode, -1,"-1",1, interfaceType); //action=1 for SUB // interfacetype='C' for custcare

			if(retVal ==1)//success
			{
				logger.info(interMsisdn+ " Charged successfully");
			}
			else if(retVal ==0)//charging failure
			{
				logger.info(interMsisdn+ " could not be Charged, may be insufficient balance");
				pstmt.close();
				con.rollback();
				return 0;
			}
			else if(retVal ==-5)//timeout
			{
				logger.info("TCP/IP conection timeout occured");
				pstmt.close();
				con.rollback();
				//function to accept temp registration and send notifying sms
				registertemp(interMsisdn, con);
				return -7;
			}
			else if(retVal ==-6)//network read/write error
			{
				logger.info("Read/Write error");
				pstmt.close();
				con.rollback();
				//function to accept temp registration and send notifying sms
				registertemp(interMsisdn, con);
				return -6;
			}
			else //
			{
				logger.info("Try later");
				pstmt.close();
				con.rollback();
				return -7;
			}

			logger.info("charging success now generating cdrs");
			retVal = genPrePaidCDR (interMsisdn, planId, "S");

			if (this.regeneratePass(interMsisdn,1) != 1)
			{
				pstmt.close();
				con.rollback();
				return 0;
			}
			insertIntoCustCareAudit(interMsisdn, 2, "SUBSCRIBED", subscriber_type, userId);
			insertIntoSubscriptionLog(interMsisdn, subscriber_type,  "S", "Y", userId);
			con.commit();
			if (rs != null) rs.close();
			if (pstmt != null) pstmt.close();

		}
		catch (SQLException sqle)
		{
			try {
				con.rollback();
				if (rs != null) rs.close();
				if (pstmt != null) pstmt.close();
			} catch (Exception e) {}
			sqle.printStackTrace();
			return 0;
		}
		finally 
		{
			conPool.free(con);
		}
		if (cfuProcess(interMsisdn, imsiBuf, SERVICE_ACTIVATE_SS) != 1)
		{
			logger.info("CFU Could not be activated for unsubscribing it " +interMsisdn );	
			//	unsubscribe(interMsisdn,"xx");  //CFU was not activated.
			return -5;
		}

		return 1;// retVal;
	} //addsubscriber
	public String addsubscriber(String Msisdn, String userId, int lang,Connection con)
	{
		String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(Msisdn);
		logger.info("Inside function addsubscriber() where  Number ["+interMsisdn+"]");
                 
               String result=statusCheck(interMsisdn,con);
               logger.info("sub-Type is ........."+result);
               
                
		int planId = Integer.parseInt(TSSJavaUtil.instance().getAppConfigParam("DEFAULT_RATE_PLAN")); 

		int totalSubs = 0;
		String imsi = "123456781011121";
		String subscriber_type="N" ; // O=postpaid, P=prepaid
		String query = "";

		StringBuffer imsiBuf = new StringBuffer();
		/*
		   if (cfuProcess(interMsisdn, imsiBuf, SERVICE_RETRIEVE_IMSI) != 1)
		   {
		   return 0;
		   }
		   imsi = imsiBuf.toString();
		 */	
		logger.info("imsi = "+ imsi);

		//con = conPool.getConnection();

		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try 
		{	
			String ret_str = "";
			SetVariable sv = new SetVariable();
			sv.setMsisdn(interMsisdn);
			sv.setPlan(planId);
			sv.setLang(lang);
			sv.setInterface("C");
			sv.setUpdatedBy(userId);
		//	sv.setSubType("P");
                      sv.setSubType(result);

			CRBTRequest crbt_req = new CRBTRequest();
			crbt_req.constructQuery(1,sv);
			int ret_val = crbt_req.send();
			if (ret_val == 0)
			{
				ret_str = "SuccessFul";
			}
			else
			{
				ret_str = crbt_req.err_string;
			}

			//	insertIntoRbtOpLog(interMsisdn, rbtCode, 1, "Default", "N", 1);
			//	insertIntoSubscriberAudit(interMsisdn, 1, "Default RBT is set");
			logger.info(" CRE::::returned"+ret_str);
			return ret_str;// retVal;

		}
		catch (Exception sqle)
		{
			/*	try {
				con.rollback();
				if (rs != null) rs.close();
				if (pstmt != null) pstmt.close();
				} catch (Exception e) {}
				sqle.printStackTrace();
				return 0;*/
		}
		/*finally 
		{
			conPool.free(con);
		}*/

		return "Please try later";// retVal;*/
	}
	
	public int actSubscriber_HLR(String Msisdn)
	{

		String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(Msisdn);
		logger.info("Activate subscriber Number by HLR="+interMsisdn);
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try
		{
			// **** 3. Check interMsisdn -  charging DONE , Activate HLR Flag
			StringBuffer imsiBuf = new StringBuffer("123456789");;

			int service = SERVICE_ACTIVATE_SS;

			if (cfuProcess(interMsisdn, imsiBuf, service) != 1)
			{
				logger.info("ERROR - SERVICE_ACTIVATE_SS");
				return -2;
			}

		}//try
		catch (Exception sqle)
		{
			sqle.printStackTrace();
			return 0;	
		}
		finally
		{
		} 
		return 1;            		
	}//actSubscriber_HLR

	
	public String unsubscribe(String Msisdn, String userId, int lang,Connection con) 
	{
		String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(Msisdn);
		logger.info(" Inside function unsubscribe().. where  Number ["+interMsisdn+"]");

           String result= statusCheck(interMsisdn,con);  
           logger.info(" Inside function unsubscribe().. where  Number ["+interMsisdn+"] and status ["+result+"]");  
		int planId = Integer.parseInt(TSSJavaUtil.instance().getAppConfigParam("DEFAULT_RATE_PLAN")); 

		int totalSubs = 0;
		String imsi = "123456781011121";
		String subscriber_type="N" ; // O=postpaid, P=prepaid
		String query = "";

		StringBuffer imsiBuf = new StringBuffer();
		/*
		   if (cfuProcess(interMsisdn, imsiBuf, SERVICE_RETRIEVE_IMSI) != 1)
		   {
		   return 0;
		   }
		   imsi = imsiBuf.toString();
		 */	
		//logger.info("imsi = "+ imsi);

		//con = conPool.getConnection();

		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try 
		{	String ret_str = "";
			SetVariable sv = new SetVariable();
			sv.setMsisdn(interMsisdn);
			sv.setPlan(planId);
			sv.setLang(lang);
			sv.setInterface("C");
			sv.setUpdatedBy(userId);
			//sv.setSubType("P");
                         sv.setSubType(result);

			CRBTRequest crbt_req = new CRBTRequest();
			crbt_req.constructQuery(2,sv);
			int ret_val = crbt_req.send();
			if (ret_val == 0)
			{
				ret_str = "SuccessFul";
			}
			else
			{
				ret_str = crbt_req.err_string;
			}

			//	insertIntoRbtOpLog(interMsisdn, rbtCode, 1, "Default", "N", 1);
			//	insertIntoSubscriberAudit(interMsisdn, 1, "Default RBT is set");
			logger.info(" CRE::::returned"+ret_str);
			return ret_str;// retVal;

		}
		catch (Exception sqle)
		{
			/*	try {
				con.rollback();
				if (rs != null) rs.close();
				if (pstmt != null) pstmt.close();
				} catch (Exception e) {}
				sqle.printStackTrace();
				return 0;*/
		}
		/*finally 
		{
			conPool.free(con);
		}*/

		return "Please try later";// retVal;*/
	}
	public int unsubscribe(String Msisdn, String userId) 
	{
		String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(Msisdn);
		logger.info("in unsubscribe()"+interMsisdn);

		String subscriber_type = "N";
		String query = "", imsi;
		StringBuffer imsiBuf = new StringBuffer();;
		int planId = 0;

		con = conPool.getConnection();

		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try 
		{
			query = "select CORP_ID from CRBT_SUBSCRIBER_MASTER where MSISDN = ?";

			pstmt = con.prepareStatement(query);
			pstmt.setString(1, interMsisdn);

			rs = pstmt.executeQuery();

			if(rs.next()) 
			{
				if(rs.getInt("CORP_ID")>0)
				{
					logger.info(interMsisdn+ " is a corp user cnt unsubscribe corpid= "+ rs.getLong("CORP_ID"));
					rs.close();
					pstmt.close();
					return -6;
				}
			}

			rs.close();
			pstmt.close();
			//to be used in real use
			/*	if (cfuProcess(interMsisdn, imsiBuf, SERVICE_RETRIEVE_IMSI) != 1)
				{
				logger.info("retrun from cfuProcess");
				return 0;
				}
				imsi = imsiBuf.toString();
			 */
			con.setAutoCommit(false);
			query = "select PLAN_INDICATOR, SUB_TYPE from CRBT_SUBSCRIBER_MASTER where MSISDN = ?";
			//query = "select PLAN_INDICATOR from CRBT_SUBSCRIBER_MASTER where MSISDN = ?";

			pstmt = con.prepareStatement(query);
			pstmt.setString(1, interMsisdn);

			rs = pstmt.executeQuery();

			if(rs.next())
			{
				planId = rs.getInt("PLAN_INDICATOR");
				subscriber_type=rs.getString("SUB_TYPE");
			}
			else
			{
				return -3;
			}
			rs.close();

			query = "delete from CRBT_SUBSCRIBER_MASTER where msisdn = ?";
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, interMsisdn);
			pstmt.executeUpdate();	
			pstmt.close();
			/*Uncomment if needed*/
			query = "delete from CRBT_WALLET_MASTER where msisdn = ?";
			logger.info(query);
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, interMsisdn);
			pstmt.executeUpdate();	
			pstmt.close();

			query = "delete from CRBT_WALLET_CONTENT where msisdn = ?";
			logger.info(query);
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, interMsisdn);
			pstmt.executeUpdate();	
			pstmt.close();

			query = "delete from CRBT_GROUP_DETAIL where msisdn = ?";
			logger.info(query);
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, interMsisdn);
			pstmt.executeUpdate();	
			pstmt.close();

			//subscriber_type="P";
			if (subscriber_type.equalsIgnoreCase("P"))
			{
				int retVal = genPrePaidCDR (interMsisdn, planId, "U");
				if (retVal != 1)
				{
					con.rollback();
					return 0;
				}
			}
			else
			{
				int retValCDR = genPostPaidCDR(interMsisdn, planId, "U");
				if (retValCDR != 1)
				{
					con.rollback();
					return 0;
				}
			}

			if(userId.equalsIgnoreCase("xx"))
			{}
			else
			{
				insertIntoCustCareAudit(interMsisdn, 2, "UNSUBSCRIBED", subscriber_type, userId);
				insertIntoSubscriptionLog(interMsisdn, subscriber_type,  "U", "N", userId);
			}
			con.commit();
			if (rs != null) rs.close();
			if (pstmt != null) pstmt.close();

		}//try
		catch (SQLException sqle)
		{
			try {
				con.rollback();
				if (rs != null) rs.close();
				if (pstmt != null) pstmt.close();
			} catch (Exception e) {}
			sqle.printStackTrace();
			return 0;
		}
		finally 
		{
			conPool.free(con);
		}
		//	/* ** to be used in real
		if (cfuProcess(interMsisdn, imsiBuf, SERVICE_DEACTIVATE_SS) != 1)
		{
			return -5;
		}

		return 1;
	} //unsubscribe

	
	public int searchHistory(String msisdn, ArrayList historyAl,Connection con)
	{
		String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(msisdn);
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String query;
				logger.info("Inside function searchHistory() where msisdn ["+interMsisdn+"]");
		try 
		{
			//con = conPool.getConnection();

			// Added by sanchit atri start
						String lastDigit=interMsisdn.substring(interMsisdn.length() - 1);
						String tableName="VCC_MAILBOX_LOG"+"_"+lastDigit;
						
						//query = "select date_format(REQUEST_DATE,'%d-%m-%Y %H:%i:%s') as REQ_DATE,MSISDN,INTERFACE,MAILBOX_TYPE,SERVICE_TYPE, UPDATED_BY,TYPE from VCC_MAILBOX_LOG where MSISDN = ? order by REQUEST_DATE desc";
						
						query = "select date_format(REQUEST_DATE,'%d-%m-%Y %H:%i:%s') as REQ_DATE,MSISDN,INTERFACE,MAILBOX_TYPE,SERVICE_TYPE, UPDATED_BY,TYPE from "+tableName+" where MSISDN = ? order by REQUEST_DATE desc";
			// Added by sanchit atri end					
			pstmt = con.prepareStatement(query);
			logger.info("DB Query ::"+query);
			pstmt.setString(1, interMsisdn);
			rs = pstmt.executeQuery();

			while (rs.next())
			{
				SubHistoryBean subHistory = new SubHistoryBean();
				subHistory.setDate(rs.getString("REQ_DATE"));
				subHistory.setMsisdn(rs.getString("MSISDN"));
				subHistory.setInterfaceType(rs.getString("INTERFACE"));
				subHistory.setMailBoxType(rs.getString("MAILBOX_TYPE"));
				subHistory.setServiceType(rs.getString("SERVICE_TYPE"));
				subHistory.setUpdatedBy(rs.getString("UPDATED_BY"));
				subHistory.setType(rs.getString("TYPE"));
				historyAl.add(subHistory);
			}
			logger.info("size of list is "+historyAl.size());
			
			
			if (rs != null) rs.close();
			if (pstmt != null) pstmt.close();

		}
		catch (Exception sqle)
		{
			logger.info("Exception inside searchHistory()"+sqle.getMessage());
			try {
				if (rs != null) rs.close();
				if (pstmt != null) pstmt.close();
			} catch (Exception exp) {}
			sqle.printStackTrace();
			return 0;
		}
		finally
		{
			try {
				if (rs != null) rs.close();
				if (pstmt != null) pstmt.close();
			} catch (Exception exp) {}
		}
		return 1;
	}//searchHistory
	
	
	public int checkStatus(String msisdn, ArrayList historyAl,Connection con)
	{
		String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(msisdn);
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String query;
				logger.info("Inside function searchHistory() where msisdn ["+interMsisdn+"]");
		try 
		{
			//con = conPool.getConnection();
			multi_table_enable=Integer.parseInt(TSSJavaUtil.instance().getKeyValue("MULTIPLE_TABLE_SUBSCRIPTION_CHECK"));
			// Added by sanchit atri start
			if (multi_table_enable==1) {
						String lastDigit=interMsisdn.substring(interMsisdn.length() - 1);
						String tableName1="VCC_SUBSCRIPTION_MASTER"+"_"+lastDigit;
						String tableName2="VCC_AUTH_USER"+"_"+lastDigit;
						query="select a.msisdn as MSISDN, a.SERVICE_TYPE as SERVICE_TYPE, a.STATUS as STATUS, a.EXPIRY_DATE as EXPIRY_DATE from "+tableName1+" a, "+tableName2+" b where a.msisdn= b.msisdn and  b.msisdn=?";
						//query = "select date_format(REQUEST_DATE,'%d-%m-%Y %H:%i:%s') as REQ_DATE,MSISDN,INTERFACE,MAILBOX_TYPE,SERVICE_TYPE, UPDATED_BY,TYPE from VCC_MAILBOX_LOG where MSISDN = ? order by REQUEST_DATE desc";
						
			} else {
				query="select a.msisdn as MSISDN, a.SERVICE_TYPE as SERVICE_TYPE,a.STATUS as STATUS, a.EXPIRY_DATE  as EXPIRY_DATE from VCC_SUBSCRIPTION_MASTER a, VCC_AUTH_USER b where a.msisdn= b.msisdn and  b.msisdn=?";
			}
			//query = "select date_format(REQUEST_DATE,'%d-%m-%Y %H:%i:%s') as REQ_DATE,MSISDN,INTERFACE,MAILBOX_TYPE,SERVICE_TYPE, UPDATED_BY,TYPE from "+tableName+" where MSISDN = ? order by REQUEST_DATE desc";
			// Added by sanchit atri end					
			pstmt = con.prepareStatement(query);
			logger.info("DB Query ::"+query);
			pstmt.setString(1, interMsisdn);
			rs = pstmt.executeQuery();

			while (rs.next())
			{
				SubHistoryBean subHistory = new SubHistoryBean();
				//subHistory.setDate(rs.getString("REQ_DATE"));
				subHistory.setMsisdn(rs.getString("MSISDN"));
				//subHistory.setInterfaceType(rs.getString("INTERFACE"));
				//subHistory.setMailBoxType(rs.getString("MAILBOX_TYPE"));
				subHistory.setServiceType(rs.getString("SERVICE_TYPE"));
			//	subHistory.setUpdatedBy(rs.getString("UPDATED_BY"));
			//	subHistory.setType(rs.getString("TYPE"));
				subHistory.setStatus(rs.getString("STATUS"));
				subHistory.setExpiryDate(rs.getString("EXPIRY_DATE"));
				historyAl.add(subHistory);
			}
			logger.info("size of list is "+historyAl.size());
			
			
			if (rs != null) rs.close();
			if (pstmt != null) pstmt.close();

		}
		catch (Exception sqle)
		{
			logger.info("Exception inside searchHistory()"+sqle.getMessage());
			try {
				if (rs != null) rs.close();
				if (pstmt != null) pstmt.close();
			} catch (Exception exp) {}
			sqle.printStackTrace();
			return 0;
		}
		finally
		{
			try {
				if (rs != null) rs.close();
				if (pstmt != null) pstmt.close();
			} catch (Exception exp) {}
		}
		return 1;
	} //check User status

	
	
	public int searchMailBoxRecord(String msisdn, ArrayList historyAl,Connection con,String serviceType)
	{
		String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(msisdn);
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String query;
				logger.info("Inside function searchMailBoxRecord() where msisdn ["+interMsisdn+"] service Type ["+serviceType+"]");
		try 
		{
			//con = conPool.getConnection();

			query = "select date_format(CALL_TIME,'%d-%m-%Y %H:%i:%s') as TIME,ORIGINATING_NUMBER,DESTINATION_NUMBER,date_format(RETRIVAL_TIME,'%d-%m-%Y %H:%i:%s') as RETRIVAL_TIME,SERVICE_TYPE,RECORDING_DURATION,MESSAGE_STATUS from VCC_VOICE_MSG where DESTINATION_NUMBER = ? and SERVICE_TYPE=? order by CALL_TIME desc";
			pstmt = con.prepareStatement(query);
			logger.info("DB Query ::"+query);
			pstmt.setString(1, interMsisdn);
			pstmt.setString(2,serviceType);
			rs = pstmt.executeQuery();

			while (rs.next())
			{
				SubHistoryBean subHistory = new SubHistoryBean();
				subHistory.setDate(rs.getString("TIME"));
				subHistory.setOriginNumber(rs.getString("ORIGINATING_NUMBER"));
				subHistory.setMsisdn(rs.getString("DESTINATION_NUMBER"));
				subHistory.setRetrvTime(rs.getString("RETRIVAL_TIME"));
				subHistory.setServiceType(rs.getString("SERVICE_TYPE"));
				subHistory.setRecordingDuratn(rs.getString("RECORDING_DURATION"));
				subHistory.setStatus(rs.getString("MESSAGE_STATUS"));
				historyAl.add(subHistory);
			}
			logger.info("size of list is "+historyAl.size());
			
			
			if (rs != null) rs.close();
			if (pstmt != null) pstmt.close();

		}
		catch (Exception sqle)
		{
			logger.info("Exception inside searchHistory()"+sqle.getMessage());
			try {
				if (rs != null) rs.close();
				if (pstmt != null) pstmt.close();
			} catch (Exception exp) {}
			sqle.printStackTrace();
			return 0;
		}
		finally
		{
			try {
				if (rs != null) rs.close();
				if (pstmt != null) pstmt.close();
			} catch (Exception exp) {}
		}
		return 1;
	}//searchMailBox
	public int searchRecording(String msisdn, ArrayList historyAl,Connection con,String basedOn,String status,String startDate,String endDate)
	{
		String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(msisdn);
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String query="";
		String serverName="NA"; // added by Avishkar
		logger.info("Inside function searchMailBoxRecord() where msisdn ["+interMsisdn+"] start Date ["+startDate+"] end date ["+endDate+"] based On ["+basedOn+"] status["+status+"]");
		try 
		{
			//con = conPool.getConnection();
			if(basedOn.equalsIgnoreCase("1"))
			{
				/*query = "select date_format(CALL_TIME,'%d-%m-%Y %H:%i:%s') as TIME,SERVER_ID,ORIGINATING_NUMBER,DESTINATION_NUMBER,CALL_DURATION," +
						"MSG_LENGTH,SERVICE_TYPE from VCC_FWD_CALL_LOGS where ORIGINATING_NUMBER = ? and MSG_LENGTH != 0 and date(CALL_TIME) " +
						"between ? and ? order by CALL_TIME desc";*/
				if(status.equals("BOTH"))
				{
					query = "SELECT DATE_FORMAT(CALL_TIME,'%d-%m-%Y %H:%i:%s') AS TIME,SERVER_ID,ORIGINATING_NUMBER,DESTINATION_NUMBER,CALL_DURATION," +
						"MSG_LENGTH,SERVICE_TYPE FROM VCC_FWD_CALL_LOGS_HISTORY WHERE ORIGINATING_NUMBER =? AND MSG_LENGTH != 0 AND DATE(CALL_TIME) " +
						"BETWEEN ? AND (SELECT DATE_SUB(DATE(MIN(CALL_TIME)),INTERVAL 1 DAY) FROM VCC_FWD_CALL_LOGS) " +
						"UNION SELECT DATE_FORMAT(CALL_TIME,'%d-%m-%Y %H:%i:%s') AS TIME,SERVER_ID,ORIGINATING_NUMBER,DESTINATION_NUMBER," +
						"CALL_DURATION,MSG_LENGTH,SERVICE_TYPE FROM VCC_FWD_CALL_LOGS WHERE ORIGINATING_NUMBER =? AND MSG_LENGTH != 0 AND " +
						"DATE(CALL_TIME) <= ? ORDER BY TIME DESC";
				}
				else if(status.equals("ONLY_FWD_CALL_LOGS"))
				{
					query="SELECT DATE_FORMAT(CALL_TIME,'%d-%m-%Y %H:%i:%s') AS TIME,SERVER_ID,ORIGINATING_NUMBER,DESTINATION_NUMBER," +
						"CALL_DURATION,MSG_LENGTH,SERVICE_TYPE FROM VCC_FWD_CALL_LOGS WHERE ORIGINATING_NUMBER =? AND MSG_LENGTH != 0 AND " +
						"DATE(CALL_TIME) BETWEEN ? AND ? ORDER BY TIME DESC";
				}
				else if(status.equals("ONLY_FWD_CALL_LOGS_HISTORY"))
				{
					query="SELECT DATE_FORMAT(CALL_TIME,'%d-%m-%Y %H:%i:%s') AS TIME,SERVER_ID,ORIGINATING_NUMBER,DESTINATION_NUMBER," +
							"CALL_DURATION,MSG_LENGTH,SERVICE_TYPE FROM VCC_FWD_CALL_LOGS_HISTORY WHERE ORIGINATING_NUMBER =? AND MSG_LENGTH != 0 AND " +
							"DATE(CALL_TIME) BETWEEN ? AND ? ORDER BY TIME DESC";
				}
				else
				{
					logger.info("Something fishy happened. Please trace the logs.Msisdn["+msisdn+"] Start["+startDate+"] " +
							"End["+endDate+"] BasedOn["+basedOn+"] Status["+status+"]");
				}
			}
			else if(basedOn.equalsIgnoreCase("2"))
			{
				//query = "select date_format(CALL_TIME,'%d-%m-%Y %H:%i:%s') as CALL_TIME,ORIGINATING_NUMBER,DESTINATION_NUMBER,CALL_DURATION,MSG_LENGTH,SERVICE_TYPE from VCC_FWD_CALL_LOGS where DESTINATION_NUMBER = ? and  date_format(date_format(CALL_TIME,'%d-%m-%y'),'%d-%m-%y') >= date_format(?, '%d-%m-%y') and date_format(date_format(CALL_TIME,'%d-%m-%y'),'%d-%m-%y') <= date_format(?, '%d-%m-%y') order by date_format(CALL_TIME,'%d-%m-%Y %H:%i:%s') desc";
				/*query = "select date_format(CALL_TIME,'%d-%m-%Y %H:%i:%s') as TIME,SERVER_ID,ORIGINATING_NUMBER,DESTINATION_NUMBER,CALL_DURATION," +
						"MSG_LENGTH,SERVICE_TYPE from VCC_FWD_CALL_LOGS where DESTINATION_NUMBER = ? and MSG_LENGTH != 0 and date(CALL_TIME) " +
						"between ? and ? order by CALL_TIME desc";*/

				if(status.equals("BOTH"))
				{
					query = "SELECT DATE_FORMAT(CALL_TIME,'%d-%m-%Y %H:%i:%s') AS TIME,SERVER_ID,ORIGINATING_NUMBER,DESTINATION_NUMBER,CALL_DURATION," +
							"MSG_LENGTH,SERVICE_TYPE FROM VCC_FWD_CALL_LOGS_HISTORY WHERE DESTINATION_NUMBER =? AND MSG_LENGTH != 0 AND DATE(CALL_TIME) " +
							"BETWEEN ? AND (SELECT DATE_SUB(DATE(MIN(CALL_TIME)),INTERVAL 1 DAY) FROM VCC_FWD_CALL_LOGS) " +
							"UNION SELECT DATE_FORMAT(CALL_TIME,'%d-%m-%Y %H:%i:%s') AS TIME,SERVER_ID,ORIGINATING_NUMBER,DESTINATION_NUMBER," +
							"CALL_DURATION,MSG_LENGTH,SERVICE_TYPE FROM VCC_FWD_CALL_LOGS WHERE DESTINATION_NUMBER =? AND MSG_LENGTH != 0 AND " +
							"DATE(CALL_TIME) <= ? ORDER BY TIME DESC";
				}
				else if(status.equals("ONLY_FWD_CALL_LOGS"))
				{
					query="SELECT DATE_FORMAT(CALL_TIME,'%d-%m-%Y %H:%i:%s') AS TIME,SERVER_ID,ORIGINATING_NUMBER,DESTINATION_NUMBER," +
						"CALL_DURATION,MSG_LENGTH,SERVICE_TYPE FROM VCC_FWD_CALL_LOGS WHERE DESTINATION_NUMBER =? AND MSG_LENGTH != 0 AND " +
						"DATE(CALL_TIME) BETWEEN ? AND ? ORDER BY TIME DESC";
				}
				else if(status.equals("ONLY_FWD_CALL_LOGS_HISTORY"))
				{
					query="SELECT DATE_FORMAT(CALL_TIME,'%d-%m-%Y %H:%i:%s') AS TIME,SERVER_ID,ORIGINATING_NUMBER,DESTINATION_NUMBER," +
							"CALL_DURATION,MSG_LENGTH,SERVICE_TYPE FROM VCC_FWD_CALL_LOGS_HISTORY WHERE DESTINATION_NUMBER =? AND MSG_LENGTH != 0 AND " +
							"DATE(CALL_TIME) BETWEEN ? AND ? ORDER BY TIME DESC";
				}
				else
				{
					logger.info("Something fishy happened. Please trace the logs.Msisdn["+msisdn+"] Start["+startDate+"] " +
							"End["+endDate+"] BasedOn["+basedOn+"] Status["+status+"]");
				}
			}
			pstmt = con.prepareStatement(query);
			logger.info("DB Query ::"+query);
			
			if(status.equals("BOTH"))
			{
				pstmt.setString(1, interMsisdn);
				pstmt.setString(2, startDate);
				pstmt.setString(3, interMsisdn);
				pstmt.setString(4, endDate);
			}
			else
			{
				pstmt.setString(1, interMsisdn);
				pstmt.setString(2, startDate);
				pstmt.setString(3, endDate);
			}
			
			rs = pstmt.executeQuery();

			while (rs.next())
			{
				SubHistoryBean subHistory = new SubHistoryBean();
				System.out.println("Date : "+rs.getString("TIME"));
				subHistory.setDate(rs.getString("TIME"));
				subHistory.setOriginNumber(rs.getString("ORIGINATING_NUMBER"));
				subHistory.setMsisdn(rs.getString("DESTINATION_NUMBER"));
				subHistory.setCallDuration(rs.getString("CALL_DURATION"));
				subHistory.setServiceType(rs.getString("SERVICE_TYPE"));
				subHistory.setMsgLength(rs.getString("MSG_LENGTH"));
			// modified by Avishkar start
				serverName=TSSJavaUtil.instance().getKeyValue("SERVER_NAME"+rs.getString("SERVER_ID"));
				logger.debug("##############>>>>>>>>>>>>>>>>>> Server_Name:["+serverName+"] <<<<<<<<<<<<<<<<<<<####################");
				if ("".equalsIgnoreCase(serverName) || serverName.equalsIgnoreCase(null)) {
					serverName="NA";
				}
				subHistory.setServerId(serverName);
				//subHistory.setServerId("vas-svr-mg0"+rs.getString("SERVER_ID"));
			// modified by Avishkar ends
				historyAl.add(subHistory);
			}
			logger.info("size of list is "+historyAl.size());
			
			
			if (rs != null) rs.close();
			if (pstmt != null) pstmt.close();

		}
		catch (Exception sqle)
		{
			logger.info("Exception inside searchRecording()"+sqle.getMessage());
			try {
				if (rs != null) rs.close();
				if (pstmt != null) pstmt.close();
			} catch (Exception exp) {}
			sqle.printStackTrace();
			return 0;
		}
		finally
		{
			try {
				if (rs != null) rs.close();
				if (pstmt != null) pstmt.close();
			} catch (Exception exp) {}
		}
		return 1;
	}//searchRecording
	
	public int checkStatus(String msisdn, StringBuffer status, StringBuffer sub, SubscriberProfile subProfile,Connection con) 
	{   
		logger.info("Inside fucntion chechStatus()... where msisdn ["+msisdn+"] ");
		String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(msisdn);
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String query, imsi = "";
		long corpId=0;int lang1=1; int planId=-1; 
		String chargingMsisdn="";
		String corpName="Individual";
		int ret=-1;
		subscriber_type="N";

		try
		{
			//con = conPool.getConnection();

			query = "select * from OPERATOR_SUBSCRIBER where (to_number(STARTS_AT) <= to_number(?) and to_number(ENDS_AT) >= to_number(?) and to_number(?) not in (select to_number(EXCLUDE_NUM) from OPERATOR_SUBSCRIBER_EXCLUDE)) or to_number(?) in (select to_number(INCLUDE_NUM) from OPERATOR_SUBSCRIBER_INCLUDE)";

			pstmt = con.prepareStatement(query);
			pstmt.setString(1, interMsisdn);
			pstmt.setString(2, interMsisdn);
			pstmt.setString(3, interMsisdn);
			pstmt.setString(4, interMsisdn);

			rs = pstmt.executeQuery();

			if(!rs.next())
			{
				rs.close();
				pstmt.close();
				return -2;
			}
			if (rs != null) rs.close();

			//query = "select STATUS, IMSI, CORP_ID,LANGUAGE,PLAN_INDICATOR from CRBT_SUBSCRIBER_MASTER  where MSISDN = ?";
                         query="select STATUS,SUB_TYPE,IMSI, CORP_ID,LANGUAGE,PLAN_INDICATOR from CRBT_SUBSCRIBER_MASTER  where MSISDN = ?";
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, interMsisdn);
			rs = pstmt.executeQuery();
			ret = 2;
			if (rs.next())
			{
				ret = 1;
				status.append(rs.getString("STATUS"));
				subscriber_type=rs.getString("SUB_TYPE");
				imsi = rs.getString("IMSI");
				corpId=rs.getLong("CORP_ID");
				lang1=rs.getInt("LANGUAGE");
				planId=rs.getInt("PLAN_INDICATOR");
			}
			else
			{
				logger.info(interMsisdn+" is not subscribed");
				pstmt.close();
				rs.close();
				return -3; //not subscribed 
			}
			pstmt.close();
			rs.close();

			logger.info(interMsisdn +" is  in CorpId= "+corpId);
			query = "select CORP_ID, CORP_NAME, CHARGING_MSISDN, PLAN_INDICATOR from CRBT_CORP_DETAIL  where CORP_ID = ?";
			pstmt = con.prepareStatement(query);
			pstmt.setLong(1, corpId);
			rs = pstmt.executeQuery();
			if (rs.next())
			{
				if(corpId!=0) 
				{
					chargingMsisdn = rs.getString("CHARGING_MSISDN");
					corpName = rs.getString("CORP_NAME");
					planId=rs.getInt("PLAN_INDICATOR");
				}
				else
				{
					chargingMsisdn=interMsisdn;
					corpName="Individual";
				}	 

				subProfile.setChargingMsisdn(chargingMsisdn);
				subProfile.setPlanIndicator(planId);
				subProfile.setCorpId(corpId);
				subProfile.setCorpName(corpName); 
				subProfile.setLang(lang1); 
				logger.info(interMsisdn +" is  in planId= "+planId);
				ret = 1;
			}

			pstmt.close();
			rs.close();

			// subscriber type is detemined from IMSI, 
			//	if 9th digit of IMSI = 1 or 3 - PREPAID
			// 	if 9th digit of IMSI = 2 - POSTPAID
			//*** @JP July 21,2007 Kingston

			/*digit9_imsi=imsi.substring(8,9);
			  if(digit9_imsi.equalsIgnoreCase("1") || digit9_imsi.equalsIgnoreCase("3"))
			  {
			  subscriber_type="P";
			  logger.info("subscriber_type= PREPAID; 9th digit imsi= "+digit9_imsi);
			  }
			  else if(digit9_imsi.equalsIgnoreCase("2"))
			  {
			  subscriber_type="O";
			  logger.info("subscriber_type= POSTPAID; 9th digit imsi= "+digit9_imsi);
			  }*/

			sub.append(subscriber_type);
			//	sub.append("P");
			subProfile.setSubType(subscriber_type);
			return ret;
			/* 
			   query = "select SUBSCRIBER_TYPE from IMSI_RANGE where to_number(START_AT) <= to_number(?) and to_number(ENDS_AT) >= to_number(?)";
			   pstmt = con.prepareStatement(query);
			   pstmt.setString(1, imsi);
			   pstmt.setString(2, imsi);

			   rs = pstmt.executeQuery();
			   logger.info(query);

			   if (rs.next()) 
			   {
			   sub.append(rs.getString("SUBSCRIBER_TYPE"));
			   }

			   if (rs != null) rs.close();
			   if (pstmt != null) pstmt.close();
			   logger.info(ret);
			   return ret;
			 */

		} //try
		catch (Exception sqle)
		{
			try {
				if (rs != null) rs.close();
				if (pstmt != null) pstmt.close();
			} catch (Exception exp) {}
			sqle.printStackTrace();
			return 0;
		}
		/*finally
		{
			conPool.free(con);
		}*/
	} //checkStatus

	// Added by AbhiShek Rana for showing sms history.
	
	public int searchSmsHistory(String msisdn, ArrayList historyAl,Connection con,String startDate,String endDate){
		
		String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(msisdn);
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String query="";
		logger.info("Inside function searchSmsHistory() where msisdn ["+interMsisdn+"] Date ["+startDate+"]");
		try 
		{
			query = "select date_format(SUBMIT_TIME,'%d-%m-%Y %H:%i:%s') as SUBMIT_TIME,ORIGINATING_NUMBER,DESTINATION_NUMBER,MESSAGE_TEXT from smsg_sms_response_mdr where DESTINATION_NUMBER=? and date_format(SUBMIT_TIME,'%Y-%m-%d') between ? and ? order by SUBMIT_TIME desc";			
			pstmt = con.prepareStatement(query);
			logger.info("DB Query ::"+query);
			pstmt.setString(1, interMsisdn);
			pstmt.setString(2, startDate);
			pstmt.setString(3, endDate);
			rs = pstmt.executeQuery();

			while (rs.next())
			{
				SmsHistoryBean smsHistory = new SmsHistoryBean();
				smsHistory.setDate(rs.getString("SUBMIT_TIME"));
				smsHistory.setOriginationNumber(rs.getString("ORIGINATING_NUMBER"));
				smsHistory.setDestinationNumber(rs.getString("DESTINATION_NUMBER"));
				smsHistory.setMessage(rs.getString("MESSAGE_TEXT"));			
				historyAl.add(smsHistory);
			}
			logger.info("size of list is "+historyAl.size());
			
			
			if (rs != null) rs.close();
			if (pstmt != null) pstmt.close();

		}
		catch (Exception sqle)
		{
			logger.info("Exception inside searchSmsHistory()"+sqle.getMessage());
			try {
				if (rs != null) rs.close();
				if (pstmt != null) pstmt.close();
			} catch (Exception exp) {}
			sqle.printStackTrace();
			return 0;
		}
		finally
		{
			try {
				if (rs != null) rs.close();
				if (pstmt != null) pstmt.close();
			} catch (Exception exp) {}
		}
		return 1;

	}
	
	
		
	public int searchRbtHistory(String msisdn, ArrayList historyAl,Connection con)
	{
		String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(msisdn);
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String query;
		logger.info("Inside function searchRbtHistory()..... where msisdn ["+msisdn+"]");

		try 
		{
			//con = conPool.getConnection();
		/*

			query = "select EVENT_TIME, OP_CODE, RBT_CODE, EVENT_CHARGED, INTERFACE_TYPE, UPDATED_BY from CRBT_ALBUM_OP_LOG where MSISDN = ? order by EVENT_TIME desc";
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, interMsisdn);
			rs = pstmt.executeQuery();

			while (rs.next())
			{
				SubscriberHistory subHistory = new SubscriberHistory();
				subHistory.setDate(rs.getString("EVENT_TIME"));
				subHistory.setActivity(rs.getString("OP_CODE"));
				subHistory.setRbtCode(rs.getString("RBT_CODE"));
				subHistory.setWas_charged(rs.getString("EVENT_CHARGED"));
				subHistory.setInterface_Type(rs.getString("INTERFACE_TYPE"));
				subHistory.setUpdate_Type(rs.getString("UPDATED_BY"));
				historyAl.add(subHistory);
			}
			if (rs != null) rs.close();
		*/

			query = "select a.*,b.action ,(case  b.action when 3 then 30 when 31 then 1 when 32 then 7 when 33 then 14 when 34 then 21 when 8 then 30 when 81 then 1 when 82 then 7 when 83 then 14 when 84 then 21 else 30 end )as validity_days from (select MSISDN, to_char(EVENT_TIME,'dd-mm-yyyy hh24:mi:ss') as E_TIME,EVENT_TIME, OP_CODE, RBT_CODE, EVENT_CHARGED, INTERFACE_TYPE, UPDATED_BY from CRBT_ALBUM_OP_LOG where MSISDN=?  UNION select MSISDN,to_char(EVENT_TIME,'dd-mm-yyyy hh24:mi:ss') as E_TIME, EVENT_TIME, OP_CODE, RBT_CODE, EVENT_CHARGED, INTERFACE_TYPE, UPDATED_BY from CRBT_ALBUM_OP_LOG_HISTORY  where MSISDN=?)a,crbt_cdrs b where a.MSISDN=b.MSISDN(+) and a.RBT_CODE=b.RBT_CODE(+) and a.EVENT_TIME=b.CREATE_DATE(+) order by a.EVENT_TIME desc";
			pstmt = con.prepareStatement(query);
			logger.info("DB QUERY::;"+query);
			pstmt.setString(1, interMsisdn);
			pstmt.setString(2, interMsisdn);
			rs = pstmt.executeQuery();

			while (rs.next())
			{
				SubscriberHistory subHistory = new SubscriberHistory();
				subHistory.setDate(rs.getString("E_TIME"));
				subHistory.setActivity(rs.getString("OP_CODE"));
				subHistory.setRbtCode(rs.getString("RBT_CODE"));
				subHistory.setWas_charged(rs.getString("EVENT_CHARGED"));
				subHistory.setInterface_Type(rs.getString("INTERFACE_TYPE"));
				subHistory.setUpdate_Type(rs.getString("UPDATED_BY"));
				subHistory.setValidityDays(rs.getString("validity_days"));
				historyAl.add(subHistory);
			}

			if (rs != null) rs.close();
			if (pstmt != null) pstmt.close();
		}
		catch (Exception sqle)
		{
			try {
				if (rs != null) rs.close();
				if (pstmt != null) pstmt.close();
			} catch (Exception exp) {}
			sqle.printStackTrace();
			return 0;
		}
		finally
		{
			try {
				if (rs != null) rs.close();
				if (pstmt != null) pstmt.close();
			} catch (Exception exp) {}
			
		}
		return 1;
	} //searchRbtHistory

	public int searchIvrStats(String msisdn, ArrayList historyAl,Connection con)  
	{
		String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(msisdn);
		logger.info("Inside function  searchIvrStats()....");
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String query;

		try 
		{
			//con = conPool.getConnection();

			query = "select to_char(CALL_TIME,'dd-mm-yyyy hh24:mi:ss') as CALL_TIME, REQUEST_COUNT, SUBSCRIBER_TYPE, CALL_DURATION from CRBT_IVR_CALL_LOG where MSISDN = ? order by CALL_TIME desc";
			//query = "select START_TIME, REQUEST_DATA, REQUEST_FROM, UPDATED_BY from CRBT_ACTIVITY_DETAIL_LOG  where msisdn = ? and REQUEST_FROM='I' order by START_TIME desc";
			pstmt = con.prepareStatement(query);
			logger.info("DB Query :::::"+query);
			pstmt.setString(1, interMsisdn);
			rs = pstmt.executeQuery();

			while (rs.next())
			{
				SubscriberHistory subHistory = new SubscriberHistory();
				subHistory.setDate(rs.getString("CALL_TIME"));
				subHistory.setRequestCount(rs.getInt("REQUEST_COUNT"));
				subHistory.setSub_type(rs.getString("SUBSCRIBER_TYPE"));
				subHistory.setCallduration(rs.getInt("CALL_DURATION"));
				historyAl.add(subHistory);
			}
			if (rs != null) rs.close();
			if (pstmt != null) pstmt.close();
			query = "select to_char(CALL_TIME,'dd-mm-yyyy hh24:mi:ss') as CALL_TIME, REQUEST_COUNT, SUBSCRIBER_TYPE, CALL_DURATION from CRBT_IVR_CALL_LOG_HISTORY where MSISDN = ? order by CALL_TIME desc";
			//   query = "select START_TIME, REQUEST_DATA, REQUEST_FROM, UPDATED_BY from CRBT_ACTIVITY_DETAIL_LOG_HISTORY  where msisdn = ? and REQUEST_FROM='U' order by START_TIME desc";
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, interMsisdn);
			logger.info("DB Query :::::"+query);
			rs = pstmt.executeQuery();

			while (rs.next())
			{
				SubscriberHistory subHistory = new SubscriberHistory();
				subHistory.setDate(rs.getString("CALL_TIME"));
				subHistory.setRequestCount(rs.getInt("REQUEST_COUNT"));
				subHistory.setSub_type(rs.getString("SUBSCRIBER_TYPE"));
				subHistory.setCallduration(rs.getInt("CALL_DURATION"));
				historyAl.add(subHistory);
			}
			if (rs != null) rs.close();
			if (pstmt != null) pstmt.close();
		}
		catch (Exception sqle)
		{
			try {
				if (rs != null) rs.close();
				if (pstmt != null) pstmt.close();
			} catch (Exception exp) {}
			logger.error("Exception in searchIvrStats()....",sqle);
			sqle.printStackTrace();
			return 0;
		}
		finally
		{
			try {
				if (rs != null) rs.close();
				if (pstmt != null) pstmt.close();
			} catch (Exception exp) {}
	}
		return 1;
	} //searchIvrStats

	public int searchSmsStats(String msisdn, ArrayList historyAl,Connection con) 
	{
		logger.info("Inside function searchSmsStats()...");
		String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(msisdn);
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String query;
		try 
		{
			//con = conPool.getConnection();

			query = "select to_date(to_char(REQUEST_TIME,'dd-mm-yyyy hh24:mi:ss'),'dd-mm-yyyy hh24:mi:ss') as REQUEST_TIME, A.MESSAGE_TEXT REQUEST_MESSAGE, RESPONSE_TIME, B.MESSAGE_TEXT RESPONSE_MESSAGE from CRBT_SMS_REQUEST_MDR A, CRBT_SMS_RESPONSE_MDR B where A.REQUEST_ID = B.REQUEST_ID and A.MSISDN = ? order by REQUEST_TIME desc";
			//	query = "select START_TIME, REQUEST_DATA, REQUEST_FROM, UPDATED_BY from CRBT_ACTIVITY_DETAIL_LOG  where msisdn = ? and REQUEST_FROM='S' order by START_TIME desc";
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, interMsisdn);
			logger.info("DB Query:::"+query);
			rs = pstmt.executeQuery();

			while (rs.next())
			{
				SubscriberHistory subHistory = new SubscriberHistory();
				subHistory.setDate(rs.getString("REQUEST_TIME"));
				subHistory.setRequestMessage(rs.getString("REQUEST_MESSAGE"));
				subHistory.setResponseTime(rs.getString("RESPONSE_TIME"));
				subHistory.setResponseMessage(rs.getString("RESPONSE_MESSAGE"));
				historyAl.add(subHistory);
			}
			if (rs != null) rs.close();
			if (pstmt != null) pstmt.close();
			query = "select to_char(REQUEST_TIME,'dd-mm-yyyy hh24:mi:ss') as REQUEST_TIME, A.MESSAGE_TEXT REQUEST_MESSAGE, RESPONSE_TIME, B.MESSAGE_TEXT RESPONSE_MESSAGE from CRBT_SMS_REQUEST_MDR_HISTORY A, CRBT_SMS_RESPONSE_MDR_HISTORY B where A.MSISDN = ? and A.REQUEST_ID = B.REQUEST_ID order by REQUEST_TIME desc";
			//	   query = "select START_TIME, REQUEST_DATA, REQUEST_FROM, UPDATED_BY from CRBT_ACTIVITY_DETAIL_LOG_HISTORY  where msisdn = ? and REQUEST_FROM='S' order by START_TIME desc";
			pstmt = con.prepareStatement(query);
			logger.info("DB QUERY:::"+query);
			pstmt.setString(1, interMsisdn);
			rs = pstmt.executeQuery();
			

			while (rs.next())
			{
				SubscriberHistory subHistory = new SubscriberHistory();
				subHistory.setDate(rs.getString("REQUEST_TIME"));
				subHistory.setRequestMessage(rs.getString("REQUEST_MESSAGE"));
				subHistory.setResponseTime(rs.getString("RESPONSE_TIME"));
				subHistory.setResponseMessage(rs.getString("RESPONSE_MESSAGE"));
				historyAl.add(subHistory);
			}
			if (rs != null) rs.close();
			if (pstmt != null) pstmt.close();
		}
		catch (Exception sqle)
		{
			try {
				if (rs != null) rs.close();
				if (pstmt != null) pstmt.close();
			} catch (Exception exp) {}
			sqle.printStackTrace();
			return 0;
		}
		finally
		{
			try {
			if (rs != null) rs.close();
			if (pstmt != null) pstmt.close();
		} catch (Exception exp) {}
		
			//conPool.free(con);
		}
		return 1;
	} //searchSmsStats

	public int searchWebStats(String msisdn, ArrayList historyAl,Connection con)
	{
		logger.info("Inside function searchWebStats().....");
		String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(msisdn);
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String query;

		try 
		{
			//con = conPool.getConnection();

			query = "select to_char(START_TIME,'dd-mm-yyyy hh24:mi:ss') as START_TIME, REQUEST_DATA, REQUEST_FROM, UPDATED_BY from CRBT_WEB_DETAIL_LOG  where msisdn = ? order by START_TIME desc";
			//query = "select START_TIME, REQUEST_DATA, REQUEST_FROM, UPDATED_BY from CRBT_ACTIVITY_DETAIL_LOG  where msisdn = ? and (REQUEST_FROM='W' or REQUEST_FROM='P') order by START_TIME desc";
			pstmt = con.prepareStatement(query);
			logger.info("DB Query:::"+query);
			pstmt.setString(1, interMsisdn);
			rs = pstmt.executeQuery();

			while (rs.next())
			{
				SubscriberHistory subHistory = new SubscriberHistory();
				subHistory.setDate(rs.getString("START_TIME"));
				subHistory.setRequestMessage(rs.getString("REQUEST_DATA"));
				subHistory.setInterface_Type(rs.getString("REQUEST_FROM"));
				subHistory.setUpdate_Type(rs.getString("UPDATED_BY"));
				historyAl.add(subHistory);
			}
			if (rs != null) rs.close();
			if (pstmt != null) pstmt.close();
			query = "select to_char(START_TIME,'dd-mm-yyyy hh24:mi:ss') as START_TIME, REQUEST_DATA, REQUEST_FROM, UPDATED_BY from CRBT_WEB_DETAIL_LOG_HISTORY  where msisdn = ? order by START_TIME desc";
			//   query = "select START_TIME, REQUEST_DATA, REQUEST_FROM, UPDATED_BY from CRBT_ACTIVITY_DETAIL_LOG_HISTORY  where msisdn = ? and (REQUEST_FROM='W' or REQUEST_FROM='P') order by START_TIME desc";
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, interMsisdn);
			logger.info("DB Query:::"+query);
			rs = pstmt.executeQuery();

			while (rs.next())
			{
				SubscriberHistory subHistory = new SubscriberHistory();
				subHistory.setDate(rs.getString("START_TIME"));
				subHistory.setRequestMessage(rs.getString("REQUEST_DATA"));
				subHistory.setInterface_Type(rs.getString("REQUEST_FROM"));
				subHistory.setUpdate_Type(rs.getString("UPDATED_BY"));
				historyAl.add(subHistory);
			}
			if (rs != null) rs.close();
			if (pstmt != null) pstmt.close();
		}
		catch (Exception sqle)
		{
			try {
				if (rs != null) rs.close();
				if (pstmt != null) pstmt.close();
			} catch (Exception exp) {}
			//sqle.printStackTrace();
			logger.error("Exception in searchWebStats....",sqle);
			return 0;
		}
		finally
		{
			try {
				if (rs != null) rs.close();
				if (pstmt != null) pstmt.close();
			} catch (Exception exp) {}
			
			//conPool.free(con);
		}
		return 1;
	} //searchWebStats

	public int searchUSSDStats(String msisdn, ArrayList historyAl,Connection con)  
	{
		logger.info("Inside function searchUSSDStats().....");
		String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(msisdn);
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String query;

		try
		{
			//con = conPool.getConnection();

			query = "select to_char(START_TIME,'dd-mm-yyyy hh24:mi:ss') as START_TIME, REQUEST_DATA, REQUEST_FROM, UPDATED_BY from CRBT_ACTIVITY_DETAIL_LOG  where msisdn = ? and REQUEST_FROM='U' order by START_TIME desc";
			pstmt = con.prepareStatement(query);
			logger.info("DB Query :::"+query);
			pstmt.setString(1, interMsisdn);
			rs = pstmt.executeQuery();

			while (rs.next())
			{
				SubscriberHistory subHistory = new SubscriberHistory();
				subHistory.setDate(rs.getString("START_TIME"));
				subHistory.setRequestMessage(rs.getString("REQUEST_DATA"));
				subHistory.setInterface_Type(rs.getString("REQUEST_FROM"));
				subHistory.setUpdate_Type(rs.getString("UPDATED_BY"));
				historyAl.add(subHistory);
			}
			if (rs != null) rs.close();
			pstmt.close();


			/*  query = "select START_TIME, REQUEST_DATA, REQUEST_FROM, UPDATED_BY from CRBT_ACTIVITY_DETAIL_LOG_HIST  where msisdn = ? and REQUEST_FROM='U' order by START_TIME desc";
			    pstmt = con.prepareStatement(query);
			    pstmt.setString(1, interMsisdn);
			    rs = pstmt.executeQuery();

			    while (rs.next())
			    {
			    SubscriberHistory subHistory = new SubscriberHistory();
			    subHistory.setDate(rs.getString("START_TIME"));
			    subHistory.setRequestMessage(rs.getString("REQUEST_DATA"));
			    subHistory.setInterface_Type(rs.getString("REQUEST_FROM"));
			    subHistory.setUpdate_Type(rs.getString("UPDATED_BY"));
			    historyAl.add(subHistory);
			    }
			    if (rs != null) rs.close();
			    if (pstmt != null) pstmt.close();*/

		}
		catch (Exception sqle)
		{
			try {
				if (rs != null) rs.close();
				if (pstmt != null) pstmt.close();
			} catch (Exception exp) {}
			logger.error("Exception in searchUSSDStats()...",sqle);
			return 0;
		}
		finally
		{
			try {
				if (rs != null) rs.close();
				if (pstmt != null) pstmt.close();
			} catch (Exception exp) {}
			
		}
		return 1;
	} //searchUSSDStats


	public int searchUSSDStats_old(String msisdn, ArrayList historyAl)
	{
		String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(msisdn);
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String query;

		try 
		{
			con = conPool.getConnection();

			//query = "select REQUEST_TIME, A.MESSAGE_TEXT REQUEST_MESSAGE, RESPONSE_TIME, B.MESSAGE_TEXT RESPONSE_MESSAGE from CRBT_USSD_REQUEST_MDR A, CRBT_USSD_RESPONSE_MDR B where A.REQUEST_ID = B.REQUEST_ID and A.MSISDN = ? order by REQUEST_TIME desc";
			query = "select to_char(REQUEST_TIME,'dd-mm-yyyy hh24:mi:ss') as REQUEST_TIME, MESSAGE_TEXT REQUEST_MESSAGE from CRBT_USSD_REQUEST_MDR where MSISDN = ? order by REQUEST_TIME desc";
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, interMsisdn);
			rs = pstmt.executeQuery();

			while (rs.next())
			{
				SubscriberHistory subHistory = new SubscriberHistory();
				subHistory.setDate(rs.getString("REQUEST_TIME"));
				subHistory.setRequestMessage(rs.getString("REQUEST_MESSAGE"));
				//					subHistory.setResponseTime(rs.getString("RESPONSE_TIME"));
				//					subHistory.setResponseMessage(rs.getString("RESPONSE_MESSAGE"));
				historyAl.add(subHistory);
			}
			if (rs != null) rs.close();
			pstmt.close();
			//query = "select REQUEST_TIME, A.MESSAGE_TEXT REQUEST_MESSAGE, RESPONSE_TIME, B.MESSAGE_TEXT RESPONSE_MESSAGE from CRBT_USSD_REQUEST_MDR_HISTORY A, CRBT_USSD_RESPONSE_MDR_HISTORY B where A.MSISDN = ? and A.REQUEST_ID = B.REQUEST_ID order by REQUEST_TIME desc";
			query = "select to_char(REQUEST_TIME,'dd-mm-yyyy hh24:mi:ss') as REQUEST_TIME, MESSAGE_TEXT REQUEST_MESSAGE from CRBT_USSD_REQUEST_MDR_HISTORY where MSISDN = ? order by REQUEST_TIME desc";
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, interMsisdn);
			rs = pstmt.executeQuery();

			while (rs.next())
			{
				SubscriberHistory subHistory = new SubscriberHistory();
				subHistory.setDate(rs.getString("REQUEST_TIME"));
				subHistory.setRequestMessage(rs.getString("REQUEST_MESSAGE"));
				//					subHistory.setResponseTime(rs.getString("RESPONSE_TIME"));
				//					subHistory.setResponseMessage(rs.getString("RESPONSE_MESSAGE"));
				historyAl.add(subHistory);
			}
			if (rs != null) rs.close();
			if (pstmt != null) pstmt.close();
		}
		catch (Exception sqle)
		{
			try {
				if (rs != null) rs.close();
				if (pstmt != null) pstmt.close();
			} catch (Exception exp) {}
			sqle.printStackTrace();
			return 0;
		}
		finally
		{
			conPool.free(con);
		}
		return 1;
	} //searchUSSDStats

	public int insertIntoCustCareAudit (String msisdn, int actType, String strActDetail, String sub_type, String userId) 
	{
		logger.info("insertIntoCustCareAudit()");
		PreparedStatement pstmt = null;
		try 
		{
			String query = "insert into CRBT_WEB_DETAIL_LOG (MSISDN, START_TIME, REQUEST_TYPE, REQUEST_DATA, SUBSCRIBER_TYPE, REQUEST_FROM,UPDATED_BY) values (?, sysdate, ?, ?, ?, ?, ?)";

			pstmt = con.prepareStatement(query);
			pstmt.setString(1, msisdn);
			pstmt.setInt(2, actType);
			pstmt.setString(3, strActDetail);
			pstmt.setString(4, sub_type);
			pstmt.setString(5, "C");
			pstmt.setString(6, userId);
			pstmt.executeUpdate();
			pstmt.close();
			return 1; //Success inserted in CCAudit 
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
	} //insertIntoCustCareAudit

	public int insertIntoSubscriptionLog (String msisdn, String sub_type, String act, String charged, String userId) 
	{
		logger.info("insertIntoSubscriptionLog()");
		PreparedStatement pstmt = null;
		try 
		{
			String query = "insert into CRBT_SUBSCRIPTION_LOG (MSISDN, SUBSCRIBER_TYPE, ACTIVITY_DATE, ACTIVITY, INTERFACE_TYPE, WAS_CHARGED, UPDATED_BY, CALL_ID) values (?, ?, sysdate, ?, ?, ?, ?, 0)";

			pstmt = con.prepareStatement(query);
			pstmt.setString(1, msisdn);
			pstmt.setString(2, sub_type);
			pstmt.setString(3, act);
			pstmt.setString(4, "C");
			pstmt.setString(5, charged);
			pstmt.setString(6, userId);
			pstmt.executeUpdate();
			pstmt.close();
			return 1; //Success inserted in CCAudit 
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
	} //insertIntoSubscriptionLog

	public int regeneratePass(String Msisdn, int act) 
	{
		logger.info("regeneratePass(): new subscriber"+ act);
		String passwd="";
		String query="";
		String tpin="";
		int lang=2;
		boolean conflag = false;

		String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(Msisdn);

		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try 
		{
			if (con == null)			
			{
				con = conPool.getConnection();
				conflag = true;
				con.setAutoCommit(false);
			}

			query = "select MSISDN, PASSWORD, TPIN, language from CRBT_SUBSCRIBER_MASTER where MSISDN = ?";
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, interMsisdn);
			rs = pstmt.executeQuery();

			if (!rs.next())
			{
				rs.close();
				pstmt.close();
				return -1;
			}
			else 
			{
				Random no_generator = new Random();
				passwd = "" + (no_generator.nextInt(8999) + 1000);
				tpin = passwd;
				lang=rs.getInt("language");
			}
			rs.close();


			String Message_Text= "You have been subscribed to the tele tunes service, your IVR password is " + passwd ;
			//**JPquery = "select TEMPLATE_MESSAGE from LBS_TEMPLATES where TEMPLATE_ID = 80 and TEMPLATE_TYPE = 10 and language_id = 1";
			query = "select TEMPLATE_MESSAGE from LBS_TEMPLATES where TEMPLATE_ID = 300 and TEMPLATE_TYPE = 10 and language_id = ?";
			pstmt = con.prepareStatement(query);
			pstmt.setInt(1,lang);
			rs = pstmt.executeQuery();
			if(rs.next()) 
			{
				String message_string = rs.getString(1);
				int tempPos =0;
				tempPos = message_string.indexOf("$(password)");
				if(tempPos !=-1) 
				{
					Message_Text = message_string.substring(0,tempPos);
					Message_Text = Message_Text +passwd+message_string.substring(tempPos+11,message_string.length());
					logger.info("1. "+Message_Text);
				}


				int tempPos2 = message_string.indexOf("$(tpin)");
				if(tempPos2 !=-1) 
				{
					Message_Text = Message_Text + message_string.substring(tempPos+11, tempPos2);
					Message_Text = Message_Text + tpin;
					Message_Text = Message_Text + message_string.substring(tempPos2+7, message_string.length());
				}
				logger.info("2. "+Message_Text);
			} 
			rs.close();
			pstmt.close();

			query="select param_value from CRBT_APP_CONFIG_PARAMS where PARAM_TAG=?";
			pstmt = con.prepareStatement(query);
			pstmt.setString(1,"SMS_ORIGINATION_NUMBER");

			rs = pstmt.executeQuery();
			String sms_origin_number="7464";
			if(rs.next()) 
			{
				sms_origin_number  = rs.getString(1);
			}
			rs.close();
			pstmt.close();
			logger.info(sms_origin_number);

			query= "insert into GMAT_MESSAGE_STORE (RESPONSE_ID, REQUEST_ID, ORIGINATING_NUMBER, DESTINATION_NUMBER, MESSAGE_TEXT, SUBMIT_TIME, STATUS) values (GMAT_RESPONSE_ID_SEQ.nextval, 0, ?, ?, ?, sysdate, ?)";
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, sms_origin_number);
			pstmt.setString(2, interMsisdn);
			pstmt.setString(3, Message_Text);
			pstmt.setString(4, "R");
			pstmt.executeUpdate();

			query = "update CRBT_SUBSCRIBER_MASTER set PASSWORD = ?, TPIN = ? where MSISDN = ?";
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, passwd);
			pstmt.setString(2, tpin);
			pstmt.setString(3, interMsisdn);
			pstmt.executeUpdate();

			if (rs != null) rs.close();
			if (pstmt != null) pstmt.close();
			if (conflag) con.commit();
			return 1;
		}
		catch (SQLException sqle) 
		{//log it
			try {
				con.rollback();
			} catch (Exception exp) {}
			sqle.printStackTrace();
			return 0;
		}
		finally
		{
			if (conflag) conPool.free(con);
		}
	}
	public int regeneratePass(String Msisdn,Connection con)
	{
		logger.info("regeneratePass()");
		String passwd="";
		String query="";
		String tpin="";
		int lang=2;
		boolean conflag = false;

		String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(Msisdn);

		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try 
		{
			if (con == null)			
			{
				//con = conPool.getConnection();
				conflag = true;
				con.setAutoCommit(false);
			}

			query = "select MSISDN, PASSWORD, TPIN, language from CRBT_SUBSCRIBER_MASTER where MSISDN = ?";
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, interMsisdn);
			rs = pstmt.executeQuery();

			if (!rs.next())
			{
				rs.close();
				pstmt.close();
				return -1;
			}
			else 
			{
				Random no_generator = new Random();
				//passwd = "p" + (no_generator.nextInt(8999) + 1000);
				passwd = "" + (no_generator.nextInt(8999) + 1000);
				tpin = passwd;
				//	tpin = "" + (no_generator.nextInt(8999) + 1000);
				//lang=rs.getInt("language");
			}
			rs.close();
			String Message_Text="";
			//String Message_Text= "Your web password is " + passwd + " and tpin is " + tpin;
			//String Message_Text= "Your IVR password is " + passwd ;
			//String Message_Text= "Your IVR password is " + passwd ;
			//logger.info(Message_Text);

			//query = "select TEMPLATE_MESSAGE from LBS_TEMPLATES where TEMPLATE_ID = 80 and TEMPLATE_TYPE = 10 and language_id = 1";
			//query = "select TEMPLATE_MESSAGE from LBS_TEMPLATES where TEMPLATE_ID = 151 and TEMPLATE_TYPE = 10 and language_id = ?";
			query = "select TEMPLATE_MESSAGE from LBS_TEMPLATES where TEMPLATE_ID = 151 and TEMPLATE_TYPE = 10 and language_id = 1";	//Updated by MoHit for SUDAN 24 Nov 14
			pstmt = con.prepareStatement(query);
			//pstmt.setInt(1,lang);
			rs = pstmt.executeQuery();
			if(rs.next()) 
			{
				String message_string = rs.getString(1);
				int tempPos =0;
				tempPos = message_string.indexOf("$(password)");

				if(tempPos !=-1)
				{
					Message_Text = message_string.substring(0,tempPos);
					Message_Text = Message_Text +passwd;
				}

				int tempPos2 = message_string.indexOf("$(tpin)");
				if(tempPos2 !=-1)
				{
					Message_Text = Message_Text + message_string.substring(tempPos+11, tempPos2);
					Message_Text = Message_Text + tpin;
					Message_Text = Message_Text + message_string.substring(tempPos2+7, message_string.length());
				}
				logger.info(">>. "+Message_Text);


			} 
			rs.close();

			query="select param_value from CRBT_APP_CONFIG_PARAMS where PARAM_TAG=?";
			pstmt = con.prepareStatement(query);
			pstmt.setString(1,"SMS_ORIGINATION_NUMBER");

			rs = pstmt.executeQuery();
			String sms_origin_number="7464";
			if(rs.next()) 
			{
				sms_origin_number  = rs.getString(1);
			}
			rs.close();
			logger.info(sms_origin_number);

			query= "insert into GMAT_MESSAGE_STORE (RESPONSE_ID, REQUEST_ID, ORIGINATING_NUMBER, DESTINATION_NUMBER, MESSAGE_TEXT, SUBMIT_TIME, STATUS) values (GMAT_RESPONSE_ID_SEQ.nextval, 0, ?, ?, ?, sysdate, ?)";
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, sms_origin_number);
			pstmt.setString(2, interMsisdn);
			pstmt.setString(3, Message_Text);
			pstmt.setString(4, "R");
			pstmt.executeUpdate();

			query = "update CRBT_SUBSCRIBER_MASTER set PASSWORD = ?, TPIN = ? where MSISDN = ?";
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, passwd);
			pstmt.setString(2, tpin);
			pstmt.setString(3, interMsisdn);
			pstmt.executeUpdate();

			if (rs != null) rs.close();
			if (pstmt != null) pstmt.close();
			if (conflag) con.commit();
			return 1;
		}
		catch (SQLException sqle) 
		{//log it
			try {
				con.rollback();
			} catch (Exception exp) {}
			sqle.printStackTrace();
			return 0;
		}
		finally
		{
			//if (conflag) conPool.free(con);
		}
	}//regeneratePass

	private int getMaxSubs(Connection con)
	{
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String key = "";
		try
		{
			String query = "select LICENCE_KEY from CRBT_APP_TEMP_KEY where KEY_ID = 1"; 
			pstmt = con.prepareStatement(query);
			rs = pstmt.executeQuery();
			while (rs.next())
			{
				//	logger.info(rs.getString(1));
				key = rs.getString(1);				
			}
			if(rs != null) rs.close();
			pstmt.close();
		}
		catch (SQLException exp)
		{
			exp.printStackTrace();
		}

		String temp = key.substring(0, 6);

		char tmp[] = temp.toCharArray();

		int n_param = Integer.parseInt(decode(tmp.length, tmp));
		if (n_param <=0 || n_param > key.length()/8)
		{
			return -1;
		}
		int loc = 6;

		for(int i =0; i< n_param; i++)
		{
			temp = key.substring(loc);
			if ((temp == null) || (temp.length() <6))
			{
				return -1;
			}
			temp = key.substring(loc,loc+6);
			tmp = temp.toCharArray();
			int len = Integer.parseInt(decode(tmp.length, tmp));

			loc = loc+6;
			if (len <=0 || (2*len) > key.substring(loc).length())
			{
				return -1;
			}
			temp = key.substring(loc, loc+2*len);
			tmp = temp.toCharArray();
			String data = decode(tmp.length, tmp);
			loc = loc+2*len;
			//logger.info("KEY VALUE="+data);
			if (i==1)
			{
				return(Integer.parseInt(data));
			}			
		}
		return -1;	
	}//getMaxSubs

	public static String decode(int len, char data[])
	{
		char l_data[] = new char[(len/2) +1];
		for (int i=0; i<len; i++)
		{
			l_data[i/2] = (char) (data[i] - 0x41);
			l_data[i/2] += (char) (data[++i] - 0x41)<<4;
		}
		String s = new String(l_data);
		return s.trim();
	} //decode
	public String getRbtName(int rbtCode)
	{
		//get RBT codes and RBT names
		logger.info("getRbtName()");
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try
		{
			if (con == null)			
			{
				con = conPool.getConnection();
			}
			String	query = "select MASKED_NAME from CRBT_RBT where RBT_CODE=?"; 
			pstmt = con.prepareStatement(query);
			pstmt.setInt(1, rbtCode);
			rs = pstmt.executeQuery();
			if (rs.next())
			{
				logger.info(rs.getString("MASKED_NAME"));
				return rs.getString("MASKED_NAME");
			}
			else
			{
				logger.info("RBT CODE= "+rbtCode +" does not exist");
				return "-1";
			}
			//	 rs.close();

		}
		catch (SQLException sqle)
		{
			try {
				if (rs != null) rs.close();
			} catch (Exception e) {}
			sqle.printStackTrace();
		}
		finally 
		{
			conPool.free(con);
		}
		return "0";
	}//getRbtName()


	public void registertemp(String interMsisdn, Connection con)
	{
		logger.info("Setting status='R' for "+interMsisdn);
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String query="";
		try
		{
			String imsi = "123456781011121";
			String subscriber_type="P" ; // all are same -postpaid or prepaid
			int planId = Integer.parseInt(TSSJavaUtil.instance().getAppConfigParam("DEFAULT_RATE_PLAN")); 
			int rbtCode = Integer.parseInt(TSSJavaUtil.instance().getAppConfigParam("DEFAULT_RBT"));
			String passwd="0000";
			String tpin="0000";
			query = "insert into crbt_subscriber_master (MSISDN,STATUS,PLAN_INDICATOR,RBT_CODE,PASSWORD,TPIN,IMSI) values (?,?, ?, ?, ?, ?, ?)";
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, interMsisdn);
			pstmt.setString(2, "R");
			pstmt.setInt(3, planId);
			pstmt.setInt(4, rbtCode);
			pstmt.setString(5, passwd);
			pstmt.setString(6, tpin);
			pstmt.setString(7, imsi);

			pstmt.executeUpdate();
			pstmt.close();

			query="select param_value from CRBT_APP_CONFIG_PARAMS where PARAM_TAG=?";
			pstmt = con.prepareStatement(query);
			pstmt.setString(1,"SMS_ORIGINATION_NUMBER");

			rs = pstmt.executeQuery();
			String sms_origin_number="4444288";
			if(rs.next()) 
			{
				sms_origin_number  = rs.getString(1);
			}
			rs.close();
			pstmt.close();
			String Message_Text="Your request for CRBT subscription is accepted";
			query= "insert into GMAT_MESSAGE_STORE (RESPONSE_ID, REQUEST_ID, ORIGINATING_NUMBER, DESTINATION_NUMBER, MESSAGE_TEXT, SUBMIT_TIME, STATUS) values (GMAT_RESPONSE_ID_SEQ.nextval, 0, ?, ?, ?, sysdate, ?)";
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, sms_origin_number);
			pstmt.setString(2, interMsisdn);
			pstmt.setString(3, Message_Text);
			pstmt.setString(4, "R");
			pstmt.executeUpdate();

		}//try
		catch (SQLException sqle)
		{
			try {
				con.rollback();
				if (rs != null) rs.close();
				if (pstmt != null) pstmt.close();
			} catch (Exception e) {}
			sqle.printStackTrace();
			//return 0;
		}
		/*		finally 
				{
				conPool.free(con);
				}
		 */
	}//registertemp

	public void		postpaidfailurelog(String interMsisdn, int retVal, Connection con)
	{
		logger.info("postpaidfailurelog() "+interMsisdn);
		PreparedStatement pstmt = null;
		String reason="";
		String query="";
		try
		{
			if(retVal==-5)			{ reason="Request/Response Time out";		}
			if(retVal==-6)			{ reason="Network Error";		}
			query="insert into CHARGING_FAILURE_LOG( msisdn, reason, request_date) values(?,?,sysdate)";
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, interMsisdn);
			pstmt.setString(2, reason);
			pstmt.executeUpdate();
			pstmt.close();

		}
		catch (SQLException sqle)
		{
			try {
				con.rollback();
				if (pstmt != null) pstmt.close();
			} catch (Exception e) {}
			sqle.printStackTrace();
			//return 0;
		}
	}//postpaidfailurelog

	public int searchActivityStats(String msisdn, ArrayList historyAl, String interface_type,Connection con) 
	{
		String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(msisdn);
		logger.info("Inside function searchActivityStats()..["+interMsisdn+"]");
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String query;

		try
		{
			//con = conPool.getConnection();

			query = "select START_TIME, REQUEST_DATA, REQUEST_FROM, UPDATED_BY from CRBT_ACTIVITY_DETAIL_LOG  where msisdn = ? and REQUEST_FROM like ? order by START_TIME desc";
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, interMsisdn);
			pstmt.setString(2,"%"+interface_type+"%");
			logger.info("DB QUery:::"+query);
			rs = pstmt.executeQuery();

			while (rs.next())
			{
				SubscriberHistory subHistory = new SubscriberHistory();
				subHistory.setDate(rs.getString("START_TIME"));
				subHistory.setRequestMessage(rs.getString("REQUEST_DATA"));
				subHistory.setInterface_Type(rs.getString("REQUEST_FROM"));
				subHistory.setUpdate_Type(rs.getString("UPDATED_BY"));
				historyAl.add(subHistory);
			}
			rs.close();
			pstmt.close();



			query = "select START_TIME, REQUEST_DATA, REQUEST_FROM, UPDATED_BY from CRBT_ACTIVITY_DETAIL_LOG_HIST  where msisdn = ? and REQUEST_FROM='U' order by START_TIME desc";
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, interMsisdn);
			logger.info("DB Query:::"+query);
			rs = pstmt.executeQuery();

			while (rs.next())
			{
				SubscriberHistory subHistory = new SubscriberHistory();
				subHistory.setDate(rs.getString("START_TIME"));
				subHistory.setRequestMessage(rs.getString("REQUEST_DATA"));
				subHistory.setInterface_Type(rs.getString("REQUEST_FROM"));
				subHistory.setUpdate_Type(rs.getString("UPDATED_BY"));
				historyAl.add(subHistory);
			}
			if (rs != null) rs.close();
			if (pstmt != null) pstmt.close();

		}
		catch (Exception sqle)
		{
			try {
				if (rs != null) rs.close();
				if (pstmt != null) pstmt.close();
			} catch (Exception exp) {}
			sqle.printStackTrace();
			logger.error("Exceptio in searchActivityStats()....",sqle);
			return 0;
		}
		finally
		{
			try {
				if (rs != null) rs.close();
				if (pstmt != null) pstmt.close();
			} catch (Exception exp) {}
			
		}
		return 1;
	} //searchActivityStats

      public String statusCheck(String msisdn,Connection con)
       {
        logger.info("inside statusCheck()");
           logger.info("After converting InternationalNumber msisdn is......."+msisdn);
                PreparedStatement pstmt = null;
                ResultSet rs = null;
                String query;
                String result="N";
          
                 try
                {
                        //con = conPool.getConnection();
                        query="select  SUB_TYPE from crbt_subscriber_master  where msisdn=? and status in ('A','I')";
                        pstmt = con.prepareStatement(query);
                        pstmt.setString(1, msisdn);
                        rs = pstmt.executeQuery();

                        if (rs.next())
                        {
                         String subType=rs.getString("SUB_TYPE");
                         result=subType;
                        }
                }
                  
                catch (Exception sqle)
                {
                        try {
                                if (rs != null) rs.close();
                                if (pstmt != null) pstmt.close();
                        } catch (Exception exp) {}
                        sqle.printStackTrace();
                        return result="N";
                }
                finally
                {
                	try {
                        if (rs != null) rs.close();
                        if (pstmt != null) pstmt.close();
                } catch (Exception exp) {}
                
                        //conPool.free(con);
                }
                return result;
        } //statusChecck

      /**
       * added by MoHit for subscription with planId
       * @param Msisdn
       * @param userId
       * @param lang
       * @param planId
       * @return
       */
      public String addsubscriber(String Msisdn, String userId, int lang, int planId)
      {
  		String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(Msisdn);
  		logger.info("Inside function addsubscriber() where  Number ["+interMsisdn+"] userId ["+userId+"] lang ["+lang+"] planId ["+planId+"]");
        con=TSSJavaUtil.instance().getconnection();           
        String result=statusCheck(interMsisdn,con);
        logger.info("sub-Type is ........."+result);
        
        	String ret_str = "";
  			SetVariable sv = new SetVariable();
  			sv.setMsisdn(interMsisdn);
  			sv.setPlan(planId);
  			sv.setLang(lang);
  			sv.setInterface("C");
  			sv.setUpdatedBy(userId);
  			//sv.setSubType("P");
            sv.setSubType(result);

            logger.info("Sending to RE : msisdn="+interMsisdn+" planId="+planId+" lang="+lang+" userId="+userId+" result="+result);
            
  			CRBTRequest crbt_req = new CRBTRequest();
  			crbt_req.constructQuery(1,sv);
  			int ret_val = crbt_req.send();
  			if (ret_val == 0)
  			{
  				ret_str = "SuccessFul";
  			}
  			else
  			{
  				ret_str = crbt_req.err_string;
  			}

  			try{
  				if(con!=null)
  				con.close();
  			}
  			catch (Exception e) {
				e.printStackTrace();
			}
  			
  			logger.info(" CRE::::returned"+ret_str);
  			return ret_str;// retVal;
      }//addsubscriber()
      
}//class
