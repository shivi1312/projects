package com.telemune.vcc.custcare;

import java.util.ArrayList;

public class EditProfileSettingBean {
	private int serialNumber;
	private String startTime;
	private String endTime;
	private ArrayList dayList= new ArrayList();
	private int rbtCode;
	private String rbtName;
	private long corpId;
	private String title;
	private String changeLinkValue;
	private String deleteLinkValue;
	private String date;
	private String occName;
	private String grpName;
	private String nick;
	private String frndNick;
	private String frndMsisdn;
	private String catName;
	
	
	
	
	public String getCatName() {
		return catName;
	}
	public void setCatName(String catName) {
		this.catName = catName;
	}
	public String getFrndNick() {
		return frndNick;
	}
	public void setFrndNick(String frndNick) {
		this.frndNick = frndNick;
	}
	public String getFrndMsisdn() {
		return frndMsisdn;
	}
	public void setFrndMsisdn(String frndMsisdn) {
		this.frndMsisdn = frndMsisdn;
	}
	public String getGrpName() {
		return grpName;
	}
	public void setGrpName(String grpName) {
		this.grpName = grpName;
	}
	public String getNick() {
		return nick;
	}
	public void setNick(String nick) {
		this.nick = nick;
	}
	public String getOccName() {
		return occName;
	}
	public void setOccName(String occName) {
		this.occName = occName;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	private boolean delFlag;
	
	public boolean isDelFlag() {
		return delFlag;
	}
	public void setDelFlag(boolean delFlag) {
		this.delFlag = delFlag;
	}
	public String getChangeLinkValue() {
		return changeLinkValue;
	}
	public void setChangeLinkValue(String changeLinkValue) {
		this.changeLinkValue = changeLinkValue;
	}
	public String getDeleteLinkValue() {
		return deleteLinkValue;
	}
	public void setDeleteLinkValue(String deleteLinkValue) {
		this.deleteLinkValue = deleteLinkValue;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(int serialNumber) {
		this.serialNumber = serialNumber;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	public ArrayList getDayList() {
		return dayList;
	}
	public void setDayList(ArrayList dayList) {
		this.dayList = dayList;
	}
	public int getRbtCode() {
		return rbtCode;
	}
	public void setRbtCode(int rbtCode) {
		this.rbtCode = rbtCode;
	}
	public String getRbtName() {
		return rbtName;
	}
	public void setRbtName(String rbtName) {
		this.rbtName = rbtName;
	}
	public long getCorpId() {
		return corpId;
	}
	public void setCorpId(long corpId) {
		this.corpId = corpId;
	}
	

}
