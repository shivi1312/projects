/*
 *
 *
 *
 */
package com.telemune.vcc.custcare;
import java.sql.ResultSet;
import java.util.*;

import com.telemune.dbutilities.*;
import org.apache.log4j.*;
public class FriendManager
{
        private static Logger logger=Logger.getLogger(FriendManager.class);
	private Connection con = null;

	public FriendManager()
	{						
	}

	public FriendManager(Connection con)
	{
		setConnection(con);
	}

	public Connection getConnection()
	{
		return con;			
	}					

	public void setConnection(Connection con)
	{
		this.con = con;				
	}

	public int deleteFriend(String msisdn, String friendsMsisdn) 
	{
		logger.info("inside deleteFriend() msisdn= "+msisdn+" friendMsisdn= "+friendsMsisdn);
		PreparedStatement pstmt;
		String query;
		if (con == null)
		{
			logger.info("CON NULL");
			return 0;
		}
		try
		{
			query = "delete from CRBT_FRIEND_DETAIL where MSISDN = ? and FRIEND_MSISDN = ?";
			logger.info("query = "+query);
			pstmt = con.prepareStatement(query);
			pstmt.setString(1,msisdn);
			pstmt.setString(2,friendsMsisdn);
			pstmt.executeUpdate();
	
			query = "delete from CRBT_FRIEND_SETTING where MSISDN = ? and FRIEND_MSISDN = ?";
			logger.info("query = "+query);
			pstmt = con.prepareStatement(query);
			pstmt.setString(1,msisdn);
			pstmt.setString(2,friendsMsisdn);
			pstmt.executeUpdate();

			pstmt.close();
			return 1;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
	}

	public int updateFriend(String msisdn, String friendsMsisdn, String nick)
	{
		logger.info("inside updateFriend() msisdn= "+msisdn+" friendMsisdn= "+friendsMsisdn+" nick= "+nick);
		if (con == null)
		{
			logger.info("CON NULL");
			return 0;
		}
		try
		{
			String query = "select FRIEND_MSISDN from CRBT_FRIEND_DETAIL where MSISDN = ? and NICK = ?";
			logger.info("query = "+query);
			PreparedStatement pstmt = con.prepareStatement(query);
			pstmt.setString(1,msisdn);
			pstmt.setString(2,nick.toUpperCase());
			ResultSet rs = pstmt.executeQuery();
			if (rs.next())
			{
				logger.info("already exists");
				pstmt.close();
				return -1;
			}

			query = "update CRBT_FRIEND_DETAIL set NICK = ? where MSISDN = ? and friend_msisdn = ?";
			logger.info("query = "+query);
			pstmt = con.prepareStatement(query);
			pstmt.setString(1,nick.toUpperCase().trim());
			pstmt.setString(2,msisdn.trim());
			pstmt.setString(3,friendsMsisdn.trim());
		
			logger.info("Query update : "+query);
			pstmt.executeUpdate();				
			pstmt.close();
			return 1;	
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
	}

	public int addFriends(String msisdn, ArrayList friends, ArrayList friendsNickAl)
	{
		logger.info("inside addFriends() msisdn = "+msisdn);
		if (con == null)
		{
			logger.info("CON NULL");
			return 0;
		}

		PreparedStatement pstmt = null;
		PreparedStatement pstmt1 = null;
		ResultSet rs = null;
		String query, query0;
		try
		{
			ToneSetting ts = new ToneSetting();
			query = "select MSISDN from CRBT_FRIEND_DETAIL where MSISDN = ? and (FRIEND_MSISDN = ? or NICK = ?)";
			logger.info("query = "+query);
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, msisdn);
			String friendMsisdn ="";
			String friendNick ="";
			for (int i=0; i<friends.size(); i++)
			{
				friendMsisdn = (String)friends.get(i);
				friendNick = (String)friendsNickAl.get(i);
				logger.info("friendMsisdn = "+friendMsisdn+" friendNick = "+(String)friendsNickAl.get(i));
				pstmt.setString(2, friendMsisdn);
				pstmt.setString(3, friendNick.toUpperCase());
				rs = pstmt.executeQuery();
				if(rs.next())
				{
					if(rs != null) rs.close();
					return -3;
				}
				if(rs != null) rs.close();
			}

			byte str[] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
			query = "insert into CRBT_FRIEND_DETAIL (MSISDN, FRIEND_MSISDN, FRIEND_SETTING_STRING, NICK) values (?,?,?,?)";	
			query0 = "insert into CRBT_FRIEND_SETTING (MSISDN, FRIEND_MSISDN, DAY, START_AT, ENDS_AT, RBT_CODE, UPDATE_TIME) values (?,?,?,?,?,?,sysdate)";	
			logger.info("query = "+query);
			logger.info("query0 = "+query0);
			pstmt = con.prepareStatement(query);
			pstmt1 = con.prepareStatement(query0);
			pstmt1.setString(1, msisdn.trim());
			pstmt1.setInt(3, ts.getDay());
			pstmt1.setInt(4, ts.getStartTime());
			pstmt1.setInt(5, ts.getEndTime());
			pstmt1.setInt(6, ts.getRbtCode());
			pstmt.setString(1, msisdn.trim());
			pstmt.setBytes(3, str); 
			Iterator ite1 = friends.iterator();
			Iterator iteNick = friendsNickAl.iterator();
			while(ite1.hasNext())
			{
				String friendsMsisdn = (String)ite1.next();
				String friendsNick = (String)iteNick.next();

				if(friendsNick == null || friendsNick.equals(""))
				{
					friendsNick = friendsMsisdn;
				}
				pstmt1.setString(2, friendsMsisdn.trim());
				pstmt.setString(2, friendsMsisdn.trim());
				pstmt.setString(4, friendsNick.toUpperCase().trim());
				pstmt.executeUpdate();
		//		pstmt1.executeUpdate();
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
		return 1;
	}

	public int getFriendDetails(String msisdn, ArrayList friends)
	{
		logger.info("inside getFriendDetails() msisdn = "+msisdn);
		try
		{
			friends.clear();

			String query = "select NICK, FRIEND_MSISDN from CRBT_FRIEND_DETAIL where MSISDN = ?";
			logger.info(query);
			PreparedStatement pstmt = con.prepareStatement(query);
			pstmt.setString(1, msisdn);
			ResultSet rs = pstmt.executeQuery();

			while (rs.next())
			{
				SubscriberFriend sf = new SubscriberFriend();
				sf.setMsisdn(msisdn);
				sf.setFriendsMsisdn(rs.getString("FRIEND_MSISDN"));
				String nick = rs.getString("NICK");
				if (nick == null || nick == "")
					nick = sf.getFriendsMsisdn();
				sf.setFriendsNick (nick);
				friends.add(sf);
			}
			if (rs != null) rs.close();
					
			pstmt.close();
			return 1;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
	}  
}
