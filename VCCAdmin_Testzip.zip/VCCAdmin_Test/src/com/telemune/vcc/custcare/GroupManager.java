/*
 *
 *
 *
 */


package com.telemune.vcc.custcare;
import java.sql.ResultSet;
import java.util.*;

import com.telemune.dbutilities.*;
import org.apache.log4j.*;
public class GroupManager
{
         private static Logger logger=Logger.getLogger(GroupManager.class);
	private Connection con = null;

	public GroupManager()
	{						
	}

	public GroupManager(Connection con)
	{
		setConnection(con);
	}

	public Connection getConnection()
	{
		return con;			
	}					

	public void setConnection(Connection con)
	{
		this.con = con;				
	}

	public int addGroup(SubscriberGroup group) 
	{
		logger.info("inside addGroup()");
		if (con == null)
		{
			logger.info("CON NULL");
			return 0;
		}
		try
		{
			PreparedStatement pstmt;
			ResultSet rs;
			String query;

			query = "select GROUPID from CRBT_GROUP_DETAIL where MSISDN = ? and MASKED_NAME = ?";
			logger.info("query = "+query);
			pstmt = con.prepareStatement(query);
			pstmt.setString(1,group.getMsisdn());
			pstmt.setString(2,group.getGroupName());
     
			rs = pstmt.executeQuery();
			if (rs.next())
			{
				logger.info("group with masked name "+group.getGroupName()+" for msisdn "+group.getMsisdn()+"  already exists");
				rs.close();
				return -5;
			}
			rs.close();

			BitSet bitSet = new BitSet(256);

			bitSet.set(255-16-200);

			byte str[] = toByteArray(bitSet);

			long groupId = 0;

			query = "select GROUPID.nextval from dual";
			pstmt = con.prepareStatement(query);
			
			rs = pstmt.executeQuery();
			if (rs.next())
			{
				groupId = rs.getLong("NEXTVAL");
			}
			
			query = "insert into CRBT_GROUP_DETAIL (MSISDN, GROUPID, MASKED_NAME, GROUP_SETTING_STRING, CREATION_DATE) values (?, ?, ?, ?, sysdate)";
			logger.info("query = "+query);
			pstmt = con.prepareStatement(query);
			pstmt.setString(1,group.getMsisdn().trim());
			pstmt.setLong(2,groupId);
			pstmt.setString(3,group.getGroupName().trim());
			pstmt.setBytes(4,str);
			pstmt.executeUpdate();

			ToneSetting ts = new ToneSetting();

			query = "insert into CRBT_GROUP_SETTING (MSISDN, GROUPID, DAY, START_AT, ENDS_AT, RBT_CODE, UPDATE_TIME) values (?, ?, ?, ?, ?, ?, sysdate)";
			logger.info("query = "+query);
			pstmt = con.prepareStatement(query);
			pstmt.setString(1,group.getMsisdn().trim());
			pstmt.setLong(2,groupId);
			pstmt.setInt(3,ts.getDay());
			pstmt.setInt(4,ts.getStartTime());
			pstmt.setInt(5,ts.getEndTime());
			pstmt.setInt(6,ts.getRbtCode());
			//pstmt.executeUpdate();

			query = "insert into CRBT_GROUP_MASTER (MSISDN, GROUPID, MEMBER_MSISDN) values (?, ?, ?)";
			logger.info("query = "+query);
			pstmt = con.prepareStatement(query);
			pstmt.setString(1,group.getMsisdn().trim());
			pstmt.setLong(2,groupId);

			ArrayList friendsAl = group.getFriends();
			Iterator ite = friendsAl.iterator();
			while(ite.hasNext())
			{
				String friendsMsisdn = (String)ite.next();
				pstmt.setString(3,friendsMsisdn.trim());
				pstmt.executeUpdate();
			}
			group.setGroupId(groupId);
			pstmt.close();
			logger.debug("successfully added group");
			return 1;	
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
	}

	public int modifyGroup(SubscriberGroup group) 
	{
		logger.info("inside modifyGroup()");
		if(con == null)
		{
			logger.info("CON Null");
			return 0;
		}
		try
		{
			PreparedStatement pstmt;
			ResultSet rs;
			String query;

			query = "select GROUPID from CRBT_GROUP_DETAIL where MSISDN = ? and MASKED_NAME = ?";
			logger.info("query = "+query);
			pstmt = con.prepareStatement(query);
			pstmt.setString(1,group.getMsisdn());
			pstmt.setString(2,group.getGroupName());
     
			rs = pstmt.executeQuery();
			while (rs.next())
			{
				if (rs.getLong("GROUPID") != group.getGroupId())
				{
					rs.close();
					return -5;
				}
			}
			rs.close();

			query = "update CRBT_GROUP_DETAIL set MASKED_NAME = ? where GROUPID = ?";
			logger.info("query = "+query);
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, group.getGroupName().trim());
			pstmt.setLong(2, group.getGroupId());
			pstmt.executeUpdate();

			query = "delete from CRBT_GROUP_MASTER where MSISDN = ? and GROUPID = ?";
			logger.info("query = "+query);
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, group.getMsisdn());
			pstmt.setLong(2, group.getGroupId());
			pstmt.executeUpdate();

			query = "insert into CRBT_GROUP_MASTER (MSISDN, GROUPID, MEMBER_MSISDN) values (?, ?, ?)";
			logger.info("query = "+query);
			pstmt = con.prepareStatement(query);
			pstmt.setString(1,group.getMsisdn().trim());
			pstmt.setLong(2,group.getGroupId());

			ArrayList friendsAl = group.getFriends();
			Iterator ite1 = friendsAl.iterator();
			while(ite1.hasNext())
			{
				String friendsMsisdn = (String)ite1.next();
				pstmt.setString(3,friendsMsisdn.trim());
				pstmt.executeUpdate();
			}
			pstmt.close();
		
			return 1;
		}	
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
	}

	public int deleteGroup(String msisdn, long groupId) 
	{
		logger.info("inside deleteGroup() msisdn="+msisdn+" gropuId="+groupId);
		if(con == null)
		{
			logger.info("Con null");
			return 0;
		}
		try
		{
			PreparedStatement pstmt;
			String query;	

			query = "delete from CRBT_GROUP_MASTER where GROUPID = ?";
			logger.info("query = "+query);
			pstmt = con.prepareStatement(query);
			pstmt.setLong(1,groupId);
			pstmt.executeUpdate();
	
			query = "delete from CRBT_GROUP_DETAIL where GROUPID = ?";
			logger.info("query = "+query);
			pstmt = con.prepareStatement(query);
			pstmt.setLong(1,groupId);
			pstmt.executeUpdate();

			query = "delete from CRBT_GROUP_SETTING where GROUPID = ?";
			logger.info("query = "+query);
			pstmt = con.prepareStatement(query);
			pstmt.setLong(1,groupId);
			pstmt.executeUpdate();

			pstmt.close();		
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}		
		return 1;	
	}
		
	public int getGroupDetails(String msisdn, ArrayList groupList)
	{
		logger.info("iniside getGroupDetails() msisdn="+msisdn);
		try
		{
			PreparedStatement pstmt;
			ResultSet rs;
			String query;

			groupList.clear();

			query = "select GROUPID, MASKED_NAME from CRBT_GROUP_DETAIL where MSISDN = ?";
			logger.info("query = "+query);
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, msisdn);
			rs = pstmt.executeQuery();
			
			while(rs.next())
			{
				SubscriberGroup sg = new SubscriberGroup();
				sg.setMsisdn(msisdn);
				sg.setGroupId(rs.getLong("GROUPID"));
				sg.setGroupName(rs.getString("MASKED_NAME"));

				groupList.add(sg);
			}

			Iterator ite =  groupList.iterator();
			while(ite.hasNext())
			{
				SubscriberGroup sg = (SubscriberGroup) ite.next();
				ArrayList friendList = new ArrayList();
					
				query = "select MEMBER_MSISDN from CRBT_GROUP_MASTER where GROUPID = ?";
				pstmt = con.prepareStatement(query);
				pstmt.setLong(1, sg.getGroupId());
				rs = pstmt.executeQuery();
				friendList.clear();
				while(rs.next())
				{
					friendList.add(rs.getString("MEMBER_MSISDN"));
				}	
				sg.setFriends(friendList);
			}
			pstmt.close();	
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}		
		return 1;
	}

	public static byte[] toByteArray(BitSet bits) 
	{
		logger.debug("inisde toByteArray()");
		byte[] bytes = new byte[30];
		for (int i=0; i<bits.length(); i++) 
		{
			if (bits.get(i)) 
			{
				bytes[bytes.length-i/8-1] |= 1<<(i%8);
			}
		}
		return bytes;
	}
	
	//Added by MoHit for QCELL 11 Nov 14
	
	public String getGroupNameById(String id, String msisdn)
	{
		logger.info("iniside getGroupNameById() msisdn ["+msisdn+"] groupId ["+id+"]");
		int groupId;
		if(id!=null)
			groupId=Integer.parseInt(id);
		else
		{
			logger.info("Group Id is null");
			return "";
		}
			
		String groupName=null;
		try
		{
			PreparedStatement pstmt;
			ResultSet rs;
			String query;

			query = "select MASKED_NAME from CRBT_GROUP_DETAIL where MSISDN = ? and GROUPID=?";
			logger.info("query = "+query);
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, msisdn);
			pstmt.setInt(2, groupId);
			rs = pstmt.executeQuery();
			
			if(rs.next())
			{
				groupName=rs.getString(1);
			}
			else
			{
				groupName="";
			}
			pstmt.close();
			rs.close();
			logger.info("returning group name = "+groupName);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return "";
		}
		return groupName;
	}
	
}
