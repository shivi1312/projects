/*
 * This class is used for user authentication for the web interface for CRBT. 
 *
 *
 *
 */


package com.telemune.vcc.custcare;
import java.util.ArrayList;

public class InvalidSearch 
{
	private String msisdn=null;
	private String searchName=null;
	private String searchDate=null;
	private ArrayList searchlist = null;//msisdns in this group

	public void setMsisdn(String msisdn )
	{
		this.msisdn = msisdn;
	}
	public String getMsisdn()  
	{
//		return TSSJavaUtil.instance().getInternationalNumber(msisdn);
		return msisdn;
	}
	public ArrayList getSearch()
  {
	    return searchlist;
	}
	public void setSearchlist(String []searchlist)
	{
		this.searchlist = new ArrayList();
		
		for(int i=0; i < searchlist.length; i++)
		{
			this.searchlist.add(searchlist[i]);	
		}
	}
	public void setSearchlist(ArrayList searchlist)
	{
		this.searchlist = searchlist;
	}

	public void setSearchlistName(String blist)
	{
		this.searchName = blist;
	}
	public String getSearchlistName()
	{
		return this.searchName;
	}
	public void setSearchlistDate(String blistDate)
	{
		this.searchDate = blistDate;
	}
	public String getSearchlistDate()
	{
		return this.searchDate;
	}

}

