/*
 * This class is used for user authentication for the web interface for CRBT. 
 *
 *
 *
 */


package com.telemune.vcc.custcare;


//import com.telemune.crbt.webif.*;
import com.telemune.dbutilities.*;
import com.telemune.vcc.common.*;

import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.*;

import org.apache.log4j.*;

public class InvalidSearchManager 
{
	private static Logger logger=Logger.getLogger(InvalidSearchManager.class);

	private ConnectionPool conPool;
	private Connection con;
	private PreparedStatement pstmt = null;
	private		ResultSet rset = null;
	private	String query=null;


	public InvalidSearchManager() 
	{
		conPool = new ConnectionPool();
	}

	public void setConnectionPool(ConnectionPool conPool) 
	{
		this.conPool = conPool;
	}

	public int getInvalidSearch(ArrayList isNumAr,Connection con)
	{
		logger.info("Inside function getInvalidSearch()....");
		try 
		{
			//con = conPool.getConnection();

			if(con == null) 
			{
				return -1;
			}

			query="SELECT MSISDN,SEARCH_NAME,SEARCH_DATE FROM CRBT_INVALID_SEARCH";
			logger.info("query = "+query);
			pstmt = con.prepareStatement (query);
			logger.info(query);
			rset=pstmt.executeQuery();
			while(rset.next())
			{
				InvalidSearch isobj=new InvalidSearch();
				isobj.setSearchlistName(rset.getString("SEARCH_NAME"));
				isobj.setSearchlistDate(rset.getString("SEARCH_DATE"));
				isobj.setMsisdn(rset.getString("MSISDN"));
				isNumAr.add(isobj);
			}
			pstmt.close();
			rset.close();
		}
		catch (SQLException e) {
			logger.error("getInvalidSearch() :"+e.getMessage());
			try {
				if(pstmt != null) pstmt.close();
				if(rset != null) rset.close();
			} catch(Exception exp) {}
			e.printStackTrace();
			return -1;
		}
		catch (Exception e) {
			try {
				if(pstmt != null) pstmt.close();
				if(rset != null) rset.close();
			} catch(Exception exp) {}                
			e.printStackTrace();
			return -1;
		}
		finally {
			try {
				if(pstmt != null) pstmt.close();
				if(rset != null) rset.close();
			} catch(Exception exp) {}                
			//conPool.free(con);
		}
		return 1;

	}//get

	public int getInvalidSearch(ArrayList isNumAr,String msisdn,Connection con) 
	{
		logger.info("Inside function getInvalidSearch().... where msisdn ["+msisdn+"] ");
		String msisdns =TSSJavaUtil.instance().getInternationalNumber(msisdn);
		try 
		{
			//con = conPool.getConnection();
			String query=null;

			query="SELECT SEARCH_NAME,to_char(SEARCH_DATE,'dd-mm-yyyy hh24:mi:ss') SEARCH_DATE FROM CRBT_INVALID_SEARCH WHERE MSISDN=? order by SEARCH_DATE desc";
			logger.info("query = "+query);
			pstmt = con.prepareStatement (query);
			pstmt.setString(1,msisdns);
			rset=pstmt.executeQuery();
			while(rset.next())
			{
				InvalidSearch isobj=new InvalidSearch();
				isobj.setSearchlistName(rset.getString("SEARCH_NAME"));
				isobj.setSearchlistDate(rset.getString("SEARCH_DATE"));

				isNumAr.add(isobj);
			}

			pstmt.close();
			rset.close();
		}
		catch (SQLException e) {
			logger.error("In searchTones not found :"+e.getMessage());
			try {
				if(pstmt != null) pstmt.close();
				if(rset != null) rset.close();
			} catch(Exception exp) {}
			e.printStackTrace();
			logger.error("Exception in getInvalidSearch()....",e);
			return 0;
		}
		finally {
			try {
				if(pstmt != null) pstmt.close();
				if(rset != null) rset.close();
			} catch(Exception exp) {}

			//conPool.free(con);
		}
		return 1;

	}//get

}

