package com.telemune.vcc.custcare;

public class MailBoxHistoryBean {
	public int pre_basic;
	public int pre_basic_block;
	public int post_basic;
	public int post_basic_block;
	public int post_exe;
	public int post_exe_block;
	public int pre_default;
	public int pre_default_block;
	public int post_default;
	public int post_default_block;
	public int fixed;
	public int fixed_block;
	public int elife;
	public int elife_block;
	public String report_date;
	
	
	public String getReport_date() {
		return report_date;
	}
	public void setReport_date(String report_date) {
		this.report_date = report_date;
	}
	public int getPre_basic() {
		return pre_basic;
	}
	public void setPre_basic(int pre_basic) {
		this.pre_basic = pre_basic;
	}
	public int getPre_basic_block() {
		return pre_basic_block;
	}
	public void setPre_basic_block(int pre_basic_block) {
		this.pre_basic_block = pre_basic_block;
	}
	public int getPost_basic() {
		return post_basic;
	}
	public void setPost_basic(int post_basic) {
		this.post_basic = post_basic;
	}
	public int getPost_basic_block() {
		return post_basic_block;
	}
	public void setPost_basic_block(int post_basic_block) {
		this.post_basic_block = post_basic_block;
	}
	public int getPost_exe() {
		return post_exe;
	}
	public void setPost_exe(int post_exe) {
		this.post_exe = post_exe;
	}
	public int getPost_exe_block() {
		return post_exe_block;
	}
	public void setPost_exe_block(int post_exe_block) {
		this.post_exe_block = post_exe_block;
	}
	public int getPre_default() {
		return pre_default;
	}
	public void setPre_default(int pre_default) {
		this.pre_default = pre_default;
	}
	public int getPre_default_block() {
		return pre_default_block;
	}
	public void setPre_default_block(int pre_default_block) {
		this.pre_default_block = pre_default_block;
	}
	public int getPost_default() {
		return post_default;
	}
	public void setPost_default(int post_default) {
		this.post_default = post_default;
	}
	public int getPost_default_block() {
		return post_default_block;
	}
	public void setPost_default_block(int post_default_block) {
		this.post_default_block = post_default_block;
	}
	public int getFixed() {
		return fixed;
	}
	public void setFixed(int fixed) {
		this.fixed = fixed;
	}
	public int getFixed_block() {
		return fixed_block;
	}
	public void setFixed_block(int fixed_block) {
		this.fixed_block = fixed_block;
	}
	public int getElife() {
		return elife;
	}
	public void setElife(int elife) {
		this.elife = elife;
	}
	public int getElife_block() {
		return elife_block;
	}
	public void setElife_block(int elife_block) {
		this.elife_block = elife_block;
	}
	
	

}
