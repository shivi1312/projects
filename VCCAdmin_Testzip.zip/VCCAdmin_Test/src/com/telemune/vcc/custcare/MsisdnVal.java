package com.telemune.vcc.custcare;


class MsisdnVal
{

        public String countrycode;
        public String st_msisdn;
        public String ed_msisdn;
        public int port;
        public String getstmsisdn()
        {
                return st_msisdn;
        }
        public String getedmsisdn()
        {
                return ed_msisdn;
        }
        public String getcountrycode()
        {
                return countrycode;
        }
        public int getport()
        {
                return port;
        }
}

