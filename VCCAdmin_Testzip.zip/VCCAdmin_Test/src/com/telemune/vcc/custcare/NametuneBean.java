package com.telemune.vcc.custcare;

public class NametuneBean {

	private int rbtCode;
    private String maskedName;
    private String artistName;

    public NametuneBean()
    {}
    
    public String getArtistName() {
		return artistName;
	}

	public void setArtistName(String artistName) {
		this.artistName = artistName;
	}

	public void setRbtCode(int rbtCode)
    {
            this.rbtCode=rbtCode;
    }

    public int getRbtCode()
    {
            return rbtCode;
    }

    public void setMaskedName(String maskedName)
    {
            this.maskedName=maskedName;
    }

    public String getMaskedName()
    {
            return maskedName;
    }

}//class ends
