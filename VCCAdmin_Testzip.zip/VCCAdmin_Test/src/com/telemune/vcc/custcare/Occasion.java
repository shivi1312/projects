/*
 * This class is used for user authentication for the web interface for CRBT. 
 *
 *
 *
 */


package com.telemune.vcc.custcare;
import com.telemune.vcc.common.*;

import java.util.ArrayList;

public class Occasion 
{
	private String msisdn=null;
	private String occasionName=null;
	private String occasionDate=null;
	private ArrayList occasionlist = null;//msisdns in this group

	public void setMsisdn(String msisdn )
	{
		this.msisdn = msisdn;
	}
	public String getMsisdn()  
	{
		return TSSJavaUtil.instance().getInternationalNumber(msisdn);
	}
	public ArrayList getOccasionList()
  {
	    return occasionlist;
	}

	public void setOccasionName(String ocName)
{	
		this.occasionName = ocName;
	}
	public String getOccasionName()
{
		return this.occasionName;
	}
	public void setOccasionDate(String ocDate)
	{
		this.occasionDate = ocDate;
	}
	public String getOccasionDate()
	{
		return this.occasionDate;
	}

}

