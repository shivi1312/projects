/*
 * This class is used for user authentication for the web interface for CRBT. 
 *
 *
 *
 */


package com.telemune.vcc.custcare;

//import com.telemune.crbt.webif.*;
import com.telemune.dbutilities.*;
import java.text.SimpleDateFormat;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.*;

import org.apache.log4j.*;

public class OccasionManager 
{
	private static Logger logger=Logger.getLogger(OccasionManager.class);
	private ConnectionPool conPool;
	private Connection con;
	PreparedStatement pstmt = null;
	ResultSet rset = null;


	public OccasionManager() 
	{
		conPool = new ConnectionPool();
	}

	public void setConnectionPool(ConnectionPool conPool) 
	{
		this.conPool = conPool;
	}
	public int getOccasion(ArrayList ocNameAr,Connection con)
	{
		logger.info("logger getOccassion()");
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");

		Date date=new Date();
		//System.out.println("Current Date : "+dateFormat.format(date));
		logger.info("getOccasion() list for set");
		try 
		{
			//con = conPool.getConnection();
			String query="";

			if(conPool == null) 
			{
				return 0;
			}
			query="SELECT OCCASION_NAME,to_char(OCCASION_DATE,'dd-mm-yyyy') OCCASION_DATE from CRBT_OCCASION_LIST WHERE OCCASION_DATE>=sysdate";
			logger.info(query);
			pstmt = con.prepareStatement(query);
			rset=pstmt.executeQuery();
			while(rset.next())
			{
				logger.info(rset.getString("OCCASION_NAME"));
				logger.info(rset.getString("OCCASION_DATE"));
				Occasion ocobj=new Occasion();
				ocobj.setOccasionName(rset.getString("OCCASION_NAME"));
				ocobj.setOccasionDate(rset.getString("OCCASION_DATE"));
				ocNameAr.add(ocobj);
			}
			rset.close();
			pstmt.close();
			query="SELECT OCCASION_NAME,SUBSTR(to_char(OCCASION_DATE,'dd-mm-yyyy'),0,6) OCCASION_DATE from CRBT_OCCASION_LIST WHERE OCCASION_DATE<sysdate AND IS_CONSTANT='Y'";
			logger.info(query);
			pstmt = con.prepareStatement(query);
			rset=pstmt.executeQuery();
			Date dt=new Date();
			int dtyear=0;
			dtyear=1900+dt.getYear();
			logger.info("Year============="+dtyear);

			//dtyear++;
			//logger.info("Year============="+dtyear);
			String occDate;

			while(rset.next())
			{
				logger.info(rset.getString("OCCASION_NAME"));
				logger.info(rset.getString("OCCASION_DATE"));
				Occasion ocobj=new Occasion();

				occDate=(rset.getString("OCCASION_DATE"))+Integer.toString(dtyear);
				if((dateFormat.parse(occDate)).compareTo(date)<0){
					occDate=(rset.getString("OCCASION_DATE"))+Integer.toString(dtyear+1);														
				}
				logger.info(occDate);
				ocobj.setOccasionName(rset.getString("OCCASION_NAME"));
				ocobj.setOccasionDate(occDate);
				ocNameAr.add(ocobj);
			}
			rset.close();
			pstmt.close();


		}
		catch (SQLException e) {
			logger.error("In searchTones not found :"+e.getMessage());
			try {
				if(pstmt != null) pstmt.close();
			} catch(Exception exp) {}
			e.printStackTrace();
			return 0;
		}
		catch (Exception e) {
			try {
				if(pstmt != null) pstmt.close();
			} catch(Exception exp) {}                
			e.printStackTrace();
			return 0;
		}

		/*finally {
		  conPool.free(con);
		  }*/

		return 1;

	}//get

}

