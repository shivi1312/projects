package com.telemune.vcc.custcare;
import com.telemune.dbutilities.*;
import java.io.*;
import java.sql.ResultSet;

import org.apache.log4j.*;
public class PlayRbt {
 
    private static Logger logger=Logger.getLogger(PlayRbt.class);
    private ConnectionPool conPool;
    private Connection con;

    public PlayRbt(){
	this.conPool =  null;
	this.con = null;
    }


    public int playRbt(int rbtcode, Writer out)
    {
	logger.info("inside playRbt() rbtcode= "+rbtcode);
	String musicPath = "";
	try {

	    if (conPool == null) 
	    {
		logger.info("ConnectionPool Null");
		return -1;
   	    }

	    con = conPool.getConnection();
	    Statement stmt = con.createStatement();
	    String query = "select file_path from crbt_rbt where rbt_code = "+rbtcode;
	    logger.info(query);
	    ResultSet rs = stmt.executeQuery(query);
	    if(rs.next())
		{
		    musicPath = rs.getString("FILE_PATH");
                    if(rs != null) rs.close();
		}
	    else 
		{
                    if(rs != null) rs.close();
                    stmt.close();
		    conPool.free(con);
		    return -10;
		}
                
            if(rs != null) rs.close();
	    stmt.close();
	    conPool.free(con);
	}
	
	catch(Exception e)
	    {
		conPool.free(con);
		e.printStackTrace();
		return -99;
	    }
	finally
	{
		if(con!=null)
			conPool.free(con);
	}

	try {
	    File file = new File(musicPath);
	    FileInputStream fis = new FileInputStream(file);
	
	    int i = fis.read();
	    while(i != -1)
		{
		    out.write(i);
		    i = fis.read();
		}
	    fis.close();
	}
	catch(FileNotFoundException exp)
	    {
		exp.printStackTrace();
		return -3;
	    }
	catch(Exception e)
	    {
		e.printStackTrace();
		return -99;
	    }
	return 99;	
    }

    public int checkvalidity(String msisdn,int rbtcode)
    {
	logger.info("inside checkValidity ");

	try
	    {

		logger.info(" IAM IN THE FINCUON");

	    	if (conPool == null) {
			logger.info("ConnectionPool Null");
			return -1;
		}

		con = conPool.getConnection();

		Statement statement = con.createStatement();
	 
		int categoryId = -1;
		String query = "select categoryid from crbt_ringtone_map where rbt_code = "+rbtcode;
		logger.info(query);
		
		ResultSet rs = statement.executeQuery(query);
		if(rs.next())
		    {
			categoryId = rs.getInt(1);
                        if(rs != null) rs.close();
		    }
		else
		    {
			logger.info("rbtcode = "+rbtcode+" not found in crbt_ringtone_map");
			if(rs != null) rs.close();
                        statement.close();
                        conPool.free(con);
			return -10;
		    }


		int recorderCatID = -1;
		
		query = "select param_value from crbt_app_config_params where param_tag='crbt_recorded_category_id'";
		logger.info(query);
		rs = statement.executeQuery(query);
		if(rs.next())
		    {
			recorderCatID = Integer.parseInt(rs.getString(1));
			logger.info("recorderCatID = "+recorderCatID);
                        if(rs != null) rs.close();	
		    }
		else
		{
			logger.info("'crbt_recorded_category_id is not found in crbt_app_config_params");
		}

		logger.info("CAT ID"+categoryId);
		logger.info("recorderCatID"+recorderCatID);

		if( categoryId == recorderCatID)
		    {

			String dbmsidn ="";
			query = "select msisdn from crbt_rbt_owner  where rbt_code="+rbtcode;
			logger.info(query);
			rs = statement.executeQuery(query);
			if(rs.next())
			    {
				dbmsidn = rs.getString(1);
                                if(rs != null) rs.close();
			    }
			else
			{
				logger.info("no entry found for the query");
			}

	
			logger.info("MSISDN-"+msisdn);
			logger.info("DBMSISDN-"+dbmsidn);
	
			if(!dbmsidn.equals(msisdn) ) 
			    {
				logger.info("In not equl");
                                if(rs != null) rs.close();
                                statement.close();
				conPool.free(con);
				return -20;
			    }
		    }
                if(rs != null) rs.close();
		statement.close();
		conPool.free(con);
	    }
	catch(Exception e)
	    {
		conPool.free(con);
		e.printStackTrace();
		return -1;
	    }
		finally
		{
			if(con!=null)
				conPool.free(con);
		}
	return 99;
    }

    public void setConnectionPool(ConnectionPool conPool)
    {
	this.conPool = conPool;			
    }

    public ConnectionPool getConnectionPool()
    {
	return conPool;		
    }
}
