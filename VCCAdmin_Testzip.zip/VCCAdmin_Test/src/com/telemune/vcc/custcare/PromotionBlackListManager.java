package com.telemune.vcc.custcare;
import com.telemune.dbutilities.*;
import java.sql.ResultSet;
import org.apache.log4j.*;

public class PromotionBlackListManager
{
	private static Logger logger=Logger.getLogger(PromotionBlackListManager.class);
	private ConnectionPool conPool;
	private Connection con;
	private  ResultSet rs = null;
	private  String query=null;



	public void setConnectionPool(ConnectionPool conPool)
	{
		this.conPool = conPool;
	}



	public int addBlackListPromotion(String msisdn,String promoStr,int status,Connection con)
	{
		int promo=0;
		
		logger.debug("inside addblacklist method...");
		logger.info("msisdn is "+msisdn+" promo "+promoStr+ "status is "+status);
		try
		{     
			//con = conPool.getConnection();
                        if("OBD".equalsIgnoreCase(promoStr)) 
                          promo=1;
                        else if("*copy".equalsIgnoreCase(promoStr))
                          promo=2;
                        else if("SMS".equalsIgnoreCase(promoStr))
                          promo=4;
                        else
                         return -1;
		//	promo=Integer.parseInt(promoStr);
			if(con == null)
			{
				status=-2;

			}
			else
			{
				query="{call p_promo_blacklist_msisdn(?,?,?)}";
				logger.info("query = "+query);
				CallableStatement cstmt=con.prepareCall(query);
				cstmt.setString(1,msisdn.trim());
				cstmt.setInt(2,promo);
				cstmt.registerOutParameter(3,java.sql.Types.INTEGER);
				cstmt.execute();
				status=cstmt.getInt(3);
				cstmt.close();
			}
		}
		catch(Exception exp)
		{
			exp.printStackTrace();
			status=-1;

		}
		/*finally
		  {
		  conPool.free(con);

		  }
		 */
		logger.info("status is "+status);        
		return status;           
	}


	public int removeBlackListPromotion(String msisdn,String promoStr,int status,Connection con)
	{
		logger.info("inside removeBlackList promo method..."+promoStr+" status is "+status);
		try
		{       
			//  con = conPool.getConnection();
			int promo=0;
			if(con==null)
			{
				logger.info("connection is null");
				status=-2;
			}
			else
			{
				if("OBD".equalsIgnoreCase(promoStr)) 
                    promo=1;
                else if("*copy".equalsIgnoreCase(promoStr))
                    promo=2;
                else if("SMS".equalsIgnoreCase(promoStr))
                    promo=4;
                else
                   return -1;
				
				query="{call p_rmv_promo_blacklist(?,?,?)}";
				logger.info("query = "+query);
				CallableStatement cstmt=con.prepareCall(query);
				cstmt.setString(1,msisdn.trim());
				cstmt.setInt(2,promo);
				cstmt.registerOutParameter(3,java.sql.Types.INTEGER);
				cstmt.execute();
				status=cstmt.getInt(3);
				cstmt.close();
			}
		}
		catch(Exception exp)
		{
			exp.printStackTrace();
			status=-1;

		}
		/*finally
		  {
		  conPool.free(con);

		  }
		 */
		logger.info("status is "+status);
		return status;

	}



	public int viewBlackListPromotion(String msisdn,int status,StringBuffer respo,Connection con)
	{
		logger.info("inside viewBlackList promo method... msisdn= "+msisdn+" status= "+status);
		try
		{
			//con = conPool.getConnection();
			if(con==null)
			{
				logger.info("connection is null");
				status=-2;
			}
			else
			{
				query="{call p_view_promo_blacklist(?,?,?)}";	
				logger.info("query = "+query);
				CallableStatement cstmt=con.prepareCall(query);
				cstmt.setString(1,msisdn.trim());
				cstmt.registerOutParameter(2,java.sql.Types.INTEGER);
				cstmt.registerOutParameter(3,java.sql.Types.VARCHAR);

				cstmt.execute();
				respo.append(cstmt.getString(3));
				status=cstmt.getInt(2);
				cstmt.close();
			}
		}
		catch(Exception exp)
		{
			exp.printStackTrace();
			status=-1;

		}
		finally
		{
			// conPool.free(con);

		}
		logger.info("status is "+status+" respo values is "+respo);
		return status;

	}

}
