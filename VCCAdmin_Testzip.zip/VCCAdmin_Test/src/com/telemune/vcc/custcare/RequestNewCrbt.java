package com.telemune.vcc.custcare;
import com.telemune.dbutilities.*;
import com.telemune.vcc.common.*;

import java.sql.ResultSet;
import java.util.*;

import org.apache.log4j.*;
public class RequestNewCrbt
{
        private static Logger logger=Logger.getLogger(RequestNewCrbt.class);
	private Connection con = null;
	private ConnectionPool conpool = null;
	private PreparedStatement pstmt = null;
	private ResultSet rs = null;
	private String query=null;
            private String msisdn="";
    private String rbt="";
    private String rbtart="";
    private String rbtalb="";
    private String reqdate="";
 public void setMsisdn(String msisdn)
    {
        this.msisdn=msisdn;
    }
    public void setRbtName(String rbt)
    {
        this.rbt=rbt;
    }
    public void setRbtArt(String rbtart)
    {
        this.rbtart=rbtart;
    }
    public void setRbtAlb(String rbtalb)
    {
        this.rbtalb=rbtalb;
    }
    public void setReqdate(String reqdate)
    {
        this.reqdate=reqdate;
    }

    public String getMsisdn()
    {
       return this.msisdn;
    }
    public String getRbtName()
    {
       return this.rbt;
    }
    public String getRbtArt()
    {
       return this.rbtart;
    }
    public String getRbtAlb()
    {
       return this.rbtalb;
    }
    public String getReqdate()
    {
       return this.reqdate;
    }

 
	public RequestNewCrbt()
	{						
	}

	public RequestNewCrbt(Connection con)
	{
		setConnection(con);
	}

	public ConnectionPool getConnectionPool()
	{
		return conpool;			
	}					

	public void setConnectionPool(ConnectionPool conpool)
	{
		this.conpool = conpool;				
	}
	public Connection getConnection()
	{
		return con;			
	}					

	public void setConnection(Connection con)
	{
		this.con = con;				
	}

	
	public int addNameTuneRequest(String Msisdn,String rbt_name)
    {
         logger.info("##>> ["+Msisdn+"] inside addRequestForNameTune()");
            String msisdn= TSSJavaUtil.instance().getInternationalNumber(Msisdn);
            con=TSSJavaUtil.instance().getconnection();
            if (con == null)
            {
                    logger.error("#Msisdn>> ["+msisdn+"] CON NULL");
                    return 0;
            }
            try 
            {
                    query = "insert into NAMETUNE_LOGS(MSISDN,NAME,REQUEST_TIME,INTERFACE,STATUS) values(?,?,sysdate,'C','F')";
                    pstmt = con.prepareStatement(query);
                    pstmt.setString(1,msisdn);
                    pstmt.setString(2,rbt_name);
                    pstmt.executeUpdate();
                    pstmt.close();
                  
            }
            catch (Exception e)
            {
                    try{
                            if(pstmt !=null) pstmt.close();
                    }catch(Exception exp){}
                    e.printStackTrace();
                    return -1;
            }
            finally
            {
            	if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
            }
            return 1;
    }//addNameTuneRequest

	
	
	public int addRequest(String Msisdn,String rbt_name,String rbt_artist,String rbt_album,Connection con)  
	{
		long reqid=0;
		String msisdn= TSSJavaUtil.instance().getInternationalNumber(Msisdn);
		logger.info("Inside function addRequest()... msisdn="+Msisdn+" rbt_name="+rbt_name+" rbt_artist="+rbt_artist+" rbt_album="+rbt_album);
		//con=conpool.getConnection();
		/*if (con == null)
		{
			logger.info("CON NULL");
			return 0;
		}*/
		try
		{
			query = "select REQUEST_CRBT_SEQ.nextval from dual";
			logger.info("query = "+query);
			pstmt = con.prepareStatement(query);
			rs = pstmt.executeQuery();
			if (rs.next())
			{
				reqid = rs.getLong("NEXTVAL");
			}
			rs.close();
			pstmt.close();

			query = "insert into REQUEST_NEW_CRBT (MSISDN, REQ_ID, RBT_NAME, RBT_ARTIST, RBT_ALBUM, REQ_DATE) values (?, ?, ?, ?, ?, sysdate)";
			logger.info("query = "+query);
			pstmt = con.prepareStatement(query);
			pstmt.setString(1,msisdn);
			pstmt.setLong(2,reqid);
			pstmt.setString(3,rbt_name);
			pstmt.setString(4,rbt_artist);
			pstmt.setString(5,rbt_album);
			logger.info("DB Query ::::"+query);
			pstmt.executeUpdate();

			rs.close();
			pstmt.close();
		}
		catch (Exception e)
		{
			try{
				if(rs !=null) rs.close();
				if(pstmt !=null) pstmt.close();
			}catch(Exception exp){}
			logger.info("Exception in addRequest()...",e);
			//e.printStackTrace();
			return -1;
		}
		finally
		{
			try{
				if(rs !=null) rs.close();
				if(pstmt !=null) pstmt.close();
			}catch(Exception exp){}
			
			//conpool.free(con);
		}
		return 1;
	}//addRequest

	public int viewRequest(String Msisdn, ArrayList viewList,Connection con)
	{
		logger.info("Inside function viewRequest()...... msisdn="+Msisdn);
		long reqid=0;
		String msisdn= TSSJavaUtil.instance().getInternationalNumber(Msisdn);
		//con=conpool.getConnection();
		/*if (con == null)
		{
			logger.info("CON NULL");
			return 0;
		}*/
		try
		{
			query = "select MSISDN, REQ_ID, RBT_NAME, RBT_ARTIST, RBT_ALBUM, REQ_DATE from Request_New_Crbt where MSISDN=? order by REQ_DATE";
			logger.info("query = "+query);
			pstmt = con.prepareStatement(query);
			pstmt.setString(1,msisdn);
			logger.info("DB Query ::::"+query);
			rs = pstmt.executeQuery();	
			while(rs.next())
			{
        RequestNewCrbt rnc = new RequestNewCrbt();
              rnc.setMsisdn(rs.getString("MSISDN"));
              rnc.setRbtName(rs.getString("RBT_NAME"));
              rnc.setRbtArt(rs.getString("RBT_ARTIST"));
              rnc.setRbtAlb(rs.getString("RBT_ALBUM"));
              rnc.setReqdate(rs.getString("REQ_DATE"));
              viewList.add(rnc);

			}
			rs.close();
			pstmt.close();
		}
		catch (Exception e)
		{
			logger.error("Exception in viewrequest()...",e);
			e.printStackTrace();
			return 0;
		}
		finally
		{
			try{
				if(pstmt!=null)pstmt.close();
				if(rs!=null)rs.close();
			}catch(Exception e){}
			//conpool.free(con);
		}
		return 1;
	}//viewRequest
	/*
	   public int modifyRequest(String Msisdn,String rbt_name,String rbt_artist,String rbt_album) 
	/*
	public int modifyRequest(String Msisdn,String rbt_name,String rbt_artist,String rbt_album) 
	{
	long reqid;
	if (con == null)
	{
	logger.info("CON NULL");
	return 0;
	}
	try
	{


	//		query = "select REQID.nextval from dual";
	//		pstmt = con.prepareStatement(query);

	//			rs = pstmt.executeQuery();
	if (rs.next())
	{
	reqId = rs.getLong("NEXTVAL");
	}

	query = "insert into Request_New_Crbt (MSISDN, REQ_ID, RBT_NAME, RBT_ARTIST, RBT_ALBUM, REQ_DATE) values (?, ?, ?, ?, ?, sysdate)";
	pstmt = con.prepareStatement(query);
	pstmt.setString(1,Msisdn);
	pstmt.setLong(2,reqid);
	pstmt.setString(3,rbt_name);
	pstmt.setString(4,rbt_artist);
	pstmt.setString(5,rbt_album);
	pstmt.executeUpdate();

	catch (Exception e)
	{
	e.printStackTrace();
	return 0;
	}
	}
	return 1;
	}




	 */
public int viewRequest(ArrayList viewList,Connection con)
 {
	logger.info("Inside function viewRequest()....");
/*logger.debug("-------viewRequest");
    con=conpool.getConnection();
logger.debug("-------");
     if (con == null)
     {
         logger.info("CON NULL");
         return 0;
     }*/
     try
     {
         query = "select MSISDN, REQ_ID, RBT_NAME, RBT_ARTIST, RBT_ALBUM, REQ_DATE from Request_New_Crbt";
	logger.info("query = "+query);
         pstmt = con.prepareStatement(query);
         logger.info("DB query::::"+query);
         rs = pstmt.executeQuery();
         while(rs.next())
         {
             RequestNewCrbt rnc = new RequestNewCrbt();
              rnc.setMsisdn(rs.getString("MSISDN"));
              rnc.setRbtName(rs.getString("RBT_NAME"));
              rnc.setRbtArt(rs.getString("RBT_ARTIST"));
              rnc.setRbtAlb(rs.getString("RBT_ALBUM"));
              rnc.setReqdate(rs.getString("REQ_DATE"));
              viewList.add(rnc);
         }
         rs.close();
         pstmt.close();
     }
     catch (Exception e)
     {
    	 logger.error("Exception in viewRequest:::",e);
         return -1;
     }
     finally
     {
    		try{
				if(pstmt!=null)pstmt.close();
				if(rs!=null)rs.close();
			}catch(Exception e){}
		
         //conpool.free(con);
     }
     return 1;
 }//viewRequest

}
