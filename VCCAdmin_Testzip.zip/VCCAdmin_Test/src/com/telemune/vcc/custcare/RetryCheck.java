
package com.telemune.vcc.custcare;
import java.util.*;

import org.apache.log4j.*;
public class RetryCheck
{
      private static Logger logger=Logger.getLogger(RetryCheck.class);

//	private	String userId = "";
//	private int count = -1;
	//  private int num_tries = -1;
	  private int num = -1;

//	private static Hashtable hashtable= null;


	public RetryCheck()
	{
			//		hashtable =  new Hashtable();
	}
	/*public RetryCheck(String userId, int count)
	{
					hashtable =  new Hashtable();
					if(hashtable.containsKey(userId))
					{ 
									hashtable.remove(userId); 
					}
					     hashtable.put(userId, new Integer(count)) ;
					
	}*/

	public int checkCount(String userId, int count, Hashtable hashtable)
	{
					logger.info("checkCount() number of tries for=> "+ userId);
					//	 try{
          Enumeration e = hashtable.keys();
					while(e.hasMoreElements())
					{
					  logger.info("==>< "+e.nextElement());
					}
					if(hashtable.containsKey(userId))
					{
					   logger.debug("****contains ***");
									Integer num_tries = (Integer) hashtable.get(userId);
									 num = num_tries.intValue();
									logger.info("tries"+ num);
									if(num==3)
									{
					          logger.info("removing userId= "+ userId);
									  hashtable.remove(userId); 
										return -11;
									}

					}
					else
					{
					    //  logger.info("adding new userId-count = "+ userId+ "-"+count);
					    // hashtable.put(userId, new Integer(count)) ;
					}
									return num;
					// }//try
					//	 catch(Exception e)
					//	 {}
	}//checkCount        
	
	
}//RetryCheck
