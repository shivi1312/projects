package com.telemune.vcc.custcare;
import com.telemune.vcc.common.*;

import java.io.*;
import java.net.*;

import org.apache.log4j.*;
public class SSFClient
{
        private static Logger logger=Logger.getLogger(SSFClient.class);
	final static String SSF_SERVER_HOST = TSSJavaUtil.instance().getSSFServer();//"stp"; //TODO, take from configuration
	final static short SSF_SERVER_PORT = TSSJavaUtil.instance().getSSFPort();//10101;
	public static void main(String [] args)
	{
		int tariffID = 111;
		//Integer announcementID = new Integer(0);
		int announcementID = -1;
		StringBuffer stat = new StringBuffer();
		String msisdn = "9821490008";
		announcementID = doEventBasedCharging(tariffID, msisdn, stat);
	}

	//public static int doEventBasedCharging(int tariffID, String msisdn, Boolean chStatus, Integer annID)
	public static int doEventBasedCharging(int tariffID, String msisdn, StringBuffer chStatus)
	{
		logger.info("doEventBasedCharging()");
		Socket socket = null;
		DataOutputStream writer = null;
		DataInputStream reader = null;
		try
		{
		logger.info("opening socket to..="+SSF_SERVER_HOST+" Port="+SSF_SERVER_PORT);
			socket = new Socket (SSF_SERVER_HOST, SSF_SERVER_PORT);
		}
		catch (SocketException se)
		{
			logger.warn("Error in opening socket\n");
			se.printStackTrace();
			return -1;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return -1;
		}

		try
		{
			logger.info("opening read/write stream");
			reader = new DataInputStream(socket.getInputStream());
			writer = new DataOutputStream(socket.getOutputStream());
		}
		catch (IOException ioe)
		{
			logger.info("Failed to get input/output stream\n");
			ioe.printStackTrace();
			return -1;
		}

		try
		{
			SSFRequest request = new SSFRequest();
			SSFResponse response = new SSFResponse();
			ByteArrayOutputStream buf = new ByteArrayOutputStream();
			ByteArrayInputStream inbuf = null;
			request.setMsisdn(msisdn);
			request.setTariffID(tariffID);

			request.encode(buf);
			int requestLen = buf.size();
			//logger.info("writing Info to SSFRequest");
			logger.info("writing Info buf size="+requestLen);
			writer.writeInt(requestLen);
			writer.write(buf.toByteArray(), 0, buf.toByteArray().length);

			//logger.info("reading Info from SSFResponse");
			logger.info("reading Info ....");
			int responseLen = reader.readInt();
			logger.info("recieved response size="+responseLen);
			byte responseBuf[] = new byte[responseLen];
			reader.read(responseBuf, 0, responseLen);

			inbuf = new ByteArrayInputStream(responseBuf);
			response.decode(inbuf);

			//chStatus = new Boolean(response.getReqStatus());
			chStatus.append(response.getReqStatus());
			int annID = (new Integer(response.getAnnouncementID())).intValue();

			logger.info("ChStatus ["+ chStatus + "] annid [" + annID+ "]");
			socket.close();
			return annID;
		}
		catch (IOException ioe)
		{
			logger.info("Failed to read / write\n");
			ioe.printStackTrace();
			return -1;
		}
	}
}
