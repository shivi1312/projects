//package com.telemune.crbt.ssf;
package com.telemune.vcc.custcare;
import java.io.*;

//import java.util.*;
import org.apache.log4j.*;

public class SSFRequest
{
         private static Logger logger=Logger.getLogger(SSFRequest.class);
	final byte msisdnTag = 0x02;
	final byte tariffIDTag = 0x03;	
	final byte requestIDTag = 0x01;

	private String msisdn = "";
	private String tariffID = "";
	private int requestID = 1;

	public SSFRequest(){}

	public SSFRequest(String msisdn, int tariffID)
	{
		this.msisdn = msisdn;
		this.tariffID = tariffID+"";
	}

	public void setMsisdn(String msisdn)
	{
		this.msisdn = msisdn;
	}

	public void setTariffID(int tariffID)
	{
		this.tariffID = tariffID+"";
	}

	public int encode(ByteArrayOutputStream buf)
	{
		int status = 0;
		byte[] intBuf = new byte[4];
		byte[] reqBuf = new byte[4];
		byte[] len =    new byte[4];
		buf.reset();

		buf.write(requestIDTag);
	
		len[3] = (byte)(4 & 0xff);
		len[2] = (byte)((4 >> 8) & 0xff);
		len[1] = (byte)((4 >> 16) & 0xff);
		len[0] = (byte)((4 >> 24) & 0xff);
		buf.write(len,0, 4);

		//buf.write(4);

		/* 11223344 */ /* TODO, should we swap these bytes */
		reqBuf[3] = (byte)(requestID & 0xff);
		reqBuf[2] = (byte)((requestID >> 8) & 0xff);
		reqBuf[1] = (byte)((requestID >> 16) & 0xff);
		reqBuf[0] = (byte)((requestID >> 24) & 0xff);
		buf.write(reqBuf, 0, 4);
		
		buf.write(msisdnTag);
	 	int l_len=msisdn.length();	
//		buf.write(msisdn.length());
		len[3] = (byte)(l_len & 0xff);
		len[2] = (byte)((l_len >> 8) & 0xff);
		len[1] = (byte)((l_len >> 16) & 0xff);
		len[0] = (byte)((l_len >> 24) & 0xff);
		buf.write(len,0,4);

		buf.write(msisdn.getBytes(),0,msisdn.length());
		
		buf.write(tariffIDTag);
		l_len=tariffID.length();
		intBuf[3] = (byte)(l_len & 0xff);
		intBuf[2] = (byte)((l_len >> 8) & 0xff);
		intBuf[1] = (byte)((l_len  >> 16) & 0xff);
		intBuf[0] = (byte)((l_len >> 24) & 0xff);

		buf.write(intBuf,0,4);
		buf.write(tariffID.getBytes(),0,l_len);


		logger.debug("printing encode():");
		byte []printBuf = buf.toByteArray();
		for (int i = 0; i < buf.size(); i++)
		{
			System.out.print(Integer.toHexString(printBuf[i]) +" ");
		}
		logger.debug("");
		return 0;
	}

	public int decode(ByteArrayInputStream buf)
	{
		int tag;
		int len;
		tag = buf.read();
		
		if (tag != tariffIDTag)
		{
			return -1;
		}
		len = buf.read();
		if (len > 20 || len <= 0)
		{
		}

		byte[] intBuf = new byte[4];
		int tariffID1 = 0;
		tariffID1 = tariffID1 | intBuf[1];
		tariffID1 = (tariffID1 >> 8) | intBuf[0];
		tariffID1 = (tariffID1 >> 16) | intBuf[1];
		tariffID1 = (tariffID1 >> 16) | intBuf[1];

		if (tag != msisdnTag)
		{
			return -1;
		}
		len = buf.read();
		if (len > 20 || len <= 0)
		{
			return -1;
		}
		byte msisdnBuf[] = new byte[len];
		buf.read(msisdnBuf, 0, len);
		
		return 0;
	}

	public static void main(String [] args)
	{
		SSFRequest req = new SSFRequest();
		req.setMsisdn("9818899014");
		req.setTariffID(2);		
		ByteArrayOutputStream output = new ByteArrayOutputStream();
		req.encode(output);
	}


}


