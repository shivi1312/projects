//package com.telemune.crbt.ssf;
package com.telemune.vcc.custcare;
import java.io.*;

import org.apache.log4j.*;
public class SSFResponse
{
        private static Logger logger=Logger.getLogger(SSFResponse.class);
	final int reqStatusTag = 2;
	final int msisdnTag = 2;
	final int announcementIDTag = 3;
	final int requestIDTag = 1;

	private boolean reqStatus;
	private int announcementID;

	public SSFResponse()
	{
	}

	public void setReqStatus(boolean reqStatus)
	{
		this.reqStatus = reqStatus;
	}

	public boolean getReqStatus()
	{
		return reqStatus;
	}

	public void setAnnoncementID (int announcementID)
	{
		this.announcementID = announcementID;
	}

	public int getAnnouncementID ()
	{
		return announcementID;
	}

	public int encode(ByteArrayOutputStream buf)
	{
		int status = 0;
		byte[] intBuf = new byte[4];
		buf.reset();

		buf.write(reqStatusTag);
		buf.write(1);
		if (reqStatus)
		{
			buf.write(1);
		}
		else
		{
			buf.write(0);
		}

		buf.write(announcementIDTag);
		buf.write(4);

		/* 11223344 */ /* TODO, should we swap these bytes */
		//intBuf[3] = (byte)(tariffID & 0xff);
		//intBuf[2] = (byte)((tariffID >> 8) & 0xff);
		//intBuf[1] = (byte)((tariffID >> 16) & 0xff);
		//intBuf[0] = (byte)((tariffID >> 24) & 0xff);

		intBuf[1] = (byte)(announcementID & 0xff);
		intBuf[0] = (byte)((announcementID >> 8) & 0xff);
		intBuf[3] = (byte)((announcementID >> 16) & 0xff);
		intBuf[2] = (byte)((announcementID >> 24) & 0xff);
		buf.write(intBuf, 0, 4);

		logger.debug("");
		byte []printBuf = buf.toByteArray();
		logger.info(printBuf[0]);
		for (int i = 0; i < buf.size(); i++)
		{
			System.out.print(Integer.toHexString(printBuf[i]) +" ");
		}
		logger.debug("");
		return 0;
	}

	public int decode(ByteArrayInputStream buf)
	{
		int tag;
		int leni;
		byte len[] = new byte [4];
		byte val[] = new byte [4];
		tag = buf.read();
		if (tag!=requestIDTag)
		{
			return -1;
		}
		buf.read(len,0,4);
		buf.read(val,0,4);
	
		tag = buf.read();

		if (tag != msisdnTag)
		{
			return -1;
		}
		buf.read(len,0,4);
		buf.read(val,0,4);


		tag = buf.read();

		if (tag != announcementIDTag)
		{
			return -1;
		}
		buf.read(len,0,4);
		int reqStatusBuf = buf.read();
		//		len = buf.read();

		announcementID = reqStatusBuf;

			if (reqStatusBuf == 1)
		{
			reqStatus = true;
		}
		else
		{
			reqStatus = false;
		}
		return 0;
	}

	public static void main(String [] args)
	{
		SSFResponse res = new SSFResponse();
		res.setAnnoncementID(510);
		res.setReqStatus(true);		
		ByteArrayOutputStream output = new ByteArrayOutputStream();
		res.encode(output);

		byte temp[] = output.toByteArray();

		ByteArrayInputStream input = new ByteArrayInputStream(temp);
		res.decode(input);
		res.encode(output);
	}
}
