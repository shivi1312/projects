package com.telemune.vcc.custcare;

public class SmsHistoryBean {

	private String date;
	private String msisdn;
	private String originationNumber;
	private String destinationNumber;
	private String message;
	
	public String getOriginationNumber() {
		return originationNumber;
	}
	public void setOriginationNumber(String originationNumber) {
		this.originationNumber = originationNumber;
	}
	public String getDestinationNumber() {
		return destinationNumber;
	}
	public void setDestinationNumber(String destinationNumber) {
		this.destinationNumber = destinationNumber;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	
}
