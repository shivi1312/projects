package com.telemune.vcc.custcare;

public class SubHistoryBean {
	private String date;
   private String msisdn;
   private String interfaceType;
    private String mailBoxType;
    private String serviceType;
    private String updatedBy;
    private String description;
    private String type;
    private String originNumber;
    private String retrvTime;
    private String recordingDuratn;
    private String status;
    private String callDuration;
    private String msgLength;
    private String serverId;
    private String expiryDate;
    
    
    
    
    public String getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}
	public String getServerId() {
		return serverId;
	}
	public void setServerId(String serverId) {
		this.serverId = serverId;
	}
	public String getCallDuration() {
		return callDuration;
	}
	public void setCallDuration(String callDuration) {
		this.callDuration = callDuration;
	}
	public String getMsgLength() {
		return msgLength;
	}
	public void setMsgLength(String msgLength) {
		this.msgLength = msgLength;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getOriginNumber() {
		return originNumber;
	}
	public void setOriginNumber(String originNumber) {
		this.originNumber = originNumber;
	}
	public String getRetrvTime() {
		return retrvTime;
	}
	public void setRetrvTime(String retrvTime) {
		this.retrvTime = retrvTime;
	}
	public String getRecordingDuratn() {
		return recordingDuratn;
	}
	public void setRecordingDuratn(String recordingDuratn) {
		this.recordingDuratn = recordingDuratn;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	public String getInterfaceType() {
		return interfaceType;
	}
	public void setInterfaceType(String interfaceType) {
		this.interfaceType = interfaceType;
	}
	public String getMailBoxType() {
		return mailBoxType;
	}
	public void setMailBoxType(String mailBoxType) {
		this.mailBoxType = mailBoxType;
	}
	public String getServiceType() {
		return serviceType;
	}
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
    
}
