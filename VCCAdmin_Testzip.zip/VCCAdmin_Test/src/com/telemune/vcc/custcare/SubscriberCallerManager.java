/*
 *
 *
 *
 */
package com.telemune.vcc.custcare;
import java.util.*;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.telemune.dbutilities.*;
import com.telemune.vcc.common.*;

import org.apache.log4j.*;
public class SubscriberCallerManager
{
        private static Logger logger=Logger.getLogger(SubscriberCallerManager.class);
	private Connection con = null;

	public SubscriberCallerManager()
	{						
	}

	public SubscriberCallerManager(Connection con)
	{
		setConnection(con);
	}

	public Connection getConnection()
	{
		return con;			
	}					

	public void setConnection(Connection con)
	{
		this.con = con;				
	}

	public int setDefaultTone(String msisdn, ArrayList toneSettingsAl, int rbtCode)
	{
		logger.info("inside setDefaultTone() msisdn= "+msisdn+" rbtCode= "+rbtCode);
		PreparedStatement pstmtUpdate = null, pstmtInsert = null, pstmt = null;
		ResultSet rs = null;
		String queryUpdate, queryInsert, query;
		
		queryUpdate = "update CRBT_DEFAULT_DETAIL set RBT_CODE = ?, UPDATE_TIME = sysdate where MSISDN = ? and DAY = ? and START_AT = ? and ENDS_AT = ?";
		queryInsert = "insert into CRBT_DEFAULT_DETAIL (MSISDN, DAY, START_AT, ENDS_AT, RBT_CODE, UPDATE_TIME) values (?,?,?,?,?,sysdate)";
		logger.info("queryUpdate = "+queryUpdate);
		logger.info("queryInsert = "+queryInsert);
		try 
		{
			pstmtUpdate = con.prepareStatement(queryUpdate);
			pstmtInsert = con.prepareStatement(queryInsert);

			pstmtUpdate.setInt(1, rbtCode);
			pstmtUpdate.setString(2, msisdn.trim());

			pstmtInsert.setString(1, msisdn.trim());
			pstmtInsert.setInt(5, rbtCode);
			
			Iterator ite = toneSettingsAl.iterator();

			while(ite.hasNext())
			{
				ToneSetting toneSetting = (ToneSetting)ite.next();
				if ((toneSetting.getDay() == 8) && (toneSetting.getStartTime() == 2500) && (toneSetting.getEndTime() == 2500))
				{
					query = "update CRBT_SUBSCRIBER_MASTER set RBT_CODE = ? where MSISDN = ?";
					pstmt = con.prepareStatement(query);
					pstmt.setInt(1, rbtCode);
					pstmt.setString(2, msisdn.trim());
					pstmt.executeUpdate();
					pstmt.close();
				}				
				pstmtUpdate.setInt(3, toneSetting.getDay());
				pstmtUpdate.setInt(4, toneSetting.getStartTime());
				pstmtUpdate.setInt(5, toneSetting.getEndTime());

				if (pstmtUpdate.executeUpdate() >= 1)
				{
				}
				else
				{
					pstmtInsert.setInt(2, toneSetting.getDay());
					pstmtInsert.setInt(3, toneSetting.getStartTime());
					pstmtInsert.setInt(4, toneSetting.getEndTime());
					pstmtInsert.executeUpdate();
				}
			}
			pstmtUpdate.close();
			pstmtInsert.close();

			return updateDefaultString(msisdn);
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
	}

	public int setGroupTone(long groupId, String msisdn, ArrayList toneSettingsAl, int rbtCode)
	{
		logger.info("inside setGroupTone() groupId= "+groupId+" msisdn="+msisdn+" rbtCode= "+rbtCode);
		PreparedStatement pstmtUpdate = null, pstmtInsert = null;
		String queryUpdate, queryInsert;
		
		queryUpdate = "update CRBT_GROUP_SETTING set RBT_CODE = ?, UPDATE_TIME = sysdate where MSISDN = ? and GROUPID = ? and DAY = ? and START_AT = ? and ENDS_AT = ?";
		queryInsert = "insert into CRBT_GROUP_SETTING (MSISDN, GROUPID, DAY, START_AT, ENDS_AT, RBT_CODE, UPDATE_TIME) values (?,?,?,?,?,?,sysdate)";
		logger.info("queryUpdate = "+queryUpdate);
		logger.info("queryInsert = "+queryInsert);
		try 
		{
			pstmtUpdate = con.prepareStatement(queryUpdate);
			pstmtInsert = con.prepareStatement(queryInsert);

			pstmtUpdate.setInt(1, rbtCode);
			pstmtUpdate.setString(2, msisdn.trim());
			pstmtUpdate.setLong(3, groupId);

			pstmtInsert.setString(1, msisdn.trim());
			pstmtInsert.setLong(2, groupId);
			pstmtInsert.setInt(6, rbtCode);
			
			Iterator ite = toneSettingsAl.iterator();

			while(ite.hasNext())
			{
				ToneSetting toneSetting = (ToneSetting)ite.next();
				pstmtUpdate.setInt(4, toneSetting.getDay());
				pstmtUpdate.setInt(5, toneSetting.getStartTime());
				pstmtUpdate.setInt(6, toneSetting.getEndTime());

				if (pstmtUpdate.executeUpdate() >= 1)
				{
				}
				else
				{
					pstmtInsert.setInt(3, toneSetting.getDay());
					pstmtInsert.setInt(4, toneSetting.getStartTime());
					pstmtInsert.setInt(5, toneSetting.getEndTime());
					pstmtInsert.executeUpdate();
				}
			}			
			pstmtUpdate.close();
			pstmtInsert.close();

			return updateGroupString(groupId);
		}
		catch (Exception e)
	  {
			e.printStackTrace();
			return 0;
	  }
	}

	public int setFriendTone(String friendMsisdn, String msisdn, ArrayList toneSettingsAl, int rbtCode)
	{
		logger.info("inside setFriendTone() friendMsisdn= "+friendMsisdn+" msisdn= "+msisdn+" rbtCode= "+rbtCode);
		PreparedStatement pstmtUpdate = null, pstmtInsert = null;
		ResultSet rs = null;
		String queryUpdate, queryInsert;
		
		queryUpdate = "update CRBT_FRIEND_SETTING set RBT_CODE = ?, UPDATE_TIME = sysdate where MSISDN = ? and FRIEND_MSISDN = ? and DAY = ? and START_AT = ? and ENDS_AT = ?";
		queryInsert = "insert into CRBT_FRIEND_SETTING (MSISDN, FRIEND_MSISDN, DAY, START_AT, ENDS_AT, RBT_CODE, UPDATE_TIME) values (?,?,?,?,?,?,sysdate)";
		logger.info("queryUpdate = "+queryUpdate);
		logger.info("queryInsert = "+queryInsert);
		try 
		{
			pstmtUpdate = con.prepareStatement(queryUpdate);
			pstmtInsert = con.prepareStatement(queryInsert);

			pstmtUpdate.setInt(1, rbtCode);
			pstmtUpdate.setString(2, msisdn.trim());
			pstmtUpdate.setString(3, friendMsisdn);

			pstmtInsert.setString(1, msisdn.trim());
			pstmtInsert.setString(2, friendMsisdn.trim());
			pstmtInsert.setInt(6, rbtCode);
			
			Iterator ite = toneSettingsAl.iterator();

			while(ite.hasNext())
			{
				ToneSetting toneSetting = (ToneSetting)ite.next();
				pstmtUpdate.setInt(4, toneSetting.getDay());
				pstmtUpdate.setInt(5, toneSetting.getStartTime());
				pstmtUpdate.setInt(6, toneSetting.getEndTime());

				if (pstmtUpdate.executeUpdate() >= 1)
				{
				}
				else
				{
					pstmtInsert.setInt(3, toneSetting.getDay());
					pstmtInsert.setInt(4, toneSetting.getStartTime());
					pstmtInsert.setInt(5, toneSetting.getEndTime());
					pstmtInsert.executeUpdate();
				}
			}
			pstmtUpdate.close();
			pstmtInsert.close();

			return updateFriendString(msisdn, friendMsisdn);
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
	}

	public int setDateTone(String msisdn, String date[], int rbtCode)
	{
		logger.info("inside setDateTone() msisdn= "+msisdn+" rbtCode= "+rbtCode);
		PreparedStatement pstmtUpdate = null, pstmtInsert = null;
		ResultSet rs = null;
		String queryUpdate, queryInsert;
		
		queryUpdate = "update CRBT_EVENTDATE_RBT set RBT_CODE = ?, UPDATE_TIME = sysdate, OCCASION_NAME='0' where MSISDN = ? and EVENT_DATE = to_date(?, 'DD-MM-YYYY')";
		queryInsert = "insert into CRBT_EVENTDATE_RBT (MSISDN, EVENT_DATE, RBT_CODE, UPDATE_TIME,OCCASION_NAME) values (?, to_date(?,'DD-MM-YYYY'), ?, sysdate,0)";
		logger.info("queryUpdate = "+queryUpdate);
		logger.info("queryInsert = "+queryInsert);
		try 
		{
			pstmtUpdate = con.prepareStatement(queryUpdate);

			pstmtUpdate.setInt(1, rbtCode);
			pstmtUpdate.setString(2, msisdn.trim());
			pstmtUpdate.setString(3,date[0]+"-"+date[1]+"-"+date[2]);

			if (pstmtUpdate.executeUpdate() >= 1)
			{
				logger.info("updated");
			}
			else
			{
				pstmtInsert = con.prepareStatement(queryInsert);

				pstmtInsert.setString(1, msisdn.trim());
				pstmtInsert.setString(2,date[0]+"-"+date[1]+"-"+date[2]);
				pstmtInsert.setInt(3, rbtCode);
			
				pstmtInsert.executeUpdate();
				pstmtInsert.close();
				logger.info("inserted");
			}
			Date today = new Date();
			if ((Integer.parseInt(date[0])==today.getDate()) && (Integer.parseInt(date[1])==(today.getMonth()+1)) && (Integer.parseInt(date[2])==(today.getYear()+1900)))
			{
				queryUpdate = "update CRBT_SUBSCRIBER_MASTER set DATE_SETTING_VALIDITY = 1 where MSISDN = ?";
				logger.info("queryUpdate = "+queryUpdate);
				pstmtUpdate = con.prepareStatement(queryUpdate);

				pstmtUpdate.setString(1, msisdn.trim());
				pstmtUpdate.executeUpdate();	
			}
			pstmtUpdate.close();
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
		return 1;
	}
	public int setOccTone(String msisdn, String date[], int rbtCode, String occName)
	{
		logger.info("inside setOccTone() msisdn = "+msisdn+" rbtCode= "+rbtCode+" occName= "+occName);
		PreparedStatement pstmtUpdate = null, pstmtInsert = null;
		ResultSet rs = null;
		String queryUpdate, queryInsert;
		
		queryUpdate = "update CRBT_EVENTDATE_RBT set RBT_CODE = ?, UPDATE_TIME = sysdate,OCCASION_NAME=? where MSISDN = ? and EVENT_DATE = to_date(?, 'DD-MM-YYYY')";
		queryInsert = "insert into CRBT_EVENTDATE_RBT (MSISDN, EVENT_DATE, RBT_CODE, UPDATE_TIME,OCCASION_NAME) values (?, to_date(?,'DD-MM-YYYY'), ?, sysdate,?)";
		logger.info("queryUpdate = "+queryUpdate);
		logger.info("queryInsert = "+queryInsert);
		try 
		{
			pstmtUpdate = con.prepareStatement(queryUpdate);

			pstmtUpdate.setInt(1, rbtCode);
			pstmtUpdate.setString(2,occName.trim());
			pstmtUpdate.setString(3, msisdn.trim());
			pstmtUpdate.setString(4,date[0]+"-"+date[1]+"-"+date[2]);

			if (pstmtUpdate.executeUpdate() >= 1)
			{	
				logger.info("updated");
			}
			else
			{
				pstmtInsert = con.prepareStatement(queryInsert);

				pstmtInsert.setString(1, msisdn.trim());
				pstmtInsert.setString(2,date[0]+"-"+date[1]+"-"+date[2]);
				pstmtInsert.setInt(3, rbtCode);
				pstmtInsert.setString(4,occName.trim());
			
				pstmtInsert.executeUpdate();
				pstmtInsert.close();
				logger.info("inserted");
			}
			Date today = new Date();
			if ((Integer.parseInt(date[0])==today.getDate()) && (Integer.parseInt(date[1])==(today.getMonth()+1)) && (Integer.parseInt(date[2])==(today.getYear()+1900)))
			{
				queryUpdate = "update CRBT_SUBSCRIBER_MASTER set DATE_SETTING_VALIDITY = 1 where MSISDN = ?";
				logger.info("queryUpdate = "+queryUpdate);
				pstmtUpdate = con.prepareStatement(queryUpdate);

				pstmtUpdate.setString(1, msisdn.trim());
				pstmtUpdate.executeUpdate();	
			}
			pstmtUpdate.close();
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
		return 1;
	}

	public int getSubscriberDefaultSettings(String msisdn, ArrayList toneSettingsAl)
	{
		logger.info("inside getSubscriberDefaultSettings() msisdn= "+msisdn);
		try
		{
			String query = "select DAY, START_AT, ENDS_AT, CDD.RBT_CODE, CR.MASKED_NAME, CR.CORP_ID from CRBT_DEFAULT_DETAIL CDD, CRBT_RBT CR where MSISDN = ? and CDD.RBT_CODE = CR.RBT_CODE order by START_AT desc, ENDS_AT desc, DAY desc";
			logger.info("query = "+query);
			PreparedStatement pstmt = con.prepareStatement(query);

			pstmt.setString(1,msisdn);			

			toneSettingsAl.clear();
	
			ResultSet rs = pstmt.executeQuery();

			while(rs.next())
			{
				ToneSetting ts = new ToneSetting();
				ts.setDay(rs.getInt(1));
				ts.setStartTime(rs.getInt(2));				
				ts.setEndTime(rs.getInt(3));
				ts.setRbtCode(rs.getInt(4));
				ts.setRbtMaskName(rs.getString(5));
				ts.setCorpId(rs.getLong(6));
				toneSettingsAl.add(ts);
			}

			rs.close();
			pstmt.close();
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}	
		return 1;
	}

	public int getSubscriberDateSettings(String msisdn, ArrayList toneSettingsAl)
	{
		logger.info("inside getSubscriberDateSettings() msisdn= "+msisdn);
		try
		{
			String query = "select to_char(EVENT_DATE, 'DD-MM-YYYY') EVENT_DATE, CER.RBT_CODE, CR.MASKED_NAME from CRBT_EVENTDATE_RBT CER, CRBT_RBT CR where MSISDN = ? and CER.RBT_CODE = CR.RBT_CODE and (CER.OCCASION_NAME='0' or CER.OCCASION_NAME='NA') order by  to_date(EVENT_DATE, 'DD-MM-YYYY') desc";
			PreparedStatement pstmt = con.prepareStatement(query);
			
			pstmt.setString(1,msisdn);

			toneSettingsAl.clear();

			ResultSet rs = pstmt.executeQuery();

			while (rs.next())
			{
				ToneSetting ts = new ToneSetting();
				ts.setDate(rs.getString(1));
				ts.setRbtCode(rs.getInt(2));
				ts.setRbtMaskName(rs.getString(3));
				toneSettingsAl.add(ts);
			}
			
			rs.close();
			pstmt.close();
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}	
		return 1;	
	}
	public int getSubscriberOccSettings(String msisdn, ArrayList toneSettingsAl)
	{
		logger.info("getSubscriberOccSettings() msisdn = "+msisdn);
		logger.debug("Occ Setting");	

		try
		{
			String query = "select to_char(EVENT_DATE, 'DD-MM-YYYY') EVENT_DATE, CER.RBT_CODE, CR.MASKED_NAME,CER.OCCASION_NAME from CRBT_EVENTDATE_RBT CER, CRBT_RBT CR where MSISDN = ? and CER.RBT_CODE = CR.RBT_CODE and not (CER.OCCASION_NAME='0' or CER.OCCASION_NAME='NA') order by  to_date(EVENT_DATE, 'DD-MM-YYYY') desc";
			logger.info("query = "+query);
			PreparedStatement pstmt = con.prepareStatement(query);
			
			pstmt.setString(1,msisdn);

			toneSettingsAl.clear();

			ResultSet rs = pstmt.executeQuery();

			while (rs.next())
			{
				ToneSetting ts = new ToneSetting();
				ts.setDate(rs.getString(1));
				ts.setRbtCode(rs.getInt(2));
				ts.setRbtMaskName(rs.getString(3));
				ts.setOccasionName(rs.getString(4));
				toneSettingsAl.add(ts);
			}
		logger.info(query);	
			rs.close();
			pstmt.close();
		}
		catch (Exception e)
		{
		logger.error(e.toString());	
			e.printStackTrace();
			return 0;
		}	
		return 1;	
  }	
	public int getSubscriberFriendSettings(String msisdn, String friendMsisdn, ArrayList toneSettingsAl)
	{
		logger.info("inside getSubscriberFriendSettings() msisdn = "+msisdn+" friendMsisdn= "+friendMsisdn);
		try
		{
			String query = "select DAY, START_AT, ENDS_AT, CFS.RBT_CODE, CR.MASKED_NAME from CRBT_FRIEND_SETTING CFS, CRBT_RBT CR where MSISDN = ? and FRIEND_MSISDN = ? and CFS.RBT_CODE = CR.RBT_CODE order by START_AT, ENDS_AT, RBT_CODE";
			logger.info("query = "+query);
			PreparedStatement pstmt = con.prepareStatement(query);

			pstmt.setString(1, msisdn);
			pstmt.setString(2, friendMsisdn);
				
			ResultSet rs = pstmt.executeQuery();

			while (rs.next())
			{
				ToneSetting ts = new ToneSetting();
				ts.setDay(rs.getInt(1));
				ts.setStartTime(rs.getInt(2));
				ts.setEndTime(rs.getInt(3));
				ts.setRbtCode(rs.getInt(4));
				ts.setRbtMaskName(rs.getString(5));
				toneSettingsAl.add(ts);
			}
			rs.close();
			pstmt.close();
			return 1;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
	}

	public int getSubscriberFriendSettings(String msisdn, ArrayList friends, ArrayList advance)
	{
		logger.info("inside getSubscriberFriendsSettings() msisdn = "+msisdn);
		try
		{
			String query = "select FRIEND_MSISDN, NICK from CRBT_FRIEND_DETAIL where MSISDN = ?";
			logger.info("query = "+query);
			PreparedStatement pstmt = con.prepareStatement(query);

			pstmt.setString(1, msisdn);
			
			ResultSet rs = pstmt.executeQuery();

			friends.clear();
			ArrayList friendList = new ArrayList();
			while (rs.next())
			{
				SubscriberFriend sf = new SubscriberFriend();
				sf.setMsisdn(msisdn);
				sf.setFriendsMsisdn(rs.getString("FRIEND_MSISDN"));
				logger.info("friends msisdn = "+rs.getString("FRIEND_MSISDN"));
				String nick = rs.getString("NICK");

				if (nick == null || nick == "")
					nick = sf.getFriendsMsisdn();

				sf.setFriendsNick (nick);
				friendList.add(sf);
			}
			if(rs != null) rs.close();
			
			query = "select DAY, START_AT, ENDS_AT, CFS.RBT_CODE, CR.MASKED_NAME from CRBT_FRIEND_SETTING CFS, CRBT_RBT CR where MSISDN = ? and FRIEND_MSISDN = ? and CFS.RBT_CODE = CR.RBT_CODE order by START_AT, ENDS_AT, RBT_CODE";
			logger.info("query = "+query);
			pstmt = con.prepareStatement(query);

			for (int i=0; i<friendList.size(); i++)
			{
				SubscriberFriend sf = (SubscriberFriend) friendList.get(i);
				if (getFriendAdvancedTone(sf.getMsisdn(), sf) == 1)
				{
					advance.add(sf);
				}
				pstmt.setString(1, sf.getMsisdn());
				pstmt.setString(2, sf.getFriendsMsisdn());
				
				rs = pstmt.executeQuery();
				ArrayList toneSettingsAl = new ArrayList();
				while (rs.next())
				{
					ToneSetting ts = new ToneSetting();
					ts.setDay(rs.getInt(1));
					ts.setStartTime(rs.getInt(2));
					ts.setEndTime(rs.getInt(3));
					ts.setRbtCode(rs.getInt(4));
					ts.setRbtMaskName(rs.getString(5));
					toneSettingsAl.add(ts);
				}
				sf.setToneSettings(toneSettingsAl);
				friends.add(sf);
			}
			pstmt.close();
			return 1;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
	}
  
	public int getSubscriberGroupSettings(long groupId, ArrayList toneSettingsAl)
	{
		logger.info("inside getSubscriberGroupSettings() groupId = "+groupId);
		try
		{
			String query = "select DAY, START_AT, ENDS_AT, CGS.RBT_CODE, CR.MASKED_NAME from CRBT_GROUP_SETTING CGS, CRBT_RBT CR where GROUPID = ? and CGS.RBT_CODE = CR.RBT_CODE order by START_AT, ENDS_AT, RBT_CODE";
			logger.info("query = "+query);
			PreparedStatement pstmt = con.prepareStatement(query);

			pstmt.setLong(1, groupId);
				
			ResultSet rs = pstmt.executeQuery();

			while (rs.next())
			{
				ToneSetting ts = new ToneSetting();
				ts.setDay(rs.getInt(1));
				ts.setStartTime(rs.getInt(2));
				ts.setEndTime(rs.getInt(3));
				ts.setRbtCode(rs.getInt(4));
				ts.setRbtMaskName(rs.getString(5));
				toneSettingsAl.add(ts);
			}
			rs.close();
			pstmt.close();
			return 1;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
	}

	public int getSubscriberGroupSettings(String msisdn, ArrayList groups, ArrayList advance)
	{
		logger.info("inside getSubscriberGroupSettings() msisdn= "+msisdn);
		try
		{
			String query = "select GROUPID, MASKED_NAME from CRBT_GROUP_DETAIL where MSISDN = ?";
			logger.info("query = "+query);
			PreparedStatement pstmt = con.prepareStatement(query);

			pstmt.setString(1, msisdn);
			
			ResultSet rs = pstmt.executeQuery();

			groups.clear();
			ArrayList groupList = new ArrayList();
			while (rs.next())
			{
				SubscriberGroup sg = new SubscriberGroup();
				sg.setMsisdn(msisdn);
				sg.setGroupId(rs.getLong("GROUPID"));
				sg.setGroupName(rs.getString("MASKED_NAME"));
				groupList.add(sg);
				logger.info("groupid = "+rs.getLong("GROUPID")+" masked name = "+rs.getString("MASKED_NAME"));
			}
      if(rs != null) rs.close();
			
			query = "select DAY, START_AT, ENDS_AT, CGS.RBT_CODE, CR.MASKED_NAME from CRBT_GROUP_SETTING CGS, CRBT_RBT CR where MSISDN = ? and GROUPID = ? and CGS.RBT_CODE = CR.RBT_CODE order by START_AT, ENDS_AT, RBT_CODE";
			logger.info("query = "+query);
			pstmt = con.prepareStatement(query);

			for (int i=0; i<groupList.size(); i++)
			{
				SubscriberGroup sg = (SubscriberGroup) groupList.get(i);
				if (getGroupAdvancedTone(sg) == 1)
				{
					advance.add(sg);
				}
				pstmt.setString(1, sg.getMsisdn());
				pstmt.setLong(2, sg.getGroupId());
				
				rs = pstmt.executeQuery();

				ArrayList toneSettingsAl = new ArrayList();
				while (rs.next())
				{
					ToneSetting ts = new ToneSetting();
					ts.setDay(rs.getInt(1));
					ts.setStartTime(rs.getInt(2));
					ts.setEndTime(rs.getInt(3));
					ts.setRbtCode(rs.getInt(4));
					ts.setRbtMaskName(rs.getString(5));
					toneSettingsAl.add(ts);
				}
				sg.setToneSettings(toneSettingsAl);
				groups.add(sg);
			}
			pstmt.close();
			return 1;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
	}
  
	public int deleteSubscriberDefaultSetting(String msisdn, int startTime, int endTime, int rbtCode)
	{
		logger.info("inside deleteSubscriberDefaultSettings() msisdn= "+msisdn+" startTime="+startTime+" endTime= "+endTime+" rbtCode= "+rbtCode);
		try
		{
			String query = "delete from CRBT_DEFAULT_DETAIL where MSISDN = ? and START_AT = ? and ENDS_AT = ? and RBT_CODE = ?";
			logger.info("query = "+query);
			PreparedStatement pstmt = con.prepareStatement(query);
		
			pstmt.setString(1, msisdn);	
			pstmt.setInt(2, startTime);	
			pstmt.setInt(3, endTime);	
			pstmt.setInt(4, rbtCode);
			pstmt.executeUpdate();

			pstmt.close();
			return updateDefaultString(msisdn);
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
	}

	public int deleteSubscriberDateSetting(String msisdn, String date, int rbtCode)
	{
		logger.info("inside deleteSubscriberDateSetting() msisdn= "+msisdn+" date="+date+" rbtCode="+rbtCode);
		try
		{
			String query = "delete from CRBT_EVENTDATE_RBT where MSISDN = ? and EVENT_DATE = to_date(?,'DD-MM-YYYY') and RBT_CODE = ?";
			logger.info("query = "+query);
			PreparedStatement pstmt = con.prepareStatement(query);
		
			pstmt.setString(1, msisdn);	
			pstmt.setString(2, date);	
			pstmt.setInt(3, rbtCode);

			pstmt.executeUpdate();
			logger.info("deleted");
			Date today = new Date();
			if ((Integer.parseInt(date.substring(0,2))==today.getDate()) && (Integer.parseInt(date.substring(3,5))==(today.getMonth()+1)) && (Integer.parseInt(date.substring(6))==(today.getYear()+1900)))
			{
				query = "update CRBT_SUBSCRIBER_MASTER set DATE_SETTING_VALIDITY = 0 where MSISDN = ?";
				logger.info("query = "+query);
				pstmt = con.prepareStatement(query);
				pstmt.setString(1, msisdn);
				pstmt.executeUpdate();	
				logger.info("updated");
			}	
			pstmt.close(); 
			return 1;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
	}
  
	public int deleteSubscriberFriendSetting(String msisdn, int startTime, int endTime, String friendsMsisdn, int rbtCode)
	{
		logger.info("inside deleteSubscriberFriendSetting() msisdn= "+msisdn+" startTime= "+startTime+" endTime= "+endTime+" friendMsisdn= "+friendsMsisdn+" rbtCode"+ rbtCode);
		try
		{
			String query = "delete from CRBT_FRIEND_SETTING where MSISDN = ? and FRIEND_MSISDN = ? and START_AT = ? and ENDS_AT = ? and RBT_CODE = ?";
			logger.info("query = "+query);
			PreparedStatement pstmt = con.prepareStatement(query);
		
			pstmt.setString(1, msisdn);	
			pstmt.setString(2, friendsMsisdn);	
			pstmt.setInt(3, startTime);
			pstmt.setInt(4, endTime);
			pstmt.setInt(5, rbtCode);

			pstmt.executeUpdate();
	
			pstmt.close(); 
			return updateFriendString(msisdn, friendsMsisdn);
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
	}

  public int deleteSubscriberGroupSetting(String msisdn, long groupId, int startTime, int endTime, int rbtCode)
	{
		logger.info("inside deleteSubscriberGroupSetting() msisdn= "+msisdn+" groupId= "+groupId+" startTime= "+startTime+" endTime= "+endTime+" rbtCode= "+rbtCode);
		try
		{
			String query = "delete from CRBT_GROUP_SETTING where MSISDN = ? and GROUPID = ? and START_AT = ? and ENDS_AT = ? and RBT_CODE = ?";
			logger.info("query = "+query);
			PreparedStatement pstmt = con.prepareStatement(query);
		
			pstmt.setString(1, msisdn);	
			pstmt.setLong(2, groupId);	
			pstmt.setInt(3, startTime);
			pstmt.setInt(4, endTime);
			pstmt.setInt(5, rbtCode);

			pstmt.executeUpdate();
	
			pstmt.close(); 
			return updateGroupString(groupId);
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
	}

	public int updateDefaultTone(String msisdn, ArrayList toneSettingsAl, int startTime, int endTime, int rbtCode)
	{
		logger.info("inside updateDefaultTone() msisdn= "+msisdn+" startTime= "+startTime+" endTime= "+endTime+" rbtCode= "+rbtCode);
		try
		{	
			String query = "delete from CRBT_DEFAULT_DETAIL where MSISDN = ? and START_AT = ? and ENDS_AT = ? and RBT_CODE = ?";
			logger.info("query = "+query);
			PreparedStatement pstmt = con.prepareStatement(query);

			pstmt.setString(1, msisdn);
			pstmt.setInt(2, startTime);
			pstmt.setInt(3, endTime);
			pstmt.setInt(4, rbtCode);

			pstmt.executeUpdate();
			pstmt.close();
	
			return 1;
			
			//setDefaultTone(msisdn, toneSettingsAl, rbtCode); ashu
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
	}

	public int updateFriendTone(String msisdn, String friendsMsisdn, ArrayList toneSettingsAl, int startTime, int endTime, int rbtCode)
	{
		logger.info("updateFriendTone msisdn = "+msisdn+" friendsMsisdn= "+friendsMsisdn+" startTime= "+startTime+" endTime= "+endTime+" rbtCode= "+rbtCode);
		try
		{	
			String query = "delete from CRBT_FRIEND_SETTING where MSISDN = ? and FRIEND_MSISDN = ? and START_AT = ? and ENDS_AT = ? and RBT_CODE = ?";
			logger.info("query = "+query);
			PreparedStatement pstmt = con.prepareStatement(query);

			pstmt.setString(1, msisdn);
			pstmt.setString(2, friendsMsisdn);
			pstmt.setInt(3, startTime);
			pstmt.setInt(4, endTime);
			pstmt.setInt(5, rbtCode);

			pstmt.executeUpdate();
			pstmt.close();
	return 1;
//			return setFriendTone(friendsMsisdn, msisdn, toneSettingsAl, rbtCode);ashu
			
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
	}

	public int updateGroupTone(String msisdn, long groupId, ArrayList toneSettingsAl, int startTime, int endTime, int rbtCode)
	{
		logger.info("inside updateGroupTone msisdn = "+msisdn+" groupId= "+groupId+" startTime= "+startTime+" endTime= "+endTime+" rbtCode= "+rbtCode);
		try
		{	
			String query = "delete from CRBT_GROUP_SETTING where MSISDN = ? and GROUPID = ? and START_AT = ? and ENDS_AT = ? and RBT_CODE = ?";
			logger.info("query = "+query);
			PreparedStatement pstmt = con.prepareStatement(query);

			pstmt.setString(1, msisdn);
			pstmt.setLong(2, groupId);
			pstmt.setInt(3, startTime);
			pstmt.setInt(4, endTime);
			pstmt.setInt(5, rbtCode);

			pstmt.executeUpdate();
			pstmt.close();
	
			return 1;
			//setGroupTone(groupId, msisdn, toneSettingsAl, rbtCode); ashu
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
	}

	public int setGroupAdvanceTone(String msisdn, String control_name, int catId, long groupId)
	{
		logger.info("setGroupAdvanceTone msisdn= "+msisdn+" control_name= "+control_name+" catId= "+catId+" groupId= "+groupId);
		try
		{
			String query = "select CONTROL_ID from CRBT_RBT_CONTROL where CONTROL_NAME = ? and CAT_ID = ?";
			logger.info("query = "+query);
			PreparedStatement pstmt = con.prepareStatement(query);

			pstmt.setString(1, control_name);
			pstmt.setInt(2, catId);
 	
			ResultSet rs = pstmt.executeQuery();

			int control_id = 0;

			if (rs.next())
			{
				control_id = rs.getInt("CONTROL_ID");
				logger.info("control_id = "+control_id);
			}
			else
			{
				logger.info("control Id not found for the query");
			}

			query = "update CRBT_GROUP_DETAIL set CONTROL_RBT_CODE = ? where MSISDN = ? and GROUPID = ?";
			logger.info("query = "+query);
			pstmt = con.prepareStatement(query);

			pstmt.setInt(1, control_id);
			pstmt.setString(2, msisdn.trim());
			pstmt.setLong(3, groupId);

			pstmt.executeUpdate();

			pstmt.close();
			return control_id;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
	}

	public int setFriendAdvanceTone(String msisdn, String control_name, int catId, String friendsMsisdn)
	{
	   	logger.info("inside setFriendAdvanceTone() msisdn= "+msisdn+" control_name= "+control_name+" catId= "+catId+" frinedsMsisdn= "+friendsMsisdn);
		try
		{
			String query = "select CONTROL_ID from CRBT_RBT_CONTROL where CONTROL_NAME = ? and CAT_ID = ?";
			logger.info("query = "+query);
			PreparedStatement pstmt = con.prepareStatement(query);

			pstmt.setString(1, control_name);
			pstmt.setInt(2, catId);
 	
			ResultSet rs = pstmt.executeQuery();

			int control_id = 0;

			if (rs.next())
			{
				control_id = rs.getInt("CONTROL_ID");
				logger.info("control_id = "+control_id);
			}
			else
			{
				logger.info("control_id not found for the query");
			}

			query = "update CRBT_FRIEND_DETAIL set CONTROL_RBT_CODE = ? where MSISDN = ? and FRIEND_MSISDN = ?";
			logger.info("query = "+query);
			pstmt = con.prepareStatement(query);

			pstmt.setInt(1, control_id);
			pstmt.setString(2, msisdn.trim());
			pstmt.setString(3, friendsMsisdn.trim());

			pstmt.executeUpdate();

			pstmt.close();
			return control_id;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
	}

	public int setAdvanceTone(String msisdn, String control_name, int catId)
	{
 			logger.info("SubscriberCallerManager: setAdvanceTone() msisdn= "+msisdn+" control_name= "+control_name+" catId= "+catId);
		try
		{
			String query = "select CONTROL_ID from CRBT_RBT_CONTROL where CONTROL_NAME = ? and CAT_ID = ?";
			logger.info("query = "+query);
			PreparedStatement pstmt = con.prepareStatement(query);

			pstmt.setString(1, control_name);
			pstmt.setInt(2, catId);
 	
	   			logger.info(query);
			ResultSet rs = pstmt.executeQuery();

			int control_id = 0;

			if (rs.next())
			{
				control_id = rs.getInt("CONTROL_ID");
				logger.info("control_id = "+control_id);
			}
			else
			{
				logger.info("control_id not found for the query");
			}

	   		logger.info("control_id="+control_id+" msisdn="+msisdn);
			query = "update CRBT_SUBSCRIBER_MASTER set RBT_CODE = ? where MSISDN = ?";
			logger.info("query = "+query);
			pstmt = con.prepareStatement(query);

			pstmt.setInt(1, control_id);
			pstmt.setString(2, msisdn.trim());
	   			logger.info(query);

			pstmt.executeUpdate();

			pstmt.close();
			return control_id;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
	}

	public int getAdvancedTone(String msisdn, Rbt rbt)
	{
		logger.info("inside getAdvanceTone() msisdn= "+msisdn);
		try
		{
			String query = "select RBT_CODE from CRBT_SUBSCRIBER_MASTER where MSISDN = ?";
			logger.info("query = "+query);
			PreparedStatement pstmt = con.prepareStatement(query);

			pstmt.setString(1, msisdn);

			ResultSet rs = pstmt.executeQuery();

			int rbtId = 0;
			if (rs.next())
			{
				rbtId = rs.getInt("RBT_CODE");
				logger.info("rbtCode = "+rbtId);
			}
			else
			{
				logger.info("rbtCode not found for the query");
			}
			rs.close();
				

//			query = "select CONTROL_NAME, CRC.CAT_ID, MASKED_NAME from CRBT_RBT_CONTROL CRC, " +
	//				"CRBT_CATEGORY_MASTER CCM where CRC.CAT_ID = CCM.CAT_ID and CONTROL_ID = ?";

			query = "select CONTROL_NAME, CRC.CAT_ID, MASKED_NAME from CRBT_RBT_CONTROL CRC, CRBT_CATEGORY_MASTER CCM where CRC.CAT_ID = CCM.CAT_ID and CONTROL_ID = ?";
			logger.info("query = "+query);

			pstmt = con.prepareStatement(query);

			pstmt.setInt(1, rbtId);

			rs = pstmt.executeQuery();

			if (rs.next())
			{
				rbt.setRbtMaskName(rs.getString("CONTROL_NAME"));
				rbt.setCatId(rs.getInt("CAT_ID"));
				rbt.setNickname(rs.getString("MASKED_NAME"));
				rbt.setRbtId(rbtId);
			}
			else
			{
				logger.info("no data found for the query");
				rs.close();
				pstmt.close();
				return 2;
			}
			rs.close();
			pstmt.close();
			return 1;
		}
		catch (Exception exp)
		{
			exp.printStackTrace();
			return 0;
		}
	}

	public int getFriendAdvancedTone(String msisdn, SubscriberFriend sfFriend)
	{
		logger.info("inside getFriendAdvanceTone() msisdn= "+msisdn);
		try
		{
			String query = "select CONTROL_RBT_CODE from CRBT_FRIEND_DETAIL where MSISDN = ? and FRIEND_MSISDN = ?";
			logger.info("query = "+query);
			PreparedStatement pstmt = con.prepareStatement(query);

			pstmt.setString(1, msisdn);
			pstmt.setString(2, sfFriend.getFriendsMsisdn());

			ResultSet rs = pstmt.executeQuery();

			int rbtId = 0;
			if (rs.next())
			{
				rbtId = rs.getInt("CONTROL_RBT_CODE");
				logger.info("control_rbt_code = "+rbtId);
			}
			else
			{
				logger.info("control_rbt_code not found for the query");
			}
			rs.close();
				
			query = "select CONTROL_NAME, CRC.CAT_ID, MASKED_NAME from CRBT_RBT_CONTROL CRC, CRBT_CATEGORY_MASTER CCM where CRC.CAT_ID = CCM.CAT_ID and CONTROL_ID = ?";
			logger.info("query = "+query);
			pstmt = con.prepareStatement(query);

			pstmt.setInt(1, rbtId);

			rs = pstmt.executeQuery();

			if (rs.next())
			{
				ToneSetting ts = new ToneSetting();
				ts.setRbtMaskName(rs.getString("CONTROL_NAME"));
				ts.setCatMaskName(rs.getString("MASKED_NAME"));
				logger.info("masked_name= "+rs.getString("MASKED_NAME"));
				ts.setRbtCode(rbtId);
				ArrayList tsAl = new ArrayList();
				tsAl.add(ts);
				sfFriend.setAdvToneSetting(tsAl);
			}
			else
			{
				logger.info("no data found for the query");
				rs.close();
				pstmt.close();
				return 2;
			}
			rs.close();
			pstmt.close();
			return 1;
		}
		catch (Exception exp)
		{
			exp.printStackTrace();
			return 0;
		}
	}

	public int getGroupAdvancedTone(SubscriberGroup sgroup)
	{
		logger.info("inside getGroupAdvanceTone()");
		try
		{
			String query = "select CONTROL_RBT_CODE from CRBT_GROUP_DETAIL where GROUPID = ?";
			logger.info("query = "+query);
			PreparedStatement pstmt = con.prepareStatement(query);

			pstmt.setLong(1, sgroup.getGroupId());

			ResultSet rs = pstmt.executeQuery();

			int rbtId = 0;
			if (rs.next())
			{
				rbtId = rs.getInt("CONTROL_RBT_CODE");
			}
			rs.close();
				
			query = "select CONTROL_NAME, CRC.CAT_ID, MASKED_NAME from CRBT_RBT_CONTROL CRC, CRBT_CATEGORY_MASTER CCM where CRC.CAT_ID = CCM.CAT_ID and CONTROL_ID = ?";
			logger.info("query = "+query);
			pstmt = con.prepareStatement(query);

			pstmt.setInt(1, rbtId);

			rs = pstmt.executeQuery();

			if (rs.next())
			{
				ToneSetting ts = new ToneSetting();
				ts.setRbtMaskName(rs.getString("CONTROL_NAME"));
				ts.setCatMaskName(rs.getString("MASKED_NAME"));
				ts.setRbtCode(rbtId);
				ArrayList tsAl = new ArrayList();
				tsAl.add(ts);
				sgroup.setAdvToneSetting(tsAl);
			}
			else
			{
				logger.info("no data found for the query");
				rs.close();
				pstmt.close();
				return 2;
			}
			rs.close();
			pstmt.close();
			return 1;
		}
		catch (Exception exp)
		{
			exp.printStackTrace();
			return 0;
		}
	}

	public int removeGroupAdvancedTone(long groupId)
	{
		logger.info("inside removeGroupAdvanceTone() groupId= "+groupId);
		try
		{
			int rbtId = 0;
			PreparedStatement pstmt = null;
	
			String query = "update CRBT_GROUP_DETAIL set CONTROL_RBT_CODE = ? where GROUPID = ?";
			logger.info("query = "+query);
			pstmt = con.prepareStatement(query);

			pstmt.setInt(1, rbtId);
			pstmt.setLong(2, groupId);

			pstmt.executeUpdate();

			pstmt.close();
			return 1;
		}

		catch (Exception exp)
		{
			exp.printStackTrace();
			return 0;
		}
	}

	public int removeFriendAdvancedTone(String msisdn, String friendsMsisdn)
	{
		logger.info("inside removeFriendAdvanceTone() msisdn= "+msisdn+" friendsMsisdn= "+friendsMsisdn);
		try
		{
			int rbtId = 0;
			PreparedStatement pstmt = null;
	
			String query = "update CRBT_FRIEND_DETAIL set CONTROL_RBT_CODE = ? where MSISDN = ? and FRIEND_MSISDN = ?";
			logger.info("query = "+query);
			pstmt = con.prepareStatement(query);

			pstmt.setInt(1, rbtId);
			pstmt.setString(2, msisdn.trim());
			pstmt.setString(3, friendsMsisdn.trim());

			pstmt.executeUpdate();

			pstmt.close();
			return 1;
		}

		catch (Exception exp)
		{
			exp.printStackTrace();
			return 0;
		}
	}

	public int removeAdvancedTone(String msisdn)
	{
		logger.info("removeAdvancedTone() msisdn= "+msisdn);
		try
		{
			int rbtId = 0;
	
			String query = "select RBT_CODE from CRBT_DEFAULT_DETAIL where MSISDN = ? and DAY = 8 and START_AT = 2500 and ENDS_AT = 2500";
			logger.info("query = "+query);
			PreparedStatement pstmt = con.prepareStatement(query);

			pstmt.setString(1, msisdn);

			ResultSet rs = pstmt.executeQuery();

			if (rs.next())
			{
				rbtId = rs.getInt("RBT_CODE");
				logger.info("rbt_code = "+rbtId);
			}
			rs.close();
				
			query = "update CRBT_SUBSCRIBER_MASTER set RBT_CODE = ? where MSISDN = ?";
			logger.info("query = "+query);
			pstmt = con.prepareStatement(query);

			pstmt.setInt(1, rbtId);
			pstmt.setString(2, msisdn.trim());

			pstmt.executeUpdate();

			pstmt.close();
			return 1;
		}
		catch (Exception exp)
		{
			exp.printStackTrace();
			return 0;
		}
	}

	public int giftToneToFriend(String msisdn, String friendMsisdn, int rbtCode)
	{
		logger.info("inside giftToneToFriend() msisdn"+msisdn+" friendMsisdn= "+friendMsisdn+" cbtCode= "+rbtCode);
		PreparedStatement pstmt = null; 
		ResultSet rs = null;
		String query;
		
		try
		{
			query = "select WALLET_ID from CRBT_WALLET_MASTER where MSISDN = ? and IVR_NAME = ?";
			logger.info("query = "+query);
			pstmt = con.prepareStatement(query);

			pstmt.setString(1, friendMsisdn);
			pstmt.setInt(2, 0);

			rs = pstmt.executeQuery();

			long walletId = 0;

			if (rs.next())
			{
				walletId = rs.getLong("WALLET_ID");
				logger.info("walletId = "+walletId);
			}
			else
			{
				logger.info("walletId not found for the query");
				pstmt.close();
				return 3;
			}

			//query = "insert into CRBT_WALLET_CONTENT (WALLET_ID, RBT_CODE, CREATE_DATE) values (?,?,sysdate)";
			query = "insert into CRBT_WALLET_CONTENT (WALLET_ID, RBT_CODE, CREATE_DATE,MSISDN) values (?,?,sysdate,?)";
			logger.info("query = "+query);
			pstmt = con.prepareStatement(query);

			pstmt.setLong(1, walletId);
			pstmt.setInt(2, rbtCode);
			pstmt.setString(3, msisdn.trim());

			pstmt.executeUpdate();

			String messageText = "You have been gifted a RBT ("+rbtCode+") from your friend "+msisdn;

			//query = "insert into GMAT_MESSAGE_STORE (RESPONSE_ID, REQUEST_ID, ORIGINATING_NUMBER, DESTINATION_NUMBER, MESSAGE_TEXT, SUBMIT_TIME, STATUS) values (GMAT_RESPONSE_ID_SEQ.NEXTVAL, 0, '6666', ?, ?, sysdate ,'R')";
			query = "insert into GMAT_MESSAGE_STORE (RESPONSE_ID, REQUEST_ID, ORIGINATING_NUMBER, DESTINATION_NUMBER, MESSAGE_TEXT, SUBMIT_TIME, STATUS) values (GMAT_RESPONSE_ID_SEQ.NEXTVAL, 0, '4444288', ?, ?, sysdate ,'R')";
			logger.info("query = "+query);
			pstmt = con.prepareStatement(query);

			pstmt.setString(1, friendMsisdn.trim());
			pstmt.setString(2, messageText.trim());
			logger.info("messageText= "+messageText);

			pstmt.executeUpdate();
	
			pstmt.close();
		}
		catch (SQLException sqle)
		{
			if (sqle.getErrorCode() == 1)
			{
				return 2;
			}
			sqle.printStackTrace();
			return 0;
		}
		catch (Exception exp)
		{
			exp.printStackTrace();
			return 0;
		}
		return 1;
	}

	private int updateDefaultString(String msisdn)
	{
		logger.info("inside updateDefaultString() msisdn = "+msisdn);
		ArrayList list = new ArrayList();
		int ret = getSubscriberDefaultSettings(msisdn, list);
		BitSet bitSet = new BitSet(256);

		byte str[] = updateSettingString(list, bitSet);
		try
		{
			String query = "update CRBT_SUBSCRIBER_MASTER set DEFAULT_SINGLE_SETTING = ? where MSISDN = ?";
			logger.info("query = "+query);
			PreparedStatement pstmt = con.prepareStatement(query);
			pstmt.setBytes(1, str);
			pstmt.setString(2, msisdn.trim());
			pstmt.executeUpdate();

			pstmt.close();
			return 1;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return 0;
		}
	}

	private int updateGroupString(long groupId)
	{
		logger.info("inside updateGroupString() groupId= "+groupId);
		ArrayList list = new ArrayList();
		int ret = getSubscriberGroupSettings(groupId, list);
		BitSet bitSet = new BitSet(256);
		bitSet.set(255-16-200);

		byte str[] = updateSettingString(list, bitSet);
		try
		{
			String query = "update CRBT_GROUP_DETAIL set GROUP_SETTING_STRING = ? where GROUPID = ?";
			logger.info("query = "+query);
			PreparedStatement pstmt = con.prepareStatement(query);
			pstmt.setBytes(1, str);
			pstmt.setLong(2, groupId);
			pstmt.executeUpdate();

			pstmt.close();
			return 1;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return 0;
		}
	}

	private int updateFriendString(String msisdn, String friendMsisdn)
	{
		logger.info("inside updateFriendString() msisdn= "+msisdn+" friendMsisdn= "+friendMsisdn);
		ArrayList list = new ArrayList();
		int ret = getSubscriberFriendSettings(msisdn, friendMsisdn, list);
		BitSet bitSet = new BitSet(256);

		byte str[] = updateSettingString(list, bitSet);
		try
		{
			String query = "update CRBT_FRIEND_DETAIL set FRIEND_SETTING_STRING = ? where MSISDN = ? and FRIEND_MSISDN = ?";
			logger.info("query = "+query);
			PreparedStatement pstmt = con.prepareStatement(query);
			pstmt.setBytes(1, str);
			pstmt.setString(2, msisdn.trim());
			pstmt.setString(3, friendMsisdn.trim());
			pstmt.executeUpdate();

			pstmt.close();
			return 1;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return 0;
		}
	}

	private byte[] updateSettingString(ArrayList setList, BitSet bitSet)
	{
		logger.info("inside updateSettingString()");
		for (int i=0; i<setList.size(); i++)
		{
			ToneSetting ts = (ToneSetting) setList.get(i);
			if ((ts.getDay() == 8) && (ts.getStartTime() == 2500) && (ts.getEndTime() == 2500))
			{
				bitSet.set(255-16-0);
			}
			else if ((ts.getStartTime() == 2500) && (ts.getEndTime() == 2500))
			{
				bitSet.set(255-16-ts.getDay());
			}
			else if (ts.getDay() == 8)
			{
				for (int j=ts.getStartTime()/100; j<ts.getEndTime()/100; j++)
				{
					bitSet.set(255-16-(8+j));
				} 
			}
			else
			{
				for (int j=ts.getStartTime()/100; j<ts.getEndTime()/100; j++)
				{
					bitSet.set(255-16-(32+ ((ts.getDay()-1)*24) +j));
				}	
			}
		}
		return toByteArray(bitSet);
	}
	
	public static BitSet fromByteArray(byte[] bytes) 
	{
		BitSet bits = new BitSet();
		for (int i=0; i<bytes.length*8; i++) 
		{
			if ((bytes[bytes.length-i/8-1]&(1<<(i%8))) > 0) 
			{
				bits.set(i);
			}
		}
		return bits;
	}

	public static byte[] toByteArray(BitSet bits) 
	{
		byte[] bytes = new byte[30];
		for (int i=0; i<bits.length(); i++) 
		{
			if (bits.get(i)) 
			{
				bytes[bytes.length-i/8-1] |= 1<<(i%8);
			}
		}
		return bytes;
	}
}
