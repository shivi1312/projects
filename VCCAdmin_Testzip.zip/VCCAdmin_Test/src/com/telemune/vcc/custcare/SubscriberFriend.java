/*
 * This class is used for user authentication for the web interface for CRBT. 
 *
 *
 *
 */


package com.telemune.vcc.custcare;
import com.telemune.vcc.common.*;

import java.util.ArrayList;

public class SubscriberFriend
{
	private String msisdn=null;
	private String friendsNick=null;
	private String friendsMsisdn = null;
	private ArrayList toneSettings = null; //RBT settings for this group
	private ArrayList advToneSetting = null; //RBT settings for this group

	public void setMsisdn(String msisdn )
	{
		this.msisdn = msisdn;
	}

	public String getMsisdn()
	{
		return TSSJavaUtil.instance().getInternationalNumber(msisdn);
	}


	public void setFriendsNick(String friendsNick )
	{
		this.friendsNick = friendsNick;
	}

	public String getFriendsNick()
	{
		return friendsNick;
	}
	public void setFriendsMsisdn(String friendsMsisdn )
	{
		this.friendsMsisdn = friendsMsisdn;
	}

	public String getFriendsMsisdn()
	{
		return friendsMsisdn;
	}

	public ArrayList getToneSettings()
	{
		return toneSettings;
	}

	public ArrayList getAdvToneSetting()
	{
		return advToneSetting;
	}

	public void setToneSettings(ArrayList toneSettings)
	{
		this.toneSettings = toneSettings;
	}

	public void setAdvToneSetting(ArrayList advToneSetting)
	{
		this.advToneSetting = advToneSetting;
	}

	public void setToneSettings(ToneSetting [] toneSettings)
	{
		this.toneSettings = new ArrayList();
		
		for(int i=0; i < toneSettings.length; i++)
		{
			this.toneSettings.add(toneSettings[i]);	
		}

	}

}

