/*
 * This class is used for user authentication for the web interface for CRBT. 
 *
 *
 *
 */


package com.telemune.vcc.custcare;
import com.telemune.vcc.common.*;

import java.util.ArrayList;

public class SubscriberGroup
{
	private String msisdn=null;
	private long groupId = -1;
	private String groupName = null;
	private ArrayList toneSettings = null; //RBT settings for this group
	private ArrayList advToneSetting = null; //RBT settings for this group
	private ArrayList friends = null;//msisdns in this group

	public void setMsisdn(String msisdn )
	{
		this.msisdn = msisdn;
	}

	public void setGroupId(long id)
	{
		this.groupId = id;
	}

	public void setGroupName(String name)
	{
		this.groupName = name;
	}

	public long getGroupId()
	{
		return groupId;
	}

	public String getGroupName()
	{
		return groupName;
	}
	
	public String getMsisdn() 
	{
		return TSSJavaUtil.instance().getInternationalNumber(msisdn);
	}

	public ArrayList getToneSettings()
	{
		return toneSettings;
	}

	public ArrayList getAdvToneSetting()
	{
		return advToneSetting;
	}

	public ArrayList getFriends()
	{
		return friends;
	}

	public void setToneSettings(ArrayList toneSettings)
	{
		this.toneSettings = toneSettings;
	}

	public void setAdvToneSetting(ArrayList advToneSetting)
	{
		this.advToneSetting = advToneSetting;
	}

	public void setFriends(String []friends)
	{
		this.friends = new ArrayList();
		
		for(int i=0; i < friends.length; i++)
		{
			this.friends.add(friends[i]);	
		}
	}

	public void setToneSettings(ToneSetting [] toneSettings)
	{
		this.toneSettings = new ArrayList();
		
		for(int i=0; i < toneSettings.length; i++)
		{
			this.toneSettings.add(toneSettings[i]);	
		}

	}


	public void setFriends(ArrayList friends)
	{
		this.friends = friends;
	}

	

}

