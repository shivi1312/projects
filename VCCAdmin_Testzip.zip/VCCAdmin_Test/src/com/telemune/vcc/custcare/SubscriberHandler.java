package com.telemune.vcc.custcare;

import com.google.gson.Gson;
import com.telemune.dbutilities.Connection;
import com.telemune.dbutilities.PreparedStatement;
import com.telemune.vcc.common.TSSJavaUtil;
import com.telemune.vcc.custcare.SubscriberHandler;
import com.telemune.vcc.custcare.action.ProvisioningBean;
import com.telemune.vcc.request.VccRuleEngineRequest;
import com.telemune.vcc.response.VccRuleEngineResponse;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import org.apache.log4j.Logger;

public class SubscriberHandler {
  private Logger logger = Logger.getLogger(SubscriberHandler.class);
  
  Connection con;
  
  private Gson gson = null;
  
  public String getActiveTrigger(String serviceType, ArrayList<ProvisioningBean> actTrgList) {
    this.logger.info("inside getActiveTrigger()");
    ProvisioningBean bean = null;
    if (serviceType.equalsIgnoreCase("Voice Mail")) {
      String actTrgs = TSSJavaUtil.instance().getKeyValue(
          "VM_ACTIVE_TRIGGER");
      String[] actTrgArray = actTrgs.split(",");
      for (int i = 0; i <= actTrgArray.length - 1; i++) {
        bean = new ProvisioningBean();
        bean.setActTrgName(TSSJavaUtil.instance().getKeyValue(
              "ACTIVE_TRIGGER_" + (i + 1)));
        actTrgList.add(bean);
      } 
    } else if (serviceType.equalsIgnoreCase("Voice Note")) {
      String actTrgs = TSSJavaUtil.instance().getKeyValue(
          "VN_ACTIVE_TRIGGER");
      String[] actTrgArray = actTrgs.split(",");
      for (int i = 0; i <= actTrgArray.length - 1; i++) {
        bean = new ProvisioningBean();
        bean.setActTrgName(TSSJavaUtil.instance().getKeyValue(
              "ACTIVE_TRIGGER_" + (i + 1)));
        actTrgList.add(bean);
      } 
    } else {
      serviceType.equalsIgnoreCase("MCA");
    } 
    return "SUCCESS";
  }
  
  public HashMap<String, String> getServices() {
    this.logger.info("inside getServices()");
    HashMap<String, String> serviceMap = null;
    try {
      //TSSJavaUtil;
      this.logger.info("Loading service from cache [" + TSSJavaUtil.instance().getServiceMap().size() + "]");
     // TSSJavaUtil.instance();
      serviceMap = TSSJavaUtil.instance().getServiceMap();
      if (serviceMap == null) {
        this.logger.error("Critical Error, no services are available");
        return serviceMap;
      } 
    } catch (Exception e) {
      this.logger.info("Exception in getting Service " + e);
      return serviceMap;
    } 
    return serviceMap;
  }
  
  public String getRatePlan(String serviceType, ArrayList<ProvisioningBean> planList) {
    this.logger.info("inside getRateplan()");
    String service_type = null;
    String query = null;
    if (serviceType.equalsIgnoreCase("Voice Mail")) {
      service_type = TSSJavaUtil.instance().getKeyValue("VM");
      query = "select distinct(PLAN_NAME),scope from VCC_RATE_PLAN where SERVICE_TYPE=?";
    } else if (serviceType.equalsIgnoreCase("Voice Note")) {
      service_type = TSSJavaUtil.instance().getKeyValue("VN");
      query = "select distinct(PLAN_NAME) from VCC_RATE_PLAN where SERVICE_TYPE=?";
    } else if (serviceType.equalsIgnoreCase("MCA")) {
      service_type = TSSJavaUtil.instance().getKeyValue("MCA");
      query = "select distinct(PLAN_NAME) from VCC_RATE_PLAN where SERVICE_TYPE=?";
    } 
    Connection con = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;
    try {
      con = TSSJavaUtil.instance().getconnection();
      pstmt = con.prepareStatement(query);
      pstmt.setString(1, service_type);
      rs = pstmt.executeQuery();
      this.logger.info("QUERY: " + query);
      ProvisioningBean bean = null;
      while (rs != null && rs.next()) {
        bean = new ProvisioningBean();
        bean.setPlanId(rs.getString("PLAN_NAME"));
        bean.setPlanName(rs.getString("PLAN_NAME"));
        if (serviceType.equalsIgnoreCase("Voice Mail"))
          bean.setScope(rs.getString("SCOPE")); 
        planList.add(bean);
      } 
      pstmt.close();
      rs.close();
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      try {
        if (rs != null) {
          rs.close();
          rs = null;
        } 
        if (pstmt != null) {
          pstmt.close();
          pstmt = null;
        } 
        if (con != null) {
          TSSJavaUtil.instance().freeConnection(con);
          con = null;
        } 
      } catch (Exception e) {
        e.printStackTrace();
      } 
    } 
    return "SUCCESS";
  }
  
  public String getSubJsonObject(ProvisioningBean provisioningBean) {
    this.gson = new Gson();
    VccRuleEngineRequest vccSubscribeRequest = new VccRuleEngineRequest();
    vccSubscribeRequest.setMsisdn(provisioningBean.getMsisdn());
    vccSubscribeRequest.setPlanName(provisioningBean.getPlanName());
    if (provisioningBean.getServiceType().equalsIgnoreCase("VM")) {
      vccSubscribeRequest.setServiceType(TSSJavaUtil.instance()
          .getKeyValue("VM"));
      vccSubscribeRequest.setActionId(TSSJavaUtil.instance().getKeyValue(
            "vm_sub_actionId"));
    } else if (provisioningBean.getServiceType().equalsIgnoreCase("VN")) {
      vccSubscribeRequest.setServiceType(TSSJavaUtil.instance()
          .getKeyValue("VN"));
      vccSubscribeRequest.setActionId(TSSJavaUtil.instance().getKeyValue(
            "vn_sub_actionId"));
    } else if (provisioningBean.getServiceType().equalsIgnoreCase("MCA")) {
      vccSubscribeRequest.setServiceType(TSSJavaUtil.instance()
          .getKeyValue("MCA"));
      vccSubscribeRequest.setActionId(TSSJavaUtil.instance().getKeyValue(
            "mca_sub_actionId"));
    } 
    if (provisioningBean.getActiveTrigger().equalsIgnoreCase("0")) {
      vccSubscribeRequest.setActTrg(0);
    } else if (provisioningBean.getActiveTrigger().equalsIgnoreCase(
        "User Busy")) {
      vccSubscribeRequest.setActTrg(Integer.parseInt(
            TSSJavaUtil.instance().getKeyValue("user_busy_id")));
    } else if (provisioningBean.getActiveTrigger().equalsIgnoreCase(
        "No Answer")) {
      vccSubscribeRequest.setActTrg(Integer.parseInt(
            TSSJavaUtil.instance().getKeyValue("no_answer_id")));
    } else if (provisioningBean.getActiveTrigger().equalsIgnoreCase(
        "Unreachable")) {
      vccSubscribeRequest.setActTrg(Integer.parseInt(
            TSSJavaUtil.instance().getKeyValue("unreachable_id")));
    } else if (provisioningBean.getActiveTrigger().equalsIgnoreCase("All")) {
      vccSubscribeRequest.setActTrg(Integer.parseInt(
            TSSJavaUtil.instance().getKeyValue("all_id")));
    } 
    vccSubscribeRequest.setNotification(provisioningBean.getNotification());
    if (provisioningBean.getSubType().equalsIgnoreCase("F") || (
      provisioningBean.getUserType() != null && provisioningBean
      .getUserType().equalsIgnoreCase("F"))) {
      vccSubscribeRequest.setCbcmEnable(Boolean.valueOf(false));
      vccSubscribeRequest.setNotification(Boolean.valueOf(false));
    } else {
      vccSubscribeRequest.setCbcmEnable(provisioningBean.getCbcmEnable());
      vccSubscribeRequest.setNotification(provisioningBean
          .getNotification());
    } 
    if (provisioningBean.getSubType().equals("-1")) {
      vccSubscribeRequest.setSubType(provisioningBean.getUserType());
    } else {
      vccSubscribeRequest.setSubType(provisioningBean.getSubType());
    } 
    vccSubscribeRequest.setTid(String.valueOf(System.nanoTime()));
    vccSubscribeRequest.setChannel(TSSJavaUtil.instance().getKeyValue(
          "channel"));
    vccSubscribeRequest.setInterFace(TSSJavaUtil.instance().getKeyValue(
          "interface"));
    vccSubscribeRequest.setAppId(TSSJavaUtil.instance().getKeyValue(
          "app_id"));
    vccSubscribeRequest.setReqBy(provisioningBean.getMsisdn());
    vccSubscribeRequest
      .setLang(Integer.parseInt(provisioningBean.getLang()));
    vccSubscribeRequest.setUpdatedBy(provisioningBean.getRoleId());
    String jsonObj = this.gson.toJson(vccSubscribeRequest);
    return jsonObj;
  }
  
  public String getUnSubJsonObject(ProvisioningBean provisioningBean) {
    this.gson = new Gson();
    VccRuleEngineRequest vccSubscribeRequest = new VccRuleEngineRequest();
    vccSubscribeRequest.setMsisdn(provisioningBean.getMsisdn());
    if (provisioningBean.getServiceType().equalsIgnoreCase("VM")) {
      vccSubscribeRequest.setServiceType(TSSJavaUtil.instance()
          .getKeyValue("VM"));
      vccSubscribeRequest.setActionId(TSSJavaUtil.instance().getKeyValue(
            "vm_unsub_actionId"));
    } else if (provisioningBean.getServiceType().equalsIgnoreCase("VN")) {
      vccSubscribeRequest.setServiceType(TSSJavaUtil.instance()
          .getKeyValue("VN"));
      vccSubscribeRequest.setActionId(TSSJavaUtil.instance().getKeyValue(
            "vn_unsub_actionId"));
    } else if (provisioningBean.getServiceType().equalsIgnoreCase("MCA")) {
      vccSubscribeRequest.setServiceType(TSSJavaUtil.instance()
          .getKeyValue("MCA"));
      vccSubscribeRequest.setActionId(TSSJavaUtil.instance().getKeyValue(
            "mca_unsub_actionId"));
    } 
    vccSubscribeRequest.setTid(String.valueOf(System.nanoTime()));
    vccSubscribeRequest.setChannel(TSSJavaUtil.instance().getKeyValue(
          "channel"));
    vccSubscribeRequest.setInterFace(TSSJavaUtil.instance().getKeyValue(
          "interface"));
    vccSubscribeRequest.setAppId(TSSJavaUtil.instance().getKeyValue(
          "app_id"));
    try {
      if (provisioningBean.getSubType().equalsIgnoreCase("F") || (
        provisioningBean.getUserType() != null && provisioningBean
        .getUserType().equalsIgnoreCase("F"))) {
        vccSubscribeRequest.setCbcmEnable(Boolean.valueOf(false));
        vccSubscribeRequest.setNotification(Boolean.valueOf(false));
      } else {
        vccSubscribeRequest.setNotification(provisioningBean
            .getNotification());
        vccSubscribeRequest.setCbcmEnable(provisioningBean
            .getCbcmEnable());
      } 
    } catch (Exception exception) {}
    vccSubscribeRequest.setSubType(provisioningBean.getSubType());
    vccSubscribeRequest.setReqBy(provisioningBean.getMsisdn());
    vccSubscribeRequest
      .setLang(Integer.parseInt(provisioningBean.getLang()));
    vccSubscribeRequest.setUpdatedBy(provisioningBean.getRoleId());
    String jsonObj = this.gson.toJson(vccSubscribeRequest);
    return jsonObj;
  }
  
  public VccRuleEngineResponse requestToRuleEngine(String json) {
    Socket socket = null;
    DataOutputStream out = null;
    DataInputStream reader = null;
    String response = null;
    VccRuleEngineResponse subscribeResponse = new VccRuleEngineResponse();
    try {
      this.logger.info("Going to connect RuleEngine");
      socket = new Socket(TSSJavaUtil.instance().getKeyValue(
            "rule_engine_ip"), Integer.parseInt(TSSJavaUtil.instance()
            .getKeyValue("rule_engine_port")));
      socket.setSoTimeout(Integer.parseInt(TSSJavaUtil.instance()
            .getKeyValue("rule_engine_socket_timeout")));
      this.logger.info("Server has connected!\n");
      this.logger.info("Sending string: '" + json + "'\n");
      out = new DataOutputStream(socket.getOutputStream());
      out.writeUTF(json);
      out.flush();
      reader = new DataInputStream(socket.getInputStream());
      response = reader.readUTF();
      if (response != null) {
        subscribeResponse = (VccRuleEngineResponse)this.gson.fromJson(response, 
            VccRuleEngineResponse.class);
        this.logger.info("request: " + json + " response: " + response);
      } else {
        this.logger.info("request: " + json + " response: " + response);
      } 
    } catch (SocketTimeoutException ex) {
      this.logger.error(
          String.format("[%s] Socket Time out Exception : ", new Object[] { json }), ex);
      try {
        if (out != null)
          out.close(); 
        if (reader != null)
          reader.close(); 
        if (socket != null)
          socket.close(); 
      } catch (Exception e) {
        this.logger.info("Exception While closing connection");
      } 
    } catch (Exception e) {
      this.logger.error(String.format("[%s] Error: ", new Object[] { json }), e);
    } finally {
      try {
        if (out != null)
          out.close(); 
        if (reader != null)
          reader.close(); 
        if (socket != null)
          socket.close(); 
      } catch (Exception exception) {}
    } 
    this.logger.info("Response Json Is" + 
        this.gson.toJson(subscribeResponse).toString());
    return subscribeResponse;
  }
  
  public String getSubTypeJsonObject(String msisdn, String serviceType) {
    this.logger.info("Getting Json Data for subType Request" + msisdn);
    this.gson = new Gson();
    VccRuleEngineRequest vccSubscribeRequest = new VccRuleEngineRequest();
    vccSubscribeRequest.setMsisdn(msisdn);
    vccSubscribeRequest.setActionId(TSSJavaUtil.instance().getKeyValue(
          "subType_actionId"));
    vccSubscribeRequest.setTid(String.valueOf(System.nanoTime()));
    vccSubscribeRequest.setLang(Integer.parseInt(TSSJavaUtil.instance()
          .getKeyValue("default_language")));
    if (serviceType.equalsIgnoreCase("Voice Mail")) {
      vccSubscribeRequest.setServiceType(TSSJavaUtil.instance()
          .getKeyValue("VM"));
    } else if (serviceType.equalsIgnoreCase("Voice Note")) {
      vccSubscribeRequest.setServiceType(TSSJavaUtil.instance()
          .getKeyValue("VN"));
    } 
    vccSubscribeRequest.setInterFace(TSSJavaUtil.instance().getKeyValue(
          "interface"));
    vccSubscribeRequest.setReqBy(msisdn);
    String jsonObj = this.gson.toJson(vccSubscribeRequest);
    this.logger.info("json Object is" + jsonObj);
    return jsonObj;
  }
  
  public String getProfileChange(String msisdn, String subType, String planName) {
    this.logger.info("Getting Json Data for Profile Change Request" + msisdn);
    this.gson = new Gson();
    VccRuleEngineRequest vccSubscribeRequest = new VccRuleEngineRequest();
    vccSubscribeRequest.setMsisdn(msisdn);
    vccSubscribeRequest.setActionId(TSSJavaUtil.instance().getKeyValue(
          "profileChange_actionId"));
    vccSubscribeRequest.setTid(String.valueOf(System.nanoTime()));
    vccSubscribeRequest.setLang(Integer.parseInt(TSSJavaUtil.instance()
          .getKeyValue("default_language")));
    vccSubscribeRequest.setServiceType(TSSJavaUtil.instance()
        .getKeyValue("VM"));
    vccSubscribeRequest.setSubType(subType);
    vccSubscribeRequest.setInterFace(TSSJavaUtil.instance().getKeyValue(
          "interface"));
    vccSubscribeRequest.setReqBy(msisdn);
    vccSubscribeRequest.setPlanName(planName);
    String jsonObj = this.gson.toJson(vccSubscribeRequest);
    this.logger.info("json Object is" + jsonObj);
    return jsonObj;
  }
}
