package com.telemune.vcc.custcare;

public class SubscriberHistory
{
    private String date;
    private String activity;
   private String sub_type;
   private String was_charged;
    private String rbtCode;
    private String change_type;
    private String interface_type;
    private String request_message;
    private String response_message;
    private String response_time;
    private String update_type;	
    private String validityDays;
    private int request_count;
    private int call_duration;		
    public void SubscriberHistory()
    {
	    date="";
	    activity="";
	    sub_type="";
	    was_charged="";

    }
    public void setValidityDays(String validityDays)
	  {
	this.validityDays=validityDays;
	 }
	public String getValidityDays()
	{
	return this.validityDays;
	}

    
    public void setDate(String date) 
    {
        this.date=date;
    }
    public void setResponseTime(String response_time) 
    {
        this.response_time=response_time;
    }

    public void setActivity(String activity)
    {
        this.activity = activity;
    }

   public void setSub_type(String sub_type)
	{
			this.sub_type=sub_type;
	}
   public void setWas_charged(String was_charged)
        {
		this.was_charged=was_charged;
	}
   public void setRbtCode(String rbtCode)
   {
	this.rbtCode=rbtCode;
   }
   public void setChange_Type(String change_type)
   {
	this.change_type=change_type;
   } 
   public void setInterface_Type(String interface_type)
   {
	this.interface_type=interface_type;
   } 
   public void setUpdate_Type(String update_type)
   {
	this.update_type=update_type;
   } 
   public void setRequestCount(int request_count)
   {
	this.request_count=request_count;
   } 
   public void setCallduration(int call_duration)
   {
	this.call_duration=call_duration;
   } 
   public void setRequestMessage(String request_message)
   {
	this.request_message=request_message;
   } 
   public void setResponseMessage(String response_message)
   {
	this.response_message=response_message;
   } 
    public String getDate()
    {
        return date;
    }
    public String getResponseTime()
    {
        return response_time;
    }

    public String getRequestMessage()
    {
        return request_message;
    }
    public String getResponseMessage()
    {
        return response_message;
    }
    public String getActivity()
    {
        return activity;
    }
    public String getChange_Type()
    {
        return change_type;
    }
    public String getInterface_Type()
    {
        return interface_type;
    }
    public String getUpdate_Type()
    {
        return update_type;
    }
    public String getRbtCode()
    {
       return rbtCode;
    }

		public String getSub_type()
		{
				return sub_type;
		}		
    
		public String getWas_charged()
			
		{
				return was_charged;
		}
		public int getRequestCount()
			
		{
				return request_count;
		}
		public int getCallduration()
			
		{
				return call_duration;
		}









}

