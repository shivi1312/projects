/*
 *
 *
 *
 */
package com.telemune.vcc.custcare;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;

import com.telemune.dbutilities.*;
import com.telemune.vcc.common.Rbt;
import com.telemune.vcc.common.SubscriberProfile;
import com.telemune.vcc.common.TSSJavaUtil;


public class SubscriberProfileManagerBean
{
	static Logger logger=Logger.getLogger(SubscriberProfileManagerBean.class);
	//to be set by caller
	private ConnectionPool conPool = null;

	//will be used internally
	private Connection con = null;


	//to be received from caller, wont work if these fields are not set
	private SubscriberCallerManager scm =  null;
	//to be received from caller, wont work if these fields are not set
	private SubscriberProfile subscriberProfile =  null;

	//to be set in this class (on first access)
	private ArrayList groupDetails = null;
	private ArrayList friendDetails = null;

	//to be set in this class (on first access)
	private ArrayList groupSettings = null;
	private ArrayList friendSettings = null;
	private ArrayList defaultSettings = null;
	private ArrayList dateSettings = null;
	private ArrayList advanceSettings = null;
	private ArrayList groupAdvanceSettings = null;
	private ArrayList occSettings = null;

	private	ResultSet rs = null;
	private PreparedStatement pstmt=null;
	private String query="";
	private String interfaceType="W";
	public SubscriberProfileManagerBean()
	{
		scm = new SubscriberCallerManager();
	}	

	public void setConnectionPool(ConnectionPool conPool)
	{
		this.conPool = conPool;			
	}

	public void setSubscriberProfile(SubscriberProfile sp)
	{
		this.subscriberProfile = sp;	
	}

	public ArrayList getGroupSettings()
	{
		return groupSettings;
	}

	public ArrayList getFriendSettings()
	{
		return friendSettings;
	}

	public ArrayList getDefaultSettings()
	{
		return defaultSettings;
	}
	public ArrayList getOccSettings()
	{
		return occSettings;
	}


	public ArrayList getDateSettings()
	{
		return dateSettings;
	}

	public ArrayList getAdvanceSettings()
	{
		return advanceSettings;
	}

	public ArrayList getGroupAdvanceSettings()
	{
		return groupAdvanceSettings;
	}

	public int getSubscriberCallerInfo(Connection con)
	{
		try
		{

			//con = conPool.getConnection();

			SubscriberCallerManager scam = new SubscriberCallerManager(con);

			groupSettings = new ArrayList();
			friendSettings = new ArrayList();
			defaultSettings = new ArrayList();
			dateSettings = new ArrayList();				
			advanceSettings = new ArrayList();				
			groupAdvanceSettings = new ArrayList();				
			occSettings = new ArrayList();
			if (scam.getSubscriberOccSettings(subscriberProfile.getMsisdn(),occSettings) != 1 )
			{
				System.out.println("Error In Getting Occassion");
				return 0;
			}

			if (scam.getSubscriberDateSettings(subscriberProfile.getMsisdn(),dateSettings) != 1 )
			{
				System.out.println("Error In Getting Date");
				return 0;
			}
			if (scam.getSubscriberFriendSettings(subscriberProfile.getMsisdn(), friendSettings, advanceSettings) != 1) 
			{
				System.out.println("Error In Getting Friends");
				return 0;
			}
			if (scam.getSubscriberGroupSettings(subscriberProfile.getMsisdn(),groupSettings,groupAdvanceSettings) != 1)
			{
				System.out.println("Error In Getting Groups");
				return 0;
			}
			if (scam.getSubscriberDefaultSettings(subscriberProfile.getMsisdn(),defaultSettings) != 1)
			{
				System.out.println("Error In Getting Defaults");
				return 0;
			}			
			return 1;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
			
	}
	public int setSubscriberOccTone(String msisdn, String date[], int rbtCode, String occName) 
	{

		System.out.println("setSubscriberOccTone()");

		String changeType="RINGTONE_FOR_DATE";
		String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(msisdn);

		try
		{
			con = conPool.getConnection();
			con.setAutoCommit(false);

			SubscriberCallerManager scam = new  SubscriberCallerManager(con);

			int ret = scam.setOccTone(interMsisdn, date, rbtCode, occName);
			if(ret != 1)
			{
				con.rollback();
				return ret;
			}
			//////uncommented by JP
			/*		if (updateFreeEventsUsed(interMsisdn) != 1)
					{
					con.rollback();
					return 0;
					}
			 */
			if(updateCRBTScore(rbtCode) !=1)
			{
				con.rollback();
				return 0;
			}
			//    int chr = doCharging(interMsisdn, rbtCode, changeType);//JP
			//workingcodeline			int chr = doCharging(interMsisdn, rbtCode, 1);
			/*
			   int planIndicator = Integer.parseInt(TSSJavaUtil.instance().getAppConfigParam("DEFAULT_RATE_PLAN"));
			   query = "select RBT_CHARGE_CODE, GIFT_CHARGE_CODE from CRBT_RATE_PLANS where PLAN_INDICATOR = ?";
			   pstmt = con.prepareStatement(query);
			   pstmt.setInt(1, planIndicator);
			//System.out.println(query);

			rs = pstmt.executeQuery();
			int rbt_charge_code=0;
			int gift_charge_code=0;
			if(rs.next())
			{
			gift_charge_code=Integer.parseInt(rs.getString("GIFT_CHARGE_CODE"));
			rbt_charge_code=Integer.parseInt(rs.getString("RBT_CHARGE_CODE"));
			System.out.println("RBT_CHARGE_CODE= "+rbt_charge_code);
			}

			if(rs != null) rs.close();
			pstmt.close();


			TCPPacketCharging tcpCharge = new TCPPacketCharging();
			int chr = tcpCharge.doEventBasedCharging(interMsisdn, rbt_charge_code, rbtCode,"-1",3, interfaceType); //action=1 for SUB // interfacetype='W' for crbtuser
			System.out.println("setSubscriberOccTone: chr="+chr);


			if (chr != 1)
			{
			con.rollback();
			return chr;
			}
			 */
			StringBuffer opFor = new StringBuffer();
			opFor.append(date[0]);
			opFor.append("-");
			opFor.append(date[1]);
			opFor.append("-");
			opFor.append(date[2]);
			insertIntoRbtOpLog(interMsisdn, rbtCode, 1, opFor.toString(), "N", 1);
			insertIntoSubscriberAudit(interMsisdn, 1, "Occassion RBT "+occName+" is set",con);

			con.commit();
			return 1;
		}
		catch (Exception e)
		{
			try {
				con.rollback();
			} catch(Exception exp) {}
			e.printStackTrace();
			return 0;
		}
		finally
		{
			conPool.free(con);
		}
	}//setSubscriberOccTone

	
	public int addNewFriend(String msisdn, ArrayList friends, ArrayList friendsNickAl,Connection con)
	{
		try
		{
			String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(msisdn);
			
			con.setAutoCommit(false);

			FriendManager fm = new FriendManager(con);
			/* converting all Friends number to International format*/
			ArrayList interFriends = new ArrayList();
			Iterator ite = friends.iterator();
			while(ite.hasNext())
			{				
				String interFriend = TSSJavaUtil.instance().getInternationalNumber((String)ite.next());
				interFriends.add(interFriend);
				insertIntoFriendOpLog(interMsisdn, 1, interFriend,con);
			}

			int i = fm.addFriends(interMsisdn, interFriends, friendsNickAl);

			if (i != 1) 
			{
				con.rollback();
				return i;
			}

			insertIntoSubscriberAudit(interMsisdn, 1, "Friends Added",con);

			con.commit();
			return 1;				
		}
		catch (Exception e)
		{
			try {
				con.rollback();
			} catch (Exception exp) {}
			e.printStackTrace();
			return 0;
		}
		
	}

	public int modifyFriend(String msisdn, String friendMsisdn, String nick,Connection con)
	{
		try
		{
			//data not loaded, load it				
			String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(msisdn);	
			String interFriendMsisdn = TSSJavaUtil.instance().getInternationalNumber(friendMsisdn);

			//con = conPool.getConnection();

			con.setAutoCommit(false);

			FriendManager fm = new FriendManager(con);

			int ret = fm.updateFriend(interMsisdn, interFriendMsisdn, nick);
			if (ret != 1)
			{
				con.rollback();
				return ret;
			}
			insertIntoFriendOpLog(interMsisdn, 3, interFriendMsisdn,con);
			insertIntoSubscriberAudit (interMsisdn, 1, "Friend modified",con);
			con.commit();	
			return 1;
		}
		catch (Exception e)
		{
			try {
				con.rollback();
			} catch(Exception exp) {}
			e.printStackTrace();
			return 0;
		}
		
	}

	public int deleteFriends(String msisdn, String  friendMsisdns[],Connection con)
	{
		try
		{
			String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(msisdn);	
			//con = conPool.getConnection();

			con.setAutoCommit(false);

			FriendManager fm = new FriendManager(con);

			for(int i =0; i<friendMsisdns.length; i++)
			{
				String interFriendMsisdn = TSSJavaUtil.instance().getInternationalNumber(friendMsisdns[i]);	
				if(fm.deleteFriend(interMsisdn,interFriendMsisdn) != 1)
				{
					con.rollback();
					return 0;
				}

				insertIntoFriendOpLog(interMsisdn, 2, interFriendMsisdn,con);
			}

			insertIntoSubscriberAudit(interMsisdn, 1, "Friends Deleted",con);

			con.commit();
			return 1;
		}
		catch (Exception e)
		{
			try {
				con.rollback();
			} catch (Exception exp) {}
			e.printStackTrace();
			return 0;
		}
		
	}

	public ArrayList getFriendsList(Connection con)
	{
		try
		{
			//data not loaded, load it

			//con = conPool.getConnection();

			FriendManager fm = new FriendManager(con);

			friendDetails = new ArrayList();

			if (fm.getFriendDetails(subscriberProfile.getMsisdn(), friendDetails) != 1) 
			{
				System.out.println("Error In Getting Friends");
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
		return friendDetails;
	}

	public int addSubscriberGroup(String groupName, String msisdn, ArrayList friends,Connection con) 
	{
		String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(msisdn);	
		ArrayList interFriends = new ArrayList();
		Iterator ite = friends.iterator();
		while(ite.hasNext())
		{
			interFriends.add(TSSJavaUtil.instance().getInternationalNumber((String)ite.next()));
		}

		SubscriberGroup sg = new SubscriberGroup();
		sg.setGroupName(groupName);
		sg.setMsisdn(interMsisdn);
		sg.setFriends(interFriends);
		try
		{
			//con = conPool.getConnection();

			con.setAutoCommit(false);

			GroupManager gm = new GroupManager(con);

			int ret = gm.addGroup(sg);

			if (ret != 1)
			{
				con.rollback();
				return ret;
			}

			insertIntoGroupOpLog(interMsisdn, 1, sg.getGroupId(),con);
			insertIntoSubscriberAudit(interMsisdn, 1, "Group Added",con); 
			con.commit();
			return 1;	
		}
		catch (Exception e)
		{
			try {
				con.rollback();
			} catch (Exception exp) {}
			e.printStackTrace();
			return 0;
		}
		
	}

	public int modifySubscriberGroup(String groupName, long groupId, String msisdn, ArrayList friends,Connection con) 
	{
		String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(msisdn);
		/* converting all Friends number to International format*/
		ArrayList interFriends = new ArrayList();
		Iterator ite = friends.iterator();
		while(ite.hasNext())
		{
			interFriends.add(TSSJavaUtil.instance().getInternationalNumber((String)ite.next()));
		}
		SubscriberGroup sg = new SubscriberGroup();
		sg.setGroupName(groupName.toUpperCase());
		sg.setMsisdn(interMsisdn);
		sg.setFriends(interFriends);
		sg.setGroupId(groupId);

		try
		{
			//con = conPool.getConnection();
			con.setAutoCommit(false);

			GroupManager gm = new GroupManager(con);

			int ret = gm.modifyGroup(sg);
			if(ret != 1 )
			{
				con.rollback();	
				return ret;
			}

			insertIntoGroupOpLog(interMsisdn, 3, groupId,con);
			insertIntoSubscriberAudit(interMsisdn, 1, "Group Modified",con);

			con.commit();
			return 1;				
		}
		catch (Exception e)
		{
			try
			{
				con.rollback();
			} catch (Exception exp) {}
			e.printStackTrace();
			return 0;
		}
		
	}

	public int deleteGroups(String msisdn, String  groupId[],Connection con)
	{
		logger.info("Inside function deleteGroups()...........connection["+con+"] length of groupid array ["+groupId.length+"]");
		try
		{
			//con = conPool.getConnection();

			String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(msisdn);	

			GroupManager gm = new GroupManager(con);

			con.setAutoCommit(false);

			for(int i =0; i<groupId.length; i++)
			{
				long gId = Long.parseLong(groupId[i]);
				logger.info("group id is "+gId);

				if (gm.deleteGroup(interMsisdn, gId) != 1)
				{
					con.rollback();
					return 0;
				}

				insertIntoGroupOpLog (interMsisdn, 2, gId,con);
			}

			insertIntoSubscriberAudit(interMsisdn, 1, "Groups Deleted",con);

			con.commit();
			return 1;
		}
		catch (Exception e)
		{
			try
			{
				con.rollback();
			} catch (Exception exp) {}
			e.printStackTrace();
			return 0;
		}
		
	}

	// this function is for getting the group details 
	public ArrayList getGroupsList(Connection con)
	{
		try
		{
			//con = conPool.getConnection();

			GroupManager gm = new GroupManager(con);

			groupDetails = new ArrayList();

			if (gm.getGroupDetails(subscriberProfile.getMsisdn(), groupDetails) != 1) 
			{
				System.out.println("Error In Getting Groups");
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
		return groupDetails;
	}

	public int setSubscriberDefaultTone(String msisdn, ArrayList toneSettingsAl, int rbtCode) 
	{
		String changeType="DEFAULT_RINGTONE";
		String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(msisdn);

		try
		{
			con = conPool.getConnection();
			con.setAutoCommit(false);

			SubscriberCallerManager scam = new SubscriberCallerManager(con);

			int ret = scam.setDefaultTone(interMsisdn, toneSettingsAl, rbtCode);
			if (ret != 1)
			{
				con.rollback();
				return ret;
			}

			insertIntoRbtOpLog(interMsisdn, rbtCode, 1, "Default", "N", 1);
			insertIntoSubscriberAudit(interMsisdn, 1, "Default RBT is set",con);

			con.commit();
			return 1;
		}
		catch (Exception e)
		{
			try {
				con.rollback();
			} catch(Exception exp) {}
			e.printStackTrace();
			return 0;
		}
		finally
		{
			conPool.free(con);
		}
	}

	public int setSubscriberGroupTone(String msisdn, long groupId, ArrayList toneSettingsAl, int rbtCode) 
	{
		String changeType="RINGTONE_FOR_GROUP";
		String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(msisdn);

		try
		{
			con = conPool.getConnection();
			con.setAutoCommit(false);

			SubscriberCallerManager scam = new SubscriberCallerManager(con);

			int ret = scam.setGroupTone(groupId, msisdn, toneSettingsAl, rbtCode);
			if (ret != 1)
			{
				con.rollback();
				return ret;
			}

			insertIntoRbtOpLog(interMsisdn, rbtCode, 1, "Group:"+groupId, "N", 1);
			insertIntoSubscriberAudit(interMsisdn, 1, "Group RBT is set",con);

			con.commit();
		}
		catch (Exception e)
		{
			try {
				con.rollback();
			} catch(Exception exp) {}
			e.printStackTrace();
			return 0;
		}
		finally
		{
			conPool.free(con);
		}
		return 1;
	}

	public int setSubscriberFriendTone(String msisdn, String friendMsisdn, ArrayList toneSettingsAl, int rbtCode) 
	{
		String changeType = "RINGTONE_FOR "+friendMsisdn;
		String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(msisdn);
		String interFriendMsisdn = TSSJavaUtil.instance().getInternationalNumber(friendMsisdn);

		ArrayList frndsList = new ArrayList();
		ArrayList nickList = new ArrayList();

		nickList.add(new String(""));
		frndsList.add(interFriendMsisdn);
		//this.addNewFriend(interMsisdn, frndsList, nickList);// upadte by ekansh
		this.addNewFriend(interMsisdn, frndsList, nickList,con);
		try
		{
			//data not loaded, load it

			con = conPool.getConnection();
			con.setAutoCommit(false);

			SubscriberCallerManager scam = new SubscriberCallerManager(con);

			int ret = scam.setFriendTone(interFriendMsisdn, interMsisdn, toneSettingsAl, rbtCode);
			if (ret != 1)
			{
				con.rollback();
				return ret;
			}
			/*
			   query="select param_value from CRBT_APP_CONFIG_PARAMS where PARAM_TAG=?";
			   pstmt = con.prepareStatement(query);
			   pstmt.setString(1,"SMS_ORIGINATION_NUMBER");

			   rs = pstmt.executeQuery();
			   System.out.println(query);
			   String sms_origin_number="7464";
			   if(rs.next())
			   {
			   sms_origin_number  = rs.getString(1);
			   }
			   rs.close();

			   String Message_Text="Your friend "+interMsisdn +" has set PRBT for you";

			   query = "select template_message from lbs_templates where template_id = 308 and template_type = 10 and language_id = 1";
			   pstmt = con.prepareStatement(query);
			   rs = pstmt.executeQuery();
			   if(rs.next())
			   {
			   String message_string = rs.getString(1);
			   int tempPos = 0;
			   tempPos = message_string.indexOf("$(msisdn)");
			   if(tempPos !=-1)
			   {
			   Message_Text = message_string.substring(0,tempPos);
			   Message_Text = Message_Text + interMsisdn;
			   }
			   }
			   System.out.println(">> "+interFriendMsisdn+"  "+Message_Text);

			   query= "insert into GMAT_MESSAGE_STORE (RESPONSE_ID, REQUEST_ID, ORIGINATING_NUMBER, DESTINATION_NUMBER, MESSAGE_TEXT, SUBMIT_TIME, STATUS) values (GMAT_RESPONSE_ID_SEQ.NEXTVAL, 0, ? , ?, ?, sysdate ,'R')";
			   pstmt = con.prepareStatement(query);
			   pstmt.setString(1, sms_origin_number);
			   pstmt.setString(2,interFriendMsisdn);
			   pstmt.setString(3,Message_Text);
			   pstmt.executeUpdate();
			   pstmt.close();
			 */


			//if (updateFreeEventsUsed(interMsisdn) != 1)
			//		{
			//		con.rollback();
			//		return 0;
			//		}

			if(updateCRBTScore(rbtCode) !=1)
			{
				con.rollback();
				return 0;
			}

			//JPworkingcodeline		int chr = doCharging(interMsisdn, rbtCode, changeType);
			/*
			   int planIndicator = Integer.parseInt(TSSJavaUtil.instance().getAppConfigParam("DEFAULT_RATE_PLAN"));
			   query = "select RBT_CHARGE_CODE, GIFT_CHARGE_CODE from CRBT_RATE_PLANS where PLAN_INDICATOR = ?";
			   pstmt = con.prepareStatement(query);
			   pstmt.setInt(1, planIndicator);
			//System.out.println(query);

			rs = pstmt.executeQuery();
			int rbt_charge_code=0;
			int gift_charge_code=0;
			if(rs.next())
			{
			gift_charge_code=Integer.parseInt(rs.getString("GIFT_CHARGE_CODE"));
			rbt_charge_code=Integer.parseInt(rs.getString("RBT_CHARGE_CODE"));
			System.out.println("RBT_CHARGE_CODE= "+rbt_charge_code);
			System.out.println("GIFT_CHARGE_CODE= "+gift_charge_code);
			}

			if(rs != null) rs.close();
			pstmt.close();


			TCPPacketCharging tcpCharge = new TCPPacketCharging();
			int chr = tcpCharge.doEventBasedCharging(interMsisdn, rbt_charge_code, rbtCode,"-1",3, interfaceType); //action=3 for RBT purchase, interfacetype='W' for crbtuser
			System.out.println("setSubscriberFriendTone: chr="+chr);

			if (chr != 1)
			{
			con.rollback();
			return chr;
			}
			 */

			insertIntoRbtOpLog(interMsisdn, rbtCode, 1, interFriendMsisdn, "N", 1);
			insertIntoSubscriberAudit(interMsisdn, 1, "Friend RBT is set",con);

			con.commit();
			return 1;
		}
		catch (Exception e)
		{
			try {
				con.rollback();
			} catch(Exception exp) { }
			e.printStackTrace();
			return 0;
		}
		finally
		{
			conPool.free(con);
		}
	}

	public int setSubscriberDateTone(String msisdn, String date[], int rbtCode) 
	{

		String changeType="RINGTONE_FOR_DATE";
		String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(msisdn);

		try
		{
			con = conPool.getConnection();
			con.setAutoCommit(false);

			SubscriberCallerManager scam = new  SubscriberCallerManager(con);

			int ret = scam.setDateTone(interMsisdn, date, rbtCode);
			if(ret != 1)
			{
				con.rollback();
				return ret;
			}

			/*			if (updateFreeEventsUsed(interMsisdn) != 1)
						{
						con.rollback();
						return 0;
						}
			 */
			if(updateCRBTScore(rbtCode) !=1)
			{
				con.rollback();
				return 0;
			}
			//int chr = doCharging(interMsisdn, rbtCode, changeType);
			/*
			   int planIndicator = Integer.parseInt(TSSJavaUtil.instance().getAppConfigParam("DEFAULT_RATE_PLAN"));
			   query = "select RBT_CHARGE_CODE, GIFT_CHARGE_CODE from CRBT_RATE_PLANS where PLAN_INDICATOR = ?";
			   pstmt = con.prepareStatement(query);
			   pstmt.setInt(1, planIndicator);
			//System.out.println(query);

			rs = pstmt.executeQuery();
			int rbt_charge_code=0;
			int gift_charge_code=0;
			if(rs.next())
			{
			gift_charge_code=Integer.parseInt(rs.getString("GIFT_CHARGE_CODE"));
			rbt_charge_code=Integer.parseInt(rs.getString("RBT_CHARGE_CODE"));
			System.out.println("RBT_CHARGE_CODE= "+rbt_charge_code);
			System.out.println("GIFT_CHARGE_CODE= "+gift_charge_code);
			}

			if(rs != null) rs.close();
			pstmt.close();


			TCPPacketCharging tcpCharge = new TCPPacketCharging();
			int chr = tcpCharge.doEventBasedCharging(interMsisdn, rbt_charge_code, rbtCode,"-1",3, interfaceType); //action=3 for RBT // interfacetype='W' for crbtuser
			System.out.println("setSubscriberDateTone: chr="+chr);

			if (chr != 1)
			{
			con.rollback();
			return chr;
			}
			 */
			StringBuffer opFor = new StringBuffer();
			opFor.append(date[0]);
			opFor.append("-");
			opFor.append(date[1]);
			opFor.append("-");
			opFor.append(date[2]);
			insertIntoRbtOpLog(interMsisdn, rbtCode, 1, opFor.toString(), "N", 1);
			insertIntoSubscriberAudit(interMsisdn, 1, "Date RBT is set",con);

			con.commit();
			return 1;
		}
		catch (Exception e)
		{
			try {
				con.rollback();
			} catch(Exception exp) {}
			e.printStackTrace();
			return 0;
		}
		finally
		{
			conPool.free(con);
		}
	}


	public int deleteSubscriberProfile(String msisdn, String[] delStrings)
	{
		try
		{
			System.out.println("in deleteSubscriberProfile");
			con = conPool.getConnection();
			System.out.println("got DB connection");
			con.setAutoCommit(false);

			String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(msisdn);	

			SubscriberCallerManager	scam = new SubscriberCallerManager(con);

			//data....0 RBT, 1 Start, 2 End, 3 Grou ID, 4 Friend Msisdn

			int retVal=0;

			for(int z=0; z<delStrings.length; z++)
			{
				StringTokenizer st = new StringTokenizer(delStrings[z], "&");
				String data[] = new String[6];
				int count =0;
				String request_data = "";
				String request_for = "";

				while(st.hasMoreTokens())
				{
					data[count++]=st.nextToken();
				}

				if(!data[3].equals("0") && data[1].equals("3000")) //Default
				{
					//					String interFriendMsisdn = TSSJavaUtil.instance().getInternationalNumber(data[4]);
					//data....0 RBT, 1 Start, 2 End, 3 Grou ID, 4 Friend Msisdn
					retVal = scam.removeGroupAdvancedTone(Long.parseLong(data[3]));
					System.out.println("returned back "+retVal);
					if(retVal != 1) 
					{
						con.rollback();
						return retVal;
					}
					// *************************** Insert details in Web Stats ************************
					request_data = "An advanced Profile is deleted"; 
					request_for = data[3]; 
				}

				else if(data[1].equals("3000") && data[4].equals("Default")) //Default
				{
					String interFriendMsisdn = TSSJavaUtil.instance().getInternationalNumber(data[4]);
					//data....0 RBT, 1 Start, 2 End, 3 Grou ID, 4 Friend Msisdn
					retVal = scam.removeAdvancedTone(interMsisdn);
					if(retVal != 1) 
					{
						con.rollback();
						return retVal;
					}
					// *************************** Insert details in Web Stats ************************
					request_data = "An advanced Profile is deleted"; 
					request_for = "Default"; 
				}

				else if(data[1].equals("3000")) //Default
				{
					String interFriendMsisdn = TSSJavaUtil.instance().getInternationalNumber(data[4]);
					//data....0 RBT, 1 Start, 2 End, 3 Grou ID, 4 Friend Msisdn
					retVal = scam.removeFriendAdvancedTone(interMsisdn, interFriendMsisdn);
					if(retVal != 1) 
					{
						con.rollback();
						return retVal;
					}
					// *************************** Insert details in Web Stats ************************
					request_data = "An advanced Profile is deleted"; 
					request_for = interFriendMsisdn; 
				}

				else if(data[3].equals("0") && data[4].equals("Default")) //Default
				{
					//data....0 RBT, 1 Start, 2 End, 3 Grou ID, 4 Friend Msisdn
					retVal = scam.deleteSubscriberDefaultSetting(interMsisdn, Integer.parseInt(data[1]), Integer.parseInt(data[2]), Integer.parseInt(data[0]));
					if(retVal != 1) 
					{
						con.rollback();
						return retVal;
					}
					// *************************** Insert details in Web Stats ************************
					request_data = "A Default Profile is deleted"; 
					request_for = "Default"; 
				}

				else if(data[3].equals("0") && data[4].equals("Date"))
				{
					retVal = scam.deleteSubscriberDateSetting(interMsisdn, data[1],  Integer.parseInt(data[0]));
					if(retVal != 1) 
					{
						con.rollback();
						return retVal;
					}
					// *************************** Insert details in Web Stats ************************
					request_data = "Setting for date "+data[1]+" is deleted";
					request_for = data[1]; 
				}
				else if(data[3].equals("0") && data[4].equals("Occassion"))
				{
					retVal = scam.deleteSubscriberDateSetting(interMsisdn, data[1].substring(0,10),  Integer.parseInt(data[0]));
					if(retVal != 1)
					{
						con.rollback();
						return retVal;
					}
					// *************************** Insert details in Web Stats ************************
					request_data = "Setting for Occassion "+data[1].substring(10)+" is deleted";
					request_for = data[1].substring(10);
				}

				else if(data[3].equals("0")) //Friends
				{
					//data....0 RBT, 1 Start, 2 End, 3 Grou ID, 4 Friend Msisdn
					String interFriendMsisdn = TSSJavaUtil.instance().getInternationalNumber(data[4]);

					retVal = scam.deleteSubscriberFriendSetting(interMsisdn, Integer.parseInt(data[1]), Integer.parseInt(data[2]), interFriendMsisdn, Integer.parseInt(data[0]));
					if(retVal != 1) 
					{
						con.rollback();
						return retVal;
					}
					// *************************** Insert details in Web Stats ************************
					request_data = "Setting of friend "+interFriendMsisdn+" is deleted"; 
					request_for = interFriendMsisdn; 
				}

				else //Group
				{
					//data....0 RBT, 1 Start, 2 End, 3 Grou ID, 4 Friend Msisdn
					retVal = scam.deleteSubscriberGroupSetting(interMsisdn, Long.parseLong(data[3]), Integer.parseInt(data[1]), Integer.parseInt(data[2]),Integer.parseInt(data[0]));
					if(retVal != 1) 
					{
						con.rollback();
						return retVal;
					}
					// *************************** Insert details in Web Stats ************************
					request_data = "Settings Group "+data[0]+" is deleted"; 
					request_for = data[3]; 
				}

				insertIntoRbtOpLog(interMsisdn, Integer.parseInt(data[0]), 5, request_for, "N", 1);
				insertIntoSubscriberAudit(interMsisdn, 1, request_data,con);
			}
			con.commit();
			return 1;		
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
		finally
		{
			conPool.free(con);
		}
	}

	public int updateSubscriberProfile(String msisdn, ArrayList toneSettingsAl, int startTime, int endTime, int rbtCode, long groupId, String friendsMsisdn)
	{
		String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(msisdn);

		try
		{
			con = conPool.getConnection();
			con.setAutoCommit(false);

			SubscriberCallerManager	scam = new SubscriberCallerManager(con);
			String changeType = "";
			String request_data = "";
			String request_for = "";

			if ((groupId == 0) && friendsMsisdn.equals("Default"))
			{
				int ret = scam.updateDefaultTone(interMsisdn, toneSettingsAl, startTime, endTime, rbtCode);
				if (ret != 1)
				{
					con.rollback();
					return ret;
				}

				changeType="DEFAULT_RINGTONE";
				request_data = "Updated a default RBT";
				request_for = "Default";
			}

			else if (groupId == 0)
			{
				String interFriendMsisdn = TSSJavaUtil.instance().getInternationalNumber(friendsMsisdn);

				int ret = scam.updateFriendTone(interMsisdn, interFriendMsisdn, toneSettingsAl, startTime, endTime, rbtCode);
				if (ret != 1)
				{
					con.rollback();
					return ret;
				}

				changeType= "RINGTONE for"+interFriendMsisdn;
				request_data = "Updated RBT for"+interFriendMsisdn;
				request_for = interFriendMsisdn;
			}

			else
			{
				int ret = scam.updateGroupTone(interMsisdn, groupId, toneSettingsAl, startTime, endTime, rbtCode);
				if (ret != 1)
				{
					con.rollback();
					return ret;
				}

				changeType= "RINGTONE for Group"+groupId;
				request_data = "Updated RBT for group"+groupId;
				request_for = groupId+"";
			}

			/*			if (updateFreeEventsUsed(interMsisdn) != 1)
						{
						con.rollback();
						return 0;
						}
			 */
			if(updateCRBTScore(rbtCode) !=1)
			{
				con.rollback();
				return 0;
			}

			//						int chr = doCharging(interMsisdn, rbtCode, changeType);
			/*
			   int planIndicator = Integer.parseInt(TSSJavaUtil.instance().getAppConfigParam("DEFAULT_RATE_PLAN"));
			   query = "select RBT_CHARGE_CODE, GIFT_CHARGE_CODE from CRBT_RATE_PLANS where PLAN_INDICATOR = ?";
			   pstmt = con.prepareStatement(query);
			   pstmt.setInt(1, planIndicator);
			//System.out.println(query);

			rs = pstmt.executeQuery();
			int rbt_charge_code=0;
			int gift_charge_code=0;
			if(rs.next())
			{
			gift_charge_code=Integer.parseInt(rs.getString("GIFT_CHARGE_CODE"));
			rbt_charge_code=Integer.parseInt(rs.getString("RBT_CHARGE_CODE"));
			System.out.println("RBT_CHARGE_CODE= "+rbt_charge_code);
			System.out.println("GIFT_CHARGE_CODE= "+gift_charge_code);
			}

			if(rs != null) rs.close();
			pstmt.close();


			TCPPacketCharging tcpCharge = new TCPPacketCharging();
			int chr = tcpCharge.doEventBasedCharging(interMsisdn, rbt_charge_code, rbtCode,"-1",3, interfaceType); //action=1 for SUB // interfacetype='W' for crbtuser
			System.out.println("setSubscriberOccTone: chr="+chr);

			if (chr != 1)
			{
			con.rollback();
			return chr;
			}
			 */

			insertIntoRbtOpLog(interMsisdn, rbtCode, 6, request_for, "N", 1);
			insertIntoSubscriberAudit(interMsisdn, 1, request_data,con);

			con.commit();
		}
		catch (Exception e)
		{
			try {
				con.rollback();
			} catch(Exception exp) {}
			e.printStackTrace();
			return 0;
		}
		finally
		{
			conPool.free(con);
		}
		return 1;
	}

	private int prepaidCharging(String interMsisdn, int chargeCode)
	{
		int ret = TSSJavaUtil.instance().isChargingEnabled();
		System.out.println(ret);
		if (ret == 1) 
		{
			StringBuffer stat = new StringBuffer();
			SSFClient ssfClient = new SSFClient();

			int announcementID = SSFClient.doEventBasedCharging(chargeCode, interMsisdn, stat);
			if (announcementID < 0)
			{
				System.out.println("SSF Error");
				return 0;
			}
			System.out.println("AnnouncementID : " + announcementID);
			System.out.println("Status ID : " + stat);

			if(stat.toString().equalsIgnoreCase("true"))
			{
				if(announcementID == 502)//recharge reminder
				{
					return 502;
				}
				else if(announcementID == 510)
				{
					return 510;
				}
				return 1;
			}
			else if (stat.toString().equalsIgnoreCase("false"))
			{
				switch(announcementID)
				{
					case 501:
					case 503:
					case 507:
						return -2;
					default:
						return -2;
				}
			}
			else
			{
				System.out.println("Unexpexted results from SSF ");
				return 0;
			}
		}
		else 
		{
			System.out.println("Charging Disabled");
			return 1;
		} 
	}

	private int prepaidCharging(String interMsisdn, int planId, int rbtCode, int charge)
	{
		if (con == null)
		{
			System.out.println("CON NULL");
			return 0;	
		}

		try
		{
			String query = "";
			if (charge == 1)
			{
				query = "insert into CRBT_PREPAID_SETTING_CDR (PRE_SECDR_ID, MSISDN, INTERFACE_USED, UPDATE_TIME, STATUS, PLAN_INDICATOR, RBT_CODE) values (PRE_SECDR_ID.nextval, ?, ?, sysdate, ?, ?, ?)"; 
			}
			else
			{
				query = "insert into CRBT_PREPAID_GIFTING_CDR (PRE_GICDR_ID, MSISDN, INTERFACE_USED, UPDATE_TIME, STATUS, PLAN_INDICATOR, RBT_CODE) values (PRE_GICDR_ID.nextval, ?, ?, sysdate, ?, ?, ?)";
			}
			PreparedStatement pstmt = con.prepareStatement(query);

			pstmt.setString(1, interMsisdn);
			pstmt.setString(2, "W");
			pstmt.setString(3, "N");
			pstmt.setInt(4, planId);
			pstmt.setInt(5, rbtCode);
			pstmt.executeUpdate();
			pstmt.close();	
			return 1; //Success inserted in CDR 
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
	}

	private int postpaidCharging(String interMsisdn, int planId, int rbtCode, int charge)
	{
		if (con == null)
		{
			System.out.println("CON NULL");
			return 0;	
		}

		try
		{
			String query = "";
			if (charge == 1)
			{
				query = "insert into CRBT_SETTING_CDR (SECDR_ID, MSISDN, INTERFACE_USED, UPDATE_TIME, STATUS, PLAN_INDICATOR, RBT_CODE) values (SECDR_ID.nextval, ?, ?, sysdate, ?, ?, ?)"; 
			}
			else
			{
				query = "insert into CRBT_GIFTING_CDR (GICDR_ID, MSISDN, INTERFACE_USED, UPDATE_TIME, STATUS, PLAN_INDICATOR, RBT_CODE) values (GICDR_ID.nextval, ?, ?, sysdate, ?, ?, ?)";
			}
			PreparedStatement pstmt = con.prepareStatement(query);

			pstmt.setString(1, interMsisdn);
			pstmt.setString(2, "W");
			pstmt.setString(3, "N");
			pstmt.setInt(4, planId);
			pstmt.setInt(5, rbtCode);
			pstmt.executeUpdate();
			pstmt.close();	
			return 1; //Success inserted in CDR 
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
	}

	private int insertIntoSubscriberAudit(String interMsisdn, int actType, String strActDetail,Connection con)
	{
		PreparedStatement pstmt = null;
		try
		{
			String sub_type = subscriberProfile.getSubType();
			/*		String subscriber_type = "P";
					String query ="Select msisdn from postpaid_subscribers where msisdn='"+interMsisdn+"'";
					ResultSet rs = stmt.executeQuery(query);
					if(rs.next())
					{
					subscriber_type="O";
					rs.close();                  
					}*/

			String query = "insert into CRBT_WEB_DETAIL_LOG (MSISDN, START_TIME, REQUEST_TYPE, REQUEST_DATA, SUBSCRIBER_TYPE, REQUEST_FROM, UPDATED_BY) values(?,sysdate,?,?,?,?,?)";

			pstmt = con.prepareStatement(query);
			pstmt.setString(1, interMsisdn);
			pstmt.setInt(2, actType);
			pstmt.setString(3, strActDetail);
			pstmt.setString(4, sub_type);
			pstmt.setString(5, "W");
			pstmt.setString(6, interMsisdn);
			pstmt.executeUpdate();
			pstmt.close();
			return 1; //Success inserted in CCAudit 
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
	}

	/*	public int updateFreeEventsUsed(String interMsisdn)
		{
		if (con == null)
		{
		System.out.println("CON NULL");
		return 0;
		}

		try
		{
		PreparedStatement pstmt = null;

		String query="update CRBT_SUBSCRIBER_MASTER set FREE_EVENTS_USED = FREE_EVENTS_USED+1 where MSISDN = ?";
		pstmt = con.prepareStatement(query);
		pstmt.setString(1, interMsisdn);
		pstmt.executeUpdate();
		pstmt.close();
		return 1;
		}
		catch (Exception e)
		{
		e.printStackTrace();
		return 0;
		}
		return 1;
		}*/

	public int updateCRBTScore(int rbtCode)
	{
		if (con == null)
		{
			System.out.println("CON NULL");
			return 0;
		}
		try
		{	


			query= "update CRBT_RBT set RBT_SCORE = RBT_SCORE+1 where RBT_CODE = ?";
			pstmt = con.prepareStatement(query);
			pstmt.setInt(1, rbtCode);
			pstmt.executeUpdate();
			pstmt.close();
			//	return 1;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
		return 1;
	}	

	// ****************************** Charging *********************************************
	private int doCharging(String interMsisdn, int rbtCode, int charge)
	{
		if (con == null)
		{
			System.out.println("CON NULL");
			return 0;
		}

		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String query = null;

		int charge_code=0;	
		int planIndicator=0;

		try
		{
			planIndicator = subscriberProfile.getPlanIndicator();

			if (charge == 1)
			{
				query = "select RBT_CHARGE_CODE from CRBT_RATE_PLANS where PLAN_INDICATOR = ?";
			}
			else
			{
				query = "select GIFT_CHARGE_CODE from CRBT_RATE_PLANS where PLAN_INDICATOR = ?";	
			}
			pstmt = con.prepareStatement(query);
			pstmt.setInt(1, planIndicator);

			rs = pstmt.executeQuery();

			if(rs.next())
			{
				charge_code=Integer.parseInt(rs.getString(1));
			}

			if(rs != null) rs.close();
			pstmt.close();

			if (subscriberProfile.isPrepaid())
			{
				int retVal = prepaidCharging(interMsisdn, planIndicator, rbtCode, charge);
				//				int retVal = prepaidCharging(interMsisdn, charge_code);
				if (retVal == 1 || retVal == 502 || retVal == 510)
				{
					System.out.println("Done Prepaid Cahrging");
					return 1;
				}
				else 
				{
					System.out.println("Error In Prepaid Cahrging");
					return retVal;
				}
			}
			else
			{
				if (postpaidCharging(interMsisdn, planIndicator, rbtCode, charge) != 1)
				{
					System.out.println("Error In Postpaid Cahrging");
					return 0;
				}
				return 1;
			}
		}
		catch(Exception exp)
		{
			exp.printStackTrace();
			return 0;
		}	
	}

	public int setAdvancedTone(String msisdn, String control_name, int catId, String friendMsisdn, long groupId)
	{
		String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(msisdn);

		try
		{
			String request_data = "";
			String opFor = "";
			int ret = -1;
			if (groupId != 0)
			{
				con = conPool.getConnection();
				con.setAutoCommit(false);
				SubscriberCallerManager	scam = new SubscriberCallerManager(con);
				ret = scam.setGroupAdvanceTone(interMsisdn, control_name, catId, groupId);
				request_data = "Set Advance rbt for group";
				opFor = ""+groupId;
			}
			else if (friendMsisdn.equalsIgnoreCase("Default"))
			{ 
				con = conPool.getConnection();
				con.setAutoCommit(false);
				SubscriberCallerManager	scam = new SubscriberCallerManager(con);
				ret = scam.setAdvanceTone(interMsisdn, control_name, catId);
				request_data = "Set Advance rbt for Default";
				opFor = "Default";				
			}
			else 
			{
				String interFriendMsisdn = TSSJavaUtil.instance().getInternationalNumber(friendMsisdn);

				ArrayList frndsList = new ArrayList();
				ArrayList nickList = new ArrayList();

				nickList.add(new String(""));
				frndsList.add(interFriendMsisdn);
				//this.addNewFriend(interMsisdn, frndsList, nickList);update by ekansh
				this.addNewFriend(interMsisdn, frndsList, nickList,con);
				con = conPool.getConnection();
				con.setAutoCommit(false);
				SubscriberCallerManager	scam = new SubscriberCallerManager(con);
				ret = scam.setFriendAdvanceTone(interMsisdn, control_name, catId, interFriendMsisdn);
				request_data = "Set Advance rbt for friend";
				opFor = interFriendMsisdn;
			}
			if (ret < 1)
			{
				con.rollback();
				return ret;
			}

			insertIntoRbtOpLog(interMsisdn, ret, 1, opFor, "N", 1);
			insertIntoSubscriberAudit(interMsisdn, 1, request_data,con);

			con.commit();
		}
		catch (Exception e)
		{
			try {
				con.rollback();
			} catch(Exception exp) {}
			e.printStackTrace();
			return 0;
		}
		finally
		{
			conPool.free(con);
		}
		return 1;
	}

	public int isAdvancedSet(Rbt rbt,Connection con)
	{
		try
		{

			//con = conPool.getConnection();
			SubscriberCallerManager scam = new SubscriberCallerManager(con);

			return (scam.getAdvancedTone(subscriberProfile.getMsisdn(), rbt));
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
		
	}

	public int deleteFriendAdvanceSetting(String msisdn, String friendMsisdn)
	{
		try
		{

			con = conPool.getConnection();
			SubscriberCallerManager scam = new SubscriberCallerManager(con);

			return (scam.removeFriendAdvancedTone(msisdn, friendMsisdn));
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
		finally
		{
			conPool.free(con);
		}		
	}

	public int deleteAdvanceSetting(String msisdn)
	{
		try
		{

			con = conPool.getConnection();
			SubscriberCallerManager scam = new SubscriberCallerManager(con);

			return (scam.removeAdvancedTone(msisdn));
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return 0;
		}
		finally
		{
			conPool.free(con);
		}		
	}
	public String giftTone(String msisdn, String friendMsisdn, int rbtCode) 
	{
		{
			System.out.println("giftTone()"+subscriberProfile.getMsisdn());

			friendMsisdn = TSSJavaUtil.instance().getInternationalNumber(friendMsisdn);
			String changeType="GIFT_RINGTONE";
			String interMsisdn = subscriberProfile.getMsisdn();


			String ret_str = "";
			SetVariable sv = new SetVariable();
			sv.setMsisdn(interMsisdn);
			sv.setPlan(subscriberProfile.getPlanIndicator());
			sv.setLang(subscriberProfile.getLang());
			sv.setInterface("W");
			sv.setUpdatedBy(interMsisdn);
			sv.setSubType(subscriberProfile.getSubType());
			sv.rbt_code = rbtCode;
			sv.fmsisdn=friendMsisdn;

			System.out.println("Gifting -->"+interMsisdn+"--"+rbtCode+"---"+friendMsisdn+"---"+subscriberProfile.getLang()+"---"+subscriberProfile.getPlanIndicator()+"---"+subscriberProfile.getSubType());
			CRBTRequest crbt_req = new CRBTRequest();
			System.out.println("Gifting -->"+sv.fmsisdn);
			int resp=crbt_req.constructQuery(6,sv);
			System.out.println("resppppppppppppppp "+resp);
			
			int ret_val = crbt_req.send();
			if (ret_val == 0)
			{
				ret_str = "SuccessFul";
			}
			else
			{
				ret_str = crbt_req.err_string;
				/*String key=ret_val+"_"+subscriberProfile.getLang();
				logger.info("This is the key from"+key+"This is the lang"+subscriberProfile.getLang());
				ret_str = TSSJavaUtil.instance().getErrorStringByCode(key);*/
			}

			//	insertIntoRbtOpLog(interMsisdn, rbtCode, 1, "Default", "N", 1);
			//	insertIntoSubscriberAudit(interMsisdn, 1, "Default RBT is set");
			logger.info("Returningh    ::  "+ret_str);
			return ret_str;// retVal;

		}
	}
	/*	public int giftTone(String msisdn, String friendMsisdn, int rbtCode)
		{
		String interMsisdn = TSSJavaUtil.instance().getInternationalNumber(msisdn);

		try
		{
	//data not loaded, load it
	String interFriendMsisdn = TSSJavaUtil.instance().getInternationalNumber(friendMsisdn);

	con = conPool.getConnection();
	con.setAutoCommit(false);

	SubscriberCallerManager scam = new SubscriberCallerManager(con);

	int ret = scam.giftToneToFriend(interMsisdn, interFriendMsisdn, rbtCode);
	if (ret != 1)
	{
	insertIntoRBTGiftLog (interMsisdn, ret, interFriendMsisdn);
	con.rollback();
	return ret;
	}

	//	int chr = doCharging(interMsisdn, rbtCode, 0);
	int planIndicator = Integer.parseInt(TSSJavaUtil.instance().getAppConfigParam("DEFAULT_RATE_PLAN")); 
	query = "select RBT_CHARGE_CODE, GIFT_CHARGE_CODE from CRBT_RATE_PLANS where PLAN_INDICATOR = ?";
	pstmt = con.prepareStatement(query);
	pstmt.setInt(1, planIndicator);
	//System.out.println(query);

	rs = pstmt.executeQuery();
	int rbt_charge_code=0;
	int gift_charge_code=0;
	if(rs.next())
	{
	gift_charge_code=Integer.parseInt(rs.getString("GIFT_CHARGE_CODE"));
	rbt_charge_code=Integer.parseInt(rs.getString("RBT_CHARGE_CODE"));
	System.out.println("GIFT_CHARGE_CODE= "+gift_charge_code);
	}

	if(rs != null) rs.close();
	pstmt.close();


	TCPPacketCharging tcpCharge = new TCPPacketCharging();
	System.out.println("Charge :giftToneToFriend() .... "+interFriendMsisdn);
	int chr = tcpCharge.doEventBasedCharging(msisdn, gift_charge_code, rbtCode,interFriendMsisdn,4, interfaceType); //action=1 for SUB // interfacetype='W' for crbtuser
	System.out.println("giftToneToFriend: chr="+chr);


	if (chr != 1)
	{
	insertIntoRBTGiftLog (interMsisdn, 5, interFriendMsisdn);
	con.rollback();
	return chr;
	}

	insertIntoSettingCdr(interMsisdn, planIndicator, rbtCode, 2);
	insertIntoRBTGiftLog (interMsisdn, 1, interFriendMsisdn);
	insertIntoSubscriberAudit(interMsisdn, 0, "Gifted RBT");

	con.commit();
	return 1;
	}
	catch (Exception e)
	{
	try {
	con.rollback();
	} catch(Exception exp) {}
	e.printStackTrace();
	return 0;
	}
	finally
	{
		conPool.free(con);
	}
}*/

private int insertIntoFriendOpLog(String interMsisdn, int opCode, String friendMsisdn,Connection con)
{
	PreparedStatement pstmt = null;
	try
	{
		String sub_type = subscriberProfile.getSubType();
		String query = "insert into CRBT_FRIEND_OP_LOG (MSISDN, SUBSCRIBER_TYPE, EVENT_TIME, INTERFACE_TYPE, OP_CODE, FRIEND_MSISDN, EVENT_CHARGED, UPDATED_BY, CALL_ID) values (?,?,sysdate,?,?,?,?,?,?)";

		pstmt = con.prepareStatement(query);
		pstmt.setString(1, interMsisdn);
		pstmt.setString(2, sub_type);
		pstmt.setString(3, "W");
		pstmt.setInt(4, opCode);
		pstmt.setString(5, friendMsisdn);
		pstmt.setString(6, "N");
		pstmt.setString(7, interMsisdn);
		pstmt.setInt(8, 0);
		pstmt.executeUpdate();
		pstmt.close();
		return 1; //Success inserted in CCAudit 
	}
	catch (Exception e)
	{
		e.printStackTrace();
		return 0;
	}
}
public int getSpecialCat(String catName)
{

	System.out.println("setSpecialCat() control_name="+catName);
	int catId = 0;
	ResultSet rs=null;
	PreparedStatement pstmt=null;
	try
	{
		con = conPool.getConnection();
		String query = "select CAT_ID from CRBT_RBT_CONTROL where CONTROL_NAME=?";
		pstmt = con.prepareStatement(query);

		pstmt.setString(1, catName);

		rs = pstmt.executeQuery();

		if (rs.next())
		{
			catId = rs.getInt("CAT_ID");
		}
		else
		{
			catId=-1;
		}
		rs.close();
		pstmt.close();
	}
	catch (Exception e)
	{
		try {
			rs.close();
			pstmt.close();
		} catch(Exception exp) {}
		e.printStackTrace();
		return 0;
	}
	finally
	{
		conPool.free(con);
	}
	return catId;

}//getSpecialCategoryId


private int insertIntoGroupOpLog(String interMsisdn, int opCode, long groupId,Connection con)
{
	PreparedStatement pstmt = null;
	try
	{
		String sub_type = subscriberProfile.getSubType();
		String query = "insert into CRBT_GROUP_OP_LOG (MSISDN, SUBSCRIBER_TYPE, EVENT_TIME, INTERFACE_TYPE, OP_CODE, GROUP_ID, EVENT_CHARGED, UPDATED_BY, CALL_ID) values (?,?,sysdate,?,?,?,?,?,?)";

		pstmt = con.prepareStatement(query);
		pstmt.setString(1, interMsisdn);
		pstmt.setString(2, sub_type);
		pstmt.setString(3, "W");
		pstmt.setInt(4, opCode);
		pstmt.setLong(5, groupId);
		pstmt.setString(6, "N");
		pstmt.setString(7, interMsisdn);
		pstmt.setInt(8, 0);
		pstmt.executeUpdate();
		pstmt.close();
		return 1; //Success inserted in CCAudit 
	}
	catch (Exception e)
	{
		e.printStackTrace();
		return 0;
	}
}

private int insertIntoRBTGiftLog(String interMsisdn, int opCode, String friendMsisdn)
{
	PreparedStatement pstmt = null;
	try
	{
		String sub_type = subscriberProfile.getSubType();
		/*		String subscriber_type = "P";
				String query ="Select msisdn from postpaid_subscribers where msisdn='"+interMsisdn+"'";
				ResultSet rs = stmt.executeQuery(query);
				if(rs.next())
				{
				subscriber_type="O";
				rs.close();                  
				}*/

		String query = "insert into CRBT_RBT_GIFT_LOG (MSISDN, SUBSCRIBER_TYPE, EVENT_TIME, INTERFACE_TYPE, OP_CODE, FRIEND_MSISDN, EVENT_CHARGED, UPDATED_BY, CALL_ID) values (?,?,sysdate,?,?,?,?,?,?)";

		pstmt = con.prepareStatement(query);
		pstmt.setString(1, interMsisdn);
		pstmt.setString(2, sub_type);
		pstmt.setString(3, "W");
		pstmt.setInt(4, opCode);
		pstmt.setString(5, friendMsisdn);
		pstmt.setString(6, "Y");
		pstmt.setString(7, interMsisdn);
		pstmt.setInt(8, 0);
		pstmt.executeUpdate();
		pstmt.close();
		return 1; //Success inserted in CCAudit 
	}
	catch (Exception e)
	{
		e.printStackTrace();
		return 0;
	}
}

private int insertIntoRbtOpLog(String interMsisdn, int rbtcode, int opCode, String opFor, String charged, int treatment)
{
	PreparedStatement pstmt = null;
	try
	{
		String sub_type = subscriberProfile.getSubType();
		/*		String subscriber_type = "P";
				String query ="Select msisdn from postpaid_subscribers where msisdn='"+interMsisdn+"'";
				ResultSet rs = stmt.executeQuery(query);
				if(rs.next())
				{
				subscriber_type="O";
				rs.close();                  
				}*/

		String query = "insert into CRBT_RBT_OP_LOG (MSISDN, SUBSCRIBER_TYPE, EVENT_TIME, RBT_CODE, INTERFACE_TYPE, OP_CODE, OP_FOR, EVENT_CHARGED, UPDATED_BY, CALL_ID, OP_TREATMENT) values (?,?,sysdate,?,?,?,?,?,?,?,?)";

		pstmt = con.prepareStatement(query);
		pstmt.setString(1, interMsisdn);
		pstmt.setString(2, sub_type);
		pstmt.setInt(3, rbtcode);
		pstmt.setString(4, "W");
		pstmt.setInt(5, opCode);
		pstmt.setString(6, opFor);
		pstmt.setString(7, charged);
		pstmt.setString(8, interMsisdn);
		pstmt.setInt(9, 0);
		pstmt.setInt(10, treatment);
		pstmt.executeUpdate();
		pstmt.close();
		return 1; //Success inserted in CCAudit 
	}
	catch (Exception e)
	{
		e.printStackTrace();
		return 0;
	}
}

private int insertIntoSettingCdr(String interMsisdn, int planId, int rbtCode, int charge)
{
	if (con == null)
	{
		System.out.println("CON NULL");
		return 0;
	}

	try
	{
		String query = "";
		if (charge == 1)
		{
			query = "insert into CRBT_PREPAID_SETTING_CDR (PRE_SECDR_ID, MSISDN, INTERFACE_USED, UPDATE_TIME, STATUS, PLAN_INDICATOR, RBT_CODE) values (PRE_SECDR_ID.nextval, ?, ?, sysdate, ?, ?, ?)";
		}
		else
		{
			query = "insert into CRBT_PREPAID_GIFTING_CDR (PRE_GICDR_ID, MSISDN, INTERFACE_USED, UPDATE_TIME, STATUS, PLAN_INDICATOR, RBT_CODE) values (PRE_GICDR_ID.nextval, ?, ?, sysdate, ?, ?, ?)";
		}
		PreparedStatement pstmt = con.prepareStatement(query);

		pstmt.setString(1, interMsisdn);
		pstmt.setString(2, "W");
		pstmt.setString(3, "N");
		pstmt.setInt(4, planId);
		pstmt.setInt(5, rbtCode);
		pstmt.executeUpdate();
		pstmt.close();
		return 1; //Success inserted in CDR
	}
	catch (Exception e)
	{
		e.printStackTrace();
		return 0;
	}
}//insertIntoSettingCdr





}//class 
