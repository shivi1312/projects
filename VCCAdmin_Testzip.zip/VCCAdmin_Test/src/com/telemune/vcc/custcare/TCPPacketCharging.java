package com.telemune.vcc.custcare;
import com.telemune.vcc.common.*;

import java.io.*;
import java.net.*;

import org.apache.log4j.*;
public class TCPPacketCharging
{
      private static Logger logger=Logger.getLogger(TCPPacketCharging.class);
	final static String SSF_SERVER_HOST = TSSJavaUtil.instance().getSSFServer();//"stp"; //TODO, take from configuration
	final static short SSF_SERVER_PORT = TSSJavaUtil.instance().getSSFPort();//10101;
	private int resp;
	public void TCPPacketCharging()
	{
		resp=0;
	}


	public int doEventBasedCharging(String msisdn, int tariffID, int rbtcode, String fmsisdn, int action, String interfaceType)
	{
		logger.info("doEventBasedCharging()"+msisdn+"  "+action+" "+interfaceType+" "+rbtcode);
		Socket socket = null;
		DataOutputStream writer = null;
		DataInputStream reader = null;
		String packetData="";
		StringBuffer chStatus=null;
		try
		{
			logger.info("opening socket to..="+SSF_SERVER_HOST+" Port="+SSF_SERVER_PORT);
			socket = new Socket (SSF_SERVER_HOST, SSF_SERVER_PORT);
			//		socket.setSoTimeout(100); //100ms
		}
		catch (SocketException se)
		{
			logger.info("Error in opening socket\n");
			se.printStackTrace();
			return -1;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return -1;
		}

		try
		{
			logger.info("opening read/write stream");
			reader = new DataInputStream(socket.getInputStream());
			writer = new DataOutputStream(socket.getOutputStream());
		}
		catch (IOException ioe)
		{
			logger.info("Failed to get input/output stream\n");
			ioe.printStackTrace();
			return -1;
		}

		try
		{
			//	socket.setSoTimeout(100); //100ms
			switch(action)
			{
				case 1: //Subscription 
					packetData="ACT:"+action+";TAR:"+tariffID+";INT:"+interfaceType;
					break;
				case 2: //Subscription renew
					break;
				case 3: //RBT purchase
					packetData="ACT:"+action+";TAR:"+tariffID+";RBT:"+rbtcode+";INT:"+interfaceType;
					break;
				case 4: //RBT Gift
					packetData="ACT:"+action+";TAR:"+tariffID+";RBT:"+rbtcode+";FMSISDN:"+fmsisdn+";INT:"+interfaceType;
					break;
				default:
					break;
			}
			logger.info("packet ="+packetData);
			TCPRequest request = new TCPRequest();
		//	TCPRequest response= new TCPRequest();
			ByteArrayOutputStream buf = new ByteArrayOutputStream();
			ByteArrayInputStream inbuf = null;
			request.setMsisdn(msisdn);
			//request.setTariffID(tariffID);
			request.setData(packetData);

			request.encode(buf);

			int requestLen = buf.size();
			logger.info("request:packetData info buf size="+requestLen+" .... sending" );
	byte len[]=new byte[4];
		len[3] = (byte)(requestLen & 0xff);
                len[2] = (byte)((requestLen >> 8) & 0xff);
                len[1] = (byte)((requestLen >> 16) & 0xff);
                len[0] = (byte)((requestLen >> 24) & 0xff);	
		writer.write(len,0,4);
			writer.write(buf.toByteArray(), 0, buf.toByteArray().length);

			//logger.info("reading Info from SSFResponse");
			logger.info("response: reading info ....");
			int responseLen = reader.readInt();
			logger.info("recieved response size="+responseLen);
			byte responseBuf[] = new byte[responseLen];
			reader.read(responseBuf, 0, responseLen);

			inbuf = new ByteArrayInputStream(responseBuf);
			request.decode(inbuf);
 			resp = request.getResponseId();
			logger.info("TCPPacketCharging: response: ="+resp);
			socket.close();
			return resp;
		}
		catch(InterruptedIOException ioEx)
		{

			logger.error("Socket TimeOut occurred");
			ioEx.printStackTrace();
			return -5;
		}
		catch (IOException ioe)
		{
			logger.info("Failed to read / write\n");
			ioe.printStackTrace();
			return -6;
		}
	}//doEventBasedCharging


}//class
