package com.telemune.vcc.custcare;
import java.io.*;
import org.apache.log4j.*;
public class TCPRequest 
{
        private static Logger logger=Logger.getLogger(TCPRequest.class);
	final byte requestIDTag = 0x01;
	final byte msisdnTag = 0x02;
	final byte dataTag = 0x03;	

	private int requestID = 0;
	private String msisdn = "";
	private String data = "";
//	private int tariffID = 0;
	private int responseId=-1;	
	public TCPRequest(){}

	public TCPRequest(int requestID, String msisdn, String data)
	{
		this.requestID = requestID;
		this.msisdn = msisdn;
		this.data = data;
	}

	public void setMsisdn(String msisdn)
	{
		this.msisdn = msisdn;
	}
	
	public String getMsisdn()
	{
					return this.msisdn;
	}
	
	public void setData(String data)
	{
		this.data = data;
	}
	
	public String getData()
	{
		return this.data;
	}

	public void setRequestID(int requestID)
	{
		this.requestID = requestID;
	}
	
	public int getRequestID()
	{
		return this.requestID;
	}
	public void setResponseId(int responseId)
	{
		this.responseId = responseId;
	}
	
	public int getResponseId()
	{
		return this.responseId;
	}
	public int encode(ByteArrayOutputStream buf)
	{
		int status = 0;
		byte[] intBuf = new byte[4];
		byte[] reqBuf = new byte[4];
		byte[] len =    new byte[4];
		buf.reset();

		buf.write(requestIDTag);
	
		len[3] = (byte)(4 & 0xff);
		len[2] = (byte)((4 >> 8) & 0xff);
		len[1] = (byte)((4 >> 16) & 0xff);
		len[0] = (byte)((4 >> 24) & 0xff);
		buf.write(len,0, 4);

		//buf.write(4);

		/* 11223344 */ /* TODO, should we swap these bytes */
		reqBuf[3] = (byte)(requestID & 0xff);
		reqBuf[2] = (byte)((requestID >> 8) & 0xff);
		reqBuf[1] = (byte)((requestID >> 16) & 0xff);
		reqBuf[0] = (byte)((requestID >> 24) & 0xff);
		buf.write(reqBuf, 0, 4);
		

		buf.write(msisdnTag);
		
	 	int l_len=msisdn.length();	
//		buf.write(msisdn.length());
		len[3] = (byte)(l_len & 0xff);
		len[2] = (byte)((l_len >> 8) & 0xff);
		len[1] = (byte)((l_len >> 16) & 0xff);
		len[0] = (byte)((l_len >> 24) & 0xff);
		buf.write(len,0,4);
		buf.write(msisdn.getBytes(),0,msisdn.length());



		buf.write(dataTag);
		
		//buf.write(len, 0, 4);
	 	int d_len=data.length();	
		//buf.write(4);
//		logger.info("tariffID " + tariffID);

		/* 11223344 */ /* TODO, should we swap these bytes */
		intBuf[3] = (byte)(d_len & 0xff);
		intBuf[2] = (byte)((d_len >> 8) & 0xff);
		intBuf[1] = (byte)((d_len >> 16) & 0xff);
		intBuf[0] = (byte)((d_len >> 24) & 0xff);
		buf.write(intBuf,0,4);
		buf.write(data.getBytes(),0,data.length());
		//buf.write(tariffID);


		logger.debug("");
		byte []printBuf = buf.toByteArray();
		for (int i = 0; i < buf.size(); i++)
		{
			System.out.print(Integer.toHexString(printBuf[i]) +" ");
		}
		logger.debug("");
		return 0;
	}

	public void decode(ByteArrayInputStream buf)
	{

		logger.debug("vaise hi");
		logger.debug("");

		byte[] intBuf = new byte[4];
		int tag=0;
		int len=0;
		int status=0;


		tag= buf.read();
		logger.info("before while .... tag ="+tag);

		while (tag!=-1)
		{

			logger.info("before switch tag "+tag);
			//							logger.info("postion in buf= "+ buf.pos());

			switch (tag)
			{
				case requestIDTag:
					buf.skip(4);
					status= buf.read(intBuf,0,4);
					requestID = 0;
					requestID = requestID | intBuf[0];
					requestID = (requestID >> 8) | intBuf[1];
					requestID = (requestID >> 16) | intBuf[2];
					requestID = (requestID >> 24) | intBuf[3];
					logger.info("decode():request id"+requestID);
					break;
				case  msisdnTag:

					status= buf.read(intBuf,0,4);
					len = 0;
					len = len | intBuf[0];
					len = (len >> 8) | intBuf[1];
					len = (len >> 16) | intBuf[2];
					len = (len >> 24) | intBuf[3];

					byte[] chbuf=new byte[len];
					status= buf.read(chbuf,0,len);
					msisdn=new String(chbuf); 
					logger.info("decode():msisdn "+msisdn);
					break;
				case dataTag:

					status= buf.read(intBuf,0,4);
					len = 0;
					len = len | intBuf[0];
					len = (len >> 8) | intBuf[1];
					len = (len >> 16) | intBuf[2];
					len = (len >> 24) | intBuf[3];

					byte[] dbuf=new byte[len];
					status= buf.read(dbuf,0,len);
					data=new String(dbuf); 
					//this.responseId=Integer.parseInt(data);
					setResponseId(Integer.parseInt(data));
					logger.info("decode():data "+data);
					break;
				default:
					logger.info("decode():in default tag "+tag);

			}
			tag= buf.read();
			logger.info("decode(): tag before exit=  "+tag);
		}

//		return 0;
	}//decode

	public static void main(String [] args)
	{
		TCPRequest req = new TCPRequest();
		req.setMsisdn("9818899014");
		req.setData("prag");
		req.setRequestID(1);		
		ByteArrayOutputStream output = new ByteArrayOutputStream();
		req.encode(output);
	}
}
