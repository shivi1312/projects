/*
 * This class is used for user authentication for the web interface for CRBT. 
 *
 *
 *
 */


package com.telemune.vcc.custcare;

public class ToneSetting
{
	private int rbtCode = 0;
	private long corpId=0;
	private int day = 8;
	private int startTime = 2500;
	private int endTime = 2500;
	private String rbtMaskName;
	private String catMaskName;
	private String date = null;	
	private String occasionName = "";	

	public int getStartTime()
	{
		return startTime;			
	}
  
	public int getEndTime()
	{
		return endTime;			
	}

	public int getDay()
	{
		return day;			
	}
	
	public int getRbtCode()
	{	
		return rbtCode;			
	}
  	public long getCorpId()
	{
		return corpId;			
	}
	public void setCorpId(long corpId)
	{
		this.corpId = corpId;			
	}
	
	public String getRbtMaskName()
	{
		return rbtMaskName;
	}
   
	public String getCatMaskName()
	{
		return catMaskName;
	}

	public String getDate()
	{
		return date;
	}	
	public String getOccasionName()
	{
		return occasionName;
	}	
	
	public void setRbtMaskName(String rbtMaskName)
	{
		this.rbtMaskName = rbtMaskName;
	}

	public void setCatMaskName(String catMaskName)
	{
		this.catMaskName = catMaskName;
	}

	public int setRbtCode(int rbtCode)	
	{
		this.rbtCode = rbtCode;			
		return this.rbtCode;
	}			

	public int setDay(int day)
	{
		this.day = day;			
		return this.day;
	}
	
	public int setStartTime(int startTime)			
	{
		this.startTime = startTime;			
		return this.startTime;
	}	
	
	public int setEndTime(int endTime)
	{
		this.endTime = endTime;
		return this.endTime;
	}

	public String setDate(String date)
	{
		this.date=date;
		return this.date;
	}	
	public void setOccasionName(String ocName)
	{
		this.occasionName=ocName;
	}	
}
