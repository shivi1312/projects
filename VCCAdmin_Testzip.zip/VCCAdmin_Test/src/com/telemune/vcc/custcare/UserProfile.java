package com.telemune.vcc.custcare;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.telemune.dbutilities.Connection;
import com.telemune.dbutilities.PreparedStatement;
import com.telemune.vcc.common.TSSJavaUtil;
import com.telemune.vcc.custcare.action.UserProfileBean;
import com.telemune.vcc.custcare.action.serviceTypeBean;

public class UserProfile {
    static Logger logger=Logger.getLogger(UserProfile.class);
	private PreparedStatement pstmt = null;
	private Connection con = null;
	private ResultSet rs =null;
	private String query = null;
	private int multi_table_enable=-1;
	


	public int getUserProfile(UserProfileBean userProfileBean)
	{
		String profile;
		serviceTypeBean serviceBean=null;
		ArrayList<serviceTypeBean> serviceAl=new ArrayList<serviceTypeBean>();
		String query1; // added by Avishkar 18/9/2020
		try
		{
		logger.info("Inside getUserProfile() msisdn ["+userProfileBean.getMsisdn()+"]");
		con = TSSJavaUtil.instance().getconnection(); 
	// addition start by Avishkar
			multi_table_enable=Integer.parseInt(TSSJavaUtil.instance().getKeyValue("MULTIPLE_TABLE_SUBSCRIPTION_CHECK"));
			if (multi_table_enable==1) {
				String lastDigit=userProfileBean.getMsisdn().substring(userProfileBean.getMsisdn().length() - 1);
				String tableNameSub="VCC_SUBSCRIPTION_MASTER"+"_"+lastDigit;
				query="select SERVICE_TYPE,RATE_PLAN,DATE_REGISTERED,SERVICE_FLAG from "+tableNameSub+" where MSISDN=?";
			} else {
				query="select SERVICE_TYPE,RATE_PLAN,DATE_REGISTERED,SERVICE_FLAG from vcc_subscription_master where MSISDN=?";
			}
//						query = "select SERVICE_TYPE,RATE_PLAN,DATE_REGISTERED,SERVICE_FLAG from vcc_subscription_master where MSISDN=?";
	// addition end by Avishkar
				pstmt = con.prepareStatement (query);
				pstmt.setString(1, userProfileBean.getMsisdn());
				rs = pstmt.executeQuery ();
				serviceAl.clear();
				while(rs.next())
				{
					serviceBean=new serviceTypeBean();
						profile=getPlanName(rs.getInt("RATE_PLAN"));
						serviceBean.setProfile(profile);
						serviceBean.setDate(rs.getString("DATE_REGISTERED"));
						serviceBean.setService(rs.getString("SERVICE_TYPE"));
						serviceAl.add(serviceBean);
						userProfileBean.setServiceFlag(rs.getString("SERVICE_FLAG"));
				}
				userProfileBean.setServiceType(serviceAl);
				rs.close();
				pstmt.close();
			// addition start by Avishkar
//				multi_table_enable=Integer.parseInt(TSSJavaUtil.instance().getKeyValue("MULTIPLE_TABLE_SUBSCRIPTION_CHECK"));
				if (multi_table_enable==1) {
					String lastDigit=userProfileBean.getMsisdn().substring(userProfileBean.getMsisdn().length() - 1);
					String tableNameAuth="VCC_AUTH_USER"+"_"+lastDigit;
					query1="SELECT LANGUAGE,PASS,GREETING_TYPE from "+tableNameAuth+" where MSISDN=?";
				} else {
					query1="SELECT LANGUAGE,PASS,GREETING_TYPE from vcc_auth_user where MSISDN=?";
				}
//				query1="SELECT LANGUAGE,PASS,GREETING_TYPE from vcc_auth_user where MSISDN=?";
			// addition end by Avishkar
				pstmt=con.prepareStatement(query1);
				pstmt.setString(1, userProfileBean.getMsisdn());
				rs = pstmt.executeQuery ();
				while(rs.next())
				{
					userProfileBean.setLanguage(rs.getString("LANGUAGE"));
					userProfileBean.setPassword(rs.getString("PASS"));
					if(rs.getInt("GREETING_TYPE")==0)
						userProfileBean.setGreetingEnable("Disable");
					else if(rs.getInt("GREETING_TYPE")==1)
						userProfileBean.setGreetingEnable("Enable");
				}
				rs.close();
				pstmt.close();
				String query2="Select FRIEND_MSISDN from vcc_advanced_details where MSISDN=?";
				pstmt = con.prepareStatement (query2);
				pstmt.setString(1, userProfileBean.getMsisdn());
				rs = pstmt.executeQuery ();
				
				while(rs.next())
				{
					userProfileBean.setAlternativeNumber(rs.getString("FRIEND_MSISDN"));
				}
				rs.close();
				pstmt.close();
				logger.info("user Profile is "+userProfileBean.toString());

				
				}
		catch (Exception e)
		{
			try
			{
				if(rs != null) rs.close ();
				if(pstmt != null) pstmt.close ();
			}catch(SQLException sqle)
			{
				logger.error ("Exception in getSmscConfig, Exception is : " + sqle.getMessage ());
			}
			logger.error("Exception caught "+e);
			e.printStackTrace ();
			return -1;
		}//catch
		finally{ try {
			if(con!=null)	TSSJavaUtil.instance().freeConnection(con);
		} catch (Exception e2) {
			// TODO: handle exception
		} }

		return 1;
	}
	
	public String getPlanName(int ratePlan)
	{
		String planName="";
		Connection con=null;
	ResultSet rs=null;
	PreparedStatement pstmt=null;
		try
		{
			con=TSSJavaUtil.instance().getconnection(); 
		
		String query3="select PLAN_NAME from vcc_rate_plan where PLAN_ID=?";
		pstmt=con.prepareStatement(query3);
		pstmt.setInt(1,ratePlan);
		rs = pstmt.executeQuery ();

			while(rs.next())
			{
					planName=rs.getString("PLAN_NAME");
			}

	
		}
		catch (Exception e)
		{
			logger.error("Exception caught "+e);
			e.printStackTrace ();
		}//catch
		finally{ try {
			if(rs != null) rs.close ();
			if(pstmt != null) pstmt.close ();
			if(con!=null)	TSSJavaUtil.instance().freeConnection(con);
		} catch (Exception e2) {
			// TODO: handle exception
		} }
		return planName;
	}
	
	
	public int updateProfile(UserProfileBean userProfile)
	{
		String query="";
		Connection con=null;
		PreparedStatement pstmt=null;
		String lastDigit=""; // added by Avishkar
		String tableNameAuth=""; // added by Avishkar
		try
		{
		logger.info("msisdn ["+userProfile.getMsisdn()+"] updated language ["+userProfile.getLanguage()+"] and reset Password ["+userProfile.isResetpassword()+"]");
		con=TSSJavaUtil.instance().getconnection();
	// addition start by Avishkar
		multi_table_enable=Integer.parseInt(TSSJavaUtil.instance().getKeyValue("MULTIPLE_TABLE_SUBSCRIPTION_CHECK"));
		if(userProfile.isResetpassword()) {
			if (multi_table_enable==1) {
				lastDigit=userProfile.getMsisdn().substring(userProfile.getMsisdn().length() - 1);
				tableNameAuth="VCC_AUTH_USER"+"_"+lastDigit;
				query="update "+tableNameAuth+" set LANGUAGE=?,ISNEW=1 where MSISDN=?";
			} else {
				query="update vcc_auth_user set LANGUAGE=?,ISNEW=1 where MSISDN=?";
			}
//		 query="update vcc_auth_user set LANGUAGE=?,ISNEW=1 where MSISDN=?";
		} else {
			if (multi_table_enable==1) {
				lastDigit=userProfile.getMsisdn().substring(userProfile.getMsisdn().length() - 1);
				tableNameAuth="VCC_AUTH_USER"+"_"+lastDigit;
				query="update "+tableNameAuth+" set LANGUAGE=? where MSISDN=?";
			} else {
				query="update vcc_auth_user set LANGUAGE=? where MSISDN=?";
			}
//			 query="update vcc_auth_user set LANGUAGE=? where MSISDN=?";
		}
	// addition end by Avishkar
		pstmt=con.prepareStatement(query);
		pstmt.setString(1,userProfile.getLanguage());
		pstmt.setString(2, userProfile.getMsisdn());
		 pstmt.executeUpdate();
		}
		catch (Exception e)
		{
			logger.error("Exception caught inside updateProfile"+e.getMessage());
			e.printStackTrace ();
			return -1;
		}//catch
		finally{ try {
		
			if(pstmt != null) pstmt.close ();
			if(con!=null)	TSSJavaUtil.instance().freeConnection(con);
		} catch (Exception e2) {
			return -1;// TODO: handle exception
		} }
		return 1;
			
	}
	
	
	
	public int getProfileDetail(UserProfileBean userProfileBean)
	{
		String query="";
		Connection con=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		String planName;
		try
		{
			logger.info("Inside getProfileDetail() msisdn ["+userProfileBean.getMsisdn()+"]");
			con=TSSJavaUtil.instance().getconnection();
		// addition start by Avishkar
			multi_table_enable=Integer.parseInt(TSSJavaUtil.instance().getKeyValue("MULTIPLE_TABLE_SUBSCRIPTION_CHECK"));
			if (multi_table_enable==1) {
				String lastDigit=userProfileBean.getMsisdn().substring(userProfileBean.getMsisdn().length() - 1);
				String tableNameAuth="VCC_AUTH_USER"+"_"+lastDigit;
				String tableNameSub="VCC_SUBSCRIPTION_MASTER"+"_"+lastDigit;
				query="select a.MSISDN,a.SUB_TYPE,s.SERVICE_TYPE, s.RATE_PLAN from "+tableNameAuth+" as a inner join "+tableNameSub+" as s on a.MSISDN=s.MSISDN where a.MSISDN=? and s.SERVICE_TYPE='0010'";
			} else {
				query="select vcc_auth_user.MSISDN,vcc_auth_user.SUB_TYPE,vcc_subscription_master.SERVICE_TYPE,vcc_subscription_master.RATE_PLAN from vcc_auth_user inner join vcc_subscription_master on vcc_auth_user.MSISDN=vcc_subscription_master.MSISDN where vcc_auth_user.MSISDN=? and vcc_subscription_master.SERVICE_TYPE='0010'";;
			}
//			query = "select vcc_auth_user.MSISDN,vcc_auth_user.SUB_TYPE,vcc_subscription_master.SERVICE_TYPE,vcc_subscription_master.RATE_PLAN from vcc_auth_user inner join vcc_subscription_master on vcc_auth_user.MSISDN=vcc_subscription_master.MSISDN where vcc_auth_user.MSISDN=? and vcc_subscription_master.SERVICE_TYPE='0010'";
		// addition end by Avishkar

			pstmt = con.prepareStatement (query);
			pstmt.setString(1, userProfileBean.getMsisdn());
			rs = pstmt.executeQuery ();
			while(rs.next())
			{
				planName=getPlanName(rs.getInt("RATE_PLAN"));
				userProfileBean.setProfileType(planName);
				userProfileBean.setSubType(rs.getString("SUB_TYPE"));
			}
			logger.info("User Profile Bean is"+userProfileBean.toString());
			
	}
		catch (Exception e)
		{
			logger.error("Exception caught inside getProfileDetail for msisdn ["+userProfileBean.getMsisdn()+"]"+e.getMessage());
			e.printStackTrace ();
			return -1;
		}//catch
		finally{ try {
			if(rs != null) rs.close ();
			if(pstmt != null) pstmt.close ();
			if(con!=null)	TSSJavaUtil.instance().freeConnection(con);
		} catch (Exception e2) {
			// TODO: handle exception
		} }
		return 1;
	}	
		
}