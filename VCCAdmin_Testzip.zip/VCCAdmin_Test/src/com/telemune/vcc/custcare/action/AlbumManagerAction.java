package com.telemune.vcc.custcare.action;

import java.util.ArrayList;
import java.util.HashMap;
import org.apache.log4j.Logger;
import com.telemune.dbutilities.Connection;
import com.telemune.vcc.common.RbtDetails;
import com.telemune.vcc.common.SubscriberProfile;
import com.telemune.vcc.common.TSSJavaUtil;
import com.telemune.vcc.common.ValidateAction;
import com.telemune.vcc.custcare.AlbumDetails;
import com.telemune.vcc.custcare.AlbumManager;
import com.telemune.vcc.custcare.CallCenterManagerBean;
import com.telemune.vcc.custcare.GroupManager;

public class AlbumManagerAction extends ValidateAction
{

	private String msisdn;
	private String subType="";
	private String message;
	private BlackListManageBean albBean=null;
	private HashMap<String,String> userMap;
	private HashMap<String,String> optionMap;

	public AlbumManagerAction()
	{
		setLinkName("custcare");
	}

	public HashMap<String, String> getOptionMap() {
		return optionMap;
	}
	public void setOptionMap(HashMap<String, String> optionMap) {
		this.optionMap = optionMap;
	}
	public HashMap<String, String> getUserMap() {
		return userMap;
	}
	public void setUserMap(HashMap<String, String> userMap) {
		this.userMap = userMap;
	}
	public BlackListManageBean getAlbBean() {
		return albBean;
	}
	public void setAlbBean(BlackListManageBean albBean) {
		this.albBean = albBean;
	}
	Logger logger=Logger.getLogger(AlbumManagerAction.class);

	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}

	public String getSubType() {
		return subType;
	}
	public void setSubType(String subType) {
		this.subType = subType;
	}
	// this function handle the Add Album 


	public String home(){
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
		}else{

			String msisdn="";
			msisdn=this.getMsisdn();
			String retval="failure";
			System.out.println("Inside function home()..where MSISDN [ "+msisdn+" ] and subType ["+getSubType()+"]");
			if(sessionMap.isEmpty()||sessionMap==null)
			{
				logger.info("you sessionis expired");
				return "logout";

			}
			if(sessionMap.containsKey(msisdn))
			{
					
						msisdn=TSSJavaUtil.instance().getInternationalNumber(msisdn);
					
			}else
			{
				logger.info("Subscriberprofile attribute is not set in session");

			}
			retval="success";
			return retval;
		}
	}


	public String addAlbum()
	{
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
		}else{

			SubscriberProfile subProfile=null;
			AlbumManager albumManager = null;
			Connection con= null;
			String msisdn="";
			String user="";
			msisdn=this.getMsisdn();
			String albumName=albBean.getAlbName();
			String retval="failure";
			System.out.println("Inside function addAlbum()..where MSISDN [ "+msisdn+" ],SubType [ "+getSubType()+" ] and albName ["+albumName+"]");
			if(sessionMap.isEmpty()||sessionMap==null)
			{
				logger.info("you sessionis expired");
				return "logout";

			}
			if(sessionMap.containsKey(msisdn))
			{

				subProfile=(SubscriberProfile)sessionMap.get(msisdn);
				user=(String)sessionMap.get("user");
				msisdn=TSSJavaUtil.instance().getInternationalNumber(msisdn);
				
			}else
			{
				logger.info("Subscriberprofile attribute is not set in session");

			}
			this.setMsisdn(msisdn);

			try{
				con=TSSJavaUtil.instance().getconnection();
				albumName = albumName.toUpperCase();
				albumManager = new AlbumManager();
				albumManager.setSubscriberProfile(getSubType());
				albumManager.setUser(user);
				albumManager.setSubscriberProfile(getSubType());
				int val = albumManager.addAlbum(msisdn, albumName,con);
				if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
				if(val<0)
				{
					this.setMessage(getText("tryLater"));
					this.setActionName("goBack");
				}else if(val==0)
				{
					this.setMessage(getText("alExist"));
					this.setActionName("goBack");
				}else if(val==2)
				{
					this.setMessage(getText("custcare.invalidAlbum"));
					this.setActionName("goBack");
				}else
				{
					this.setMessage(getText("addSuccess"));
					this.setActionName("viewAlbums.action?msisdn="+msisdn+"&subType="+getSubType()+"&albBean.albName=");
				}


				retval="success";
			}catch (Exception e) {
				logger.error("Exception inside addAlbum",e); 
			}finally
			{
				subProfile=null;
				albumManager = null;
					if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
				
			}

			return retval;
		}
	}

	// this function is for getting the search result for Album 

	public String getAlbumDetailFromDatabase()
	{
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
		}else{

			SubscriberProfile subProfile=null;
			AlbumManager albumManager = null;
			ArrayList albumIdName = null;
			Connection con= null;
			String msisdn="";
			String user="";
			msisdn=this.getMsisdn();
			String name=albBean.getAlbName();
			String retval="failure";
			System.out.println("Inside function getAlbumDetailFromDatabase(). where MSIDN [ "+msisdn+" ] ,SubType [ "+getSubType()+" ] AND ALBUM NAME ["+name+"]");
			if(sessionMap.isEmpty()||sessionMap==null)
			{
				logger.info("you sessionis expired");
				return "logout";

			}
			if(sessionMap.containsKey(msisdn))
			{

				subProfile=(SubscriberProfile)sessionMap.get(msisdn);
				user=(String)sessionMap.get("user");
				
				msisdn=TSSJavaUtil.instance().getInternationalNumber(msisdn);
				
			}else
			{
				logger.info("Subscriberprofile attribute is not set in session");

			}
			this.setMsisdn(msisdn);

			try{
				con=TSSJavaUtil.instance().getconnection();
				albumManager = new AlbumManager();
				//albumManager.setConnectionPool(conPool);
				albumIdName = new ArrayList();
				boolean delButton = false;
				int albumCount = albumManager.getAlbumIdNames(msisdn, name, albumIdName,con);
				if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
				if(albumCount<0)
				{
					this.setMessage(getText("tryLater"));
					retval="result";
				}else if(albumCount==0)
				{
					this.setMessage(getText("custcare.noAlbumFound"));
					retval="result";
				}else
				{
					retval=SUCCESS;
					albBean.setDataListAl(albumIdName);
				}	

			}catch(Exception ex)
			{
				logger.error("Exception inside getAlbumDetailFromDatabase()....",ex);
			}finally
			{
				subProfile=null;
				albumManager = null;
				albumIdName = null;
					if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
			}

			return retval;
		}
	}


	// this function is for view albums details
	public String viewRbtDetailsOfAlbum()
	{	
		System.out.println("Inside function viewRbtDetailsOfAlbum()..where MSISDN [ "+msisdn+" ] , subType ["+getSubType()+"] , albumId [ "+albBean.getAlbId()+" ] and album name [ "+albBean.getAlbName()+" ]");

		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
		}else{

			SubscriberProfile subProfile=null;
			AlbumManager albumManager = null;
			AlbumDetails albumDetails = null;
			RbtDetails[] rbtDetails =null;
			ArrayList albumIdName =null;

			
			Connection con= null;
			String msisdn="";
			String user="";
			msisdn=this.getMsisdn();
			String retval="failure";
			logger.info("Inside function viewAlbumDetails()  ");

			if(sessionMap.isEmpty()||sessionMap==null)
			{
				logger.info("you sessionis expired");
				return "logout";

			}
			if(sessionMap.containsKey(msisdn))
			{

				subProfile=(SubscriberProfile)sessionMap.get(msisdn);
				user=(String)sessionMap.get("user");
				
				msisdn=TSSJavaUtil.instance().getInternationalNumber(msisdn);
				
			}else
			{
				logger.info("Subscriberprofile attribute is not set in session");

			}
			this.setMsisdn(msisdn);

			try{
				con=TSSJavaUtil.instance().getconnection();
				int defaultRbt = Integer.parseInt(TSSJavaUtil.instance().getAppConfigParam("DEFAULT_RBT"));
				long albumId = albBean.getAlbId();
				logger.info("albumId= "+ albumId);

				albumManager = new AlbumManager();
				albumDetails = new AlbumDetails();
				int defaultSetRbt =albumManager.getSubscriberDefaultSettingRbt(msisdn,con);
				int ret = albumManager.getAlbumDetails(msisdn, albumId, albumDetails,con);
				rbtDetails = albumDetails.getRbts();

				albumIdName =new ArrayList();
				int val = 0;
				if(rbtDetails.length > 0)
				{
					//second argument is "" so it will get all album names
					val = albumManager.getAlbumIdNames(msisdn, "", albumIdName,con);
					System.out.println("size of album list  -->  "+albumIdName.size());
				}

				if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
				if(ret<0||val<0)
				{
					retval="result";
					this.setMessage(getText("tryLater"));
				}else
				{
					retval="success";
					albBean.setAlbumlistAl(albumIdName);
					albBean.setRbtDetail(rbtDetails);
					albBean.setDefaultRbt(defaultRbt);
					albBean.setDefaultSetRbt(defaultSetRbt);
					albBean.setSize(rbtDetails.length);
					albBean.setOldAlbId(albumId);
				}
			}catch(Exception exe)
			{
				exe.printStackTrace();
				logger.info("Exception in viewRbtDetailsOfAlbum()....",exe);
			}finally
			{

				subProfile=null;
				albumManager = null;
				albumDetails = null;
				rbtDetails =null;
				albumIdName =null;

					if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
			}
			System.out.println("Successfully exited from viewRbtDetailsOfAlbum");
			return retval;
		}
	}


	//this function handles the move and remove of the rbt from particular album

	public String handleMoveRemoveRbtFromAlbum()
	{
		System.out.println("Inside function handleMoveRemoveRbtFromAlbum()..where MSISDN [ "+msisdn+" ] , subType ["+getSubType()+"] , albumId [ "+albBean.getAlbId()+" ] and album name [ "+albBean.getAlbName()+" ]");
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
		}else{

			SubscriberProfile subProfile=null;
			String[] idValues = null;
			int[] rbtIds = null; 
			CallCenterManagerBean callCenterManager = null;
			Connection con= null;
			String msisdn="";
			String user="";
			msisdn=this.getMsisdn();	
			String retval="failure";

			logger.info("Inside the function handleMoveRemoveRbtFromAlbum()");

			if(sessionMap.isEmpty()||sessionMap==null)
			{
				logger.info("you sessionis expired");
				return "logout";

			}
			if(sessionMap.containsKey(msisdn))
			{

				subProfile=(SubscriberProfile)sessionMap.get(msisdn);
				user=(String)sessionMap.get("user");
				
				msisdn=TSSJavaUtil.instance().getInternationalNumber(msisdn);
				
			}else
			{
				logger.info("Subscriberprofile attribute is not set in session");

			}
			this.setMsisdn(msisdn);

			try{
				con=TSSJavaUtil.instance().getconnection();
				String action = albBean.getAction();

				idValues = albBean.getDeleteAl();
				rbtIds = new int[idValues.length];
				for(int i=0; i<idValues.length; i++)
					rbtIds[i] = Integer.parseInt(idValues[i]);
				long oldaid = albBean.getOldAlbId();
				long newaid = albBean.getAlbId();
				callCenterManager = new CallCenterManagerBean();
				callCenterManager.setUser(user);
				callCenterManager.setSubscriberProfile(getSubType());

				String val = callCenterManager.removeRbtAlbum(subProfile,rbtIds,user,action,oldaid,newaid,con);
				if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
				this.setMessage(val);
				actionName="viewAlbums.action?msisdn="+msisdn+"&subType="+subType+"&albBean.albName=";
				retval="success";
			}catch(Exception exe)
			{
				logger.error("Exception in handleMoveRemoveRbtFromAlbum()....",exe);
				exe.printStackTrace();
			}finally
			{

				subProfile=null;
				idValues = null;
				rbtIds = null; 
				callCenterManager = null;
					if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
			}
			return retval;
		}
	}


	public String setDataForModifyAlbum()
	{
		System.out.println("Inside function setDataForModifyAlbum()..where MSISDN [ "+msisdn+" ] and subType ["+getSubType()+"]");
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
		}else{

			SubscriberProfile subProfile=null;
			Connection con= null;
			String msisdn="";
			String user="";
			msisdn=this.getMsisdn();	
			String retval="failure";
			//logger.info("Inside function setDataForModifyAlbum().....");
			try
			{
			if(sessionMap.isEmpty()||sessionMap==null)
			{
				logger.info("you sessionis expired");
				return "logout";

			}
			if(sessionMap.containsKey(msisdn))
			{

				subProfile=(SubscriberProfile)sessionMap.get(msisdn);
				user=(String)sessionMap.get("user");
				
				msisdn=TSSJavaUtil.instance().getInternationalNumber(msisdn);
				
			}else
			{
				logger.info("Subscriberprofile attribute is not set in session");

			}
			this.setMsisdn(msisdn);
			long albumId = albBean.getAlbId();
			String albumName = albBean.getAlbName();
			albBean.setAlbId(albumId);
			albBean.setAlbName(albumName);
			
			return SUCCESS;
			}catch (Exception e) {
					e.printStackTrace();
					return "failure";
			}
			finally
			{
				subProfile=null;
			}
		}
	}


	// this function modify the album name into database
	public String handleModifyAlbum()
	{
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
		}else{

			SubscriberProfile subProfile=null;
			AlbumManager albumManager = null;
			
			Connection con= null;
			String msisdn="";
			String user="";
			msisdn=this.getMsisdn();	
			String retval="failure";
			logger.info("Inside function  handleModifyAlbum()....");
			if(sessionMap.isEmpty()||sessionMap==null)
			{
				logger.info("you sessionis expired");
				return "logout";

			}
			if(sessionMap.containsKey(msisdn))
			{

				subProfile=(SubscriberProfile)sessionMap.get(msisdn);
				user=(String)sessionMap.get("user");
				
				msisdn=TSSJavaUtil.instance().getInternationalNumber(msisdn);
				
			}else
			{
				logger.info("Subscriberprofile attribute is not set in session");

			}
			this.setMsisdn(msisdn);

			try{
				con=TSSJavaUtil.instance().getconnection();
				long albumId = albBean.getAlbId();
				String albumName = albBean.getAlbName();	
				albumName = albumName.toUpperCase();
				albumManager = new AlbumManager();
				albumManager.setUser(user);
				albumManager.setSubscriberProfile(getSubType());

				int val = albumManager.updateAlbum(msisdn, albumId, albumName,con);
				logger.info("This is the return value of updateAlbum() RETVAL [ "+retval+" ]");
				if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
				if(val<0)
				{
					this.setMessage(getText("tryLater"));
					this.setActionName("goBack");
				}else if(val==0)
				{
					this.setMessage(getText("alExist"));
					this.setActionName("goBack");
				}else if(val==2)
				{
					this.setMessage(getText("custcare.invalidAlbum"));
					this.setActionName("goBack");
				}else
				{
					this.setMessage(getText("modSuccess"));
					this.setActionName("viewAlbums.action?msisdn="+msisdn+"&subType="+getSubType()+"&albBean.albName=");
				}

				retval="success";
			}catch(Exception exe)
			{
				logger.error("Exception in handleModifyAlbum()....",exe);
			}finally
			{
				subProfile=null;
				albumManager = null;
				
					if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
			}

			return retval;
		}
	}

	//this function handle the delete Album method
	public String handleDeleteAlbum()
	{
		System.out.println("Inside function handleDeleteAlbum()..where MSISDN [ "+msisdn+" ] , subType ["+getSubType()+"] , albumId [ "+albBean.getAlbId()+" ] and album name [ "+albBean.getAlbName()+" ]");
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
		}else{

			SubscriberProfile subProfile=null;
			AlbumManager albumManager = null;
			Connection con= null;
			String msisdn="";
			String user="";
			msisdn=this.getMsisdn();	
			String retval="failure";
			logger.info("Inside function handleDeleteAlbum()...");
			if(sessionMap.isEmpty()||sessionMap==null)
			{
				logger.info("you sessionis expired");
				return "logout";

			}
			if(sessionMap.containsKey(msisdn))
			{

				subProfile=(SubscriberProfile)sessionMap.get(msisdn);
				user=(String)sessionMap.get("user");
				
				msisdn=TSSJavaUtil.instance().getInternationalNumber(msisdn);
				
			}else
			{
				logger.info("Subscriberprofile attribute is not set in session");

			}
			this.setMsisdn(msisdn);
			long albumId = albBean.getAlbId();

			try{
				con=TSSJavaUtil.instance().getconnection();
				albumManager = new AlbumManager();
				albumManager.setUser(user);
				albumManager.setSubscriberProfile(getSubType());
				int val = albumManager.removeAlbum(msisdn, albumId,con);
				if(val<0)
				{
					this.setMessage(getText("tryLater"));
					this.setActionName("goBack");
				}else if(val==0)
				{
					this.setMessage(getText("custcare.cantDeleteAlbum"));//this.setMessage("Album can not be deleted, Delete blingback tunes from this album first");
					this.setActionName("goBack");
				}else
				{
					this.setMessage(getText("delSuccess"));
					this.setActionName("viewAlbums.action?msisdn="+msisdn+"&subType="+getSubType()+"&albBean.albName=");
				}

				retval="success";
			}catch(Exception exe)
			{
				logger.error("Inside function handleDeleteAlbum()....",exe);
			}finally
			{
				subProfile=null;
				albumManager = null;
					if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
			}

			return retval;
		}
	}



	// this function is for getting the data for Album advance option

	public String getAdvOptionData()
	{
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
		}else{

			SubscriberProfile subProfile=null;
			CallCenterManagerBean callCenter=null;
			ArrayList groupList  = null;
			ArrayList friendList = null;
			Connection con= null;
			String msisdn="";
			String user="";
			msisdn=this.getMsisdn();	
			String retval="failure";
			logger.info("Inside function getAdvOptionData()...");
			if(sessionMap.isEmpty()||sessionMap==null)
			{
				logger.info("you sessionis expired");
				return "logout";

			}
			if(sessionMap.containsKey(msisdn))
			{

				subProfile=(SubscriberProfile)sessionMap.get(msisdn);
				user=(String)sessionMap.get("user");
				
				msisdn=TSSJavaUtil.instance().getInternationalNumber(msisdn);
				
			}else
			{
				logger.info("Subscriberprofile attribute is not set in session");

			}
			this.setMsisdn(msisdn);
			userMap= new HashMap<String, String>();
			optionMap=new HashMap<String, String>();
			try{
				con=TSSJavaUtil.instance().getconnection();
				callCenter=new CallCenterManagerBean();
				callCenter.setUser(user);
				groupList  = callCenter.getGroupsList(msisdn,con);
				friendList = callCenter.getFriendsList(msisdn,con);
				albBean=new BlackListManageBean();
				if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
				albBean.setDataListAl(friendList);
				albBean.setAlbumlistAl(groupList);

				userMap.put("default",getText("default"));
				userMap.put("group",getText("group"));
				userMap.put("friend",getText("friend"));
				userMap.put("mobile",getText("mobile"));
				optionMap.put("RANDOM",getText("RANDOM"));
				optionMap.put("SEQ",getText("SEQ"));

				retval="success";
			}catch(Exception ee)
			{
				logger.error("Exception in getAdvOptionData() .....",ee);
				ee.printStackTrace();
			}finally
			{
				subProfile=null;
				callCenter=null;
				groupList  = null;
				friendList = null;
					if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
			}
			return retval;
		}
	}


	// this function is for set the data for Album advance option 
	public String handleAlbAdvOption()
	{
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
		}else{

			SubscriberProfile subProfile=null;
			CallCenterManagerBean callCenterManager = null;
			GroupManager gm=null;
			Connection con= null;
			String msisdn="";
			String users="";
			msisdn=this.getMsisdn();	
			String retval="failure";
			logger.info("Inside function handleAlbAdvOption()...");
			if(sessionMap.isEmpty()||sessionMap==null)
			{
				logger.info("you sessionis expired");
				return "logout";

			}
			if(sessionMap.containsKey(msisdn))
			{

				subProfile=(SubscriberProfile)sessionMap.get(msisdn);
				users=(String)sessionMap.get("user");
				
				msisdn=TSSJavaUtil.instance().getInternationalNumber(msisdn);
				
			}else
			{
				logger.info("Subscriberprofile attribute is not set in session");

			}
			this.setMsisdn(msisdn);
			actionName="albumHome.action?msisdn="+msisdn+"&subType="+subType;
			try{

				callCenterManager = new CallCenterManagerBean();
				//callCenterManager.setConnectionPool(conPool);
				callCenterManager.setUser(users);
				callCenterManager.setSubscriberProfile(getSubType());

				String control_name = albBean.getPlaySet();
				String user = albBean.getUserSet();
				
				gm=new GroupManager();
				con=TSSJavaUtil.instance().getconnection();
				gm.setConnection(con);
				String group = gm.getGroupNameById(albBean.getGroup(),msisdn);
				
				String friend = albBean.getFriend();
				String mobile = albBean.getMobile();
				logger.info("Values are for CONTROL [ "+control_name+" ] USER ["+user+"] GROUP ["+group+"] FRIEND ["+friend+"] MOBILE ["+mobile+"]");

				int cat_Id = -1;
				long groupId = 0;
				String friendMsisdn = "";

				if (user.equalsIgnoreCase("group"))
				{
					groupId=1;
					//           groupId = Integer.parseInt(group);
				}
				else if (user.equalsIgnoreCase("default"))
				{
					friendMsisdn = "Default";
				}
				else if (user.equalsIgnoreCase("friend"))
				{
					friendMsisdn = friend;
				}
				else if (user.equalsIgnoreCase("mobile"))
				{
					friendMsisdn = mobile;
				}
				if(groupId==0)
				{
					group="--";
				}
				//int ret = 0;
				String ret  = "";

				cat_Id = Integer.parseInt(TSSJavaUtil.instance().getAppConfigParam("SPECIAL_CONTROL_CATID"));
				logger.info("SPECIAL_CONTROL_CATID="+cat_Id);
				if(control_name.equals("SEQ"))
				{
					ret = callCenterManager.setAdvancedTone(subProfile, control_name, friendMsisdn, group,users);
				}

				else if(control_name.equals("RANDOM"))
				{
					ret = callCenterManager.setAdvancedTone(subProfile, control_name, friendMsisdn, group,users);
				}else
				{
					this.setMessage(getText("tryLater"));
				}

				this.setMessage(ret); 
				retval="success";
				if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
				
			}catch(Exception exe)
			{
				logger.error("Exception in handleAlbAdvOption()...",exe);
				exe.printStackTrace();

			}
			finally
			{
				subProfile=null;
				callCenterManager = null;
				 gm=null;
				try{
					
					if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
				}
				catch(Exception e)
				{}
			}
			return retval;
		}
	}






}
