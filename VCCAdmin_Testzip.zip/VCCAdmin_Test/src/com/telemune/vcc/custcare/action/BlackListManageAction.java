package com.telemune.vcc.custcare.action;

import java.util.ArrayList;
import org.apache.log4j.Logger;
import com.telemune.dbutilities.Connection;
import com.telemune.vcc.common.SubscriberProfile;
import com.telemune.vcc.common.TSSJavaUtil;
import com.telemune.vcc.common.ValidateAction;
import com.telemune.vcc.custcare.Blacklist;
import com.telemune.vcc.custcare.BlacklistManager;

/**
 * 
 *
 */
public class BlackListManageAction extends ValidateAction
{

	private String message;
	private String msisdn;
	private String subType;
	BlackListManageBean blkBean=null;
	Logger logger=Logger.getLogger(BlackListManageAction.class);

	public BlackListManageAction()
	{
		setLinkName("custcare");
	}
	
	public String getMsisdn() {
		return msisdn;
	}


	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}


	public String getSubType() {
		return subType;
	}


	public void setSubType(String subType) {
		this.subType = subType;
	}


	public BlackListManageBean getBlkBean() {
		return blkBean;
	}


	public void setBlkBean(BlackListManageBean blkBean) {
		this.blkBean = blkBean;
	}


	public String getMessage() {
		return message;
	}


	public void setMessage(String message) {
		this.message = message;
	}



	
	
// this function is for adding the black list number into the database
	public String addBlackListNumber()
	{
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
			}else{
				
		SubscriberProfile subProfile=null;
		String[] blNumber=null;
		Blacklist blacklist = null;
	    BlacklistManager blacklistmanager = null;
	    ArrayList blacklistar = null;
	    
		Connection con= null;
		String msisdn="";
		String user="";
		msisdn=this.getMsisdn();
		String retval="failure";
		logger.info("Inside function addBlackListNumber()... where MSISDN [  "+msisdn+" ]");
		if(sessionMap.isEmpty()||sessionMap==null)
		{
			logger.info("you sessionis expired");
			return "logout";
			
		}
		if(sessionMap.containsKey(msisdn))
		{
			
			subProfile=(SubscriberProfile)sessionMap.get(msisdn);
			user=(String)sessionMap.get("user");
			 msisdn=TSSJavaUtil.instance().getInternationalNumber(msisdn);
		}else
		{
			logger.info("Subscriberprofile attribute is not set in session");
			
		}
		this.setMsisdn(msisdn);
		blNumber=blkBean.getNumber();
		
		 blacklist = new Blacklist();
	       blacklistmanager = new BlacklistManager();
	        blacklistmanager.setUser(user);
	        blacklistmanager.setSubscriberProfile(getSubType());
	        blacklistar = new ArrayList();
	        blacklist.setUserMsisdn(msisdn);
	       

		
		
		for(int i=0;i<blNumber.length;i++)
		{
			if(blNumber[i].length()>0)
			{
				blacklistar.add(blNumber[i]);
			}
		}
		
		 blacklist.setBlacklist(blacklistar);
		 
		 
		 try{
			 con=TSSJavaUtil.instance().getconnection();
		 
	        int i = blacklistmanager.addBlacklist(blacklist,con);
	        if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
	        logger.info("The return value is from blacklistmanager.addBlacklist(blacklist,con) [ "+i+" ]");
	        if(i==-3)
	        {
	        	this.setMessage(getText("custcare.numExistInBlacklist"));
	        	actionName="goBack";
	        	
	        }else if(i==1)
	        {
	        	this.setMessage(getText("addSuccess"));
	        	actionName="modifyManageBlkPromo.action?msisdn="+msisdn+"&subType="+getSubType();
	        	
	        }else
	        {
	        	this.setMessage(getText("tryLater"));
	        	actionName="goBack";
	        }
	        retval="success";
		 }catch(Exception exe)
		 {
			 logger.error("Exception inside addBlackListNumber()...",exe);
		 }finally
		 {
				
				subProfile=null;
				blNumber=null;
				blacklist = null;
			    blacklistmanager = null;
			    blacklistar = null;
			    
				if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
		 }
		
		
		return retval;
			}
	}
	
	
// this function is for get details for Blacklist data
	public String getBalckListDetails()
	{
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
			}else{
				
		blkBean= new BlackListManageBean();
		SubscriberProfile subProfile=null;
		Blacklist blOb=null;
        BlacklistManager blMOb=null;
        ArrayList blNumAr = null;

		Connection con= null;
		String msisdn="";
		String user="";
		msisdn=this.getMsisdn();
		String retval="failure";
		logger.info("Inside function getBalckListDetails()....where msisdn [  "+msisdn+" ].");
		if(sessionMap.isEmpty()||sessionMap==null)
		{
			logger.info("you sessionis expired");
			return "logout";
			
		}
		if(sessionMap.containsKey(msisdn))
		{
			
			subProfile=(SubscriberProfile)sessionMap.get(msisdn);
			user=(String)sessionMap.get("user");
			 msisdn=TSSJavaUtil.instance().getInternationalNumber(msisdn);
		}else
		{
			logger.info("Subscriberprofile attribute is not set in session");
			
		}
		this.setMsisdn(msisdn);
		logger.info("This is 66666666666666666666"+this.getMsisdn());
		 blOb=new Blacklist();
	        blMOb=new BlacklistManager();

	        //blMOb.setConnectionPool(conPool);
	        blOb.setUserMsisdn(msisdn);
	        blNumAr = new ArrayList();
	        try{		
	        	con=TSSJavaUtil.instance().getconnection();
	        int st = blMOb.getBlackList(blOb, blNumAr,con);
	        if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
	        if (st == 1) {

	        		blkBean.setDataListAl(blNumAr);
	        		this.setMsisdn(msisdn);
	        		retval="success";
	        }else if(st==-1)
	        {
	        	this.setMessage(getText("custcare.noBlacklistCreated").replace("$(MSISDN)",msisdn));
	        	//this.setMessage("Their is no blacklist created by"+msisdn);
	        	this.actionName="goBack";
	        	retval="result";
	        }else{
	        	this.setMessage(getText("tryLater"));
	        	retval="result";
	        }
		
	        }catch(Exception exe)
	        {
	        	logger.error("Exception in getBalckListDetails()...",exe);
	        }finally
			 {
	    		subProfile=null;
	    		blOb=null;
	            blMOb=null;
	            blNumAr = null;

					if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
			 }
		return retval;
			}
	}
	
	
//this function is for deletion for blacklist numbers
	
public String deleteBlackListNumber()
{
	if(!checkSession().equalsIgnoreCase("success")){
		return "error";
		}else{
			
	SubscriberProfile subProfile=null;
	BlacklistManager blm=null;
	Connection con= null;
	String msisdn="";
	String user="";
	msisdn=this.getMsisdn();
	String retval="failure";
	logger.info("Inside function deleteBlackListNumber() for MSISDN [ "+msisdn+"  ]");
	if(sessionMap.isEmpty()||sessionMap==null)
	{
		logger.info("you sessionis expired");
		return "logout";
		
	}
	if(sessionMap.containsKey(msisdn))
	{
		
		subProfile=(SubscriberProfile)sessionMap.get(msisdn);
		user=(String)sessionMap.get("user");
		 msisdn=TSSJavaUtil.instance().getInternationalNumber(msisdn);
	}else
	{
		logger.info("Subscriberprofile attribute is not set in session");
		
	}
	
	 blm=new BlacklistManager();
     blm.setUser(user);
     blm.setSubscriberProfile(getSubType());

     this.setMsisdn(msisdn);
     String blistMsisdns[] = blkBean.getDeleteAl();

     try{
    	 con=TSSJavaUtil.instance().getconnection();
     int i = blm.deleteBlackList(msisdn,blistMsisdns,con);
     if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
     if(i<0)
     {
    	 this.setMessage(getText("tryLater"));
    	 actionName="goBack";
     }else if(i==0)
     {
    	 this.setMessage(getText("custcare.selectNumToDelete"));
    	 actionName="goBack";
    	 //this.setMessage("Please select at least one number to delete.");
     }else
     {
    	 this.setMessage(getText("delSuccess"));//this.setMessage("Successfully deleted the selected numbers!!");
    	 actionName="modifyManageBlkPromo.action?msisdn="+msisdn+"&subType="+getSubType();
     }
     retval="success";
     }catch(Exception exe)
     {
    	 logger.error("Exception inside deleteBlackListNumber()...",exe);
     }finally
	 {
    	 subProfile=null;
    	blm=null;
			if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
	 }

	return retval;
		}
}


// THIS FUNCTION GETTING THE DETAILS FOR MODIFY BLACKLIST NUMBERS
public String getDetailsForModifyBlackListNumber()
{
	if(!checkSession().equalsIgnoreCase("success")){
		return "error";
		}else{
			
	SubscriberProfile subProfile=null;
	Connection con= null;
	String msisdn="";
	String user="";
	msisdn=this.getMsisdn();
	String blkmsisdn= blkBean.getBlkMsisdn();
	try{
	logger.info("Inside function getDetailsForModifyBlackListNumber() for msisdn [  "+msisdn+"  ] and BLACKLIST MSISDN [ "+blkmsisdn+" ]");
	if(sessionMap.isEmpty()||sessionMap==null)
	{
		logger.info("you sessionis expired");
		return "logout";
		
	}
	if(sessionMap.containsKey(msisdn))
	{
		
		subProfile=(SubscriberProfile)sessionMap.get(msisdn);
		user=(String)sessionMap.get("user");
		 msisdn=TSSJavaUtil.instance().getInternationalNumber(msisdn);
	}else
	{
		logger.info("Subscriberprofile attribute is not set in session");
		
	}
	logger.info("this is the msisdn &&&&&&&&&&&&&&&&&&&"+msisdn);
	this.setMsisdn(msisdn);
	
	blkBean.setBlkMsisdn(blkmsisdn);
	blkBean.setNewBlkMsisdn(blkmsisdn);
	return "success";
	}
	catch (Exception e) {
		e.printStackTrace();
		return "failure";
	}
	finally
	{
		subProfile=null;
	}
		}
}


// THIS FUNCTION IS FOR MODIFY	BLACK LIST NUMBER
public String handleModifyBlackListNumber()
{
	if(!checkSession().equalsIgnoreCase("success")){
		return "error";
		}else{
			
	SubscriberProfile subProfile=null;
	BlacklistManager  blm= null;
		
	Connection con= null;
	String msisdn="";
	String user="";
	String retval="failure";
	msisdn=this.getMsisdn();
	String blacklistMsisdn = blkBean.getBlkMsisdn();
    String blnumber= blkBean.getNewBlkMsisdn();
	logger.info("Inside function handleModifyBlackListNumber() for MSISDN [ "+msisdn+" ] where old Blacklist No.[ "+blacklistMsisdn+" ] and new BlackList no. ["+blnumber+"]");
	 
	if(sessionMap.isEmpty()||sessionMap==null)
	{
		logger.info("you sessionis expired");
		return "logout";
		
	}
	if(sessionMap.containsKey(msisdn))
	{
		
		subProfile=(SubscriberProfile)sessionMap.get(msisdn);
		user=(String)sessionMap.get("user");
		 msisdn=TSSJavaUtil.instance().getInternationalNumber(msisdn);
	}else
	{
		logger.info("Subscriberprofile attribute is not set in session");
		
	}
	this.setMsisdn(msisdn);
	
		try{
			con=TSSJavaUtil.instance().getconnection();
			blm= new BlacklistManager();
	 		blm.setUser(user);
	        blm.setSubscriberProfile(getSubType());
	        int i = blm.modifyBlackList(msisdn, blacklistMsisdn,blnumber,con);
	        if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
	        logger.info("return value from blm.modifyBlackList() is [ "+i+" ]");
	        if(i==1)
	        {
	        	this.setMessage(getText("modSuccess"));
	        	actionName="modifyManageBlkPromo.action?msisdn="+msisdn+"&subType="+getSubType();
	        }else if(i==-1)
	        {
	        	this.setMessage(getText("custcare.friendWithNameExist"));
	        	actionName="goBack";
	        	//this.setMessage("Friend with the same name already exist");	
	        }else if(i==-3){
	        	this.setMessage(getText("custcare.numExistInBlacklist"));
	        	actionName="goBack";
	        }
	        else
	        {
	        	this.setMessage(getText("tryLater"));
	        	actionName="goBack";
	        }
	       retval="success"; 
	     	}
			catch(Exception exe)
	        {
	        	logger.error("Exception in handleModifyBlackListNumber()",exe);
	        }finally
	   	 		{
	        	subProfile=null;
	        	blm= null;
	        		
	   			if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
	   	 }
	
	return retval;
		}
}
	

}
