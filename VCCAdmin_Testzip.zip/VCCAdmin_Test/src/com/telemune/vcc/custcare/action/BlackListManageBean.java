package com.telemune.vcc.custcare.action;

import java.util.ArrayList;

import com.telemune.vcc.common.RbtDetails;

public class BlackListManageBean {

private String[] number;
private ArrayList dataListAl= new ArrayList();
String[] deleteAl;
private String blkMsisdn;
private String newBlkMsisdn;
private String albName;
private String searchText;
private int grpId;
private String userSet;
private String playSet;
private ArrayList albumlistAl= new ArrayList();
private int defaultRbt;
private int defaultSetRbt;
private long albId;
private String action;
private RbtDetails[] rbtDetail;
private int size;
private long oldAlbId;
private String group;
private String friend;
private String mobile;




public String getFriend() {
	return friend;
}

public void setFriend(String friend) {
	this.friend = friend;
}

public String getMobile() {
	return mobile;
}

public void setMobile(String mobile) {
	this.mobile = mobile;
}

public String getGroup() {
	return group;
}

public void setGroup(String group) {
	this.group = group;
}

public long getOldAlbId() {
	return oldAlbId;
}

public void setOldAlbId(long oldAlbId) {
	this.oldAlbId = oldAlbId;
}

public int getSize() {
	return size;
}

public void setSize(int size) {
	this.size = size;
}

public RbtDetails[] getRbtDetail() {
	return rbtDetail;
}

public void setRbtDetail(RbtDetails[] rbtDetail) {
	this.rbtDetail = rbtDetail;
}

public String getAction() {
	return action;
}

public void setAction(String action) {
	this.action = action;
}

public long getAlbId() {
	return albId;
}

public void setAlbId(long albId) {
	this.albId = albId;
}

public ArrayList getAlbumlistAl() {
	return albumlistAl;
}

public void setAlbumlistAl(ArrayList albumlistAl) {
	this.albumlistAl = albumlistAl;
}

public int getDefaultRbt() {
	return defaultRbt;
}

public void setDefaultRbt(int defaultRbt) {
	this.defaultRbt = defaultRbt;
}

public int getDefaultSetRbt() {
	return defaultSetRbt;
}

public void setDefaultSetRbt(int defaultSetRbt) {
	this.defaultSetRbt = defaultSetRbt;
}

public String getAlbName() {
	return albName;
}

public void setAlbName(String albName) {
	this.albName = albName;
}

public String getSearchText() {
	return searchText;
}

public void setSearchText(String searchText) {
	this.searchText = searchText;
}

public int getGrpId() {
	return grpId;
}

public void setGrpId(int grpId) {
	this.grpId = grpId;
}

public String getUserSet() {
	return userSet;
}

public void setUserSet(String userSet) {
	this.userSet = userSet;
}

public String getPlaySet() {
	return playSet;
}

public void setPlaySet(String playSet) {
	this.playSet = playSet;
}

public String getNewBlkMsisdn() {
	return newBlkMsisdn;
}

public void setNewBlkMsisdn(String newBlkMsisdn) {
	this.newBlkMsisdn = newBlkMsisdn;
}

public String getBlkMsisdn() {
	return blkMsisdn;
}

public void setBlkMsisdn(String blkMsisdn) {
	this.blkMsisdn = blkMsisdn;
}

public String[] getDeleteAl() {
	return deleteAl;
}

public void setDeleteAl(String[] deleteAl) {
	this.deleteAl = deleteAl;
}

public ArrayList getDataListAl() {
	return dataListAl;
}

public void setDataListAl(ArrayList dataListAl) {
	this.dataListAl = dataListAl;
}

public String[] getNumber() {
	return number;
}

public void setNumber(String[] number) {
	this.number = number;
}

	
	
}
