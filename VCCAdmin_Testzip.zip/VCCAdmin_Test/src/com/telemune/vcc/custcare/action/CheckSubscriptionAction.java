package com.telemune.vcc.custcare.action;

import java.util.ArrayList;
import java.util.Iterator;

import org.apache.log4j.Logger;

import com.telemune.dbutilities.Connection;
import com.telemune.vcc.common.TSSJavaUtil;
import com.telemune.vcc.common.ValidateAction;
import com.telemune.vcc.custcare.CrbtUtility;
import com.telemune.vcc.custcare.SubHistoryBean;

public class CheckSubscriptionAction extends ValidateAction{
	 Logger logger = Logger.getLogger(HistoryManagement.class);
	
	private SubscriberHistoryManagementBean historyBean = null;
	
	private String message;
	
	
	
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public SubscriberHistoryManagementBean getHistoryBean() {
		return historyBean;
	}

	public void setHistoryBean(SubscriberHistoryManagementBean historyBean) {
		this.historyBean = historyBean;
	}

	

	public String checkStatus() {
		return "success";
	}
	
	 public String handleCheckStatus() {
  /*  if (!checkSession().equalsIgnoreCase("success"))
      return "error";*/ 
    if (this.historyBean.getMsisdn() == null) {
      System.out.println("return failure to handle exception");
      return "failure";
    } 
    String msisdn = this.historyBean.getMsisdn();
    String returnString = "failure";
    Connection con = null;
    String[] header = new String[0];
    ArrayList dataListAl = null;
    int id=99;
    try {
      msisdn = TSSJavaUtil.instance().getInternationalNumber(msisdn);
      //int id = this.historyBean.getId();
      String retVal = "";
      String title = this.historyBean.getTitle();
      this.logger.info("Inside function handleSubHistory() where MSISDN [" + 
          msisdn + "]  ID [" + id + "] title["+getText("custitleHistory" + id)+"]");
      con = TSSJavaUtil.instance().getconnection();
      dataListAl = new ArrayList();
      int headerCount = 0;
      String head = "";
      head = getText("cusReportHeader" + id);
     // text = getText("custitleHistory" + id);
      historyBean.setTitle(getText("custitleHistory" + id));
      this.logger.info("head from language file is = " + head);
      String[] paramsVal = head.split(",");
      headerCount = paramsVal.length;
      this.logger.info("Length of header [" + headerCount + "]");
      header = paramsVal;
   //   if (this.sessionMap.containsKey(this.historyBean.getSessionNumber())) {
        switch (id) {
         /* case 1:
            retVal = getHistoryReport(con, msisdn, dataListAl, 
                headerCount);
            returnString = "success";
            break;
          case 2:
            retVal = getMailBoxReport(con, msisdn, dataListAl, 
                headerCount, this.historyBean.getServiceType());
            returnString = "success";
            break;
          case 3:
            retVal = getRecordingHistory(con, msisdn, dataListAl, 
                headerCount, this.historyBean.getStart(), 
                this.historyBean.getEnd(), this.historyBean.getBasedOn());
            returnString = "success";
            break;
          case 4:
            retVal = getSmsHistory(con, msisdn, dataListAl, 
                headerCount, this.historyBean.getStart(), 
                this.historyBean.getEnd());
            returnString = "success";
            break;*/
        case 99:
        	retVal=getUserStatus(con, msisdn, dataListAl, 
                    headerCount);
        	returnString = "success";
        	break;
        
        } 
     /* } else {
        this.logger.info("You are not authenticated to view this link");
        returnString = "error";
      } */
      int size = dataListAl.size();
      this.logger.info("This is the size of list [" + size + "]");
      if (con != null)
        TSSJavaUtil.instance().freeConnection(con); 
      setMessage(retVal);
      this.historyBean.setHeader(header);
      this.historyBean.setId(id);
      this.historyBean.setDataAl(dataListAl);
      this.historyBean.setMsisdn(msisdn);
      this.historyBean.setSize(size);
      this.historyBean.setTitle(getText("custitleHistory" + id));
    } catch (Exception exe) {
      this.logger.info("Their is some exception in handleSubHistory() ", 
          exe);
      exe.printStackTrace();
      return "failure";
    } finally {
      header = null;
      dataListAl = null;
      try {
        if (con != null && 
          con != null)
          TSSJavaUtil.instance().freeConnection(con); 
      } catch (Exception exe) {
        exe.printStackTrace();
      } 
    } 
    return returnString;
}
	
	 
	 
	 public String getUserStatus(Connection con, String msisdn, ArrayList<String[]> dataAl, int headCount) {
		    if (!checkSession().equalsIgnoreCase("success"))
		      return "error"; 
		    if (this.historyBean == null) {
		      System.out.println("return failure to handle exception");
		      return "failure";
		    } 
		    dataAl.clear();
		    this.logger.info("Inside function getHistoryReport()... where MSISDN [" + 
		        msisdn + "]");
		    String retVal = "";
		    ArrayList historyAl = new ArrayList();
		    CrbtUtility crbtutil = new CrbtUtility();
		    SubHistoryBean subHistory = null;
		    try {
		      int st = crbtutil.checkStatus(msisdn, historyAl, con);
		      this.logger.info("Return value is [" + st + "]");
		      String type = "";
		      if (st == 1 && historyAl.size() > 0) {
		        this.logger.info("Inside block where data found into data base");
		        retVal = "OK";
		        Iterator<SubHistoryBean> ite = historyAl.iterator();
		        while (ite.hasNext()) {
		          String serviceType = "";
		          String interfaceType = "";
		          String[] data = new String[headCount];
		          subHistory = new SubHistoryBean();
		          subHistory = ite.next();
		          if (subHistory.getServiceType()
		            .equalsIgnoreCase(TSSJavaUtil.instance().getKeyValue("VM"))) {
		            serviceType = "Voice Mail Service";
		          } else if (subHistory.getServiceType()
		            .equalsIgnoreCase(TSSJavaUtil.instance().getKeyValue("VN"))) {
		            serviceType = "Voice Note Service";
		          } else if (subHistory.getServiceType()
		            .equalsIgnoreCase(TSSJavaUtil.instance().getKeyValue("MCA"))) {
		            serviceType = "Missed Call Alert";
		          } 
		         
		         
		          //data[0] = subHistory.getDate();
		          data[0] = subHistory.getMsisdn();
		          //data[1]= subHistory.getServiceType();
		          //data[2] = interfaceType;
		          //data[3] = subHistory.getMailBoxType();
		          data[1] = serviceType;
		          data[2] = subHistory.getStatus();
		          data[3] = subHistory.getExpiryDate();
		          //data[5] = subHistory.getUpdatedBy();
		         // data[6] = type;
		          this.logger.info("This is the data [" + data[0] + "] [" + 
		              data[1] + "] [" + data[2] + "] [" + data[3] + 
		              "]");
		          dataAl.add(data);
		        } 
		      } else if (st == 1) {
		        retVal = String.valueOf(getText("cusalerthis")) + " " + msisdn;
		      } else {
		        retVal = getText("alertunknown");
		      } 
		    } catch (Exception e) {
		      e.printStackTrace();
		    } finally {
		      historyAl = null;
		      crbtutil = null;
		      subHistory = null;
		    } 
		    this.logger.info("This is the resultant String [" + retVal + "]");
		    return retVal;
		  }
		  
	 
	 
	
	
	
	

}
