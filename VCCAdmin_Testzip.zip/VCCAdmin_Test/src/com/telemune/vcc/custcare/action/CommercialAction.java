package com.telemune.vcc.custcare.action;

import java.util.ArrayList;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;
import com.telemune.dbutilities.Connection;
import com.telemune.vcc.common.CategoryManager;
import com.telemune.vcc.common.RbtManager;
import com.telemune.vcc.common.TSSJavaUtil;
import com.telemune.vcc.common.ValidateAction;
import com.telemune.vcc.custcare.CommercialSubManager;
import com.telemune.vcc.custcare.InvalidSearchManager;
import com.telemune.vcc.custcare.PromotionBlackListManager;

public class CommercialAction extends ValidateAction {

	private String message;
	CommercialBean bean;
	Logger logger= Logger.getLogger(CommercialAction.class);
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public CommercialBean getBean() {
		return bean;
	}
	public void setBean(CommercialBean bean) {
		this.bean = bean;
	}
	
	public CommercialAction()
	{
		setLinkName("custcare");
	}
	
// here the function start for commercials
	
	public String getDataForAddComercial()
	{
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
			}else{
				
		bean = new CommercialBean();
		String retVal= "failure";
		logger.info("Inside function getDataForAddComercial()........");
		ArrayList catList= new ArrayList();
		CategoryManager categoryManager= null;
		Connection con=null;
		try{
			
		con=TSSJavaUtil.instance().getconnection();
		categoryManager= new CategoryManager();
		categoryManager.getCategoryListForAddComercial(catList, con);
		if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
		int size=catList.size();
		bean.setCatList(catList);
		bean.setSize(size);
		retVal="success";
		}catch(Exception e)
		{
			logger.info("Exception in getDataForAddComercial().... ",e);
			
		}finally
		{
			categoryManager=null;
			catList=null;
				if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
		}
		
		return retVal;
			}
	}
	
	
// this function is for getting the rbtlist from ajax	
public String getRbtListFromAjax()
{
	int pageId= bean.getPageId();
	int catId= bean.getCatId();
	int pageCount=0;
	logger.info("Inside function getRbtListFromAjax()..where pageId ["+pageId+"] and catId ["+catId+"] -1 for all categories");
	if(!checkSession().equalsIgnoreCase("success")){
		return "error";
		}else{
			
	String retVal="failuire";
	RbtManager manager= null;
	ArrayList rbtlist= null;
	Connection con=null;
	try{
		con=TSSJavaUtil.instance().getconnection();
		manager= new RbtManager();
		rbtlist= new ArrayList();
		pageCount=manager.getRbtdetailsForCom(con, rbtlist, catId, pageId);
		if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
		int showing=pageId*20;
        for(int i=0;i<rbtlist.size();i++)
        {
                showing++;
        }
        logger.info("Page id before set in bean ["+pageId+"]");
        int size= rbtlist.size();
        bean.setRbtList(rbtlist);
        bean.setPageId(pageId);
        bean.setPageCount(pageCount);
        bean.setCatId(catId);
        bean.setShow(showing);
        bean.setSize(size);
        retVal="success";
	}catch(Exception e)
	{
	logger.error("Exception in getRbtListFromAjax()....",e);
	retVal="failure";
	}finally
	{
		manager=null;
		rbtlist=null;
			if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
	}
	
	return retVal;
		}
}

// this function is for Invlaid search rbt
	
	public String getInvalidSearchedRbtList()
	{
		logger.info("Inside function getInvalidSearchedRbtList().....");
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
			}else{
		bean= new CommercialBean();
		InvalidSearchManager isMOb=null;
        ArrayList isNumAr = null;
		String retVal="failure";
		Connection con=null;
		try{
		con=TSSJavaUtil.instance().getconnection();
		isMOb=new InvalidSearchManager();
        isNumAr = new ArrayList();
        int st = isMOb.getInvalidSearch(isNumAr,con);
        if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
        logger.info("This is the retval from "+st+" and the size of list is "+isNumAr.size());
        bean.setRbtList(isNumAr);
        
        bean.setSize(isNumAr.size());
        retVal="success";
		}catch(Exception e)
		{
			logger.info("Exception inside getInvalidSearchedRbtList() ..",e);
		}finally
		{
			isMOb=null;
			isNumAr=null;
				if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
		}
		
		return retVal;
			}
	}
	
	
// this function is for getting the category list for commercial manage
	
public String getCatForComManage()
{
	logger.info("Inside function getCatForComManage()......");
	if(!checkSession().equalsIgnoreCase("success")){
		return "error";
		}else{
	
	bean= new CommercialBean();
	String retval="failure";
	Connection con=null;
	ArrayList catList= null;
	CategoryManager manager= null;
	try{
		int size=0;
		catList= new ArrayList();
		con=TSSJavaUtil.instance().getconnection();
		manager= new CategoryManager();
		int ret=manager.getCategoryForComManage(catList, con);
		if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
		if(ret==0)
		{
			size=0;
		}else
		{
			size=catList.size();
			
		}
		bean.setCatList(catList);
		bean.setSize(size);
		retval="success";
		logger.info("The value of size [ "+size+" ]");
	}catch(Exception ex)
	{
		logger.info("Exception in getCatForComManage()...",ex);
		
	}finally
	{
		catList= null;
		manager= null;
			if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
	}
	return retval;
		}
}

// this function get the rbt list of Commercial manage
public String getRbtForComManage()
{
	
	String retval="failure";
	int catId= bean.getCatId();
	logger.info("Inside function getRbtForComManage().. where catId is [ "+catId+" ] ");
	Connection con=null;
	if(!checkSession().equalsIgnoreCase("success")){
		return "error";
		}else{
			ArrayList rbtList= null;
			CategoryManager manager=null;
	try{
		con=TSSJavaUtil.instance().getconnection();
		rbtList= new ArrayList();
		manager=new CategoryManager();
		int ret=manager.getRbtForComManage(catId, rbtList, con);
		int size= rbtList.size();
		if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
		bean.setRbtList(rbtList);
		bean.setSize(size);
		retval="success";
		
	}catch (Exception e) {
		logger.error("Exception in getRbtForComManage()....",e);
		// TODO: handle exception
	}finally
	{
		manager=null;
		rbtList=null;
			if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
	}
	
	return retval;
		}
}
	
// this function is for getting the data for 	manae view commercial
public String getDataForViewCom()
{

	String rbtId= bean.getRbtId();
	String rbtName= bean.getRbtName();
	Connection con= null;
	String retVal= "failure";
	logger.info("Inside function getDataForViewCom()...... where rbtID [ "+rbtId+" ] rbtName [ "+rbtName+" ]");
	if(!checkSession().equalsIgnoreCase("success")){
		return "error";
		}else{
	
			CommercialSubManager comMan=null;
		      ArrayList NumAr = null;
	try{
		con=TSSJavaUtil.instance().getconnection();
	  comMan=new CommercialSubManager();
      NumAr = new ArrayList();
      int st = comMan.getMembers(NumAr,rbtId,con);
      if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
      if(st==1){
      logger.info("Return value is  [ "+st+" ] and size of list is [  "+NumAr.size()+"  ]");
      
      bean.setCatList(NumAr);
      bean.setSize(NumAr.size());
      retVal="success";
      
      }else
      {
    	  logger.info("Please try later ");
    	retVal="success";  
      }
      
	}catch (Exception e) {
		// TODO: handle exception
		logger.error("Exception in getDataForViewCom()....",e);
	}finally
	{
		comMan=null;
	    NumAr = null;
			if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
	}
	
	return retVal;
		}
}


// this function is for manage Modify commercial
public String getDataForManageComModify()
{
	String member= bean.getMember();
	logger.info("Inside function getDataForManageComModify()... where member  [  "+member+" ]");
	if(!checkSession().equalsIgnoreCase("success")){
		return "error";
		}else{
	
	bean.setMember(member);
	bean.setMsisdn(member);
	return "success";
		}
}




// this function modifies the manage commercial
public String modifyManageCom()
{
	String old_mem= bean.getMember();
	String new_mem=bean.getMsisdn();
	Connection con=null;
	String retVal= "failure";
	logger.info("Inside function modifyManageCom().... where old_member is [ "+old_mem+" ] and new mwmber is  [ "+new_mem+" ]");
	if(!checkSession().equalsIgnoreCase("success")){
		return "error";
		}else{
	
			CommercialSubManager  csm= null;
	try{
		con=TSSJavaUtil.instance().getconnection();
	csm= new CommercialSubManager();
	  int i = csm.modifyMember(old_mem,new_mem,con);
	if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
	
	if(i==1)
	{
		this.setMessage(getText("modSuccess"));
		
	}else if(i==-3)
	{
		this.setMessage(getText("alExist"));//this.setMessage("Number already exist");
			
	}else
	{
		this.setMessage(getText("tryLater"));
	}
	retVal="success";
	}catch(Exception e)
	{
		logger.info("Exception in modifyManageCom()...",e);
	}finally
	{
		csm=null;
			if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
	}
	return retVal;
		}
}


// this function is for deleting the manage commercial member 
public String deleteManageComMember()
{
	String[] deleteAl= bean.getDeleteAl();
	logger.info("Inside function deleteManageComMember().... where the length of deleteArray is [ "+deleteAl.length+" ]");
	if(!checkSession().equalsIgnoreCase("success")){
		return "error";
		}else{
	
	Connection con= null;
	String retVal="failure";
	try{
		 CommercialSubManager csm=new CommercialSubManager();
		con= TSSJavaUtil.instance().getconnection();
		int i = csm.deleteMembers(deleteAl,con);
		if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
		if(i==0)
		{
			this.setMessage(getText("custcare.selectMemToDelete"));
			//this.setMessage("Please select atleast one member to be deleted");
		}else if(i<0)
		{
			this.setMessage(getText("tryLater"));
		}else
		{
			this.setMessage(getText("delSuccess"));
		}
		retVal="success";
	}catch (Exception e) {
		// TODO: handle exception
		logger.info("Excepotion inside deleteManageComMember()... ",e);
	}
	finally
	{
		deleteAl=null;
		if(con!=null) TSSJavaUtil.instance().freeConnection(con);
	}
	return retVal;
		}
}



// this function is for set the rbtcode in add commercial
public String comset()
{
	String rbtId=bean.getRbtId();
	String rbtName=bean.getRbtName();
	logger.info("Inside function comset() where rbtid [ "+rbtId+" ] and rbtName [  "+rbtName+" ]");
	if(!checkSession().equalsIgnoreCase("success")){
		return "error";
		}else{
	
	bean.setRbtId(rbtId);
	bean.setRbtName(rbtName);
	return "success";
		}
}

// this function is for comset msisdn
public String setCommercialMsisdn()
{
	String rbtId=bean.getRbtId();
	String rbtName=bean.getRbtName();
	actionName="addCom.action";
	logger.info("Inside function setCommercialMsisdn()..... where rbtcode [ "+rbtId+" ] and rbtname [ "+rbtName+" ]");
	if(!checkSession().equalsIgnoreCase("success")){
		return "error";
		}else{
	
	String msisdn=bean.getMsisdn();
	CommercialSubManager comManager = new CommercialSubManager();
	StringTokenizer st = null;
    ArrayList Members = null;
    ArrayList exclusionList =null;

    //comManager.setConnectionPool(conPool);
	String retVal="failure";
	Connection con=null;
	try{
		con=TSSJavaUtil.instance().getconnection();
	int rbtcode=Integer.parseInt(rbtId);
    long excludeSize=0;
    st = new StringTokenizer(msisdn);

    Members = new ArrayList();
    exclusionList =new ArrayList();

    while(st.hasMoreTokens())
    {
        Members.add(st.nextToken());
    }

    int i = comManager.addCommercialSub(rbtcode,Members,exclusionList,con);
    if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
    excludeSize = exclusionList.size();
    logger.info(excludeSize+ " numbers excluded from commercial subscription");
	if(i==-5)
	{
		this.setMessage(getText("tryLater"));
		retVal="success";
	}else if(i==1&& excludeSize==0)
	{
		this.setMessage(getText("custcare.allNumAdded"));//this.setMessage("All numbers are added successfully!");
		retVal="success";
	}else if(excludeSize>0&&i==1)
	{
		this.setMessage(getText("custcare.numAdded"));//this.setMessage("Numbers are added");
		bean.setCatList(exclusionList);
		retVal="exclude";
	}else
	{
		this.setMessage(getText("tryLater"));
		retVal="success";	
	}
    
	}catch(Exception exe)
	{
		logger.info("Exception in setCommercialMsisdn()... ",exe);
	}finally
	{
		comManager = null;
		st = null;
	    Members = null;
	    exclusionList =null;

			if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
	}
	return retVal;
		}
}


// this function is for rbt search for Add commercial
public String getRbtSearchedForAddCom()
{
	String sertxt=bean.getSearchTxt();
	int pageid=bean.getPageId();
	String retVal= "failure";
	logger.info("Inside function getRbtSearchedForAddCom().... where SEARCHED TEXT [ "+sertxt+" ] and pageid [ "+pageid+" ]");
	if(!checkSession().equalsIgnoreCase("success")){
		return "error";
		}else{
	
	 String rbtName = sertxt.toUpperCase();
	 Connection con= null;
	 CategoryManager catManager= null;
	 ArrayList rbtList = null;
	 try{
		 con=TSSJavaUtil.instance().getconnection();
	 catManager= new CategoryManager();
	 rbtList = new ArrayList();
	 int rbtCount = catManager.searchRbtTonescom(rbtName, pageid, rbtList,con);
	 if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
	 int showing = pageid*10;
	for(int i=0;i<rbtList.size();i++)
	{
		showing++;
	}
	 bean.setSearchTxt(sertxt);
	 bean.setPageId(pageid);
	 bean.setPageCount(rbtCount);
	 bean.setShow(showing);
	 bean.setRbtList(rbtList);
	 bean.setSize(rbtList.size());
	 retVal="success";
	 }catch(Exception exe)
	 {
		 logger.error("Exception in getRbtSearchedForAddCom()...",exe);
	 }finally
		{
		 catManager= null;
		 rbtList = null;
				if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
		}
	 return retVal;
		}
}



// this function is for rbt search for manage commercial
public String getRbtSearchedForManageCom()
{
	String sertxt=bean.getSearchTxt();
	int pageid=bean.getPageId();
	String retVal= "failure";
	logger.info("Inside function getRbtSearchedForManageCom().... where SEARCHED TEXT [ "+sertxt+" ] and pageid [ "+pageid+" ]");
	if(!checkSession().equalsIgnoreCase("success")){
		return "error";
		}else{
	
	 String rbtName = sertxt.toUpperCase();
	 Connection con= null;
	 CategoryManager catManager= null;
	 ArrayList rbtList = null;
	 
	 try{
		 con=TSSJavaUtil.instance().getconnection();
	 catManager= new CategoryManager();
	 rbtList = new ArrayList();
	 int rbtCount = catManager.searchRbtTonesView(rbtName, pageid, rbtList,con);
	 if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
	 int showing = pageid*10;
	for(int i=0;i<rbtList.size();i++)
	{
		showing++;
	}
	 bean.setSearchTxt(sertxt);
	 bean.setPageId(pageid);
	 bean.setPageCount(rbtCount);
	 bean.setShow(showing);
	 bean.setRbtList(rbtList);
	 bean.setSize(rbtList.size());
	 retVal="success";
	 }catch(Exception exe)
	 {
		 logger.error("Exception in getRbtSearchedForManageCom()...",exe);
	 }finally
		{
		 catManager= null;
		 rbtList = null;
		 
				if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
		}
	 return retVal;
		}
}


// here is the function starts for handling the promotional black list
public String setmsisdnForPromo()
{
	String msisdn=bean.getMsisdn();
	msisdn=TSSJavaUtil.instance().getInternationalNumber(msisdn);
	logger.info("Inside function setmsisdnForPromo()..... where MSISDN [ "+msisdn+"  ]");
	if(!checkSession().equalsIgnoreCase("success")){
		return "error";
		}else{
	
	bean.setMsisdn(msisdn);
	return "success";
		}
}


//handle promotional blaklist for particular msisdn
public String handlePromoBlacklist()
{
	actionName="blackpromo?bean.msisdn="+bean.getMsisdn();
	int id=bean.getShow();
	String msisdn=bean.getMsisdn();
	msisdn=TSSJavaUtil.instance().getInternationalNumber(msisdn);
	logger.info("Inside function handlePromoBlacklist()...... where ID [ "+id+" ] and MSISDN [ "+msisdn+" ]");
	if(!checkSession().equalsIgnoreCase("success")){
		return "error";
		}else{
	
	String retVal="failure";
	String title="";
	
	switch(id)
	{
	case 1:retVal="success";
			title=getText("custcare.addBlacklistPromotion");
			break;
			
	case 2:		retVal="success";
				title=getText("custcare.removeBlacklistPromotion");
				break;
	
	}
	
	//String[] blak={"OBD","*COPY","SMS"};
	
	bean.setMsisdn(msisdn);
	bean.setSearchTxt(title);
	bean.setShow(id);
	return "success";
		}
}


// this function is for handle the add/remove the promotion blacklist 
public String handleAddRemovePromotion()
{
int id=bean.getShow();
actionName="blackpromo?bean.msisdn="+bean.getMsisdn();
logger.info("Inside function handleAddRemovePromotion().....  ");
if(!checkSession().equalsIgnoreCase("success")){
	return "error";
	}else{

String msisdn=bean.getMsisdn();
// String sub=request.getParameter("sub");
 String promo=bean.getMember();
 PromotionBlackListManager problackmanage=null;
 Connection con= null;
 try{
	 con=TSSJavaUtil.instance().getconnection();
 int promoCheck=Integer.parseInt(promo);
 problackmanage=new PromotionBlackListManager();
 int status=0;
 if(promoCheck==1)
 {
promo="OBD";

  }
  else if(promoCheck==2)
   {
 promo="*copy";

   }
   else if(promoCheck==4)
   {
promo="SMS";
   }
 logger.info("Inside function handleAddRemovePromotion()..... where ");
 switch(id)
 {
 case 1:status= problackmanage.addBlackListPromotion(msisdn,promo,status,con);
 if(status==4)
	{
	 this.setMessage(getText("custcare.numExistForPromo").replace("$(PROMO)",promo));//this.setMessage("Particular Number is Already exist for "+promo);
	}else if(status<0)
	{
		this.setMessage(getText("custcare.blacklistFailForPromo").replace("$(PROMO)",promo));//this.setMessage("BlackList Promotion Fail for "+promo);
	}else if(status>0)
	{
		this.setMessage(getText("custcare.addBlacklistPromoSuccess").replace("$(PROMO)",promo));//this.setMessage("Add BlackList Promotion successfully for "+promo);
	}else
	{
		this.setMessage(getText("tryLater"));//this.setMessage("Please try later "+promo);
	}
 		break;
 case 2:status= problackmanage.removeBlackListPromotion(msisdn,promo,status,con);
 		if(status==5)
 		{
 			this.setMessage(getText("custcare.numNotInBlacklistPromo").replace("$(PROMO)",promo));//this.setMessage("Particular Number is not in BlackList for "+promo);
 		}else if(status<0)
 		{
 			this.setMessage(getText("custcare.blacklistPromoFail").replace("$(PROMO)",promo));//this.setMessage("BlackList Promotion Fail for "+promo);
 		}else if(status>0)
 		{
 			this.setMessage(getText("custcare.delBlacklistPromoSuccess").replace("$(PROMO)",promo));//this.setMessage("Remove BlackList Promotion successfully for "+promo);
 		}else
 		{
 			this.setMessage(getText("tryLater"));//this.setMessage("Please try later "+promo);
 		}
 		break;
 }
 if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
     
   logger.info("status is "+status);


 }catch(Exception exe)
 {
	logger.error("Exception inside handleAddRemovePromotion......",exe);
	return "failure";
 }finally
 {
	 problackmanage=null;
		if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
 }
return "success";
	}	
}


// this function is for view black list promo 
public String viewBlackListPromo()
{
	String msisdn=bean.getMsisdn();
	actionName="blackpromo?bean.msisdn="+bean.getMsisdn();
	logger.info("Inside the function viewBlackListPromo()...");
	if(!checkSession().equalsIgnoreCase("success")){
		return "error";
		}else{
	
	PromotionBlackListManager problackmanage=new PromotionBlackListManager();
    int status=-10;
    String res="";
    String retval="failure";
       StringBuffer respo=new StringBuffer("");
logger.info("before viewBlackListPromo calling...");
Connection con= null;
       try{    
    	   con=TSSJavaUtil.instance().getconnection();
  status= problackmanage.viewBlackListPromotion(msisdn,status,respo,con);
  if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
logger.info(" status is "+status+" and response is "+respo);
	if(status==0)
	{
		res="Not register for any services";
		retval="response";
	}else if (status>0)
	{
		res=respo.toString();
		retval="response";
	}else
	{
		this.setMessage(getText("tryLater"));
		retval="success";
	}
	bean.setMsisdn(msisdn);
	bean.setMember(res);

       }catch(Exception exe)
       {
    	   logger.error("Exception in viewBlackListPromo()......",exe);
       }finally
		{
    	   problackmanage=null;
				if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
		}
	 return retval;

		}
}


}
