package com.telemune.vcc.custcare.action;

import java.util.ArrayList;

public class CommercialBean {

private String searchTxt;
private int catId;
private String rbtId;
private String rbtName;
private int pageId;
private int pageCount;
private int show;
private int size;
private ArrayList catList= new ArrayList();
private ArrayList rbtList= new ArrayList();
private int selectcatid;
private String msisdn;
private String member;
private String[] deleteAl;





public String[] getDeleteAl() {
	return deleteAl;
}
public void setDeleteAl(String[] deleteAl) {
	this.deleteAl = deleteAl;
}
public String getMember() {
	return member;
}
public void setMember(String member) {
	this.member = member;
}
public String getMsisdn() {
	return msisdn;
}
public void setMsisdn(String msisdn) {
	this.msisdn = msisdn;
}
public int getSelectcatid() {
	return selectcatid;
}
public void setSelectcatid(int selectcatid) {
	this.selectcatid = selectcatid;
}
public ArrayList getCatList() {
	return catList;
}
public void setCatList(ArrayList catList) {
	this.catList = catList;
}
public ArrayList getRbtList() {
	return rbtList;
}
public void setRbtList(ArrayList rbtList) {
	this.rbtList = rbtList;
}
public int getSize() {
	return size;
}
public void setSize(int size) {
	this.size = size;
}
public int getPageId() {
	return pageId;
}
public void setPageId(int pageId) {
	this.pageId = pageId;
}
public int getPageCount() {
	return pageCount;
}
public void setPageCount(int pageCount) {
	this.pageCount = pageCount;
}
public int getShow() {
	return show;
}
public void setShow(int show) {
	this.show = show;
}
public String getSearchTxt() {
	return searchTxt;
}
public void setSearchTxt(String searchTxt) {
	this.searchTxt = searchTxt;
}
public int getCatId() {
	return catId;
}
public void setCatId(int catId) {
	this.catId = catId;
}
public String getRbtId() {
	return rbtId;
}
public void setRbtId(String rbtId) {
	this.rbtId = rbtId;
}
public String getRbtName() {
	return rbtName;
}
public void setRbtName(String rbtName) {
	this.rbtName = rbtName;
}



	
}
