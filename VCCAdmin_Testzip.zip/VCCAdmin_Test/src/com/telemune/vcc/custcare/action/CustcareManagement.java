package com.telemune.vcc.custcare.action;

import com.google.gson.Gson;
import com.telemune.dbutilities.Connection;
import com.telemune.vcc.common.HistoryGenerator;
import com.telemune.vcc.common.SessionHistory;
import com.telemune.vcc.common.TSSJavaUtil;
import com.telemune.vcc.common.ValidateAction;
import com.telemune.vcc.custcare.CrbtUtility;
import com.telemune.vcc.custcare.RequestNewCrbt;
import com.telemune.vcc.custcare.SubscriberHandler;
import com.telemune.vcc.custcare.action.CustcareManagement;
import com.telemune.vcc.custcare.action.ProvisioningBean;
import com.telemune.vcc.custcare.action.ScopeBean;
import com.telemune.vcc.custcare.action.SubscriberHistoryManagementBean;
import com.telemune.vcc.model.HistoryDataBean;
import com.telemune.vcc.response.VccRuleEngineResponse;
import java.util.ArrayList;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;

public class CustcareManagement extends ValidateAction {
  Logger logger = Logger.getLogger(CustcareManagement.class);
  
  SubscriberHistoryManagementBean historyBean = null;
  
  ProvisioningBean provisioningBean = null;
  
  ArrayList<ProvisioningBean> planList = null;
  
  ArrayList<ProvisioningBean> actTrgList = null;
  
  VccRuleEngineResponse ruleEngineResponse = null;
  
  ArrayList<ProvisioningBean> planList1 = null;
  
  HistoryDataBean historyDataBean = null;
  
  HistoryGenerator historyGenerator = null;
  
  Connection con = null;
  
  public VccRuleEngineResponse getRuleEngineResponse() {
    return this.ruleEngineResponse;
  }
  
  public void setRuleEngineResponse(VccRuleEngineResponse ruleEngineResponse) {
    this.ruleEngineResponse = ruleEngineResponse;
  }
  
  ArrayList acttrg = new ArrayList();
  
  private String serviceType;
  
  private String serviceData;
  
  private String msisdn;
  
  private Boolean cbcmEnable;
  
  private String userSubType;
  
  String message;
  
  public ArrayList getActtrg() {
    return this.acttrg;
  }
  
  public void setActtrg(ArrayList acttrg) {
    this.acttrg = acttrg;
  }
  
  public ArrayList<ProvisioningBean> getActTrgList() {
    return this.actTrgList;
  }
  
  public void setActTrgList(ArrayList<ProvisioningBean> actTrgList) {
    this.actTrgList = actTrgList;
  }
  
  public ArrayList<ProvisioningBean> getPlanList() {
    return this.planList;
  }
  
  public void setPlanList(ArrayList<ProvisioningBean> planList) {
    this.planList = planList;
  }
  
  public ArrayList<ProvisioningBean> getPlanList1() {
    return this.planList1;
  }
  
  public void setPlanList1(ArrayList<ProvisioningBean> planList1) {
    this.planList1 = planList1;
  }
  
  public String getUserSubType() {
    return this.userSubType;
  }
  
  public void setUserSubType(String userSubType) {
    this.userSubType = userSubType;
  }
  
  public Boolean getCbcmEnable() {
    return this.cbcmEnable;
  }
  
  public void setCbcmEnable(Boolean cbcmEnable) {
    this.cbcmEnable = cbcmEnable;
  }
  
  public String getMsisdn() {
    return this.msisdn;
  }
  
  public void setMsisdn(String msisdn) {
    this.msisdn = msisdn;
  }
  
  public void setServiceData(String serviceData) {
    this.serviceData = serviceData;
  }
  
  public String getServiceType() {
    return this.serviceType;
  }
  
  public String getServiceData() {
    return this.serviceData;
  }
  
  public void setServiceType(String serviceType) {
    this.serviceType = serviceType;
  }
  
  public ProvisioningBean getProvisioningBean() {
    return this.provisioningBean;
  }
  
  public void setProvisioningBean(ProvisioningBean provisioningBean) {
    this.provisioningBean = provisioningBean;
  }
  
  public SubscriberHistoryManagementBean getHistoryBean() {
    return this.historyBean;
  }
  
  public void setHistoryBean(SubscriberHistoryManagementBean historyBean) {
    this.historyBean = historyBean;
  }
  
  public String getMessage() {
    return this.message;
  }
  
  public void setMessage(String message) {
    this.message = message;
  }
  
  public CustcareManagement() {
    setLinkName("custcare");
  }
  
  public String manage() {
    SubscriberHandler subscriberhandler = null;
    subscriberhandler = new SubscriberHandler();
    ServletActionContext.getContext().getApplication().put("cbcmEnable", TSSJavaUtil.instance().getKeyValue("CBCM_ENABLE"));
    this.provisioningBean.setServiceMap(subscriberhandler.getServices());
    return "success";
  }
  
  public String getService() {
    this.logger.info("inside getservice Data" + this.msisdn);
    this.provisioningBean = new ProvisioningBean();
    SubscriberHandler subscriberHandler = new SubscriberHandler();
    this.planList1 = new ArrayList<ProvisioningBean>();
    this.planList = new ArrayList<ProvisioningBean>();
    this.actTrgList = new ArrayList<ProvisioningBean>();
    String subType = "";
    if (this.serviceType.equalsIgnoreCase("Voice Mail")) {
      String json = subscriberHandler.getSubTypeJsonObject(this.msisdn, 
          this.serviceType);
      this.ruleEngineResponse = subscriberHandler
        .requestToRuleEngine(json);
      subType = this.ruleEngineResponse.getSubType();
      this.logger.info("Subtype from RuleEngine [" + subType + "]");
      try {
        this.provisioningBean.setUserType(subType);
      } catch (Exception e) {
        e.printStackTrace();
      } 
    } else if (this.serviceType.equalsIgnoreCase("Voice Mail") && 
      !this.userSubType.equalsIgnoreCase("-1")) {
      this.logger.info("Setting User selected SubType [" + this.userSubType + "]");
      subType = this.userSubType;
    } 
    subscriberHandler.getRatePlan(this.serviceType, this.planList1);
    ProvisioningBean bean = null;
    if (this.planList1.size() != 0)
      for (int i = 0; i < this.planList1.size(); i++) {
        bean = this.planList1.get(i);
        if (this.serviceType.equalsIgnoreCase("Voice Mail")) {
          ScopeBean scope = (ScopeBean)(new Gson()).fromJson(bean.getScope(), 
              ScopeBean.class);
          if (subType.equalsIgnoreCase(scope.getST())) {
            this.planList.add(bean);
          } else if (subType.equalsIgnoreCase("N")) {
            bean.setPlanId("basic");
            bean.setPlanName("basic");
            this.planList.add(bean);
            break;
          } 
        } else if (this.serviceType.equalsIgnoreCase("Voice Note")) {
          this.planList.add(bean);
        } else if (this.serviceType.equalsIgnoreCase("MCA")) {
          this.planList.add(bean);
        } 
      }  
    if (this.serviceType.equalsIgnoreCase("Voice Mail") && 
      TSSJavaUtil.instance()
      .getKeyValue("VM_ACTIVETRIGGER_ENABLE")
      .equalsIgnoreCase("1")) {
      subscriberHandler.getActiveTrigger(this.serviceType, this.actTrgList);
    } else if (this.serviceType.equalsIgnoreCase("Voice Note") && 
      TSSJavaUtil.instance()
      .getKeyValue("VN_ACTIVETRIGGER_ENABLE")
      .equalsIgnoreCase("1")) {
      subscriberHandler.getActiveTrigger(this.serviceType, this.actTrgList);
    } else if (this.serviceType.equalsIgnoreCase("MCA") && 
      TSSJavaUtil.instance()
      .getKeyValue("MCA_ACTIVETRIGGER_ENABLE")
      .equalsIgnoreCase("1")) {
      subscriberHandler.getActiveTrigger(this.serviceType, this.actTrgList);
    } 
    return "success";
  }
  
  public String handleManage() {
    HttpServletRequest request = ServletActionContext.getRequest();
    HttpSession session = request.getSession();
    String user = ((SessionHistory)session.getAttribute("sessionHistory"))
      .getUser();
    String roleName1 = ((SessionHistory)session
      .getAttribute("sessionHistory")).getRoleName();
    this.con = TSSJavaUtil.instance().getconnection();
    if (this.provisioningBean.getId() == 1) {
      this.logger.info("Inside handling subscription request. MSISDN [" + 
          this.provisioningBean.getMsisdn() + "] SubType[" + 
          this.provisioningBean.getSubType() + "] CBCMEnable[" + 
          this.provisioningBean.getCbcmEnable() + 
          "] NotificationEnable [" + 
          this.provisioningBean.getNotification() + "] lang[" + 
          this.provisioningBean.getLang() + "] Service [" + 
          this.provisioningBean.getServiceType() + "] PlanName [" + 
          this.provisioningBean.getPlanName() + "] ");
      if ((this.provisioningBean.getMsisdn() != null || this.provisioningBean
        .getMsisdn().equalsIgnoreCase("")) && (
        this.provisioningBean.getServiceType() != null || this.provisioningBean
        .getServiceType().equalsIgnoreCase("")) && (
        this.provisioningBean.getPlanName() != null || this.provisioningBean
        .getPlanName().equalsIgnoreCase(""))) {
        if (!this.acttrg.isEmpty()) {
          this.provisioningBean.setActiveTrigger((String)this.acttrg.get(0));
        } else {
          this.provisioningBean.setActiveTrigger("0");
        } 
        String roleId = ((SessionHistory)session
          .getAttribute("sessionHistory")).getUser();
        if (this.provisioningBean.getCbcmEnable().booleanValue()) {
          this.provisioningBean.setRoleId(String.valueOf(user) + "/CBCM");
        } else if (!this.provisioningBean.getCbcmEnable().booleanValue()) {
          this.provisioningBean.setRoleId(String.valueOf(user) + "/WCBCM");
        } 
        SubscriberHandler subscriberHandler = new SubscriberHandler();
        String json = subscriberHandler
          .getSubJsonObject(this.provisioningBean);
        this.ruleEngineResponse = subscriberHandler
          .requestToRuleEngine(json);
        this.provisioningBean.setResult(this.ruleEngineResponse.getResult());
        if (this.ruleEngineResponse.getMsg() == null || 
          this.ruleEngineResponse.getMsg().equalsIgnoreCase("")) {
          this.provisioningBean
            .setMessage(this.ruleEngineResponse.getMessage());
        } else {
          this.provisioningBean.setMessage(this.ruleEngineResponse.getMsg());
        } 
        try {
          this.historyDataBean = new HistoryDataBean();
          this.historyDataBean.setUser(user);
          this.historyDataBean.setAction(getText("subscribeservice"));
          this.historyDataBean.setEvent("Add");
          this.historyDataBean.setRole(roleName1);
          this.historyDataBean.setMsg("User Subscribe [" + 
              this.provisioningBean.getMsisdn() + "] Status [" + 
              this.provisioningBean.getResult() + "]");
          this.historyGenerator = new HistoryGenerator();
          this.historyGenerator.insertHistoryData(this.historyDataBean, this.con);
        } catch (Exception e) {
          this.logger.error("Exception in inserting history data", e);
        } finally {
          if (this.con != null)
            TSSJavaUtil.instance().freeConnection(this.con); 
        } 
      } 
    } 
    if (this.provisioningBean.getId() == 2) {
      this.logger.info("Inside handling Unsubscription Request MSISDN [" + 
          this.provisioningBean.getMsisdn() + "] SubType[" + 
          this.provisioningBean.getSubType() + "] CBCMEnable[" + 
          this.provisioningBean.getCbcmEnable() + 
          "] NotificationEnable [" + 
          this.provisioningBean.getNotification() + "] lang[" + 
          this.provisioningBean.getLang() + "] Service [" + 
          this.provisioningBean.getServiceType() + "]");
      SubscriberHandler subscriberHandler = new SubscriberHandler();
      String roleId = ((SessionHistory)session
        .getAttribute("sessionHistory")).getUser();
      if (this.provisioningBean.getCbcmEnable().booleanValue()) {
        this.provisioningBean.setRoleId(String.valueOf(roleId) + "/CBCM");
      } else if (!this.provisioningBean.getCbcmEnable().booleanValue()) {
        this.provisioningBean.setRoleId(String.valueOf(roleId) + "/WCBCM");
      } 
      String json = subscriberHandler
        .getUnSubJsonObject(this.provisioningBean);
      this.ruleEngineResponse = subscriberHandler
        .requestToRuleEngine(json);
      this.provisioningBean.setResult(this.ruleEngineResponse.getResult());
      this.provisioningBean.setMessage(this.ruleEngineResponse.getMsg());
      try {
        this.historyDataBean = new HistoryDataBean();
        this.historyDataBean.setUser(user);
        this.historyDataBean.setAction(getText("unsubscribeservice"));
        this.historyDataBean.setEvent("Delete");
        this.historyDataBean.setRole(roleName1);
        this.historyDataBean.setMsg("User Unsubscribe [" + 
            this.provisioningBean.getMsisdn() + "] Status [" + 
            this.provisioningBean.getResult() + "]");
        this.historyGenerator = new HistoryGenerator();
        this.historyGenerator.insertHistoryData(this.historyDataBean, this.con);
      } catch (Exception e) {
        this.logger.error("Exception in inserting history data", e);
      } finally {
        if (this.con != null)
          TSSJavaUtil.instance().freeConnection(this.con); 
      } 
    } 
    return "success";
  }
  
  public String regenratePass(String msisdn, Connection con) {
    this.logger.info("Inside function regenratePass()... ");
    CrbtUtility crbtutil = new CrbtUtility();
    String retVal = "";
    try {
      int st = crbtutil.regeneratePass(msisdn, con);
      if (st == 1) {
        retVal = String.valueOf(getText("cusalrepas1")) + " " + msisdn + 
          getText("cusalrepas2");
      } else if (st == -1) {
        retVal = String.valueOf(msisdn) + " " + getText("cusalrepas3");
      } else if (st == -2) {
        retVal = String.valueOf(msisdn) + " " + getText("cusalerthis1");
      } else {
        retVal = getText("alertunknown");
      } 
      this.logger.info("This is the resultant String [" + retVal + "]");
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      crbtutil = null;
    } 
    return retVal;
  }
  
  public String handleActivate(String msisdn, int id) {
    this.logger.info("Inside function handleActivate()........");
    CrbtUtility crbtutil = new CrbtUtility();
    String retVal = "";
    int st = 0;
    try {
      if (id == 5) {
        st = crbtutil.actSubscriber_HLR(msisdn);
      } else if (id == 4) {
        st = crbtutil.actSubscriber_HLR(msisdn);
      } 
      if (st == 1) {
        retVal = String.valueOf(getText("cusmanage" + id)) + "of " + 
          getText("cusalert1");
      } else if (st == -2) {
        retVal = String.valueOf(msisdn) + " " + getText("cusalert2");
      } else if (st == -3) {
        retVal = getText("cusalert3");
      } else {
        retVal = getText("alertunknown");
      } 
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      crbtutil = null;
    } 
    return retVal;
  }
  
  public String handleRequestNewCrbt() {
    String msisdn = this.historyBean.getMsisdn();
    msisdn = TSSJavaUtil.instance().getInternationalNumber(msisdn);
    String rbtName = this.historyBean.getRbtName();
    String artistName = this.historyBean.getArtistName();
    String albName = this.historyBean.getAlbName();
    this.actionName = "reqnewfwd.action?linkName=custcare";
    this.logger.info("Inside function handleRequestNewCrbt().... where MSISDN [" + 
        msisdn + "] RBTNAME [" + rbtName + "] ARTIST NAME [" + 
        artistName + "] ALBUM NAME [" + albName + "]");
    String retVal = "success";
    RequestNewCrbt reqRbt = new RequestNewCrbt();
    Connection con = null;
    try {
      con = TSSJavaUtil.instance().getconnection();
      int i = reqRbt
        .addRequest(msisdn, rbtName, artistName, albName, con);
      if (con != null)
        TSSJavaUtil.instance().freeConnection(con); 
      this.logger.info("This is return Value from addRequest()..." + i);
      if (i == 1) {
        setMessage(getText("cusaddrbt"));
      } else {
        setMessage(getText("alertunknown"));
      } 
    } catch (Exception exe) {
      this.logger.info("Exception inside handleRequestNewCrbt()..", exe);
      exe.printStackTrace();
      retVal = "failure";
    } finally {
      reqRbt = null;
      if (con != null)
        TSSJavaUtil.instance().freeConnection(con); 
    } 
    return retVal;
  }
  
  public String getRequestedRbtData() {
    int id = this.historyBean.getId();
    String retVal = "success";
    RequestNewCrbt reqMan = new RequestNewCrbt();
    ArrayList reqAl = new ArrayList();
    Connection con = null;
    try {
      con = TSSJavaUtil.instance().getconnection();
      if (id == 1) {
        String msisdn = this.historyBean.getMsisdn();
        msisdn = TSSJavaUtil.instance().getInternationalNumber(msisdn);
        this.logger.info("Inside function getRequestedRbtData() where id [" + 
            id + "] msisdn [" + msisdn + "]");
        int val = reqMan.viewRequest(msisdn, reqAl, con);
        if (val < 0)
          setMessage(getText("tryLater")); 
      } else {
        this.logger.info("Inside function getRequestedRbtData() where id [" + 
            id + "] msisdn [All]");
        int val = reqMan.viewRequest(reqAl, con);
        if (val < 0)
          setMessage(getText("tryLater")); 
      } 
      if (con != null)
        TSSJavaUtil.instance().freeConnection(con); 
      int size = reqAl.size();
      this.historyBean.setDataAl(reqAl);
      this.historyBean.setSize(size);
    } catch (Exception e) {
      this.logger.error("Exception in getRequestedRbtData()...", e);
      retVal = "failure";
    } finally {
      reqAl = null;
      reqMan = null;
      if (con != null)
        TSSJavaUtil.instance().freeConnection(con); 
    } 
    return retVal;
  }
  
  public String handleRequestNameTune() {
    String msisdn = this.historyBean.getMsisdn();
    msisdn = TSSJavaUtil.instance().getInternationalNumber(msisdn);
    String rbtName = this.historyBean.getRbtName();
    this.actionName = "reqnametunefwd.action?linkName=custcare";
    this.logger.info("Inside function handleRequestNameTune().... where MSISDN [" + 
        msisdn + "] RBTNAME [" + rbtName + "]");
    String retVal = "success";
    RequestNewCrbt reqRbt = new RequestNewCrbt();
    try {
      int i = reqRbt.addNameTuneRequest(msisdn, rbtName);
      this.logger.info("This is return Value from addNameTuneRequest()..." + i);
      if (i == 1) {
        setMessage(getText("cusaddnametune"));
      } else {
        setMessage(getText("alertunknown"));
      } 
    } catch (Exception exe) {
      this.logger.info("Exception inside handleRequestNameTune()..", exe);
      exe.printStackTrace();
      retVal = "failure";
    } 
    return retVal;
  }
}
