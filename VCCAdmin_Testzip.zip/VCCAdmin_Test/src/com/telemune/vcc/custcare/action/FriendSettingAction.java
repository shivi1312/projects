package com.telemune.vcc.custcare.action;
import java.util.ArrayList;
import org.apache.log4j.Logger;
import com.telemune.dbutilities.Connection;
import com.telemune.vcc.common.*;
import com.telemune.vcc.custcare.CallCenterManagerBean;
import com.telemune.vcc.custcare.SubscriberFriend;

public class FriendSettingAction extends ValidateAction{
static Logger logger=Logger.getLogger(FriendSettingAction.class);
	
	private String msisdn;
	private String subType;
	
	
	{
		setLinkName("custcare");
	}
	
public String getSubType() {
		return subType;
	}

	public void setSubType(String subType) {
		this.subType = subType;
	}

public String getMsisdn() {
		return msisdn;
	}

	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
private String message;
	

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	private FriendSettingBean friendBean=null;
	
	public FriendSettingBean getFriendBean() {
		return friendBean;
	}

	public void setFriendBean(FriendSettingBean friendBean) {
		this.friendBean = friendBean;
	}

	
	
	public String addFriendSetting()
	{
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
			}else{
			//String msisdn=subscriberProfile.getMsisdn();
				
				
		String msisdn=this.getMsisdn();
		SubscriberProfile subscriberProfile= (SubscriberProfile)sessionMap.get(msisdn);
		
		String user=(String)sessionMap.get("user");
		
		logger.info("inside function addFriendSetting().. where MSISDN [ "+msisdn+" ] and SUB TYPE [ "+getSubType()+" ]");
		String friendMsisdn[]=friendBean.getFriendMsisdn();
		String friendNick[]=friendBean.getFriendNick();
		 ArrayList Friends = new ArrayList();
	     ArrayList FriendsNick = new ArrayList();
	     Connection con=null;
	     
	     CallCenterManagerBean callCenterManager = new CallCenterManagerBean();
	     
	     callCenterManager.setUser(user);
	     callCenterManager.setSubscriberProfile(getSubType());
	     
		logger.info("the size of friend's msisdn array is "+friendMsisdn.length);
		for(int i=0;i<friendMsisdn.length;i++)
		{
			if(!friendMsisdn[i].equals(""))
			{
			Friends.add(friendMsisdn[i]);
			FriendsNick.add(friendNick[i]);
			}
		}
		this.setMsisdn(msisdn);
		try{
			con=TSSJavaUtil.instance().getconnection();
			int i = callCenterManager.addNewFriend(msisdn,Friends, FriendsNick,con);
			if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
			if(i==-3)
			{
				this.setMessage(getText("alExist"));//this.setMessage("Friends Already Exist");
				actionName="goBack";
			}else if(i==1)
			{
				this.setMessage(getText("addSuccess"));//this.setMessage("Friends Added successfully");
				actionName="modifyManageFrn.action?msisdn="+msisdn+"&subType="+getSubType();
			}else
			{
				this.setMessage(getText("unknownError"));//this.setMessage("unknown Error");
				actionName="goBack";
			}
		
			
		}catch(Exception exe)
		{
			exe.printStackTrace();
			return "failure";
			
		}finally{
			 friendMsisdn=null;
			 friendNick=null;
			 Friends = null;
		     FriendsNick = null;
		     callCenterManager = null;
		     subscriberProfile=null;
		     
				if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
		}
		
		return SUCCESS;
			}
	}

	
	
// this function for getting the list for friend	
	public String getFriendList()
	{
		
		logger.info("inside function getFriendList()...................subType=["+subType+"]");
		System.out.println("inside function getFriendList()...................subType=["+subType+"]");
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
			}else{
		
		friendBean= new FriendSettingBean();
		SubscriberProfile subProfile=null;
		CallCenterManagerBean callCenterManager = null;
		ArrayList  subscriberFriend = null;
        ArrayList dataList= null;
        FriendSettingBean bean=null;
    	SubscriberFriend sf=null;
		
		Connection con= null;
		String user="";
		msisdn=this.getMsisdn();
		if(sessionMap.isEmpty()||sessionMap==null)
		{
			logger.info("you sessionis expired");
			return "logout";
			
		}
		if(sessionMap.containsKey(msisdn))
		{
			
			subProfile=(SubscriberProfile)sessionMap.get(msisdn);
			user=(String)sessionMap.get("user");
			 msisdn=TSSJavaUtil.instance().getInternationalNumber(msisdn);
		}else
		{
			logger.info("Subscriberprofile attribute is not set in session");
			
		}
		
		callCenterManager = new CallCenterManagerBean();
        callCenterManager.setUser(user);
		this.setMsisdn(msisdn);
		System.out.println("subtype==="+subType);
		this.setSubType(subType);
		System.out.println("subtype by getter -->  "+getSubType());
		    try{
	        	con=TSSJavaUtil.instance().getconnection();
	        subscriberFriend = callCenterManager.getFriendsList(msisdn,con);
	        if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
	        String Nick;
	        dataList= new ArrayList();
	        for(int i=0;i<subscriberFriend.size();i++)
	        {
	        	bean= new FriendSettingBean();
	        	sf=(SubscriberFriend)subscriberFriend.get(i);
	        	bean.setFrnMsisdn(sf.getFriendsMsisdn());
	        	  Nick = sf.getFriendsNick();
                if (Nick.equals(sf.getFriendsMsisdn()) || Nick == null  || Nick.equals("null"))
                {
                Nick="";
                bean.setModifyNick(Nick);
                }else
                {
                	bean.setModifyNick(Nick);	
                }
                
               bean.setFrnNick(Nick); 
               dataList.add(bean);
	        }
	        
	        friendBean.setDataList(dataList);
	        friendBean.setSize(dataList.size());
	        friendBean.setSubType(subType);
	        System.out.println("friendBean subtype==  "+friendBean.getSubType());
	        }catch(Exception exe)
	        {
	        	exe.printStackTrace();
	        	return "failure";
	        }finally{
	        	subProfile=null;
	    		callCenterManager = null;
	    		subscriberFriend = null;
	            dataList= null;
	            bean=null;
	        	sf=null;
	      		if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
			}

		return SUCCESS;
			}
	}
	
	
	
// this function is for delete the friend information from database
	public String deleteFriend()
	{
		logger.info("inside in function deletefriend()............");
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
			}else{
		
		SubscriberProfile subProfile=null;
		String friendMsisdns[]=null;
		CallCenterManagerBean callCenterManager = null;
		Connection con= null;
		String msisdn="";
		String user="";
		String subType=getSubType();
		msisdn=this.getMsisdn();
		if(sessionMap.isEmpty()||sessionMap==null)
		{
			logger.info("you sessionis expired");
			return "logout";
			
		}
		if(sessionMap.containsKey(msisdn))
		{
			subProfile=(SubscriberProfile)sessionMap.get(msisdn);
			user=(String)sessionMap.get("user");
			 msisdn=TSSJavaUtil.instance().getInternationalNumber(msisdn);
		}else
		{
			logger.info("Subscriberprofile attribute is not set in session");
			
		}
		
		friendMsisdns =friendBean.getDeleteAl();
		 this.setMsisdn(msisdn);
		 
		 
		 
		 callCenterManager = new CallCenterManagerBean();
		 callCenterManager.setUser(user);

         //String friendMsisdns[] = (String [])request.getParameterValues("msisdns");

         callCenterManager.setSubscriberProfile(subType);
         

        try{
        	con=TSSJavaUtil.instance().getconnection();
        	int i = callCenterManager.deleteFriends(msisdn, friendMsisdns,con);
        
        if(i==1)
        {
        	this.setMessage(getText("delSuccess"));
        	actionName="modifyManageFrn.action?msisdn="+msisdn+"&subType="+getSubType();
        	
        }else
        {
        	this.setMessage(getText("tryLater"));
        	actionName="goBack";
        }
        }catch(Exception exe)
        {
        	exe.printStackTrace();
        	logger.info(exe);
        	return "failure";
        }finally{
        	 subProfile=null;
     		friendMsisdns=null;
     		callCenterManager = null;
      		if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
		}
		return SUCCESS;
			}
	}
	
	
	//this function  is for getdetails for  modify 
	
	public String getDetails()
	{
		logger.info("inside function getDetails().................");
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
			}else{
				SubscriberProfile subProfile=null;
		try{
		
		subType=getSubType();
		String msisdn="";
		msisdn=getMsisdn();
		if(sessionMap.isEmpty()||sessionMap==null)
		{
			logger.info("you sessionis expired");
			return "logout";
			
		}
		if(sessionMap.containsKey(msisdn))
		{
			subProfile=(SubscriberProfile)sessionMap.get(msisdn);
			
		}else
		{
			logger.info("Subscriberprofile attribute is not set in session");
			
		}
		this.setMsisdn(msisdn);
		String frnMsisdn=friendBean.getFrnMsisdn();
		String frnNick= friendBean.getFrnNick();
		friendBean.setFrnMsisdn(frnMsisdn);
		friendBean.setFrnNick(frnNick);
		friendBean.setSubType(subType);
		return SUCCESS;
			}
		catch (Exception e) {
				e.printStackTrace();
				logger.error(e);
				return "error";
		}
		finally
		{
			subProfile=null;
		}
			}
	}
	
	
// this function is for the friend modification
	
	public String modifyFriend()
	{
		logger.info("inside function modifyFriend()..............");
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
			}else{
		
		SubscriberProfile subProfile=null;
		CallCenterManagerBean callCenterManager = null;
		
		Connection con= null;
		String msisdn="";
		msisdn=this.getMsisdn();
		String user="";
		if(sessionMap.isEmpty()||sessionMap==null)
		{
			logger.info("you sessionis expired");
			return "logout";
			
		}
		if(sessionMap.containsKey(msisdn))
		{
			subProfile=(SubscriberProfile)sessionMap.get(msisdn);
			msisdn=TSSJavaUtil.instance().getInternationalNumber(msisdn);
			user=(String)sessionMap.get("user");
		}else
		{
			logger.info("Subscriberprofile attribute is not set in session");
			
		}
		//SubscriberProfileManagerBean subProfileManager = new SubscriberProfileManagerBean();
		this.setMsisdn(msisdn);
		
		
		
		 callCenterManager = new CallCenterManagerBean();
	        //callCenterManager.setConnectionPool(conPool);
	        //callCenterManager.setSessionHistory(sessionHistory);
		 callCenterManager.setUser(user);
		 
		 String friendMsisdn = friendBean.getFrnMsisdn();
	        String nick=friendBean.getFrnNick();
	        

	        callCenterManager.setSubscriberProfile(getSubType());

	        
	        if(nick.equals("") || nick.equals("null") || nick.equals(null) || nick.equals("Not Given") )
	                nick="";

        if(nick.equals("") || nick.equals(null))
                nick="";
        try{
        	con=TSSJavaUtil.instance().getconnection();
        	int i = callCenterManager.modifyFriend(msisdn, friendMsisdn,nick,con);
        
        if(i==1)
        {
        	this.setMessage(getText("modSuccess"));
        	actionName="modifyManageFrn.action?msisdn="+msisdn+"&subType="+getSubType();
        }else if(i==-1)
        {
        	this.setMessage(getText("someError"));
        	actionName="goBack";
        }else
        {
        	this.setMessage(getText("tryLater"));
        	actionName="goBack";
        }
        
        }catch(Exception exe)
        {
        	exe.printStackTrace();
        	logger.info("exception in "+exe);
        	return "failure";
        }
        finally{
        	subProfile=null;
    		callCenterManager = null;
        		if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
		}

		
		return SUCCESS;
	}
	}
}
