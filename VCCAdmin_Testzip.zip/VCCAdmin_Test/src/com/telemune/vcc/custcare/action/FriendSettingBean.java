package com.telemune.vcc.custcare.action;

import java.util.ArrayList;

public class FriendSettingBean {
	private String[] friendMsisdn;
	private String[] friendNick;
	
	private String frnNick;
	private String frnMsisdn;
	private ArrayList dataList= new ArrayList();
	private String[] deleteAl;
	private int size;
	private String modifyNick;
	private String subType;
	
	
	
	
	public String getSubType() {
		return subType;
	}
	public void setSubType(String subType) {
		this.subType = subType;
	}
	public String getModifyNick() {
		return modifyNick;
	}
	public void setModifyNick(String modifyNick) {
		this.modifyNick = modifyNick;
	}
	public String getFrnNick() {
		return frnNick;
	}
	public void setFrnNick(String frnNick) {
		this.frnNick = frnNick;
	}
	public String getFrnMsisdn() {
		return frnMsisdn;
	}
	public void setFrnMsisdn(String frnMsisdn) {
		this.frnMsisdn = frnMsisdn;
	}
	public ArrayList getDataList() {
		return dataList;
	}
	public void setDataList(ArrayList dataList) {
		this.dataList = dataList;
	}
	public String[] getDeleteAl() {
		return deleteAl;
	}
	public void setDeleteAl(String[] deleteAl) {
		this.deleteAl = deleteAl;
	}
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	public String[] getFriendMsisdn() {
		return friendMsisdn;
	}
	public void setFriendMsisdn(String[] friendMsisdn) {
		this.friendMsisdn = friendMsisdn;
	}
	public String[] getFriendNick() {
		return friendNick;
	}
	public void setFriendNick(String[] friendNick) {
		this.friendNick = friendNick;
	}
	

}
