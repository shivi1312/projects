package com.telemune.vcc.custcare.action;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;
import com.telemune.dbutilities.Connection;
import com.telemune.vcc.common.*;
import com.telemune.vcc.custcare.CallCenterManagerBean;
import com.telemune.vcc.custcare.SubscriberGroup;

public class GroupSettingAction extends ValidateAction {
	static Logger logger= Logger.getLogger(GroupSettingAction.class);
	private GroupSettingBean groupBean=null;
	private long groupId;
	private String msisdn;
	private String subType;
	
	
	public GroupSettingAction()
	{
		setLinkName("custcare");
	}
	
	public String getSubType() {
		return subType;
	}
	public void setSubType(String subType) {
		this.subType = subType;
	}
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	public long getGroupId() {
		return groupId;
	}
	public void setGroupId(long groupId) {
		this.groupId = groupId;
	}
	public GroupSettingBean getGroupBean() {
		return groupBean;
	}
	public void setGroupBean(GroupSettingBean groupBean) {
		this.groupBean = groupBean;
	}
	private String message;
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}

	
	// this function is for adding the new group
	public String addNewGroup()
	{
		logger.info("inside of function addNewGroup().....");
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
			}else{
		
		String groupName="";
		String groupMember="";
		String msisdn="";
		String sub_type="";
		String query="";
		String user="";
		msisdn=this.getMsisdn();
		if(groupBean!=null)
		{
			groupName=groupBean.getGroupName();
			groupName=groupName.toUpperCase();
			groupMember=groupBean.getGroupMember();
		}
		Connection con=null;
		SubscriberProfile subProfile=null;
		if(sessionMap.containsKey(msisdn))
		{
			subProfile=(SubscriberProfile)sessionMap.get(msisdn);
			user=(String)sessionMap.get("user");
			 msisdn=TSSJavaUtil.instance().getInternationalNumber(msisdn);
		}else
		{
			logger.info("Subscriberprofile attribute is not set in session");
			
		}
		logger.info("group name ["+groupName+"] group Member ["+groupMember+"] msisdn ["+msisdn+"] sub_type ["+sub_type+"] connection ["+con+"]");

		
		CallCenterManagerBean callCenterManager = new CallCenterManagerBean();
        //callCenterManager.setConnectionPool(conPool);
        //callCenterManager.setSessionHistory(sessionHistory);
			callCenterManager.setUser(user);

        callCenterManager.setSubscriberProfile(getSubType());


		StringTokenizer st = new StringTokenizer(groupMember);
        ArrayList<String> Friends = new ArrayList<String>();
        while(st.hasMoreTokens())
        {
                Friends.add(st.nextToken());
        }
        
        this.setMsisdn(msisdn);
        
        try{
        	
        	con=TSSJavaUtil.instance().getconnection();
        	
            int i = callCenterManager.addSubscriberGroup(groupName,msisdn,Friends,con);
        	 if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
        	if(i==-5)
        	{
        		this.setMessage(getText("alExist"));
        		actionName="goBack";
        	}else if(i==1)
        	{
        		this.setMessage(getText("addSuccess"));
        		actionName="modifyManageGrp.action?msisdn="+msisdn+"&subType="+getSubType();
        	}else
        	{
        		this.setMessage(getText("unknownError"));
        		actionName="goBack";
        	}
        }catch(Exception exe)
        {
        	logger.error("Exception in addNewGroup()",exe);
        	exe.printStackTrace();
        	return "failure";
        }finally{
        	callCenterManager=null;
        	Friends=null;
        	st=null;
        	subProfile=null;
        	
        		if(con!=null)if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
        }
	return SUCCESS;
			}
	}
	
	
	// this is for the show the group details or for view
	public String viewGroups()
	{
		logger.info("inside function viewGroups()............");
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
			}else{
		
		groupBean= new GroupSettingBean();
		Connection con=null;
		SubscriberProfile subProfile=null;
		CallCenterManagerBean callCenterManager = null;
		ArrayList  subscriberGroups =null;
    	ArrayList dataAl= null;
    	ArrayList friend= null;
    	GroupSettingBean gpBean= null;
    	SubscriberGroup sg=null;
    	
		String msisdn="";
		msisdn=this.getMsisdn();
		if(sessionMap.isEmpty()||sessionMap==null)
		{
			logger.info("you sessionis expired");
			return "logout";
			
		}
		if(sessionMap.containsKey(msisdn))
		{
			subProfile=(SubscriberProfile)sessionMap.get(msisdn);
			
			msisdn=TSSJavaUtil.instance().getInternationalNumber(msisdn);
		}else
		{
			logger.info("Subscriberprofile attribute is not set in session");
			
		}
		this.setMsisdn(msisdn);
		
		 callCenterManager = new CallCenterManagerBean();
	        try{
	        	con=TSSJavaUtil.instance().getconnection();
	        	subscriberGroups = callCenterManager.getGroupsList(msisdn,con);
	        	if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
	        	dataAl= new ArrayList();
	        	friend= new ArrayList();
	        	String msisdnString="";
	        	logger.info("the size of arraylist is "+subscriberGroups.size());
	        	for(int i=0;i<subscriberGroups.size();i++)
	        	{
	        		gpBean= new GroupSettingBean();
	        		sg= (SubscriberGroup)subscriberGroups.get(i);
	        		gpBean.setGroupName(sg.getGroupName());
	        		gpBean.setGroupId(sg.getGroupId());
	        		friend=sg.getFriends();
	        		logger.info("this is the size of friend list"+friend.size());
	        		
	        		Iterator fnIte = friend.iterator();
	        		int count = 0;
                    while(fnIte.hasNext())
                    {
                            if(msisdnString.equals(""))
                            msisdnString = (String)fnIte.next();
                            else
                                    msisdnString += ", " + (String)fnIte.next();
                            count++;
                            if(count==3)
                                    msisdnString+="\n";
                    }
                    logger.info("this is the msisdn strinh"+msisdnString);
                    gpBean.setGroupMember(msisdnString);
                    msisdnString="";
                    dataAl.add(gpBean);
	        	}
	       groupBean.setDataList(dataAl); 
	       groupBean.setSize(dataAl.size());
	        }catch(Exception ex)
	        {
	        	logger.error("Exception. viewGroups() ...",ex);
	        	ex.printStackTrace();
	        	return "failure";
	        }finally
	        {
	        	subProfile=null;
	    		callCenterManager = null;
	    		subscriberGroups =null;
	        	dataAl= null;
	        	friend= null;
	        	gpBean= null;
	        	sg=null;
	        	
	        if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
	        }
		return SUCCESS;
			}
	}
	
	
	
	
// this function is for deleting the group 	
	public String deleteGroup()
	{
		logger.info("inside function deleteGroup()................");
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
			}else{
		
		Connection con=null;
		SubscriberProfile subProfile=null;
		CallCenterManagerBean callCenterManager = null;
		String groupIdArr[] =null;
		
		String msisdn="";
		msisdn=this.getMsisdn();
		String user="";
		if(sessionMap.isEmpty()||sessionMap==null)
		{
			logger.info("you sessionis expired");
			return "logout";
			
		}
		if(sessionMap.containsKey(msisdn))
		{
			subProfile=(SubscriberProfile)sessionMap.get(msisdn);
			user=(String)sessionMap.get("user");
			 msisdn=TSSJavaUtil.instance().getInternationalNumber(msisdn);
		}else
		{
			logger.info("Subscriberprofile attribute is not set in session");
			
		}
		this.setMsisdn(msisdn);
		
		
		
		callCenterManager = new CallCenterManagerBean();
        
        callCenterManager.setSubscriberProfile(getSubType());
        callCenterManager.setUser(user);
        
		
		
		try{
			
		con=TSSJavaUtil.instance().getconnection();
        
        groupIdArr =groupBean.getDeleteAl();
        
        
        int i = callCenterManager.deleteGroups(msisdn, groupIdArr,con);
        if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
        if(i==0)
        {
        	this.setMessage(getText("tryLater"));
        	actionName="goBack";
        }else if(i==1)
        {
        	this.setMessage(getText("delSuccess"));
        	actionName="modifyManageGrp.action?msisdn="+msisdn+"&subType="+getSubType();
        }else
        {
        	this.setMessage(getText("tryLater"));
        	actionName="goBack";
        }
       return "success"; 
       }catch(Exception exe)
		{
    	   logger.error("Exception in deleteGroup()...",exe);
			exe.printStackTrace();
			return "failure";
		}
		finally
        {
			subProfile=null;
			callCenterManager = null;
			 groupIdArr =null;
			
        		if(con!=null)if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
        }
			}
	}
	
	
	public String getDataForModify()
	{
		logger.info("inside function getDataForModify()..................");
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
			}else{
		
		Connection con=null;
		SubscriberProfile subProfile=null;
		CallCenterManagerBean callCenterManager = null;
		ArrayList  subscriberGroups =null;
		SubscriberGroup sg = null;
		ArrayList friends  = null;
		
		String msisdn="";
		msisdn=this.getMsisdn();
		String user="";
		if(sessionMap.isEmpty()||sessionMap==null)
		{
			logger.info("you sessionis expired");
			return "logout";
			
		}
		if(sessionMap.containsKey(msisdn))
		{
			subProfile=(SubscriberProfile)sessionMap.get(msisdn);
			 msisdn=TSSJavaUtil.instance().getInternationalNumber(msisdn);
			 user=(String)sessionMap.get("user");
		}else
		{
			logger.info("Subscriberprofile attribute is not set in session");
			
		}
		
		long groupId= groupBean.getGroupId();
		this.setMsisdn(msisdn);
		 callCenterManager = new CallCenterManagerBean();
	        callCenterManager.setSubscriberProfile(getSubType());
	        callCenterManager.setUser(user);
	        		
        try{
        	con=TSSJavaUtil.instance().getconnection();
        	subscriberGroups = callCenterManager.getGroupsList(msisdn,con);
        if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
        boolean daySet[]=null;

        Iterator ite = subscriberGroups.iterator();
        sg = new SubscriberGroup();
        while(ite.hasNext())
        {
                sg = (SubscriberGroup) ite.next();
                if(sg.getGroupId() == groupId)
                {
                        break;
                }
                else
                {
                       
                }
        }

        friends  = sg.getFriends();
        groupBean.setGroupId(groupId);
        groupBean.setGroupName(sg.getGroupName());
        groupBean.setSize(friends.size());
        groupBean.setDataList(friends);
        }catch(Exception exe)
        {
        	logger.error("Exception in getDataForModify().......",exe);
        	exe.printStackTrace();
        	return "failure";
        }finally
        	{
        	subProfile=null;
    		callCenterManager = null;
    		subscriberGroups =null;
    		sg = null;
    		friends  = null;
    		
        	if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
        }
		return SUCCESS;
			}
	}
	
	
	
// this function is for modify the group settings .......
	public String modifyGroup()
	{
		logger.info("inside function modifyGroup()..................");
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
			}else{
		
		Connection con=null;
		SubscriberProfile subProfile=null;
		String[] membersList=null;
		CallCenterManagerBean callCenterManager = null;
		StringTokenizer st = null;
        ArrayList Friends = null;

		
		
		String msisdn="";
		msisdn=this.getMsisdn();
		String user="";
		if(sessionMap.isEmpty()||sessionMap==null)
		{
			logger.info("you sessionis expired");
			return "logout";
			
		}
		if(sessionMap.containsKey(msisdn))
		{
			subProfile=(SubscriberProfile)sessionMap.get(msisdn);
			user=(String)sessionMap.get("user");
			 msisdn=TSSJavaUtil.instance().getInternationalNumber(msisdn);
		}else
		{
			logger.info("Subscriberprofile attribute is not set in session");
			
		}
		
		long groupId= groupBean.getGroupId();
		String groupName= groupBean.getGroupName();
		membersList=groupBean.getDeleteAl();
		String friends=groupBean.getGroupMember();
		
		this.setMsisdn(msisdn);
		    callCenterManager = new CallCenterManagerBean();
	        callCenterManager.setSubscriberProfile(getSubType());
	        callCenterManager.setUser(user);
        
        st = new StringTokenizer(friends);

        Friends = new ArrayList();
        while(st.hasMoreTokens())
        {
        String strTempFriend=st.nextToken();
                Friends.add(strTempFriend);
        }

        if (membersList != null)
        {
                for (int i=0; i<membersList.length; i++)
                {
                        if ((membersList[i] != null) && (membersList[i].length() > 7))
                        {
                                Friends.add(membersList[i]);
                        }
                }
        }

        try{
        	con=TSSJavaUtil.instance().getconnection();
        	int i = callCenterManager.modifySubscriberGroup(groupName, groupId, msisdn, Friends,con);

        logger.info("this is the return from modifysubscribergroup "+i);
        if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
        if(i==1)
        {
        	this.setMessage(getText("modSuccess"));
        	actionName="modifyManageGrp.action?msisdn="+msisdn+"&subType="+getSubType();
        }else
        {
        	this.setMessage(getText("tryLater"));
        	actionName="goBack";
        }
        
        
        
        
        }catch(Exception exe)
        {
        	logger.error("Exception in modifyGroup()...",exe);
        	exe.printStackTrace();
        	return "failure";
        }finally
        {
        	subProfile=null;
    		membersList=null;
    		callCenterManager = null;
    		st = null;
            Friends = null;

        if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
        }

		
		
		return SUCCESS;
	}
	
	
	}
	
}
