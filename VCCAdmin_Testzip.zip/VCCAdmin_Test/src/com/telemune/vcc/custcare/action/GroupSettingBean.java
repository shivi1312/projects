package com.telemune.vcc.custcare.action;

import java.util.ArrayList;

public class GroupSettingBean {
private String groupName;
private String groupMember;
private int size;
private ArrayList dataList;
private String[] deleteAl;
private long groupId;





public long getGroupId() {
	return groupId;
}
public void setGroupId(long groupId) {
	this.groupId = groupId;
}
public ArrayList getDataList() {
	return dataList;
}
public void setDataList(ArrayList dataList) {
	this.dataList = dataList;
}
public String[] getDeleteAl() {
	return deleteAl;
}
public void setDeleteAl(String[] deleteAl) {
	this.deleteAl = deleteAl;
}
public int getSize() {
	return size;
}
public void setSize(int size) {
	this.size = size;
}
public String getGroupName() {
	return groupName;
}
public void setGroupName(String groupName) {
	this.groupName = groupName;
}
public String getGroupMember() {
	return groupMember;
}
public void setGroupMember(String groupMember) {
	this.groupMember = groupMember;
}

}
