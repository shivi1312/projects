package com.telemune.vcc.custcare.action;

import com.telemune.dbutilities.Connection;
import com.telemune.vcc.common.TSSJavaUtil;
import com.telemune.vcc.common.ValidateAction;
import com.telemune.vcc.custcare.CrbtUtility;
import com.telemune.vcc.custcare.SmsHistoryBean;
import com.telemune.vcc.custcare.SubHistoryBean;
import com.telemune.vcc.custcare.action.DateStatusBean;
import com.telemune.vcc.custcare.action.HistoryManagement;
import com.telemune.vcc.custcare.action.SubscriberHistoryManagementBean;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.TimeZone;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.joda.time.Days;
import org.joda.time.ReadableInstant;

public class HistoryManagement extends ValidateAction {
  Logger logger = Logger.getLogger(HistoryManagement.class);
  
  String message;
  
  SubscriberHistoryManagementBean historyBean = null;
  
  public String getMessage() {
    return this.message;
  }
  
  public void setMessage(String message) {
    this.message = message;
  }
  
  public SubscriberHistoryManagementBean getHistoryBean() {
    return this.historyBean;
  }
  
  public void setHistoryBean(SubscriberHistoryManagementBean historyBean) {
    this.historyBean = historyBean;
  }
  
  public HistoryManagement() {
    setLinkName("custcare");
  }
  
  public String setHistoryInfo() {
    this.logger.info("Inside function setHistoryInfo().....");
    if (!checkSession().equalsIgnoreCase("success"))
      return "error"; 
    if (this.historyBean == null) {
      this.logger.info("inside condition when history bean is null");
      return "failure";
    } 
    int id = this.historyBean.getId();
    String sessionNumber = "";
    String text = "";
    text = getText("custitleHistory" + id);
    this.logger.info("id is" + id);
    switch (id) {
      case 1:
        sessionNumber = "500";
        break;
      case 2:
        sessionNumber = "530";
        break;
      case 3:
        sessionNumber = "540";
        break;
      case 4:
        sessionNumber = "550";
        break;
      case 5:
        sessionNumber = "830";
        break;
    } 
    this.logger.info("This is the id [" + id + "]  and  sessionnumber [" + 
        sessionNumber + "] and title [" + text + "]");
    this.historyBean.setId(id);
    this.historyBean.setSessionNumber(sessionNumber);
    this.historyBean.setTitle(text);
    return "success";
  }
  
  public String handleSmsHistoryManagement() {
    return "";
  }
  
  public String handleHistoryManagement() {
    if (!checkSession().equalsIgnoreCase("success"))
      return "error"; 
    if (this.historyBean == null) {
      System.out.println("return failure to handle exception");
      return "failure";
    } 
    String msisdn = this.historyBean.getMsisdn();
    String returnString = "failure";
    Connection con = null;
    String[] header = new String[0];
    ArrayList dataListAl = null;
    try {
      msisdn = TSSJavaUtil.instance().getInternationalNumber(msisdn);
      int id = this.historyBean.getId();
      String retVal = "";
      String title = this.historyBean.getTitle();
      this.logger.info("Inside function handleSubHistory() where MSISDN [" + 
          msisdn + "]  ID [" + id + "]");
      con = TSSJavaUtil.instance().getconnection();
      dataListAl = new ArrayList();
      int headerCount = 0;
      String head = "";
      head = getText("cusReportHeader" + id);
      this.logger.info("head from language file is = " + head);
      String[] paramsVal = head.split(",");
      headerCount = paramsVal.length;
      this.logger.info("Length of header [" + headerCount + "]");
      header = paramsVal;
      if (this.sessionMap.containsKey(this.historyBean.getSessionNumber())) {
        switch (id) {
          case 1:
            retVal = getHistoryReport(con, msisdn, dataListAl, 
                headerCount);
            returnString = "success";
            break;
          case 2:
            retVal = getMailBoxReport(con, msisdn, dataListAl, 
                headerCount, this.historyBean.getServiceType());
            returnString = "success";
            break;
          case 3:
            retVal = getRecordingHistory(con, msisdn, dataListAl, 
                headerCount, this.historyBean.getStart(), 
                this.historyBean.getEnd(), this.historyBean.getBasedOn());
            returnString = "success";
            break;
          case 4:
            retVal = getSmsHistory(con, msisdn, dataListAl, 
                headerCount, this.historyBean.getStart(), 
                this.historyBean.getEnd());
            returnString = "success";
            break;
        } 
      } else {
        this.logger.info("You are not authenticated to view this link");
        returnString = "error";
      } 
      int size = dataListAl.size();
      this.logger.info("This is the size of list [" + size + "]");
      if (con != null)
        TSSJavaUtil.instance().freeConnection(con); 
      setMessage(retVal);
      this.historyBean.setHeader(header);
      this.historyBean.setId(id);
      this.historyBean.setDataAl(dataListAl);
      this.historyBean.setMsisdn(msisdn);
      this.historyBean.setSize(size);
      this.historyBean.setTitle(title);
    } catch (Exception exe) {
      this.logger.info("Their is some exception in handleSubHistory() ", 
          exe);
      exe.printStackTrace();
      return "failure";
    } finally {
      header = null;
      dataListAl = null;
      try {
        if (con != null && 
          con != null)
          TSSJavaUtil.instance().freeConnection(con); 
      } catch (Exception exe) {
        exe.printStackTrace();
      } 
    } 
    return returnString;
  }
  
  public String getHistoryReport(Connection con, String msisdn, ArrayList<String[]> dataAl, int headCount) {
    if (!checkSession().equalsIgnoreCase("success"))
      return "error"; 
    if (this.historyBean == null) {
      System.out.println("return failure to handle exception");
      return "failure";
    } 
    dataAl.clear();
    this.logger.info("Inside function getHistoryReport()... where MSISDN [" + 
        msisdn + "]");
    String retVal = "";
    ArrayList historyAl = new ArrayList();
    CrbtUtility crbtutil = new CrbtUtility();
    SubHistoryBean subHistory = null;
    try {
      int st = crbtutil.searchHistory(msisdn, historyAl, con);
      this.logger.info("Return value is [" + st + "]");
      String type = "";
      if (st == 1 && historyAl.size() > 0) {
        this.logger.info("Inside block where data found into data base");
        retVal = "OK";
        Iterator<SubHistoryBean> ite = historyAl.iterator();
        while (ite.hasNext()) {
          String serviceType = "";
          String interfaceType = "";
          String[] data = new String[headCount];
          subHistory = new SubHistoryBean();
          subHistory = ite.next();
          if (subHistory.getServiceType()
            .equalsIgnoreCase(TSSJavaUtil.instance().getKeyValue("VM"))) {
            serviceType = "Voice Mail Service";
          } else if (subHistory.getServiceType()
            .equalsIgnoreCase(TSSJavaUtil.instance().getKeyValue("VN"))) {
            serviceType = "Voice Note Service";
          } else if (subHistory.getServiceType()
            .equalsIgnoreCase(TSSJavaUtil.instance().getKeyValue("MCA"))) {
            serviceType = "Missed Call Alert";
          } 
          if (subHistory.getType().equalsIgnoreCase("Sub") || 
            subHistory.getType().equalsIgnoreCase("S")) {
            type = "Subscribe";
          } else if (subHistory.getType().equalsIgnoreCase(
              "Unsub") || 
            subHistory.getType().equalsIgnoreCase("U")) {
            type = "UnSubscribe";
          } else if (subHistory.getType().equalsIgnoreCase("BTE")) {
            type = "Basic to Executive";
          } else if (subHistory.getType().equalsIgnoreCase("ETB")) {
            type = "Executive to Basic";
          } else if (subHistory.getType().equalsIgnoreCase("CN")) {
            type = "Change Number";
          } else if (subHistory.getType().equalsIgnoreCase("CP")) {
            type = "Change Password";
          } else if (subHistory.getType().equalsIgnoreCase("BU")) {
            type = "Unblock";
          } else if (subHistory.getType().equalsIgnoreCase("UB")) {
            type = "Block";
          } else if (subHistory.getType().equalsIgnoreCase("R")) {
            type = "Reset";
          } 
          if (subHistory.getInterfaceType().equalsIgnoreCase("I") || 
            subHistory.getInterfaceType()
            .equalsIgnoreCase("irt") || 
            subHistory.getInterfaceType()
            .equalsIgnoreCase("irc")) {
            interfaceType = "IVR";
          } else if (subHistory.getInterfaceType()
            .equalsIgnoreCase("S")) {
            interfaceType = "SMS";
          } else if (subHistory.getInterfaceType()
            .equalsIgnoreCase("C")) {
            interfaceType = "CustCare";
          } else if (subHistory.getInterfaceType()
            .equalsIgnoreCase("U")) {
            interfaceType = "USSD";
          } else if (subHistory.getInterfaceType()
            .equalsIgnoreCase("M")) {
            interfaceType = "MPBN";
          } else if (subHistory.getInterfaceType()
            .equalsIgnoreCase("W")) {
            interfaceType = "WEB User";
          } else if (subHistory.getInterfaceType()
            .equalsIgnoreCase("R")) {
            interfaceType = "Renew";
          } 
          data[0] = subHistory.getDate();
          data[1] = subHistory.getMsisdn();
          data[2] = interfaceType;
          data[3] = subHistory.getMailBoxType();
          data[4] = serviceType;
          data[5] = subHistory.getUpdatedBy();
          data[6] = type;
          this.logger.info("This is the data [" + data[0] + "] [" + 
              data[1] + "] [" + data[2] + "] [" + data[3] + 
              "] [" + data[4] + "]" + data[5] + "] [" + 
              data[6] + "]");
          dataAl.add(data);
        } 
      } else if (st == 1) {
        retVal = String.valueOf(getText("cusalerthis")) + " " + msisdn;
      } else {
        retVal = getText("alertunknown");
      } 
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      historyAl = null;
      crbtutil = null;
      subHistory = null;
    } 
    this.logger.info("This is the resultant String [" + retVal + "]");
    return retVal;
  }
  
  public String getMailBoxReport(Connection con, String msisdn, ArrayList<String[]> dataAl, int headCount, String serviceType) {
    if (!checkSession().equalsIgnoreCase("success"))
      return "error"; 
    if (this.historyBean == null) {
      System.out.println("return failure to handle exception");
      return "failure";
    } 
    dataAl.clear();
    this.logger.info("Inside function getMailBoxReport()... where MSISDN [" + 
        msisdn + "] Service Type [" + serviceType + "]");
    String retVal = "";
    ArrayList historyAl = new ArrayList();
    CrbtUtility crbtutil = new CrbtUtility();
    SubHistoryBean subHistory = null;
    try {
      int st = crbtutil.searchMailBoxRecord(msisdn, historyAl, con, 
          serviceType);
      this.logger.info("Return value is [" + st + "]");
      String status = "";
      if (st == 1 && historyAl.size() > 0) {
        this.logger.info("Inside block where data found into data base");
        retVal = "OK";
        Iterator<SubHistoryBean> ite = historyAl.iterator();
        int i = 0;
        while (ite.hasNext()) {
          String[] data = new String[headCount];
          subHistory = new SubHistoryBean();
          subHistory = ite.next();
          if (subHistory.getServiceType()
            .equalsIgnoreCase("0010")) {
            serviceType = "Voice Mail Service";
          } else if (subHistory.getServiceType()
            .equalsIgnoreCase("0100")) {
            serviceType = "Voice Note Service";
          } 
          if (subHistory.getStatus().equalsIgnoreCase("N")) {
            status = "NEW";
          } else if (subHistory.getStatus().equalsIgnoreCase("R")) {
            status = "READ";
          } else if (subHistory.getStatus().equalsIgnoreCase("S")) {
            status = "SAVE";
          } 
          data[0] = subHistory.getDate();
          data[1] = subHistory.getOriginNumber();
          data[2] = subHistory.getRecordingDuratn();
          data[3] = subHistory.getRetrvTime();
          data[4] = serviceType;
          data[5] = status;
          this.logger.info("This is the data [" + data[0] + "] [" + 
              data[1] + "] [" + data[2] + "] [" + data[3] + 
              "] [" + data[4] + "]" + data[5] + "]");
          dataAl.add(data);
        } 
      } else if (st == 1) {
        retVal = String.valueOf(getText("custRecordalrt")) + " " + msisdn;
      } else {
        retVal = getText("alertunknown");
      } 
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      historyAl = null;
      crbtutil = null;
      subHistory = null;
    } 
    this.logger.info("This is the resultant String [" + retVal + "]");
    return retVal;
  }
  
  public String getSmsHistory(Connection con, String msisdn, ArrayList<String[]> dataAl, int headCount, String start, String end) {
    if (!checkSession().equalsIgnoreCase("success"))
      return "error"; 
    if (this.historyBean == null) {
      System.out.println("return failure to handle exception");
      return "failure";
    } 
    dataAl.clear();
    this.logger.info("Inside function getSmsHistory()... where MSISDN [" + 
        msisdn + "] Date is [" + start + "] ");
    String retVal = "";
    ArrayList historyAl = new ArrayList();
    CrbtUtility crbtutil = new CrbtUtility();
    SimpleDateFormat yearFormat = null;
    SimpleDateFormat dayFormat = null;
    SmsHistoryBean smsHistory = null;
    try {
      yearFormat = new SimpleDateFormat("yyyy-MM-dd");
      if (start.indexOf("-") == 2) {
        dayFormat = new SimpleDateFormat("dd-MM-yyyy");
      } else if (start.indexOf("-") == 4) {
        dayFormat = new SimpleDateFormat("yyyy-MM-dd");
      } 
      Date startDate = dayFormat.parse(start);
      Date endDate = dayFormat.parse(end);
      int st = crbtutil.searchSmsHistory(msisdn, historyAl, con, 
          yearFormat.format(startDate), 
          yearFormat.format(endDate));
      this.logger.info("Return value is [" + st + "]");
      if (st == 1 && historyAl.size() > 0) {
        retVal = "OK";
        Iterator<SmsHistoryBean> ite = historyAl.iterator();
        int i = 0;
        while (ite.hasNext()) {
          String[] data = new String[headCount];
          smsHistory = new SmsHistoryBean();
          smsHistory = ite.next();
          data[0] = smsHistory.getDate();
          data[1] = smsHistory.getOriginationNumber();
          data[2] = smsHistory.getDestinationNumber();
          data[3] = smsHistory.getMessage();
          this.logger.info("This is the data [" + data[0] + "] [" + 
              data[1] + "] [" + data[2] + "] [" + data[3] + 
              "]");
          dataAl.add(data);
        } 
      } else if (st == 1) {
        retVal = String.valueOf(getText("custSmsHistoryalt")) + " " + msisdn;
      } else {
        retVal = getText("alertunknown");
      } 
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      historyAl = null;
      crbtutil = null;
      smsHistory = null;
    } 
    this.logger.info("This is the resultant String [" + retVal + "]");
    return retVal;
  }
  
  public String getRecordingHistory(Connection con, String msisdn, ArrayList<String[]> dataAl, int headCount, String start, String end, String basedOn) {
    if (!checkSession().equalsIgnoreCase("success"))
      return "error"; 
    if (this.historyBean == null) {
      System.out.println("return failure to handle exception");
      return "failure";
    } 
    dataAl.clear();
    this.logger.info("Inside function getRecordingHistory()... where MSISDN [" + 
        msisdn + 
        "] StartDate is [" + 
        start + 
        "] End Date is [" + 
        end + "] based on [" + basedOn + "]");
    String retVal = "";
    ArrayList historyAl = new ArrayList();
    CrbtUtility crbtutil = new CrbtUtility();
    SimpleDateFormat yearFormat = null;
    SimpleDateFormat dayFormat = null;
    SubHistoryBean subHistory = null;
    DateStatusBean dsBean = null;
    try {
      yearFormat = new SimpleDateFormat("yyyy-MM-dd");
      dsBean = processDates(start, end);
      int st = crbtutil.searchRecording(msisdn, historyAl, con, 
          basedOn, dsBean.getStatus(), 
          yearFormat.format(dsBean.getStartDate()), 
          yearFormat.format(dsBean.getEndDate()));
      this.logger.info("Return value is [" + st + "]");
      String serviceType = "";
      if (st == 1 && historyAl.size() > 0) {
        retVal = "OK";
        Iterator<SubHistoryBean> ite = historyAl.iterator();
        int i = 0;
        while (ite.hasNext()) {
          String[] data = new String[headCount];
          subHistory = new SubHistoryBean();
          subHistory = ite.next();
          if (subHistory.getServiceType()
            .equalsIgnoreCase("0010")) {
            serviceType = "Voice Mail Service";
          } else if (subHistory.getServiceType()
            .equalsIgnoreCase("0100")) {
            serviceType = "Voice Note Service";
          } 
          data[0] = subHistory.getDate();
          data[1] = subHistory.getOriginNumber();
          data[2] = subHistory.getMsisdn();
          data[3] = subHistory.getCallDuration();
          data[4] = subHistory.getMsgLength();
          data[5] = serviceType;
          data[6] = subHistory.getServerId();
          this.logger.info("This is the data [" + data[0] + "] [" + 
              data[1] + "] [" + data[2] + "] [" + data[3] + 
              "] [" + data[4] + "] [" + data[5] + "] [" + 
              data[6] + "]");
          dataAl.add(data);
        } 
      } else if (st == 1) {
        retVal = String.valueOf(getText("custRecordalrt")) + " " + msisdn;
      } else {
        retVal = getText("alertunknown");
      } 
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      historyAl = null;
      crbtutil = null;
      subHistory = null;
    } 
    this.logger.info("This is the resultant String [" + retVal + "]");
    return retVal;
  }
  
  public DateStatusBean processDates(String start, String end) {
    String status = "";
    SimpleDateFormat dayFormat = null;
    Date startDate = null;
    Date endDate = null;
    TimeZone dubai = null;
    DateStatusBean dsBean = new DateStatusBean();
    try {
      dayFormat = new SimpleDateFormat("dd-MM-yyyy");
      startDate = dayFormat.parse(start);
      endDate = dayFormat.parse(end);
      Date dubaiDate = new Date();
      DateTime oraStartDate = new DateTime(startDate);
      DateTime oraEndDate = new DateTime(endDate);
      DateTime oraDubaiDate = new DateTime(dubaiDate);
      int dayDiffEnd = Days.daysBetween((ReadableInstant)oraEndDate, (ReadableInstant)oraDubaiDate)
        .getDays();
      int dayDiffStart = Days.daysBetween((ReadableInstant)oraStartDate, (ReadableInstant)oraDubaiDate)
        .getDays();
      if (dayDiffStart <= 1) {
        this.logger.info("We'll retrieve data only from vcc_fwd_call_logs. dayDiffStart[" + 
            dayDiffStart + "]..dayDiffEnd[" + dayDiffEnd + "]");
        status = "ONLY_FWD_CALL_LOGS";
      } else if (dayDiffEnd >= 2) {
        this.logger.info("We'll retrieve data only from vcc_fwd_call_logs_history. dayDiffStart[" + 
            dayDiffStart + 
            "]..dayDiffEnd[" + 
            dayDiffEnd + 
            "]");
        status = "ONLY_FWD_CALL_LOGS_HISTORY";
      } else {
        this.logger.info("We'll retrieve data from both vcc_fwd_call_logs and vcc_fwd_call_logs_history. dayDiffStart[" + 
            dayDiffStart + 
            "]..dayDiffEnd[" + 
            dayDiffEnd + 
            "]");
        status = "BOTH";
      } 
    } catch (Exception e) {
      e.printStackTrace();
    } 
    dsBean.setStartDate(startDate);
    dsBean.setEndDate(endDate);
    dsBean.setStatus(status);
    return dsBean;
  }
}
