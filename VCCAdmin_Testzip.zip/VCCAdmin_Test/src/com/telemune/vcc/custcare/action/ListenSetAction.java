package com.telemune.vcc.custcare.action;

import java.util.ArrayList;
import org.apache.log4j.Logger;
import com.telemune.dbutilities.Connection;
import com.telemune.vcc.common.CategoryManager;
import com.telemune.vcc.common.RbtManager;
import com.telemune.vcc.common.SubscriberProfile;
import com.telemune.vcc.common.TSSJavaUtil;
import com.telemune.vcc.common.ValidateAction;

public class ListenSetAction extends ValidateAction {

	
	private String msisdn;
	private String subType;
	private ListenSetBean setBean=null;
	private String message;
	
	public ListenSetAction()
	{
		setLinkName("custcare");
	}
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	
	public String getSubType() {
		return subType;
	}

	public void setSubType(String subType) {
		this.subType = subType;
	}


	Logger logger=Logger.getLogger(ListenSetAction.class);
	
	public ListenSetBean getSetBean() {
		return setBean;
	}

	public void setSetBean(ListenSetBean setBean) {
		this.setBean = setBean;
	}

	public String getMsisdn() {
		return msisdn;
	}

	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}


// this function is for getting the data for Listen and Set	
	
public String getDataForListenSet()
{
	if(!checkSession().equalsIgnoreCase("success")){
		return "error";
		}else{
			
	setBean= new ListenSetBean();
	logger.info("Inside function getDataForListenSet().....");
	
	SubscriberProfile subProfile=null;
	ArrayList catList= null;
	ArrayList rbtList= null;
	CategoryManager catManager= null;
	RbtManager rbtManager= null;
	
	
	Connection con= null;
	String msisdn="";
	String user="";
	msisdn=this.getMsisdn();	
	String retval="failure";
	
if(sessionMap.isEmpty()||sessionMap==null)
{
	logger.info("you sessionis expired");
	return "logout";
	
}
if(sessionMap.containsKey(msisdn))
{
	subProfile=(SubscriberProfile)sessionMap.get(msisdn);
	user=(String)sessionMap.get("user");
	 msisdn=TSSJavaUtil.instance().getInternationalNumber(msisdn);
}else
{
	logger.info("Subscriberprofile attribute is not set in session");
	
}
	this.setMsisdn(msisdn);
	catList= new ArrayList();
	rbtList= new ArrayList();
	int catId=-1;
	int pageid=0;
	try{
		
		con=TSSJavaUtil.instance().getconnection();
		catManager= new CategoryManager();
		catManager.getCategoryForComManage(catList, con);
		rbtManager= new RbtManager();
		int pagecount=rbtManager.getRbtdetailsForCom(con, rbtList, catId, pageid);
		if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
		
		 int showing=pageid*20;
         for(int i=0;i<rbtList.size();i++)
         {
                 showing++;
         }
         logger.info("This  CATEGORY LIST SIZE [ "+catList.size()+" ]  RBTLIST SIZE ["+rbtList.size()+"]  PAGEID ["+pageid+"] PAGECOUNT ["+pagecount+"] SHOWING [ "+showing+" ]");
		setBean.setCatId(catId);
		setBean.setPageCount(pagecount);
		setBean.setCatList(catList);
		setBean.setRbtList(rbtList);
		setBean.setShow(showing);
		retval="success";
		
	}catch(Exception e)
	{
		logger.error("exception inside getDataForListenSet()....",e);
	}finally
	{

		subProfile=null;
		catList= null;
		rbtList= null;
		catManager= null;
		rbtManager= null;
		
			if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
		
	}
	
	return retval;
		}
}


}
