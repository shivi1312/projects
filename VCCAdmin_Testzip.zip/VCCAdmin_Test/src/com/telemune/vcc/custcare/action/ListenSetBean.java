package com.telemune.vcc.custcare.action;

import java.util.ArrayList;

public class ListenSetBean {
	private ArrayList catList= new ArrayList();
	private ArrayList rbtList= new ArrayList();
	private int catId;
	private int rbtId;
	private int pageId;
	private int pageCount;
	private int show;
	private String rbtName;
	private int rbtFound;
	
	private ArrayList grpList= new ArrayList();
	private ArrayList occList= new ArrayList();
	private ArrayList frnList= new ArrayList();
	private String[] hourArray;
	private String date;
	private String stTime;
	private String edTime;
	private String[] deleteAl;
	public String[] getDeleteAl() {
		return deleteAl;
	}
	public void setDeleteAl(String[] deleteAl) {
		this.deleteAl = deleteAl;
	}
	private String[] day;
	private String setUser;
	private String setDate;
	private String setTime;
	private String frnMsisdn;
	private String grpName;
	private String frn;
	private String occVal;
	
	
	
	public String getOccVal() {
		return occVal;
	}
	public void setOccVal(String occVal) {
		this.occVal = occVal;
	}
	public String getGrpName() {
		return grpName;
	}
	public void setGrpName(String grpName) {
		this.grpName = grpName;
	}
	public String getFrn() {
		return frn;
	}
	public void setFrn(String frn) {
		this.frn = frn;
	}
	public String getFrnMsisdn() {
		return frnMsisdn;
	}
	public void setFrnMsisdn(String frnMsisdn) {
		this.frnMsisdn = frnMsisdn;
	}
	public String getSetUser() {
		return setUser;
	}
	public void setSetUser(String setUser) {
		this.setUser = setUser;
	}
	public String getSetDate() {
		return setDate;
	}
	public void setSetDate(String setDate) {
		this.setDate = setDate;
	}
	public String getSetTime() {
		return setTime;
	}
	public void setSetTime(String setTime) {
		this.setTime = setTime;
	}
	public String[] getDay() {
		return day;
	}
	public void setDay(String[] day) {
		this.day = day;
	}
	
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getStTime() {
		return stTime;
	}
	public void setStTime(String stTime) {
		this.stTime = stTime;
	}
	public String getEdTime() {
		return edTime;
	}
	public void setEdTime(String edTime) {
		this.edTime = edTime;
	}
	public String[] getHourArray() {
		return hourArray;
	}
	public void setHourArray(String[] hourArray) {
		this.hourArray = hourArray;
	}
	public ArrayList getGrpList() {
		return grpList;
	}
	public void setGrpList(ArrayList grpList) {
		this.grpList = grpList;
	}
	public ArrayList getOccList() {
		return occList;
	}
	public void setOccList(ArrayList occList) {
		this.occList = occList;
	}
	public ArrayList getFrnList() {
		return frnList;
	}
	public void setFrnList(ArrayList frnList) {
		this.frnList = frnList;
	}
	public int getRbtFound() {
		return rbtFound;
	}
	public void setRbtFound(int rbtFound) {
		this.rbtFound = rbtFound;
	}
	public String getRbtName() {
		return rbtName;
	}
	public void setRbtName(String rbtName) {
		this.rbtName = rbtName;
	}
	public int getPageId() {
		return pageId;
	}
	public void setPageId(int pageId) {
		this.pageId = pageId;
	}
	public int getPageCount() {
		return pageCount;
	}
	public void setPageCount(int pageCount) {
		this.pageCount = pageCount;
	}
	public int getShow() {
		return show;
	}
	public void setShow(int show) {
		this.show = show;
	}
	private String searchTxt;
	
	
	public String getSearchTxt() {
		return searchTxt;
	}
	public void setSearchTxt(String searchTxt) {
		this.searchTxt = searchTxt;
	}
	public ArrayList getCatList() {
		return catList;
	}
	public void setCatList(ArrayList catList) {
		this.catList = catList;
	}
	public ArrayList getRbtList() {
		return rbtList;
	}
	public void setRbtList(ArrayList rbtList) {
		this.rbtList = rbtList;
	}
	public int getCatId() {
		return catId;
	}
	public void setCatId(int catId) {
		this.catId = catId;
	}
	public int getRbtId() {
		return rbtId;
	}
	public void setRbtId(int rbtId) {
		this.rbtId = rbtId;
	}
	
	
	

}
