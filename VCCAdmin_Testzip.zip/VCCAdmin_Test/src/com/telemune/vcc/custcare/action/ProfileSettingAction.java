package com.telemune.vcc.custcare.action;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;
import com.telemune.dbutilities.Connection;
import com.telemune.vcc.common.Rbt;
import com.telemune.vcc.common.SubscriberProfile;
import com.telemune.vcc.common.TSSJavaUtil;
import com.telemune.vcc.common.ValidateAction;
import com.telemune.vcc.custcare.AlbumDetails;
import com.telemune.vcc.custcare.AlbumManager;
import com.telemune.vcc.custcare.CallCenterManagerBean;
import com.telemune.vcc.custcare.EditProfileSettingBean;
import com.telemune.vcc.custcare.Occasion;
import com.telemune.vcc.custcare.OccasionManager;
import com.telemune.vcc.custcare.SubscriberFriend;
import com.telemune.vcc.custcare.SubscriberGroup;
import com.telemune.vcc.custcare.ToneSetting;

public class ProfileSettingAction extends ValidateAction{
	static Logger logger=Logger.getLogger(ProfileSettingAction.class);
	private ProfileSettingBean profileBean=null;
	private String msisdn;
	private String subType;
	
	{
		setLinkName("custcare");
	}
	
	public String getMsisdn() {
		return msisdn;
	}

	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	
	
	public String getSubType() {
		return subType;
	}

	public void setSubType(String subType) {
		this.subType = subType;
	}

	public ProfileSettingBean getProfileBean() {
		return profileBean;
	}

	public void setProfileBean(ProfileSettingBean profileBean) {
		this.profileBean = profileBean;
	}


	private String message;
	

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
			
// this fuinction is for the modifyprofile jsp 
			
	public String getEditProfileInfo()
	{
		logger.info("Inside function getEditProfileInfo()...........");
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
			}else{
				
		
		profileBean= new ProfileSettingBean();
		SubscriberProfile subProfile=null;
		CallCenterManagerBean callCenterManager = null;
		 Rbt rbt = null;
		 ArrayList  subscriberGroups = null;
	        ArrayList friendSettingsAl = null;
	        ArrayList defaultSettingsAl = null;
	        ArrayList dateSettingsAl = null;
	        ArrayList occSettingsAl =   null;
	        ArrayList advSettingAl      =null;
	        ArrayList gpAdvSettingAl      = null;
	        ArrayList defaultDataList= null;
	        HashMap toneDisplaySetting = null;
	        ToneSetting ts = null;
	        EditProfileSettingBean bean= null;
	        ArrayList friendSetList=null;
	        SubscriberFriend sf = null;
	         ArrayList fToneSettings = null;
	         ArrayList groupSetList= null;
	         ArrayList toneSettings = null;
	         ArrayList friends  = null;
	         ArrayList dateSetList= null;
	         ArrayList occDataList= null;
	        		 ArrayList defAdvnc=null;
	        		 EditProfileSettingBean defBean=null;
	        		 ArrayList frndAdvnc=null;
	        		 EditProfileSettingBean frndbean=null;
	         		SubscriberFriend subscriberFriend=null;
	         		ToneSetting toneSetting=null;
	         		ArrayList grpAdvnc=null;
	         		EditProfileSettingBean grpbean=null;
	        		SubscriberGroup group=null;
	         		
		Connection con= null;
		String msisdn="";
		String user="";
		msisdn=this.getMsisdn();	
		String retval="failure";
		logger.info("Inside function handleAlbAdvOption()...");
	if(sessionMap.isEmpty()||sessionMap==null)
	{
		logger.info("you sessionis expired");
		return "logout";
		
	}
	if(sessionMap.containsKey(msisdn))
	{
		
		subProfile=(SubscriberProfile)sessionMap.get(msisdn);
		user=(String)sessionMap.get("user");
		 msisdn=TSSJavaUtil.instance().getInternationalNumber(msisdn);
	}else
	{
		logger.info("Subscriberprofile attribute is not set in session");
		
	}
		this.setMsisdn(msisdn);

		
		try{
		con=TSSJavaUtil.instance().getconnection();
		
		boolean showdel = false;

        //SubscriberProfileManagerBean subProfileManager = new SubscriberProfileManagerBean();
		
		
		callCenterManager = new CallCenterManagerBean();
		 callCenterManager.setUser(user);
		 rbt = new Rbt();

        int adv = callCenterManager.isAdvancedSet(msisdn,rbt,con);
        //subProfileManager.getSubscriberCallerInfo(con);
        callCenterManager.getSubscriberCallerInfo(msisdn,con);
        subscriberGroups = callCenterManager.getGroupSettings();
        friendSettingsAl = callCenterManager.getFriendSettings();
        defaultSettingsAl = callCenterManager.getDefaultSettings();
        dateSettingsAl = callCenterManager.getDateSettings();
        occSettingsAl =   callCenterManager.getOccSettings();
        advSettingAl      = callCenterManager.getAdvanceSettings();
        gpAdvSettingAl      = callCenterManager.getGroupAdvanceSettings();
        
        
        System.out.println("Friend Advance Setting List size : "+advSettingAl.size()+" || group Advance Setting List Size : "+gpAdvSettingAl.size()+" || and Default Setting List Size : "+defaultSettingsAl.size());
        if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
        
   // here is the list which we are going to set the data for default list     
        
        defaultDataList= new ArrayList();
  // here the bussiness logic starts
        
        toneDisplaySetting = new HashMap();
        int serialNumber=0;

        Iterator deIte = defaultSettingsAl.iterator();

        String prevKey2 = null;
        boolean printFlag2 = false;
        String strStartTime2=null;
        String strEndTime2=null;
        String rbtName2 = "";
        int rbtCode2 = -1;
        long corpId=0;
        boolean delPrint = true;
               String caller_type="caller";
               
        while(deIte.hasNext())
        {
         ts = (ToneSetting)deIte.next();

         String key = ts.getStartTime()+":"+ts.getEndTime()+":"+ts.getRbtCode();
         boolean daySet[]=null;
         boolean printDaySet[]= new boolean[7];
         daySet = (boolean[])toneDisplaySetting.get(key);
         logger.info("Key Value is ||"+key);
         if(prevKey2 !=null && !prevKey2.equals(key))
         {
          serialNumber++;
          printFlag2 = true;
          printDaySet = (boolean[])toneDisplaySetting.get(prevKey2);
          prevKey2 = key;
         }
         else
         {
          strStartTime2 = "" + ts.getStartTime();
          strEndTime2 = "" + ts.getEndTime();
          rbtCode2 = ts.getRbtCode();
          corpId=ts.getCorpId();
          rbtName2 = ts.getRbtMaskName();
          printFlag2 = false;
         }

         if (prevKey2 == null)
          prevKey2 = key;

         if(daySet != null)
         {
          int dayId = ts.getDay();
          if(dayId == 8)
          {
           for(int m=0; m < 7; m++)
        	   daySet[m] = true;
          }
          else
          {
           daySet[dayId -1] = true;
          }
          toneDisplaySetting.put(key, daySet);
         }
         else
         {
          daySet = new boolean[7];
          int dayId = ts.getDay();
          if(dayId == 8)
          {
           for(int m=0; m < 7; m++)
            daySet[m] = true;
          }
          else
           daySet[dayId -1] = true;
          toneDisplaySetting.put(key, daySet);
         }
         
         bean= new EditProfileSettingBean();
         if(printFlag2)
         {
        	 
          caller_type=setDataForDefaultSetting(serialNumber, strStartTime2, strEndTime2, printDaySet, rbtCode2, rbtName2, delPrint, corpId,bean);
          strStartTime2 = "" + ts.getStartTime();
          strEndTime2 = "" + ts.getEndTime();
          rbtCode2 = ts.getRbtCode();
          corpId=ts.getCorpId();
          rbtName2 = ts.getRbtMaskName();
          printFlag2=false;
          delPrint = false;
          defaultDataList.add(bean);
          
         }
         if (!deIte.hasNext())
         {
          serialNumber++;
          printDaySet = (boolean[])toneDisplaySetting.get(prevKey2);
          strStartTime2 = "" + ts.getStartTime();
          strEndTime2 = "" + ts.getEndTime();
          rbtCode2 = ts.getRbtCode();
          corpId=ts.getCorpId();
          rbtName2 = ts.getRbtMaskName();
          printFlag2 = true;
          caller_type=setDataForDefaultSetting(serialNumber, strStartTime2, strEndTime2, printDaySet, rbtCode2, rbtName2, delPrint, corpId,bean);
          delPrint = false;
          defaultDataList.add(bean);
         }
         if(serialNumber>1)
         {
        	 showdel=true;
         }
        // here we are going to the bean of default list
         
        }
        
       profileBean.setDefaultList(defaultDataList);
       profileBean.setDefSize(defaultDataList.size());
       
        
        friendSetList= new ArrayList();
        toneDisplaySetting = new HashMap();
        
// here we are going to iterate the friend list
        Iterator frIte = friendSettingsAl.iterator();
        while(frIte.hasNext())
        {
         sf = (SubscriberFriend)frIte.next();
         fToneSettings = sf.getToneSettings();
         if(fToneSettings != null)
         {
          Iterator fToneIte = fToneSettings.iterator();
          String prevKey1 = null;
          boolean printFlag1 = false;
          String strStartTime1=null;
          String strEndTime1=null;
          String rbtName="";
          int rbtCode = -1;
          while(fToneIte.hasNext())
          {
           ts = (ToneSetting)fToneIte.next();

           String key = ts.getStartTime() + "," + ts.getEndTime() + "," +ts.getRbtCode();
           boolean daySet[]=null;
           boolean printDaySet[]= new boolean[7];
           daySet = (boolean[])toneDisplaySetting.get(key);
           logger.info("Map key Value||| "+key);
           if(prevKey1 !=null && !prevKey1.equals( key))
           {
            serialNumber++;
            printFlag1 = true;
            printDaySet = (boolean[])toneDisplaySetting.get(prevKey1);
            prevKey1 = key;
           }
           else
           {
            strStartTime1 = "" + ts.getStartTime();
            strEndTime1 = "" + ts.getEndTime();
            rbtCode = ts.getRbtCode();
            rbtName = ts.getRbtMaskName();
            printFlag1 = false;
           }
           if(prevKey1 == null)
            prevKey1 = key;

           if(daySet != null)
           {
            int dayId = ts.getDay();
            if(dayId == 8)
            {
             for(int m=0; m < 7; m++)
              daySet[m] = true;
            }
            else
            {
             daySet[dayId -1] = true;
            }

            toneDisplaySetting.put(key, daySet);
           }
           else
           {
            daySet = new boolean[7];
            int dayId = ts.getDay();
            if(dayId == 8)
            {
             for(int m=0; m < 7; m++)
              daySet[m] = true;
            }
            else
             daySet[dayId -1] = true;

            toneDisplaySetting.put(key, daySet);

           }
bean= new EditProfileSettingBean();
           if(printFlag1)
           {
            String friendMsisdn = new String("");
            if(sf.getFriendsNick().equals("Not Given"))
             friendMsisdn=sf.getFriendsMsisdn();
            else
             friendMsisdn=sf.getFriendsMsisdn()+" "+"("+sf.getFriendsNick()+")";

            getDataForGroupAndFriendSetting(serialNumber,0, sf.getFriendsMsisdn(), strStartTime1, strEndTime1, printDaySet,sf.getFriendsNick(),rbtCode,rbtName, friendMsisdn, bean);
           // (out,serialNumber,0, sf.getFriendsMsisdn(), strStartTime1, strEndTime1, printDaySet,sf.getFriendsNick(),rbtCode,rbtName, friendMsisdn);
            strStartTime1 = "" + ts.getStartTime();
            strEndTime1 = "" + ts.getEndTime();
            rbtCode = ts.getRbtCode();
            rbtName = ts.getRbtMaskName();
            friendSetList.add(bean);
           }
           if(!fToneIte.hasNext())
           {
            String friendMsisdn = new String("");

            if(sf.getFriendsNick().equals("Not Given"))
             friendMsisdn=sf.getFriendsMsisdn();
            else
             friendMsisdn=sf.getFriendsMsisdn() +" "+ "(" + sf.getFriendsNick() +")";

            serialNumber++;
            printDaySet = (boolean[])toneDisplaySetting.get(prevKey1);
            strStartTime1 = "" + ts.getStartTime();
            strEndTime1 = "" + ts.getEndTime();
            rbtCode = ts.getRbtCode();
            rbtName = ts.getRbtMaskName();
            printFlag1 = true;
           // test(out,serialNumber,0, sf.getFriendsMsisdn(), strStartTime1, strEndTime1, printDaySet,sf.getFriendsNick(),rbtCode,rbtName,friendMsisdn);
            getDataForGroupAndFriendSetting(serialNumber,0, sf.getFriendsMsisdn(), strStartTime1, strEndTime1, printDaySet,sf.getFriendsNick(),rbtCode,rbtName, friendMsisdn, bean);
            
            friendSetList.add(bean);
           }//if printFlag

          }//while fToneIte.hasnext()

         }//if fToneSettings !=null

        }//while more friends
        if(friendSetList.size()>0)
        {
        	showdel=true;
        }
        profileBean.setFriendSettingList(friendSetList);
        profileBean.setFrnSize(friendSetList.size());

        
        toneDisplaySetting = new HashMap();
        groupSetList= new ArrayList();
        Iterator ite = subscriberGroups.iterator();
        while(ite.hasNext())
        {
         SubscriberGroup sg = (SubscriberGroup) ite.next();
         toneSettings = sg.getToneSettings();
         friends  = sg.getFriends();

         if(toneSettings != null)
         {
          toneDisplaySetting.clear();

          Iterator toneIte = toneSettings.iterator();
          String prevKey = null;
          boolean printFlag = false;
          String strStartTime=null;
          String strEndTime=null;
          int rbtCode=-1;
          String rbtName="";
          while(toneIte.hasNext())
          {
           ts = (ToneSetting)toneIte.next();

           String key = ts.getStartTime() + "," + ts.getEndTime() +"," + ts.getRbtCode();
           boolean daySet[]=null;
           boolean printDaySet[]= new boolean[7];
           daySet = (boolean[])toneDisplaySetting.get(key);

           if(prevKey !=null && !prevKey.equals( key))
           {
            serialNumber++;
            printFlag = true;
            printDaySet = (boolean[])toneDisplaySetting.get(prevKey);
            prevKey = key;
           }
           else
           {
            strStartTime = "" + ts.getStartTime();
            strEndTime = "" + ts.getEndTime();
            rbtCode = ts.getRbtCode();
            rbtName = ts.getRbtMaskName();
            printFlag = false;
           }
           if(prevKey == null)
            prevKey = key;

           if(daySet != null)
           {
            int dayId = ts.getDay();
            logger.info("The day is "+dayId);
            if(dayId == 8)
            {
             for(int m=0; m < 7; m++)
              daySet[m] = true;
            }
            else
            {
             daySet[dayId -1] = true;
            }

            toneDisplaySetting.put(key, daySet);
           }
           else
           {
            daySet = new boolean[7];
            int dayId = ts.getDay();
            if(dayId == 8)
            {
             for(int m=0; m < 7; m++)
              daySet[m] = true;
            }
            else
             daySet[dayId -1] = true;

            toneDisplaySetting.put(key, daySet);
           }
           bean= new EditProfileSettingBean();
           if(printFlag)
           {
            String groupName = ( sg.getGroupName() ) + "(Group)";
            getDataForGroupAndFriendSetting(serialNumber,sg.getGroupId(), sg.getGroupName(), strStartTime, strEndTime, printDaySet,sg.getGroupName(),rbtCode, rbtName,groupName, bean);
            //test(out,serialNumber,sg.getGroupId(), sg.getGroupName(), strStartTime, strEndTime, printDaySet,sg.getGroupName(),rbtCode, rbtName,groupName);
            strStartTime = "" + ts.getStartTime();
            strEndTime = "" + ts.getEndTime();
            rbtCode = ts.getRbtCode();
            rbtName = ts.getRbtMaskName();
            groupSetList.add(bean);
            
           }

           if(!toneIte.hasNext())
           {
        	   String groupName = ( sg.getGroupName() ) + "(Group)";
        	      serialNumber++;
        	      printDaySet = (boolean[])toneDisplaySetting.get(prevKey);
        	      strStartTime = "" + ts.getStartTime();
        	      strEndTime = "" + ts.getEndTime();
        	      rbtCode = ts.getRbtCode();
        	      rbtName = ts.getRbtMaskName();
        	      printFlag = true;
        	      getDataForGroupAndFriendSetting(serialNumber,sg.getGroupId(), sg.getGroupName(), strStartTime, strEndTime, printDaySet,sg.getGroupName(),rbtCode, rbtName,groupName, bean);
        	      groupSetList.add(bean);      
        	  //.    test(out,serialNumber,sg.getGroupId(), sg.getGroupName(), strStartTime, strEndTime, printDaySet,sg.getGroupName(),rbtCode,rbtName, groupName);

        	     }//if printFlag
        	    }//while ite hasNext
        	   }//tonesettings not null
        	  }//while iterator groups
        if(groupSetList.size()>0)
        {
        	showdel=true;
        }
        profileBean.setGroupSettingList(groupSetList);
        profileBean.setGrpSize(groupSetList.size());
 
        dateSetList= new ArrayList();
        if(dateSettingsAl.size()>0)
        {
        	showdel=true;
        	   serialNumber = 0;
               Iterator daIte = dateSettingsAl.iterator();
               while(daIte.hasNext())
               {
            	   	bean= new EditProfileSettingBean();
                       ts = (ToneSetting)daIte.next();
                       serialNumber++;
                       getDataForDateSetting(serialNumber,ts.getDate().toString(),ts.getRbtCode(),ts.getRbtMaskName(),bean);
                       dateSetList.add(bean);
                       
               }
               profileBean.setDateSetList(dateSetList);
               profileBean.setDateSize(dateSetList.size());
        }
        
        occDataList= new ArrayList();
        if (occSettingsAl.size() > 0)
        {
        	showdel=true;
         
        	serialNumber = 0;
            Iterator occIte = occSettingsAl.iterator();
            while(occIte.hasNext())
            {bean= new EditProfileSettingBean();
                    ts = (ToneSetting)occIte.next();
                    serialNumber++;
            getDataForOccassionSetting(serialNumber,ts.getOccasionName(),ts.getDate(),ts.getRbtCode(),ts.getRbtMaskName(),bean);
            occDataList.add(bean);
            }
            profileBean.setOccSetList(occDataList);
            profileBean.setOccSize(occDataList.size());

        }
        
        
        defAdvnc=new ArrayList();
       		defBean=new EditProfileSettingBean();
       		defBean.setRbtName(rbt.getRbtMaskName());
       		defBean.setNick(rbt.getNickname());
       		defBean.setDeleteLinkValue(rbt.getRbtId()+"&3000&3000&0&Default");
       		defAdvnc.add(defBean);
        profileBean.setDefaultAdvRbt(defAdvnc);
        
        
        
        frndAdvnc=new ArrayList();
        if(advSettingAl.size()>0)
        {
        	showdel=true;
        	Iterator frndIte = advSettingAl.iterator();
        	while(frndIte.hasNext())
        	{
        		frndbean=new EditProfileSettingBean();
        		subscriberFriend=(SubscriberFriend)frndIte.next();
        		
        		for(int i=0;i<subscriberFriend.getAdvToneSetting().size();i++)
        		{
        			toneSetting=(ToneSetting)subscriberFriend.getAdvToneSetting().get(i);
        			getDataForAdvncFrndSetting(subscriberFriend.getFriendsMsisdn(),subscriberFriend.getFriendsNick(),toneSetting.getRbtMaskName(),toneSetting.getCatMaskName(),toneSetting.getRbtCode() ,frndbean);
        			frndAdvnc.add(frndbean);
        		}
        	}
        	profileBean.setAdvFriendSettingList(frndAdvnc);
        }
        
        
        
        
        grpAdvnc=new ArrayList();
        if(gpAdvSettingAl.size()>0)
        {
        	showdel=true;
        	Iterator grpIte = gpAdvSettingAl.iterator();
        	while(grpIte.hasNext())
        	{
        		grpbean=new EditProfileSettingBean();
        		group=(SubscriberGroup)grpIte.next();
        		serialNumber++;
        		for(int i=0;i<group.getAdvToneSetting().size();i++)
        		{
        			toneSetting=(ToneSetting)group.getAdvToneSetting().get(i);
        			getDataForAdvncGrpSetting(group.getGroupId(),group.getGroupName(),toneSetting.getRbtMaskName(),toneSetting.getCatMaskName(),toneSetting.getRbtCode() ,grpbean);
        			grpAdvnc.add(grpbean);
        		}
        	}
        	profileBean.setAdvGrpSettingList(grpAdvnc);
        }
        
        
        actionName="intoUserProfile.action?msisdn="+msisdn+"&subType="+getSubType();
        logger.info("Value of showdel is "+showdel);
        profileBean.setShowdel(showdel);
        
        
		}catch(Exception exe)
		{
			logger.error("Exception in getEditProfileInfo()..",exe);
			exe.printStackTrace();
			return "failure";
		}
		finally
		{
			subProfile=null;
			callCenterManager = null;
			 rbt = null;
			 subscriberGroups = null;
		        friendSettingsAl = null;
		        defaultSettingsAl = null;
		        dateSettingsAl = null;
		        occSettingsAl =   null;
		        advSettingAl      =null;
		        gpAdvSettingAl      = null;
		        defaultDataList= null;
		        toneDisplaySetting = null;
		        ts = null;
		        bean= null;
		        friendSetList=null;
		        sf = null;
		         fToneSettings = null;
		         groupSetList= null;
		         toneSettings = null;
		         friends  = null;
		         dateSetList= null;
		         occDataList= null;
		        		defAdvnc=null;
		        		defBean=null;
		        		frndAdvnc=null;
		        		frndbean=null;
		         		subscriberFriend=null;
		         		toneSetting=null;
		         		grpAdvnc=null;
		         		grpbean=null;
		         		group=null;
			 try
			 {
			if(con!=null) if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
			 }
			  catch(Exception exp){exp.printStackTrace();}
		}
		return SUCCESS;
			}
		
	}
			
			
	// this function is for setting the data in bean for default setting 
public String setDataForDefaultSetting(int serialNumber, String strStartTime, String strEndTime, boolean[] printDaySet, int rbtCode, String rbtName, boolean delPrint, long corpId,EditProfileSettingBean bean)
{
	logger.info("inside  function setDataForDefaultSetting()................");
	if(!checkSession().equalsIgnoreCase("success")){
		return "error";
		}else{
		
			ArrayList dateList= null;
			Rbt checkday= null;
	String day="";
	 String caller_type1="";
	 for(int i=0; i< 7; i++)
	 {
	  if(printDaySet[i]==true)
	   day +=i;
	 }
	 try
	 {
	 bean.setSerialNumber(serialNumber);
	  if(delPrint)
	  {
		 bean.setTitle("All time setting"); 
	  }
	  else
	   bean.setTitle( "Default");
	  bean.setRbtName( rbtName );
	  bean.setRbtCode(rbtCode );
	  if(strStartTime.equals("2500"))
	  {
	   strStartTime = "0000";
	  }
	  if(strStartTime.length()==1)
	  {
	   strStartTime = "000" + strStartTime;
	  }
	  else if(strStartTime.length()==2)
	  {
	   strStartTime = "00" + strStartTime;
	  }
	  else if(strStartTime.length()==3)
	  {
	   strStartTime = "0" + strStartTime;
	  }
	  bean.setStartTime(strStartTime);
	 
	  if(strEndTime.equals("2500"))
	  {
	   strEndTime = "2300";
	  }
	  if(strEndTime.length()==1)
	  {
	   strEndTime = "000" + strEndTime;
	  }
	  else if(strEndTime.length()==2)
	  {
	   strEndTime = "00" + strEndTime;
	  }
	  else if(strEndTime.length()==3)
	  {
	   strEndTime = "0" + strEndTime;
	  }
	  bean.setEndTime(strEndTime);
	  dateList= new ArrayList();
	  
	  for(int m=0; m < 7; m++)
	  {
		  checkday= new Rbt();
	   if(printDaySet[m] == true)
	   {
		   checkday.setCheckDay(true);
	   }
	   else
	   {
		   checkday.setCheckDay(false);
	   }
	   
	   dateList.add(checkday);
	   
	  }
	  bean.setDayList(dateList);
	  actionName="intoUserProfile.action?msisdn="+msisdn+"&subType="+getSubType();
	  if(!delPrint )
	  {
//	      if(corpId ==0)
	      {
	    	  
	      String changeLinkval="st="+strStartTime+"&et="+strEndTime+"&groupId=0&num=Default&day="+day+"&nick=Default&rbtId="+rbtCode+"&rbtname="+rbtName;
	      bean.setChangeLinkValue(changeLinkval);
	      String deleteVal=rbtCode+"&";
	      String stTime="";
	    	String edTime="";	  
	                  if (strStartTime.equals("0000") && strEndTime.equals("2300"))
	                  {
	                	  stTime="2500";
	                	  edTime="2500";
	                     
	                  }
	                  else
	                  {
	                	stTime=strStartTime  ;
	                	edTime=strEndTime;
	                     
	                  }
	                 deleteVal=deleteVal+"&"+stTime+"&"+edTime+"&0&Default&"+day;
	                 logger.info(deleteVal);
	                 bean.setDeleteLinkValue(deleteVal);
	                 bean.setDelFlag(true);
	              }//if(corpId)
	          }//if(!delPrint)
	          else
	          {
	        	  bean.setDelFlag(false);
	          }
	  
	 }catch(Exception exe)
	 {
		 logger.error("Exception in setDataForDefaultSetting()...",exe);
		 exe.printStackTrace();
		 return "failure";
		 
	 }
finally
{
	dateList= null;
	checkday= null;
}
	return SUCCESS;
		}
}
	
	
// this function is for getting the data of date setting

public void getDataForDateSetting(int serialNumber,String date,int rbtCode, String rbtName,EditProfileSettingBean datebean)
{
	logger.info("Inside function getDataFordateSetting()..................");
	datebean.setSerialNumber(serialNumber);
    datebean.setDate(date );
    datebean.setRbtName( rbtName );
    datebean.setRbtCode(rbtCode);
    String stTime="0000";
    datebean.setStartTime(stTime);
    String edTime="2300";
    datebean.setEndTime(edTime);
    String checkVal=rbtCode+"&"+date+"&0000&0&Date&0";
    datebean.setDeleteLinkValue(checkVal);
}

//this function is for occasion setting 
public void getDataForOccassionSetting(int serialNumber,String occName,String date,int rbtCode, String rbtName,EditProfileSettingBean datebean)
{
	logger.info("Inside the function getDataForOccassionSetting()............... ");
	datebean.setSerialNumber(serialNumber);
	datebean.setOccName(occName);
    datebean.setDate(date );
    datebean.setRbtName( rbtName );
    datebean.setRbtCode(rbtCode);
    String stTime="0000";
    datebean.setStartTime(stTime);
    String edTime="2300";
    datebean.setEndTime(edTime);
    String checkVal=rbtCode+"&"+date+"&0000&0&Date&0";
    datebean.setDeleteLinkValue(checkVal);
}


//this function is for Advance Group setting 
public void getDataForAdvncGrpSetting(long grpId,String GrpName,String rbtName, String catName,int rbtCode,EditProfileSettingBean grpbean)
{
	logger.info("Inside the function getDataForAdvncGrpSetting()............... ");

	grpbean.setRbtName( rbtName );
	grpbean.setRbtCode(rbtCode);
	grpbean.setGrpName(GrpName);
	grpbean.setCatName(catName);
	String checkVal=rbtCode+"&3000&3000&"+grpId+"&"+GrpName;
	grpbean.setDeleteLinkValue(checkVal);
}

//this function is for Advance Group setting 
public void getDataForAdvncFrndSetting(String frndMsisdn,String frndNick,String rbtName, String catName,int rbtCode,EditProfileSettingBean frndbean)
{
	logger.info("Inside the function getDataForAdvncFrndSetting()............... ");

	frndbean.setRbtName( rbtName );
	frndbean.setRbtCode(rbtCode);
	frndbean.setFrndMsisdn(frndMsisdn);
	frndbean.setFrndNick(frndNick);
	frndbean.setCatName(catName);
	String checkVal=rbtCode+"&3000&3000&0&"+frndMsisdn;
	frndbean.setDeleteLinkValue(checkVal);
}




// this is the common function for getting the data for freind setting and groupsetting
public void getDataForGroupAndFriendSetting(int serialNumber, long strGroupId, String strGroupName, String strStartTime, String strEndTime, boolean[] printDaySet, String nick,int rbtCode, String rbtName, String Nick,EditProfileSettingBean bean)
{
	logger.info("Inside function getDataForGroupAndFriendSetting()...............");

	 String day="";
	 ArrayList dateList= null;
	 Rbt checkday=null;
     for(int i =0; i< 7; i++)
     {
             if(printDaySet[i]==true)
                     day +=i;
     }
     try
     {
    	     bean.setSerialNumber(serialNumber );
            bean.setNick(Nick);
            bean.setRbtName( rbtName );
             bean.setRbtCode(rbtCode );
             if(strStartTime.equals("2500"))
             {
                     strStartTime = "0000";
             }
             if(strStartTime.length()==1)
             {
                     strStartTime = "000" + strStartTime;
             }
             else if(strStartTime.length()==2)
             {
                     strStartTime = "00" + strStartTime;
             }
             else if(strStartTime.length()==3)
             {
                     strStartTime = "0" + strStartTime;
             }
             bean.setStartTime(strStartTime);
             if(strEndTime.equals("2500"))
             {
                     strEndTime = "2300";
             }
             if(strEndTime.length()==1)
             {
                     strEndTime = "000" + strEndTime;
             }
             else if(strEndTime.length()==2)
             {
                     strEndTime = "00" + strEndTime;
             }
             else if(strEndTime.length()==3)
             {
                     strEndTime = "0" + strEndTime;
             }
             bean.setEndTime(strEndTime );
             dateList= new ArrayList();
       	  
       	  for(int m=0; m < 7; m++)
       	  { checkday= new Rbt();
       	   if(printDaySet[m] == true)
       	   {
       		   checkday.setCheckDay(true);
       	   }
       	   else
       	   {
       		   checkday.setCheckDay(false);
       	   }
       	   
       	   dateList.add(checkday);
       	   
       	  }
       	  bean.setDayList(dateList);

       	 String changeLinkval="st="+strStartTime+"&et="+strEndTime+"&groupId="+strGroupId+"&num="+strGroupName+"&day="+day+"&nick="+nick+"&rbtId="+rbtCode+"&rbtname="+rbtName;
       	bean.setChangeLinkValue(changeLinkval);
       	 String deleteVal=rbtCode+"&";
	      String stTime="";
	    	String edTime="";	  
	                  if (strStartTime.equals("0000") && strEndTime.equals("2300"))
	                  {
	                	  stTime="2500";
	                	  edTime="2500";
	                     
	                  }
	                  else
	                  {
	                	stTime=strStartTime  ;
	                	edTime=strEndTime;
	                     
	                  }
	                 deleteVal=deleteVal+"&"+stTime+"&"+edTime+"&"+strGroupId+"&"+strGroupName+"&"+day;
	                 logger.info(deleteVal);
	                 bean.setDeleteLinkValue(deleteVal);
	     
	                 actionName="intoUserProfile.action?msisdn="+msisdn+"&subType="+getSubType();
     }
     catch (Exception e)
     {
    	 logger.error("Exception in getDataForGroupAndFriendSetting()..",e);
             e.printStackTrace();
             
     }
     finally
     {
    	 dateList= null;
    	 checkday=null;
     }

}


// this function id for delete the profile of the user

public String deleteProfile()
{
	logger.info("Inside function deleteProfile().....................");
	if(!checkSession().equalsIgnoreCase("success")){
		return "error";
		}else{
			
	
	SubscriberProfile subProfile=null;
	CallCenterManagerBean callCenterManager = null;
	String delStrings[]=null;
	
	Connection con= null;
	String msisdn="";
	String users="";
	msisdn=this.getMsisdn();	
	String retval="failure";
	try
	{
if(sessionMap.isEmpty()||sessionMap==null)
{
	logger.info("you sessionis expired");
	return "logout";
	
}
if(sessionMap.containsKey(msisdn))
{
	
	subProfile=(SubscriberProfile)sessionMap.get(msisdn);
	users=(String)sessionMap.get("user");
	 msisdn=TSSJavaUtil.instance().getInternationalNumber(msisdn);
}else
{
	logger.info("Subscriberprofile attribute is not set in session");
	
}
	this.setMsisdn(msisdn);
	
	callCenterManager = new CallCenterManagerBean();

    //llCenterManager.setSessionHistory();
	callCenterManager.setUser(users);

	        delStrings=profileBean.getDeleteVal();
	        callCenterManager.setSubscriberProfile(getSubType());
	        logger.info("the size of delete array list"+delStrings.length);
	        String i = callCenterManager.deleteSubscriberProfile(subProfile, delStrings , users);
	        
	        logger.info("This the message from Rule enginge"+i);
	        this.setMessage(i);
	        actionName="modifyManageProfile.action?msisdn="+msisdn+"&subType="+getSubType();
	        return SUCCESS;
	}catch (Exception e) {
		e.printStackTrace();
		return "failure";
	}
	finally
	{
		subProfile=null;
		callCenterManager = null;
		delStrings=null;
	}
		}
}


// this function is for get the details for modifyThe profile

public String modifyProfile()
{
	logger.info("Inside of function modifyProfile().....................");
	System.out.println("Inside of function modifyProfile()..................... : "+profileBean.getMdVal()+" || msisdn : "+msisdn);
	if(!checkSession().equalsIgnoreCase("success")){
		return "error";
		}else{
			

	if(sessionMap.isEmpty()||sessionMap==null)
	{
		logger.info("session is expired");
		return "logout";
	}
	SubscriberProfile subProfile=null;
	String[] paramsVal=null;
	String[] val= null;
	String[] args=null;
	String[] deleteval={"-1","-1","-1","-1","-1","-1","-1"};
	 String[] checkval={"0","1","2","3","4","5","6"}; 
	 String hourArray[]=null;
	 ArrayList checkAl= null;
	 Rbt rbt=null;
	 try{
	String msisdn=getMsisdn();
	Connection con=null;
	if(sessionMap.containsKey(msisdn))
	{
		subProfile=(SubscriberProfile)sessionMap.get(msisdn);
		logger.info(subProfile);
		 msisdn=subProfile.getMsisdn();
		 msisdn=TSSJavaUtil.instance().getInternationalNumber(msisdn);
	}else
	{
		logger.info("Subscriberprofile attribute is not set in session");
		
	}
	
	String linkval=profileBean.getMdVal();
	logger.info("the link String is "+linkval);
	boolean isCorpUser=false;
	paramsVal=linkval.split("&");
	val= new String[paramsVal.length];
	for(int k=0;k<paramsVal.length;k++)
	{
		args=paramsVal[k].split("=");
		val[k]=args[1].toString();
	}
	//st=0000 &et=2300& groupId=0& num=18761234567834& day=0123456& nick=DFGHJK& rbtId=20352& rbtname=AKONSUNNYDAY
	System.out.println("***************************subprofile : "+subProfile.toString());
	
	
	if(subProfile.getCorpId()>0) isCorpUser=true;  //belongs to a corporate;

	
	String strRbtCode = val[6];
	 String strStartTime = val[0];
	 String strEndTime = val[1];
	 String strGroupId =  val[2];
	 String strDays =  val[4];
	 String strName =  val[3];
	 String strNick =  val[5];
	 String strRbtName = val[7];

	 int numOfDays = strDays.length();
	 char chDays[] = strDays.toCharArray();

	 String startHour = null;
	 String startMin = null;
	 String endHour = null;
	 String endMin = null;

	 int iStartHour=0;
	 int iStartMin =0;
	 int iEndHour=0;
	 int iEndMin=0;

	 boolean bDays[] = new boolean[7];
	 
	 for(int i =0;i<7;i++)
	  bDays[i]=false;
	 for(int m=0; m<numOfDays;m++)
	 {
	  switch(chDays[m])
	  {
	   case '0':
	    bDays[0] = true;
	    deleteval[0]="0";
	    break;
	   case '1':
	    bDays[1] = true;
	    deleteval[1]="1";
	    break;
	   case '2':
	    bDays[2] = true;
	    deleteval[2]="2";
	    break;
	   case '3':
	    bDays[3] = true;
	    deleteval[3]="3";
	    break;

	   case '4':
	    bDays[4] = true;
	    deleteval[4]="4";
	    break;

	   case '5':
	    bDays[5] = true;
	    deleteval[5]="5";
	    break;
	   case '6':
	    bDays[6] = true;
	    deleteval[6]="6";
	    break;
	  }
	 }
	 if(strStartTime.equals("0"))
	 {
	  startHour = "00";//strStartTime.substring(strStartTime.length() - 2, 2);
	  startMin = "00";//strStartTime.substring(1,strStartTime.length() - 2);
	  iStartHour =0;
	  iStartMin =0;
	 }
	 else
	 {

	  if(strStartTime.length()==3)
	   strStartTime ="0" + strStartTime;
	  else if(strStartTime.length()==2)
	   strStartTime = "00" + strStartTime;
	  startMin = strStartTime.substring(strStartTime.length() - 2, strStartTime.length());
	  startHour = strStartTime.substring(0,strStartTime.length() - 2);
	  iStartHour = Integer.parseInt(startHour);
	  iStartMin = Integer.parseInt(startMin);
	  logger.info("starthour :"+iStartHour + "start min :" + iStartMin);
	 }
	 if(strEndTime.equals("0"))
	 {
	  endHour = "00";//strStartTime.substring(strStartTime.length() - 2, 2);
	  endMin = "00";//strStartTime.substring(1,strStartTime.length() - 2);
	  iEndHour=0;
	  iEndMin=0;
	 }
	 else
	 {
	  if(strEndTime.length()==3)
	   strEndTime ="0" + strEndTime;
	  else if(strEndTime.length()==2)
	   strEndTime = "00" + strEndTime;
	  endMin = strEndTime.substring(strEndTime.length() - 2, strEndTime.length());
	  endHour = strEndTime.substring(0,strEndTime.length() - 2);

	  iEndHour = Integer.parseInt(endHour);
	  iEndMin = Integer.parseInt(endMin);
	  System.out.println("starthour "+iEndHour + "startmin:" + iEndMin);
	 }
hourArray=new String[24];
	 if(isCorpUser)
	 {
		 for(int i = 0; i < 24; i++)
         {
            // if(i>8 && i<17){}
           //  else
           //  {
                 if(i < 10 )
                 {
                	hourArray[i]="0"+i; 
                 }
                 else
                 {
                	 hourArray[i]=""+i;
                 }
            // }
             
         }

	 }else
	 {
		 for(int i = 0; i <= 23; i ++)
         {
             if(i<10)
             {
            		hourArray[i]="0"+i;
             }
             else
             {
            		hourArray[i]=""+i;
             }
         }

	 }
	 boolean check=false;
	 checkAl= new ArrayList();
	 for(int j=0;j<checkval.length;j++)
	 {
		 rbt= new Rbt();
		 rbt.setOthers(checkval[j]);
		 if(checkval[j].equalsIgnoreCase(deleteval[j]))
		 {
			 check=true;
		 }else
		 {
			 check=false;
		 }
		 
		 rbt.setCheckDay(check);
		 checkAl.add(rbt);
	 }
	 
	 for(int k=0;k<deleteval.length;k++)
	 {
		 logger.info("this is the value of string array"+deleteval[k]);
	 }
	 
	 
	 profileBean.setHourArry(hourArray);
	 profileBean.setNumber(strName);
	 profileBean.setRbtName(strRbtName);
	 profileBean.setRbtId(Integer.parseInt(strRbtCode));
	//profileBean.setDeleteVal(deleteval);
	profileBean.setCheck(checkAl);
	
	profileBean.setTimeSet(strStartTime);
	profileBean.setDaySet(strEndTime);
	profileBean.setGrpSize(Integer.parseInt(strGroupId));
	profileBean.setRbtId(Integer.parseInt(strRbtCode));
	profileBean.setFriend(strNick);
	
	System.out.println("st Time : "+profileBean.getStTime() +" || ed Time : "+profileBean.getEdTime());
	String stTimeStr="";
	if(iStartHour<10)
		stTimeStr="0"+iStartHour;
	else
		stTimeStr=iStartHour+"";
		
	 profileBean.setStTime(stTimeStr);
	 profileBean.setEdTime(Integer.toString(iEndHour));
	 actionName="intoUserProfile.action?msisdn="+msisdn+"&subType="+getSubType();
	return SUCCESS;
	 }
	 catch (Exception e) {
		e.printStackTrace();
		
		return "failure";
	}
	 finally
	 {
		 subProfile=null;
			 paramsVal=null;
			 val= null;
			 args=null;
			 deleteval=null;
			 checkval= null; 
			 hourArray=null;
			 checkAl= null;
			 rbt=null;
	 }
		}
}



// this function is for update the profile from database

public String updateProfile()
{
	logger.info("Inside function updateProfile().....................");
	if(!checkSession().equalsIgnoreCase("success")){
		return "error";
		}else{
			
	
	SubscriberProfile subProfile=null;
	CallCenterManagerBean callCenterManager = null;
	ArrayList toneSettings =null;
	ToneSetting ts=null;
	String days[]=null;
	
	Connection con= null;
	String msisdn="";
	String users="";
	msisdn=this.getMsisdn();	
	String retval="failure";
if(sessionMap.isEmpty()||sessionMap==null)
{
	logger.info("you sessionis expired");
	return "logout";
	
}
if(sessionMap.containsKey(msisdn))
{
	
	subProfile=(SubscriberProfile)sessionMap.get(msisdn);
	users=(String)sessionMap.get("user");
	 msisdn=TSSJavaUtil.instance().getInternationalNumber(msisdn);
}else
{
	logger.info("Subscriberprofile attribute is not set in session");
	
}
	this.setMsisdn(msisdn);
	
	try{
		con=TSSJavaUtil.instance().getconnection();
	
		
		callCenterManager = new CallCenterManagerBean();
       callCenterManager.setUser(users);
        callCenterManager.setSubscriberProfile(getSubType());

	 int oldStartTime = Integer.parseInt(profileBean.getTimeSet());
	 int oldEndTime = Integer.parseInt(profileBean.getDaySet());
	 String friend = profileBean.getNumber();
	 String nick = profileBean.getFriend();

	 String startTimeArr=profileBean.getStTime();
	 String endTimeArr=profileBean.getEdTime();
	 days = profileBean.getDeleteVal();

	 int groupID = profileBean.getGrpSize();
	 long groupId = (groupID);
	 int rbtCode = profileBean.getRbtId();

	 toneSettings =new ArrayList();
	 toneSettings.clear();

	 int startTime = 100*Integer.parseInt(startTimeArr);
	 int endTime = 100*Integer.parseInt(endTimeArr);

	 if ((startTime == 0000) && (endTime == 2300))
	 {
	  startTime = 2500;
	  endTime = 2500;
	 }

	 if(days.length==7)
	 {
	  ts= new ToneSetting();
	  ts.setDay(8);
	  ts.setStartTime(startTime);
	  ts.setEndTime(endTime);
	  ts.setRbtCode(rbtCode);
	  toneSettings.add(ts);
	 }
	 else
	 {
	  for(int j=0; j<days.length; j++)
	  {
	   ts= new ToneSetting();
	   ts.setDay(Integer.parseInt(days[j],10)+1);
	   ts.setStartTime(startTime);
	   ts.setEndTime(endTime);
	   ts.setRbtCode(rbtCode);
	   toneSettings.add(ts);
	  }
	 }

	 if ((oldStartTime == 0000) && (oldEndTime == 2300))
	 {
	  oldStartTime = 2500;
	  oldEndTime = 2500;
	 }

	String ret = "";

	 ret = callCenterManager.updateSubscriberProfile(msisdn, toneSettings, oldStartTime, oldEndTime, rbtCode, (int)groupId, nick, friend, subProfile, users,con);
	 if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
	 logger.info("this is the return value ....."+ret);
	 actionName="intoUserProfile.action?msisdn="+msisdn+"&subType="+getSubType();
	 this.setMessage(ret);
	}catch(Exception exe)
	{
		logger.error("Exception in updateProfile()...",exe);
		exe.printStackTrace();
		return "failure";
	}
	finally
	{
		subProfile=null;
		callCenterManager = null;
		toneSettings =null;
		ts=null;
		days=null;
		
		 try
		 {
		if(con!=null) if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
		 }
		 catch(Exception exp)
		 {
			 exp.printStackTrace();
		 }
	}
	
	return SUCCESS;
		}
}





// this function is called before the set.jsp for data fetching
public String getDataForSet()
{
	logger.info("Inside function getDataForSet()......................");
	if(!checkSession().equalsIgnoreCase("success")){
		return "error";
		}else{
			
	SubscriberProfile subProfile=null;
	CallCenterManagerBean callCenterManager= null;
	OccasionManager ocman=null;
	 ArrayList  subscriberGroups =null;
	 ArrayList friendSettingsAl = null;
	 ArrayList occasionAl=null;
	 AlbumManager albumManager = null;
	 StringBuffer strbuff =null;
	 ArrayList occasionList= null;
	 
	 	 ProfileSettingBean bean= null;
		 Occasion oc=null;
		 String[] dayVal={"1","2","3","4","5","6","7"};
		 ArrayList dateAl= null;
		 Rbt rbt= null;
		 ArrayList albumListAl= null;
		 AlbumDetails album = null;
	     AlbumDetails alDetails= null;
				 
	Connection con= null;
	String msisdn="";
	String users="";
	msisdn=this.getMsisdn();	
	String retval="failure";
if(sessionMap.isEmpty()||sessionMap==null)
{
	logger.info("you sessionis expired");
	return "logout";
	
}
if(sessionMap.containsKey(msisdn))
{
	
	subProfile=(SubscriberProfile)sessionMap.get(msisdn);
	users=(String)sessionMap.get("user");
	 msisdn=TSSJavaUtil.instance().getInternationalNumber(msisdn);
}else
{
	logger.info("Subscriberprofile attribute is not set in session");
	
}
	this.setMsisdn(msisdn);
	actionName="intoUserProfile.action?msisdn="+msisdn+"&subType="+getSubType();
	try{
		con=TSSJavaUtil.instance().getconnection();
	boolean isCorpUser=false; //if msisdn does not belong to any corporate;

	 if(subProfile.getCorpId()>0) isCorpUser=true;  //if msisdn belongs to a corporate;

	// SubscriberProfileManagerBean subProfileManager = new SubscriberProfileManagerBean();
	 //subProfileManager.setConnectionPool(conPool);
	 callCenterManager= new CallCenterManagerBean();
	 callCenterManager.setSubscriberProfile(getSubType());
	 callCenterManager.setUser(users);
	 
	 ocman=new OccasionManager();
	
	 subscriberGroups = callCenterManager.getGroupsList(msisdn,con);
	 friendSettingsAl = callCenterManager.getFriendsList(msisdn,con);
	 
	 occasionAl=new ArrayList();
	
	 int occheck=ocman.getOccasion(occasionAl,con);

	 long rbtId = profileBean.getRbtId();
	 String rname = profileBean.getRbtName();
	 int showCat = profileBean.getCatId();

	 //String pageno = request.getParameter("pageno");

	 String catDetails = profileBean.getCatName();

	 albumManager = new AlbumManager();
	 strbuff = new StringBuffer();

	 int rbtFound = albumManager.findRbtInAlbums(msisdn, rbtId, strbuff,con);
	 logger.info("rbtFound value"+rbtFound);
	 int val = 0;
	 java.util.ArrayList albumIdName = null;
	 if(rbtFound == 0) // rbt not found in any album, then get all albums
	 {
	  albumIdName = new java.util.ArrayList(5);
	  val = albumManager.getAlbumIdNames(msisdn, "", albumIdName,con);
	 
	 if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
	 int corp=0;
	 String hourArray[]=new String[24];
	 if(isCorpUser)
	 {corp=1;
		 
		 for(int i = 0; i < 24; i++)
         {
             if(i>8 && i<17){}
             else
             {
                 if(i < 10 )
                 {
                	hourArray[i]="0"+i; 
                 }
                 else
                 {
                	 hourArray[i]=""+i;
                 }
             }
             
         }

	 }else
	 {
		 for(int i = 0; i <= 23; i ++)
         {
             if(i<10)
             {
            		hourArray[i]="0"+i;
             }
             else
             {
            		hourArray[i]=""+i;
             }
         }

	 }
	 
	 occasionList= new ArrayList();
	 for(int j=0;j<occasionAl.size();j++)
	 {
		 bean= new ProfileSettingBean();
		 oc=(Occasion)occasionAl.get(j);
		 bean.setOldPass(oc.getOccasionDate()+""+oc.getOccasionName());
		 bean.setEdTime(oc.getOccasionName());
		 occasionList.add(bean);
	 }
	 dateAl= new ArrayList();
	 for(int j=0;j<dayVal.length;j++)
	 {
		 rbt= new Rbt();
		 rbt.setOthers(dayVal[j]);
		 dateAl.add(rbt);
	 }
	 albumListAl= new ArrayList();
	 for(int i=0; i<albumIdName.size(); i++)
     {
      album = (AlbumDetails) albumIdName.get(i);
      
       alDetails= new AlbumDetails();
       if(album.getAlbumName().equalsIgnoreCase("Default"))
                          {
    	   alDetails.setAlbumName(album.getAlbumName());
    	   alDetails.setAlbumId(album.getAlbumId());
                          }
       albumListAl.add(alDetails);
     }
	 
	 profileBean.setGroupSettingList(subscriberGroups);
	 profileBean.setFriendList(friendSettingsAl);
	 profileBean.setOccSetList(occasionList);
	 profileBean.setDeleteVal(hourArray);
	 profileBean.setCatId(showCat);
	 profileBean.setRbtId((int)rbtId);
	 profileBean.setDefSize(corp);
	profileBean.setDefaultList(albumListAl);
	 profileBean.setDateSetList(dateAl);
	 return SUCCESS;
	 
	 }else if(val<0||rbtFound<0)
	 {
		 this.setMessage(getText("someError"));
		 return "error";
	 }else
	 {
		 if(rbtFound==1)
		 {
			 this.setMessage(getText("custcare.rbtExistInAlbum"));//this.setMessage("RBt Already Exist in Album");
			 return "error";
		 }
	 }
	 
	 
	 
	}catch(Exception exe)
	{
		logger.error("Exception in getDataForSet()..",exe);
		exe.printStackTrace();
		return "failure";
	}
	finally
	{
		 subProfile=null;
		 callCenterManager= null;
		 ocman=null;
		 subscriberGroups =null;
		 friendSettingsAl = null;
		 occasionAl=null;
		 albumManager = null;
		 strbuff =null;
		 occasionList= null;
		 
		 	 bean= null;
			 oc=null;
			 dayVal=null;
			 dateAl= null;
			 rbt= null;
			 albumListAl= null;
			 album = null;
		     alDetails= null;
					 
		try
		{
		if(con!=null)
		{
		 if(con!=null)   TSSJavaUtil.instance().freeConnection(con);	
		}
		}
		catch (Exception e) {
		
			e.printStackTrace();
		}
	}

	
	return SUCCESS;
		}
}


// this function is for setting the tone 


public String setTone()
{
	logger.info("Inside function setTone()..................");
	if(!checkSession().equalsIgnoreCase("success")){
		return "error";
		}else{
			
	SubscriberProfile subProfile=null;
	 AlbumManager albumManager = null;
	 CallCenterManagerBean callCenterManager= null;
	 StringTokenizer st =null;
	 ArrayList toneSettings =null;
	 ToneSetting ts =null;
	 
	 
	Connection con= null;
	String msisdn="";
	String users="";
	msisdn=this.getMsisdn();	
	String retval="failure";
if(sessionMap.isEmpty()||sessionMap==null)
{
	logger.info("you sessionis expired");
	return "logout";
	
}
if(sessionMap.containsKey(msisdn))
{
	
	subProfile=(SubscriberProfile)sessionMap.get(msisdn);
	users=(String)sessionMap.get("user");
	 msisdn=TSSJavaUtil.instance().getInternationalNumber(msisdn);
}else
{
	logger.info("Subscriberprofile attribute is not set in session");
	
}
	this.setMsisdn(msisdn);
	try{
	con=TSSJavaUtil.instance().getconnection();
	int rbtCode = profileBean.getRbtId();

    //either albumId will have id (old album) or name(newAlbumName)
    String strAlbumId = profileBean.getAlbumid();
    String sendsms = profileBean.getSms();
    if(sendsms == null) sendsms = "N";
    logger.info("value of sendsms is "+sendsms);

    String ret_str="Str";
    int val = 1;
    int rbt_exist_chk=val;
    if (strAlbumId != null) // add rbt to album
    {
   logger.info("Inside when album id is not null");
   
            albumManager = new AlbumManager();
            //albumManager.setConnectionPool(conPool);
            albumManager.setUser(users);
            albumManager.setSubscriberProfile(getSubType());
            try
            {
                    long albumId = Long.parseLong(strAlbumId);
                    val = albumManager.addRbtAlbum(msisdn, albumId, rbtCode, new StringBuffer().append("null"),con);//last argument is the name for new album else null
            }
            catch(NumberFormatException nfe)
            {
                    strAlbumId = strAlbumId.toUpperCase();
                    val = albumManager.addRbtAlbum(msisdn, 0, rbtCode, new StringBuffer(strAlbumId),con);//last argument is the name for new album else null
            }
    }

    int ret = 0;

    if (val >= 0)
    {
    		callCenterManager= new CallCenterManagerBean();
    		
    		callCenterManager.setSubscriberProfile(getSubType());
    		
            callCenterManager.setUser(users);

            String userSelect = profileBean.getUserSet();
            String timeSelect = profileBean.getTimeSet();
            String daySelect = profileBean.getDaySet();

            String friendMsisdn = profileBean.getFriend();
            String dateSelectArr=profileBean.getMdVal();
            String[] param=dateSelectArr.split("-");
           
            logger.info("date is "+dateSelectArr);

            String startTimeArr=profileBean.getStTime();

            String endTimeArr=profileBean.getEdTime();

            String days[] = profileBean.getDay();

            String groupName = profileBean.getGpname();

            String showCat=Integer.toString(profileBean.getCatId());

            String friendName = profileBean.getCatName();
            String occassionDate = profileBean.getOccname();
            String occName="";
            String eventDate[] = new String[3];
            if(occassionDate!=null)
            {
                    occName=occassionDate.substring(10);
                    occassionDate=occassionDate.substring(0,10);
                    System.out.println("occassionDate= start");
                    System.out.println("occassionDate= "+occassionDate);

                    st = new StringTokenizer(occassionDate,"-");
                    int d1=0;
                    while(st.hasMoreTokens())
                    {
                            eventDate[d1]=st.nextToken();
                            d1++;
                    }
            }

            if (userSelect.equals("friend"))
            {
                    friendMsisdn = friendName;
            }
            long groupId = -1;
         

            if(userSelect.equals("date"))
            {
                ret_str = callCenterManager.setSubscriberDateTone(subProfile, rbtCode,rbt_exist_chk,users,param);
            	}
            else if(userSelect.equals("occasion"))
            {
                ret_str = callCenterManager.setSubscriberDateTone(subProfile, rbtCode,rbt_exist_chk,users,eventDate,occName);
            	}

        else
        {
                toneSettings =new ArrayList();

                int startTime = 2500;
                int endTime = 2500;

                if (timeSelect.equals("timings"))
                {
                        startTime = 100*Integer.parseInt(startTimeArr);
                        endTime = 100*Integer.parseInt(endTimeArr);
                        if ((startTime == 0000) && (endTime == 2300))
                        {
                                startTime = 2500;
                                endTime = 2500;
                        }
                }

                System.out.println(startTime);
                if ((daySelect.equals("allday")) || (days.length == 7))
                {
                        ts = new ToneSetting();
                        ts.setDay(8);
                        ts.setStartTime(startTime);
                        ts.setEndTime(endTime);
                        ts.setRbtCode(rbtCode);
                        toneSettings.add(ts);
                }
                else
                {
                        for(int j=0; j<days.length; j++)
                        {
                                ts= new ToneSetting();
                                ts.setDay(Integer.parseInt(days[j],10));
                                ts.setStartTime(startTime);
                                ts.setEndTime(endTime);
                                ts.setRbtCode(rbtCode);
                                toneSettings.add(ts);
                        }
                }
                if (userSelect.equals("group"))
                {
                        ret_str = callCenterManager.setSubscriberGroupTone(subProfile, toneSettings, rbtCode,rbt_exist_chk,users,groupName);
                }
                else if (userSelect.equals("default"))
                {
                        ret_str = callCenterManager.setSubscriberDefaultTone(subProfile, toneSettings, rbtCode,rbt_exist_chk,users);
                }
                else if (userSelect.equals("friend"))
                {
                    ret_str = callCenterManager.setSubscriberFriendTone(subProfile, toneSettings, rbtCode,rbt_exist_chk,users,friendMsisdn);
                }
                else if (userSelect.equals("mobile"))
                {
                    ret_str = callCenterManager.setSubscriberFriendTone(subProfile, toneSettings, rbtCode,rbt_exist_chk,users,friendMsisdn);
                }
        }
    }
    
    actionName="intoUserProfile.action?msisdn="+msisdn+"&subType="+getSubType();
    logger.info("this is the value return from rule engine"+ret_str);
    this.setMessage(ret_str);
	}catch(Exception exe)
	{
		logger.error("Exception in setTone()..",exe);
		exe.printStackTrace();
		return "failure";
	}
	finally
	{
		subProfile=null;
		 albumManager = null;
		 callCenterManager= null;
		 st =null;
		 toneSettings =null;
		 ts =null;
		try
		{
		if(con!=null) if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	return SUCCESS;
		}
}


	
public String gettingDataForGift()
{
	logger.info("Inside function gettingDataForGift().................... ");
	if(!checkSession().equalsIgnoreCase("success")){
		return "error";
		}else{
			
	//logger.info("inside function changePass()");
	SubscriberProfile subProfile=null;
	CallCenterManagerBean callCenterManager= null;
	
	Connection con= null;
	String msisdn="";
	String users="";
	msisdn=this.getMsisdn();	
	String retval="failure";
if(sessionMap.isEmpty()||sessionMap==null)
{
	logger.info("you sessionis expired");
	return "logout";
	
}
if(sessionMap.containsKey(msisdn))
{
	
	subProfile=(SubscriberProfile)sessionMap.get(msisdn);
	users=(String)sessionMap.get("user");
	 msisdn=TSSJavaUtil.instance().getInternationalNumber(msisdn);
}else
{
	logger.info("Subscriberprofile attribute is not set in session");
	
}
	this.setMsisdn(msisdn);
	
	try
	{
	long rbtId=profileBean.getRbtId();
	int catId=profileBean.getCatId();
	String catName=profileBean.getCatName();
	String rbtName=profileBean.getRbtName();
	logger.info("rbtId ["+rbtId+"] catId["+catId+"] catName["+catName+"] rbtName ["+rbtName+"]");
	//SubscriberProfileManagerBean subProfileManager = new SubscriberProfileManagerBean();
	con=TSSJavaUtil.instance().getconnection();
	callCenterManager= new CallCenterManagerBean();
	callCenterManager.setSubscriberProfile(getSubType());
	callCenterManager.setUser(users);
	  ArrayList friendSettingsAl = callCenterManager.getFriendsList(msisdn,con);
	  if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
	  profileBean.setCatId(catId);
	  profileBean.setRbtId((int)rbtId);
	  profileBean.setRbtName(rbtName);
	  profileBean.setFriendList(friendSettingsAl);
	  profileBean.setRbtName(rbtName);
	  actionName="intoUserProfile.action?msisdn="+msisdn+"&subType="+getSubType();
	}catch(Exception exe)
	{
		logger.error("Exception in gettingDataForGift()...",exe);
		exe.printStackTrace();
		return "failure";
	}finally
	{
		subProfile=null;
		callCenterManager= null;
		
		try{
			if(con!=null)if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	return SUCCESS;
		}
}
	
	
	
// this is the function for gift the rbt 

			public String giftRbt()
				{
					logger.info("inside function giftRbt().................");
					if(!checkSession().equalsIgnoreCase("success")){
						return "error";
						}else{
							
					
					SubscriberProfile subProfile=null;
					CallCenterManagerBean callCenterManager= null;
					Connection con= null;
					String msisdn="";
					String users="";
					msisdn=this.getMsisdn();	
					String retval="failure";
				if(sessionMap.isEmpty()||sessionMap==null)
				{
					logger.info("you sessionis expired");
					return "logout";
					
				}
				if(sessionMap.containsKey(msisdn))
				{
					
					subProfile=(SubscriberProfile)sessionMap.get(msisdn);
					users=(String)sessionMap.get("user");
					 msisdn=TSSJavaUtil.instance().getInternationalNumber(msisdn);
				}else
				{
					logger.info("Subscriberprofile attribute is not set in session");
					
				}
					this.setMsisdn(msisdn);
					try{
					//SubscriberProfileManagerBean subProfileManager = new SubscriberProfileManagerBean();
						callCenterManager= new CallCenterManagerBean();
						callCenterManager.setSubscriberProfile(getSubType());
						callCenterManager.setUser(users);
			        int rbtCode = profileBean.getRbtId();

			        String userSelect = profileBean.getGiftFlag();

			        String friendMsisdn = profileBean.getNumber();

			       String friendName = profileBean.getFriend();
			       logger.info("these are the parameters rbtCode ["+rbtCode+"] userSlect ["+userSelect+"] friend msisdn ["+friendMsisdn+"] friend name ["+friendName+"]");

			        if (userSelect.equals("1"))
			        {
			                friendMsisdn = friendName;
			        }

			        String ret = "";
			        ret = callCenterManager.giftTone(msisdn, friendMsisdn, rbtCode,subProfile);
			        logger.info("this is the return message from rule engine ["+ret+"]");
			        this.setMessage(ret);
			        
					}catch(Exception exe)
					{
						logger.error("Exception in giftRbt()...",exe);
						exe.printStackTrace();
						return "failure";
					}
					finally
					{
						subProfile=null;
						callCenterManager= null;
						try
						{
							if(con!=null)if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
						}
						catch (Exception e) {
							// TODO: handle exception
							e.printStackTrace();
						}
					}
					actionName="intoUserProfile.action?msisdn="+msisdn+"&subType="+getSubType();
					return SUCCESS;
						}
				}
			
	

}
