package com.telemune.vcc.custcare.action;

import java.util.ArrayList;

public class ProfileSettingBean {

	private int catId;
	private String catName;
	private int rbtId;
	private String rbtName;
	private ArrayList friendList= new ArrayList();
	private String friend;
	private String giftFlag;
	private boolean showdel;
	private String userSet;
	private String timeSet;
	private String daySet;
	private String sms;
	private String gpname;
	private String oldPass;
	private ArrayList defaultAdvRbt=new ArrayList();
	
	
	public String getOldPass() {
		return oldPass;
	}
	public void setOldPass(String oldPass) {
		this.oldPass = oldPass;
	}
	public String getGpname() {
		return gpname;
	}
	public void setGpname(String gpname) {
		this.gpname = gpname;
	}

	// these are the list for defaultSetting
	private String modifyLinkVal;
	private String[] deleteVal;
	private String day[];
	private int defSize=0;
	private int frnSize=0;
	private int grpSize=0;
	private int dateSize=0;
	private int occSize=0;
	
	private ArrayList defaultList= new ArrayList();
	private ArrayList friendSettingList=new ArrayList();
	private ArrayList groupSettingList= new ArrayList();
	private ArrayList dateSetList= new ArrayList();
	private ArrayList occSetList= new ArrayList();
	
	private ArrayList advFriendSettingList=new ArrayList();
	private ArrayList advGrpSettingList=new ArrayList();
	
	private String mdVal;
	private ArrayList<String> check;
	private String stTime;
	private String edTime;
	private String albumid;
	
	
	private String occname;
	
	
	
	
	
	
	public ArrayList getDefaultAdvRbt() {
		return defaultAdvRbt;
	}
	public void setDefaultAdvRbt(ArrayList defaultAdvRbt) {
		this.defaultAdvRbt = defaultAdvRbt;
	}
	public ArrayList getAdvFriendSettingList() {
		return advFriendSettingList;
	}
	public void setAdvFriendSettingList(ArrayList advFriendSettingList) {
		this.advFriendSettingList = advFriendSettingList;
	}
	public ArrayList getAdvGrpSettingList() {
		return advGrpSettingList;
	}
	public void setAdvGrpSettingList(ArrayList advGrpSettingList) {
		this.advGrpSettingList = advGrpSettingList;
	}
	public boolean isShowdel() {
		return showdel;
	}
	public void setShowdel(boolean showdel) {
		this.showdel = showdel;
	}
	public String getOccname() {
		return occname;
	}
	public void setOccname(String occname) {
		this.occname = occname;
	}
	public String getAlbumid() {
		return albumid;
	}
	public void setAlbumid(String albumid) {
		this.albumid = albumid;
	}
	public String[] getDay() {
		return day;
	}
	public void setDay(String[] day) {
		this.day = day;
	}
	public String getStTime() {
		return stTime;
	}
	public void setStTime(String stTime) {
		this.stTime = stTime;
	}
	public String getEdTime() {
		return edTime;
	}
	public void setEdTime(String edTime) {
		this.edTime = edTime;
	}

	public ArrayList<String> getCheck() {
		return check;
	}
	public void setCheck(ArrayList<String> check) {
		this.check = check;
	}

	private String[] hourArry;
	
	
	
	public String[] getHourArry() {
		return hourArry;
	}
	public void setHourArry(String[] hourArry) {
		this.hourArry = hourArry;
	}
	public String getMdVal() {
		return mdVal;
	}
	public void setMdVal(String mdVal) {
		this.mdVal = mdVal;
	}
	public ArrayList getDateSetList() {
		return dateSetList;
	}
	public void setDateSetList(ArrayList dateSetList) {
		this.dateSetList = dateSetList;
	}
	public ArrayList getOccSetList() {
		return occSetList;
	}
	public void setOccSetList(ArrayList occSetList) {
		this.occSetList = occSetList;
	}
	public ArrayList getGroupSettingList() {
		return groupSettingList;
	}
	public void setGroupSettingList(ArrayList groupSettingList) {
		this.groupSettingList = groupSettingList;
	}
	public ArrayList getFriendSettingList() {
		return friendSettingList;
	}
	public void setFriendSettingList(ArrayList friendSettingList) {
		this.friendSettingList = friendSettingList;
	}
	public int getDefSize() {
		return defSize;
	}
	public void setDefSize(int defSize) {
		this.defSize = defSize;
	}
	public int getFrnSize() {
		return frnSize;
	}
	public void setFrnSize(int frnSize) {
		this.frnSize = frnSize;
	}
	public int getGrpSize() {
		return grpSize;
	}
	public void setGrpSize(int grpSize) {
		this.grpSize = grpSize;
	}
	public int getDateSize() {
		return dateSize;
	}
	public void setDateSize(int dateSize) {
		this.dateSize = dateSize;
	}
	public int getOccSize() {
		return occSize;
	}
	public void setOccSize(int occSize) {
		this.occSize = occSize;
	}
	
	
	
	
	
	 public String getModifyLinkVal() {
		return modifyLinkVal;
	}
	public void setModifyLinkVal(String modifyLinkVal) {
		this.modifyLinkVal = modifyLinkVal;
	}
	public String[] getDeleteVal() {
		return deleteVal;
	}
	public void setDeleteVal(String[] deleteVal) {
		this.deleteVal = deleteVal;
	}
	public ArrayList getDefaultList() {
		return defaultList;
	}
	public void setDefaultList(ArrayList defaultList) {
		this.defaultList = defaultList;
	}
	public String getUserSet() {
		return userSet;
	}
	public void setUserSet(String userSet) {
		this.userSet = userSet;
	}
	public String getTimeSet() {
		return timeSet;
	}
	public void setTimeSet(String timeSet) {
		this.timeSet = timeSet;
	}
	public String getSms() {
		return sms;
	}
	public void setSms(String sms) {
		this.sms = sms;
	}
	public String getDaySet() {
		return daySet;
	}
	public void setDaySet(String daySet) {
		this.daySet = daySet;
	}
	public String getGiftFlag() {
		return giftFlag;
	}
	public void setGiftFlag(String giftFlag) {
		this.giftFlag = giftFlag;
	}
	private String number;
	
	
	public String getFriend() {
		return friend;
	}
	public void setFriend(String friend) {
		this.friend = friend;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	
	public ArrayList getFriendList() {
		return friendList;
	}
	public void setFriendList(ArrayList friendList) {
		this.friendList = friendList;
	}
	public int getRbtId() {
		return rbtId;
	}
	public void setRbtId(int rbtId) {
		this.rbtId = rbtId;
	}
	public String getRbtName() {
		return rbtName;
	}
	public void setRbtName(String rbtName) {
		this.rbtName = rbtName;
	}
	public int getCatId() {
		return catId;
	}
	public void setCatId(int catId) {
		this.catId = catId;
	}
	public String getCatName() {
		return catName;
	}
	public void setCatName(String catName) {
		this.catName = catName;
	}
	
	
}
