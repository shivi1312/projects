package com.telemune.vcc.custcare.action;

import java.util.HashMap;

public class ProvisioningBean {

	private String msisdn;
	private int id;
	private String sessionNumber;
	private String serviceType="NA";
	private String planId ;
	private String planName;
	private String activeTrigger;
	private int actTrgId ;
	private String actTrgName;
	private String result ;
	private String message ;
	private String roleId;
	private String scope;
	private Boolean notification;
	private Boolean cbcmEnable;
	private String subType;
	private String userType;
	private String lang="1";
	
	

	public String getLang() {
		return lang;
	}
	public void setLang(String lang) {
		this.lang = lang;
	}
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	public String getSubType() {
		return subType;
	}
	public void setSubType(String subType) {
		this.subType = subType;
	}
	public Boolean getNotification() {
		return notification;
	}
	public void setNotification(Boolean notification) {
		this.notification = notification;
	}
	public Boolean getCbcmEnable() {
		return cbcmEnable;
	}
	public void setCbcmEnable(Boolean cbcmEnable) {
		this.cbcmEnable = cbcmEnable;
	}
	public String getScope() {
		return scope;
	}
	public void setScope(String scope) {
		this.scope = scope;
	}
	public String getRoleId() {
		return roleId;
	}
	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	private HashMap<Integer, String> activeTriggerMap= new HashMap<Integer, String>();
	private HashMap<String, String> serviceMap= new HashMap<String, String>();
	private HashMap<Integer, String> ratePlanMap= new HashMap<Integer, String>();
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getSessionNumber() {
		return sessionNumber;
	}
	public void setSessionNumber(String sessionNumber) {
		this.sessionNumber = sessionNumber;
	}
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	public String getServiceType() {
		return serviceType;
	}
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public String getActiveTrigger() {
		return activeTrigger;
	}
	public void setActiveTrigger(String activeTrigger) {
		this.activeTrigger = activeTrigger;
	}
	public HashMap<Integer, String> getActiveTriggerMap() {
		return activeTriggerMap;
	}
	public void setActiveTriggerMap(HashMap<Integer, String> activeTriggerMap) {
		this.activeTriggerMap = activeTriggerMap;
	}
	public HashMap<String, String> getServiceMap() {
		return serviceMap;
	}
	public void setServiceMap(HashMap<String, String> serviceMap) {
		this.serviceMap = serviceMap;
	}
	public HashMap<Integer, String> getRatePlanMap() {
		return ratePlanMap;
	}
	public void setRatePlanMap(HashMap<Integer, String> ratePlanMap) {
		this.ratePlanMap = ratePlanMap;
	}
	public String getPlanId() {
		return planId;
	}
	public void setPlanId(String planId) {
		this.planId = planId;
	}
	public String getActTrgName() {
		return actTrgName;
	}
	public void setActTrgName(String actTrgName) {
		this.actTrgName = actTrgName;
	}
	public int getActTrgId() {
		return actTrgId;
	}
	public void setActTrgId(int actTrgId) {
		this.actTrgId = actTrgId;
	}
	
	
}
