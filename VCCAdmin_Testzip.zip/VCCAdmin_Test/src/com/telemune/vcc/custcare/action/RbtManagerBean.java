package com.telemune.vcc.custcare.action;

import java.util.ArrayList;

public class RbtManagerBean{
	private ArrayList dataList= new ArrayList();
	private int catId;
	private String searchRbt="";
	private String userSet;
	private String group;
	private String friend;
	private String mobile;
	private String adv;//Topmost across all Categories
	private long rbtId;
	private String rbtName="";
	
	//added by varinderpal to search by artist name starts
	private ArrayList dataList1= new ArrayList();
	private String artName="";
	//added by varinderpal to search by artist name starts
	
	private String albumName="";//rbt stored in which album
	private String album="";
	private String newAlbum="";//For new album
	
	//added by varinderpal on 1april 15

	private String searchArtist="";
	private String artistName="";
	
	
	private String date="";
	private String occasion="";
	private String timeSet="";
	private String daysStTime="";
	private String daysEdTime="";
	private String daySet="";
	private String days[];
	
	private long corpId;
	int pageno;
	int total=-1;
	int showing=-1;
	
	
	
public String getSearchArtist() {
	return searchArtist;
}

public void setSearchArtist(String searchArtist) {
	this.searchArtist = searchArtist;
}

	public String getArtistName(){
		return artistName;
	}

	public void setArtistName(String artistName){
		this.artistName = artistName;
	}

//end by varinderpal	
	
	


	public int getShowing() {
		return showing;
	}

	public void setShowing(int showing) {
		this.showing = showing;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	

	public int getPageno() {
		return pageno;
	}

	public void setPageno(int pageno) {
		this.pageno = pageno;
	}

	public long getCorpId() {
		return corpId;
	}

	public void setCorpId(long corpId) {
		this.corpId = corpId;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getOccasion() {
		return occasion;
	}

	public void setOccasion(String occasion) {
		this.occasion = occasion;
	}

	public String getTimeSet() {
		return timeSet;
	}

	public void setTimeSet(String timeSet) {
		this.timeSet = timeSet;
	}

	public String getDaysStTime() {
		return daysStTime;
	}

	public void setDaysStTime(String daysStTime) {
		this.daysStTime = daysStTime;
	}

	public String getDaysEdTime() {
		return daysEdTime;
	}

	public void setDaysEdTime(String daysEdTime) {
		this.daysEdTime = daysEdTime;
	}

	public String getDaySet() {
		return daySet;
	}

	public void setDaySet(String daySet) {
		this.daySet = daySet;
	}

	public String[] getDays() {
		return days;
	}

	public void setDays(String[] days) {
		this.days = days;
	}

	
	
	public String getAlbum() {
		return album;
	}

	public void setAlbum(String album) {
		this.album = album;
	}

	public String getNewAlbum() {
		return newAlbum;
	}

	public void setNewAlbum(String newAlbum) {
		this.newAlbum = newAlbum;
	}

	public String getAlbumName() {
		return albumName;
	}

	public void setAlbumName(String albumName) {
		this.albumName = albumName;
	}

	public long getRbtId() {
		return rbtId;
	}

	public void setRbtId(long rbtId) {
		this.rbtId = rbtId;
	}

	public String getRbtName() {
		return rbtName;
	}

	public void setRbtName(String rbtName) {
		this.rbtName = rbtName;
	}

	//added by varinderpal to search by artist name starts
	
	public String getArtName() {
		return artName;
	}

	public void setArtName(String artName) {
		this.artName = artName;
	}
	
	//added by varinderpal to search by artist name ends
	
	
	
	public String getUserSet() {
		return userSet;
	}

	public void setUserSet(String userSet) {
		this.userSet = userSet;
	}

	public String getGroup() {
		return group;
	}

	public void setGroup(String group) {
		this.group = group;
	}

	public String getFriend() {
		return friend;
	}

	public void setFriend(String friend) {
		this.friend = friend;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getAdv() {
		return adv;
	}

	public void setAdv(String adv) {
		this.adv = adv;
	}

	
	public String getSearchRbt() {
		return searchRbt;
	}

	public void setSearchRbt(String searchRbt) {
		this.searchRbt = searchRbt;
	}

	public int getCatId() {
		return catId;
	}

	public void setCatId(int catId) {
		this.catId = catId;
	}

	public ArrayList getDataList() {
		return dataList;
	}

	public void setDataList(ArrayList dataList) {
		this.dataList = dataList;
	}
	
	
	//added by varinderpal
	public ArrayList getDataList1() {
		return dataList1;
	}

	public void setDataList1(ArrayList dataList1){
		this.dataList1 = dataList1;
	}

	
}
