package com.telemune.vcc.custcare.action;

public class ScopeBean {

	private String ST;
	private String OR;
	private String SC;
	public String getST() {
		return ST;
	}
	public void setST(String sT) {
		ST = sT;
	}
	public String getOR() {
		return OR;
	}
	public void setOR(String oR) {
		OR = oR;
	}
	public String getSC() {
		return SC;
	}
	public void setSC(String sC) {
		SC = sC;
	}
	
}
