package com.telemune.vcc.custcare.action;

import java.util.ArrayList;
import java.util.Iterator;
import org.apache.log4j.Logger;
import com.telemune.dbutilities.Connection;
import com.telemune.vcc.common.SubscriberProfile;
import com.telemune.vcc.common.TSSJavaUtil;
import com.telemune.vcc.common.ValidateAction;
import com.telemune.vcc.custcare.CrbtUtility;
import com.telemune.vcc.custcare.InvalidSearch;
import com.telemune.vcc.custcare.InvalidSearchManager;
import com.telemune.vcc.custcare.SubscriberHistory;

public class SubscriberHistoryManagement extends ValidateAction{
	Logger logger=Logger.getLogger(SubscriberHistoryManagement.class);

	public SubscriberHistoryManagement()
	{
		setLinkName("custcare");
	}
	String message;
	SubscriberHistoryManagementBean historyBean=null;
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public SubscriberHistoryManagementBean getHistoryBean() {
		return historyBean;
	}
	public void setHistoryBean(SubscriberHistoryManagementBean historyBean) {
		this.historyBean = historyBean;
	}


	//This function is for set the history id and sessionNumber
	public String setHistoryInfo()
	{
		logger.info("Inside function setHistoryInfo().....");
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
		}else{

			int id=historyBean.getId();
			String sessionNumber="";
			String text="";
			text=getText("custitle"+id);
			switch(id)
			{
			case 1:
				sessionNumber="950";
				break;
			case 2:
				sessionNumber="951";
				break;
			case 3:
				sessionNumber="952";
				break;
			case 4:
				sessionNumber="953";
				break;
			case 5:
				sessionNumber="954";
				break;
			case 6:
				sessionNumber="956";
				break;
			case 7:
				sessionNumber="957";
				break;
			case 8:
				sessionNumber="958";
				break;
			case 9: sessionNumber="959";        
			break;
			default:
				break;
			}
			logger.info("This is the id ["+id+"]  and  sessionnumber ["+sessionNumber+"] and title ["+text+"]");

			historyBean.setId(id);
			historyBean.setSessionNumber(sessionNumber);
			historyBean.setTitle(text);

			return SUCCESS;
		}

	}


	// this function is for handle the all stats for custcare	
	public String handleHistoryManagement()
	{
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
		}else{
			String msisdn=historyBean.getMsisdn();
			String returnString="failure";
			Connection con=null;
			String[] header = {};
			ArrayList dataListAl=null;
			try{
				msisdn=TSSJavaUtil.instance().getInternationalNumber(msisdn);
				int id=historyBean.getId();
				String title=historyBean.getTitle();
				String retVal="";

				logger.info("Inside function handleSubHistory() where MSISDN ["+msisdn+"]  ID ["+id+"] TITLE ["+title+"]");
				//System.out.println("Inside function handleSubHistory() where MSISDN ["+msisdn+"]  ID ["+id+"] TITLE ["+title+"]");
				// here we are using the switch case for handle the 	
				con=TSSJavaUtil.instance().getconnection();

				
				dataListAl= new ArrayList();
				int headerCount=0;
				// this sets the header of the list

				String head="";
				String[] paramsVal;
				head=this.getText("cusReportHeader"+id);
				logger.info("head from language file is = "+head);
				paramsVal=head.split(",");
				headerCount=paramsVal.length;
				logger.info("Length of header ["+headerCount+"]");
				
				//head from language file is = ﺎﻠﺗﺍﺮﻴﺧ، ﺎﻠﻨﺷﺎﻃ، ﺎﻠﺸﺤﻧ، ﺎﻟﻭﺎﺠﻫﺓ ﺎﻠﻤﺴﺘﺧﺪﻣﺓ، ﺖﻣ ﺖﺣﺪﻴﺜﻫ ﺏﻭﺎﺴﻃﺓ؟؟؟ 
					//	2014-10-31 18:29:33,427 INFO  [SubscriberHistoryManagement] Length of header [1]

			//	System.out.println("Length of header ["+headerCount+"]");
				header=paramsVal;

				//System.out.println(historyBean.getSessionNumber());
				if(sessionMap.containsKey(historyBean.getSessionNumber()))
				{
					//System.out.println("You are authenticated to view this link");
					switch(id)
					{// this case handle the subscription history link
					case 1:		retVal=getHistoryReport(con, msisdn, dataListAl,headerCount);
					returnString="success";
					break;
					// this case handles the modify profile		
					/*	case 2:			logger.info("Inside of modify history");
								break;*/

					// this case is for handle the Rbt change history			
					case 3:     retVal=getRbtChangeHistoryReport(con, msisdn, dataListAl,headerCount);
					returnString="success";
					break;

					// this case handle the  report for IVR - Statistics						
					case 4:		retVal=getIvrStatisticReport(con, msisdn, dataListAl,headerCount);
					returnString="success";
					break;


					// this case handle the report for SMS-Statistics				
					case 5:		retVal=getSmsStatisticReport(con, msisdn, dataListAl,headerCount);
					returnString="success";
					break;

					//this case handle the report for web statistics			
					case 6:		retVal=getWebStatisticsReport(con, msisdn, dataListAl,headerCount);
					returnString="success";
					break;

					// this case handle the report for ussd- statistics
					case 7:		retVal=getUssdStatisticsReport(con, msisdn, dataListAl,headerCount);
					returnString="success";
					break;
					// this case handle the report for user activity
					case 8:		retVal=getUserActivityReport(con, msisdn, dataListAl,headerCount);
					returnString="success";
					break;
					//	this case handles the Searched RBt's Statistics
					case 9: 	retVal=getSearchedRbtStatistics(con, msisdn, dataListAl,headerCount);
					returnString="success";
					break;
					}
				}else
				{
					logger.info("You are not authenticated to view this link");
					returnString="error";

				}

				int size=dataListAl.size();
				logger.info("This is the size of list ["+size+"]");
				if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
				this.setMessage(retVal);
				historyBean.setHeader(header);
				historyBean.setId(id);
				historyBean.setDataAl(dataListAl);
				historyBean.setMsisdn(msisdn);
				historyBean.setSize(size);
				historyBean.setTitle(title);

			}catch(Exception exe)
			{
				logger.info("Their is some exception in handleSubHistory() ",exe);
				exe.printStackTrace();
				return "failure";
			}finally
			{
				header = null;
				dataListAl=null;
				try{
					if(con!=null)if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
				}catch(Exception exe)
				{
					exe.printStackTrace();
				}
			}
			return returnString;
		}
	}


	// this function get the history reports 
	public String getHistoryReport(Connection con,String msisdn,ArrayList dataAl,int headCount)
	{
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
		}else{

			dataAl.clear();
			logger.info("Inside function getHistoryReport()... where MSISDN ["+msisdn+"]");
			String retVal="";
			ArrayList historyAl = new ArrayList();
			StringBuffer status = new StringBuffer();
			CrbtUtility crbtutil= new CrbtUtility();
			SubscriberHistory subHistory=null;
			try{
		
				
			int st = crbtutil.searchHistory(msisdn, historyAl,con);
			String activity="";
			String subType="";
			String interfac="";
			if ((st==1) && (historyAl.size()>0))
			{
				retVal="OK";
				Iterator ite = historyAl.iterator();
				int i=0;
				while(ite.hasNext()) {

					String[] data= new String[headCount];

					subHistory = new SubscriberHistory();
					subHistory = (SubscriberHistory)ite.next();

					if(subHistory.getActivity().equalsIgnoreCase("S")||subHistory.getActivity().equalsIgnoreCase("S30"))
					{
					if (subHistory.getInterface_Type().equalsIgnoreCase("M"))
					activity ="Subscription Renewed";
					else
					activity ="Subscribed";
					}
					else if (subHistory.getActivity().equalsIgnoreCase("S1"))
					activity ="Subscription Renwed One Day";
					else if (subHistory.getActivity().equalsIgnoreCase("S7"))
					activity ="Subscription Renwed One week";
					else if (subHistory.getActivity().equalsIgnoreCase("S14"))
					activity ="Subscription Renwed Two week";
					else if (subHistory.getActivity().equalsIgnoreCase("S21"))
					activity ="Subscription Renwed Three week";
					else if (subHistory.getActivity().equalsIgnoreCase("D"))
					activity ="Deactivated";
					else if (subHistory.getActivity().equalsIgnoreCase("A1"))
					activity ="Activated for one Day";
					else if (subHistory.getActivity().equalsIgnoreCase("A7"))
					activity ="Activated for One week";
					else if (subHistory.getActivity().equalsIgnoreCase("A14"))
					activity ="Activated for Two week";
					else if (subHistory.getActivity().equalsIgnoreCase("A21"))
					activity ="Activated for Three week";
					else if (subHistory.getActivity().equalsIgnoreCase("U"))
					activity ="Unsubscribed";
					else if (subHistory.getActivity().equalsIgnoreCase("A")||subHistory.getActivity().equalsIgnoreCase("A30"))
					activity ="Activated";
					else if (subHistory.getActivity().equalsIgnoreCase("I"))
					activity ="Temporary Suspended";
					else if (subHistory.getActivity().equalsIgnoreCase("R30"))
					activity ="RBT Renewed";



					if(subHistory.getSub_type().equalsIgnoreCase("O"))
						subType ="PostPaid";
					else
						subType ="PrePaid";

					if (subHistory.getInterface_Type().equalsIgnoreCase("C"))
						interfac = "CC";
					if (subHistory.getInterface_Type().equalsIgnoreCase("I"))
						interfac = "IVR";
					if (subHistory.getInterface_Type().equalsIgnoreCase("S"))
						interfac = "SMS";
					if (subHistory.getInterface_Type().equalsIgnoreCase("P"))
						interfac = "WAP";
					if (subHistory.getInterface_Type().equalsIgnoreCase("V"))
						interfac = "* Copy";
					if (subHistory.getInterface_Type().equalsIgnoreCase("M"))
						interfac = "ChgModule";
					if (subHistory.getInterface_Type().equalsIgnoreCase("U"))
						interfac = "USSD";
					if (subHistory.getInterface_Type().equalsIgnoreCase("W")||subHistory.getInterface_Type().equalsIgnoreCase("X"))
						interfac = "Web";
					if (subHistory.getInterface_Type().equalsIgnoreCase("O"))
						interfac = "OBD";

					data[0]=subHistory.getDate();
					data[1]=activity;
					data[2]=subHistory.getWas_charged();
					data[3]=interfac;
					data[4]=subHistory.getUpdate_Type();

					logger.info("This is the dtaa ["+data[0]+"] ["+data[1]+"] ["+data[2]+"] ["+data[3]+"] ["+data[4]+"] ");	  

					dataAl.add(data);

				}	

			}else if(st==1)
			{
				retVal=getText("cusalerthis")+" "+msisdn;

			}else if(st==-2)
			{
				retVal=msisdn+" "+getText("cusalerthis1");
			}else
			{
				retVal=getText("alertunknown");
			}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
			finally
			{
				historyAl = null;
				status = null;
				crbtutil= null;
				subHistory=null;
			}
			logger.info("This is the resultant String ["+retVal+"]");
			return retVal;
		}


	}



	// this function give the details of rbt change of particular msisdn
	public String getRbtChangeHistoryReport(Connection con,String msisdn,ArrayList dataAl ,int headCount)
	{
		logger.info("Inside function getRbtChangeHistoryReport()... where MSISDN ["+msisdn+"]");
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
		}else{

			String retVal="";
			dataAl.clear();
			ArrayList historyAl = new ArrayList();
			CrbtUtility crbtutil= new CrbtUtility();
			SubscriberHistory subHistory = null;
			try{
				int st = crbtutil.searchRbtHistory(msisdn, historyAl,con);
			Iterator ite = historyAl.iterator();
			int i =0;
			String op="";
			String interfac="";
			
			if(st==1)
			{
				retVal="OK";
				while(ite.hasNext()) {

					String[] data=new String[headCount];
					subHistory = new SubscriberHistory();
					subHistory = (SubscriberHistory)ite.next();


					if(subHistory.getActivity().equalsIgnoreCase("4"))
						op ="Added";
					else if(subHistory.getActivity().equalsIgnoreCase("5"))
						op ="Deleted";
					else
						continue;
					if (subHistory.getInterface_Type().equalsIgnoreCase("C"))
						interfac = "CC";  //customer Care
					else if (subHistory.getInterface_Type().equalsIgnoreCase("I"))
						interfac = "IVR";
					else if (subHistory.getInterface_Type().equalsIgnoreCase("S"))
						interfac = "SMS";
					else if (subHistory.getInterface_Type().equalsIgnoreCase("P"))
						interfac = "WAP";
					else if (subHistory.getInterface_Type().equalsIgnoreCase("W"))
						interfac = "Web"; //crbtuser
					else if (subHistory.getInterface_Type().equalsIgnoreCase("U"))
						interfac = "USSD"; //crbtuser
					else if (subHistory.getInterface_Type().equalsIgnoreCase("V"))
						interfac = "* Copy"; //crbtuser
					else if (subHistory.getInterface_Type().equalsIgnoreCase("O"))
						interfac = "OBD"; //crbtuser
					else
						interfac="CRBT";
					data[0]=subHistory.getDate();
					data[1]=subHistory.getRbtCode();
					data[2]=op;
					data[3]=subHistory.getWas_charged();
					data[4]=interfac;
					data[5]=subHistory.getUpdate_Type();
					data[6]=subHistory.getValidityDays();
					dataAl.add(data);
				}

			}else if(st==-2)
			{
				retVal=msisdn+" "+getText("cusalerthis1");
			}else
			{
				retVal=getText("alertunknown");
			}
			}
			catch (Exception e) {
				e.printStackTrace();
				return "failure";
			}
			finally
			{
				historyAl = null;
				crbtutil= null;
				subHistory=null;
			}
			logger.info("This is the resultant String ["+retVal+"]");
			return retVal;
		}

	}


	// this function is for handle the ivr statistics 
	public String getIvrStatisticReport(Connection con,String msisdn,ArrayList dataAl,int headCount)
	{
		logger.info("Inside function getIvrStatisticReport().. where msisdn ["+msisdn+"]");
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
		}else{

			String retVal="";
			dataAl.clear();
			ArrayList historyAl = new ArrayList();
			CrbtUtility crbtutil= new CrbtUtility();
			SubscriberHistory subHistory = null;
			try{
			int st = crbtutil.searchIvrStats(msisdn, historyAl,con);
			if(st==1)
			{
				retVal="OK";

				Iterator ite = historyAl.iterator();
				int i =0;

				while(ite.hasNext()) {
					String[] data=new String[headCount];
					subHistory = new SubscriberHistory();
					subHistory = (SubscriberHistory)ite.next();
					data[0]=subHistory.getDate();
					data[1]=Integer.toString(subHistory.getRequestCount());
					data[2]=Integer.toString(subHistory.getCallduration());
					dataAl.add(data);
				}

			}else if(st==-2)
			{
				retVal=msisdn+" "+getText("cusalerthis1");
			}else
			{
				retVal=getText("alertunknown");
			}
			}catch (Exception e) {
				e.printStackTrace();
				return "failure";
			}
			finally
			{
				historyAl = null;
				crbtutil= null;
				subHistory=null;
			}
			logger.info("This is the resultant String ["+retVal+"]");

			return retVal;
		}
	}


	// this function for handle the sms statistics
	public String getSmsStatisticReport(Connection con,String msisdn,ArrayList dataAl,int headCount)
	{
		logger.info("Inside function getSmsStatisticReport().. where msisdn ["+msisdn+"]");
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
		}else{

			String retVal="";
			dataAl.clear();
			ArrayList historyAl = new ArrayList();
			CrbtUtility crbtutil= new CrbtUtility();
			SubscriberHistory subHistory = null;
			try{
			int st = crbtutil.searchSmsStats(msisdn, historyAl,con);

			if (st == 1) {
				retVal="OK";

				Iterator ite = historyAl.iterator();
				int i =0;
				while(ite.hasNext()) {
					String[] data=new String[headCount];
					subHistory = new SubscriberHistory();
					subHistory = (SubscriberHistory)ite.next();
					data[0]=subHistory.getDate();
					data[1]=subHistory.getRequestMessage();
					data[2]=subHistory.getResponseTime();
					data[3]=subHistory.getResponseMessage();
					dataAl.add(data);
				}

			}else if(st==-2)
			{
				retVal=msisdn+" "+getText("cusalerthis1");
			}else
			{
				retVal=getText("alertunknown");
			}
			}
			catch (Exception e) {
				e.printStackTrace();
				return "failure";
			}
			finally
			{
				historyAl = null;
				crbtutil= null;
				subHistory=null;
			}
			logger.info("This is the resultant String ["+retVal+"]");

			return retVal;
		}

	}


	// this function is handle the web statistics report
	public String getWebStatisticsReport(Connection con,String msisdn,ArrayList dataAl,int headCount)
	{
		logger.info("Inside function getWebStatisticsReport().... ");
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
		}else{

			String retVal="";
			dataAl.clear();
			ArrayList historyAl = new ArrayList();
			CrbtUtility crbtutil= new CrbtUtility();
			SubscriberHistory subHistory = null;
			try{
			int st = crbtutil.searchWebStats(msisdn, historyAl,con);
			String interfac="";
			if (st == 1) {
				retVal="OK";
				Iterator ite = historyAl.iterator();
				int i =0;
				while(ite.hasNext()) 
				{
					String[] data=new String[headCount];
					subHistory = new SubscriberHistory();
					subHistory = (SubscriberHistory)ite.next();
					if (subHistory.getInterface_Type().equalsIgnoreCase("C"))
						interfac = "CC";
					else if (subHistory.getInterface_Type().equalsIgnoreCase("P"))
						interfac = "WAP";
					else if (subHistory.getInterface_Type().equalsIgnoreCase("W"))
						interfac = "Web";
					else if (subHistory.getInterface_Type().equalsIgnoreCase("U"))
						interfac = "USSD";
					else
						interfac="CRBT";
					data[0]=subHistory.getDate();
					data[1]=subHistory.getRequestMessage();
					data[2]=interfac;
					data[3]=subHistory.getUpdate_Type();
					dataAl.add(data);
				}

			}else if(st==-2)
			{
				retVal=msisdn+" "+getText("cusalerthis1");
			}else
			{
				retVal=getText("alertunknown");
			}
			}catch (Exception e) {
				e.printStackTrace();
				return "failure";
			}finally
			{
				historyAl = null;
				crbtutil= null;
				subHistory=null;
			}
			logger.info("This is the resultant String ["+retVal+"]");

			return retVal;
		}

	}


	// this function handles the USSD Statistics
	public String getUssdStatisticsReport(Connection con,String msisdn,ArrayList dataAl,int headCount)
	{
		logger.info("Inside function getUssdStatisticsReport()....");
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
		}else{

			String retVal="";
			dataAl.clear();
			ArrayList historyAl = new ArrayList();
			CrbtUtility crbtutil= new CrbtUtility();
			SubscriberHistory subHistory=null;
			try{
			int st = crbtutil.searchUSSDStats(msisdn, historyAl,con);

			if (st == 1) {
				retVal="OK";
				Iterator ite = historyAl.iterator();
				int i =0;
				while(ite.hasNext()) {
					String[] data=new String[headCount];
					subHistory = new SubscriberHistory();
					subHistory = (SubscriberHistory)ite.next();
					data[0]=subHistory.getDate();
					data[1]=subHistory.getRequestMessage();
					dataAl.add(data);
				}
			}else if(st==-2)
			{
				retVal=msisdn+" "+getText("cusalerthis1");
			}else
			{
				retVal=getText("alertunknown");
			}
			}
			catch (Exception e) {
				e.printStackTrace();
				return "failure";
			}
			finally
			{
				subHistory=null;
			}
			logger.info("This is the resultant String ["+retVal+"]");

			return retVal;
		}

	}



	// this function handle the User Activity statistics

	public String getUserActivityReport(Connection con,String msisdn,ArrayList dataAl,int headCount)
	{
		logger.info("Inside function getUserActivityReport().....");
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
		}else{

			String retVal="";
			dataAl.clear();
			String interface_type="";
			ArrayList historyAl = new ArrayList();
			String interfac = new String("");
			CrbtUtility crbtutil= new CrbtUtility();
			SubscriberHistory subHistory=null;
			try{
			int st = crbtutil.searchActivityStats(msisdn, historyAl,interface_type,con);
			if (st == 1) {
				retVal="OK";
				Iterator ite = historyAl.iterator();
				int i =0;
				while(ite.hasNext()) 
				{
					String[] data=new String[headCount];
					subHistory = new SubscriberHistory();
					subHistory = (SubscriberHistory)ite.next();

					if (subHistory.getInterface_Type().equalsIgnoreCase("C"))
						interfac = "Customer care";
					else if (subHistory.getInterface_Type().equalsIgnoreCase("P")||subHistory.getInterface_Type().equalsIgnoreCase("X"))
						interfac = "WAP";
					else if (subHistory.getInterface_Type().equalsIgnoreCase("W"))
						interfac = "Web";
					else if (subHistory.getInterface_Type().equalsIgnoreCase("I"))
						interfac = "IVR";
					else if (subHistory.getInterface_Type().equalsIgnoreCase("S"))
						interfac = "SMS";
					else if (subHistory.getInterface_Type().equalsIgnoreCase("U"))
						interfac = "USSD";
					else if (subHistory.getInterface_Type().equalsIgnoreCase("T"))
						interfac = "CORP";
					else if (subHistory.getInterface_Type().equalsIgnoreCase("V"))
						interfac = "*COPY";
					else
						interfac ="CRBT System";
					data[0]=subHistory.getDate();
					data[1]=subHistory.getRequestMessage();
					data[2]=interfac;
					data[3]=subHistory.getUpdate_Type();
					dataAl.add(data);
				}
			}else if(st==-2)
			{
				retVal=msisdn+" "+getText("cusalerthis1");
			}else
			{
				retVal=getText("alertunknown");
			}
			}catch (Exception e) {
				e.printStackTrace();
				return "failure";
			}
			finally
			{
				subHistory=null;
			}
			logger.info("This is the resultant String ["+retVal+"]");

			return retVal;
		}
	}

	// this function handles the Searched Rbt's Statistics report
	public String getSearchedRbtStatistics(Connection con,String msisdn,ArrayList dataAl,int headCount)
	{
		logger.info("Inside function getSearchedRbtStatistics().....");
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
		}else{

			String retVal="";
			dataAl.clear();
			InvalidSearch isOb=new InvalidSearch();
			InvalidSearchManager isMOb=new InvalidSearchManager();
			ArrayList isNumAr = new ArrayList();
			try
			{
			int st = isMOb.getInvalidSearch(isNumAr,msisdn,con);
			if(st<0)
			{
				retVal=getText("alertunknown");
			}else
			{
				retVal="OK";
				Iterator ite = isNumAr.iterator();
				int i =0;
				while(ite.hasNext())
				{
					String[] data=new String[headCount];
					isOb = (InvalidSearch)ite.next();
					data[0]=isOb.getSearchlistName();
					data[1]=isOb.getSearchlistDate();
					dataAl.add(data);                   
				}
			}
			}catch (Exception e) {
				e.printStackTrace();
				return "failure";
			}
			finally
			{

				isOb=null;
				isMOb=null;
				isNumAr = null;
			}
			logger.info("This is the resultant String ["+retVal+"]");

			return retVal;
		}

	}

	// this function is for handle modify profile link
	public String handleModifyProfileHistory()
	{
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
		}else{

			String msisdn=historyBean.getMsisdn();
			String retVal="failure";
			logger.info("Inside function handleModifyProfileHistory()....where msisdn [  "+msisdn+"  ]");
			Connection con= null;
			CrbtUtility crbtutil= null;
			SubscriberProfile subscriberProfile = null;
			StringBuffer status = null;
			StringBuffer sub = null;
			try{

				crbtutil= new CrbtUtility() ;
				con=TSSJavaUtil.instance().getconnection();
				subscriberProfile = new SubscriberProfile();
				subscriberProfile.setMsisdn(msisdn);
				status = new StringBuffer("");
				sub = new StringBuffer("");
				msisdn = TSSJavaUtil.instance().getInternationalNumber(msisdn);
				int check = crbtutil.checkStatus(msisdn, status, sub, subscriberProfile,con);
				subscriberProfile.setSubType(sub.toString());
				historyBean.setSubType(sub.toString());
				System.out.println("sub_Type : "+sub.toString());
				if(con!=null)   TSSJavaUtil.instance().freeConnection(con);

				logger.info("status "+status+ " subscribed msisdn= "+msisdn+ " chargingMsisdn="+ subscriberProfile.getChargingMsisdn() +" sub type="+sub+ "/"+subscriberProfile.getSubType());

				if(check==-1)
				{
					this.setMessage(getText("custcare.msisdnNotInRange").replace("$(MSISDN)",msisdn));//this.setMessage(msisdn+"is not in the specified range of CRBT");

				}else if(check==-2)
				{
					this.setMessage(getText("custcare.notSubscriberOfService").replace("$(MSISDN)",msisdn));//this.setMessage(msisdn+"is not subscriber of service");
				}else if(check==1)
				{
					if(status.toString().equalsIgnoreCase("A"))
					{
						sessionMap.put(msisdn, subscriberProfile);
						historyBean.setMsisdn(msisdn);
						this.setMessage("SEND");
					}else if(status.toString().equalsIgnoreCase("I"))
					{
						this.setMessage(getText("custcare.subscriberDeactivate")); //this.setMessage("The subscriber has been deactivated for the service");
					}

				}else if(check==2)
				{
					this.setMessage(getText("custcare.notSubscriberOfService").replace("$(MSISDN)",msisdn));//this.setMessage(msisdn+"is not subscriber of service");
				}
				else if(check==-3)
				{
					this.setMessage(getText("custcare.notSubscriberOfService").replace("$(MSISDN)",msisdn));//this.setMessage(msisdn+"is not subscriber of service");
				}
				else
				{
					this.setMessage(getText("tryLater"));
				}
				retVal="success";
			}catch(Exception exe)
			{
				logger.error("Exception in handleModifyProfileHistory()",exe);
			}finally
			{

				crbtutil= null;
				subscriberProfile = null;
				status = null;
				sub = null;
					if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
			}
			return retVal;
		}
	}


}
