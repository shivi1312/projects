package com.telemune.vcc.custcare.action;

import org.apache.log4j.Logger;

import com.telemune.vcc.common.TSSJavaUtil;
import com.telemune.vcc.common.ValidateAction;
import com.telemune.vcc.custcare.SubscriberHandler;
import com.telemune.vcc.custcare.UserProfile;
import com.telemune.vcc.response.VccRuleEngineResponse;

public class UserProfileAction  extends ValidateAction  {
	static Logger logger=Logger.getLogger(ProfileSettingAction.class);
	private UserProfileBean userProfileBean=new UserProfileBean();
	private String msisdn;
	private UserProfile userProfile=null;
	String message;
	private SubscriberHandler subscriberHandler=null; 
	VccRuleEngineResponse ruleEngineResponse = null;
	
	
	
	
	
	public VccRuleEngineResponse getRuleEngineResponse() {
		return ruleEngineResponse;
	}


	public void setRuleEngineResponse(VccRuleEngineResponse ruleEngineResponse) {
		this.ruleEngineResponse = ruleEngineResponse;
	}


	public String getMessage() {
		return message;
	}


	public void setMessage(String message) {
		this.message = message;
	}


	public UserProfileBean getUserProfileBean() {
		return userProfileBean;
	}


	public void setUserProfileBean(UserProfileBean userProfileBean) {
		this.userProfileBean = userProfileBean;
	}


	public String getMsisdn() {
		return msisdn;
	}


	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}


	public String getUserProfile() {
		
		logger.info("Inside getting user profile msisdn ["+userProfileBean.getMsisdn()+"]");
		int response;
		this.linkName = "custcare";
		//this.id=userProfileBean.getId();
		try
		{
			
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
			}else{
			userProfileBean.setMsisdn(TSSJavaUtil.instance().getInternationalNumber(userProfileBean.getMsisdn()));

				userProfile=new UserProfile();
				response =userProfile.getUserProfile(userProfileBean);
				if (response == -1) {
					return "failure";
				}
				else
				{
					char [] serviceFlag=userProfileBean.getServiceFlag().toCharArray();
				
					if(checkServiceFlag(userProfileBean.getServiceFlag(),9))
					{
						userProfileBean.setNotificationEnable("Enable");
					}else
					{
						userProfileBean.setNotificationEnable("Disable");
					}
					if(checkServiceFlag(userProfileBean.getServiceFlag(),10))
					{
						userProfileBean.setHeaderEnable("Enable");
					}else
					{
						userProfileBean.setHeaderEnable("Disable");
					}
					if(checkServiceFlag(userProfileBean.getServiceFlag(),8))
					{
						userProfileBean.setAlternativeEnable("Enable");
					}else
					{
						userProfileBean.setAlternativeEnable("Disable");
					}
					
					
						logger.info("service type is"+userProfileBean.getServiceType());
					
				}

			}
		}
		catch (Exception e) {
			logger.error("Exception inside getUserProfile(),,,,,", e);
			return "failure";
		}
		finally {
			//userProfileBean = null;
		}
		return "success";
		

	}
	
	
	public String modifyProfile()
	{
		logger.info("Inside modifyProfile() msisdn ["+userProfileBean.getMsisdn()+"] language ["+userProfileBean.getLanguage()+"] reset password ["+userProfileBean.isResetpassword());
		int response = -1;
		try
		{
		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		} else {
			userProfileBean.setMsisdn(TSSJavaUtil.instance().getInternationalNumber(userProfileBean.getMsisdn()));

			userProfile=new UserProfile();
			response =userProfile.updateProfile(userProfileBean);
			if (response == -1) {
				userProfileBean.setResult("failure");
				return "failure";
			}
			else
			{
				userProfileBean.setResult("success");
				this.setMessage(getText("custcare.userProfile.updated"));
			}
		
			
		}
		}
		catch (Exception e) {
			logger.error("Exception inside modifyProfile(),,,,,", e);
			return "failure";
		}
		finally {
			//userProfileBean = null;
		}
		return "success";
		
		
	}
	
	public String getUserProfileInfo()
	{
		logger.info("Inside getting user profile information msisdn ["+userProfileBean.getMsisdn()+"]");
		int response;
		this.linkName = "custcare";
		//this.id=userProfileBean.getId();
		try
		{
			
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
			}else{
				userProfile=new UserProfile();
			userProfileBean.setMsisdn(TSSJavaUtil.instance().getInternationalNumber(userProfileBean.getMsisdn()));
			response=userProfile.getProfileDetail(userProfileBean);
		
			if (response == -1) {
				userProfileBean.setResult("failure");
				return "failure";
			}
			else if(userProfileBean.getSubType().equalsIgnoreCase("O"))
			{
				userProfileBean.setResult("success");
			}
			else
			{
				userProfileBean.setResult("failure");
				userProfileBean.setMessage(getText("custcare.userProfile.notVoiceMailPrepaidSub"));	
			}
			}
			}
		catch (Exception e) {
			logger.error("Exception inside getUserProfileInfo() for msisdn ["+userProfileBean.getMsisdn()+"]"+e.getMessage());
			e.printStackTrace();
			return "failure";
		}
		
		return "success";
		
		

	}
	
	public String changeProfile()
	{
		logger.info("Inside changeProfile() msisdn ["+userProfileBean.getMsisdn()+"] profile ["+userProfileBean.getProfileType()+"] subtype ["+userProfileBean.getSubType()+"]");
		
		try
		{
		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		} else {
			try
			{
			subscriberHandler=new SubscriberHandler();
			userProfileBean.setMsisdn(TSSJavaUtil.instance().getInternationalNumber(userProfileBean.getMsisdn()));
			if (userProfileBean.getSubType().equalsIgnoreCase("O")) {
				String json = subscriberHandler.getProfileChange(userProfileBean.getMsisdn(),userProfileBean.getSubType(),userProfileBean.getProfileType());
				this.ruleEngineResponse = subscriberHandler
						.requestToRuleEngine(json);
				userProfileBean.setResult(ruleEngineResponse.getResult());
				userProfileBean.setMessage(ruleEngineResponse.getMsg());

				logger.info("Getting result from RuleEngine [" +userProfileBean.getResult() + " message ["+userProfileBean.getMessage()+"]");
				}
			else
			{
				logger.info("user is not postpaid subscriber");
				userProfileBean.setResult("failure");

				
			}
			}catch (Exception e) {
					e.printStackTrace();
				}
			}
			
			
		}
		catch (Exception e) {
			logger.error("Exception inside modifyProfile(),,,,,", e);
			return "failure";
		}
		finally {
			//userProfileBean = null;
		}
		return "success";
		
		
	}
	
	public Boolean checkServiceFlag(String serviceFlag, int position) {
		if (serviceFlag != null) {
			char[] sflag = serviceFlag.toCharArray();

			int flag = sflag[position - 1];
			if (flag == 48) // 48 == 0 in Service flag
				return true;
			else
				/*
				 * Changed by Vivek Kumar at 18/04/2016
				 */

				return false;
		} else {
			return false;
		}
	}

}
