package com.telemune.vcc.custcare.action;

import java.util.ArrayList;

public class UserProfileBean {

	private String msisdn;
	private String profileType;
	private String password;
	private String language;
	private String headerEnable;
	private String notificationEnable;
	private String alternativeEnable;
	private String alternativeNumber;
	private String greetingEnable;
	private String serviceFlag;
	private int id;
	private boolean resetpassword;
	private String result;
	private String subType="N";
	private String message;
	
	
	
	
	
	
	
	
	

	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getSubType() {
		return subType;
	}
	public void setSubType(String subType) {
		this.subType = subType;
	}
	public String getGreetingEnable() {
		return greetingEnable;
	}
	public void setGreetingEnable(String greetingEnable) {
		this.greetingEnable = greetingEnable;
	}
	
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	private ArrayList<serviceTypeBean> serviceType;
	
	
	
	
	

	
	public boolean isResetpassword() {
		return resetpassword;
	}
	public void setResetpassword(boolean resetpassword) {
		this.resetpassword = resetpassword;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getHeaderEnable() {
		return headerEnable;
	}
	public void setHeaderEnable(String headerEnable) {
		this.headerEnable = headerEnable;
	}
	public String getNotificationEnable() {
		return notificationEnable;
	}
	public void setNotificationEnable(String notificationEnable) {
		this.notificationEnable = notificationEnable;
	}
	public String getAlternativeEnable() {
		return alternativeEnable;
	}
	public void setAlternativeEnable(String alternativeEnable) {
		this.alternativeEnable = alternativeEnable;
	}
	public String getServiceFlag() {
		return serviceFlag;
	}
	public void setServiceFlag(String serviceFlag) {
		this.serviceFlag = serviceFlag;
	}
	public ArrayList<serviceTypeBean> getServiceType() {
		return serviceType;
	}
	public void setServiceType(ArrayList<serviceTypeBean> serviceType) {
		this.serviceType = serviceType;
	}
	public String getProfileType() {
		return profileType;
	}
	public void setProfileType(String profileType) {
		this.profileType = profileType;
	}
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	
	public String getAlternativeNumber() {
		return alternativeNumber;
	}
	public void setAlternativeNumber(String alternativeNumber) {
		this.alternativeNumber = alternativeNumber;
	}
	@Override
	public String toString() {
		return "UserProfileBean [msisdn=" + msisdn + ", profileType="
				+ profileType + ", language=" + language
				+ ", alternativeNumber=" + alternativeNumber
				+ ", greetingEnable=" + greetingEnable + ", serviceFlag="
				+ serviceFlag + ", subType=" + subType + ", serviceType="
				+ serviceType + "]";
	}
	
	
}
