package com.telemune.vcc.custcare.action;

public class serviceTypeBean {
	
	private String date;
	private String profile;
	private String service;
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getProfile() {
		return profile;
	}
	public void setProfile(String profile) {
		this.profile = profile;
	}
	public String getService() {
		return service;
	}
	public void setService(String service) {
		this.service = service;
	}
	@Override
	public String toString() {
		return "serviceTypeBean [date=" + date + ", profile=" + profile
				+ ", serviceType=" + service + "]";
	}
	
	

}
