package com.telemune.vcc.locale;

import com.opensymphony.xwork2.ActionSupport;
import com.telemune.vcc.reports.ReportMetadata;
import com.telemune.vcc.reports.ReportMetadataCache;

public class LocaleAction extends ActionSupport{
 
	//business logic
	@Override
	public String execute() {
		ReportMetadataCache metadataCache=null;
		ReportMetadata rm=null;
		try{
		ReportMetadataCache.reload();
		metadataCache= ReportMetadataCache.getInstance(); 
		 for(int i=0;i<metadataCache.getReportCount();i++)
		 {
		 	rm=metadataCache.getReportMetadata(i);
		 	rm.setReportTitle(getText(rm.getReportTitle()));
		 	System.out.println(getText(rm.getReportTitle()));
		 	String[] temp1=rm.getReportHeaders();
		 	String[] temp2=new String[temp1.length];
		 	for(int x=0;x<temp1.length;x++)
		 	{
		 		temp2[x]=getText(temp1[x]);
		 	}
		 	rm.setReportHeaders(temp2);
		 }
		}catch (Exception e) {
			e.printStackTrace();
		}
		finally
		{
			rm=null;
			metadataCache=null;
			
		}
		return "SUCCESS";
	}
}