package com.telemune.vcc.operationAndMaintainance;

public class ApplicationBean {
	
	private String applicationName;
	
	private String loggerFilePath;
	
	private String recommendedLoggerLevel;

	public String getRecommendedLoggerLevel() {
		return recommendedLoggerLevel;
	}

	public void setRecommendedLoggerLevel(String recommendedLoggerLevel) {
		this.recommendedLoggerLevel = recommendedLoggerLevel;
	}

	public String getApplicationName() {
		return applicationName;
	}

	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}

	public String getLoggerFilePath() {
		return loggerFilePath;
	}

	public void setLoggerFilePath(String loggerFilePath) {
		this.loggerFilePath = loggerFilePath;
	}
}
