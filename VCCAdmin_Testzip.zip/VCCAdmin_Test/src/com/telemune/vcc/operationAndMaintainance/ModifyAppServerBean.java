package com.telemune.vcc.operationAndMaintainance;

public class ModifyAppServerBean {
	
	private String serverName;
	
	private String serverIP;
	
	private String serverPort;
	
	private String applicationName;
	
	private String loggerFilePath;
	
	private String recommendedLoggerLevel;

	public String getRecommendedLoggerLevel() {
		return recommendedLoggerLevel;
	}

	public void setRecommendedLoggerLevel(String recommendedLoggerLevel) {
		this.recommendedLoggerLevel = recommendedLoggerLevel;
	}

	public String getServerName() {
		return serverName;
	}

	public void setServerName(String serverName) {
		this.serverName = serverName;
	}

	public String getServerIP() {
		return serverIP;
	}

	public void setServerIP(String serverIP) {
		this.serverIP = serverIP;
	}

	public String getServerPort() {
		return serverPort;
	}

	public void setServerPort(String serverPort) {
		this.serverPort = serverPort;
	}

	public String getApplicationName() {
		return applicationName;
	}

	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}

	public String getLoggerFilePath() {
		return loggerFilePath;
	}

	public void setLoggerFilePath(String loggerFilePath) {
		this.loggerFilePath = loggerFilePath;
	}
}
