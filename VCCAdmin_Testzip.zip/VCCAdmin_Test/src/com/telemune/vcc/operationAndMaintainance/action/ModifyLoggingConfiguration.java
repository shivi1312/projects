package com.telemune.vcc.operationAndMaintainance.action;


import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Map;

import org.apache.log4j.Logger;

import com.telemune.operationAndMaintainance.logConfigurator.LogConfigurator;
import com.telemune.operationAndMaintainance.logConfigurator.model.Server;
import com.telemune.vcc.common.ValidateAction;

public class ModifyLoggingConfiguration extends ValidateAction {


	private static final long serialVersionUID = 1L;

	private Logger logger=Logger.getLogger(ModifyLoggingConfiguration.class);
	
	private LogConfigurator logConfigurator=new LogConfigurator();
	
	private String physicalPathOnSystem="/home/richard/development/workspace_vcc/VCCAdmin/src/logInfo.json";
	
	private String serverIP;
	
	private String serverPort;
	
	private String loggerFilePath;
	
	private String logLevel;
	
	private String applicationName;
	
	private InputStream inputStream;
	
	public InputStream getInputStream() {
		return inputStream;
	}

	public void setInputStream(InputStream inputStream) {
		this.inputStream = inputStream;
	}

	public String getApplicationName() {
		return applicationName;
	}

	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}

	public String getServerIP() {
		return serverIP;
	}

	public void setServerIP(String serverIP) {
		this.serverIP = serverIP;
	}

	public String getServerPort() {
		return serverPort;
	}

	public void setServerPort(String serverPort) {
		this.serverPort = serverPort;
	}

	public String getLoggerFilePath() {
		return loggerFilePath;
	}

	public void setLoggerFilePath(String loggerFilePath) {
		this.loggerFilePath = loggerFilePath;
	}

	public String getLogLevel() {
		return logLevel;
	}

	public void setLogLevel(String logLevel) {
		this.logLevel = logLevel;
	}

	public ModifyLoggingConfiguration()
	{
		setLinkName("operationAndMaintainence");
	}
	
	@SuppressWarnings("unchecked")
	public String modifyLogging() {
		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		} else {
			String jsonFilePath = new ModifyLoggingConfiguration().getClass()
					.getClassLoader().getResource("logInfo.json").getFile();
			Map<String,Object> map=logConfigurator.getConfigurationDetails(jsonFilePath);
			ArrayList<Server> serverList = (ArrayList<Server>) map
					.get("serverList");
			sessionMap.put("serverList", serverList);
			return "success";
		}
	}
	
	public String modifyLogJsonData() {
		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		} else {
			String message = "";
			try {
			boolean isModified = logConfigurator
						.modifyLogLevel(
								getServerIP(),
								getServerPort(),getApplicationName(),
								getLoggerFilePath(),getLogLevel());

				if (isModified)
					message = "Data Modified Successfully.";
				else
					message = "Failure in data modification.\nPlease try again later.";
				inputStream = new ByteArrayInputStream(message.getBytes());
				} catch (Exception e) {
				logger.error("Exception occured while modifying configurations. ServerIP["
						+ getServerIP()
						+ "] ServerPort["
						+ getServerPort()
						+ "] ApplicationName["
						+ getApplicationName()
						+ "] LoggerFilePath[" + getLoggerFilePath() + "]");
			}
			return "success";
		}
	}
	
	
	
}
