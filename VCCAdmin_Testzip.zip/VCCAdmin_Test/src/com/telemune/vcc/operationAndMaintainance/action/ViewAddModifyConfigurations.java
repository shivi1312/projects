package com.telemune.vcc.operationAndMaintainance.action;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.telemune.operationAndMaintainance.logConfigurator.LogConfigurator;
import com.telemune.operationAndMaintainance.logConfigurator.model.Server;
import com.telemune.vcc.common.ValidateAction;
import com.telemune.vcc.operationAndMaintainance.ApplicationBean;
import com.telemune.vcc.operationAndMaintainance.ModifyAppServerBean;
import com.telemune.vcc.operationAndMaintainance.ServerBean;

public class ViewAddModifyConfigurations extends ValidateAction {

	private static final long serialVersionUID = 1L;

	private Logger logger = Logger.getLogger(ModifyLoggingConfiguration.class);

	private LogConfigurator logConfigurator = new LogConfigurator();

	private String physicalPathOnSystem = "/home/richard/development/workspace_vcc/VCCAdmin/src/logInfo.json";

	private String message;

	private ServerBean serverBean;

	private ApplicationBean applicationBean;

	private ModifyAppServerBean modifyAppServerBean;

	private String jsonData;

	private InputStream inputStream;

	public InputStream getInputStream() {
		return inputStream;
	}

	public String getJsonData() {
		return jsonData;
	}

	public void setJsonData(String jsonData) {
		this.jsonData = jsonData;
	}

	public ModifyAppServerBean getModifyAppServerBean() {
		return modifyAppServerBean;
	}

	public void setModifyAppServerBean(ModifyAppServerBean modifyAppServerBean) {
		this.modifyAppServerBean = modifyAppServerBean;
	}

	public ApplicationBean getApplicationBean() {
		return applicationBean;
	}

	public void setApplicationBean(ApplicationBean applicationBean) {
		this.applicationBean = applicationBean;
	}

	public ServerBean getServerBean() {
		return serverBean;
	}

	public void setServerBean(ServerBean serverBean) {
		this.serverBean = serverBean;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@SuppressWarnings("unchecked")
	public String getConfigurations() {
		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		} else {
			String jsonFilePath = new ViewAddModifyConfigurations().getClass()
					.getClassLoader().getResource("logInfo.json").getFile();
			Map<String, Object> map = logConfigurator
					.viewLogging(physicalPathOnSystem);
			ArrayList<Server> serverList = (ArrayList<Server>) map
					.get("serverList");
			sessionMap.put("serverList", serverList);
			System.out.println("Message : " + getMessage());
			return "success";
		}
	}

	@SuppressWarnings("unchecked")
	public String viewLoggingConfigurations() {
		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		} else {
			String jsonFilePath = new ViewAddModifyConfigurations().getClass()
					.getClassLoader().getResource("logInfo.json").getFile();
			Map<String, Object> map = logConfigurator.viewLogging(jsonFilePath);
			ArrayList<Server> serverList = (ArrayList<Server>) map
					.get("serverList");
			sessionMap.put("serverList", serverList);
			return "success";
		}
	}

	public String addNewServerConfigurationInJson() {
		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		} else {
			String jsonFilePath = new ViewAddModifyConfigurations().getClass()
					.getClassLoader().getResource("logInfo.json").getFile();

			String isServerAdded = logConfigurator
					.addNewServerConfigurationInJson(physicalPathOnSystem,
							getServerBean().getServerName(), getServerBean()
									.getServerIP(), getServerBean()
									.getServerPort());
			setMessage(isServerAdded);
			return "success";
		}
	}

	public String addApplicationConfigInJson() {
		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		} else {
			String jsonFilePath = new ViewAddModifyConfigurations().getClass()
					.getClassLoader().getResource("logInfo.json").getFile();

			logger.info(physicalPathOnSystem + ","
					+ getServerBean().getServerName() + ","
					+ getServerBean().getServerIP() + ","
					+ getApplicationBean().getApplicationName() + ","
					+ getApplicationBean().getLoggerFilePath()+","+getApplicationBean().getRecommendedLoggerLevel());

			String isApplicationAdded = logConfigurator
					.addApplicationConfigInJson(physicalPathOnSystem,
							getServerBean().getServerName(), getServerBean()
									.getServerIP(), getApplicationBean()
									.getApplicationName(), getApplicationBean()
									.getLoggerFilePath(),getApplicationBean().getRecommendedLoggerLevel());
			setMessage(isApplicationAdded);
			return "success";
		}
	}

	public String modifyLoggingConfigurations() {
		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		} else {

			String jsonFilePath = new ViewAddModifyConfigurations().getClass()
					.getClassLoader().getResource("logInfo.json").getFile();

			Map<String, String> oldDataMap = new HashMap<String, String>();
			oldDataMap.put("serverName", getServerBean().getServerName());
			oldDataMap.put("serverIP", getServerBean().getServerIP());
			oldDataMap.put("serverPort", getServerBean().getServerPort());
			oldDataMap.put("applicationName", getApplicationBean()
					.getApplicationName());
			oldDataMap.put("loggerFilePath", getApplicationBean()
					.getLoggerFilePath());
			oldDataMap.put("recommendedLoggerLevel", getApplicationBean()
					.getRecommendedLoggerLevel());
			
			
			Map<String, String> newDataMap = new HashMap<String, String>();
			newDataMap.put("serverName", getModifyAppServerBean()
					.getServerName());
			newDataMap.put("serverIP", getModifyAppServerBean().getServerIP());
			newDataMap.put("serverPort", getModifyAppServerBean()
					.getServerPort());
			newDataMap.put("applicationName", getModifyAppServerBean()
					.getApplicationName());
			newDataMap.put("loggerFilePath", getModifyAppServerBean()
					.getLoggerFilePath());
			newDataMap.put("recommendedLoggerLevel", getModifyAppServerBean().getRecommendedLoggerLevel());
			
			boolean isModified = logConfigurator.modifyLoggingConfigurations(
					physicalPathOnSystem, oldDataMap, newDataMap);

			return "success";
		}
	}

	public String removeConfiguration() {
		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		} else {
			logger.info(getJsonData());
			
			String message = "";
			try {
				logger.info(getJsonData());
				boolean isRemoved = logConfigurator.removeConfiguration(
						physicalPathOnSystem, getJsonData());

				if (isRemoved)
					message = "Data Removed Successfully.";
				else
					message = "Failure in data removal.\nPlease try again later.";
				inputStream = new ByteArrayInputStream(message.getBytes());
				} catch (Exception e) {
				logger.error("Exception occured while removing configuration. Data["+getJsonData()+"]");
			}
			return "success";
		}
	}

}
