package com.telemune.vcc.reports;

public class DateStruct
{
    public int dd;
    public int mm;
    public int yy;
    public int hh;
    public int mi;
    public void DateStruct ()
    {
        dd=0;
        mm=0;
        yy=0;
        hh=0;
        mi=0;
    }
    public void DateStruct (int dd, int mm, int yy, int hh, int mi)
    {
        this.dd=dd;
        this.mm=mm;
        this.yy=yy;
        this.hh=hh;
        this.mi=mi;
    }
    public void DateStruct (int dd, int mm, int yy)
    {
        this.dd=dd;
        this.mm=mm;
        this.yy=yy;
        this.hh=0;
        this.mi=0;
    }
}
