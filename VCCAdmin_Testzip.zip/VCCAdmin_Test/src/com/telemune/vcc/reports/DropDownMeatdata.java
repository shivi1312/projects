package com.telemune.vcc.reports;

import java.util.ArrayList;

public class DropDownMeatdata
{
	ArrayList<DropDown> dropDownList;
	String queryId;
	String type;
	String columnCon;
	
	
	public String getColumnCon() {
		return columnCon;
	}
	public void setColumnCon(String columnCon) {
		this.columnCon = columnCon;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public ArrayList<DropDown> getDropDownList() {
		return dropDownList;
	}
	public void setDropDownList(ArrayList<DropDown> dropDownList) {
		this.dropDownList = dropDownList;
	}
	public String getQueryId() {
		return queryId;
	}
	public void setQueryId(String queryId) {
		this.queryId = queryId;
	}
	@Override
	public String toString() {
		return "DropDownMeatdata [dropDownList=" + dropDownList + ", queryId="
				+ queryId + ", type=" + type + ", columnCon=" + columnCon + "]";
	}
	

}
