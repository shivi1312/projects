package com.telemune.vcc.reports;

import java.util.Date;

public class MediaStatBean {
private Date time;
private String media1;
private String media4;
private String media3;
private String media2;
private String media5;
public Date getTime() {
	return time;
}
public void setTime(Date time) {
	this.time = time;
}
public String getMedia1() {
	return media1;
}
public void setMedia1(String media1) {
	this.media1 = media1;
}
public String getMedia4() {
	return media4;
}
public void setMedia4(String media4) {
	this.media4 = media4;
}
public String getMedia3() {
	return media3;
}
public void setMedia3(String media3) {
	this.media3 = media3;
}
public String getMedia2() {
	return media2;
}
public void setMedia2(String media2) {
	this.media2 = media2;
}
public String getMedia5() {
	return media5;
}
public void setMedia5(String media5) {
	this.media5 = media5;
}
@Override
public String toString() {
	return "MediaStatBean [time=" + time + ", media1=" + media1 + ", media4="
			+ media4 + ", media3=" + media3 + ", media2=" + media2
			+ ", media5=" + media5 + "]";
}



}
