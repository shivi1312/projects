package com.telemune.vcc.reports;

import java.util.Arrays;
import java.util.HashMap;

import com.telemune.vcc.common.TSSJavaUtil;


public class ReportBean 
{
	private int linkId,duration,code;
    private int id;
	private String start;
	private String end;
	private String fileName;
	private String[] format=null;
	private String[] agge=null;
	private String title,selectValues;
    private  String[] type; 
  //  private  String[] optionalSelect;
    private String defaultType="Current";
    private HashMap<String,DropDownMeatdata> dropDownMap;
    private String[] reportHeaders;
	private boolean download=false;
	private String aggeValue=null;
	
	
	
	
	
	public String getAggeValue() {
		return aggeValue;
	}

	public void setAggeValue(String aggeValue) {
		this.aggeValue = aggeValue;
	}

	public int getLinkId() {
		return linkId;
	}

	public void setLinkId(int linkId) {
		this.linkId = linkId;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public void setSelectValues(String selectValues) {
		this.selectValues = selectValues;
	}

	public boolean isDownload() {
		return download;
	}

	public void setDownload(boolean download) {
		this.download = download;
	}

	public String getSelectValues() {
		return selectValues;
	}

	public HashMap<String, DropDownMeatdata> getDropDownMap() {
		return dropDownMap;
	}
	public void setDropDownMap(HashMap<String, DropDownMeatdata> dropDownMap) {
		this.dropDownMap = dropDownMap;
	}
	public String[] getReportHeaders() {
		return reportHeaders;
	}
	public void setReportHeaders(String[] reportHeaders) {
		this.reportHeaders = reportHeaders;
	}
	public String getDefaultType() {
		return defaultType;
	}
	public void setDefaultType(String defaultType) {
		this.defaultType = defaultType;
	}
	public String[] getType() {
		return type;
	}
	public void setType(String[] type) {
		this.type = type;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getStart()
	{
		return start;
	}
	public void setStart(String start) {
		this.start = start;
	}
	public String getEnd() {
		return end;
	}
	public void setEnd(String end) {
		this.end = end;
	}

	public String[] getFormat() {
		return format;
	}
	public void setFormat(String[] format) {
		this.format = format;
	}
	public String[] getAgge() {
		return agge;
	}
	public void setAgge(String[] agge) {
		this.agge = agge;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Override
	public String toString() {
		return "ReportBean [id=" + id + ", start=" + start + ", end=" + end
				+ ", format=" + Arrays.toString(format) + ", agge="
				+ Arrays.toString(agge) + ", title=" + title + ", type="
				+ Arrays.toString(type) + ", duration = "+duration+", defaultType=" + defaultType
				+ ", dropDownMap=" + dropDownMap + ", reportHeaders="
				+ Arrays.toString(reportHeaders) + "]";
	}
	


}
