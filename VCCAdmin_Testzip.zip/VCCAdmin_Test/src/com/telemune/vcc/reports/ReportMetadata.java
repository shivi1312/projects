package com.telemune.vcc.reports;

import java.util.Arrays;
import java.util.HashMap;

public class ReportMetadata
{
	private int reportId;
	private String[] reportHeaders;
	private String reportTitle;
	private String currentQuery;
	private String archiveQuery;
    private int  sessionId;
	private String[] reportAggr;
	private String[] reportFormat;
	private HashMap<String,DropDownMeatdata> dropDownMap;



	


	public HashMap<String,DropDownMeatdata> getDropDownMap() {
		return dropDownMap;
	}


	public void setDropDownMap(HashMap<String,DropDownMeatdata> dropDownMap) {
		this.dropDownMap = dropDownMap;
	}


	public String[] getReportAggr() {
		return reportAggr;
	}


	public void setReportAggr(String[] reportAggr) {
		this.reportAggr = reportAggr;
	}


	public String[] getReportFormat() {
		return reportFormat;
	}


	public void setReportFormat(String[] reportFormat) {
		this.reportFormat = reportFormat;
	}


	public int getSessionId() {
	return sessionId;
}


public void setSessionId(int sessionId) {
	this.sessionId = sessionId;
}


	


	public ReportMetadata(int reportId, String[] reportHeaders, String reportTitle,
		String currentQuery, String archiveQuery, int sessionId,
		String[] reportAggr, String[] reportFormat,HashMap<String,DropDownMeatdata> dropDownMap) {
	super();
	this.reportId = reportId;
	this.reportHeaders = reportHeaders;
	this.reportTitle = reportTitle;
	this.currentQuery = currentQuery;
	this.archiveQuery = archiveQuery;
	this.sessionId = sessionId;
	this.reportAggr = reportAggr;
	this.reportFormat = reportFormat;
	this.dropDownMap=dropDownMap;
}


	public String[] getReportHeaders() {
		return reportHeaders;
	}


	public void setReportHeaders(String[] reportHeaders) {
		this.reportHeaders = reportHeaders;
	}




	public String getReportTitle() {
		return reportTitle;
	}


	public void setReportTitle(String reportTitle) {
		this.reportTitle = reportTitle;
	}


	public String getCurrentQuery() {
		return currentQuery;
	}


	public void setCurrentQuery(String currentQuery) {
		this.currentQuery = currentQuery;
	}


	public String getArchiveQuery() {
		return archiveQuery;
	}


	public void setArchiveQuery(String archiveQuery) {
		this.archiveQuery = archiveQuery;
	}


	public int getReportId() {
		return reportId;
	}


	public void setReportId(int reportId) {
		this.reportId = reportId;
	}


	@Override
	public String toString() {
		return "ReportMetadata [reportId=" + reportId + ", reportHeaders="
				+ Arrays.toString(reportHeaders) + ", reportTitle="
				+ reportTitle + ", currentQuery=" + currentQuery
				+ ", archiveQuery=" + archiveQuery + "]";
	}










}
