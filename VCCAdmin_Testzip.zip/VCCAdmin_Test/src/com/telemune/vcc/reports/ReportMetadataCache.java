package com.telemune.vcc.reports;

import com.telemune.dbutilities.Connection;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Hashtable;
import org.apache.log4j.Logger;

import com.telemune.dbutilities.PreparedStatement;
import com.telemune.vcc.custcare.MailBoxHistoryBean;

public class ReportMetadataCache 
{
	private static  ReportMetadataCache instance;
	//private static ArrayList<Integer> reportLinks= new ArrayList<Integer>();
	private static Hashtable<Integer, ReportMetadata> metadata=null;
	private int reportsCount=0;
	static Logger  logger=Logger.getLogger(ReportMetadataCache.class);
	
	public static synchronized ReportMetadataCache getInstance()
	{
		logger.info("Instance of ReportMetadataCache created.............");
		if(instance==null)
		{
		//	instance=new ReportMetadataCache();
			//instance.InitializeMetadata();
		}
		
		return instance;
	}
	
	public static void reload()
	{
			instance =null;
			metadata=null;
		//	instance=new ReportMetadataCache();
			//instance.InitializeMetadata();
	}
	
	public   ReportMetadata getReportMetadata(int id)
	{
		logger.debug("In getReportMetadata Id:"+id);
		//logger.debug("metadata.containsKey(id)  "+metadata.containsKey(id));
		if(metadata.containsKey(id))
		{
			return metadata.get(id);

		}
		return null;

	}
	public int searchVNMailBoxHistory(ArrayList historyAl,Connection con){

		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String query="";
		logger.info("Inside function searchMailBoxHistory() ");
		try 
		{
			query = "select PREPAID_DEFAULT,POSTPAID_DEFAULT,REPORT_DATE from vcc_mailbox_stats";			
			pstmt = con.prepareStatement(query);
			logger.info("DB Query ::"+query);
			rs = pstmt.executeQuery();

			while (rs.next())
			{
				MailBoxHistoryBean mailBoxHistory = new MailBoxHistoryBean();
				mailBoxHistory.setPre_default(rs.getInt("PREPAID_DEFAULT"));
				mailBoxHistory.setPost_default(rs.getInt("POSTPAID_DEFAULT"));
				mailBoxHistory.setReport_date(rs.getString("REPORT_DATE"));
				
				
				historyAl.add(mailBoxHistory);
			}
			logger.info("size of list is "+historyAl.size());
			
			
			if (rs != null) rs.close();
			if (pstmt != null) pstmt.close();

		}
		catch (Exception sqle)
		{
			logger.info("Exception inside searchMailBoxHistory()"+sqle.getMessage());
			try {
				if (rs != null) rs.close();
				if (pstmt != null) pstmt.close();
			} catch (Exception exp) {}
			sqle.printStackTrace();
			return 0;
		}
		finally
		{
			try {
				if (rs != null) rs.close();
				if (pstmt != null) pstmt.close();
			} catch (Exception exp) {}
		}
		return 1;

	
		
	}
	// Added by swati Goel for showing MAILBox Stats.
	
		public int searchMailBoxHistory(ArrayList historyAl,Connection con){
			
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			String query="";
			logger.info("Inside function searchMailBoxHistory() ");
			try 
			{
				query = "select * from vcc_mailbox_stats";			
				pstmt = con.prepareStatement(query);
				logger.info("DB Query ::"+query);
				rs = pstmt.executeQuery();

				while (rs.next())
				{
					MailBoxHistoryBean mailBoxHistory = new MailBoxHistoryBean();
					mailBoxHistory.setPre_basic(rs.getInt("PREPAID_BASIC"));
					mailBoxHistory.setPre_basic_block(rs.getInt("PREPAID_BASIC_BLOCK"));
					mailBoxHistory.setPost_basic(rs.getInt("POSTPAID_BASIC"));
					mailBoxHistory.setPost_basic_block(rs.getInt("POSTPAID_BASIC_BLOCK"));
					mailBoxHistory.setPost_exe(rs.getInt("POSTPAID_EXECUTIVE"));
					mailBoxHistory.setPost_exe_block(rs.getInt("POSTPAID_EXECUTIVE_BLOCK"));
					mailBoxHistory.setFixed(rs.getInt("PSTN"));
					mailBoxHistory.setFixed_block(rs.getInt("PSTN_BLOCK"));
					mailBoxHistory.setElife(rs.getInt("ELIFE"));
					mailBoxHistory.setElife_block(rs.getInt("ELIFE_BLOCK"));
					mailBoxHistory.setReport_date(rs.getString("REPORT_DATE"));
					
					
					historyAl.add(mailBoxHistory);
				}
				logger.info("size of list is "+historyAl.size());
				
				
				if (rs != null) rs.close();
				if (pstmt != null) pstmt.close();

			}
			catch (Exception sqle)
			{
				logger.info("Exception inside searchMailBoxHistory()"+sqle.getMessage());
				try {
					if (rs != null) rs.close();
					if (pstmt != null) pstmt.close();
				} catch (Exception exp) {}
				sqle.printStackTrace();
				return 0;
			}
			finally
			{
				try {
					if (rs != null) rs.close();
					if (pstmt != null) pstmt.close();
				} catch (Exception exp) {}
			}
			return 1;

		}
			
	
	
	public int getMediaCurrentStat(MediaStatBean mediaBean,Connection con){
			
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			String query="";
			logger.info("Inside function getMediaCurrentStat() ");
			try 
			{
				query = " select * from vcc_media_caps where time=(select max(time) from vcc_media_caps)";			
				pstmt = con.prepareStatement(query);
				logger.info("DB Query ::"+query);
				rs = pstmt.executeQuery();

				while (rs.next())
				{				
					mediaBean.setTime(rs.getDate("time"));
					mediaBean.setMedia1(rs.getString("mg01"));
					mediaBean.setMedia2(rs.getString("mg02"));
					mediaBean.setMedia3(rs.getString("mg03"));
					mediaBean.setMedia4(rs.getString("mg04"));
					mediaBean.setMedia5(rs.getString("mg05"));
					}
				logger.info("size of list is "+mediaBean.toString());
				
				
				if (rs != null) rs.close();
				if (pstmt != null) pstmt.close();

			}
			catch (Exception sqle)
			{
				logger.info("Exception inside getMediaCurrentStat()"+sqle.getMessage());
				try {
					if (rs != null) rs.close();
					if (pstmt != null) pstmt.close();
				} catch (Exception exp) {}
				sqle.printStackTrace();
				return 0;
			}
			finally
			{
				try {
					if (rs != null) rs.close();
					if (pstmt != null) pstmt.close();
				} catch (Exception exp) {}
			}
			return 1;

		}
			
	
	

	
	public int getReportCount() {
	int count=0;
	if(metadata!=null)
	{
		count=metadata.size();
	}
	return count; 
}		

	}
