package com.telemune.vcc.reports;

import java.util.Date;

public class SubDetailBean {
private String msisdn;
private Date register;
private String interfc;
public String getMsisdn() {
	return msisdn;
}
public void setMsisdn(String msisdn) {
	this.msisdn = msisdn;
}
public Date getRegister() {
	return register;
}
public void setRegister(Date register) {
	this.register = register;
}
public String getInterfc() {
	return interfc;
}
public void setInterfc(String interfc) {
	this.interfc = interfc;
}
@Override
public String toString() {
	return "SubDetailBean [msisdn=" + msisdn + ", register=" + register
			+ ", interfc=" + interfc + "]";
}


}
