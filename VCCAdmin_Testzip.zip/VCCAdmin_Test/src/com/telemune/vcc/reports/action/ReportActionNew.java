package com.telemune.vcc.reports.action;

import java.util.ArrayList;
import java.util.Iterator;

import org.apache.log4j.Logger;

import com.telemune.dbutilities.Connection;

import com.telemune.vcc.common.TSSJavaUtil;
import com.telemune.vcc.common.ValidateAction;
import com.telemune.vcc.reports.*;
import com.telemune.vcc.custcare.MailBoxHistoryBean;
import com.telemune.vcc.custcare.action.SubscriberHistoryManagementBean;

public class ReportActionNew extends ValidateAction{
	
	Logger  logger=Logger.getLogger(ReportActionNew.class);
	int id;
	SubscriberHistoryManagementBean historyBean=null;
	public SubscriberHistoryManagementBean getHistoryBean() {
		return historyBean;
	}
	public void setHistoryBean(SubscriberHistoryManagementBean historyBean) {
		this.historyBean = historyBean;
	}
	
	public ReportActionNew()
	{
		setLinkName("report");
	}
	
	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String setReportInfo() {
		logger.info("Inside function setReportInfo() of ReportAction.....");
	
		if(!checkSession().equalsIgnoreCase("success"))
		{
			return "error";
		}
		else
		{
			return SUCCESS;
		}
		
	}
	
	public String handleMailBoxStatVN(){

		
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
		}else{
			
			if(historyBean==null)
			{
				System.out.println("return failure to handle exception");
				return "failure";
			}
			Connection con=null;
			String[] header = {};
			ArrayList dataListAl=null;
			String returnString="failure";

				String retVal="";

			
			try
			{
			
			int id=historyBean.getId();
			String title=getText("reportTitleHistory"+id);
			
				con=TSSJavaUtil.instance().getconnection();

				
				dataListAl= new ArrayList();
				int headerCount=0;
				// this sets the header of the list

				String head="";
			
				String[] paramsVal;
				head=this.getText("ReportHeader"+id);
				logger.info("head from language file is = "+head);
				paramsVal=head.split(",");
				headerCount=paramsVal.length;
				logger.info("Length of header ["+headerCount+"]");
				
				
				header=paramsVal;
				
				switch(id)
				{
				case 13:
					retVal=getVMMailBoxHistory(con, dataListAl,headerCount);

					break;
				case 14:
					retVal=getVNMailBoxHistory(con, dataListAl,headerCount);

					break;
				case 15:
					retVal=getCurrentMediaStat(con, dataListAl,headerCount);
					break;

				default:
					break;
				}


			//	retVal=getVNMailBoxHistory(con, dataListAl,headerCount);
					returnString="success";
					
					int size=dataListAl.size();
				logger.info("This is the size of list ["+size+"]");
				if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
				this.setMessage(retVal);
				historyBean.setHeader(header);
				historyBean.setDataAl(dataListAl);
				historyBean.setSize(size);
				historyBean.setTitle(title);
				

			}catch(Exception exe)
			{
				logger.info("Their is some exception in handleSubHistory() ",exe);
				exe.printStackTrace();
				return "failure";
			}finally
			{
				header = null;
				dataListAl=null;
				try{
					if(con!=null)if(con!=null)   TSSJavaUtil.instance().freeConnection(con);
				}catch(Exception exe)
				{
					exe.printStackTrace();
				}
			}
			return returnString;
		}
	}
		public String getVNMailBoxHistory(Connection con,ArrayList dataAl,int headCount){


		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
		}else{
			if(historyBean==null)
			{
				System.out.println("return failure to handle exception");
				return "failure";
			}

			dataAl.clear();
			logger.info("Inside function getMailBoxHistory()... ");
			String retVal="";
			ArrayList historyAl = new ArrayList();
			 ReportMetadataCache reportCache=new ReportMetadataCache();
			MailBoxHistoryBean mailBoxHistory=null;
			 
			try{
				
			
					 
					int st = reportCache.searchVNMailBoxHistory(historyAl, con);
				
			logger.info("Return value is ["+st+"]");
			
			if ((st==1) && (historyAl.size()>0))
			{
				retVal="OK";
				Iterator ite = historyAl.iterator();
				int i=0;
				while(ite.hasNext()) {

					String[] data= new String[headCount];

					mailBoxHistory = new MailBoxHistoryBean();
					mailBoxHistory = (MailBoxHistoryBean)ite.next();
					data[0]=mailBoxHistory.getReport_date();
					data[1]=mailBoxHistory.getPre_default()+"";
					data[2]=mailBoxHistory.getPost_default()+"";
					logger.info("This is the data ["+data[0]+"] ["+data[1]+"] ["+data[2]+"] ");	  

					dataAl.add(data);

				}	

			}else if(st==1)
			{
				retVal=getText("reportMailBoxHistory");

			}else
			{
				retVal=getText("alertunknown");
			}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
			finally
			{
				historyAl = null;
				reportCache= null;
				mailBoxHistory=null;
			}
			logger.info("This is the resultant String ["+retVal+"]");
			return retVal;
		}
	}
	public String getVMMailBoxHistory(Connection con,ArrayList dataAl,int headCount){

		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
		}else{
			if(historyBean==null)
			{
				System.out.println("return failure to handle exception");
				return "failure";
			}

			dataAl.clear();
			logger.info("Inside function getMailBoxHistory()... ");
			String retVal="";
			ArrayList historyAl = new ArrayList();
			 ReportMetadataCache reportCache=new ReportMetadataCache();
			MailBoxHistoryBean mailBoxHistory=null;
			 
			try{
				
			
					 
					int st = reportCache.searchMailBoxHistory(historyAl, con);
				
			logger.info("Return value is ["+st+"]");
			
			if ((st==1) && (historyAl.size()>0))
			{
				retVal="OK";
				Iterator ite = historyAl.iterator();
				int i=0;
				while(ite.hasNext()) {

					String[] data= new String[headCount];

					mailBoxHistory = new MailBoxHistoryBean();
					mailBoxHistory = (MailBoxHistoryBean)ite.next();
					data[0]=mailBoxHistory.getReport_date();

					data[1]=mailBoxHistory.getPre_basic()+"";
					data[2]=mailBoxHistory.getPre_basic_block()+"";
					data[3]=mailBoxHistory.getPost_basic()+"";
					data[4]=mailBoxHistory.getPost_basic_block()+"";
					data[5]=mailBoxHistory.getPost_exe()+"";
					data[6]=mailBoxHistory.getPost_exe_block()+"";
					data[7]=mailBoxHistory.getFixed()+"";
					data[8]=mailBoxHistory.getFixed_block()+"";
					data[9]=mailBoxHistory.getElife()+"";
					data[10]=mailBoxHistory.getElife_block()+"";
					logger.info("This is the data ["+data[0]+"] ["+data[1]+"] ["+data[2]+"] ["+data[3]+"] ["+data[4]+"] ["+data[5]+"] ["+data[6]+"] ["+data[7]+"] ["+data[8]+"] ["+data[9]+"] ["+data[10]+"] ");	  

					dataAl.add(data);

				}	

			}else if(st==1)
			{
				retVal=getText("reportMailBoxHistory");

			}else
			{
				retVal=getText("alertunknown");
			}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
			finally
			{
				historyAl = null;
				reportCache= null;
				mailBoxHistory=null;
			}
			logger.info("This is the resultant String ["+retVal+"]");
			return retVal;
		}

	}
	
		public String getCurrentMediaStat(Connection con,ArrayList dataAl,int headCount){
				if(!checkSession().equalsIgnoreCase("success")){
					return "error";
				}else{
		if(historyBean==null)
		{
			System.out.println("return failure to handle exception");
			return "failure";
		}

		dataAl.clear();
		logger.info("Inside function getCurrentMediaStat()... ");
		String retVal="";
		
		 ReportMetadataCache reportCache=new ReportMetadataCache();
		MediaStatBean mediaBean=new MediaStatBean();
		 
		try{
			
		
				 
				int st = reportCache.getMediaCurrentStat(mediaBean, con);
			
		logger.info("Return value is ["+st+"]");
		
		if (st==1)
		{
			retVal="OK";
			String[] data= new String[headCount];

				
				data[0]=mediaBean.getTime()+"";
				data[1]=mediaBean.getMedia1();
				data[2]=mediaBean.getMedia2();
				data[3]=mediaBean.getMedia3();
				data[4]=mediaBean.getMedia4();
				data[5]=mediaBean.getMedia5();
				logger.info("This is the data ["+data[0]+"] ["+data[1]+"] ["+data[2]+"] ["+data[3]+"] ["+data[4]+"] ["+data[5]+"]");	  
				dataAl.add(data);

			}	
		else
		{
			retVal=getText("alertunknown");
		}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally
		{
		
			reportCache= null;
			mediaBean=null;
		}
		logger.info("This is the resultant String ["+retVal+"]");
		return retVal;
	}
}

	

}
