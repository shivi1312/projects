package com.telemune.vcc.reports;

import java.util.ArrayList;
import java.util.Arrays;

public class downloadBean {

	private String fileName,title;
	private String path;
	private String[] header;
	private ArrayList dataAl;
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
	public String[] getHeader() {
		return header;
	}
	public void setHeader(String[] header) {
		this.header = header;
	}
	public ArrayList getDataAl() {
		return dataAl;
	}
	public void setDataAl(ArrayList dataAl) {
		this.dataAl = dataAl;
	}
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	@Override
	public String toString() {
		return "downloadBean [fileName=" + fileName + ", title=" + title
				+ ", path=" + path + ", header=" + Arrays.toString(header)
				+ ", dataAl=" + dataAl + "]";
	}
	
	
}
