package com.telemune.vcc.response;

import com.telemune.vcc.response.Info;

public class VccRuleEngineResponse implements java.io.Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private String result="Fail";

	   private String msisdn;

	   private Info info;

	   private String tid;

	   private String actionId;

	   private String msg;
	   
	   private String message;
	   
	   private String subType="N";
	   
	   
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getSubType() {
		return subType;
	}

	public void setSubType(String subType) {
		this.subType = subType;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public String getMsisdn() {
		return msisdn;
	}

	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}

	public Info getInfo() {
		return info;
	}

	public void setInfo(Info info) {
		this.info = info;
	}

	public String getTid() {
		return tid;
	}

	public void setTid(String tid) {
		this.tid = tid;
	}

	public String getActionId() {
		return actionId;
	}

	public void setActionId(String actionId) {
		this.actionId = actionId;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}


	
    

}
