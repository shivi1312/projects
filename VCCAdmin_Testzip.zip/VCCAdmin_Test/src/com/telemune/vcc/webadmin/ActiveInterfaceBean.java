package com.telemune.vcc.webadmin;

public class ActiveInterfaceBean {

	String description="";
	String key="";
	public ActiveInterfaceBean(String description) {
		super();
		this.description = description;
	}
	
	
	

	public ActiveInterfaceBean(String description, String key) {
		super();
		this.description = description;
		this.key = key;
	}




	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	
	
	
	
	
	
}
