/*@Jatinder */

package com.telemune.vcc.webadmin;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import com.telemune.dbutilities.*;
import com.telemune.vcc.common.TSSJavaUtil;

import org.apache.log4j.*;
public class AdvertiseManager
{
	static Logger logger=Logger.getLogger(AdvertiseManager.class);
	private PreparedStatement pstmt = null;
	private Connection con =null;
	private ResultSet rs =null;
	private String query=null;
	private long catId=0;
	private long adId=0;

	
	// *******************  New Category Details **********
	// ********* 
	public int addAdCategory(Advertise advertise)
	{
		logger.info("webadmin: Advertisement Category");
		try
		{
			con = TSSJavaUtil.instance().getconnection();

			query="select CATEGORY_ID,NAME from AD_CATEGORY_DETAILS where NAME=?";
			logger.info("query= "+query);
			pstmt=con.prepareStatement(query);
			pstmt.setString(1, advertise.getCatName() );
			rs= pstmt.executeQuery();

			if(rs.next() )
			{
				logger.info("webadmin; this name exists= "+rs.getString("CATEGORY_ID")+":"+rs.getString("NAME"));
				pstmt.close();
				rs.close();
				return -2;
			}
			pstmt.close();
			rs.close();

			query = "select adCat_id.nextval from dual";
			pstmt = con.prepareStatement(query);

			rs= pstmt.executeQuery();
			if(rs.next() )
			{
				catId = rs.getLong("NEXTVAL");
				pstmt.close();
				rs.close();
			}
			else
			{
				pstmt.close();
				rs.close();
				return -1;
			}

			query="insert into AD_CATEGORY_DETAILS (CATEGORY_ID, NAME,FREQUENCY) values(?,?,?)";
			logger.info("query= "+query);

			pstmt = con.prepareStatement(query);

			pstmt.setLong(1,catId);
			pstmt.setString(2, advertise.getCatName().trim() );
			pstmt.setInt(3, advertise.getCatFrequency() );	

			pstmt.executeUpdate();

			pstmt.close();	
		}//try
		catch (Exception e)
		{
			try
			{
				if (pstmt != null)
					pstmt.close ();
			}
			catch (SQLException sqle)
			{
			}
			logger.error("Exception in addAdCategory",e);
			e.printStackTrace ();
			return -1;
		}//catch
		finally
		{
			TSSJavaUtil.instance().freeConnection(con);
		}

		return 0;
	} // addAdCategory()

	public int viewAdCategory(ArrayList adCategoryAl,long catId)
	{
		logger.info("webadmin; viewAdCategory()");
		try
		{
			con = TSSJavaUtil.instance().getconnection();

			if(catId==0)
			{
				query="select * from AD_CATEGORY_DETAILS order by NAME";
				pstmt=con.prepareStatement(query);
			}
			else
			{
				query="select * from AD_CATEGORY_DETAILS where CATEGORY_ID=? order by NAME";
				pstmt =con.prepareStatement(query);
				pstmt.setLong(1,catId);
			}
			logger.info("query= "+query);
			rs = pstmt.executeQuery();
			while(rs.next() )
			{
				Advertise advertise = new Advertise();
				advertise.setCatId( rs.getLong("CATEGORY_ID") );
				advertise.setCatName( rs.getString("NAME") );
				advertise.setCatFrequency ( rs.getInt("FREQUENCY") );
				adCategoryAl.add(advertise);
			}//while

			pstmt.close();
			rs.close();
		}//try
		catch(Exception e)
		{
			try
			{
				if( pstmt != null || rs != null ) 
				{
					pstmt.close();
					rs.close();
				}//if
			}//try
			catch (SQLException sqle)
			{
			}
			logger.error("Exception in viewAdCategory",e);
			e.printStackTrace ();
			return -1;
		}//catch
		finally
		{
			TSSJavaUtil.instance().freeConnection(con);
		}
		return 99;


	} //viewAdCategory()

	public int delAdCategory(Advertise advertise)
	{

		logger.info("inside delAdCategory()");
		try
		{
			con =TSSJavaUtil.instance().getconnection();

			query="delete from SUBSCRIBER_AD_CATEGORY where CATEGORY_ID=?";
			logger.info("query= "+query);
			pstmt = con.prepareStatement(query);
			pstmt.setLong(1, advertise.getCatId() );

			pstmt.executeUpdate();
			pstmt.close();

			query="delete from AD_DETAILS where CATEGORY_ID=?";
			logger.info("query= "+query);
			pstmt = con.prepareStatement(query);
			pstmt.setLong(1, advertise.getCatId() );

			pstmt.executeUpdate();
			pstmt.close();

			query="delete from AD_CATEGORY_DETAILS where CATEGORY_ID=?";
			logger.info("query= "+query);
			pstmt = con.prepareStatement(query);
			pstmt.setLong(1, advertise.getCatId() );

			pstmt.executeUpdate();
			pstmt.close();
		}//try
		catch (Exception e)
		{
			try
			{
				if (pstmt != null)
					pstmt.close ();
			}
			catch (SQLException sqle)
			{
			}
			logger.error("Exception in delAdCategory",e);
			e.printStackTrace ();
			return -1;
		}//catch
		finally
		{
			TSSJavaUtil.instance().freeConnection(con);
		}
		return 2;

	}//delAdCategory

	public int modifyAdCategory(Advertise advertise)
	{
		logger.info("webadmin: modifyAdCategory()");
		try
		{
			con = TSSJavaUtil.instance().getconnection();
			query="update AD_CATEGORY_DETAILS set NAME=?, FREQUENCY=? where CATEGORY_ID=?";
			logger.info("query= "+query);
			pstmt = con.prepareStatement(query);

			pstmt.setString(1, advertise.getCatName().trim() );
			pstmt.setInt(2, advertise.getCatFrequency() );
			pstmt.setLong(3,advertise.getCatId() );

			pstmt.executeUpdate();
			pstmt.close();
		}//try
		catch (Exception e)
		{
			try
			{
				if (pstmt != null)
					pstmt.close ();
			}
			catch (SQLException sqle)
			{
				sqle.printStackTrace();
				return -1;	
			}
			logger.error("Exception in modifyAdCategory",e);
			e.printStackTrace ();
			return -1;
		}//catch
		finally
		{
			TSSJavaUtil.instance().freeConnection(con);
		}
		return 0;


	}//modifyAdCategory
	// ********* 
	// *******************  New Ad Details ********** 

	public int addAdDetail(Advertise advertise)
	{
		logger.info("webadmin: addAdDetail()");
		try
		{
			con = TSSJavaUtil.instance().getconnection();

			query="select AD_ID,NAME from AD_DETAILS where NAME=?";
			logger.info("query= "+query);
			pstmt=con.prepareStatement(query);
			pstmt.setString(1, advertise.getAdName() );
			rs= pstmt.executeQuery();

			if(rs.next() )
			{
				logger.info(" this name exists= "+rs.getString("AD_ID")+":"+rs.getString("NAME"));
				rs.close();
				pstmt.close();
				return -2;
			}
			rs.close();
			pstmt.close();

			query = "select adDetail_id.nextval from dual";
			logger.info("query= "+query);
			pstmt = con.prepareStatement(query);

			rs= pstmt.executeQuery();
			if(rs.next() )
			{
				adId = rs.getLong("NEXTVAL");
				rs.close();
				pstmt.close();
			}
			else
			{
				rs.close();
				pstmt.close();
				return -1;
			}			

			query="insert into AD_DETAILS (AD_ID, NAME,CATEGORY_ID,FREQUENCY,START_DATE,END_DATE,MAX_ADS,ADDS_SENT) values(?,?,?,?,to_date(?,'DD-MM-YYYY'),to_date(?,'DD-MM-YYYY'),?,?)";
			logger.info("query= "+query);

			pstmt = con.prepareStatement(query);

			pstmt.setLong(1,adId);
			pstmt.setString(2, advertise.getAdName().trim() );
			pstmt.setLong(3, advertise.getAdCat() );	
			pstmt.setInt(4, advertise.getAdFrequency() );	
			pstmt.setString(5, advertise.getStartDate().trim() );
			pstmt.setString(6, advertise.getEndDate().trim() );
			pstmt.setInt(7, advertise.getAdMax() );	
			pstmt.setInt(8, advertise.getAdSent() );	
			pstmt.executeUpdate();

			pstmt.close();	
		}//try
		catch (Exception e)
		{
			try
			{
				if (pstmt != null)
					pstmt.close ();
			}
			catch (SQLException sqle)
			{
			}
			logger.error("Exception in addAdDetail",e);
			e.printStackTrace ();
			return -1;
		}//catch
		finally
		{
			TSSJavaUtil.instance().freeConnection(con);
		}

		return 0;

	} //addAdDetail()

	public int viewAdDetail(ArrayList adDetailAl,long adId)
	{
		logger.info("webadmin; viewAdDetail()");
		try
		{
			con = TSSJavaUtil.instance().getconnection();

			if(adId==0)
			{
				query="select AD_ID,NAME,CATEGORY_ID,FREQUENCY,to_char(START_DATE,'DD-MM-YYYY')START_DATE,to_char(END_DATE,'DD-MM-YYYY')END_DATE,MAX_ADS,ADDS_SENT from AD_DETAILS order by NAME";
				pstmt=con.prepareStatement(query);
			}
			else
			{
				query="select AD_ID,NAME,CATEGORY_ID,FREQUENCY,to_char(START_DATE,'DD-MM-YYYY')START_DATE,to_char(END_DATE,'DD-MM-YYYY')END_DATE,MAX_ADS,ADDS_SENT from AD_DETAILS where AD_ID=? order by NAME";
				pstmt =con.prepareStatement(query);
				pstmt.setLong(1,adId);
			}
			logger.info("query= "+query);
			rs = pstmt.executeQuery();
			while(rs.next() )
			{
				Advertise advertise = new Advertise();
				advertise.setAdId( rs.getLong("AD_ID") );
				advertise.setAdName( rs.getString("NAME") );
				advertise.setAdCategory( rs.getLong("CATEGORY_ID") );
				advertise.setAdFrequency ( rs.getInt("FREQUENCY") );
				advertise.setStartDate( rs.getString("START_DATE"));
				advertise.setEndDate( rs.getString("END_DATE"));
				advertise.setAdMax( rs.getInt("MAX_ADS") );
				advertise.setAdSent( rs.getInt("ADDS_SENT") );

				adDetailAl.add(advertise);
			}//while

			pstmt.close();
			rs.close();
		}//try
		catch(Exception e)
		{
			try
			{
				if( pstmt != null || rs != null ) 
				{
					pstmt.close();
					rs.close();
				}//if
			}//try
			catch (SQLException sqle)
			{
			}
			logger.error("Exception in viewAdDetail",e);
			e.printStackTrace ();
			return -1;
		}//catch
		finally
		{
			TSSJavaUtil.instance().freeConnection(con);
		}
		return 99;


	}  //viewAdDetail()

	public int modifyAdDetail(Advertise advertise)
	{
		logger.info("webadmin: modifyAdDetail()");
		try
		{
			con = TSSJavaUtil.instance().getconnection();

			query="update AD_DETAILS set  NAME=?,CATEGORY_ID=?,FREQUENCY=?,START_DATE=to_date(?,'DD-MM-YYYY'),END_DATE=to_date(?,'DD-MM-YYYY'),MAX_ADS=?,ADDS_SENT=? where AD_ID=?";
			logger.info("query= "+query);
			pstmt = con.prepareStatement(query);

			pstmt.setLong(8, advertise.getAdId() );
			pstmt.setString(1, advertise.getAdName().trim() );
			pstmt.setLong(2, advertise.getAdCat() );	
			pstmt.setInt(3, advertise.getAdFrequency() );	
			pstmt.setString(4, advertise.getStartDate().trim() );
			pstmt.setString(5, advertise.getEndDate().trim() );
			pstmt.setInt(6, advertise.getAdMax() );	
			pstmt.setInt(7, advertise.getAdSent() );	
			pstmt.executeUpdate();

			pstmt.close();	
		}//try
		catch (Exception e)
		{
			try
			{
				if (pstmt != null)
					pstmt.close ();
			}
			catch (SQLException sqle)
			{
			}
			logger.error("Exception in modifyAdDetail",e);
			e.printStackTrace ();
			return -1;
		}//catch
		finally
		{
			TSSJavaUtil.instance().freeConnection(con);
		}

		return 0;

	} //modifyAddDetail

	public int delAdDetail(Advertise advertise)
	{
		logger.info("webadmin: delAdDetail()");
		try
		{
			con = TSSJavaUtil.instance().getconnection();
			query = "delete from AD_DETAILS where AD_ID=? and NAME=?";
			logger.info("query= "+query);
			pstmt = con.prepareStatement(query);

			pstmt.setLong(1, advertise.getAdId() );
			pstmt.setString(2, advertise.getAdName() );

			pstmt.executeUpdate();

			pstmt.close();

		}//try
		catch (Exception e)
		{
			try
			{
				if (pstmt != null)
					pstmt.close ();
			}
			catch (SQLException sqle)
			{
			}
			logger.error("Exception in delAdDetail",e);
			e.printStackTrace ();
			return -1;
		}//catch
		finally
		{
			TSSJavaUtil.instance().freeConnection(con);
		}
		return 2;


	}//delAdDetail

} //class AdvertiseManager
