/**
 * @author MoHit
 * Created on 24 March 2015 for COMMON
 */


package com.telemune.vcc.webadmin;

import java.sql.ResultSet;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.telemune.dbutilities.Connection;
import com.telemune.dbutilities.PreparedStatement;
import com.telemune.vcc.common.TSSJavaUtil;

public class BlacklistManagerNew 
{
	private static Logger logger=Logger.getLogger(BlacklistManagerNew.class);
	private Connection con=null;
	PreparedStatement pstmt=null;
    ResultSet rs =null;
	
    /**
     * This method is used to add new entry into OPERATOR_SUBSCRIBER_EXCLUDE before
     * some validations to add a number to system blacklist
     * @param msisdn
     * @return
     */
	public int addNewBlacklist(String msisdn)
	{
		logger.info("inside addNewBlacklist() msisdn="+msisdn);
		String intrMsisdn=TSSJavaUtil.instance().getInternationalNumber(msisdn);
		int rangeId=-1;
		
		try
		{
			con=TSSJavaUtil.instance().getconnection();
			
			String query="select RANGE_ID from OPERATOR_SUBSCRIBER where STARTS_AT < ? and ENDS_AT > ?";
			logger.info(query);
			pstmt = con.prepareStatement(query);
			pstmt.setString(1,intrMsisdn);
			pstmt.setString(2,intrMsisdn);
			rs = pstmt.executeQuery();
			if (rs.next())
			{
				rangeId=rs.getInt("RANGE_ID");
				logger.info("In the subscriber range msisdn="+intrMsisdn+" rangeId="+rangeId);
			}
			else
			{
				logger.info("Not in subscriber range msisdn="+intrMsisdn);
                return -2;
			}
			rs.close();
            pstmt.close();

            query="select * from CRBT_SUBSCRIBER_MASTER where MSISDN=?";
			logger.info(query);
			pstmt = con.prepareStatement(query);
			pstmt.setString(1,intrMsisdn);
			rs = pstmt.executeQuery();
			if (rs.next())
			{
				logger.info("already subscribed msisdn="+intrMsisdn);
                rs.close();
                pstmt.close();
                return -3;
			}
            
			query="select * from OPERATOR_SUBSCRIBER_EXCLUDE where EXCLUDE_NUM=?";
			logger.info(query);
			pstmt = con.prepareStatement(query);
			pstmt.setString(1,intrMsisdn);
			rs = pstmt.executeQuery();
			if (rs.next())
			{
				logger.info("already blacklisted msisdn="+intrMsisdn);
                rs.close();
                pstmt.close();
                return -4;
			}
			
			query="insert into OPERATOR_SUBSCRIBER_EXCLUDE values(?,?)";
			logger.info(query);
			pstmt = con.prepareStatement(query);
			pstmt.setInt(1,rangeId);
			pstmt.setString(2,intrMsisdn);
			int result = pstmt.executeUpdate();
			rs.close();
            pstmt.close();
            
			if(result>0)
				return 1;
			else
				return -5;
			
		}
		catch (Exception e) 
		{
			logger.info("exception inside addNewBlacklist() "+e);
			e.printStackTrace();
			return -1;
		}
		finally
        {
        	try{
        	if(pstmt!=null) pstmt.close();
        	if(rs!=null) rs.close();
        	if(con!=null) TSSJavaUtil.instance().freeConnection(con);
        	}
        	catch (Exception e) {
				e.printStackTrace();
			}
        }
	}//addNewBlacklist()
	
	/**
	 * This method is used to get all the blacklist numbers from OPERATOR_SUBSCRIBER_EXCLUDE table
	 * @param al
	 * @return
	 */
	public int getAllBlacklists(ArrayList<String> al)
	{
		logger.info("inside getAllBlacklists()");
		try
		{
			con=TSSJavaUtil.instance().getconnection();
			
			String query="select EXCLUDE_NUM from OPERATOR_SUBSCRIBER_EXCLUDE";
			logger.info(query);
			pstmt = con.prepareStatement(query);
			rs = pstmt.executeQuery();
			
			al.clear();
			
			while(rs.next())
			{
				al.add(rs.getString("EXCLUDE_NUM"));
			}
			rs.close();
			pstmt.close();
			return 1;
		}
		catch (Exception e) 
		{
			logger.info("Exception inside getAllBlacklists()"+e);
			e.printStackTrace();
			return -1;
		}
		finally
		{
			try{
	        	if(pstmt!=null) pstmt.close();
	        	if(rs!=null) rs.close();
	        	if(con!=null) TSSJavaUtil.instance().freeConnection(con);
	        	}
	        	catch (Exception e) {
					e.printStackTrace();
				}
		}
	}//getAllBlacklist()
	
	
	public int deleteBlacklistNumbers(ArrayList<String> al,StringBuffer msisdnsDeleted)
	{
		logger.info("inside deleteBlacklistNumbers() msisdnToDelete="+al);
		try
		{
			con=TSSJavaUtil.instance().getconnection();
			
			String query="delete from OPERATOR_SUBSCRIBER_EXCLUDE where EXCLUDE_NUM=?";
			logger.info(query);
			pstmt = con.prepareStatement(query);
			int status=-1;
			Boolean bool=false;
			
			for(int i=0;i<al.size();i++)
			{
				pstmt.setString(1,al.get(i));
				status = pstmt.executeUpdate();
				if(status>0)
				{
					bool=true;
					logger.info("msisdn DELETED from blacklist (OPERATOR_SUBSCRIBER_EXCLUDE table) = "+al.get(i));
					msisdnsDeleted.append(", "+al.get(i));
				}
				else
					logger.info("msisdn NOT DELETED from blacklist (OPERATOR_SUBSCRIBER_EXCLUDE table) = "+al.get(i));
			}
			if(bool)
				return 1;
			return -2;
		}
		catch (Exception e) 
		{
			logger.info("Exception inside getAllBlacklists()"+e);
			e.printStackTrace();
			return -1;
		}
		finally
		{
			try{
	        	if(pstmt!=null) pstmt.close();
	        	if(rs!=null) rs.close();
	        	if(con!=null) TSSJavaUtil.instance().freeConnection(con);
	        	}
	        	catch (Exception e) {
					e.printStackTrace();
				}
		}
	}//deleteBlacklistNumbers()
	
}
