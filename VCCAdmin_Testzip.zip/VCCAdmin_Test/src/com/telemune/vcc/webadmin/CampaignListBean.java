package com.telemune.vcc.webadmin;

public class CampaignListBean {
  private int list_id;
  private String list_name;
  private String status;
  
  public CampaignListBean() {
    list_id=0;
    list_name="";
    status="";
  }
  
  

public CampaignListBean(int list_id, String list_name, String status) {
	super();
	this.list_id = list_id;
	this.list_name = list_name;
	this.status = status;
}



public int getList_id() {
	return list_id;
}

public void setList_id(int list_id) {
	this.list_id = list_id;
}

public String getList_name() {
	return list_name;
}

public void setList_name(String list_name) {
	this.list_name = list_name;
}

public String getStatus() {
	return status;
}

public void setStatus(String status) {
	this.status = status;
}
  
  @Override
	public String toString() {
		
		return super.toString();
	}
  
  
  
}
