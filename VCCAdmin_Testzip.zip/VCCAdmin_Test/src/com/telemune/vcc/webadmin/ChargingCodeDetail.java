package com.telemune.vcc.webadmin;

public class ChargingCodeDetail {
	private Integer reqId;
	private Integer chargingCode;
	private Double amountPostPaid;
	private Double amountPrePaid;
	private String chargingCodeName;
	private Integer tarrifPre;
	private Integer tarrifPost;
	
	
	public ChargingCodeDetail(Integer chargingCode,
			Double amountPostPaid, Double amountPrePaid, String chargingCodeName,
			Integer tarrifPre, Integer tarrifPost) {
		super();
		
		this.chargingCode = chargingCode;
		this.amountPostPaid = amountPostPaid;
		this.amountPrePaid = amountPrePaid;
		this.chargingCodeName = chargingCodeName;
		this.tarrifPre = tarrifPre;
		this.tarrifPost = tarrifPost;
	}


	public ChargingCodeDetail() {
		super();
	}
	
	


	public Integer getReqId() {
		return reqId;
	}


	public void setReqId(Integer reqId) {
		this.reqId = reqId;
	}


	public Integer getChargingCode() {
		return chargingCode;
	}


	public void setChargingCode(Integer chargingCode) {
		this.chargingCode = chargingCode;
	}


	public Double getAmountPostPaid() {
		return amountPostPaid;
	}


	public void setAmountPostPaid(Double amountPostPaid) {
		this.amountPostPaid = amountPostPaid;
	}


	public Double getAmountPrePaid() {
		return amountPrePaid;
	}


	public void setAmountPrePaid(Double amountPrePaid) {
		this.amountPrePaid = amountPrePaid;
	}


	


	public String getChargingCodeName() {
		return chargingCodeName;
	}


	public void setChargingCodeName(String chargingCodeName) {
		this.chargingCodeName = chargingCodeName;
	}


	public Integer getTarrifPre() {
		return tarrifPre;
	}


	public void setTarrifPre(Integer tarrifPre) {
		this.tarrifPre = tarrifPre;
	}


	public Integer getTarrifPost() {
		return tarrifPost;
	}


	public void setTarrifPost(Integer tarrifPost) {
		this.tarrifPost = tarrifPost;
	}


	@Override
	public String toString() {
		return "ChargingCodeDetail [reqId=" + reqId + ", chargingCode="
				+ chargingCode + ", amountPostPaid=" + amountPostPaid
				+ ", amountPrePaid=" + amountPrePaid + ", chargingCodeName="
				+ chargingCodeName + ", tarrifPre=" + tarrifPre + ", tarrifPost="
				+ tarrifPost + "]";
	}
	
}
