package com.telemune.vcc.webadmin;

import java.util.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.telemune.dbutilities.*;
import com.telemune.vcc.common.TSSJavaUtil;

import org.apache.log4j.*;
public class ChargingCodeManager
{
	static Logger logger=Logger.getLogger(ChargingCodeManager.class);
	private ResultSet rs = null;
	private PreparedStatement pstmt = null;
	private PreparedStatement pstmt1 = null;
	private Connection con = null;
	private String query = null;
	private String query1 = null;

	
	public int addChargingCode (ChargingCode chgObj,Connection con)
	{
		logger.info("webadmin: addChargingCode()");
		long chg_id=0;
		try
		{
			query = "SELECT CHARGING_CODE_NAME FROM VCC_CHARGING_CODE WHERE CHARGING_CODE_NAME=? ";
			logger.info("query= "+query);
			pstmt = con.prepareStatement (query);
			pstmt.setString (1,chgObj.getChgName());
			rs = pstmt.executeQuery ();
			if(rs.next ())
			{
				logger.info("already exists");
				rs.close ();
				pstmt.close ();
				return -2; //Record already exists
			}
			rs.close ();
			pstmt.close ();
			query = "INSERT INTO VCC_CHARGING_CODE (CHARGING_CODE, AMOUNT_PRE, AMOUNT_POST,CHARGING_CODE_NAME,TARIFF_PRE,TARIFF_POST) VALUES (?,?,?,?,?,?)";
			logger.info("query= "+query);
			pstmt = con.prepareStatement (query);
			pstmt.setLong (1, chg_id);
			pstmt.setDouble (2, chgObj.getAmountP());
			pstmt.setDouble (3, chgObj.getAmountO());
			pstmt.setString (4, chgObj.getChgName ().trim());
			pstmt.setInt(5,1);
			pstmt.setInt(6,1);
			pstmt.executeUpdate ();
			pstmt.close ();
		}//try
		catch (Exception e)
		{
			try
			{
				if(pstmt != null) pstmt.close ();
				if(rs != null) rs.close ();
			}catch(SQLException sqle)
			{
				logger.error ("webadmin-addChargingCode: Exception is: " + sqle.getMessage ());
			}

			e.printStackTrace ();
			return -1;
		}
		//finally  { conPool.free(con); } 
		return 1; //  added susccessfully

	}// addChargingCode()

	public int getChargingCode (ArrayList chgAl,Connection con)
	{
		logger.info("getChargingCode() ");
		try
		{
			//con = conPool.getConnection();
			query = "select CHARGING_CODE_NAME, AMOUNT_PRE,AMOUNT_POST, CHARGING_CODE from VCC_CHARGING_CODE";
			logger.info("query= "+query);
			//query="select CHARGING_CODE_NAME, AMOUNT_PRE,AMOUNT_POST,CHARGING_CODE from VCC_CHARGING_CODE where CHARGING_CODE not in (select charging_code from crbt_rbt)";
			pstmt = con.prepareStatement (query);
			rs = pstmt.executeQuery ();
			while(rs.next ())
			{
				ChargingCode chgOb = new ChargingCode ();
				chgOb.setChgName (rs.getString ("CHARGING_CODE_NAME"));
				chgOb.setAmountP (rs.getDouble ("AMOUNT_PRE"));
				chgOb.setAmountO (rs.getDouble ("AMOUNT_POST"));
				chgOb.setChgCode (rs.getLong ("CHARGING_CODE"));
				chgAl.add (chgOb);
			}
			
			rs.close ();
			pstmt.close ();
		} //try
		catch (Exception e)
		{
			try
			{
				if(rs != null) rs.close ();
				if(pstmt != null) pstmt.close ();
			}catch(SQLException sqle)
			{
				logger.error ("Exception in getChargingCode: " + sqle.getMessage ());
			}
			e.printStackTrace ();
			return -1;
		}
		//finally{ conPool.free(con); }
		return 1;
	}//getChargingCode

	public int getChargingCode (ArrayList ocAl,long chgCode,Connection con)
	{
		logger.info("getChargingCode() ");
		try
		{
			//con = conPool.getConnection();
			query = "select CHARGING_CODE_NAME, AMOUNT_PRE,AMOUNT_POST, CHARGING_CODE from VCC_CHARGING_CODE where CHARGING_CODE=?";
			logger.info("query= "+query);
			pstmt = con.prepareStatement (query);
			pstmt.setLong(1,chgCode);
			rs = pstmt.executeQuery ();

			while(rs.next ())
			{
				ChargingCode ocob = new ChargingCode ();
				ocob.setChgName(rs.getString ("CHARGING_CODE_NAME"));
				ocob.setAmountP (rs.getDouble ("AMOUNT_PRE"));
				ocob.setAmountO (rs.getDouble ("AMOUNT_POST"));
				ocob.setChgCode (chgCode);
				ocAl.add (ocob);
			}
			rs.close ();
			pstmt.close ();
		} //try
		catch (Exception e)
		{
			try
			{
				if(rs != null) rs.close ();
				if(pstmt != null) pstmt.close ();
			}catch(SQLException sqle)
			{
				logger.error ("Exception in getChargingCode, Exception is : " + sqle.getMessage ());
			}
			e.printStackTrace ();
			return -1;
		}
		//finally{ conPool.free(con); }
		return 1;

	}//getChargingCode()

	public int updateChargingCode (ChargingCode ocobj, long chgCode,Connection con)
	{
		logger.info("in function updateChargingCode() "+chgCode);

		try
		{
			//con = conPool.getConnection();

			query = "UPDATE VCC_CHARGING_CODE SET AMOUNT_PRE=?,AMOUNT_POST=? where Charging_Code=?";
			logger.info("query= "+query);
			pstmt = con.prepareStatement (query);

			pstmt.setDouble (1, ocobj.getAmountP ());
			pstmt.setDouble (2, ocobj.getAmountO ());
			pstmt.setLong (3, chgCode);

			pstmt.executeUpdate ();
			pstmt.close ();
		}//try
		catch (Exception e)
		{
			try
			{
				if(pstmt != null) pstmt.close ();
				if(rs != null) rs.close ();
			}catch(SQLException sqle)
			{
				logger.error ("Exception in updateChargingCode: " + sqle.getMessage ());
			}
			e.printStackTrace ();
			return -1;
		}
		//finally{conPool.free(con); }
		return 1;
	} // updateChargingCode

	public int deleteChargingCode (ArrayList codes)
	{
		logger.info("deleteChargingCode()");
		try
		{
			con = TSSJavaUtil.instance().getconnection();
			query = "delete from VCC_CHARGING_CODE WHERE CHARGING_CODE=?";
			logger.info("query= "+query);
			pstmt = con.prepareStatement(query);
			for(int i=0; i<codes.size(); i++)
			{
				pstmt.setLong (1,Long.parseLong((String)codes.get(i)));
				pstmt.executeUpdate();
			}
			pstmt.close();
		}//try
		catch (Exception e)
		{
			try
			{
				if(pstmt != null) pstmt.close ();
			}catch(SQLException sqle)
			{
				logger.error ("Exception in deleteChargingCode: " + sqle.getMessage ());
			}
			e.printStackTrace ();
			return -1;
		}
		finally{ TSSJavaUtil.instance().freeConnection(con);  }
		return 1;
	}//deleteChargingCode

	public int getTableCol (ArrayList colAl)
	{
		logger.info("getTableCol() ");
		try
		{
			con = TSSJavaUtil.instance().getconnection();
			query = "SELECT column_name FROM USER_TAB_COLS WHERE TABLE_NAME ='CRBT_RATE_PLANS'";
			logger.info("query= "+query);
			pstmt = con.prepareStatement (query);
			rs = pstmt.executeQuery ();
			while(rs.next ())
			{
				ChargingCode chgOb = new ChargingCode ();
				chgOb.setColName (rs.getString ("column_name"));
				colAl.add (chgOb);
			}
			rs.close ();
			pstmt.close ();
		} //try
		catch (Exception e)
		{
			try
			{
				if(rs != null) rs.close ();
				if(pstmt != null) pstmt.close ();
			}catch(SQLException sqle)
			{
				logger.error ("Exception in getTableCol: " + sqle.getMessage ());
			}
			e.printStackTrace ();
			return -1;
		}
		finally{TSSJavaUtil.instance().freeConnection(con); }
		return 1;
	}//getTableCol

	/*
	   public int defineChargingRule (ChargingCode chgObj)
	   {
	   logger.info("webadmin: defineChargingRule");
	   int plan_id=0;
	   try
	   {
	   con = conPool.getConnection();
	   query="select chg_plan_id.nextval from dual";
	   pstmt=con.prepareStatement(query);
	   rs = pstmt.executeQuery();
	   if(rs.next())
	   {
	   plan_id = rs.getInt(1);
	   }
	   rs.close ();
	   pstmt.close ();
	   pstmt.setString (3, chgObj.getRbtChgCode());
	   pstmt.setString (4, chgObj.getRbtGiftChgCode ());
	   pstmt.setString (5, chgObj.getRbtMonoChgCode ());
	   pstmt.setString (6, chgObj.getRbtNoChgCode());
	   pstmt.setString (7, chgObj.getRbtNormalChgCode ());
	   pstmt.setString (8, chgObj.getSubChgCode ());
	   pstmt.setString (9, chgObj.getRbtRecChgCode ());
	   pstmt.setInt (10, chgObj.getValidity());
	   pstmt.setString (11, chgObj.getRemarks());
	   pstmt.setString (12, "S");
	   pstmt.setString (13, "U");
	   pstmt.setString (14, "cdr");

	   pstmt.executeUpdate ();
	   pstmt.close ();
	   }//try
	   catch (Exception e)
	   {
	   try
	   {
	   if(pstmt != null) pstmt.close ();
	   if(rs != null) rs.close ();
	   }catch(SQLException sqle)
	   {
	   logger.info ("webadmin/defineChargingRule, Exception is: " + sqle.getMessage ());
	   }

	   e.printStackTrace ();
	   return -1;
	   }
	   finally  { conPool.free(con); } 
	   return 1; //  added susccessfully

	   }// defineChargingRule
	 */
}//class
