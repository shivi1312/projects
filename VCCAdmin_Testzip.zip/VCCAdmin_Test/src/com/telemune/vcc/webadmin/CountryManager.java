
package com.telemune.vcc.webadmin;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import com.telemune.dbutilities.*;
import com.telemune.vcc.common.TSSJavaUtil;

import org.apache.log4j.*;

public class CountryManager

{
                      static Logger logger=Logger.getLogger(CountryManager.class);
				private PreparedStatement pstmt = null;
				private Connection con = null;
				private ResultSet rs =null;
				private String query = null;
				



	public int addCountry(Country country)
 {
		logger.info("webadmin: addCountry()");
		try
		{
			con = TSSJavaUtil.instance().getconnection();

			query = "select COUNTRY_NAME from ROME_COUNTRY_MASTER where MCC=?";
			logger.info("query= "+query);
			pstmt = con.prepareStatement(query);
			pstmt.setInt(1,country.getMcc() );
			rs = pstmt.executeQuery();
			if (rs.next())
			{
					logger.info("already exists");
					pstmt.close();
					rs.close();
					return -2;  // this COUNTRY_NAME name exists
			}
			pstmt.close();
			rs.close();

			query = "insert into ROME_COUNTRY_MASTER (COUNTRY_CODE, COUNTRY_NAME, CC, MCC, INROAM_FLAG, OUTROAM_FLAG) values (?,?,?,?,?,?)";
			logger.info("query= "+query);
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, country.getCode().trim() );
			pstmt.setString(2, country.getName().trim() );
			pstmt.setInt(3, country.getCc() );
			pstmt.setInt(4, country.getMcc() );
			pstmt.setString(5, country.getInbound().trim() );
			pstmt.setString(6, country.getOutbound().trim() );

			pstmt.executeUpdate();
		  pstmt.close();	
		}//try
    catch (Exception e)
    {
      try
      {
				if (pstmt != null)
					  pstmt.close ();
      }
      catch (SQLException sqle)
      {
					sqle.printStackTrace();
					return -1;	
      }
      logger.error("Exception in addCountry",e);
      e.printStackTrace ();
      return -1;
    }//catch
		finally
		{	try{	if(con!=null)	TSSJavaUtil.instance().freeConnection(con);
		}catch(Exception e){}
		}

    return 0;
 
 }//addCountry

public int viewCountryConfig(ArrayList countryConfigAl )
{
		logger.info("webadmin: viewCountryConfig()");
		
	try
		{
			con = TSSJavaUtil.instance().getconnection();

			query = "select * from ROME_COUNTRY_MASTER order by COUNTRY_CODE";
			logger.info("query= "+query);
			pstmt = con.prepareStatement(query);
			rs = pstmt.executeQuery();
			while( rs.next() )
			{
				Country country = new Country();
				country.setCode (rs.getString("COUNTRY_CODE" ) );
				country.setName (rs.getString("COUNTRY_Name" ) );
				country.setCc (rs.getInt("CC" ) );
				country.setMcc (rs.getInt("MCC" ) );
				country.setInbound (rs.getString("INROAM_FLAG" ) );
				country.setOutbound (rs.getString("OUTROAM_FLAG" ) );
				countryConfigAl.add(country);
			}//while

			pstmt.close();
			rs.close();	
		}//try
		catch(Exception e)
		{
			try
			{
				if( pstmt != null || rs != null ) 
				{
									pstmt.close();
									rs.close();
				}//if
   		}//try
      catch (SQLException sqle)
      {
      }
			logger.error("Exception in viewCountryConfig",e);
      e.printStackTrace ();
      return -1;
		}//catch
	finally
	{	try{	if(con!=null)	TSSJavaUtil.instance().freeConnection(con);
	}catch(Exception e){}
	}

		return 99;
			
}//viewCountryConfig

  public int modifyCountryConfig (Country country)
  {
					logger.info("webadmin:modifyCountryConfig()");
    try
    {
      con = TSSJavaUtil.instance().getconnection();
      query = "update ROME_COUNTRY_MASTER set INROAM_FLAG = ? , OUTROAM_FLAG = ? where MCC=?";
	logger.info("query= "+query);
      pstmt = con.prepareStatement (query);
			
      pstmt.setString (1, country.getInbound().trim() );
      pstmt.setString (2, country.getOutbound().trim() );
      pstmt.setInt (3, country.getMcc() );
      
			pstmt.executeUpdate ();
      pstmt.close ();
    }
    catch (Exception e)
    {
      try
      {
				if (pstmt != null)
				  pstmt.close ();
      }
      catch (SQLException sqle)
      {
      }
      logger.error("Exception in modifyCountryConfig",e);
      e.printStackTrace ();
      return -1;
    }
		finally
		{	
			try {
				if(con!=null)	TSSJavaUtil.instance().freeConnection(con);
			} catch (Exception e2) {
				// TODO: handle exception
			}
			
		}
    return 0;
  }//modifyCountryConfig

 public int delCountryConfig (Country country)
  {
	logger.info("inside delCountryConfig()");
    try
    {
      con = TSSJavaUtil.instance().getconnection();
      query = "delete from ROME_COUNTRY_MASTER where MCC = ?";
	logger.info("query= "+query);
      pstmt = con.prepareStatement (query);
      pstmt.setInt (1, country.getMcc() );
      pstmt.executeUpdate ();
      pstmt.close ();
    }
    catch (Exception e)
    {
      try
      {
					if (pstmt != null)
				  pstmt.close ();
      }
      catch (SQLException sqle)
      {
      }
      logger.error("Exception in delCountryConfig",e);
      e.printStackTrace ();
      return -1;
    }
		finally
		{	
			
			try {
				if(con!=null)	TSSJavaUtil.instance().freeConnection(con);
			} catch (Exception e2) {
				// TODO: handle exception
			}
		}
  return 2;
  }//delCountryConfig

public int getCountryNameCode(ArrayList countryConfigAl )
{
		logger.info("webadmin: viewCountryConfig");
		
	try
		{
			con = TSSJavaUtil.instance().getconnection();

			query = "select COUNTRY_CODE,COUNTRY_Name  from COUNTRY_CODE  order by COUNTRY_name";
			logger.info("query= "+query);
			pstmt = con.prepareStatement(query);
			rs = pstmt.executeQuery();
			while( rs.next() )
			{
				Country country = new Country();
				country.setName (rs.getString("COUNTRY_NAME" ) );
				country.setCode (rs.getString("COUNTRY_CODE" ) );
				//country.setCc (rs.getInt("CC" ) );
		//		country.setMcc (rs.getInt("MCC" ) );
			//	country.setInbound (rs.getString("INROAM_FLAG" ) );
			//	country.setOutbound (rs.getString("OUTROAM_FLAG" ) );
				countryConfigAl.add(country);
			}//while

			pstmt.close();
			rs.close();	
		}//try
		catch(Exception e)
		{
			try
			{
				if( pstmt != null || rs != null ) 
				{
									pstmt.close();
									rs.close();
				}//if
   		}//try
      catch (SQLException sqle)
      {
      }
			  logger.error("Exception in delCountryConfig",e);
      e.printStackTrace ();
      return -1;
		}//catch
		finally	{
			try {
				if(con!=null)	TSSJavaUtil.instance().freeConnection(con);
			} catch (Exception e2) {
				// TODO: handle exception
			}
		}
		return 99;
			
}//viewCountryConfig

}//class
