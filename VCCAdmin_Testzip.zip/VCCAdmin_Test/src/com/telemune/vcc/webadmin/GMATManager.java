
package com.telemune.vcc.webadmin;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import com.telemune.dbutilities.*;
import com.telemune.vcc.common.TSSJavaUtil;

import org.apache.log4j.*;
public class GMATManager

{
                               static Logger logger=Logger.getLogger(GMATManager.class);
				private PreparedStatement pstmt = null;
				private Connection con = null;
				private ResultSet rs =null;
				private String query = null;
				

 public int addGMAT(GMAT gmat)
 {
		 logger.info("webadmin: addGMAT()");
		try
		{
				con = TSSJavaUtil.instance().getconnection();
				query= "select * from GMAT_HELP_MASTER where PROCESS_NAME=? and LANGUAGE_ID=?" ;
				logger.info("query= "+query);
				pstmt = con.prepareStatement(query);

				pstmt.setString(1, gmat.getName());
				pstmt.setInt(2, gmat.getLanguage() );
				rs = pstmt.executeQuery();

				if(rs.next() )
				{
						logger.debug("webadmin-addGMAT() this GMAT Name and Language Id Already Exists");
						pstmt.close();		
						rs.close();
						return -1;
								
				}
				pstmt.close();
				rs.close();
				
				query = "insert into GMAT_HELP_MASTER (PROCESS_NAME,HELP_MESSAGE,LANGUAGE_ID) values(?,?,?)";
				logger.info("query= "+query);
				pstmt = con.prepareStatement(query);

				pstmt.setString(1, gmat.getName().trim());
				pstmt.setString(2, gmat.getMessage().trim());
				pstmt.setInt(3, gmat.getLanguage());
				pstmt.executeUpdate();

				pstmt.close();
				
		}//try
     catch (Exception e)
		 {
						 try
						 {
										 if (pstmt != null)
											 pstmt.close ();
						 }
						 catch (SQLException sqle)
						 {
										 sqle.printStackTrace();
										 return -1;	
						 }
						 logger.error("Exception in addGMAT",e);
						 e.printStackTrace ();
						 return -1;
		 }//catch
		finally
		{		
			try {
				if(con!=null)	TSSJavaUtil.instance().freeConnection(con);
			} catch (Exception e2) {
				// TODO: handle exception
			}
		}
    return 0;
 
	} //addGMAT
 
  public int getGMAT(ArrayList gmatConfigAl, String name, int languageId)
	{
				logger.info("webadmin: getGMAT() for name= "+name);
		try
		{
			con = TSSJavaUtil.instance().getconnection();
			if(name.equals("X") && languageId == -1)
			{
				query="select * from  GMAT_HELP_MASTER order by PROCESS_NAME";
				pstmt = con.prepareStatement(query);
      }   
			else
			{
				query="select * from  GMAT_HELP_MASTER where PROCESS_NAME=? and LANGUAGE_ID=? order by PROCESS_NAME";
				pstmt = con.prepareStatement(query);
				pstmt.setString(1, name);
				pstmt.setInt(2,languageId);
			}
			rs = pstmt.executeQuery();
		  while(rs.next() )
				{
						GMAT gmat = new GMAT();
						gmat.setName( rs.getString("PROCESS_NAME"));
						gmat.setMessage( rs.getString("HELP_MESSAGE") );
						gmat.setLanguage(  rs.getInt("LANGUAGE_ID"));
	 					gmatConfigAl.add(gmat);
				}
			  rs.close();
				pstmt.close();
		}//try
   catch (Exception e)
		{
						try
						{
										if (rs != null)
														rs.close ();
										if (pstmt != null)
														pstmt.close ();
						}
						catch (SQLException sqle)
						{
										sqle.printStackTrace();
										return -1;	
						}
						logger.error("Exception in getGMAT",e);
						e.printStackTrace ();
						return -1;
		}//catch
		finally
		{
			try {
				if(con!=null)	TSSJavaUtil.instance().freeConnection(con);
			} catch (Exception e2) {
				// TODO: handle exception
			}
		}
    return 0;

	}//getGMAT
	
	public int modifyGMAT(GMAT gmat)
	{
				logger.info("webadmin: modifyGMAT() ");
		try
		{
				con = TSSJavaUtil.instance().getconnection();
				query="update GMAT_HELP_MASTER set HELP_MESSAGE=? where LANGUAGE_ID=? and PROCESS_NAME=?";
				logger.info("query= "+query);
				pstmt = con.prepareStatement(query);

				pstmt.setString(1, gmat.getMessage().trim());
				pstmt.setInt(2, gmat.getLanguage());
				pstmt.setString(3, gmat.getName().trim());
				pstmt.executeUpdate();

				pstmt.close();
		
		}//try
    catch (Exception e)
		{
						try
						{
										if (pstmt != null)
														pstmt.close ();
						}
						catch (SQLException sqle)
						{
										sqle.printStackTrace();
										return -1;	
						}
						logger.error("Exception in modifyGMAT",e);
						e.printStackTrace ();
						return -1;
		}//catch
		finally
		{	
			try {
				if(con!=null)	TSSJavaUtil.instance().freeConnection(con);
			} catch (Exception e2) {
				// TODO: handle exception
			}
		}
    return 0;
 
	} //modifyGMAT




} //class GMATManager
