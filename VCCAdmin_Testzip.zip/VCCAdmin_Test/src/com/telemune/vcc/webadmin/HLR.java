/*
 * This class is used for VLR config for the admin web interface for CRBT.
 *@Jatinder Pal
 *
 * 
 */
package com.telemune.vcc.webadmin;

import java.util.ArrayList;

public class HLR
{
	private int hlrId;
	private String hlrName;
	private String hlrIp;
	private int hlrPort;
	private String login;
	private String password;
	private String description;
	private int conn;
	private ArrayList<Integer> deleteList;

	public HLR()
	{
					
	}

	public int getHlrId() {
		return hlrId;
	}

	public void setHlrId(int hlrId) {
		this.hlrId = hlrId;
	}

	public String getHlrName() {
		return hlrName;
	}

	public void setHlrName(String hlrName) {
		this.hlrName = hlrName;
	}

	public String getHlrIp() {
		return hlrIp;
	}

	public void setHlrIp(String hlrIp) {
		this.hlrIp = hlrIp;
	}

	public int getHlrPort() {
		return hlrPort;
	}

	public void setHlrPort(int hlrPort) {
		this.hlrPort = hlrPort;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getConn() {
		return conn;
	}

	public void setConn(int conn) {
		this.conn = conn;
	}

	public ArrayList<Integer> getDeleteList() {
		return deleteList;
	}

	public void setDeleteList(ArrayList<Integer> deleteList) {
		this.deleteList = deleteList;
	}

	@Override
	public String toString() {
		return "HLR [hlrId=" + hlrId + ", hlrName=" + hlrName + ", hlrIp="
				+ hlrIp + ", hlrPort=" + hlrPort + ", login=" + login
				+ ", password=" + password + ", description=" + description
				+ ", conn=" + conn + ", deleteList=" + deleteList + "]";
	}
	
	

} // class HLR
