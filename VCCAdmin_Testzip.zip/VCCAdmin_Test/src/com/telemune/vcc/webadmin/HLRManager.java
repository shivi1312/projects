
package com.telemune.vcc.webadmin;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import com.telemune.dbutilities.*;
 import org.apache.log4j.*;
public class HLRManager

{
                private static Logger logger=Logger.getLogger(HLRManager.class);
				private ConnectionPool conPool = null;
				private PreparedStatement pstmt = null;
				private Connection con = null;
				private ResultSet rs =null;
				private String query = null;
				
 public HLRManager()				 
 {
				 conPool = new ConnectionPool();
 }

   public void setConnectionPool(ConnectionPool conPool)
        {
                this.conPool = conPool;
        }

        public ConnectionPool getConnectionPool()
        {
                return conPool;
        }

 public int addHLRConfig (HLR hlr)
	{
		logger.debug ("webadmin: addHLRConfig");
		try
		{
		con = conPool.getConnection();
			query = "select HLR_NAME from HLR_CONFIG where HLR_NAME = ?";
			pstmt = con.prepareStatement (query);
			pstmt.setString (1, hlr.getHlrName());
			rs = pstmt.executeQuery();
			if (rs.next())
			{
				rs.close();			
				pstmt.close();
				logger.info("webadmin; This HLR Name "+hlr.getHlrName()+ " already exists");
				System.out.println("webadmin; This HLR Name "+hlr.getHlrName()+ " already exists");
				return -2;
			}
				rs.close();			
				pstmt.close();

			int hlrId = 0;

			query = "insert into HLR_CONFIG (HLR_NAME, HLR_IP, HLR_PORT, CONNECTIONS, LOGIN, PASSWORD) values (?, ?, ?, ?, ?, ?)";
			pstmt = con.prepareStatement (query);
		
			pstmt.setString (1, hlr.getHlrName().trim());
			pstmt.setString (2, hlr.getHlrIp().trim());
			pstmt.setInt (3, hlr.getHlrPort());
			pstmt.setInt (4, hlr.getConn() );
			pstmt.setString (5, hlr.getLogin ().trim() );
			pstmt.setString (6, hlr.getPassword ().trim() );
			pstmt.executeUpdate ();
			pstmt.close ();
		}
		catch (Exception e)
		{
			try
			{
				if(pstmt != null) pstmt.close ();
				if(rs != null) rs.close ();
			}catch(SQLException sqle)
			{
				logger.error ("Exception in addHLRConfig, Exception is : " + sqle.getMessage ());
			}
			e.printStackTrace ();
			return -1;
		}
		finally{ conPool.free(con); }
		return 0;
	} // addHLRConfig

	public int getHLRConfig (ArrayList hlrConfigAl, int hlrId )
	{
		logger.info ("webadmin: getHLRConfig() for hlrid= "+hlrId);
		try
		{
		con = conPool.getConnection();
			if( hlrId == -1 )
			{
				 query = "select HLR_ID, HLR_NAME, HLR_IP, HLR_PORT, CONNECTIONS, LOGIN, PASSWORD from HLR_CONFIG";
					pstmt = con.prepareStatement (query);
			}
			else
			{
				 query = "select HLR_ID, HLR_NAME, HLR_IP, HLR_PORT, CONNECTIONS, LOGIN, PASSWORD from HLR_CONFIG where HLR_ID=?";
					pstmt = con.prepareStatement (query);
					pstmt.setInt(1,hlrId);
			}
			rs = pstmt.executeQuery ();
			hlrConfigAl.clear ();
			while(rs.next ())
			{
				HLR hlr = new HLR();
				hlr.setHlrId(rs.getInt ("HLR_ID"));
				hlr.setHlrName(rs.getString ("HLR_NAME"));
				hlr.setHlrPort(rs.getInt ("HLR_PORT"));
				hlr.setHlrIp(rs.getString ("HLR_IP"));
				hlr.setConn(rs.getInt ("CONNECTIONS"));
				hlr.setLogin (rs.getString ("LOGIN"));
				hlr.setPassword (rs.getString("PASSWORD"));
				
				hlrConfigAl.add (hlr);
			}
			
			rs.close ();
			pstmt.close ();
		}//try
		catch (Exception e)
		{
			try
			{
				if(rs != null) rs.close ();
				if(pstmt != null) pstmt.close ();
			}catch(SQLException sqle)
			{
				logger.error ("Exception in getHLRConfig, Exception is : " + sqle.getMessage ());
			}
			logger.error ("Exception caught "+e);
			e.printStackTrace ();
			return -1;
		}//catch
		finally{ conPool.free(con); }
		
		return 0;
	}//getHLRConfig
 
 public int updateHLRConfig (HLR hlr)
	{
		logger.debug ("webadmin updateHLRConfig() for HLR_ID= "+ hlr.getHlrId());
		try
		{
		con = conPool.getConnection();
			String query = "update HLR_CONFIG set HLR_IP=?, HLR_PORT=?, CONNECTIONS=?, LOGIN=?, PASSWORD=? where HLR_ID=?";
			pstmt = con.prepareStatement (query);
			pstmt.setString (1, hlr.getHlrIp().trim());
			pstmt.setInt (2, hlr.getHlrPort());
			pstmt.setInt (3, hlr.getConn());
			pstmt.setString (4, hlr.getLogin ().trim());
			pstmt.setString (5, hlr.getPassword ().trim());
			pstmt.setInt (6, hlr.getHlrId());
			pstmt.executeUpdate ();
			pstmt.close ();
		}//try
		catch (Exception e)
		{
			logger.error ("Exception in updateHLRConfig, Exception is : " +e);
			try
			{
				if(pstmt != null) pstmt.close ();
			}catch(SQLException sqle)
			{
				logger.error ("Exception in updateHLRConfig, Exception is : " + sqle.getMessage ());
			}
			e.printStackTrace ();
			return -1;
		}//catch
		finally { conPool.free(con); }
		return 0;
	}//updateHLRConfig
  
 public int deleteHLRConfig (ArrayList hlrIdAl)
	{
		logger.debug ("webadmin: deleteHLRConfig(), hlr id is" + hlrIdAl);
		try
		{
		con = conPool.getConnection();
			String query = "delete from HLR_CONFIG WHERE HLR_ID = ?";
			pstmt = con.prepareStatement (query);
			Iterator ite = hlrIdAl.iterator ();
			while(ite.hasNext ())
			{
				int hlrId =(Integer)ite.next ();
				pstmt.setInt (1, hlrId);
				pstmt.executeUpdate();
			}
			pstmt.close ();
		}
		catch (SQLException e)
		{
			logger.error("Exception in deleteHLRConfig, Exception is : " +e);
			try
			{
				if(pstmt != null) pstmt.close ();
			}catch(SQLException sqle)
			{
				logger.error("Exception in deleteHLRConfig, Exception is : " + sqle.getMessage ());
			}
			e.printStackTrace ();
			if (e.getErrorCode() == 2292)
				return -2;
			else
				return -1;
		}
		finally
		 { conPool.free(con); }
		return 0;
	}//deleteHLRConfig


} //class HLRManager
