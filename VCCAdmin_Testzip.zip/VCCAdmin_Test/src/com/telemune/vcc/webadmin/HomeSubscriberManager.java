
package com.telemune.vcc.webadmin;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import com.telemune.dbutilities.*;
import com.telemune.vcc.common.*;

import org.apache.log4j.*;
public class HomeSubscriberManager
{
                                 static Logger logger=Logger.getLogger(HomeSubscriberManager.class);
				private PreparedStatement pstmt = null;
				private PreparedStatement pstmt1 = null;
				private ResultSet rs =null;
				private ResultSet rs1 =null;
				private String query = null;
				private String query1 = null;
				

 public int addHomeSubscriber (HomeSubDetail homeSubDetail)
	{
	    Connection con=null;
	    logger.info ("webadmin: addHomeSubscriber ");
		try
		{
			con = TSSJavaUtil.instance().getconnection();
			int retVal = checkRange (homeSubDetail);
			if(retVal < 0)
			{
				return retVal; //if -1 then exception occured otherwise User ALREADY EXISTS
			}
			
			// NOT Condition
			if( (!homeSubDetail.getStartAt ().equalsIgnoreCase ("")) && (!homeSubDetail.getStartAt ().equalsIgnoreCase (null)) && (!homeSubDetail.getStartAt ().equalsIgnoreCase ("null")) )
			{
				if(insertRange (homeSubDetail) < 0)
				{
					return -1; //Error in insert
				}
			}
			if(insertExcludes (homeSubDetail) < 0)
			{
				return -1; //Error in insert
			}
		}//try
		catch (Exception e)
		{
				logger.error ("In addHomeSubscriber, SQLException is : " + e.getMessage ());
     		e.printStackTrace ();
		  	return -1;
		}//catch
		finally { 
			try {
				if(con!=null)	TSSJavaUtil.instance().freeConnection(con);
			} catch (Exception e2) {
				// TODO: handle exception 
				 e2.printStackTrace();
			}
		}
		
		return 0;
	} // addHomeSubscriber

	private int checkRange (HomeSubDetail homeSubDetail)
	{
		logger.info ("webadmin: checkRange() in HomeSubscriberManager");
	   Connection con=null;
		try
		{
			con=TSSJavaUtil.instance().getconnection();
			String interStartMsisdn = TSSJavaUtil.instance ().getInternationalNumber ( homeSubDetail.getStartAt ());
			String interEndMsisdn = TSSJavaUtil.instance ().getInternationalNumber (homeSubDetail.getEndsAt ());
			
			query = "select RANGE_ID from OPERATOR_SUBSCRIBER where to_number(STARTS_AT) <= to_number(?)and to_number(ENDS_AT) >= to_number(?)";
			logger.info("query= "+query);
			pstmt = con.prepareStatement (query);
			
			logger.info ("checking for Starting MSISDN "+ interStartMsisdn);
			pstmt.setString (1, interStartMsisdn);
			pstmt.setString (2, interStartMsisdn);
			rs = pstmt.executeQuery ();
			pstmt.clearParameters ();
			while(rs.next ())
			{
				logger.info ("This Number Already Exists ");
				rs.close();
				pstmt.close();
				return -3; //Range already exists(checking starting no. of new range)
			}
			
			logger.info ("checking for Ending MSISDN "+interEndMsisdn);
			pstmt.setString (1, interEndMsisdn);
			pstmt.setString (2, interEndMsisdn);
			rs = pstmt.executeQuery ();
			pstmt.clearParameters ();
			while(rs.next ())
			{
				logger.info ("This Number Exists ");
				rs.close();
				pstmt.close();
				return -3; //Range already exists(checking ending no. of new range)
			}
				rs.close();
				pstmt.close();

			query = "select RANGE_ID from OPERATOR_SUBSCRIBER where to_number(STARTS_AT) >=to_number(?) and to_number(STARTS_AT)<=to_number(?)";
			logger.info("query= "+query);
			pstmt = con.prepareStatement (query);
			logger.debug ("checking for MSISDN Range "+interStartMsisdn+"-"+interEndMsisdn);
			pstmt.setString (1, interStartMsisdn);
			pstmt.setString (2, interEndMsisdn);
			rs = pstmt.executeQuery ();
			pstmt.clearParameters ();
			while(rs.next ())
			{
				logger.debug ("This Range Exists ");
				rs.close();
				pstmt.close();
				return -4; //Range already exists(checking whether new range is superset of some existing range)
			}
		rs.close();
		pstmt.close();
	}
		catch (Exception e)
		{
			try
			{
				if(rs != null) rs.close ();
				if(pstmt != null) pstmt.close ();
			}
			catch(SQLException sqle)
			{
				logger.error ("In checkRange method, SQLException is :" + sqle.getMessage ());
			}
			e.printStackTrace ();
			return -1;
		}
		finally { 
			try {
				if(con!=null)	TSSJavaUtil.instance().freeConnection(con);
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
		return 0;
	} // checkRange

	private int insertRange (HomeSubDetail homeSubDetail)
	{
		logger.info ("webadmin: insertRange()");
		Connection con=null;
		try
		{
			 
			int rangeId = -1;
			con=TSSJavaUtil.instance().getconnection();
			 query = "select crbt_range_id.nextval from dual";
			pstmt = con.prepareStatement (query);
			rs = pstmt.executeQuery ();
			if (rs.next ())
			{
				rangeId = rs.getInt(1);			
				homeSubDetail.setRangeId(rangeId);
				rs.close();
				pstmt.close();
			}
			else
			{
				logger.info ("HomeSubscriberManager insertRange: rangeId not created");
				rs.close();
				pstmt.close();
				return -2;  // 
			}
			
			String interStartAt = TSSJavaUtil.instance ().getInternationalNumber (homeSubDetail.getStartAt ());
			String interEndsAt = TSSJavaUtil.instance ().getInternationalNumber (homeSubDetail.getEndsAt ());
			
			query = "INSERT INTO operator_subscriber(RANGE_ID, STARTS_AT, ENDS_AT, HLR_ID) VALUES(? , ? ,  ?, ?)";
			logger.info("query= "+query);
			pstmt = con.prepareStatement (query);
			pstmt.setInt (1, homeSubDetail.getRangeId ());
			pstmt.setString (2, interStartAt.trim());
			pstmt.setString (3, interEndsAt.trim());
			pstmt.setInt (4, homeSubDetail.getHlrId());
			pstmt.executeUpdate ();
			pstmt.close ();
		}
		catch (SQLException e)
		{
			try
			{
				if(pstmt != null) pstmt.close ();
				if(rs != null) rs.close ();
			}catch(SQLException sqle)
			{
				logger.error ("Exception in insertRange, Exception is : " + sqle.getMessage ());
			}
			e.printStackTrace ();
			return -1;
		}
		finally { 
			try {
				if(con!=null)	TSSJavaUtil.instance().freeConnection(con);
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
		return 0;
	}//insertRange
	
	private int insertExcludes (HomeSubDetail homeSubDetail)
	{
		logger.info ("webadmin insertExcludes()");
		Connection con=null;
		try
		{
			con=TSSJavaUtil.instance().getconnection();
			Iterator ite = (homeSubDetail.getExcludes ()).iterator ();
			 query = "INSERT INTO operator_subscriber_exclude(RANGE_ID, EXCLUDE_NUM) VALUES (?, ?)";
			logger.info("query= "+query);
			pstmt = con.prepareStatement (query);
			while(ite.hasNext ())
			{
				String strExclude = (String) ite.next ();
				String interExcludeMsisdn = TSSJavaUtil.instance ().getInternationalNumber (strExclude);
				pstmt.setInt (1, homeSubDetail.getRangeId ());
				pstmt.setString (2, interExcludeMsisdn.trim());
				pstmt.executeUpdate();
			}
			pstmt.close ();
		}
		catch (Exception e)
		{
			try
			{
				if(pstmt != null) pstmt.close ();
			}catch(SQLException sqle)
			{
				logger.error ("In insertExcludes, SQLException is : " + sqle.getMessage ());
			}
			e.printStackTrace ();
			return -1;
		}
		finally { 
			try {
				if(con!=null)	TSSJavaUtil.instance().freeConnection(con);
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
		return 0;
	} //insertExcludes


 public int getHomeSubscriber (ArrayList homeSubDetailAl,int rangeId)
  {
		logger.info("webadmin getHomeSubscriber()");
		 Connection con=null;
		try
		{
			con = TSSJavaUtil.instance().getconnection();
			if(rangeId==-1)
			{
			query = "select RANGE_ID, STARTS_AT, ENDS_AT, OS.HLR_ID, HLR_NAME from OPERATOR_SUBSCRIBER OS, CRBT_HLR_CONFIG CHC where OS.HLR_ID = CHC.HLR_ID order by STARTS_AT";
			pstmt = con.prepareStatement (query);
			}
			else
			{
				query = "select RANGE_ID, STARTS_AT, ENDS_AT, OS.HLR_ID, HLR_NAME from OPERATOR_SUBSCRIBER OS, CRBT_HLR_CONFIG CHC where OS.HLR_ID = CHC.HLR_ID and RANGE_ID =? order by STARTS_AT";
				pstmt = con.prepareStatement (query);
				pstmt.setInt(1,rangeId);
			}
			logger.info("query= "+query);
			rs = pstmt.executeQuery ();
			while(rs.next ())
			{
				HomeSubDetail homeSubDetail = new HomeSubDetail ();
				homeSubDetail.setRangeId (rs.getInt ("RANGE_ID"));
				homeSubDetail.setStartAt (rs.getString ("STARTS_AT"));
				homeSubDetail.setEndsAt (rs.getString ("ENDS_AT"));
				homeSubDetail.setHlrName (rs.getString ("HLR_NAME"));
				homeSubDetail.setHlrId(rs.getInt ("HLR_ID"));
				
				int i = listExcludes(homeSubDetail);					// get list of numbers excluded from this Range
				homeSubDetailAl.add (homeSubDetail);
	  	}
			
			rs.close ();
			pstmt.close ();
		}
		catch (Exception e)
		{
			logger.error ("Exception in getHomeSubscriber, Exception is : " +e);
			try
			{
				if(rs != null) rs.close ();
				if(pstmt != null) pstmt.close ();
			}catch(SQLException sqle)
			{
				logger.error ("Exception in getHomeSubscriber, Exception is : " + sqle.getMessage ());
			}
			e.printStackTrace ();
			return -1;
		}
		finally { 
			try {
				if(con!=null)	TSSJavaUtil.instance().freeConnection(con);
			} catch (Exception e2) {
				// TODO: handle exception
			}
		} 
		return 0;
	
	}// getHomeSubscriber

	private int listExcludes (HomeSubDetail homeSubDetail)
	{
		logger.info("webadmin listExcludes()");
		Connection con=null;
		try
		{
			con=TSSJavaUtil.instance().getconnection();
			ArrayList excludeAl = new ArrayList ();
			query1 = "select EXCLUDE_NUM from OPERATOR_SUBSCRIBER_EXCLUDE where RANGE_ID = ?";
			logger.info("query= "+query);
			pstmt1 = con.prepareStatement (query1);
			pstmt1.setInt (1, homeSubDetail.getRangeId ());
			rs1 = pstmt1.executeQuery ();
			while(rs1.next ())
			{
				excludeAl.add (rs1.getString ("EXCLUDE_NUM"));
			}
			homeSubDetail.setExcludes (excludeAl);
			rs1.close ();
			pstmt1.close ();
		}
		catch (Exception e)
		{
			try
			{
				if(rs1 != null) rs1.close ();
				if(pstmt1 != null) pstmt1.close ();
			}catch(SQLException sqle)
			{
				logger.error ("Exception in listExcludes, Exception is : " + sqle.getMessage ());
			}
			e.printStackTrace ();
			return -1;
		}
		finally { 
			try {
				if(con!=null)	TSSJavaUtil.instance().freeConnection(con);
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
		return 0;
	} //listExcludes()

 public int deleteHomeSubscriber (ArrayList rangeIdArr)
	{
		logger.info("webadmin deleteHomeSubscriber()");
		Connection con=null;
		try
		{
			con = TSSJavaUtil.instance().getconnection();
			for(int z=0; z<rangeIdArr.size();z++)
			{
				int rangeId = Integer.parseInt((String)rangeIdArr.get(z));
				
				query = "delete from OPERATOR_SUBSCRIBER_EXCLUDE where RANGE_ID = ?";
				logger.info("query= "+query);
				pstmt = con.prepareStatement (query);
				pstmt.setInt (1, rangeId);
				pstmt.executeQuery ();
				
				query = "delete from  OPERATOR_SUBSCRIBER where RANGE_ID = ?";
				logger.info("query= "+query);
				pstmt = con.prepareStatement (query);
				pstmt.setInt (1, rangeId);
				pstmt.executeQuery ();
				pstmt.close ();
			}
		
		}//try
		catch (Exception e)
		{
			try
			{
				if(pstmt != null) pstmt.close ();
			}catch(SQLException sqle)
			{
				logger.error ("Exception in deleteHomeSubscriber, Exception is : " + sqle.getMessage ());
			}
			e.printStackTrace ();
			return -1;
		}//catch
		finally { 
			try {
				if(con!=null)	TSSJavaUtil.instance().freeConnection(con);
			} catch (Exception e2) {
				// TODO: handle exception
			}
		}

		return 0;
	} // deleteHomeSubscriber
	
 public int updateHomeSubscriber (HomeSubDetail homeSubDetail)
	{
		logger.info ("webadmin updateHomeSubscriber()");  // remove all  previous Values and then Insert New
		Connection con=null;
		try
		{
			con = TSSJavaUtil.instance().getconnection();
			query = "delete from  OPERATOR_SUBSCRIBER_EXCLUDE where RANGE_ID = ?";
			logger.info("query= "+query);
			pstmt = con.prepareStatement (query);
			pstmt.setInt (1, homeSubDetail.getRangeId ());
			pstmt.executeUpdate();
		  pstmt.close();	
			
			query = "delete from  OPERATOR_SUBSCRIBER where RANGE_ID = ?";
			logger.info("query= "+query);
			pstmt = con.prepareStatement (query);
			pstmt.setInt (1, homeSubDetail.getRangeId ());
			pstmt.executeUpdate();
		  pstmt.close();	
			return addHomeSubscriber (homeSubDetail); // con.commit() is done inside this method
		}//try
		catch (Exception e)
		{
			try
			{
				if(pstmt != null) pstmt.close ();
			}catch(SQLException sqle)
			{
				logger.error ("In updateHomeSubscriber, SQLException is : " + sqle.getMessage ());
			}
			e.printStackTrace ();
			return -1;
		}//catch
		finally { 
			try {
				if(con!=null)	TSSJavaUtil.instance().freeConnection(con);
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
	// 	finally { conPool.free(con); } // connection is closed in addHomeSubscriber function
	
	} // updateHomeSubscriber

} // class HomeSubscriberManager
