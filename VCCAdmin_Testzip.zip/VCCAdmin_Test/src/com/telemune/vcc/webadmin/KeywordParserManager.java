

package com.telemune.vcc.webadmin;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import com.telemune.dbutilities.*;
import com.telemune.vcc.common.TSSJavaUtil;

import org.apache.log4j.*;
public class KeywordParserManager
{
	static Logger logger=Logger.getLogger(KeywordParserManager.class);
	private PreparedStatement pstmt = null;
	private Connection con = null;
	private ResultSet rs =null;
	private String query = null;

	public int  getProcesses (ArrayList processAl)
	{
		logger.info ("KeywordParserManager: in function getProcesses ");
		try
		{
			con = TSSJavaUtil.instance().getconnection();
			query = "select PROCESS_NAME from LBS_PROCESS_MASTER order by PROCESS_NAME";
			logger.info("query= "+query);
			pstmt = con.prepareStatement (query);
			rs = pstmt.executeQuery ();
			while(rs.next ())
			{
				processAl.add (rs.getString("PROCESS_NAME"));
			}
			rs.close ();
			pstmt.close ();
		}
		catch (Exception e)
		{//log it
			try
			{
				if(rs != null) rs.close ();
				if(pstmt != null) pstmt.close ();
			}catch(SQLException sqle)
			{
				logger.error ("Exception in getProcesses, Exception is : " + sqle.getMessage ());
			}
			logger.error ("Exception Received:" + e);
			return -99;
		}
		finally{ 
			try {
				if(con!=null)	TSSJavaUtil.instance().freeConnection(con);	
			} catch (Exception e2) {
				// TODO: handle exception
			}

		} 
		return 99;

	} // getProcesses

	public int  getPackages (ArrayList packageAl)
	{
		logger.info ("webadmin getPackages");
		try
		{
			con = TSSJavaUtil.instance().getconnection();
			query = "select PACKAGE_NAME from LBS_PACKAGE_MASTER order by PACKAGE_NAME";
			logger.info("query= "+query);
			pstmt = con.prepareStatement (query);
			rs = pstmt.executeQuery ();
			while(rs.next ())
			{
				packageAl.add (rs.getString("PACKAGE_NAME"));
			}
			rs.close ();
			pstmt.close ();
		}
		catch (Exception e)
		{//log it
			try
			{
				if(rs != null) rs.close ();
				if(pstmt != null) pstmt.close ();
			}catch(SQLException sqle)
			{
				logger.error ("Exception in getPackages, Exception is : " + sqle.getMessage ());
			}
			logger.error ("Exception Received:" + e);
			return -99;
		}
		finally { 
			try {
				if(con!=null)	TSSJavaUtil.instance().freeConnection(con);
			} catch (Exception e2) {
				// TODO: handle exception
			}
		}
		return 99;

	} //getPackages

	public int addKeywordParser (KeywordParser keywordParser, String lngID)
	{
		logger.info ("webadmin addKeywordParser");
		try
		{
			con = TSSJavaUtil.instance().getconnection();
			query = "select REQUEST_KEYWORD from LBS_PARSER_MASTER where REQUEST_KEYWORD = ?";
			logger.info("query= "+query);
			pstmt = con.prepareStatement (query);
			pstmt.setString(1, keywordParser.getRequestKeyword() );
			rs = pstmt.executeQuery();
			if(rs.next())
			{
				rs.close();
				pstmt.close();
				return -2; // Keyword name already exist
			}
			rs.close();
			pstmt.close();

			query = "insert into LBS_PARSER_MASTER(REQUEST_KEYWORD, PROCESS_NAME, PACKAGE_NAME, CREATED_BY, CREATION_DATE, LANGUAGE_ID) values (?, ?, 'CrbtSms', ?, sysdate, ?)";
			logger.info("query= "+query);
			pstmt = con.prepareStatement (query);

			pstmt.setString(1, keywordParser.getRequestKeyword().trim() );
			pstmt.setString(2,  keywordParser.getProcessName().trim() );
			pstmt.setString(3, keywordParser.getCreatedBy().trim() );
			pstmt.setString(4, lngID.trim() );

			pstmt.executeUpdate ();
			pstmt.close ();
		}
		catch (Exception e)
		{//log it
			try
			{
				if(pstmt != null) pstmt.close ();
			}catch(SQLException sqle)
			{
				logger.error ("Exception in addKeywordParser, Exception is : " + sqle.getMessage ());
			}
			logger.error ("Exception Received:" + e);
			return -99;
		}
		finally { 
			try {
				if(con!=null)	TSSJavaUtil.instance().freeConnection(con);
			} catch (Exception e2) {
				// TODO: handle exception
			}
		}

		return 0;

	} // addKeywordParser

	public int  getKeywordParser (ArrayList keywordParserAl, String keyword, String order)
	{
		logger.info ("in function getKeywordParser for "+ keyword+"==order=="+order);
		try
		{
			con = TSSJavaUtil.instance().getconnection();
			if(keyword.equalsIgnoreCase("X") )  // show all Keywords
			{
				query = "select REQUEST_KEYWORD, PROCESS_NAME, PACKAGE_NAME, CREATED_BY, CREATION_DATE, UPDATED_BY, UPDATE_DATE from LBS_PARSER_MASTER ORDER BY REQUEST_KEYWORD "+order; //ASC";
				pstmt = con.prepareStatement (query);
			}
			else                    // show keyword given 
			{
				query = "select REQUEST_KEYWORD, PROCESS_NAME, PACKAGE_NAME, CREATED_BY, CREATION_DATE, UPDATED_BY, UPDATE_DATE from LBS_PARSER_MASTER where REQUEST_KEYWORD LIKE ? ORDER BY REQUEST_KEYWORD "+order;  // ASC";
				pstmt = con.prepareStatement (query);
				pstmt.setString(1, "%"+keyword+"%");
			}
			logger.info("query= "+query);
			rs = pstmt.executeQuery ();
			while(rs.next ())
			{
				KeywordParser keyParser = new KeywordParser ();
				keyParser.setRequestKeyword(rs.getString("REQUEST_KEYWORD"));
				keyParser.setProcessName(rs.getString ("PROCESS_NAME"));
				keyParser.setPackageName(rs.getString ("PACKAGE_NAME"));
				keyParser.setCreatedBy(rs.getString("CREATED_BY"));
				keyParser.setCreationDate(rs.getString("CREATION_DATE"));
				keyParser.setUpdatedBy(rs.getString("UPDATED_BY"));
				keyParser.setUpdateDate(rs.getString("UPDATE_DATE"));

				keywordParserAl.add (keyParser);
			}
			rs.close ();
			pstmt.close ();
		}
		catch (Exception e)
		{//log it
			try
			{
				if(rs != null) rs.close ();
				if(pstmt != null) pstmt.close ();
			}catch(SQLException sqle)
			{
				logger.error ("Exception in getKeywordParserData, Exception is : " + sqle.getMessage ());
			}
			logger.error ("Exception Received:" + e);
			return -99;
		}
		finally{
			try {
				if(con!=null)	TSSJavaUtil.instance().freeConnection(con);
			} catch (Exception e2) {
				// TODO: handle exception
			}
		}
		return 99;

	} //getKeywordParserData

	public int deleteKeywordParser (String[] reqKeywords)
	{
		logger.info ("in function deleteKeywordParser");
		try
		{
			con = TSSJavaUtil.instance().getconnection();
			query = "delete from LBS_PARSER_MASTER where REQUEST_KEYWORD = ?";
			logger.info("query= "+query);
			pstmt = con.prepareStatement (query);
			for(int i=0; i<reqKeywords.length; i++)
			{
				pstmt.setString(1, reqKeywords[i]);
				pstmt.executeUpdate();
			}
			pstmt.close ();
		}
		catch (Exception e)
		{//log it
			try
			{
				if(pstmt != null) pstmt.close ();
			}catch(SQLException sqle)
			{
				logger.error ("Exception in deleteKeywordParser, Exception is : " + sqle.getMessage ());
			}
			return -99;
		}
		finally{ try {
			if(con!=null)	TSSJavaUtil.instance().freeConnection(con);
		} catch (Exception e2) {
			// TODO: handle exception
		} }

		return 99;

	} //deleteKeywordParserData

	public int updateKeywordParser (KeywordParser keyParser,String old_keyword)
	{
		logger.info ("in function updateKeywordParser for \" "+ keyParser.getRequestKeyword() + "\" & "+ keyParser.getProcessName() );
		try
		{
			con = TSSJavaUtil.instance().getconnection();
			query = "update LBS_PARSER_MASTER set PROCESS_NAME=?, REQUEST_KEYWORD=?, UPDATE_DATE=sysdate where REQUEST_KEYWORD=?";
			logger.info("query= "+query);
			//query = "update LBS_PARSER_MASTER set PROCESS_NAME=?, UPDATE_DATE=sysdate where REQUEST_KEYWORD=?";
			pstmt = con.prepareStatement (query);
			pstmt.setString(1, keyParser.getProcessName().trim() );
			pstmt.setString(2, keyParser.getRequestKeyword().trim() );
			pstmt.setString(3, old_keyword.trim() );

			pstmt.executeUpdate ();
			pstmt.close ();
		}
		catch (Exception e)
		{//log it
			try
			{
				if(pstmt != null) pstmt.close ();
			}catch(SQLException sqle)
			{
				logger.error ("Exception in updateKeywordParser, Exception is : " + sqle.getMessage ());
			}
			logger.error ("Exception Received:" + e);
			return -99;
		}
		finally{
			try {
				if(con!=null)	TSSJavaUtil.instance().freeConnection(con);
			} catch (Exception e2) {
				// TODO: handle exception
			}
		}

		return 99;

	} //updateKeywordParserData
	public String  getDesc (String process)
	{
		logger.info ("KeywordParserManager: in function getDesc ");
		String desc="";
		String syntax="";
		String result="";
		try
		{
			con = TSSJavaUtil.instance().getconnection();
			query = "select SYNTAX_MESSAGE,DESCRIPTION from LBS_PROCESS_MASTER where PROCESS_NAME=?";
			pstmt = con.prepareStatement (query);
			pstmt.setString(1, process);
			rs = pstmt.executeQuery ();
			while(rs.next ())
			{
				syntax=rs.getString("SYNTAX_MESSAGE");
				desc=rs.getString("DESCRIPTION");
			}
			rs.close ();
			pstmt.close ();
		}
		catch (Exception e)
		{//log it
			logger.error ("Exception Received:" + e);
		}
		finally{
			try {
				if(con!=null)	TSSJavaUtil.instance().freeConnection(con);
			} catch (Exception e2) {
				// TODO: handle exception
			}
		} 
		result=syntax+"--"+desc;
		return result;

	} // getDesc
	public int  getKeywordDetail (ArrayList keywordParserAl, String keyword)
	{
		logger.info ("in function getKeywordParser for "+ keyword);
		String Request_keyword="";
		try
		{
			con = TSSJavaUtil.instance().getconnection();
			query = "select PROCESS_NAME from LBS_PARSER_MASTER WHERE REQUEST_KEYWORD = ?";
			logger.info("query= "+query);
			pstmt = con.prepareStatement (query);
			pstmt.setString(1, keyword);
			rs = pstmt.executeQuery ();
			while(rs.next ())
			{
				Request_keyword=rs.getString ("PROCESS_NAME");
			}
			rs.close ();
			pstmt.close ();

			query = "select PROCESS_NAME, MIN_ARGUMENTS, MAX_ARGUMENTS, SYNTAX_MESSAGE, DESCRIPTION from LBS_PROCESS_MASTER WHERE PROCESS_NAME = ?";
			logger.info("query= "+query);
			pstmt = con.prepareStatement (query);
			pstmt.setString(1, Request_keyword);
			rs = pstmt.executeQuery ();
			while(rs.next ())
			{
				KeywordParser keyParser = new KeywordParser ();
				//	keyParser.setRequestKeyword(rs.getString ("REQUEST_KEYWORD"));
				keyParser.setProcessName(rs.getString ("PROCESS_NAME"));
				keyParser.setMinArgument(Integer.parseInt(rs.getString ("MIN_ARGUMENTS")));
				keyParser.setMaxArgument(Integer.parseInt(rs.getString("MAX_ARGUMENTS")));
				keyParser.setSyntaxMessage(rs.getString("SYNTAX_MESSAGE"));
				keyParser.setDesc(rs.getString("DESCRIPTION"));

				keywordParserAl.add (keyParser);
			}
			rs.close ();
			pstmt.close ();
		}
		catch (Exception e)
		{//log it
			try
			{
				if(rs != null) rs.close ();
				if(pstmt != null) pstmt.close ();
			}catch(SQLException sqle)
			{
				logger.error ("Exception in getKeywordParserData, Exception is : " + sqle.getMessage ());
			}
			logger.error ("Exception Received:" + e);
			return -99;
		}
		finally{ 
			try {
				if(con!=null)	TSSJavaUtil.instance().freeConnection(con);
			} catch (Exception e2) {
				// TODO: handle exception
			}
		}
		return 99;

	} //getKeywordDetail


} // class KeywordParserManager
