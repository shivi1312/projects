/*
 * TemplateSMS.java
 *
 * Created on October 8, 2004, 5:29 PM
 */

package com.telemune.vcc.webadmin;

/**
 *
 * @author  ripu
 */
 import org.apache.log4j.*;
public class KeywordSMS implements java.io.Serializable
 {
     static Logger logger=Logger.getLogger(KeywordSMS.class);
   
    private int  processid = 0;
    private String processname = null;
    private String packagename= null;
				
    private int  minargument = 0;

    private int  maxargument = 0;
				 private String createdby= null;
					 private String creationdate= null;
						 private String updateby= null;
							 private String syntaxmessage= null;
								 private String updatedate= null;
									


				
    
   /** Creates a new instance of keywordSMS */
    public KeywordSMS()
		 {
   
							  logger.debug ("in  KeywordSMS");
									
							processid = 0;
        processname = "";
     packagename="";
									minargument=0;
									maxargument=0;
									createdby="";
									creationdate="";
									updateby="";
									syntaxmessage="";
									updatedate="";

								
    }
    
    
    public void setProcessId(int processid)
		 {
        this.processid = processid;
    }

    
    public void setProcessName(String processname)
		 {
        this.processname = processname;
    }
    
    
    public void setPackageName(String packagename)
		 {
        this.packagename =packagename;
    }
    
    
    public void setMinArgument(int minargument)
		 {
        this.minargument =minargument;
    }
    
    public void setMaxArgument(int maxargument)
		 {
        this.maxargument= maxargument;
    }
   public void setCreateBy(String createdby)
	 {
					 this.createdby=createdby;
	 }

		  public void setCreationDate(String creationdate)
								  {
														      this.creationdate=creationdate;
																				  }


				  public void setUpdateBy(String updateby)
										  {
																      this.updateby=updateby;
																						  }


						  public void setSyntaxMessage(String syntaxmessage)
												  {
																		      this.syntaxmessage=syntaxmessage;
																								  }


								

								     public void setUpdateDate(String updatedate)
																	              {
																												this.updatedate=updatedate;
																																}
		
		
		
		
		/*   **** get values ******            */
    public int   getProcessId()
		 {
        return processid;
    }
    
				public String getProcessName()
		 {
        return processname;
    }
   
				public String getPackageName()
		 {
        return packagename;
    }
   
				public int  getMinArgument()
		 {
        return minargument;
    }
    public int  getMaxArgument()
		 {
        return maxargument;
    }
	 

		
																																					
				
				
				public String  getCreateBy()
	 {
					 return createdby;
	 }


	
	    public String  getCreationDate()
									  {
															      return creationdate;
																					  }
					   
					public String  getUpdateBy()
													  {
																			      return updateby;
																									  }
									 
					public String  getSyntaxMessage()
																	  {
																							      return syntaxmessage;
																													  }
													
	
	
	
    public String  getUpdateDate()
								                   {
																								  return updatedate;
																												 }


				
	

	} 










//class KeywordSMS
