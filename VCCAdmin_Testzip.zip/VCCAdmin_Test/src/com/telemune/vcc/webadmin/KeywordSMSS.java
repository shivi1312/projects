/*
 * TemplateSMS.java
 *
 * Created on October 8, 2004, 5:29 PM
 */

package com.telemune.vcc.webadmin;

/**
 *
 * @author  ripu
 */
public class KeywordSMSS implements java.io.Serializable
{



	private String requestkeyword= null;

	private String processname = null;
	private String packagename= null;
	private String createdby= null;
	private String creationdate= null;
	private String updateby= null;
	private String updatedate= null;
	private int languageid=0;
	private String isworking=null;





	/** Creates a new instance of keywordSMS */
	public KeywordSMSS()
	{




		requestkeyword ="";
		processname = "";
		packagename="";
		createdby="";
		creationdate="";
		updateby="";
		updatedate="";
		languageid=0;
		isworking="";

	}


	public void setRequestKeyword(String requestkeyword)
	{
		this.requestkeyword = requestkeyword;
	}


	public void setProcessName(String processname)
	{
		this.processname = processname;
	}


	public void setPackageName(String packagename)
	{
		this.packagename =packagename;
	}


	public void setCreatedBy(String createdby)
	{
		this.createdby=createdby;
	}

	public void setCreationDate(String  creationdate )
	{
		this.creationdate=creationdate;
	}

	public void setUpdateBy(String updateby)
	{
		this.updateby=updateby;
	}


	public void setUpdateDate(String updatedate)
	{
		this.updatedate=updatedate;
	}








	public void setLanguageId(int languageid)
	{
		this.languageid=languageid;
	}



	public void setIsWorking(String  isworking)
	{
		this.isworking=isworking;
	}




	/*   **** get values ******            */
	public String  getRequestKeyword()
	{
		return requestkeyword;
	}

	public String getProcessName()
	{
		return processname;
	}

	public String getPackageName()
	{
		return packagename;
	}


	public String  getCreatedBy()
	{
		return createdby;
	}
	public String  getCreationDate()
	{
		return creationdate;
	}



	public String  getUpdateBy()
	{
		return updateby;
	}





	public String  getUpdateDate()
	{
		return updatedate;
	}



	public int   getLanguageId()
	{
		return languageid;
	}

	public String  getIsWorking()
	{
		return isworking;
	}






} 










//class KeywordSMS
