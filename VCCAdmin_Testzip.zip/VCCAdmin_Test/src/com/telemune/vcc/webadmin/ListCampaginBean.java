package com.telemune.vcc.webadmin;

import java.io.File;

public class ListCampaginBean {

	
	private int list_id;
	private String listName;
	private File uploadFile;
	private int listCount;
	
	public int getListCount() {
		return listCount;
	}
	public void setListCount(int listCount) {
		this.listCount = listCount;
	}
	public File getUploadFile() {
		return uploadFile;
	}
	public void setUploadFile(File uploadFile) {
		this.uploadFile = uploadFile;
	}
	public ListCampaginBean(int list_id,String list_name)
	 {
		 this.list_id=list_id;
		 this.listName=list_name;
	 }
	public ListCampaginBean(int list_id,String list_name,int listCount)
	 {
		 this.list_id=list_id;
		 this.listName=list_name;
		 this.listCount=listCount;
	 }
	 public ListCampaginBean()
	 {
		
	 }
	public int getList_id() {
		return list_id;
	}

	public void setList_id(int list_id) {
		this.list_id = list_id;
	}
	public String getListName() {
		return listName;
	}
	public void setListName(String listName) {
		this.listName = listName;
	}
}
