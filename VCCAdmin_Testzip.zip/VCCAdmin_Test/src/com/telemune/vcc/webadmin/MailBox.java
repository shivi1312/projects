package com.telemune.vcc.webadmin;

import java.util.ArrayList;

public class MailBox {
	private int mailBoxId;
	private String mailBoxType="";
	private int maxMessage;
	private int msgLifetime;
	private int msgTimeAftrRet;
	private int mgsTimAftrSav;
	private int maxRecordTime;
	private ArrayList<Integer> deleteList;
	
	public int getMailBoxId() {
		return mailBoxId;
	}
	public void setMailBoxId(int mailBoxId) {
		this.mailBoxId = mailBoxId;
	}
	public String getMailBoxType() {
		return mailBoxType;
	}
	public void setMailBoxType(String mailBoxType) {
		this.mailBoxType = mailBoxType;
	}
	public int getMaxMessage() {
		return maxMessage;
	}
	public void setMaxMessage(int maxMessage) {
		this.maxMessage = maxMessage;
	}
	public int getMsgLifetime() {
		return msgLifetime;
	}
	public void setMsgLifetime(int msgLifetime) {
		this.msgLifetime = msgLifetime;
	}
	public int getMsgTimeAftrRet() {
		return msgTimeAftrRet;
	}
	public void setMsgTimeAftrRet(int msgTimeAftrRet) {
		this.msgTimeAftrRet = msgTimeAftrRet;
	}
	public int getMgsTimAftrSav() {
		return mgsTimAftrSav;
	}
	public void setMgsTimAftrSav(int mgsTimAftrSav) {
		this.mgsTimAftrSav = mgsTimAftrSav;
	}
	public int getMaxRecordTime() {
		return maxRecordTime;
	}
	public void setMaxRecordTime(int maxRecordTime) {
		this.maxRecordTime = maxRecordTime;
		
		
	}
	public ArrayList<Integer> getDeleteList() {
		return deleteList;
	}
	public void setDeleteList(ArrayList<Integer> deleteList) {
		this.deleteList = deleteList;
	}
	@Override
	public String toString() {
		return "MailBox [mailBoxId=" + mailBoxId + ", mailBoxType="
				+ mailBoxType + ", maxMessage=" + maxMessage + ", msgLifetime="
				+ msgLifetime + ", msgTimeAftrRet=" + msgTimeAftrRet
				+ ", mgsTimAftrSav=" + mgsTimAftrSav + ", maxRecordTime="
				+ maxRecordTime + "]";
	}
	
	
}
