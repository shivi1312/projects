package com.telemune.vcc.webadmin;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import com.telemune.dbutilities.*;

import org.apache.log4j.*;
public class MailBoxManager

{
                private static Logger logger=Logger.getLogger(MailBoxManager.class);
				private ConnectionPool conPool = null;
				private PreparedStatement pstmt = null;
				private Connection con = null;
				private ResultSet rs =null;
				private String query = null;
				MailBox mailBox=null;
				
 public MailBoxManager()				 
 {
				 conPool = new ConnectionPool();
 }

   public void setConnectionPool(ConnectionPool conPool)
        {
                this.conPool = conPool;
        }

        public ConnectionPool getConnectionPool()
        {
                return conPool;
        }

 public int addMailBoxDetail(MailBox mailBox)
	{
		logger.debug ("Inside function webadmin: addMailBox");
		try
		{
		con = conPool.getConnection();
		
			query = "select MAILBOX_TYPE from VCC_MAILBOX_PARAMS where  MAILBOX_TYPE= ?";
			pstmt = con.prepareStatement (query);
			pstmt.setString (1, mailBox.getMailBoxType());
			rs = pstmt.executeQuery();
			if (rs.next())
			{
				rs.close();			
				pstmt.close();
				logger.info("webadmin; This MAil Box "+mailBox.getMailBoxType()+ " already exists");
				return -2;
			}
				rs.close();			
				pstmt.close();

			int hlrId = 0;

			query = "insert into VCC_MAILBOX_PARAMS (MAILBOX_TYPE,MAX_MESSAGES,MSG_LIFETIME,MSG_LIFETIME_AFTER_RET,MSG_LIFETIME_AFTER_SAVE,MAX_RECORDING_TIME) values (?, ?, ?, ?, ?, ?)";
			pstmt = con.prepareStatement (query);
		
			pstmt.setString (1, mailBox.getMailBoxType().trim());
			pstmt.setInt(2, mailBox.getMaxMessage());
			pstmt.setInt (3, mailBox.getMsgLifetime());
			pstmt.setInt (4, mailBox.getMsgTimeAftrRet());
			pstmt.setInt (5,mailBox.getMgsTimAftrSav());
			pstmt.setInt(6,mailBox.getMaxRecordTime() );
			pstmt.executeUpdate ();
			pstmt.close ();
		}
		catch (Exception e)
		{
			try
			{
				if(pstmt != null) pstmt.close ();
				if(rs != null) rs.close ();
			}catch(SQLException sqle)
			{
				logger.error ("Exception in addMailBox, Exception is : " + sqle.getMessage ());
			}
			e.printStackTrace ();
			return -1;
		}
		finally{ conPool.free(con); }
		return 0;
	} // addMailBox

	public int getMailBoxDetail(ArrayList<MailBox> mailBoxAl, int mailBoxId )
	{
		logger.info ("webadmin: getMailBoxdetail() for mailBoxid= "+mailBoxId);
		try
		{
		con = conPool.getConnection();
			if( mailBoxId == -1 )
			{
				 query = "select MAILBOX_ID,MAILBOX_TYPE,MAX_MESSAGES,MSG_LIFETIME,MSG_LIFETIME_AFTER_RET,MSG_LIFETIME_AFTER_SAVE,MAX_RECORDING_TIME from VCC_MAILBOX_PARAMS";
					pstmt = con.prepareStatement (query);
			}
			else
			{
				 query = "select MAILBOX_ID,MAILBOX_TYPE,MAX_MESSAGES,MSG_LIFETIME,MSG_LIFETIME_AFTER_RET,MSG_LIFETIME_AFTER_SAVE,MAX_RECORDING_TIME from VCC_MAILBOX_PARAMS where MAILBOX_ID=?";
					pstmt = con.prepareStatement (query);
					pstmt.setInt(1,mailBoxId);
			}
			rs = pstmt.executeQuery ();
			mailBoxAl.clear ();
			while(rs.next ())
			{
				mailBox=new MailBox();
				mailBox.setMailBoxId(rs.getInt ("MAILBOX_ID"));
				mailBox.setMailBoxType(rs.getString("MAILBOX_TYPE"));
				mailBox.setMaxMessage(rs.getInt ("MAX_MESSAGES"));
				mailBox.setMsgLifetime(rs.getInt("MSG_LIFETIME"));
				mailBox.setMsgTimeAftrRet(rs.getInt("MSG_LIFETIME_AFTER_RET"));
				mailBox.setMgsTimAftrSav(rs.getInt("MSG_LIFETIME_AFTER_SAVE"));
				mailBox.setMaxRecordTime(rs.getInt("MAX_RECORDING_TIME"));
				mailBoxAl.add(mailBox);
			}
			
			rs.close ();
			pstmt.close ();
		}//try
		catch (Exception e)
		{
			try
			{
				if(rs != null) rs.close ();
				if(pstmt != null) pstmt.close ();
			}catch(SQLException sqle)
			{
				logger.error ("Exception in getHLRConfig, Exception is : " + sqle.getMessage ());
			}
			logger.error ("Exception caught "+e);
			e.printStackTrace ();
			return -1;
		}//catch
		finally{ conPool.free(con); }
		
		return 0;
	}//getMailBox
 
 public int updateMAilBox (MailBox mailBox)
	{
		logger.info ("webadmin updatemailBox() for MailBoxId= "+ mailBox.getMailBoxId());
		try
		{
		con = conPool.getConnection();
			String query = "update VCC_MAILBOX_PARAMS set MAX_MESSAGES=?,MSG_LIFETIME=?,MSG_LIFETIME_AFTER_RET=?,MSG_LIFETIME_AFTER_SAVE=?,MAX_RECORDING_TIME=? where MAILBOX_ID=?";
			pstmt = con.prepareStatement (query);

			pstmt.setInt (1,mailBox.getMaxMessage());
			pstmt.setInt (2,mailBox.getMsgLifetime());
			pstmt.setInt(3,mailBox.getMsgTimeAftrRet());
			pstmt.setInt(4, mailBox.getMgsTimAftrSav());
			pstmt.setInt (5,mailBox.getMaxRecordTime());
			pstmt.setInt(6,mailBox.getMailBoxId());
			pstmt.executeUpdate ();
			pstmt.close ();
		}//try
		catch (Exception e)
		{
			logger.error ("Exception in updateMailBox, Exception is : " +e);
			try
			{
				if(pstmt != null) pstmt.close ();
			}catch(SQLException sqle)
			{
				logger.error ("Exception in updateMailBox, Exception is : " + sqle.getMessage ());
			}
			e.printStackTrace ();
			return -1;
		}//catch
		finally { conPool.free(con); }
		return 0;
	}//updateMailBox
  
 public int deleteMailBox (ArrayList mailBoxIdAl)
	{
		logger.debug ("webadmin: deleteMailBox(), MailBox id is" + mailBoxIdAl);
		int mailBoxId=-1;
		try
		{
		con = conPool.getConnection();
			String query = "delete from VCC_MAILBOX_PARAMS where MAILBOX_ID=?";
			pstmt = con.prepareStatement (query);
			Iterator ite = mailBoxIdAl.iterator ();
			while(ite.hasNext ())
			{
				mailBoxId =(Integer)ite.next ();
				pstmt.setInt (1, mailBoxId);
				pstmt.executeUpdate();
			}
			pstmt.close ();
		}
		catch (SQLException e)
		{
			logger.error("Exception in deleteMailBox, Exception is : " +e);
			try
			{
				if(pstmt != null) pstmt.close ();
			}catch(SQLException sqle)
			{
				logger.error("Exception in deleteMailBox, Exception is : " + sqle.getMessage ());
			}
			e.printStackTrace ();
			if (e.getErrorCode() == 2292)
				return -2;
			else
				return -1;
		}
		finally
		 { conPool.free(con); }
		return 0;
	}//deleteMailBox


} //class MailBoxManager

