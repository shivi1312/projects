
// modified on 12-01-2006
//@author Jatinder Pal
package com.telemune.vcc.webadmin;

import java.util.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.telemune.dbutilities.*;
import org.apache.log4j.*;
public class OccasionManager
{
	static Logger logger=Logger.getLogger(OccasionManager.class);

	private ResultSet rs = null;
	private PreparedStatement pstmt = null;
	private PreparedStatement pstmt1 = null;
	private Connection con = null;
	private String query = null;
	private String query1 = null;



	public int addOccasion (Occasion ocobj,Connection con)
	{
		logger.info("webadmin: addOccasion");
		try
		{
			//con = conPool.getConnection();
			query = "SELECT OCCASION_NAME, OCCASION_DATE FROM CRBT_OCCASION_LIST WHERE OCCASION_NAME LIKE ? ";	
			logger.info("query= "+query);
			pstmt = con.prepareStatement (query);
			pstmt.setString (1,"%"+ ocobj.getOccasionName ()+"%");
			rs = pstmt.executeQuery ();
			if(rs.next ())
			{
				rs.close ();
				pstmt.close ();
				return -2; //Record already exists
			}
			rs.close ();
			pstmt.close ();
			query = "INSERT INTO CRBT_OCCASION_LIST (OCCASION_NAME,OCCASION_DATE, IS_CONSTANT,UPDATE_TIME, DESCRIPTION) VALUES (?,to_date(to_char(to_date(?,'dd-mm-yyyy'),'dd-mon-yyyy'),'dd-mon-yyyy'), ?,sysdate,?)";
			logger.info("query= "+query);
			//query = "INSERT INTO CRBT_OCCASION_LIST (OCCASION_NAME,OCCASION_DATE, IS_CONSTANT,UPDATE_TIME, DESCRIPTION) VALUES (?,to_date(?), ?,sysdate,?)";
			//			query = "INSERT INTO CRBT_OCCASION_LIST (OCCASION_NAME,OCCASION_DATE, IS_CONSTANT,UPDATE_TIME, DESCRIPTION) VALUES (?,?, ?,sysdate,?)";
			pstmt = con.prepareStatement (query);

			logger.debug(query);
			pstmt.setString (1, ocobj.getOccasionName ().trim());
			pstmt.setString (2, ocobj.getOccasionDate ().trim());
			pstmt.setString (3, ocobj.getIsConstant().trim());
			pstmt.setString (4, ocobj.getDescription ().trim());

			pstmt.executeUpdate ();
			pstmt.close ();


		}//try
		catch (Exception e)
		{
			try
			{
				if(pstmt != null) pstmt.close ();
			}catch(SQLException sqle)
			{
				logger.error ("webadmin-addOccassion: Exception in addOccassion, Exception is : " + sqle.getMessage ());
			}

			e.printStackTrace ();
			return -1;
		}
		//		finally  { conPool.free(con); } 
		return 1; //  added susccessfully

	}// add()

	public int getOccasions (ArrayList ocAl,Connection con)
	{
		logger.info("getOccasions() ");
		try
		{
			//con = conPool.getConnection();
			query = "select OCCASION_NAME,to_char(OCCASION_DATE, 'DD-MM-YYYY')OCCASION_DATE,IS_CONSTANT from CRBT_OCCASION_LIST ";
			logger.info("query= "+query);
			pstmt = con.prepareStatement (query);
			rs = pstmt.executeQuery ();
			while(rs.next ())
			{
				Occasion ocob = new Occasion ();
				ocob.setOccasionName (rs.getString ("OCCASION_NAME"));
				ocob.setOccasionDate (rs.getString ("OCCASION_DATE"));
				ocob.setIsConstant (rs.getString ("IS_CONSTANT"));
				ocAl.add (ocob);
			}
			rs.close ();
			pstmt.close ();
		} //try
		catch (Exception e)
		{
			try
			{
				if(rs != null) rs.close ();
				if(pstmt != null) pstmt.close ();
			}catch(SQLException sqle)
			{
				logger.error ("Exception in listUser, Exception is : " + sqle.getMessage ());
			}
			e.printStackTrace ();
			return -1;
		}
		//finally{ conPool.free(con); }
		return 1;
	}//get

	public int getOccasions (ArrayList ocAl,String ocName,Connection con)
	{
		logger.info("getOccasions() ");
		try
		{
			//con = conPool.getConnection();
			{
				query = "select OCCASION_NAME,to_char(OCCASION_DATE, 'DD-MM-YYYY')OCCASION_DATE,IS_CONSTANT,DESCRIPTION from CRBT_OCCASION_LIST WHERE OCCASION_NAME=?";
				logger.info("query= "+query);
				pstmt = con.prepareStatement (query);
				pstmt.setString(1,ocName);
			}
			rs = pstmt.executeQuery ();
			while(rs.next ())
			{
				Occasion ocob = new Occasion ();
				ocob.setOccasionName (rs.getString ("OCCASION_NAME"));
				ocob.setOccasionDate (rs.getString ("OCCASION_DATE"));
				ocob.setIsConstant (rs.getString ("IS_CONSTANT"));
				ocob.setDescription(rs.getString("DESCRIPTION"));
				ocAl.add (ocob);
			}
			rs.close ();
			pstmt.close ();
		} //try
		catch (Exception e)
		{
			try
			{
				if(rs != null) rs.close ();
				if(pstmt != null) pstmt.close ();
			}catch(SQLException sqle)
			{
				logger.error ("Exception in listUser, Exception is : " + sqle.getMessage ());
			}
			e.printStackTrace ();
			return -1;
		}
		//finally{ conPool.free(con); }
		return 1;

	}//get

	public int updateOccasion (Occasion ocobj, String oldName,Connection con)
	{
		logger.info("in function updateOccasion() "+oldName);
		System.out.println("old name : "+oldName);
		try
		{
			//con = conPool.getConnection();
			if(ocobj.getOccasionName().equalsIgnoreCase(oldName))
			{}
			else
			{
				query = "SELECT OCCASION_NAME, OCCASION_DATE FROM CRBT_OCCASION_LIST WHERE OCCASION_NAME LIKE ? ";
				logger.info("query= "+query);
				pstmt = con.prepareStatement (query);
				pstmt.setString (1,"%"+ ocobj.getOccasionName ()+"%");
				rs = pstmt.executeQuery ();
				if(rs.next ())
				{
					logger.info("already exists");
					rs.close ();
					pstmt.close ();
					return -2; //Record already exists
				}
				rs.close ();
				pstmt.close ();
			}
			query = "UPDATE CRBT_OCCASION_LIST SET OCCASION_NAME=?, OCCASION_DATE=to_date(to_char(to_date(?,'dd-mm-yyyy'),'dd-mon-yyyy'),'dd-mon-yyyy'), IS_CONSTANT=? , UPDATE_TIME=sysdate , DESCRIPTION=? where OCCASION_NAME=?";
			//query = "UPDATE CRBT_OCCASION_LIST SET OCCASION_NAME=?, OCCASION_DATE=to_date(?), IS_CONSTANT=? , UPDATE_TIME=sysdate , DESCRIPTION=? where OCCASION_NAME=?";
			logger.info("query= "+query);
			pstmt = con.prepareStatement (query);
			logger.debug(query);

			pstmt.setString (1, ocobj.getOccasionName ().trim());
			pstmt.setString (2, ocobj.getOccasionDate ().trim());
			pstmt.setString (3, ocobj.getIsConstant().trim());
			pstmt.setString (4, ocobj.getDescription ().trim());
			pstmt.setString (5, oldName.trim());
			System.out.println("query for CRBT_OCCASION_LIST update : "+query);
			pstmt.executeUpdate ();
			pstmt.close ();
			logger.info("updated CRBT_OCCASION_LIST with values : "+ocobj.getOccasionName()+":"+ocobj.getOccasionDate()+":"+ocobj.getDescription()+":"+ocobj.getIsConstant());
		}//try
		catch (Exception e)
		{
			try
			{
				if(pstmt != null) pstmt.close ();
				if(rs != null) rs.close ();
			}catch(SQLException sqle)
			{
				logger.error ("Exception in updateCorp, Exception is : " + sqle.getMessage ());
			}
			e.printStackTrace ();
			return -1;
		}
		//finally{conPool.free(con); }
		return 1;
	} // updateCorp

	public int deleteOccasion (ArrayList ocAl,Connection con)
	{
		logger.info("deleteOccasion()");
		try
		{
			//con = conPool.getConnection();
			query = "delete from CRBT_OCCASION_LIST WHERE OCCASION_NAME=?";
			logger.info("query= "+query);
			pstmt = con.prepareStatement(query);
			Iterator ite1 = ocAl.iterator();
			while (ite1.hasNext())
			{
				pstmt.setString (1,(String)ite1.next());
				pstmt.executeUpdate();
				//										 logger.info(query);
			}
			pstmt.close();


		}//try
		catch (Exception e)
		{
			try
			{
				if(pstmt != null) pstmt.close ();
			}catch(SQLException sqle)
			{
				logger.error ("Exception in deleteCorpData(), Exception is : " + sqle.getMessage ());
			}
			e.printStackTrace ();
			return -1;
		}
		//finally{ conPool.free(con);  }
		return 1;
	}//delete

} //class CorpManager
