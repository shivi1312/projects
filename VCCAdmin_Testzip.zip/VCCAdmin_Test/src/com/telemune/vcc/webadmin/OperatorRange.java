package com.telemune.vcc.webadmin;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.telemune.dbutilities.Connection;
import com.telemune.dbutilities.ConnectionPool;
import com.telemune.dbutilities.PreparedStatement;

public class OperatorRange {
	
	 private static Logger logger=Logger.getLogger(OperatorRange.class);
		private ConnectionPool conPool = null;
		private PreparedStatement pstmt = null;
		private OperatorRange operatorRange=null;
		private Connection con = null;
		private ResultSet rs =null;
		private String query = null;
		private int groupId;
		private String groupName;
		private String isSelected;
		
		
		
		
		public String getIsSelected() {
			return isSelected;
		}
		public void setIsSelected(String isSelected) {
			this.isSelected = isSelected;
		}
		public int getGroupId() {
			return groupId;
		}
		public void setGroupId(int groupId) {
			this.groupId = groupId;
		}	
		public String getGroupName() {
			return groupName;
		}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public OperatorRange()				 
	 {
					 conPool = new ConnectionPool();
	 }

	   public void setConnectionPool(ConnectionPool conPool)
	        {
	                this.conPool = conPool;
	        }

	        public ConnectionPool getConnectionPool()
	        {
	                return conPool;
	        }
	        public ArrayList<OperatorRange> getGroupDetail(int groupId)
	        {
	        	ArrayList<OperatorRange> operatorList=new ArrayList<OperatorRange>();
	        	logger.info ("webadmin: getGroupDetail for groupId= "+groupId);
	    		try
	    		{
	    		con = conPool.getConnection();
	    			if( groupId == -1 )
	    			{
	    				 query="select GROUP_ID,GROUP_NAME from VCC_SERIES_GROUP";
	    					pstmt = con.prepareStatement (query);
	    			}
	    			else
	    			{
	    				query="select GROUP_ID,GROUP_NAME from VCC_SERIES_GROUP where GROUP_ID=?";
    					pstmt = con.prepareStatement (query);
	    					pstmt.setInt(1,groupId);
	    			}
	    			rs = pstmt.executeQuery ();
	    			while(rs.next ())
	    			{
	    				operatorRange=new OperatorRange();
	    				operatorRange.setGroupId(rs.getInt("GROUP_ID"));
	    				operatorRange.setGroupName(rs.getString("GROUP_NAME"));
	    				operatorList.add(operatorRange);
	    				
	    			}
	    			
	    			rs.close ();
	    			pstmt.close ();
	    		}//try
	    		catch (Exception e)
	    		{
	    			try
	    			{
	    				if(rs != null) rs.close ();
	    				if(pstmt != null) pstmt.close ();
	    			}catch(SQLException sqle)
	    			{
	    				logger.error ("Exception in getGroupDetail, Exception is : " + sqle.getMessage ());
	    			}
	    			logger.error ("Exception caught "+e);
	    			e.printStackTrace ();
	    			
	    		}//catch
	    		finally{ conPool.free(con); }
	    		
	    		return operatorList;
	        }

}
