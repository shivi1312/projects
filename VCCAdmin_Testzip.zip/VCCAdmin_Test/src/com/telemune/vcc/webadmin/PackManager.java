package com.telemune.vcc.webadmin;

import com.telemune.dbutilities.*;
import com.telemune.vcc.common.TSSJavaUtil;
import com.telemune.vcc.webadmin.action.PackSubBean;
import com.telemune.vcc.webadmin.action.PackSubNewBean;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;

public class PackManager {

	private Logger logger=Logger.getLogger(PackManager.class);
	public PackManager() {
	
	}
	
	
	/**
	 * 
	 *   
	 * This method provide list of all charing codes's detail available in CRBT_CHARGING_CODE table.
	 * 
	 * @return	
	 * 	List<ChargingCodeDetail> object if successful, 
	 * 	null = in case any error occurred.	
	 */
	public List<ChargingCodeDetail> getChargingCodeList(){
		
		logger.info(" under getChargingCodeList() ");
		
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		Connection con=null;
		
		
		String SQL="select REQ_ID,CHARGING_CODE,AMOUNT_PRE,AMOUNT_POST,DESCRIPTION,TARIFF_PRE,TARIFF_POST from CRBT_CHARGING_CODE";
		List<ChargingCodeDetail> chargingCodeList=new ArrayList<ChargingCodeDetail>();
		logger.info("query = "+SQL);		
		
		
		try{
			con=TSSJavaUtil.instance().getconnection();
			pstmt=con.prepareStatement(SQL);
			rs=pstmt.executeQuery();
			
			while(rs!=null&&rs.next()){
				/*chargingCodeList.add(
						new ChargingCodeDetail(rs.getInt("REQ_ID"), 
								rs.getInt("CHARGING_CODE"),
								rs.getDouble("AMOUNT_PRE"),
								rs.getDouble("AMOUNT_POST"),
								rs.getString("DESCRIPTION"),
								rs.getInt("TARIFF_PRE"),
								rs.getInt("TARIFF_POST")));*/
			}
		}catch (Exception e) {
			logger.fatal("ERROR in retriving CHARGING_CODE detailS!",e);
			return null;
		}finally{
			try{
			 if(rs!=null){rs.close();rs=null;}
			 if(pstmt!=null){pstmt.close();pstmt=null;}
			 if(con!=null){TSSJavaUtil.instance().freeConnection(con);con=null;}
			}catch (SQLException e) {
				logger.error(" Problem in closing transaction.",e);
			}
		}
		return chargingCodeList;
	}//### END of getChargingCodeList ###//
	
	
	//this method is used to add new pack into crbt_pack_detail
	//it returns 1 if success
	//it returns -1 if error
	public int addPack(PackSubNewBean packsubbean)
	{
		logger.info("Inside addPack() ");
		int result=-1;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		Connection con=null;
		int pk_id=-1;
		try
		{
			
		//

			System.out.println(" PACK_NAME ="+packsubbean.getPackName());
			System.out.println("===========================================================================");
			System.out.println("subscriptionDetails = "+packsubbean.getSubscriptionDetails());
			System.out.println("subscriptionRenewDetails = "+packsubbean.getSubscriptionRenewDetails());
			System.out.println("rbtPurchaseDetails = "+packsubbean.getRbtPurchaseDetails());
			System.out.println("rbtRecordingDetails ="+packsubbean.getRbtRecordingDetails());
			System.out.println("rbtGiftDetails = "+packsubbean.getRbtGiftDetails());
			System.out.println("freeRbtDetails = "+packsubbean.getFreeRbtDetails());
			System.out.println("campaignId = "+packsubbean.getCampaignId());
			System.out.println("ValidFor = "+packsubbean.getValidFor());
			System.out.println("subValidFor = "+packsubbean.getSubValidFor());
			System.out.println("offerValidFor = "+packsubbean.getOfferValidFor());
			System.out.println("packStatus = "+packsubbean.getPackScope());
			System.out.println("priority = "+packsubbean.getPriority());
			System.out.println("smsCommand = "+packsubbean.getSmsCommand());
			System.out.println("ussdCommand = "+packsubbean.getUssdCommand());
			System.out.println("ivrPath = "+packsubbean.getIvrPath());
			System.out.println("ivrShortCode = "+packsubbean.getIvrShortCode());
			System.out.println("maxWalletRbt = "+packsubbean.getMaxWalletRbt());
			System.out.println("isDefault = "+packsubbean.getIsDefaultPack());
			System.out.println("remark = "+packsubbean.getRemark());
			System.out.println("userSCope = "+packsubbean.getUserScope());
			System.out.println("rbtSetting = "+packsubbean.getRbtSetting());
			System.out.println("Start Time = "+packsubbean.getStart());
			System.out.println("End Time = "+packsubbean.getEnd());
			System.out.println("Active Interface="+packsubbean.getActiveInterface());
			
		//	
			
		  con=TSSJavaUtil.instance().getconnection();
		  String SQL="select max(PACK_ID) from CRBT_PACK_DETAIL";
		  logger.info(SQL);
		  
		  String query="insert into CRBT_PACK_DETAIL (PACK_ID,PACK_NAME,SUB_CHARGE_CODE,SUB_RENEW_CHARGE_CODE,VALID_FOR,SUBSCRIBER,RBT,GIFT_RBT,RECORDING_RBT,OFFER_VALIDITY,PRIORITY,SMS_COMMAND,USSD_COMMAND,IVR_PROMPT_PATH,IVR_SHORT_CODE,ACTIVE_ON_INTERFACE,STATUS,MAX_RBT_IN_WALLET,SCOPE,RBT_SETTING,IS_DEFAULT_PACK,REMARKS,START_DATE,END_DATE,LIST_ID,FREE_RBT_CHG_CODE_STRING)"
		  		+" values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,sysdate,sysdate,?,?)";
		  
		  pstmt=con.prepareStatement(SQL);
		  
		  rs=pstmt.executeQuery();
		  if(rs.next())
		  {
			  pk_id=rs.getInt(1);
			  logger.info("Maximum Pack_id["+pk_id+"]");
			  pk_id++;
		  }
		  pstmt.close();
		  
		  logger.info(query);
		  pstmt=con.prepareStatement(query);
		  pstmt.setInt(1, pk_id);
		  pstmt.setString(2, packsubbean.getPackName());
		  pstmt.setString(3, packsubbean.getSubscriptionDetails());
		  pstmt.setString(4, packsubbean.getSubscriptionRenewDetails());
		  pstmt.setString(5, packsubbean.getValidFor());
		  pstmt.setString(6, packsubbean.getSubValidFor());
		  pstmt.setString(7, packsubbean.getRbtPurchaseDetails());
		  pstmt.setString(8, packsubbean.getRbtGiftDetails());
		  pstmt.setString(9, packsubbean.getRbtRecordingDetails());
		  pstmt.setInt(10,packsubbean.getOfferValidFor());
		  pstmt.setInt(11,packsubbean.getPriority());
		  pstmt.setString(12,packsubbean.getSmsCommand());
		  pstmt.setString(13,packsubbean.getUssdCommand());
		  pstmt.setString(14,packsubbean.getIvrPath());
		  pstmt.setString(15,packsubbean.getIvrShortCode());
		  pstmt.setString(16,packsubbean.getActiveInterface());
		  pstmt.setString(17,packsubbean.getPackScope());
		  pstmt.setInt(18,packsubbean.getMaxWalletRbt());
		  pstmt.setString(19,packsubbean.getUserScope());
		  pstmt.setInt(20,Integer.parseInt(packsubbean.getRbtSetting()));
		  pstmt.setInt(21,Integer.parseInt(packsubbean.getIsDefaultPack()));
		  pstmt.setString(22,packsubbean.getRemark());
		  
		  String start=getDate(packsubbean.getStart());
		  String end=getDate(packsubbean.getEnd());
		   
		  //pstmt.setString(23,start);
		  //pstmt.setString(24,end);
		  pstmt.setInt(23,packsubbean.getCampaignId());
		  pstmt.setString(24,packsubbean.getFreeRbtDetails());
		  
		  pstmt.executeUpdate();
		  result=1;
		  
			
		}
		catch(Exception e)
		{
			logger.error("Exception inside addPack()");
			e.printStackTrace();
			
			try
			{
			if(con!=null)
			{
				
				TSSJavaUtil.instance().freeConnection(con);
			}
			if(pstmt!=null)
			{
				pstmt.close();
			}
			
			}
			catch(Exception sql)
			{
			 sql.printStackTrace();	
			}
			result=-100;
		}
		finally
		{
			try
			{
			if(con!=null)
			{
				
				TSSJavaUtil.instance().freeConnection(con);
			}
			if(pstmt!=null)
			{
				pstmt.close();
			}
			
			}
			catch(Exception sql)
			{
			 sql.printStackTrace();	
			}
		}
		return result;
		
	}
	
	//this method updatePack is used to update pack details in crbt_pack_detail corresponding to pack_id
	//it returns int value 1 if success 
	//it returns int value -1 if error
	public int updatePack(PackSubNewBean packsubbean,int packId)
	{
		logger.info("Inside updatePack() ");
		int result=-1;
		PreparedStatement pstmt=null;
		Connection con=null;
		try
		{
		  con=TSSJavaUtil.instance().getconnection();
		  String query="update CRBT_PACK_DETAIL  set PACK_NAME=?,SUB_CHARGE_CODE=?,SUB_RENEW_CHARGE_CODE=?,VALID_FOR=?,SUBSCRIBER=?,RBT=?,GIFT_RBT=?,RECORDING_RBT=?,OFFER_VALIDITY=?,PRIORITY=?,SMS_COMMAND=?,USSD_COMMAND=?,IVR_PROMPT_PATH=?,IVR_SHORT_CODE=?,ACTIVE_ON_INTERFACE=?,STATUS=?,MAX_RBT_IN_WALLET=?,SCOPE=?,RBT_SETTING=?,IS_DEFAULT_PACK=?,REMARKS=?,START_DATE=sysdate,END_DATE=sysdate,LIST_ID=?,FREE_RBT_CHG_CODE_STRING=? where PACK_ID=?";
		  		
		  logger.info(query);
		  pstmt=con.prepareStatement(query);
		  
		  
		  
		
		
		  pstmt.setString(1, packsubbean.getPackName());
		  pstmt.setString(2, packsubbean.getSubscriptionDetails());
		  pstmt.setString(3, packsubbean.getSubscriptionRenewDetails());
		  pstmt.setString(4, packsubbean.getValidFor());
		  pstmt.setString(5, packsubbean.getSubValidFor());
		  pstmt.setString(6, packsubbean.getRbtPurchaseDetails());
		  pstmt.setString(7, packsubbean.getRbtGiftDetails());
		  pstmt.setString(8, packsubbean.getRbtRecordingDetails());
		  pstmt.setInt(9,packsubbean.getOfferValidFor());
		  pstmt.setInt(10,packsubbean.getPriority());
		  pstmt.setString(11,packsubbean.getSmsCommand());
		  pstmt.setString(12,packsubbean.getUssdCommand());
		  pstmt.setString(13,packsubbean.getIvrPath());
		  pstmt.setString(14,packsubbean.getIvrShortCode());
		  pstmt.setString(15,packsubbean.getActiveInterface());
		  pstmt.setString(16,packsubbean.getPackScope());
		  pstmt.setInt(17,packsubbean.getMaxWalletRbt());
		  pstmt.setString(18,packsubbean.getUserScope());
		  pstmt.setInt(19,Integer.parseInt(packsubbean.getRbtSetting()));
		  pstmt.setInt(20,Integer.parseInt(packsubbean.getIsDefaultPack()));
		  pstmt.setString(21,packsubbean.getRemark());
		  
		  String start=getDate(packsubbean.getStart());
		  String end=getDate(packsubbean.getEnd());
		  
		  
		  
		  //pstmt.setString(22,start);
		  //pstmt.setString(23,end);
		  pstmt.setInt(22,packsubbean.getCampaignId());
		  pstmt.setString(23,packsubbean.getFreeRbtDetails());
		  pstmt.setInt(24, packId);  
		  pstmt.executeUpdate();
		  logger.info("Successfully Updated....");
		  result=1;
		  
			
		}
		catch(Exception e)
		{
			logger.error("Exception inside Update Pack()");
			e.printStackTrace();
			
			try
			{
			if(con!=null)
			{
				
				TSSJavaUtil.instance().freeConnection(con);
			}
			if(pstmt!=null)
			{
				pstmt.close();
			}
			
			}
			catch(Exception sql)
			{
			 sql.printStackTrace();	
			}
			result=-100;
		}
		finally
		{
			try
			{
			if(con!=null)
			{
				
				TSSJavaUtil.instance().freeConnection(con);
			}
			if(pstmt!=null)
			{
				pstmt.close();
			}
			
			}
			catch(Exception sql)
			{
			 sql.printStackTrace();	
			}
		}
		return result;
		
	}
	
	
//this method getDate give date in proper format like dd-mm-yyyy HH:mm:ss
//this method returns String 	
public String getDate(String date)
		{
		String parseDate=null;
		try
		{
			Calendar cal=Calendar.getInstance();
			DateFormat sdfDate = new SimpleDateFormat(date+"HH:mm:ss");
			parseDate=sdfDate.format(cal.getTime());
			
		}
		catch(Exception e)
		{
			logger.error("Exception indide getDate()");
			e.printStackTrace();
			
		}
		System.out.println("parseDate="+parseDate);
		return parseDate;
		
	}

//this method getCrbtPackList returns All available pack inside crbt_pack_detail 
//it returns List crbtPackList of PackSubNewBean
public List<PackSubNewBean> getCrbtPackList(){
		
		logger.info(" under getCrbtPackList() ");
		
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		Connection con=null;
		
		String SQL="select PACK_ID,PACK_NAME,SUB_CHARGE_CODE,SUB_RENEW_CHARGE_CODE,VALID_FOR,SUBSCRIBER,RBT,GIFT_RBT,RECORDING_RBT,OFFER_VALIDITY,PRIORITY,SMS_COMMAND,USSD_COMMAND,IVR_PROMPT_PATH,IVR_SHORT_CODE,ACTIVE_ON_INTERFACE,STATUS,MAX_RBT_IN_WALLET,SCOPE,RBT_SETTING,IS_DEFAULT_PACK,REMARKS,START_DATE,END_DATE,LIST_ID,FREE_RBT_CHG_CODE_STRING from CRBT_PACK_DETAIL";
		logger.info(SQL);
		
		
		List<PackSubNewBean> crbtPackList=new ArrayList<PackSubNewBean>();
		
		try{
			con=TSSJavaUtil.instance().getconnection();
			pstmt=con.prepareStatement(SQL);
			rs=pstmt.executeQuery();
			if(rs==null)
			{
				logger.info("no rate plan exists");
			}
			while(rs!=null&&rs.next()){
				System.out.println("data exists......");
				
			/*	System.out.println(rs.getInt("PACK_ID") );
				System.out.println(rs.getString("PACK_NAME"));
				System.out.println(rs.getString("SUB_CHARGE_CODE"));
				System.out.println(rs.getString("SUB_RENEW_CHARGE_CODE"));
				System.out.println(rs.getString("VALID_FOR"));
				System.out.println(rs.getString("SUBSCRIBER"));
				System.out.println(rs.getString("RBT"));
				System.out.println(rs.getString("GIFT_RBT"));
				System.out.println(rs.getString("RECORDING_RBT"));
				System.out.println(rs.getString("FREE_RBT_CHG_CODE_STRING"));
				System.out.println(rs.getInt("OFFER_VALIDITY"));
				System.out.println(rs.getInt("PRIORITY"));
				System.out.println(rs.getString("SMS_COMMAND"));
				System.out.println(rs.getString("USSD_COMMAND"));
				System.out.println(rs.getString("IVR_PROMPT_PATH"));
				System.out.println(rs.getString("IVR_SHORT_CODE"));
				System.out.println(rs.getString("ACTIVE_ON_INTERFACE"));
				System.out.println(rs.getString("STATUS"));
				System.out.println(rs.getInt("MAX_RBT_IN_WALLET"));
				System.out.println(rs.getString("SCOPE"));
				System.out.println(rs.getString("RBT_SETTING"));
				System.out.println(rs.getString("IS_DEFAULT_PACK"));
				System.out.println(rs.getString("REMARKS"));
				System.out.println(rs.getString("START_DATE"));
				System.out.println(rs.getString("END_DATE"));
				System.out.println(rs.getInt("LIST_ID"));
				*/
										
					
				logger.info(rs.getInt("PACK_ID") );
				logger.info(rs.getString("PACK_NAME"));
				logger.info(rs.getString("SUB_CHARGE_CODE"));
				logger.info(rs.getString("SUB_RENEW_CHARGE_CODE"));
				logger.info(rs.getString("VALID_FOR"));
				logger.info(rs.getString("SUBSCRIBER"));
				logger.info(rs.getString("RBT"));
				logger.info(rs.getString("GIFT_RBT"));
				logger.info(rs.getString("RECORDING_RBT"));
				logger.info(rs.getString("FREE_RBT_CHG_CODE_STRING"));
				logger.info(rs.getInt("OFFER_VALIDITY"));
				logger.info(rs.getInt("PRIORITY"));
				logger.info(rs.getString("SMS_COMMAND"));
				logger.info(rs.getString("USSD_COMMAND"));
				logger.info(rs.getString("IVR_PROMPT_PATH"));
				logger.info(rs.getString("IVR_SHORT_CODE"));
				logger.info(rs.getString("ACTIVE_ON_INTERFACE"));
				logger.info(rs.getString("STATUS"));
				logger.info(rs.getInt("MAX_RBT_IN_WALLET"));
				logger.info(rs.getString("SCOPE"));
				logger.info(rs.getString("RBT_SETTING"));
				logger.info(rs.getString("IS_DEFAULT_PACK"));
				logger.info(rs.getString("REMARKS"));
				logger.info(rs.getString("START_DATE"));
				logger.info(rs.getString("END_DATE"));
				logger.info(rs.getInt("LIST_ID"));
				
				
				
				
				crbtPackList.add(
						new PackSubNewBean(
						rs.getInt("PACK_ID"),rs.getString("PACK_NAME"), 
						rs.getString("SUB_CHARGE_CODE"), rs.getString("SUB_RENEW_CHARGE_CODE"),
						rs.getString("VALID_FOR"),rs.getString("SUBSCRIBER"),
						rs.getString("RBT"),rs.getString("GIFT_RBT"),
						rs.getString("RECORDING_RBT"), rs.getString("FREE_RBT_CHG_CODE_STRING"),
						rs.getInt("OFFER_VALIDITY"),rs.getInt("PRIORITY"), rs.getString("SMS_COMMAND"),
						rs.getString("USSD_COMMAND"),rs.getString("IVR_PROMPT_PATH"),rs.getString("IVR_SHORT_CODE"),
						rs.getString("ACTIVE_ON_INTERFACE"),rs.getString("STATUS"),rs.getInt("MAX_RBT_IN_WALLET"),
						rs.getString("SCOPE"),rs.getString("RBT_SETTING"),rs.getString("IS_DEFAULT_PACK"),
						rs.getString("REMARKS"),rs.getString("START_DATE"),rs.getString("END_DATE"),
						rs.getInt("LIST_ID")));
					
				logger.info("List size is:"+crbtPackList.size());
			}
		}catch (Exception e) {
			logger.fatal("ERROR in retriving CRBT_PACK_DETAIL inside getCrbtPackList!",e);
			return null;
		}finally{
			try{
			 if(rs!=null){rs.close();rs=null;}
			 if(pstmt!=null){pstmt.close();pstmt=null;}
			 if(con!=null){TSSJavaUtil.instance().freeConnection(con);con=null;}
			}catch (SQLException e) {
				logger.error(" Problem in closing transaction.",e);
			}
		}
		return crbtPackList;
	}//### END of getCrbtRatePlanList ###//


/**
 *  
 * This method select CRBT_PACK_DETAIL detail from database and populate packSubNewBean object.
 * 
 * @param packId
 * @return	packSubNewBean
 * , return null = in case of any exception.
 * 	
 */
public PackSubNewBean getCrbtPackByPackId(int packId) {

	logger.info(" under getCrbtPackByPackId() packId= "+packId);

	PreparedStatement pstmt = null;
	ResultSet rs = null;
	Connection con = null;

	String SQL = "select PACK_ID,PACK_NAME,SUB_CHARGE_CODE,SUB_RENEW_CHARGE_CODE,VALID_FOR,SUBSCRIBER,RBT,GIFT_RBT,RECORDING_RBT,OFFER_VALIDITY,PRIORITY,SMS_COMMAND,USSD_COMMAND,IVR_PROMPT_PATH,IVR_SHORT_CODE,ACTIVE_ON_INTERFACE,STATUS,MAX_RBT_IN_WALLET,SCOPE,RBT_SETTING,IS_DEFAULT_PACK,REMARKS,START_DATE,END_DATE,LIST_ID,FREE_RBT_CHG_CODE_STRING from CRBT_PACK_DETAIL where PACK_ID=?";
	logger.info(SQL);
	PackSubNewBean crbtPack = new PackSubNewBean();

	try {
		con = TSSJavaUtil.instance().getconnection();
		pstmt = con.prepareStatement(SQL);
		pstmt.setInt(1, packId);
			
		rs = pstmt.executeQuery();

		if (rs != null && rs.next()) {
			
			
			
			
			String startDate=getParsedDate(rs.getString("START_DATE").split(" ")[0]);
			String endDate=getParsedDate(rs.getString("END_DATE").split(" ")[0]);
			
			
			
			
			String rbtSetting=String.valueOf(rs.getInt("RBT_SETTING"));
			String isDefaultPack=String.valueOf(rs.getInt("IS_DEFAULT_PACK"));
			crbtPack= new PackSubNewBean(
					rs.getInt("PACK_ID"),rs.getString("PACK_NAME"), 
					rs.getString("SUB_CHARGE_CODE"), rs.getString("SUB_RENEW_CHARGE_CODE"),
					rs.getString("VALID_FOR"),rs.getString("SUBSCRIBER"),
					rs.getString("RBT"),rs.getString("GIFT_RBT"),
					rs.getString("RECORDING_RBT"), rs.getString("FREE_RBT_CHG_CODE_STRING"),
					rs.getInt("OFFER_VALIDITY"),rs.getInt("PRIORITY"), rs.getString("SMS_COMMAND"),
					rs.getString("USSD_COMMAND"),rs.getString("IVR_PROMPT_PATH"),rs.getString("IVR_SHORT_CODE"),
					rs.getString("ACTIVE_ON_INTERFACE"),rs.getString("STATUS"),rs.getInt("MAX_RBT_IN_WALLET"),
					rs.getString("SCOPE"),rbtSetting,isDefaultPack,
					rs.getString("REMARKS"),startDate,endDate,
					rs.getInt("LIST_ID"));
			
			
			
			
		  }
		else
		{
			logger.info("pack does not exists");
		}
	} catch (SQLException e) {
		logger.fatal("DB-ERROR in retriving CRBT_PACK_DETAIL inside getCrbtPackByPackId!", e);
		return null;
	}catch (Exception e) {
		logger.fatal("other-ERROR in retriving CRBT_PACK_DETAIL inside getCrbtPackByPackId!", e);
		return null;
	}  finally {
		try {
			if (rs != null) {
				rs.close();
				rs = null;
			}
			if (pstmt != null) {
				pstmt.close();
				pstmt = null;
			}
			if (con != null) {
				TSSJavaUtil.instance().freeConnection(con);
				con = null;
			}
		} catch (SQLException e) {
			logger.error(" Problem in closing transaction.", e);
		}
	}
	return crbtPack;
}


//this method get IS_DEFAULT_PACK,RBT_SETTING,SCOPE,STATUS,VALID_FOR,SUBSCRIBER values from crbt_pack_detail
//it returns 1 for success
//it returns -1 for error
//it populate the PackSubBean 
public int getSettingValues(PackSubBean packsub,int packId) {
	
	logger.info(" under getSettingValues packId= "+packsub.getPackName());

	PreparedStatement pstmt = null;
	ResultSet rs = null;
	Connection con = null;
    int result=-1;
    
	String SQL = "select IS_DEFAULT_PACK,RBT_SETTING,SCOPE,STATUS,VALID_FOR,SUBSCRIBER from CRBT_PACK_DETAIL where PACK_ID=?";
	logger.info(SQL);
	
	try {
		con = TSSJavaUtil.instance().getconnection();
		pstmt = con.prepareStatement(SQL);
		pstmt.setInt(1, packId);

		rs = pstmt.executeQuery();

		if (rs != null && rs.next()) {
			
			
			packsub.setIsDefaultPack(rs.getString("IS_DEFAULT_PACK"));
			packsub.setRbtSetting(rs.getString("RBT_SETTING"));
			packsub.setUserScope(rs.getString("SCOPE"));
			packsub.setPackScope(rs.getString("STATUS"));
			packsub.setValidFor(rs.getString("VALID_FOR"));
			
			packsub.setSubValidFor(rs.getString("SUBSCRIBER"));
			
			result=1;
				
			
		  }
		else
		{
			logger.info("pack does not exists");
		}
	} catch (SQLException e) {
		logger.fatal("DB-ERROR in retriving CRBT_PACK_DETAIL inside getSettingValues!", e);
		return result=-1;
	}catch (Exception e) {
		logger.fatal("other-ERROR in retriving CRBT_PACK_DETAIL inside getSettingValues!", e);
		return result=-1;
	}  finally {
		try {
			if (rs != null) {
				rs.close();
				rs = null;
			}
			if (pstmt != null) {
				pstmt.close();
				pstmt = null;
			}
			if (con != null) {
				TSSJavaUtil.instance().freeConnection(con);
				con = null;
			}
		} catch (SQLException e) {
			logger.error(" Problem in closing transaction.", e);
		}
	}
	return result;
	
	
}

//this method get Active interfaces from crbt_pack_detail corresponding to pack_id 
//it returns List of ActiveInterfaceBean
public List<ActiveInterfaceBean> getActiveList(int packId) {
            
            
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	Connection con = null;
	List<ActiveInterfaceBean> activeList=new ArrayList<ActiveInterfaceBean>();
    
	String SQL = "select ACTIVE_ON_INTERFACE from crbt_pack_detail where PACK_ID=?";
    logger.info(SQL);
	try {
		con = TSSJavaUtil.instance().getconnection();
		pstmt = con.prepareStatement(SQL);
		pstmt.setInt(1, packId);

		rs = pstmt.executeQuery();
        
  
		if (rs != null && rs.next()) {
			 
			
			String atc[]=rs.getString("ACTIVE_ON_INTERFACE").split(",");
	            for(String value:atc)
	            {
	            	activeList.add(new ActiveInterfaceBean(value));
	            }
	     			
		  }
		else
		{
			logger.info("pack does not exists");
		}
	} catch (SQLException e) {
		logger.fatal("DB-ERROR in retriving CRBT_PACK_DETAIL inside getActiveList!", e);
		
	}catch (Exception e) {
		logger.fatal("other-ERROR in retriving CRBT_PACK_DETAIL inside getActiveList!", e);
		}  finally {
		try {
			if (rs != null) {
				rs.close();
				rs = null;
			}
			if (pstmt != null) {
				pstmt.close();
				pstmt = null;
			}
			if (con != null) {
				TSSJavaUtil.instance().freeConnection(con);
				con = null;
			}
		} catch (SQLException e) {
			logger.error(" Problem in closing transaction.", e);
		}
	}
	
            
            
	
	return activeList;
}

//this getNonACtiveInterfaceList used to set nonActive Interfaces in a list
//it returns List of ActiveInterfaceBean that contains non active interfaces
public List<ActiveInterfaceBean> getNonACtiveInterfaceList(List<ActiveInterfaceBean> activeInterfaceList) {
	List<ActiveInterfaceBean> nonActiveInterfaceList=null;
	        try
	        {
	        	int smsStatus=0;
	        	int webStatus=0;
	        	int ivrStatus=0;
	        	int ussdStatus=0;
	        	int obdStatus=0;
	        	
	        	nonActiveInterfaceList=new ArrayList<ActiveInterfaceBean>();
	        	
	        	Iterator<ActiveInterfaceBean> itr=activeInterfaceList.iterator();
	        	while(itr.hasNext())
	        	{
	        		ActiveInterfaceBean bean=itr.next();
	        		if(bean.getDescription().equalsIgnoreCase("S"))
	        		{
	        			smsStatus=smsStatus+1;
	        		}
	        		else if(bean.getDescription().equalsIgnoreCase("W"))
	        		{
	        			webStatus=webStatus+1;
	        		}if(bean.getDescription().equalsIgnoreCase("I"))
	        		{
	        			ivrStatus=ivrStatus+1;
	        		}if(bean.getDescription().equalsIgnoreCase("U"))
	        		{
	        			ussdStatus=ussdStatus+1;
	        		}if(bean.getDescription().equalsIgnoreCase("O"))
	        		{
	        			obdStatus=obdStatus+1;
	        		}
	        			
	        	}
	        	
	        	if(smsStatus==0)
	        	{
	        		nonActiveInterfaceList.add(new ActiveInterfaceBean("S"));
	        	}
	        	if(webStatus==0)
	        	{
	        		nonActiveInterfaceList.add(new ActiveInterfaceBean("W"));
	        	}
	        	if(ivrStatus==0)
	        	{
	        		nonActiveInterfaceList.add(new ActiveInterfaceBean("I"));
	        	}
	        	if(ussdStatus==0)
	        	{
	        		nonActiveInterfaceList.add(new ActiveInterfaceBean("U"));
	        	}
	        	if(obdStatus==0)
	        	{
	        		nonActiveInterfaceList.add(new ActiveInterfaceBean("O"));
	        	}
	        	else
	        	{
	        		System.out.println("No matching case found...");
	        	}
	           
	        	
	        }
	        catch(Exception e)
	        {
	        	logger.info("Exception inside getNonACtiveInterfaceList");
	        	e.printStackTrace();
	        }
	
	
	return nonActiveInterfaceList;
}


/// Charging code and description
public int deleteCrbtPackDetail(int packId) {
	logger.info(" under deleteCrbtPackDetail() packId= "+packId);
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	Connection con = null;
	int status=1;
	String SQL = "delete from CRBT_PACK_DETAIL where PACK_ID = ? ";
	logger.info(SQL);
	
	try {
		con = TSSJavaUtil.instance().getconnection();
		pstmt = con.prepareStatement(SQL);
		pstmt.setInt(1, packId);
		
		status=pstmt.executeUpdate();
		logger.debug("webadmin deleteCrbtPackDetail: query execute");
		
		if (status > 0) {
			logger.info("pack deleted");
			return 1;
		} else {
			logger.info("pack is not deleted");
			return 0;
		}
	} catch (SQLException e) {
		logger.error("DB-ERROR in deleting CRBT_PACK_DETAIL details! "+e.toString(), e);
		return -1;
		
	} catch (Exception e) {
		logger.error("Other-ERROR in deleting CRBT_PACK_DETAIL details! "+e.toString(), e);
		return -1;
		
	} finally {
		try {
			if (rs != null) {
				rs.close();
				rs = null;
			}
			if (pstmt != null) {
				pstmt.close();
				pstmt = null;
			}
			if (con != null) {
				TSSJavaUtil.instance().freeConnection(con);
				con = null;
			}
		} catch (SQLException e) {
			logger.error(" Problem in closing transaction.", e);
		}
	}
	
}//#### deleteCrbtPackDeatil


//Is Pack Name Exists......

public boolean isPackNameExists(String maskedName) {
	
	logger.info(" under isPackNameExists() PACK_NAME=" + maskedName);

	PreparedStatement pstmt = null;
	ResultSet rs = null;
	Connection con = null;
	boolean status = false;
	String SQL = "select * from CRBT_PACK_DETAIL where upper(PACK_NAME)=?";
	try {
		con = TSSJavaUtil.instance().getconnection();
		pstmt = con.prepareStatement(SQL);
		pstmt.setString(1, maskedName.toUpperCase());
		rs = pstmt.executeQuery();

		if (rs != null && rs.next()) {
			status = true;
		}
		else
		{
			logger.info("pack does not exists");
		}
	} catch (Exception e) {
		logger.fatal("ERROR in retriving Pack Name detailS!", e);
		return false;
	} finally {
		try {
			if (rs != null) {
				rs.close();
				rs = null;
			}
			if (pstmt != null) {
				pstmt.close();
				pstmt = null;
			}
			if (con != null) {
				TSSJavaUtil.instance().freeConnection(con);
				con = null;
			}
		} catch (SQLException e) {
			logger.error(" Problem in closing transaction.", e);
		}
	}
	return status;
}// ### END OF isPackNameExists()

//this method is used to get Parsed date to view yyyy-MM-dd to dd-MM-yyyy 
public String getParsedDate(String date)
 {
	 SimpleDateFormat sdf1=new SimpleDateFormat("yyyy-MM-dd");
	 SimpleDateFormat sdf2=new SimpleDateFormat("dd-MM-yyyy");
	 String fdate=null;
	 try
	 {
		fdate=sdf2.format(sdf1.parse(date));
		System.out.println("Parsed date is ["+fdate+"]"); 
	 }
	 catch(Exception e)
	 {
		 logger.error("Err inside getParseddate()");
		 e.printStackTrace();
	 }
	 return fdate;
 }

/*
public List<CampaignListBean> getCampaignList(){
	
	
	
	
	
	PreparedStatement pstmt=null;
	ResultSet rs=null;
	Connection con=null;
	
    	
	String SQL="select LIST_ID,LIST_NAME,STATUS from CAMPAIGN_LIST_MASTER";
	List<CampaignListBean> campaignList=new ArrayList<CampaignListBean>();
	logger.info("query = "+SQL);		
	
	
	try{
		logger.info(" under getCampaignList() ");
		
		
		con=TSSJavaUtil.instance().getconnection();
		pstmt=con.prepareStatement(SQL);
		rs=pstmt.executeQuery();
		CampaignListBean campbean=null;
		
		
		while(rs!=null&&rs.next()){
               
			campbean=new CampaignListBean();
			System.out.println("name:["+rs.getString("LIST_NAME")+"] id["+rs.getInt("List_Id") +"] status["+rs.getString("Status")+"]");
			
			campbean.setList_id(rs.getInt("List_Id"));
			campbean.setList_name(rs.getString("List_Name"));
			campbean.setStatus(rs.getString("Status"));
			
			campaignList.add(campbean);
			System.out.println("list size:"+campaignList.size());		
					
							
		}
	}catch (Exception e) {
		logger.fatal("ERROR in retriving CAMPAIGNLIST!",e);
		return null;
	}finally{
		try{
		 if(rs!=null){rs.close();rs=null;}
		 if(pstmt!=null){pstmt.close();pstmt=null;}
		 if(con!=null){TSSJavaUtil.instance().freeConnection(con);con=null;}
		}catch (SQLException e) {
			logger.error(" Problem in closing transaction.",e);
		}
	}
	System.out.println("Campaign lIst size:"+campaignList.size());
	return campaignList;
}//### END of getCampaignList ###//
*/

}



	

