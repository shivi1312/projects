package com.telemune.vcc.webadmin;

import java.util.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.*;
import com.telemune.dbutilities.*;
import org.apache.log4j.*;
public class PromotionPackManager
{
	static Logger logger=Logger.getLogger(PromotionPackManager.class);
	private ResultSet rs = null;
	private PreparedStatement pstmt = null;
	private PreparedStatement pstmt1 = null;
	private Connection con = null;
	private String query = null;
	private String query1 = null;
	SimpleDateFormat sdf= new SimpleDateFormat("dd-MM-yyyy");
	SimpleDateFormat sdf1= new SimpleDateFormat("yyyy-MM-dd");
	public int addPromotionPack (PromotionPack promo,Connection con)
	{
		logger.info("webadmin: addPromotionPack");
		int packid=0;
		try
		{
			//con = conPool.getConnection();

			query = "SELECT PACK_NAME FROM CRBT_RBT_PACK WHERE PACK_NAME=?";
			
			pstmt = con.prepareStatement (query);
			pstmt.setString(1,promo.getPackName());
			rs = pstmt.executeQuery ();
			if(rs.next ())
			{
				logger.info("record already exists");
				rs.close ();
				pstmt.close ();
				return -2; //Record already exists
			}
			rs.close ();
			pstmt.close ();

			query = "SELECT PACK_NAME FROM CRBT_RBT_PACK WHERE PACK_SIZE=? and FREE_RBTS=?";
			pstmt = con.prepareStatement (query);
			pstmt.setInt (1,promo.getPackSize());
			pstmt.setInt (2,promo.getFreeRbt());
			rs = pstmt.executeQuery ();
			if(rs.next ())
			{
				logger.info("record already exists");
				rs.close ();
				pstmt.close ();
				return -2; //Record already exists
			}
			rs.close ();
			pstmt.close ();

			query="select rbt_pack_id.nextval from dual";
			pstmt=con.prepareStatement(query);
			rs = pstmt.executeQuery();
			if(rs.next())
			{
				packid = rs.getInt(1);
			}
			rs.close ();
			pstmt.close ();

			query = "INSERT INTO CRBT_RBT_PACK (PACK_ID,PACK_NAME, PACK_SIZE, PACK_COST, FREE_RBTS) VALUES (?,?,?,?,?)";
			logger.info("query= "+query);
			pstmt = con.prepareStatement (query);

			pstmt.setInt (1, packid);
			pstmt.setString (2, promo.getPackName().trim());
			pstmt.setInt (3, promo.getPackSize());
			pstmt.setLong (4, promo.getPackCost());
			pstmt.setInt (5, promo.getFreeRbt());

			pstmt.executeUpdate ();
			pstmt.close ();
		}//try
		catch (Exception e)
		{
			try
			{
				if(pstmt != null) pstmt.close ();
				if(rs != null) rs.close ();
			}catch(SQLException sqle)
			{
				logger.error ("webadmin-addPromotionPack: Exception is: " + sqle.getMessage ());
			}

			e.printStackTrace ();
			return -1;
		}
		//finally  { conPool.free(con); } 
		return 1; //  added susccessfully

	}// addPromotionPack()

	public int getPromotionPacks (ArrayList packAl,Connection con)
	{
		logger.info("getPromotionPacks() ");
		try
		{
			//con = conPool.getConnection();
			query = "select a.PACK_ID, a.PACK_NAME, a.PACK_SIZE, a.PACK_COST, a.FREE_RBTS, b.DESCRIPTION from CRBT_RBT_PACK A, CRBT_CHARGING_CODE b where a.PACK_COST=b.CHARGING_CODE";
			logger.info("query= "+query);
			pstmt = con.prepareStatement (query);
			rs = pstmt.executeQuery ();
			while(rs.next ())
			{
				PromotionPack promo = new PromotionPack ();
				promo.setPackName (rs.getString ("PACK_NAME"));
				promo.setPackId (rs.getInt ("PACK_ID"));
				promo.setPackSize (rs.getInt ("PACK_SIZE"));
				promo.setPackCost (rs.getLong("PACK_COST"));
				promo.setChgRule (rs.getString("DESCRIPTION"));
				promo.setFreeRbt (rs.getInt("FREE_RBTS"));
				packAl.add (promo);
			}
			rs.close ();
			pstmt.close ();
		} //try
		catch (Exception e)
		{
			try
			{
				if(rs != null) rs.close ();
				if(pstmt != null) pstmt.close ();
			}catch(SQLException sqle)
			{
				logger.error ("Exception in getPromotionPacks: " + sqle.getMessage ());
			}
			e.printStackTrace ();
			return -1;
		}
		//finally{ conPool.free(con); }
		return 1;
	}//getPromotionPacks

	public int getPromotionPack (ArrayList packAl, int packId,Connection con)
	{
		logger.info("getPromotionPack() "+packId);
		try
		{
			//con = conPool.getConnection();
			query = "select PACK_ID, PACK_NAME, PACK_SIZE, PACK_COST, FREE_RBTS from CRBT_RBT_PACK where PACK_ID=?";
			logger.info("query= "+query);
			pstmt = con.prepareStatement (query);
			pstmt.setInt(1, packId);
			rs = pstmt.executeQuery ();
			while(rs.next ())
			{
				PromotionPack promo = new PromotionPack ();
				promo.setPackName (rs.getString ("PACK_NAME"));
				promo.setPackId (rs.getInt ("PACK_ID"));
				promo.setPackSize (rs.getInt ("PACK_SIZE"));
				promo.setPackCost (rs.getLong("PACK_COST"));
				promo.setFreeRbt (rs.getInt("FREE_RBTS"));
				packAl.add (promo);
			}
			rs.close ();
			pstmt.close ();
		} //try
		catch (Exception e)
		{
			try
			{
				if(rs != null) rs.close ();
				if(pstmt != null) pstmt.close ();
			}catch(SQLException sqle)
			{
				logger.error ("Exception in getPromotionPacks: " + sqle.getMessage ());
			}
			e.printStackTrace ();
			return -1;
		}
		//finally{ conPool.free(con); }
		return 1;
	}//getPromotionPack


	public int modifyPromotionPack (PromotionPack promo, String packnameold,Connection con)
	{
		logger.info("webadmin: modifyPromotionPack");
		logger.debug(promo.getPackName()+ "  "+promo.getPackId());
		try
		{
			//con = conPool.getConnection();

			/*query = "SELECT PACK_NAME FROM CRBT_RBT_PACK WHERE PACK_NAME=?";
			  pstmt = con.prepareStatement (query);
			  pstmt.setString(1,packnameold);
			  logger.info(query);
			  rs = pstmt.executeQuery ();
			  if(rs.next ())
			  {
			  rs.close ();
			  pstmt.close ();
			  return -2; //Record already exists
			  }
			  rs.close ();
			  pstmt.close ();
			 */
			query = "SELECT PACK_NAME FROM CRBT_RBT_PACK WHERE PACK_SIZE=? and FREE_RBTS=? and PACK_COST=?";
			pstmt = con.prepareStatement (query);
			pstmt.setInt (1,promo.getPackSize());
			pstmt.setInt (2,promo.getFreeRbt());
			pstmt.setLong(3,promo.getPackCost());
			logger.debug(query);
			rs = pstmt.executeQuery ();
			if(rs.next ())
			{
				logger.info("record already exists");
				rs.close ();
				pstmt.close ();
				return -2; //Record already exists
			}
			rs.close ();
			pstmt.close ();


			query = "UPDATE CRBT_RBT_PACK set PACK_NAME=?, PACK_SIZE=?, PACK_COST=?, FREE_RBTS=? where PACK_ID=?";
			logger.info("query= "+query);
			pstmt = con.prepareStatement (query);

			pstmt.setString (1, promo.getPackName().trim());
			pstmt.setInt (2, promo.getPackSize());
			pstmt.setLong (3, promo.getPackCost());
			pstmt.setInt (4, promo.getFreeRbt());
			pstmt.setInt (5, promo.getPackId());
			logger.debug(query);

			pstmt.executeUpdate ();
			pstmt.close ();
		}//try
		catch (Exception e)
		{
			try
			{
				if(pstmt != null) pstmt.close ();
				if(rs != null) rs.close ();
			}catch(SQLException sqle)
			{
				logger.error ("webadmin-modifyPromotionPack: Exception is: " + sqle.getMessage ());
			}

			e.printStackTrace ();
			return -1;
		}
		//finally  { conPool.free(con); } 
		return 1; //  added susccessfully

	}//modifyPromotionPack

	public int definePromotionOffer (PromotionPack promo,Connection con)
	{
		logger.info("webadmin: definePromotionOffer "+promo.getStartDate()+"   "+promo.getEndDate());
		int promoid=0;
		try
		{
			//con = conPool.getConnection();

			query = "SELECT START_DATE, PACK_ID, FREE_RBTS, SUBS_OFFER FROM CRBT_PROMOTION where START_DATE=to_date(?,'dd-mm-yyyy') and PACK_ID=? and FREE_RBTS=? and SUBS_OFFER=?";
			logger.info("query= "+query);
			pstmt = con.prepareStatement (query);
			pstmt.setString(1, promo.getStartDate());
			pstmt.setInt(2, promo.getPackId());
			pstmt.setInt(3, promo.getFreeRbt());
			pstmt.setString(4, promo.getSubsOffer());
			rs = pstmt.executeQuery ();
			if(rs.next ())
			{
				logger.debug("Startdate, packid, free rbt, subsoffer combination is already defined");
				rs.close ();
				pstmt.close ();
				return -2; //Record already exists
			}
			rs.close ();
			pstmt.close ();

			query = "SELECT START_DATE, END_DATE, PACK_ID from CRBT_PROMOTION WHERE START_DATE=to_date(?,'dd-mm-yyyy') and END_DATE=to_date(?,'dd-mm-yyyy') and PACK_ID=?";
			logger.info("query= "+query);
			pstmt = con.prepareStatement (query);
			pstmt.setString(1,promo.getStartDate());
			pstmt.setString (2,promo.getEndDate());
			pstmt.setInt(3, promo.getPackId());
			rs = pstmt.executeQuery ();
			if(rs.next ())
			{
				logger.debug("Startdate, enddate and packid combination is already defined");
				rs.close ();
				pstmt.close ();
				return -21; //Record already exists
			}
			rs.close ();
			pstmt.close ();

			query="select promo_id.nextval from dual";
			pstmt=con.prepareStatement(query);
			rs = pstmt.executeQuery();
			if(rs.next())
			{
				promoid = rs.getInt(1);
			}
			rs.close ();
			pstmt.close ();
			int chgcode=0; 
			query="select PACK_COST from CRBT_RBT_PACK where PACK_ID=?";
			pstmt = con.prepareStatement (query);
			pstmt.setInt (1, promo.getPackId());
			rs = pstmt.executeQuery();
			if(rs.next())
			{
				chgcode = rs.getInt(1);
			}
			rs.close ();
			pstmt.close ();


			//query = "INSERT INTO CRBT_PROMOTION (PROMO_ID,START_DATE, END_DATE, PACK_ID, FREE_RBTS, SUBS_OFFER) VALUES (?,to_date(?,'dd-mm-yyyy'),to_date(?,'dd-mm-yyyy'),?,?,?)";
			//query = "INSERT INTO CRBT_PROMOTION (PROMO_ID,START_DATE, END_DATE, PACK_ID, FREE_RBTS, SUBS_OFFER) VALUES (?,to_date(to_char(to_date(?,'dd-mm-yyyy hh24'),'dd-mon-yyyy hh24'),'dd-mon-yyyy hh24'),to_date(to_char(to_date(?,'dd-mm-yyyy hh24'),'dd-mon-yyyy hh24'),'dd-mon-yyyy hh24') ,?,?,?)";
			//query="INSERT INTO CRBT_PROMOTION (PROMO_ID,START_DATE, END_DATE, PACK_ID, FREE_RBTS, SUBS_OFFER) VALUES (?,to_date(to_char(to_date(?,'dd-mm-yyyy hh24'),'dd-mon-yyyy hh24'),'dd-mon-yyyy hh24'),to_date(to_char(to_date(?,'dd-mm-yyyy hh24'),'dd-mon-yyyy hh24'),'dd-mon-yyyy hh24') ,?,?,?)";

			query = "INSERT INTO CRBT_PROMOTION (PROMO_ID,START_DATE,END_DATE,PACK_ID,CHARGING_CODE, SUBS_OFFER) VALUES (?,to_date(?,'dd-mm-yyyy'),to_date(?,'dd-mm-yyyy'),?,?,?)";
			logger.info("query= "+query);
			logger.debug(query);
			pstmt = con.prepareStatement (query);
			pstmt.setInt (1, promoid);
			pstmt.setString (2, promo.getStartDate().trim());
			pstmt.setString (3, promo.getEndDate().trim());
			pstmt.setInt (4, promo.getPackId());
			//pstmt.setInt (5, promo.getFreeRbt());
			pstmt.setInt (5, chgcode);
			pstmt.setString (6, promo.getSubsOffer().trim());

			pstmt.executeUpdate ();
			pstmt.close ();
		}//try
		catch (Exception e)
		{
			try
			{
				if(pstmt != null) pstmt.close ();
				if(rs != null) rs.close ();
			}catch(SQLException sqle)
			{
				logger.error ("webadmin-definePromotionOffer:Exception is: " + sqle.getMessage ());
			}

			e.printStackTrace ();
			return -1;
		}
		//finally  { conPool.free(con); } 
		return 1; //  added susccessfully

	}//definePromotionOffer

	public int deletePromoPack(ArrayList ocAl,Connection con)
	{
		logger.info("deletePromoPack()");
		try
		{
			//con = conPool.getConnection();
			query = "delete from CRBT_RBT_PACK  WHERE PACK_ID=?";
			logger.info("query= "+query);
			pstmt = con.prepareStatement(query);
			Iterator ite1 = ocAl.iterator();
			while (ite1.hasNext())
			{
				//pstmt.setInt (1,(Integer.parseInt(ite1.next())));
				pstmt.setInt (1,Integer.parseInt((String)ite1.next()));
				pstmt.executeUpdate();
			}
			pstmt.close();


		}//try
		catch (Exception e)
		{
			try
			{
				if(pstmt != null) pstmt.close ();
			}catch(SQLException sqle)
			{
				logger.error("Exception in deletePromoPack(), Exception is : " + sqle.getMessage ());
			}
			e.printStackTrace ();
			return -1;
		}
		//finally{ conPool.free(con);  }
		return 1;
	}//delete
	public int getPromotionOffers (ArrayList promooffer,Connection con)
	{
		logger.info("webadmin: getPromotionOffer");
		int promoid=0;


		try
		{
			//con = conPool.getConnection();

			//query = "SELECT PROMO_ID,START_DATE,END_DATE, PACK_ID, FREE_RBTS, SUBS_OFFER FROM CRBT_PROMOTION ";
			query = "SELECT a.PROMO_ID,b.PACK_NAME,START_DATE,END_DATE, a.PACK_ID,a.CHARGING_CODE, a.SUBS_OFFER FROM CRBT_PROMOTION a, CRBT_RBT_PACK b where a.PACK_ID=b.PACK_ID ";
			logger.info("query= "+query);
			pstmt = con.prepareStatement (query);
			rs = pstmt.executeQuery ();
			while(rs.next ())
			{
				PromotionPack promo = new PromotionPack ();
				promo.setPromoId (rs.getInt ("PROMO_ID"));
				promo.setPackName (rs.getString ("PACK_NAME"));
				promo.setStartDate ( sdf.format(sdf1.parse(rs.getString ("START_DATE"))));
				promo.setEndDate (sdf.format(sdf1.parse(rs.getString("END_DATE"))));
				//promo.setFreeRbt (rs.getInt("FREE_RBTS"));
				//	promo.setChgCode (rs.getInt("CHARGING_CODE"));
				promo.setSubsOffer (rs.getString("SUBS_OFFER"));
				promooffer.add (promo);
			}
			rs.close ();
			pstmt.close ();
		} //try
		catch (Exception e)
		{
			try
			{
				if(rs != null) rs.close ();
				if(pstmt != null) pstmt.close ();
			}catch(SQLException sqle)
			{
				logger.error ("Exception in getPromotionPacks: " + sqle.getMessage ());
			}
			e.printStackTrace ();
			return -1;
		}
		//finally{ conPool.free(con); }
		return 1;
	}//getPromotionPack

	public int deletePromoOffer(ArrayList ocAl,Connection con)
	{
		logger.info("deletePromoOffer()");
		try
		{
			//con = conPool.getConnection();
			query = "delete from CRBT_PROMOTION WHERE PROMO_ID=?";
			logger.info("query= "+query);
			pstmt = con.prepareStatement(query);
			Iterator ite1 = ocAl.iterator();
			while (ite1.hasNext())
			{
				//pstmt.setInt (1,(Integer.parseInt(ite1.next())));
				pstmt.setInt (1,Integer.parseInt((String)ite1.next()));
				pstmt.executeUpdate();
			}
			pstmt.close();


		}//try
		catch (Exception e)
		{
			try
			{
				if(pstmt != null) pstmt.close ();
			}catch(SQLException sqle)
			{
				logger.error ("Exception in deletePromoPack(), Exception is : " + sqle.getMessage ());
			}
			e.printStackTrace ();
			return -1;
		}
		//sfinally{ conPool.free(con);  }
		return 1;
	}//deleteoffer

	public int modifyPromotionOffer (PromotionPack promo,Connection con)
	{
		logger.info("webadmin: modifyPromotionOffer");
		logger.debug(promo.getPackId());
		try
		{
			//con = conPool.getConnection();

			//query = "UPDATE CRBT_PROMOTION set START_DATE=to_date(?,'dd-mm-yyyy hh24'), END_DATE=to_date(?,'dd-mm-yyyy hh24') where PROMO_ID=?";
			query = "UPDATE CRBT_PROMOTION set START_DATE=to_date(?,'dd-mm-yyyy'), END_DATE=to_date(?,'dd-mm-yyyy') where PROMO_ID=?";
			logger.info("query= "+query);
			pstmt = con.prepareStatement (query);

			pstmt.setString (1, promo.getStartDate().trim());
			pstmt.setString (2, promo.getEndDate().trim());
			pstmt.setInt (3, promo.getPackId());
			logger.debug(query);

			pstmt.executeUpdate();
			pstmt.close ();
		}//try
		catch (Exception e)
		{
			try
			{
				if(pstmt != null) pstmt.close ();
				if(rs != null) rs.close ();
			}catch(SQLException sqle)
			{
				logger.error ("webadmin-modifyPromotionOffer: Exception is: " + sqle.getMessage ());
			}

			e.printStackTrace ();
			return -1;
		}
		//finally  { conPool.free(con); } 
		return 1; //  added susccessfully

	}//modifyPromotionPack


}//class
