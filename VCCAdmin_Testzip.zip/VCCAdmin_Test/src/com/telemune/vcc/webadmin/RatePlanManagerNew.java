package com.telemune.vcc.webadmin;



import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;

import com.telemune.dbutilities.Connection;
import com.telemune.dbutilities.PreparedStatement;
import com.telemune.vcc.common.TSSJavaUtil;

public class RatePlanManagerNew {
	

	
	private Logger logger=Logger.getLogger(RatePlanManagerNew.class);
	
	Connection con;
	
	public RatePlanManagerNew(Connection con) {
		super();
		this.con = con;
	}
	
	public RatePlanManagerNew() {
		super();
	}
	
	/**
	 * @author pankajmishra
	 * 
	 * This method provide list of all charing codes's detail available in CRBT_CHARGING_CODE table.
	 * 
	 * @return	
	 * 	List<ChargingCodeDetail> object if successful, 
	 * 	null = in case any error occurred.	
	 */
	public List<ChargingCodeDetail> getChargingCodeList(){
		
		logger.info(" under getChargingCodeList() ");
		
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		Connection con=null;
		
		
		String SQL="select CHARGING_CODE,AMOUNT_PRE,AMOUNT_POST,CHARGING_CODE_NAME,TARIFF_PRE,TARIFF_POST from VCC_CHARGING_CODE";
		List<ChargingCodeDetail> chargingCodeList=new ArrayList<ChargingCodeDetail>();
		logger.info("query = "+SQL);		
		
		
		try{
			con=TSSJavaUtil.instance().getconnection();
			pstmt=con.prepareStatement(SQL);
			rs=pstmt.executeQuery();
			
			while(rs!=null&&rs.next()){
				chargingCodeList.add(
						new ChargingCodeDetail(rs.getInt("CHARGING_CODE"),
								rs.getDouble("AMOUNT_PRE"),
								rs.getDouble("AMOUNT_POST"),
								rs.getString("CHARGING_CODE_NAME"),
								rs.getInt("TARIFF_PRE"),
								rs.getInt("TARIFF_POST")));
			}
		}catch (Exception e) {
			logger.fatal("ERROR in retriving CHARGING_CODE detailS!",e);
			return null;
		}finally{
			try{
			 if(rs!=null){rs.close();rs=null;}
			 if(pstmt!=null){pstmt.close();pstmt=null;}
			 if(con!=null){TSSJavaUtil.instance().freeConnection(con);con=null;}
			}catch (SQLException e) {
				logger.error(" Problem in closing transaction.",e);
			}
		}
		return chargingCodeList;
	}//### END of getChargingCodeList ###//
	
	
	/**
	 * @author pankajmishra
	 * 
	 * This method provide List of all SMS templates available in LBS_TEMPLATES table.
	 * 
	 * @return List<TemplateSMS>
	 * 		java.util.List<TemplateSMS> if operation is successful, 
	 * 		null - if operation is failed with any reason. 
	 */
	public List<TemplateSMS> getSMSTemplateList(){
		
		logger.info(" under getSMSTemplateList() ");
		
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		Connection con=null;
		String SQL="select TEMPLATE_ID,TEMPLATE_MESSAGE,LANGUAGE_ID from LBS_TEMPLATES where LANGUAGE_ID=1 order by TEMPLATE_ID ";
		logger.info("query = "+SQL);
		List<TemplateSMS> templateSMSList=new ArrayList<TemplateSMS>();
		
		
		try{
			con=TSSJavaUtil.instance().getconnection();
			pstmt=con.prepareStatement(SQL);
			rs=pstmt.executeQuery();
			
			while(rs!=null&&rs.next()){
				templateSMSList.add(new TemplateSMS(
						rs.getLong("TEMPLATE_ID"), 
						null, null, 
						rs.getString("TEMPLATE_MESSAGE"), null,
						rs.getInt("LANGUAGE_ID")));
			}
		}catch (SQLException e) {
			logger.fatal("DB-ERROR in retriving CHARGING_CODE detailS!",e);
			return null;
		}catch (Exception e) {
			logger.fatal("Other-ERROR in retriving CHARGING_CODE detailS!",e);
			return null;
		}finally{
			try{
			 if(rs!=null){rs.close();rs=null;}
			 if(pstmt!=null){pstmt.close();pstmt=null;}
			 if(con!=null){TSSJavaUtil.instance().freeConnection(con);con=null;}
			}catch (SQLException e) {
				logger.error(" Problem in closing transaction.",e);
			}
		}
		return templateSMSList;
	}//### END of getSMSTemplateList
	
	/**
	 * @author pankajmishra
	 * 
	 * This method is validate uniqueness of MASKED_NAME given to RATE-PLAN by user.
	 *  
	 * @param maskedName
	 * @return
	 * 	false= in case of Validation failed or Any ERROR occurred
	 *  true = If validation is successful and masked name exists of given name.
	 */
	public boolean isMaskedNameExists(String maskedName) {

		logger.info(" under isMaskedNameExists() MASKED_NAME=" + maskedName);

		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Connection con = null;
		boolean status = false;
		String SQL = "select PLAN_NAME from VCC_RATE_PLAN where UPPER(PLAN_NAME)=UPPER(?)";
		//Query updated by MoHit for COMMON 3 March 15
		try {
			con = TSSJavaUtil.instance().getconnection();
			pstmt = con.prepareStatement(SQL);
			pstmt.setString(1, maskedName);
			rs = pstmt.executeQuery();

			if (rs != null && rs.next()) {
				logger.info("masked name exists in table = "+rs.getString("PLAN_NAME"));
				status = true;
			}
		} catch (Exception e) {
			logger.fatal("ERROR in retriving CHARGING_CODE detailS!", e);
			return false;
		} finally {
			try {
				if (rs != null) {
					rs.close();
					rs = null;
				}
				if (pstmt != null) {
					pstmt.close();
					pstmt = null;
				}
				if (con != null) {
					TSSJavaUtil.instance().freeConnection(con);
					con = null;
				}
			} catch (SQLException e) {
				logger.error(" Problem in closing transaction.", e);
			}
		}
		return status;
	}// ### END OF isMaskedNameExists()
	
	
	
	public boolean isPackNameExists(String maskedName) {
		
		logger.info(" under isPackNameExists() PACK_NAME=" + maskedName);

		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Connection con = null;
		boolean status = false;
		String SQL = "select * from CRBT_PACK_DETAIL where upper(PACK_NAME)=?";
		try {
			con = TSSJavaUtil.instance().getconnection();
			pstmt = con.prepareStatement(SQL);
			pstmt.setString(1, maskedName.toUpperCase());
			rs = pstmt.executeQuery();

			if (rs != null && rs.next()) {
				status = true;
			}
			else
			{
				logger.info("pack does not exists");
			}
		} catch (Exception e) {
			logger.fatal("ERROR in retriving Pack Name detailS!", e);
			return false;
		} finally {
			try {
				if (rs != null) {
					rs.close();
					rs = null;
				}
				if (pstmt != null) {
					pstmt.close();
					pstmt = null;
				}
				if (con != null) {
					TSSJavaUtil.instance().freeConnection(con);
					con = null;
				}
			} catch (SQLException e) {
				logger.error(" Problem in closing transaction.", e);
			}
		}
		return status;
	}// ### END OF isMaskedNameExists()
	

	
	/**
	 * @author pankajmishra
	 * 
	 * This method fetch all CRBT-rateplan detail from CRBT_RATE_PLAN table.
	 * 
	 * @return java.util.List<CrbtRatePlanBean>
	 * 		List<CrbtRatePlanBean> crbtRatePlanList= If projection is successful from database;
	 * 		null	= If Any error is detected
	 */
	public List<VCCRatePlanBean> getCrbtRatePlanList(){
		
		logger.info(" under getRatePlanList() ");
		
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		Connection con=null;
		
		String SQL="select PLAN_ID,SUB_CODE,SUB_VALIDITY,RENEW,RENEW_VALIDITY,RETRIEVE_CODE,RECORD_CODE,GROUP_RECORD_CODE,SERVICE_TYPE,PULL_SMS_CODE,PLAN_NAME,MAILBOX_ID,SCOPE from VCC_RATE_PLAN";
		//String SQL="select PLAN_INDICATOR,FREE_RBT,FREE_RECORDING,FREE_GIFT,SUB_FB_CHG_CODE,RBT_FB_CHG_CODE," +
				//"GIFT_FB_CHG_CODE,REC_FB_CHG_CODE,SUB_RENEW_FB_CHG_CODE,RBT_RENEW_FB_CHG_CODE," +
			//	"REC_RENEW_FB_CHG_CODE,STATUS,REMARKS,SCOPE,MASKED_NAME from CRBT_RATE_PLAN";
		
	//	String SQL_1="select PLAN_INDICATOR,FREE_RBT,FREE_RECORDING,FREE_GIFT,SUB_FB_CHG_CODE,RBT_FB_CHG_CODE,GIFT_FB_CHG_CODE,REC_FB_CHG_CODE,SUB_RENEW_FB_CHG_CODE,RBT_RENEW_FB_CHG_CODE,REC_RENEW_FB_CHG_CODE,STATUS,REMARKS,SCOPE,MASKED_NAME,PROCESS from CRBT_RATE_PLAN";
		
		
		List<VCCRatePlanBean> crbtRatePlanList=new ArrayList<VCCRatePlanBean>();
		
		try{
			con=TSSJavaUtil.instance().getconnection();
			pstmt=con.prepareStatement(SQL);
			rs=pstmt.executeQuery();
			if(rs==null)
			{
				logger.info("no rate plan exists");
			}
			while(rs!=null&&rs.next()){
				crbtRatePlanList.add(
						new VCCRatePlanBean(
						rs.getInt("PLAN_ID"), rs.getInt("SUB_CODE"), 
						rs.getInt("SUB_VALIDITY"), rs.getInt("RENEW"),
						rs.getInt("RENEW_VALIDITY"),rs.getInt("RETRIEVE_CODE"),rs.getInt("RECORD_CODE"),
						rs.getInt("GROUP_RECORD_CODE"),rs.getString("SERVICE_TYPE"),
						rs.getInt("PULL_SMS_CODE"), rs.getString("PLAN_NAME"),rs.getInt("MAILBOX_ID"),
						rs.getString("SCOPE")));
			}
		}catch (Exception e) {
			logger.fatal("ERROR in retriving VCC_RATE_PLAN details!",e);
			return null;
		}finally{
			try{
			 if(rs!=null){rs.close();rs=null;}
			 if(pstmt!=null){pstmt.close();pstmt=null;}
			 if(con!=null){TSSJavaUtil.instance().freeConnection(con);con=null;}
			}catch (SQLException e) {
				logger.error(" Problem in closing transaction.",e);
			}
		}
		return crbtRatePlanList;
	}//### END of getCrbtRatePlanList ###//
	
	/**
	 * @author pankajmishra
	 * 
	 * This method select CRBT_RATE_PLAN detail from database and populate CrbtRatePlanBean object.
	 * 
	 * @param maskedName
	 * @return	CrbtRatePlanBean
	 * , return null = in case of any exception.
	 * 	
	 */
public int getCrbtRatePlanByMaskedName(List<VCCRatePlanBean> crbtRatePlanList,int maskId){
		
		logger.info(" under getRatePlanList() mask iD"+maskId);
		
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		Connection con=null;
		String SQL="";
		try
		{
		con=TSSJavaUtil.instance().getconnection();
		if(maskId==-1)
		{
			logger.info("Inside maskId is -1");
		SQL="select PLAN_ID,SUB_CODE,SUB_VALIDITY,RENEW,RENEW_VALIDITY,RETRIEVE_CODE,RECORD_CODE,GROUP_RECORD_CODE,SERVICE_TYPE,PULL_SMS_CODE,PLAN_NAME,MAILBOX_ID,SCOPE from VCC_RATE_PLAN";
		pstmt=con.prepareStatement(SQL);
		}
		else
		{
			SQL="select PLAN_ID,SUB_CODE,SUB_VALIDITY,RENEW,RENEW_VALIDITY,RETRIEVE_CODE,RECORD_CODE,GROUP_RECORD_CODE,SERVICE_TYPE,PULL_SMS_CODE,PLAN_NAME,MAILBOX_ID,SCOPE from VCC_RATE_PLAN where PLAN_ID=?";
			pstmt=con.prepareStatement(SQL);
			pstmt.setInt(1, maskId);
		}

			rs=pstmt.executeQuery();
			while(rs.next()){
				logger.info("Record exist inside data base");
				
				crbtRatePlanList.add(new VCCRatePlanBean(
						rs.getInt("PLAN_ID"), rs.getInt("SUB_CODE"), 
						rs.getInt("SUB_VALIDITY"), rs.getInt("RENEW"),
						rs.getInt("RENEW_VALIDITY"),rs.getInt("RETRIEVE_CODE"),rs.getInt("RECORD_CODE"),
						rs.getInt("GROUP_RECORD_CODE"),rs.getString("SERVICE_TYPE"),
						rs.getInt("PULL_SMS_CODE"), rs.getString("PLAN_NAME"),rs.getInt("MAILBOX_ID"),
						rs.getString("SCOPE")));
			}
			
		}catch (Exception e) {
			logger.fatal("ERROR in retriving VCC_RATE_PLAN details!",e);
			return -1;
		}finally{
			try{
			 if(rs!=null){rs.close();rs=null;}
			 if(pstmt!=null){pstmt.close();pstmt=null;}
			 if(con!=null){TSSJavaUtil.instance().freeConnection(con);con=null;}
			}catch (SQLException e) {
				logger.error(" Problem in closing transaction.",e);
			}
		}
		return 0;
	}//### END of getCrbtRatePlanList ###//
	
	/*public CrbtRatePlanBean getCrbtRatePlanByMaskedName(String maskedName) {

		logger.info(" under getCrbtRatePlanByMaskedName() maskedName= "+maskedName);

		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Connection con = null;

		String SQL = "select PLAN_INDICATOR,FREE_RBT,FREE_RECORDING,FREE_GIFT,SUB_FB_CHG_CODE,RBT_FB_CHG_CODE,"
				+ "GIFT_FB_CHG_CODE,REC_FB_CHG_CODE,SUB_RENEW_FB_CHG_CODE,RBT_RENEW_FB_CHG_CODE,"
				+ "REC_RENEW_FB_CHG_CODE,STATUS,REMARKS,SCOPE,PROCESS, MASKED_NAME,COUNTRY_CODE from CRBT_RATE_PLAN where MASKED_NAME=?";
		
		CrbtRatePlanBean crbtRatePlan = new CrbtRatePlanBean();

		try {
			con = TSSJavaUtil.instance().getconnection();
			pstmt = con.prepareStatement(SQL);
			pstmt.setString(1, maskedName);

			rs = pstmt.executeQuery();

			if (rs != null && rs.next()) {
				crbtRatePlan = new CrbtRatePlanBean(
						rs.getInt("PLAN_INDICATOR"), rs.getInt("FREE_RBT"),
						rs.getInt("FREE_RECORDING"), rs.getInt("FREE_GIFT"),
						rs.getString("SUB_FB_CHG_CODE"),
						rs.getString("RBT_FB_CHG_CODE"),
						rs.getString("GIFT_FB_CHG_CODE"),
						rs.getString("REC_FB_CHG_CODE"),
						rs.getString("SUB_RENEW_FB_CHG_CODE"),
						rs.getString("RBT_RENEW_FB_CHG_CODE"),
						rs.getString("REC_RENEW_FB_CHG_CODE"),
						rs.getString("STATUS"), rs.getString("REMARKS"),
						rs.getString("SCOPE"), rs.getString("MASKED_NAME"));
				
				crbtRatePlan.setProcess(rs.getString("PROCESS"));
				crbtRatePlan.setCountryCode(rs.getInt("COUNTRY_CODE"));
			}
			else
			{
				logger.info("rate plan does not exists");
			}
		} catch (SQLException e) {
			logger.fatal("DB-ERROR in retriving CRBT_RATE_PLAN details!", e);
			return null;
		}catch (Exception e) {
			logger.fatal("other-ERROR in retriving CRBT_RATE_PLAN details!", e);
			return null;
		}  finally {
			try {
				if (rs != null) {
					rs.close();
					rs = null;
				}
				if (pstmt != null) {
					pstmt.close();
					pstmt = null;
				}
				if (con != null) {
					TSSJavaUtil.instance().freeConnection(con);
					con = null;
				}
			} catch (SQLException e) {
				logger.error(" Problem in closing transaction.", e);
			}
		}
		return crbtRatePlan;
	}*/
 
	/**
	 * @author Manoj Panda
	 * It make delte from request to CRBT_RATE_PLAN table to delete record by MASKED_NAME
	 * 
	 * @param maskedName of type java.lang.String
	 * @return int
	 * 	return 0= Operation is neutral
	 * 	return 1= Operation is successful
	 *  return -1= Operation is Failed
	 */
	public int deleteRatePlan(ArrayList rateplanAl) {
		logger.info(" under delete Rateplan() ratePLan "+rateplanAl);
		int ratePlanId=-1;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Connection con = null;
		String SQL = "delete from VCC_RATE_PLAN where PLAN_ID = ? ";
		try {
			
			con = TSSJavaUtil.instance().getconnection();
			pstmt = con.prepareStatement(SQL);
			
			Iterator ite = rateplanAl.iterator ();
			while(ite.hasNext ())
			{
				ratePlanId =(Integer)ite.next ();
				pstmt.setInt(1,ratePlanId);
				pstmt.executeUpdate();
			}
			pstmt.close ();
		} catch (SQLException e) {
			logger.error("DB-ERROR in deleting VCC_RATE_PLAN details! "+e.toString(), e);
			return -1;
			
		} catch (Exception e) {
			logger.error("Other-ERROR in deleting VCC_RATE_PLAN details! "+e.toString(), e);
			return -1;
			
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
					pstmt = null;
				}
				if (con != null) {
					TSSJavaUtil.instance().freeConnection(con);
					con = null;
				}
			} catch (SQLException e) {
				logger.error(" Problem in closing transaction.", e);
			}
		}
		return 0;
		
	}//#### deleteCrbtRatePlan
	/**
	 * @author Pankaj Mishra
	 * 
	 * This method insert formed String of Fall-back and Process 
	 * regarding Pre-paid and Post-paid string into CRBT_RATE_PLAN table.
	 * 
	 * 
	 * @param crbtRatePlanBean of type CrbtRatePlanBean
	 * @return 
	 * 		0= For No operation happened
	 * 		1= For insert is successful
	 * 		-1= Any DB-operation failure
	 */
	
	public int addRatePlan(VCCRatePlanBean bean)
	{
		int status=-1;
		logger.info("Inside addRatePlan "+bean.toString());
		PreparedStatement pstmt = null;
 		Connection con = null;
 		String query="";
 		try
 		{
 			query="insert into VCC_RATE_PLAN (SUB_CODE,SUB_VALIDITY,RENEW,RENEW_VALIDITY,RETRIEVE_CODE,RECORD_CODE,GROUP_RECORD_CODE,SERVICE_TYPE,PULL_SMS_CODE,PLAN_NAME,SCOPE,MAILBOX_ID) values(?,?,?,?,?,?,?,?,?,?,?,?)";
 			con=TSSJavaUtil.instance().getconnection();
 			pstmt=con.prepareStatement(query);
 			pstmt.setInt(1,bean.getSubCode());
 			pstmt.setInt(2,bean.getSubValidity());
 			pstmt.setInt(3,bean.getRenew());
 			pstmt.setInt(4,bean.getRenewValidity());
 			pstmt.setInt(5,bean.getRetCode());
 			pstmt.setInt(6,bean.getRcrdCode());
 			pstmt.setInt(7,bean.getGrpRcrdCode());
 			pstmt.setString(8,bean.getServiceType());
 			pstmt.setInt(9,bean.getPullSms());
 			pstmt.setString(10, bean.getMaskName());
 			pstmt.setString(11,bean.getScope());
 			pstmt.setInt(12,bean.getMailBoxId());
 			status=pstmt.executeUpdate();
 			if(status>0)
 			{
 				logger.info("Record inserted successfully");
 			}
 		}
 		catch (Exception e) {
			logger.error("Exception inside add rate plan() "+e.getMessage());// TODO: handle exception
			status=-1;
 		}
 		finally
 		{
 			try
 			{
 			if(pstmt!=null)
 				pstmt.close();
 			if (con != null) {
				TSSJavaUtil.instance().freeConnection(con);
				con = null;
			}
 			}
 			catch (Exception e) {
				logger.error("Exception inside close connection in addrateplan()"+e.getMessage());// TODO: handle exception
 			}
 		}
 		return status;
	}
	
	public int updateRatePlan(VCCRatePlanBean bean)
	{
		int status=-1;
		logger.info("Inside updateRatePlan() bean is"+bean+"plan Id="+bean.getPlanId());
		PreparedStatement pstmt = null;
 		Connection con = null;
 		String query="";
		try
		{
			query="update VCC_RATE_PLAN set SUB_CODE=?,SUB_VALIDITY=?,RENEW=?,RENEW_VALIDITY=?,RETRIEVE_CODE=?,RECORD_CODE=?,GROUP_RECORD_CODE=?,PULL_SMS_CODE=?,SCOPE=?,MAILBOX_ID=?,SERVICE_TYPE=? where PLAN_ID=?";
			con=TSSJavaUtil.instance().getconnection();
			pstmt=con.prepareStatement(query);
 			pstmt.setInt(1,bean.getSubCode());
 			pstmt.setInt(2,bean.getSubValidity());
 			pstmt.setInt(3,bean.getRenew());
 			pstmt.setInt(4,bean.getRenewValidity());
 			pstmt.setInt(5,bean.getRetCode());
 			pstmt.setInt(6,bean.getRcrdCode());
 			pstmt.setInt(7,bean.getGrpRcrdCode());
 			pstmt.setInt(8,bean.getPullSms());
 			pstmt.setString(9,bean.getScope());
 			pstmt.setInt(10,bean.getMailBoxId());
 			pstmt.setString(11,bean.getServiceType());
 			pstmt.setInt(12,bean.getPlanId());
 			
 			status=pstmt.executeUpdate();
 			logger.info("status is"+status);
		}
		catch (Exception e) {
			logger.error("Exception inside updateRatePlan()"+e.getMessage());// TODO: handle exception
			status=-1;
			
		}
		finally
		{
			try {
				if (pstmt != null) {
					pstmt.close();
					pstmt = null;
				}
				if (con != null) {
					TSSJavaUtil.instance().freeConnection(con);
					con = null;
				}
			} catch (SQLException e) {
				logger.error(" Problem in closing transaction.", e);
			}
		}
		return status;
	}
	
	/*public int addRatePlan(CrbtRatePlanBean crbtRatePlanBean)
	{
		int status=0;

		logger.info(" under addRatePlan() ");
		logger.info("crbtRatePlanBean ="+crbtRatePlanBean.toString());
		PreparedStatement pstmt = null;
 		Connection con = null;
         String scope="";
 		
		String SQL = "insert into CRBT_RATE_PLAN" +
				"(PLAN_INDICATOR, SUB_FB_CHG_CODE, RBT_FB_CHG_CODE," +
				"GIFT_FB_CHG_CODE, REC_FB_CHG_CODE, SUB_RENEW_FB_CHG_CODE, RBT_RENEW_FB_CHG_CODE," +
				"REC_RENEW_FB_CHG_CODE, STATUS, MASKED_NAME) " +
				"values(crbt_rate_plan_seq.nextval,?,?,?,?,?,?,?,'A',?)"; 
		
 		
 		String SQL = "insert into CRBT_RATE_PLAN" +
				"(PLAN_INDICATOR, FREE_RBT, FREE_RECORDING, FREE_GIFT, SUB_FB_CHG_CODE, RBT_FB_CHG_CODE," +
				"GIFT_FB_CHG_CODE, REC_FB_CHG_CODE, SUB_RENEW_FB_CHG_CODE, RBT_RENEW_FB_CHG_CODE," +
				"REC_RENEW_FB_CHG_CODE, STATUS,REMARKS, MASKED_NAME,PROCESS,SCOPE,COUNTRY_CODE) " +
				"values(crbt_rate_plan_seq.nextval,0,0,0,?,?,?,?,?,?,?,'A','NA',?,?,?,?)";
 		//Query updated by MoHit for COMMON 3 March 15 FREE_RBT, FREE_RECORDING, FREE_GIFT and REMARKS is added
 		
		
		 		try {
			con = TSSJavaUtil.instance().getconnection();
		 	
			pstmt = con.prepareStatement(SQL);
			pstmt.setString(1, crbtRatePlanBean.getSubFbChgCode().trim());
			pstmt.setString(2,crbtRatePlanBean.getRbtFbChgCode().trim());
			pstmt.setString(3, crbtRatePlanBean.getGiftFbChgCode().trim());
			pstmt.setString(4, crbtRatePlanBean.getRecFbChgCode().trim());
			pstmt.setString(5, crbtRatePlanBean.getSubRenewFbChgCode().trim());
			pstmt.setString(6, crbtRatePlanBean.getRbtRenewFbChgCode().trim());
			pstmt.setString(7, crbtRatePlanBean.getRecRenewFbChgCode().trim()); 
			pstmt.setString(8, crbtRatePlanBean.getMaskedName().trim().toUpperCase());
			pstmt.setString(9, crbtRatePlanBean.getProcess().trim());
			System.out.println("CrbtRatePlanBean "+crbtRatePlanBean+" Country Code "+crbtRatePlanBean.getCountryCode());
			System.out.println("CrbtRatePlanBean Scope is "+crbtRatePlanBean.getScope());
			if(crbtRatePlanBean.getScope().equalsIgnoreCase("P"))
			{
				scope="SUBTYPE:P";
			}
			else if(crbtRatePlanBean.getScope().equalsIgnoreCase("O"))
			{
			 scope="SUBTYPE:O";	
			}
			else if(crbtRatePlanBean.getScope().equalsIgnoreCase("B"))
			{
				scope="SUBTYPE:B";	
			}
			else
			{
				scope="SUBTYPE:S";
			}
			pstmt.setString(10,scope.trim());
			pstmt.setInt(11,crbtRatePlanBean.getCountryCode());
			status = pstmt.executeUpdate();
             pstmt.close();
			if(status>0){
				
		       SQL = "insert into RATE_PLAN_ALIAS (MASKED_NAME,ALIAS_NAME) values(?,?)";
		 		//Query added by shambhavi
		 		
					pstmt = con.prepareStatement(SQL);
					
					pstmt.setString(1, crbtRatePlanBean.getMaskedName().trim().toUpperCase());
					pstmt.setString(2, crbtRatePlanBean.getMaskedName().trim().toUpperCase());
					System.out.println("Masked name "+crbtRatePlanBean.getMaskedName().trim().toUpperCase());
					status = pstmt.executeUpdate();
				logger.info("Inserted into RATE_PLAN_ALIAS successfully with status ["+status+"]");
                 pstmt.close();			
			}
		} catch (Exception e) {
			logger.fatal("ERROR in inserting/adding CRBT_RATE_PLAN details!", e);
		     e.printStackTrace();
			return -1;
		} finally {
			try {
				 
				if (pstmt != null) {
					pstmt.close();
					pstmt = null;
				}
				if (con != null) {
					TSSJavaUtil.instance().freeConnection(con);
					con = null;
				}
			} catch (SQLException e) {
				logger.error(" Problem in closing transaction.", e);
			}
		}
		logger.info("adding rate plan status= "+status);
		return status;
	}//#### END OF addRatePlan
*/
	//##############Pack Added

	/**
	 * @author PANKAJ KUMAR MISHRA
	 * It update rate-plan to CRBT_RATE_PLAN table.
	 * 
	 * @param crbtRatePlanBean  of type CrbtRatePlanBean
	 * @return int 
	 * 		0 = If no update happened
	 * 		-1 = In case of any ERROR
	 * 		1 = If update is successful   
	 */
/*	public int updateRatePlan(CrbtRatePlanBean crbtRatePlanBean)
	{
		int status=0;

		logger.info(" under updateRatePlan() ");
		logger.info("crbtRatePlanBean ="+crbtRatePlanBean.toString());
		PreparedStatement pstmt = null;
 		Connection con = null;

		String SQL = "update CRBT_RATE_PLAN " +
				"set SUB_FB_CHG_CODE=?,RBT_FB_CHG_CODE=?," +
				"GIFT_FB_CHG_CODE=?,REC_FB_CHG_CODE=?,SUB_RENEW_FB_CHG_CODE=?," +
				"RBT_RENEW_FB_CHG_CODE=?,REC_RENEW_FB_CHG_CODE=?, PROCESS=?,SCOPE=?,COUNTRY_CODE=?" +
				"where MASKED_NAME=?";
		
 		
 		String SQL = "insert into CRBT_RATE_PLAN" +
				"(PLAN_INDICATOR, SUB_FB_CHG_CODE, RBT_FB_CHG_CODE," +
				"GIFT_FB_CHG_CODE, REC_FB_CHG_CODE, SUB_RENEW_FB_CHG_CODE, RBT_RENEW_FB_CHG_CODE," +
				"REC_RENEW_FB_CHG_CODE, STATUS, MASKED_NAME,PROCESS) " +
				"values(crbt_rate_plan_seq.nextval,?,?,?,?,?,?,?,'A',?,?)";
 		
		
		  try {
			con = TSSJavaUtil.instance().getconnection();
			
			pstmt = con.prepareStatement(SQL);
			pstmt.setString(1, crbtRatePlanBean.getSubFbChgCode().trim());
			pstmt.setString(2,crbtRatePlanBean.getRbtFbChgCode().trim());
			pstmt.setString(3, crbtRatePlanBean.getGiftFbChgCode().trim());
			pstmt.setString(4, crbtRatePlanBean.getRecFbChgCode().trim());
			pstmt.setString(5, crbtRatePlanBean.getSubRenewFbChgCode().trim());
			pstmt.setString(6, crbtRatePlanBean.getRbtRenewFbChgCode().trim());
			pstmt.setString(7, crbtRatePlanBean.getRecRenewFbChgCode().trim()); 
			pstmt.setString(8, crbtRatePlanBean.getProcess().trim());
			
			
			
			 * Added Two Values By Rinku
			 
			 if("P".equalsIgnoreCase(crbtRatePlanBean.getScope()))
			 {
				 pstmt.setString(9,"SUBTYPE:P");	 
			 }
			 else if("O".equalsIgnoreCase(crbtRatePlanBean.getScope()))
			 {
				 pstmt.setString(9,"SUBTYPE:O");
			 }
			 else if("B".equalsIgnoreCase(crbtRatePlanBean.getScope()))
			 {
				 pstmt.setString(9,"SUBTYPE:B");
			 }
			 else
			 {
				 pstmt.setString(9,"SUBTYPE:S");
			 }
			pstmt.setInt(10, crbtRatePlanBean.getCountryCode());
			pstmt.setString(11, crbtRatePlanBean.getMaskedName().trim().toUpperCase());
			status = pstmt.executeUpdate();

		
		} catch (Exception e) {
			logger.fatal("ERROR in inserting/adding CRBT_RATE_PLAN details!", e);
			return -1;
		} finally {
			try {
				 
				if (pstmt != null) {
					pstmt.close();
					pstmt = null;
				}
				if (con != null) {
					TSSJavaUtil.instance().freeConnection(con);
					con = null;
				}
			} catch (SQLException e) {
				logger.error(" Problem in closing transaction.", e);
			}
		}
		logger.info("updating rate plan status= "+status);
		return status;
	}//#### END OF updateRatePlan
*/
    
//  ##########Added By Harjinder to get Campaign list##################  //	
public List<CampaignListBean> getCampaignList(){
		
	
	
		
		
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		Connection con=null;
		
	    	
		String SQL="select LIST_ID,LIST_NAME,STATUS from CAMPAIGN_LIST_MASTER";
		List<CampaignListBean> campaignList=new ArrayList<CampaignListBean>();
		logger.info("query = "+SQL);		
		
		
		try{
			logger.info(" under getCampaignList() ");
			
			
			con=TSSJavaUtil.instance().getconnection();
			pstmt=con.prepareStatement(SQL);
			rs=pstmt.executeQuery();
			CampaignListBean campbean=null;
			
			
			while(rs!=null&&rs.next()){
                   
				campbean=new CampaignListBean();
				System.out.println("name:["+rs.getString("LIST_NAME")+"] id["+rs.getInt("List_Id") +"] status["+rs.getString("Status")+"]");
				
				campbean.setList_id(rs.getInt("List_Id"));
				campbean.setList_name(rs.getString("List_Name"));
				campbean.setStatus(rs.getString("Status"));
				
				campaignList.add(campbean);
				System.out.println("list size:"+campaignList.size());		
						
								
			}
		}catch (Exception e) {
			logger.fatal("ERROR in retriving CAMPAIGNLIST!",e);
			return null;
		}finally{
			try{
			 if(rs!=null){rs.close();rs=null;}
			 if(pstmt!=null){pstmt.close();pstmt=null;}
			 if(con!=null){con.close();con=null;}
			}catch (SQLException e) {
				logger.error(" Problem in closing transaction.",e);
			}
		}
		System.out.println("Campaign lIst size:"+campaignList.size());
		return campaignList;
	}//### END of getChargingCodeList ###//

//start of added by MoHit for COMMON 4 March 2015
	public HashMap<Integer, String> getRatePlanList(int countryCode) 
	{
		logger.info("inside getRatePlanList() countryCode="+countryCode);

		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Connection con = null;
		HashMap<Integer, String> ratePlanList=null;
		
		String query = "select distinct(PLAN_INDICATOR) , MASKED_NAME from crbt_rate_plan where COUNTRY_CODE=?";
		logger.info("query= "+query);
		try 
		{
				con = TSSJavaUtil.instance().getconnection();
				pstmt = con.prepareStatement(query);
				pstmt.setInt(1, countryCode);
				rs = pstmt.executeQuery();
				
				ratePlanList=new HashMap<Integer, String>();
				while(rs.next() && rs!=null)
				{
					ratePlanList.put(rs.getInt("PLAN_INDICATOR"), rs.getString("MASKED_NAME"));
				}
				con.close();
				pstmt.close();
				rs.close();
		}
		catch (Exception e) 
		{
			logger.info("Exception while getting ratePlanList ."+e);
			e.printStackTrace();
		}
		finally
		{
			try{
				if(rs!=null)
					rs.close();
				if(pstmt!=null)
					pstmt.close();
				if(con!=null)
					con.close();
			}
			catch (Exception e) {
				logger.info("exception while closing");
				e.printStackTrace();
			}
		}
		return ratePlanList;
	}//getRatePlanList()
//end of added by MoHit for COMMON 4 March 2015			
	
}
			
			