
package com.telemune.vcc.webadmin;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import com.telemune.dbutilities.*;
import com.telemune.vcc.common.Rbt;
import com.telemune.vcc.common.TSSJavaUtil;

import org.apache.log4j.*;
public class RbtOrderManager

{
	static Logger logger=Logger.getLogger(RbtOrderManager.class);
	private PreparedStatement pstmt = null;
	private Connection con = null;	
	private String query = null;

	
	public int searchRbtTones(int catId, ArrayList<Rbt> rbtList)
	{	
		logger.info("In searchRbtTones to search rbts of catId:"+catId+"");
		PreparedStatement pstmt=null;
		ResultSet rs = null;
		String query = null;
		String specialCatId ="998";
		String recordedCatId="999";	

		try 
		{
			con = TSSJavaUtil.instance().getconnection();
			if(con == null) {
				logger.info("Connection is NULL");
				return -99;
			}

			specialCatId   = TSSJavaUtil.instance().getAppConfigParam("SPECIAL_CONTROL_CATID");
			recordedCatId  = TSSJavaUtil.instance().getAppConfigParam("CRBT_RECORDED_CATEGORY_ID");
			
			query = "select * from (select RBT_CODE, RB.MASKED_NAME RBT,RBT_ORDER from  CRBT_RBT RB, CRBT_CATEGORY_MASTER CM where RB.CAT_ID=CM.CAT_ID and RB.CAT_ID=? and RBT_CODE not in (select RBT_CODE from CRBT_RBT_CONTROL) and not(RB.CAT_ID = ?) and not(RB.CAT_ID = ?) order by RB.MASKED_NAME)";
			logger.info("query = "+query);			
			pstmt = con.prepareStatement(query);
			pstmt.setInt(1,catId);		
			pstmt.setString(2, recordedCatId);
			pstmt.setString(3, specialCatId);
			
			rs = pstmt.executeQuery();
			while(rs.next()) {
				Rbt rbt=new Rbt(rs.getInt("RBT_CODE"),rs.getInt("RBT_ORDER"),rs.getString("RBT"));
				rbtList.add(rbt);
			}
			//logger.info("Total Fetched Rbts are:"+rbtList.size());
			
			pstmt.close();
			rs.close();
		}//try
		catch(Exception e)
		{	
			logger.error("Error in searchRbtTones() of RbtOrderManager:"+e);
			e.printStackTrace ();
			try
			{
				if( pstmt != null || rs != null ) 
				{
					pstmt.close();
					rs.close();
				}//if
			}//try
			catch (SQLException sqle)
			{
				logger.error("In searchRbtTones() of RbtOrderManager, SQLException :"+sqle);
			}
			
			return -1;
		}//catch
		finally
		{
			TSSJavaUtil.instance().freeConnection(con);
		}
		
		return 1;
	}

	
	public int addNewOrder(ArrayList<Integer>newRbtOrderIds,ArrayList<Integer>newRbtOrderValues)
	{	
		logger.info("In addNewOrder() to add/Modify RbtOrder In db");		
		int dbResult[]=new int[newRbtOrderIds.size()];
		
		try
		{
			con = TSSJavaUtil.instance().getconnection();
			query = "update crbt_rbt set RBT_ORDER=? where RBT_CODE=?";
			pstmt = con.prepareStatement(query);			
			logger.info("Query:"+query);
			
			for(int i=0;i<newRbtOrderIds.size();i++)
			{
			pstmt.setInt(1,newRbtOrderValues.get(i));
			pstmt.setInt(2,newRbtOrderIds.get(i));
			pstmt.addBatch();
			
			}
			dbResult=pstmt.executeBatch();
			pstmt.close();			
			
			for(int i=0;i<dbResult.length;i++)
			{	
				if(dbResult[i]>0)
				{
					logger.info("Rbt Order Insertion Operation performed Successfully Num of effected rows are:"+dbResult[i]);
					return 1;					
				}
				else if(dbResult[i]==-2)
				{
					logger.info("Rbt Order Insertion Operation performed Successfully But Num of effected rows are Unknown with result:"+dbResult[i]);
					return 1;
				}
				else{
					logger.error("Rbt Order Insertion Operation not performed Successfully response:"+dbResult[i]);
					return -1;
				}
			}
		}//try ends
		catch (Exception e)
		{
			logger.error("Exception in addNewOrder():"+e);
			e.printStackTrace ();
			try
			{
				if (pstmt != null)
					pstmt.close ();
			}
			catch (SQLException sqle)
			{
				sqle.printStackTrace();
				return -1;	
			}
			
			return -1;
		}//catch
		finally{
			TSSJavaUtil.instance().freeConnection(con);
			}
		return 1;
}//addNewOrder() ends
	

} //class RbtOrderManager






