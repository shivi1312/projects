package com.telemune.vcc.webadmin;

import java.util.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.telemune.dbutilities.*;
import com.telemune.vcc.common.TSSJavaUtil;
import com.telemune.vcc.webadmin.action.RatePlanBean;

import org.apache.log4j.*;
public class RbtRatePlanManager
{
	static Logger logger=Logger.getLogger(RbtRatePlanManager.class);
	private ResultSet rs = null;
	private PreparedStatement pstmt = null;
	private PreparedStatement pstmt1 = null;
	private Connection con = null;
	private String query = null;
	private String query1 = null;


	public int addRbtRatePlan (RbtRatePlan rbtObj)
	{
		logger.info("webadmin: addRbtRatePlan");
		long pln_id=0;
		try
		{
			con =TSSJavaUtil.instance().getconnection();
			/*	query = "SELECT DESCRIPTION FROM VCC_RATE_PLAN WHERE DESCRIPTION=? ";
			pstmt = con.prepareStatement (query);
			pstmt.setString (1,chgObj.getDesc());
			rs = pstmt.executeQuery ();
			if(rs.next ())
			{
				rs.close ();
				pstmt.close ();
				return -2; //Record already exists
			}
			rs.close ();
			pstmt.close ();*/
			query="select CHG_PLAN_ID.nextval from dual";
			pstmt=con.prepareStatement(query);
			rs = pstmt.executeQuery();
			if(rs.next())
			{
				pln_id = rs.getLong(1);
			}
			rs.close ();
			pstmt.close ();
			//		logger.info("webadmin: query execute");


			//query = "INSERT INTO VCC_RATE_PLAN (PLAN_INDICATOR, RBT_CHARGE_CODE, GIFT_CHARGE_CODE, MONOTONE_CHARGE_CODE, RBT_NO_CHARGE_CODE, RBT_NORMAL_CHARGE_CODE, SUBSCRIPTION_CHARGE_CODE, RBT_RECORDED_CHARGE_CODE, REMARKS, FILE_EXTENSION, MONTHLY_RENT_CODE, THREE_WEEK_RENT_CODE,TWO_WEEK_RENT_CODE,ONE_WEEK_RENT_CODE) VALUES (?,?,?,?,?,?,?,?,?,'cdr',?,?,?,?)";
			query = "INSERT INTO VCC_RATE_PLAN (PLAN_INDICATOR, RBT_CHARGE_CODE, GIFT_CHARGE_CODE, RBT_NORMAL_CHARGE_CODE, SUBSCRIPTION_CHARGE_CODE, REMARKS, FILE_EXTENSION, MONTHLY_RENT_CODE, THREE_WEEK_RENT_CODE,TWO_WEEK_RENT_CODE,ONE_WEEK_RENT_CODE) VALUES (?,?,?,?,?,?,'cdr',?,?,?,?)";
			logger.info("query = "+query);
			pstmt = con.prepareStatement (query);

			pstmt.setLong (1, pln_id);
			pstmt.setString (2, rbtObj.getRbtChgCode().trim());
			pstmt.setString (3, rbtObj.getRbtGiftChgCode().trim());
			//pstmt.setString (4, rbtObj.getRbtMonoChgCode());
			//	pstmt.setString (5, rbtObj.getRbtNoChgCode());
			pstmt.setString (4, rbtObj.getRbtNormalChgCode().trim());
			pstmt.setString (5, rbtObj.getSubChgCode().trim());
			//	pstmt.setString (8, rbtObj.getRbtRecChgCode());
			pstmt.setString (6, rbtObj.getRemarks().trim());
			pstmt.setString (7, rbtObj.getMRentCode().trim());
			pstmt.setString (8, rbtObj.getThreeWeek().trim());
			pstmt.setString (9, rbtObj.getTwoWeek().trim());
			pstmt.setString (10, rbtObj.getOneWeek().trim());

			pstmt.executeUpdate ();
			logger.debug("webadmin: query execute");
			pstmt.close ();
		}//try
		catch (Exception e)
		{
			try
			{
				if(pstmt != null) pstmt.close ();
				if(rs != null) rs.close ();
			}catch(SQLException sqle)
			{
				logger.error("webadmin-addChargingCode: Exception is: " + sqle.getMessage ());
			}

			e.printStackTrace ();
			return -1;
		}
		finally  { try {
			if(con!=null)	TSSJavaUtil.instance().freeConnection(con);
		} catch (Exception e2) {
			// TODO: handle exception
		} } 
		return 0; //  added susccessfully
		//	return 2; //  added susccessfully

	}// addChargingCode()

	public int getRowCode (ArrayList chgAl,Connection con)
	{
		logger.info("getChargingCode() methodName=getRowCode()");
		try
		{
			//con = conPool.getConnection();
			query = "select DESCRIPTION,CHARGING_CODE from CRBT_CHARGING_CODE";
			//query="select DESCRIPTION, AMOUNT_PRE,AMOUNT_POST,CHARGING_CODE from CRBT_CHARGING_CODE where CHARGING_CODE not in (select charging_code from crbt_rbt)";
			logger.info("query = "+query);
			pstmt = con.prepareStatement (query);
			rs = pstmt.executeQuery ();
			if(rs==null)
			{
				logger.info("no charging codes in crbt_charging_code");
			}
			while(rs.next ())
			{
				RbtRatePlan rrpOb = new RbtRatePlan ();
				rrpOb.setDesc (rs.getString ("DESCRIPTION"));
				rrpOb.setChgCode (rs.getLong ("CHARGING_CODE"));
				chgAl.add (rrpOb);
			}
			rs.close ();
			pstmt.close ();
		} //try
		catch (Exception e)
		{
			try
			{
				if(rs != null) rs.close ();
				if(pstmt != null) pstmt.close ();
			}catch(SQLException sqle)
			{
				logger.error ("Exception in getChargingCode: " + sqle.getMessage ());
			}
			e.printStackTrace ();
			return -1;
		}
		//finally{ conPool.free(con); }
		return 1;
	}//getRowCode

	public int getrateplan (ArrayList chargecode,String keyword, String order,String searchkey,Connection con)
	{
		logger.info("getrateplan searchKey= "+searchkey);
		try
		{
			//con = conPool.getConnection();
			if(searchkey.equalsIgnoreCase("X") )  // show all Keywords
			{
				query = "select PLAN_INDICATOR, REMARKS from VCC_RATE_PLAN ORDER BY "+keyword+" "+order;
				pstmt = con.prepareStatement (query);
			}
			else
			{
				query = "SELECT PLAN_INDICATOR, REMARKS from VCC_RATE_PLAN where UPPER(REMARKS) like UPPER(?) ORDER BY "+keyword+" "+order;
				pstmt = con.prepareStatement (query);
				pstmt.setString(1,"%"+searchkey+"%");
			}
			logger.info("query = "+query);
			rs = pstmt.executeQuery ();

			while(rs.next ())
			{
				RbtRatePlan RR_plan = new RbtRatePlan ();
				RR_plan.setPlanId (rs.getInt ("PLAN_INDICATOR"));
				RR_plan.setRemarks (rs.getString ("REMARKS"));
				chargecode.add (RR_plan);
			}
			rs.close ();
			pstmt.close ();
		} //try
		catch (Exception e)
		{
			try
			{
				if(rs != null) rs.close ();
				if(pstmt != null) pstmt.close ();
			}catch(SQLException sqle)
			{
				logger.error ("Exception in getChargingCode, Exception is : " + sqle.getMessage ());
			}
			e.printStackTrace ();
			return -1;
		}
		//finally{ conPool.free(con); }
		return 1;

	}//getrateplan()
	public int getRatePlans (ArrayList RateArray)
	{
		logger.info("webadmin: getRatePlans()");
		try
		{
			con =TSSJavaUtil.instance().getconnection();
			query = "SELECT PLAN_INDICATOR,REMARKS FROM VCC_RATE_PLAN";
			pstmt = con.prepareStatement (query);
			rs = pstmt.executeQuery ();
			if(rs==null)
			{
				logger.info("no entries in VCC_RATE_PLAN");
			}
			while(rs.next())
			{
				RbtRatePlan RRPObj =new RbtRatePlan();
				RRPObj.setPlanId (rs.getInt ("PLAN_INDICATOR"));
				RRPObj.setRemarks(rs.getString("REMARKS"));
				RateArray.add(RRPObj);
			}
			logger.debug("webadmin: query execute");
			rs.close ();
			pstmt.close ();
		}//try
		catch (Exception e)
		{
			try
			{
				if(pstmt != null) pstmt.close ();
				if(rs != null) rs.close ();
			}catch(SQLException sqle)
			{
				logger.error ("webadmin-addRatePlan: Exception is: " + sqle.getMessage ());
			}

			e.printStackTrace ();
			return -1;
		}
		finally  { try {
			if(con!=null)	TSSJavaUtil.instance().freeConnection(con);
		} catch (Exception e2) {
			// TODO: handle exception
		} } 
		return 0; //  added susccessfully

	}// viewRatePlan()

	public int viewRatePlan (RatePlanBean RRPObj,int planId,Connection con)
	{
		logger.info("webadmin: viewRatePlan planId= "+planId);
		try
		{
			//con = conPool.getConnection();
			//query = "SELECT PLAN_INDICATOR, RBT_CHARGE_CODE, GIFT_CHARGE_CODE, MONOTONE_CHARGE_CODE, RBT_NO_CHARGE_CODE, RBT_NORMAL_CHARGE_CODE, SUBSCRIPTION_CHARGE_CODE, RBT_RECORDED_CHARGE_CODE, REMARKS, MONTHLY_RENT_CODE, THREE_WEEK_RENT_CODE,TWO_WEEK_RENT_CODE,ONE_WEEK_RENT_CODE FROM VCC_RATE_PLAN WHERE PLAN_INDICATOR = ? ";
			query = "SELECT PLAN_INDICATOR, RBT_CHARGE_CODE, GIFT_CHARGE_CODE, RBT_NORMAL_CHARGE_CODE, SUBSCRIPTION_CHARGE_CODE, REMARKS, MONTHLY_RENT_CODE, THREE_WEEK_RENT_CODE,TWO_WEEK_RENT_CODE,ONE_WEEK_RENT_CODE FROM VCC_RATE_PLAN WHERE PLAN_INDICATOR = ? ";
			logger.info("query = "+query);
			pstmt = con.prepareStatement (query);
			pstmt.setInt (1, planId);
			rs = pstmt.executeQuery ();
			if(rs.next())
			{

				RRPObj.setPlanId (rs.getInt ("PLAN_INDICATOR"));
				RRPObj.setRbtChgCode (rs.getString("RBT_CHARGE_CODE"));
				RRPObj.setGiftChgCode (rs.getString("GIFT_CHARGE_CODE"));
				//		RRPObj.setRbtMonoChgCode (rs.getString("MONOTONE_CHARGE_CODE"));
				//		RRPObj.setRbtNoChgCode(rs.getString("RBT_NO_CHARGE_CODE"));
				RRPObj.setNormalChgCode(rs.getString("RBT_NORMAL_CHARGE_CODE"));
				RRPObj.setSubChgCode(rs.getString("SUBSCRIPTION_CHARGE_CODE"));
				//	RRPObj.setRbtRecChgCode(rs.getString("RBT_RECORDED_CHARGE_CODE"));
				RRPObj.setRemarks(rs.getString("REMARKS"));
				RRPObj.setMonRenCode(rs.getString("MONTHLY_RENT_CODE"));
				RRPObj.setThreeRenCode(rs.getString("THREE_WEEK_RENT_CODE"));
				RRPObj.setTwRenCode(rs.getString("TWO_WEEK_RENT_CODE"));
				RRPObj.setOneRenCode(rs.getString("ONE_WEEK_RENT_CODE"));

			}
			logger.debug("webadmin: query execute");
			rs.close ();
			pstmt.close ();
		}//try
		catch (Exception e)
		{
			try
			{
				if(pstmt != null) pstmt.close ();
				if(rs != null) rs.close ();
			}catch(SQLException sqle)
			{
				logger.error ("webadmin-addChargingCode: Exception is: " + sqle.getMessage ());
			}

			e.printStackTrace ();
			return -1;
		}
		//finally  { conPool.free(con); } 
		return 0; //  added susccessfully

	}// viewRatePlan()
	public int getRowCodeModify (ArrayList chargecode,RatePlanBean RRPObj,int planId,Connection con)
	{
		logger.info("webadmin: getRowCodeModify planId= "+planId);
		try
		{
			//con = conPool.getConnection();
			query = "select DESCRIPTION,CHARGING_CODE from CRBT_CHARGING_CODE";
			pstmt = con.prepareStatement (query);
			rs = pstmt.executeQuery ();
			while(rs.next ())
			{
				RbtRatePlan rrpOb = new RbtRatePlan ();
				rrpOb.setDesc (rs.getString ("DESCRIPTION"));
				rrpOb.setRbtChgCode (rs.getLong ("CHARGING_CODE")+"");
				chargecode.add (rrpOb);
			}
			rs.close ();
			pstmt.close ();

			//query = "SELECT PLAN_INDICATOR, RBT_CHARGE_CODE, GIFT_CHARGE_CODE, MONOTONE_CHARGE_CODE, RBT_NO_CHARGE_CODE, RBT_NORMAL_CHARGE_CODE, SUBSCRIPTION_CHARGE_CODE, RBT_RECORDED_CHARGE_CODE, REMARKS, MONTHLY_RENT_CODE, THREE_WEEK_RENT_CODE,TWO_WEEK_RENT_CODE,ONE_WEEK_RENT_CODE FROM VCC_RATE_PLAN WHERE PLAN_INDICATOR = ? ";
			query = "SELECT PLAN_INDICATOR, RBT_CHARGE_CODE, GIFT_CHARGE_CODE, RBT_NORMAL_CHARGE_CODE, SUBSCRIPTION_CHARGE_CODE, REMARKS, MONTHLY_RENT_CODE, THREE_WEEK_RENT_CODE,TWO_WEEK_RENT_CODE,ONE_WEEK_RENT_CODE FROM VCC_RATE_PLAN WHERE PLAN_INDICATOR = ? ";
			pstmt = con.prepareStatement (query);
			pstmt.setInt (1, planId);
			rs = pstmt.executeQuery ();
			if(rs==null)
			{
				logger.info("rate plan does not exists::::: query = "+query);
			}
			while(rs.next())
			{
				RRPObj.setPlanId (rs.getInt ("PLAN_INDICATOR"));
				RRPObj.setRbtChgCode (rs.getString("RBT_CHARGE_CODE"));
				RRPObj.setGiftChgCode (rs.getString("GIFT_CHARGE_CODE"));
				RRPObj.setNormalChgCode(rs.getString("RBT_NORMAL_CHARGE_CODE"));
				RRPObj.setSubChgCode(rs.getString("SUBSCRIPTION_CHARGE_CODE"));
				RRPObj.setRemarks(rs.getString("REMARKS"));
				RRPObj.setMonRenCode(rs.getString("MONTHLY_RENT_CODE"));
				RRPObj.setThreeRenCode(rs.getString("THREE_WEEK_RENT_CODE"));
				RRPObj.setTwRenCode(rs.getString("TWO_WEEK_RENT_CODE"));
				RRPObj.setOneRenCode(rs.getString("ONE_WEEK_RENT_CODE"));


				RRPObj.setRbtChgCode (rs.getString("RBT_CHARGE_CODE"));
				RRPObj.setOldGiftChgCode (rs.getString("GIFT_CHARGE_CODE"));
				RRPObj.setOldNormalChgCode(rs.getString("RBT_NORMAL_CHARGE_CODE"));
				RRPObj.setOldSubChgCode(rs.getString("SUBSCRIPTION_CHARGE_CODE"));
				RRPObj.setOldRemarks(rs.getString("REMARKS"));
				RRPObj.setOldMonRenCode(rs.getString("MONTHLY_RENT_CODE"));
				RRPObj.setOldThreeRenCode(rs.getString("THREE_WEEK_RENT_CODE"));
				RRPObj.setOldTwRenCode(rs.getString("TWO_WEEK_RENT_CODE"));
				RRPObj.setOldOneRenCode(rs.getString("ONE_WEEK_RENT_CODE"));

			}
			logger.debug("webadmin: query execute");
			rs.close ();
			pstmt.close ();
		}//try
		catch (Exception e)
		{
			try
			{
				if(pstmt != null) pstmt.close ();
				if(rs != null) rs.close ();
			}catch(SQLException sqle)
			{
				logger.error ("webadmin-addChargingCode: Exception is: " + sqle.getMessage ());
			}

			e.printStackTrace ();
			return -1;
		}
		//finally  { conPool.free(con); } 
		return 0; //  added susccessfully

	}// getRowCodeModify
	public int saveEditRatePlan(RbtRatePlan rbtObj,int pid,Connection con)
	{
		logger.info("webadmin: saveEditRatePlan");
		try
		{
			//con = conPool.getConnection();

			//query = "UPDATE VCC_RATE_PLAN SET RBT_CHARGE_CODE=?, GIFT_CHARGE_CODE=?, MONOTONE_CHARGE_CODE=?, RBT_NO_CHARGE_CODE=?, RBT_NORMAL_CHARGE_CODE=?, SUBSCRIPTION_CHARGE_CODE=?, RBT_RECORDED_CHARGE_CODE=?, REMARKS=?, MONTHLY_RENT_CODE=?, THREE_WEEK_RENT_CODE=?,TWO_WEEK_RENT_CODE=?,ONE_WEEK_RENT_CODE=? WHERE PLAN_INDICATOR=?";
			query = "UPDATE VCC_RATE_PLAN SET RBT_CHARGE_CODE=?, GIFT_CHARGE_CODE=?, RBT_NORMAL_CHARGE_CODE=?, SUBSCRIPTION_CHARGE_CODE=?, REMARKS=?, MONTHLY_RENT_CODE=?, THREE_WEEK_RENT_CODE=?,TWO_WEEK_RENT_CODE=?,ONE_WEEK_RENT_CODE=? WHERE PLAN_INDICATOR=?";
			pstmt = con.prepareStatement (query);

			pstmt.setString (1, rbtObj.getRbtChgCode().trim());
			pstmt.setString (2, rbtObj.getRbtGiftChgCode().trim());
			//			pstmt.setString (3, rbtObj.getRbtMonoChgCode());
			//		pstmt.setString (4, rbtObj.getRbtNoChgCode());
			pstmt.setString (3, rbtObj.getRbtNormalChgCode().trim());
			pstmt.setString (4, rbtObj.getSubChgCode().trim());
			//		pstmt.setString (7, rbtObj.getRbtRecChgCode());
			pstmt.setString (5, rbtObj.getRemarks().trim());
			pstmt.setString (6, rbtObj.getMRentCode().trim());
			pstmt.setString (7, rbtObj.getThreeWeek().trim());
			pstmt.setString (8, rbtObj.getTwoWeek().trim());
			pstmt.setString (9, rbtObj.getOneWeek().trim());
			pstmt.setInt (10, pid);

			pstmt.executeUpdate ();
			logger.debug("webadmin: query execute");
			pstmt.close ();
		}//try
		catch (Exception e)
		{
			try
			{
				if(pstmt != null) pstmt.close ();
				if(rs != null) rs.close ();
			}catch(SQLException sqle)
			{
				logger.error ("webadmin-addChargingCode: Exception is: " + sqle.getMessage ());
			}

			e.printStackTrace ();
			return -1;
		}
		//finally  { conPool.free(con); } 
		return 0; //  added susccessfully
		//	return 2; //  added susccessfully

	}// saveEditRatePlan


	public int DeleteRbtRatePlan(int planId,Connection con)
	{
		logger.info("webadmin: DeleteRbtRatePlan where planId is ["+planId+"]");
		try
		{
			con =TSSJavaUtil.instance().getconnection();
			query = "DELETE FROM VCC_RATE_PLAN WHERE PLAN_INDICATOR = ? ";
			pstmt = con.prepareStatement (query);
			pstmt.setInt (1, planId);
			pstmt.executeUpdate();
			logger.debug("webadmin: query execute");
			pstmt.close ();
		}//try
		catch (Exception e)
		{
			e.printStackTrace ();
			return -1;
		}
		finally  { try {
			if(con!=null)	TSSJavaUtil.instance().freeConnection(con);
		} catch (Exception e2) {
			// TODO: handle exception
		} } 
		return 0; //  added susccessfully

	}// DeleteRbtRatePlan

	/*	public int RatePlanLog (RbtRatePlan oldObj,RbtRatePlan newObj,int pid)
	{
		logger.info("webadmin: addRbtRatePlan");
		long pln_id=0;
		try
		{
			con = conPool.getConnection();
			query = "INSERT INTO WEB_ADMIN_LOGS (USE_TABLE, TABLE_FIELD, CURRENT_VALUE, PREVIOUS_VALUE, LINK_LOGS, UPDATED_BY, UPDATED_DATE, INDICATOR_VALUE) VALUES ('VCC_RATE_PLAN',?,?,?,'Rate_Plan_Modify',?,sysdate,?)";
			pstmt = con.prepareStatement (query);

			pstmt.setLong (1, pln_id);
			pstmt.setString (2, rbtObj.getRbtChgCode());
			pstmt.setString (3, rbtObj.getRbtGiftChgCode());
			//pstmt.setString (4, rbtObj.getRbtMonoChgCode());
		//	pstmt.setString (5, rbtObj.getRbtNoChgCode());
			pstmt.setString (4, rbtObj.getRbtNormalChgCode());
			pstmt.setString (5, rbtObj.getSubChgCode());
		//	pstmt.setString (8, rbtObj.getRbtRecChgCode());
			pstmt.setString (6, rbtObj.getRemarks());
			pstmt.setString (7, rbtObj.getMRentCode());
			pstmt.setString (8, rbtObj.getThreeWeek());
			pstmt.setString (9, rbtObj.getTwoWeek());
			pstmt.setString (10, rbtObj.getOneWeek());

			pstmt.executeUpdate ();
		logger.info("webadmin: query execute");
			pstmt.close ();
		}//try
		catch (Exception e)
		{
			try
			{
				if(pstmt != null) pstmt.close ();
				if(rs != null) rs.close ();
			}catch(SQLException sqle)
			{
				logger.info ("webadmin-addChargingCode: Exception is: " + sqle.getMessage ());
			}

			e.printStackTrace ();
			return -1;
		}
		finally  { conPool.free(con); } 
		return 0; //  added susccessfully
	//	return 2; //  added susccessfully

	}// addChargingCode()

	 */
	/*
	public int updateChargingCode (ChargingCode ocobj, long chgCode)
	{
					logger.info("in function updateChargingCode() "+chgCode);

					try
					{
									con = conPool.getConnection();

									query = "UPDATE CRBT_CHARGING_CODE SET AMOUNT_PRE=?,AMOUNT_POST=? where Charging_Code=?";
									pstmt = con.prepareStatement (query);

									pstmt.setDouble (1, ocobj.getAmountP ());
									pstmt.setDouble (2, ocobj.getAmountO ());
									pstmt.setLong (3, chgCode);

									pstmt.executeUpdate ();
									pstmt.close ();
					}//try
					catch (Exception e)
					{
									try
									{
													if(pstmt != null) pstmt.close ();
													if(rs != null) rs.close ();
									}catch(SQLException sqle)
									{
													logger.info ("Exception in updateChargingCode: " + sqle.getMessage ());
									}
									e.printStackTrace ();
									return -1;
					}
					finally{conPool.free(con); }
					return 1;
	} // updateChargingCode

	public int deleteChargingCode (String[] codes)
	{
					logger.info("deleteChargingCode()");
					try
					{
									con = conPool.getConnection();
									query = "delete from CRBT_CHARGING_CODE WHERE CHARGING_CODE=?";
									pstmt = con.prepareStatement(query);
									for(int i=0; i<codes.length; i++)
									{
													pstmt.setLong (1,Long.parseLong(codes[i]));
													pstmt.executeUpdate();
									}
									pstmt.close();
					}//try
					catch (Exception e)
					{
									try
									{
													if(pstmt != null) pstmt.close ();
									}catch(SQLException sqle)
									{
													logger.info ("Exception in deleteChargingCode: " + sqle.getMessage ());
									}
									e.printStackTrace ();
									return -1;
					}
					finally{ conPool.free(con);  }
					return 1;
	}//deleteChargingCode

	public int getTableCol (ArrayList colAl)
	{
		logger.info("getTableCol() ");
		try
		{
			con = conPool.getConnection();
			query = "SELECT column_name FROM USER_TAB_COLS WHERE TABLE_NAME ='VCC_RATE_PLAN'";
			pstmt = con.prepareStatement (query);
			rs = pstmt.executeQuery ();
			while(rs.next ())
			{
				ChargingCode chgOb = new ChargingCode ();
				chgOb.setColName (rs.getString ("column_name"));
				colAl.add (chgOb);
			}
			rs.close ();
			pstmt.close ();
		} //try
		catch (Exception e)
		{
			try
			{
				if(rs != null) rs.close ();
				if(pstmt != null) pstmt.close ();
			}catch(SQLException sqle)
			{
				logger.info ("Exception in getTableCol: " + sqle.getMessage ());
			}
			e.printStackTrace ();
			return -1;
		}
		finally{ conPool.free(con); }
		return 1;
	}*///getTableCol

	/*
	public int defineChargingRule (ChargingCode chgObj)
	{
		logger.info("webadmin: defineChargingRule");
		int plan_id=0;
		try
		{
			con = conPool.getConnection();
			query="select chg_plan_id.nextval from dual";
			pstmt=con.prepareStatement(query);
			rs = pstmt.executeQuery();
			if(rs.next())
			{
				plan_id = rs.getInt(1);
			}
			rs.close ();
			pstmt.close ();
			pstmt.setString (3, chgObj.getRbtChgCode());
			pstmt.setString (4, chgObj.getRbtGiftChgCode ());
			pstmt.setString (5, chgObj.getRbtMonoChgCode ());
			pstmt.setString (6, chgObj.getRbtNoChgCode());
			pstmt.setString (7, chgObj.getRbtNormalChgCode ());
			pstmt.setString (8, chgObj.getSubChgCode ());
			pstmt.setString (9, chgObj.getRbtRecChgCode ());
			pstmt.setInt (10, chgObj.getValidity());
			pstmt.setString (11, chgObj.getRemarks());
			pstmt.setString (12, "S");
			pstmt.setString (13, "U");
			pstmt.setString (14, "cdr");

			pstmt.executeUpdate ();
			pstmt.close ();
		}//try
		catch (Exception e)
		{
			try
			{
				if(pstmt != null) pstmt.close ();
				if(rs != null) rs.close ();
			}catch(SQLException sqle)
			{
				logger.info ("webadmin/defineChargingRule, Exception is: " + sqle.getMessage ());
			}

			e.printStackTrace ();
			return -1;
		}
		finally  { conPool.free(con); } 
		return 1; //  added susccessfully

	}// defineChargingRule
	 */
}//class
