/*
 * This class is having all function to generate Reports.
 *
 *
 *
 */
package com.telemune.vcc.webadmin;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import java.text.*;

import com.telemune.dbutilities.*;
import com.telemune.vcc.common.TSSJavaUtil;

import org.apache.log4j.*;

public class ReportUtil
{
         static Logger logger=Logger.getLogger(ReportUtil.class);
	private ResultSet rs = null;
	private ResultSet rs1 = null;
	private Connection con = null;
	private	PreparedStatement pstmt = null;
	private	PreparedStatement pstmt1 = null;

	private String time = "DD-MM-YYYY HH24";
	private String startDate = "";
	private String endDate = "";
	private String query="";

	public void setStartDate(String start)
	{
		startDate = start;
	}
	public void setEndDate(String end)
	{
		endDate = end;
	}

	public int getInvoice(ArrayList statsAl, int reportDay,int country_code)
	{
		String query1="";
		String query2="";
		long total_subs=0;
		long total_active=0;
		logger.info("in getInvoice() ");
		time ="MON-YYYY";
		try
		{
			con =TSSJavaUtil.instance().getconnection();
			if(reportDay ==0)
			{
				logger.info("country_code===  "+country_code+"   start date  "+startDate+" con=="+con);
				if(country_code==-1)
				{
					query = "select COUNTRY_CODE,sum(TOTAL_SUBS) TOTAL_SUBS,sum(ACTIVE_SUBS) ACTIVE_SUBS,sum(NEW_SUBSCRIPTION) NEW_SUBSCRIPTION,sum(SUBSCRIPTION) SUBSCRIPTION,sum(ONE_WEEK_RENT) ONE_WEEK_RENT,sum(TWO_WEEK_RENT) TWO_WEEK_RENT,sum(THREE_WEEK_RENT) THREE_WEEK_RENT,sum(RBT_PURCHASE) RBT_PURCHASE,sum(RBT_GIFT) RBT_GIFT ,sum(NEW_SUBSCRIPTION_AMOUNT) NEW_SUBSCRIPTION_AMOUNT,sum(SUBSCRIPTION_AMOUNT) SUBSCRIPTION_AMOUNT,sum(ONE_WEEK_AMOUNT) ONE_WEEK_AMOUNT,sum(TWO_WEEK_AMOUNT) TWO_WEEK_AMOUNT,sum(THREE_WEEK_AMOUNT) THREE_WEEK_AMOUNT,sum(RBT_PURCHASE_AMOUNT) RBT_PURCHASE_AMOUNT,sum(RBT_GIFT_AMOUNT) RBT_GIFT_AMOUNT ,sum(TOTAL_CALL_PULSE) TOTAL_CALL_PULSE,sum(TOTAL_PULSE_AMOUNT) TOTAL_PULSE_AMOUNT,sum(SMS) SMS,sum(SMS_AMOUNT) SMS_AMOUNT,USD_RATE from DAILY_INVOICE where invoice_date >= to_date( ?, 'DD-MM-YYYY') group by country_code ,usd_rate";
					query1=	"select count(*) from crbt_subscriber_master";
					query2=	"select count(*) from crbt_subscriber_master where status='A'";
				}
				else
				{
					query = "select to_char(invoice_date, '"+time+"') start_date,COUNTRY_CODE,TOTAL_SUBS,ACTIVE_SUBS,NEW_SUBSCRIPTION,SUBSCRIPTION,ONE_WEEK_RENT,TWO_WEEK_RENT,THREE_WEEK_RENT,RBT_PURCHASE,RBT_GIFT,NEW_SUBSCRIPTION_AMOUNT,SUBSCRIPTION_AMOUNT,ONE_WEEK_AMOUNT,TWO_WEEK_AMOUNT,THREE_WEEK_AMOUNT,RBT_PURCHASE_AMOUNT,RBT_GIFT_AMOUNT,TOTAL_CALL_PULSE,TOTAL_PULSE_AMOUNT,SMS,SMS_AMOUNT,USD_RATE from  DAILY_INVOICE where invoice_date >= to_date( ?, 'DD-MM-YYYY') and country_code=? order by invoice_date";
				}

				if(country_code==-1)
				{
					pstmt1 = con.prepareStatement (query1);
					rs1 = pstmt1.executeQuery ();
					if(rs1.next())
					{
						total_subs=rs1.getLong(1);
					}
					rs1.close();
					pstmt1.close();
					pstmt1 = con.prepareStatement (query2);
					rs1 = pstmt1.executeQuery ();
					if(rs1.next())
					{
						total_active=rs1.getLong(1);
					}
					rs1.close();
					pstmt1.close();
				}
				pstmt = con.prepareStatement (query);
				pstmt.setString (1, startDate);
				if(country_code!=-1)
				{
					pstmt.setInt (2, country_code);
				}


				rs = pstmt.executeQuery ();
				while(rs.next())
				{
					Stat stat = new Stat();
					if(country_code!=-1)
					{
						stat.setDate(rs.getString("start_date")); 
					}
					stat.setColumn1(rs.getLong("COUNTRY_CODE"));
					if(country_code==-1)
					{
						stat.setColumn2(total_subs);
						stat.setColumn3(total_active);
					}
					else
					{
						stat.setColumn2(rs.getLong("TOTAL_SUBS"));
						stat.setColumn3(rs.getLong("ACTIVE_SUBS"));
					}
					stat.setColumn4(rs.getLong("NEW_SUBSCRIPTION"));
					stat.setColumn5(rs.getLong("SUBSCRIPTION")); 
					stat.setColumn6(rs.getLong("ONE_WEEK_RENT")); 
					stat.setColumn7(rs.getLong("TWO_WEEK_RENT")); 
					stat.setColumn8(rs.getLong("THREE_WEEK_RENT")); 
					stat.setColumn9(rs.getLong("RBT_PURCHASE")); 
					stat.setColumn10(rs.getLong("RBT_GIFT")); 
					stat.setColumn11(rs.getDouble("NEW_SUBSCRIPTION_AMOUNT")); 
					stat.setColumn12(rs.getDouble("SUBSCRIPTION_AMOUNT")); 
					stat.setColumn13(rs.getDouble("ONE_WEEK_AMOUNT")); 

					stat.setColumn14(rs.getDouble("TWO_WEEK_AMOUNT")); 
					stat.setColumn15(rs.getDouble("THREE_WEEK_AMOUNT")); 

					stat.setColumn16(rs.getDouble("RBT_PURCHASE_AMOUNT")); 
					stat.setColumn17(rs.getDouble("RBT_GIFT_AMOUNT")); 
					stat.setColumn18(rs.getLong("TOTAL_CALL_PULSE")); 
					stat.setColumn19(rs.getDouble("TOTAL_PULSE_AMOUNT")); 
					stat.setColumn20(rs.getLong("SMS")); 
					stat.setColumn21(rs.getDouble("SMS_AMOUNT")); 
					stat.setColumn22(rs.getDouble("USD_RATE")); 
					statsAl.add(stat);
				}

				rs.close();
				pstmt.close();
			}
			else if(reportDay ==1) //archieve report
			{
				logger.info("country_code===  "+country_code+"   start date  "+startDate+" con=="+con);
				if(country_code==-1)
				{
					query = "select to_char(invoice_date, 'dd-mm-yyyy') start_date,COUNTRY_CODE,sum(TOTAL_SUBS) TOTAL_SUBS,sum(ACTIVE_SUBS) ACTIVE_SUBS,sum(NEW_SUBSCRIPTION) NEW_SUBSCRIPTION,sum(SUBSCRIPTION) SUBSCRIPTION,sum(ONE_WEEK_RENT) ONE_WEEK_RENT,sum(TWO_WEEK_RENT) TWO_WEEK_RENT,sum(THREE_WEEK_RENT) THREE_WEEK_RENT,sum(RBT_PURCHASE) RBT_PURCHASE,sum(RBT_GIFT) RBT_GIFT ,sum(NEW_SUBSCRIPTION_AMOUNT) NEW_SUBSCRIPTION_AMOUNT,sum(SUBSCRIPTION_AMOUNT) SUBSCRIPTION_AMOUNT,sum(ONE_WEEK_AMOUNT) ONE_WEEK_AMOUNT,sum(TWO_WEEK_AMOUNT) TWO_WEEK_AMOUNT,sum(THREE_WEEK_AMOUNT) THREE_WEEK_AMOUNT,sum(RBT_PURCHASE_AMOUNT) RBT_PURCHASE_AMOUNT,sum(RBT_GIFT_AMOUNT) RBT_GIFT_AMOUNT ,sum(TOTAL_CALL_PULSE) TOTAL_CALL_PULSE,sum(TOTAL_PULSE_AMOUNT) TOTAL_PULSE_AMOUNT,sum(SMS) SMS,sum(SMS_AMOUNT) SMS_AMOUNT,USD_RATE from MONTHLY_INVOICE where invoice_date = to_date( ?, 'DD-MM-YYYY') group by country_code ,to_char(invoice_date, 'dd-mm-yyyy'),usd_rate";
					//									"select to_char(invoice_date, 'dd-mm-yyyy') start_date,COUNTRY_CODE,sum(TOTAL_SUBS),sum(ACTIVE_SUBS),sum(NEW_SUBSCRIPTION),sum(SUBSCRIPTION),sum(ONE_WEEK_RENT),sum(TWO_WEEK_RENT),sum(THREE_WEEK_RENT),sum(RBT_PURCHASE),sum(RBT_GIFT),sum(NEW_SUBSCRIPTION_AMOUNT),sum(SUBSCRIPTION_AMOUNT),sum(ONE_WEEK_AMOUNT),sum(TWO_WEEK_AMOUNT),sum(THREE_WEEK_AMOUNT),sum(RBT_PURCHASE_AMOUNT),sum(RBT_GIFT_AMOUNT),sum(TOTAL_CALL_PULSE),sum(TOTAL_PULSE_AMOUNT),sum(SMS),sum(SMS_AMOUNT),sum(USD_RATE) from MONTHLY_INVOICE where invoice_date = to_date( ?, 'DD-MM-YYYY') group by country_code ,to_char(invoice_date, 'dd-mm-yyyy')"
				}
				else
				{
					query = "select to_char(invoice_date, '"+time+"') start_date,COUNTRY_CODE,TOTAL_SUBS,ACTIVE_SUBS,NEW_SUBSCRIPTION,SUBSCRIPTION,ONE_WEEK_RENT,TWO_WEEK_RENT,THREE_WEEK_RENT,RBT_PURCHASE,RBT_GIFT,NEW_SUBSCRIPTION_AMOUNT,SUBSCRIPTION_AMOUNT,ONE_WEEK_AMOUNT,TWO_WEEK_AMOUNT,THREE_WEEK_AMOUNT,RBT_PURCHASE_AMOUNT,RBT_GIFT_AMOUNT,TOTAL_CALL_PULSE,TOTAL_PULSE_AMOUNT,SMS,SMS_AMOUNT,USD_RATE from  MONTHLY_INVOICE where invoice_date = to_date( ?, 'DD-MM-YYYY') and country_code=?";
				}
				pstmt = con.prepareStatement (query);
				pstmt.setString (1, startDate);
				if(country_code!=-1)
				{
					pstmt.setInt (2, country_code);
				}

				rs = pstmt.executeQuery ();
				logger.info("country_code===  query executed");
				while(rs.next())
				{
					Stat stat = new Stat();
					stat.setDate(rs.getString("start_date")); 

					stat.setColumn1(rs.getLong("COUNTRY_CODE")); 
					//stat.setColumn2(total_subs);
					//stat.setColumn3(total_active);
					stat.setColumn2(rs.getLong("TOTAL_SUBS")); 
					stat.setColumn3(rs.getLong("ACTIVE_SUBS")); 
					stat.setColumn4(rs.getLong("NEW_SUBSCRIPTION")); 
					stat.setColumn5(rs.getLong("SUBSCRIPTION")); 
					stat.setColumn6(rs.getLong("ONE_WEEK_RENT")); 
					stat.setColumn7(rs.getLong("TWO_WEEK_RENT")); 
					stat.setColumn8(rs.getLong("THREE_WEEK_RENT")); 
					stat.setColumn9(rs.getLong("RBT_PURCHASE")); 
					stat.setColumn10(rs.getLong("RBT_GIFT")); 
					stat.setColumn11(rs.getDouble("NEW_SUBSCRIPTION_AMOUNT")); 
					stat.setColumn12(rs.getDouble("SUBSCRIPTION_AMOUNT")); 
					stat.setColumn13(rs.getDouble("ONE_WEEK_AMOUNT")); 
					stat.setColumn14(rs.getDouble("TWO_WEEK_AMOUNT")); 
					stat.setColumn15(rs.getDouble("THREE_WEEK_AMOUNT")); 
					stat.setColumn16(rs.getDouble("RBT_PURCHASE_AMOUNT")); 
					stat.setColumn17(rs.getDouble("RBT_GIFT_AMOUNT")); 
					stat.setColumn18(rs.getLong("TOTAL_CALL_PULSE")); 
					stat.setColumn19(rs.getDouble("TOTAL_PULSE_AMOUNT")); 
					stat.setColumn20(rs.getLong("SMS")); 
					stat.setColumn21(rs.getDouble("SMS_AMOUNT")); 
					stat.setColumn22(rs.getDouble("USD_RATE")); 
					statsAl.add(stat);
				}
				rs.close();
				pstmt.close();

			} // else if(reportDay)
			return 1;
		}//try
		catch (Exception exp)
		{
			try
			{
				if(rs != null) rs.close ();
				if(pstmt != null) pstmt.close ();
			}catch(SQLException sqle)
			{
			}
			exp.printStackTrace ();
			return -1;
		}
		finally {try {
			if(con!=null)	TSSJavaUtil.instance().freeConnection(con);
		} catch (Exception e) {
			// TODO: handle exception
		} }

	}//getInvoice()


	public int getCPInvoice(Stat stat,ArrayList statsAl, int reportDay)
	{

		logger.info("in getCPInvoice() ");
		time ="MON-YYYY";
		String query,query1,query2;
		try
		{
			con =TSSJavaUtil.instance().getconnection();
			if(reportDay ==0) //current report
			{
				logger.info("in getInvoice() "+ startDate + " to "+endDate);
				ArrayList cpcodelist = new ArrayList();	
				query1 ="select b.name name,a.code code from content_provider_webaccess a,crbt_content_provider b where a.code = b.code";
				PreparedStatement pstmt1 = con.prepareStatement(query1);
				rs = pstmt1.executeQuery();
				while(rs.next())
				{
					Stat statn = new Stat();
					statn.setDate(rs.getString("name"));
					statn.setColumn1(rs.getLong("code"));
					cpcodelist.add(statn);	
				}
				rs.close();
				Iterator ite = cpcodelist.iterator();
				Stat stats = new Stat();
				query2 ="select sum(nm) sum_num from (select a.* from (select count(*) nm , rbt_code from CRBT_PREPAID_SETTING_CDR where to_date(to_char(update_time,'YYYY-MM'),'YYYY-MM')=to_date(to_char(sysdate,'YYYY-MM'),'YYYY-MM') group by rbt_code) a where a.rbt_code in (select rbt_code from crbt_rbt where content_provider_code=?))";
				PreparedStatement pstmt2 = con.prepareStatement(query2);
				while(ite.hasNext())
				{
					stats = (Stat)ite.next();
					pstmt2.setLong(1, stats.getColumn1());
					rs = pstmt2.executeQuery();
					while(rs.next())
					{
						Stat statn = new Stat();
						statn.setDate(stats.getDate());
						statn.setColumn1(stats.getColumn1());
						statn.setColumn2(rs.getLong("sum_num"));
						statsAl.add(statn);	
					}
				}
				rs.close();   
				pstmt1.close();pstmt2.close();


			} //if(reportDay)
			else if(reportDay ==1) //archieve report
			{

				//query = "select to_char(invoice_date, '"+time+"') start_date, SMS, IVR_CALL, SUBSCRIPTION, RBT_SUBSCRIPTION, ACTIVE_SUBS from  MONTHLY_INVOICE where invoice_date = to_date( ?, 'DD-MM-YYYY')";
				query ="select subscriptions ,cp_name,cp_code from cp_monthly_invoice where to_date(to_char(invoice_date,'DD-MM-YYYY'),'DD-MM-YYYY') = to_date(?, 'DD-MM-YYYY')";
				pstmt = con.prepareStatement (query);
				pstmt.setString (1, startDate);

				rs = pstmt.executeQuery ();
				boolean flag1 = true;
				while(rs.next())
				{
					flag1 = false;	
					Stat statn = new Stat();
					statn.setDate(rs.getString("cp_name")); // total SMS
					statn.setColumn1(rs.getLong("cp_code")); // total SMS
					statn.setColumn2(rs.getLong("subscriptions")); // total IVR callsrs
					statsAl.add(statn);
				}
				if (flag1 == true)
				{
					logger.info("Invoice data not found for "+startDate);
					return -9;
				}

				rs.close();
				pstmt.close();



			} // else if(reportDay)
			return 1;
		}//try
		catch (Exception exp)
		{
			try
			{
				if(rs != null) rs.close ();
				if(pstmt != null) pstmt.close ();
			}catch(SQLException sqle)
			{
			}
			exp.printStackTrace ();
			return -1;
		}
		finally {try {
			if(con!=null)	TSSJavaUtil.instance().freeConnection(con);
		} catch (Exception e) {
			// TODO: handle exception
		}  }

	}//getCPInvoice()
	public void hourTimeList(ArrayList arrList)
	{
		logger.info("In hour time list");
		Calendar calendar = new GregorianCalendar();
		Date startTime = new Date();
		calendar.setTime(startTime);
		int year = calendar.get(Calendar.YEAR);
		int month = calendar.get(Calendar.MONTH);
		int day = calendar.get(Calendar.DATE);
		int hour = calendar.get(Calendar.HOUR_OF_DAY);
		DateStruct stDate = new DateStruct();
		stDate.DateStruct(day,month,year,0,0);
		DateStruct etDate = new DateStruct();
		etDate.DateStruct(day,month,year,hour,59);
		GregorianCalendar gc = new GregorianCalendar (stDate.yy,stDate.mm,stDate.dd,stDate.hh,stDate.mi);
		GregorianCalendar gce = new GregorianCalendar (etDate.yy,etDate.mm,etDate.dd,etDate.hh,etDate.mi);
		while(true)
		{
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH");
			String dateString = formatter.format(gc.getTime());
			arrList.add(dateString);
			gc.add(Calendar.HOUR,1);
			if(gc.after(gce))
			{
				break;
			}
		}
	}//hourTimeList()
	
	

} //class ReportUtil
