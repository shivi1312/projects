//package com.telemune.crbtcallcenter.webif;
package com.telemune.vcc.webadmin;
import com.telemune.dbutilities.*;
import com.telemune.vcc.common.*;

import java.sql.ResultSet;
import java.util.*;

import org.apache.log4j.*;
public class RequestNewCrbt
{
     static Logger logger=Logger.getLogger(RequestNewCrbt.class);
    private Connection con = null;
    private PreparedStatement pstmt = null;
    private ResultSet rs = null;
    private String query=null;
 private String msisdn="";
    private String rbt="";
    private String rbtart="";
    private String rbtalb="";
    private String reqdate="";



    
    public Connection getConnection()
    {
        return con;
    }

    public void setConnection(Connection con)
    {
        this.con = con;
    }

 public void setMsisdn(String msisdn)
    {
        this.msisdn=msisdn;
    }
    public void setRbtName(String rbt)
    {
        this.rbt=rbt;
    }
    public void setRbtArt(String rbtart)
    {
        this.rbtart=rbtart;
    }
    public void setRbtAlb(String rbtalb)
    {
        this.rbtalb=rbtalb;
    }
    public void setReqdate(String reqdate)
    {
        this.reqdate=reqdate;
    }

    public String getMsisdn()
    {
       return this.msisdn;
    }
    public String getRbtName()
    {
       return this.rbt;
    }
    public String getRbtArt()
    {
       return this.rbtart;
    }
    public String getRbtAlb()
    {
       return this.rbtalb;
    }
    public String getReqdate()
    {
       return this.reqdate;
    }



    public int addRequest(String Msisdn,String rbt_name,String rbt_artist,String rbt_album)
    {
        long reqid=0;
        String msisdn= TSSJavaUtil.instance().getInternationalNumber(Msisdn);
        con = TSSJavaUtil.instance().getconnection();
        if (con == null)
        {
            logger.info("CON NULL");
            return 0;
        }
        try
        {
            query = "select REQUEST_CRBT_SEQ.nextval from dual";
            pstmt = con.prepareStatement(query);
            rs = pstmt.executeQuery();
            if (rs.next())
            {
                reqid = rs.getLong("NEXTVAL");
            }
            rs.close();
            pstmt.close();

           query = "insert into REQUEST_NEW_CRBT (MSISDN, REQ_ID, RBT_NAME, RBT_ARTIST, RBT_ALBUM, REQ_DATE) values (?, ?, ?, ?, ?, sysdate)";
            pstmt = con.prepareStatement(query);
            pstmt.setString(1,msisdn);
            pstmt.setLong(2,reqid);
            pstmt.setString(3,rbt_name);
            pstmt.setString(4,rbt_artist);
            pstmt.setString(5,rbt_album);
            pstmt.executeUpdate();

            rs.close();
            pstmt.close();
        }
 catch (Exception e)
        {
        try{
               if(rs !=null) rs.close();
            if(pstmt !=null) pstmt.close();
        }catch(Exception exp){}
            e.printStackTrace();
            return -1;
        }
        finally
        {
            try {
				if(con!=null)	TSSJavaUtil.instance().freeConnection(con);
			} catch (Exception e2) {
				// TODO: handle exception
			}
        }
        return 1;
  }//addRequest

 public int viewRequest(ArrayList viewList, String startDate,String endDate,Connection con)
 {
     //con=conpool.getConnection();
     if (con == null)
     {
         logger.info("CON NULL");
         return 0;
     }
     try
     {

	// query="select MSISDN, REQ_ID, RBT_NAME, RBT_ARTIST, RBT_ALBUM, to_char(REQ_DATE,'DD-MM-YYYY HH24') from Request_New_Crbt where (TRUNC(REQ_DATE)<(TO_DATE(?,'DD-MM-YYYYHH24:MI:SS')) and TRUNC(REQ_DATE)>=(TO_DATE(?,'DD-MM-YYYYHH24:MI:SS')))";
         // query = "select MSISDN, REQ_ID, RBT_NAME, RBT_ARTIST, RBT_ALBUM, REQ_DATE from Request_New_Crbt";

	query="select MSISDN, REQ_ID, RBT_NAME, RBT_ARTIST, RBT_ALBUM, to_char(REQ_DATE,'DD-MM-YYYY HH24') da  from Request_New_Crbt where(TRUNC(REQ_DATE)<=(TO_DATE(?,'DD-MM-YYYY HH24:MI:SS')) and TRUNC(REQ_DATE)>=(TO_DATE(?,'DD-MM-YYYY HH24:MI:SS')))";
         pstmt = con.prepareStatement(query);

	pstmt.setString(1,endDate);
	pstmt.setString(2,startDate);

         rs = pstmt.executeQuery();
         while(rs.next())
         {
        	 RequestNewCrbt rnc = new RequestNewCrbt();
              rnc.setMsisdn(rs.getString("MSISDN"));
              rnc.setRbtName(rs.getString("RBT_NAME"));
              rnc.setRbtArt(rs.getString("RBT_ARTIST"));
              rnc.setRbtAlb(rs.getString("RBT_ALBUM"));
              rnc.setReqdate(rs.getString("da"));
              viewList.add(rnc);
         }
         rs.close();
         pstmt.close();
     }
     catch (Exception e)
     {
         e.printStackTrace();
         return -1;
     }
    /* finally
     {
         conpool.free(con);
     }*/
     return 1;
 }//viewRequest
 

}//class

