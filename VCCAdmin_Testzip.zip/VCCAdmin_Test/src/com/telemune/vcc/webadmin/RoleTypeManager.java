/*
 * To get param values.
 *
 *
// modified on Jan 11, 2006
// @ Jatinder Pal
 *
 */

package com.telemune.vcc.webadmin;

import com.telemune.dbutilities.Connection;
import com.telemune.dbutilities.PreparedStatement;
import com.telemune.vcc.common.TSSJavaUtil;
import com.telemune.vcc.webadmin.RoleType;
import com.telemune.vcc.webadmin.RoleTypeManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import org.apache.log4j.Logger;

public class RoleTypeManager {
  static Logger logger = Logger.getLogger(RoleTypeManager.class);
  
  private PreparedStatement pstmt = null;
  
  private Connection con = null;
  
  private ResultSet rs = null;
  
  private String query = null;
  
  public int addRoleData(RoleType roleType, HashSet<Integer> linkId, Connection con) {
    logger.info("in function addRoleData of RoleTypeManager");
    try {
      this.query = "select ROLE_NAME from ROLES where ROLE_NAME=?";
      this.pstmt = con.prepareStatement(this.query);
      this.pstmt.setString(1, roleType.getRoleName().trim());
      this.rs = this.pstmt.executeQuery();
      if (this.rs.next()) {
        this.rs.close();
        this.pstmt.close();
        return -2;
      } 
      this.rs.close();
      this.pstmt.close();
      this.query = "insert into ROLES (ROLE_NAME,DESCRIPTION) values (?,?)";
      this.pstmt = con.prepareStatement(this.query);
      this.pstmt.setString(1, roleType.getRoleName().trim());
      this.pstmt.setString(2, roleType.getRoleDesc().trim());
      System.out.println("inside addRoledata -->  ,  " + roleType.getRoleName() + "  , " + roleType.getRoleDesc());
      this.pstmt.executeUpdate();
      this.pstmt.close();
      int roleId = -1;
      this.query = "select ROLE_ID from ROLES where ROLE_NAME=?";
      this.pstmt = con.prepareStatement(this.query);
      this.pstmt.setString(1, roleType.getRoleName());
      this.rs = this.pstmt.executeQuery();
      if (this.rs.next())
        roleId = this.rs.getInt("ROLE_ID"); 
      this.pstmt.close();
      this.rs.close();
      System.out.println("size of array is" + linkId.size());
      if (linkId.size() > 0) {
        this.query = "insert into WEB_ACCESS (LINK_ID, ROLE_ID) values (?, ?)";
        this.pstmt = con.prepareStatement(this.query);
        Iterator<Integer> itr = linkId.iterator();
        while (itr.hasNext()) {
          int id = ((Integer)itr.next()).intValue();
          System.out.println(id);
          this.pstmt.setInt(1, id);
          this.pstmt.setInt(2, roleId);
          this.pstmt.addBatch();
        } 
        this.pstmt.executeBatch();
        this.pstmt.close();
      } 
    } catch (Exception e) {
      try {
        if (this.rs != null)
          this.rs.close(); 
        if (this.pstmt != null)
          this.pstmt.close(); 
      } catch (SQLException sqle) {
        logger.error("Exception in addRoleData, Exception is : " + sqle.getMessage());
      } 
      logger.error("Exception Received:" + e);
      e.printStackTrace();
      return -99;
    } 
    return 99;
  }
  
  public int getRoleTypes(ArrayList<RoleType> roleTypeAl, Connection con) {
    logger.info("in function getRoleTypes");
    try {
      this.query = "select ROLE_ID,ROLE_NAME,DESCRIPTION  from ROLES";
      this.pstmt = con.prepareStatement(this.query);
      this.rs = this.pstmt.executeQuery();
      while (this.rs.next()) {
        RoleType roleType = new RoleType();
        roleType.setRoleId(this.rs.getInt("ROLE_ID"));
        roleType.setRoleName(this.rs.getString("ROLE_NAME"));
        roleType.setRoleDesc(this.rs.getString("DESCRIPTION"));
        roleTypeAl.add(roleType);
      } 
      this.rs.close();
      this.pstmt.close();
    } catch (Exception e) {
      try {
        if (this.rs != null)
          this.rs.close(); 
        if (this.pstmt != null)
          this.pstmt.close(); 
      } catch (SQLException sqle) {
        logger.error("Exception in getRoleType, Exception is : " + sqle.getMessage());
      } 
      logger.info("Exception Received:" + e);
      return -99;
    } 
    return 99;
  }
  
  public int deleteRoleData(String[] links) {
    logger.info("Here in deleteRoleData of RoleTypeManager");
    System.out.println("Here in deleteRoleData of RoleTypeManager " + links.length);
    try {
      this.con = TSSJavaUtil.instance().getconnection();
      this.query = "select count(*) as total from ADMIN_USER where ROLE_ID = ?";
      this.pstmt = this.con.prepareStatement(this.query);
      int i;
      for (i = 0; i < links.length; i++) {
        System.out.println("links[i]-->  " + links[i]);
        this.pstmt.setInt(1, Integer.parseInt(links[i]));
        this.rs = this.pstmt.executeQuery();
        if (this.rs.next())
          if (this.rs.getInt("total") != 0) {
            this.rs.close();
            this.pstmt.close();
            return -66;
          }  
      } 
      this.rs.close();
      this.pstmt.close();
      this.query = "delete from WEB_ACCESS where ROLE_ID= ?";
      this.pstmt = this.con.prepareStatement(this.query);
      for (i = 0; i < links.length; i++) {
        this.pstmt.setInt(1, Integer.parseInt(links[i]));
        this.pstmt.executeUpdate();
      } 
      this.pstmt.close();
      this.query = "delete from ROLES where ROLE_ID = ?";
      this.pstmt = this.con.prepareStatement(this.query);
      for (i = 0; i < links.length; i++) {
        this.pstmt.setInt(1, Integer.parseInt(links[i]));
        this.pstmt.executeUpdate();
      } 
    } catch (Exception e) {
      try {
        if (this.rs != null)
          this.rs.close(); 
        if (this.pstmt != null)
          this.pstmt.close(); 
      } catch (SQLException sqle) {
        logger.error("Exception in deleteRoleData, Exception is : " + sqle.getMessage());
      } 
      logger.error("Exception Received:" + e);
      e.printStackTrace();
      return -99;
    } finally {
      try {
        if (this.con != null)
          TSSJavaUtil.instance().freeConnection(this.con); 
      } catch (Exception exception) {}
    } 
    try {
      if (this.con != null)
        TSSJavaUtil.instance().freeConnection(this.con); 
    } catch (Exception exception) {}
    return 99;
  }
  
  public int updateRoleData(int roleId, HashSet<Integer> links, Connection con) {
    logger.info("Here in updateRoleData of RoleTypeManager");
    System.out.println("Here in updateRoleData of RoleTypeManager  role id --> " + roleId);
    System.out.println("No of links  : " + links.size());
    try {
      this.query = "delete from WEB_ACCESS where ROLE_ID = ?";
      this.pstmt = con.prepareStatement(this.query);
      this.pstmt.setInt(1, roleId);
      this.pstmt.executeUpdate();
      this.pstmt.close();
      if (links != null) {
        this.query = "insert into WEB_ACCESS (ROLE_ID, LINK_ID) values (?,?)";
        this.pstmt = con.prepareStatement(this.query);
        this.pstmt.setInt(1, roleId);
        Iterator<Integer> itr = links.iterator();
        while (itr.hasNext()) {
          this.pstmt.setInt(2, ((Integer)itr.next()).intValue());
          this.pstmt.executeUpdate();
        } 
      } 
      this.pstmt.close();
    } catch (Exception e) {
      try {
        if (this.pstmt != null)
          this.pstmt.close(); 
      } catch (SQLException sqle) {
        logger.error("Exception in updateRoleData, Exception is : " + sqle.getMessage());
      } 
      logger.info("Exception Received:" + e);
      e.printStackTrace();
      return -99;
    } 
    return 99;
  }
  
  public ArrayList getLinks(int id, Connection con) {
    logger.info("in function getLinks of RoleTypeManager id is :  " + id);
    ArrayList<Integer> ret = new ArrayList();
    try {
      this.query = "select LINK_ID from WEB_ACCESS where ROLE_ID = ?";
      this.pstmt = con.prepareStatement(this.query);
      this.pstmt.setInt(1, id);
      this.rs = this.pstmt.executeQuery();
      while (this.rs.next())
        ret.add(new Integer(this.rs.getInt("LINK_ID"))); 
      this.rs.close();
      this.pstmt.close();
    } catch (Exception e) {
      try {
        if (this.rs != null)
          this.rs.close(); 
        if (this.pstmt != null)
          this.pstmt.close(); 
      } catch (SQLException sqle) {
        logger.error("Exception in getLinks, Exception is : " + sqle.getMessage());
      } 
      logger.error("Exception Received:" + e);
    } 
    return ret;
  }
  
  public int getHttpLinks(ArrayList<RoleType> roleTypeAl, Connection con) {
    logger.info("in function getHttpLinks of RoleTypeManager");
    try {
      this.query = "select LINK_ID, DESCRIPTION  from HTTP_LINKS where LINK_ID>9 AND IS_WORKING='Y' order by LINK_ID";
      this.pstmt = con.prepareStatement(this.query);
      this.rs = this.pstmt.executeQuery();
      while (this.rs.next()) {
        RoleType roleType = new RoleType();
        roleType.setLinkId(this.rs.getInt("LINK_ID"));
        roleType.setLinkDesc(this.rs.getString("DESCRIPTION"));
        roleTypeAl.add(roleType);
      } 
      this.rs.close();
      this.pstmt.close();
    } catch (Exception e) {
      try {
        if (this.rs != null)
          this.rs.close(); 
        if (this.pstmt != null)
          this.pstmt.close(); 
      } catch (SQLException sqle) {
        logger.error("Exception in getHttpLinks, Exception is : " + sqle.getMessage());
      } 
      logger.error("Exception Received:" + e);
      return -99;
    } 
    return 1;
  }
}
