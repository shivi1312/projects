package com.telemune.vcc.webadmin;

public class ScopeBean {
  private String scopeId;
  public ScopeBean(String scopeId, String scopeDesc) {
	super();
	this.scopeId = scopeId;
	this.scopeDesc = scopeDesc;
}
private String scopeDesc;
public String getScopeId() {
	return scopeId;
}
public void setScopeId(String scopeId) {
	this.scopeId = scopeId;
}
public String getScopeDesc() {
	return scopeDesc;
}
public void setScopeDesc(String scopeDesc) {
	this.scopeDesc = scopeDesc;
}
  
}
