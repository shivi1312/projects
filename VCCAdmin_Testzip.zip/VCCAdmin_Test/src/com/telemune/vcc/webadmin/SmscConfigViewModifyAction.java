package com.telemune.vcc.webadmin;

import org.apache.log4j.Logger;

import com.telemune.vcc.common.ValidateAction;

public class SmscConfigViewModifyAction extends ValidateAction{
	
	
	Logger logger=Logger.getLogger(SmscConfigViewModifyAction.class);
	String message;
	
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String onlySuccess()
	{
	
		logger.debug("inside SmscConfigAction class");
		return "success";
	}


}