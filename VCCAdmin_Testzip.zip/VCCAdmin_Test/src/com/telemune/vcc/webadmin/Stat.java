package com.telemune.vcc.webadmin;

public class Stat
{
	private String date;
	private long column1;
	private long column2;
	private long column3;
	private long column4;
	private long column5;
	private long column6;
	private long column7;
	private long column8;
private long column9;
private long column10;
private double column11;
private double  column12;
private double column13;
private double column14;
private double column15;
private double  column16;
private double  column17;
private long column18;
private double column19;
private long column20;
private double column21;
private double  column22;
private long column23;
	 
																	

	public void Stat()
	{
		date = "";
		column1 = 0;
		column2 = 0;
		column3 = 0;
		column4 = 0;
		column5 = 0;
		column6 = 0;
		column7 = 0;
		column8 = 0;
  column9 = 0;
  column10 = 0;
 column11 = 0;
	column12 = 0;
column13 = 0;
column14 = 0;
column15 = 0;
column16 = 0;
column17 = 0;
column18 = 0;
column19 = 0;
column20 = 0;
column21 = 0;
column22 = 0;
column23 = 0;
		}
	
	
	public void setDate (String date)
	{
		this.date = date;
	}
	public void setColumn1(long column1)
	{
		this.column1 = column1;
	}
	public void setColumn2(long column2)
	{
		this.column2 = column2;
	}
	public void setColumn3(long column3)
	{
		this.column3 = column3;
	}
	public void setColumn4(long column4)
	{
		this.column4 = column4;
	}
	public void setColumn5(long column5)
	{
		this.column5 = column5;
	}
	public void setColumn6(long column6)
	{
		this.column6 = column6;
	}
	public void setColumn7(long column7)
	{
		this.column7 = column7;
	
  }
public void setColumn8(long column8)
{
this.column8 = column8;
 }

public void setColumn9(long column9)
 {
this.column9 = column9;
 }

public void setColumn10(long column10)
{
this.column10 = column10;
 }
						
public void setColumn11(double column11)
{
this.column11 = column11;
 }

public void setColumn12(double column12)
 {
this.column12 = column12;
	}

public void setColumn13(double  column13)
{
 this.column13 = column13;
}
									
public void setColumn14(double  column14)
{
				 this.column14 = column14;
}

public void setColumn15(double  column15)
{
				 this.column15 = column15;
}
public void setColumn16(double column16)
{
				 this.column16 = column16;
}

public void setColumn17(double  column17)
{
				 this.column17 = column17;
}

public void setColumn18(long column18)
{
				 this.column18 = column18;
}

public void setColumn19(double  column19)
{
				 this.column19 = column19;
}

public void setColumn20(long column20)
{
				 this.column20 = column20;
}



public void setColumn21(double column21)
{
				     this.column21 = column21;
}


public void setColumn22(double  column22)
{
				 this.column22 = column22;
}

public void setColumn23(long column23)
{
				 this.column23 = column23;
}

		
	public String getDate()
	{
		return date;
	}
	public long getColumn1()
	{
		return column1;
	}
	public long getColumn2()
	{
		return column2;
	}
	public long getColumn3()
	{
		return column3;
	}
	public long getColumn4()
	{
		return column4;
	}
	public long getColumn5()
	{
		return column5;
	}
	public long getColumn6()
	{
		return column6;
	}
	public long getColumn7()
	{
		return column7;
	}
	public long getColumn8()
	{
		return column8;
	}
	
 public long getColumn9()
				 {
									  return column9;
											 }

 public long getColumn10()
				 {
									  return column10;
											 }
 public double getColumn11()
				 {
									  return column11;
											 }
 public double  getColumn12()
				 {
									  return column12;
											 }
 public double getColumn13()
				 {
									  return column13;
											 }
 public double  getColumn14()
				 {
									  return column14;
											 }
 public double  getColumn15()
				 {
									  return column15;
											 }
 public double  getColumn16()
				 {
									  return column16;
											 }
 public  double  getColumn17()
				 {
									  return column17;
											 }
 public long getColumn18()
				 {
									  return column18;
											 }
 public double  getColumn19()
				 {
									  return column19;
											 }
 public long getColumn20()
				 {
									  return column20;
											 }
 public double  getColumn21()
				 {
									  return column21;
											 }
 public double  getColumn22()
				 {
									  return column22;
											 }
 public long getColumn23()
				 {
									  return column23;
											 }

public long  getColumn(int i)
				
	{
		if (i == 1)
		{
			return column1;
		}
		 if (i == 2)
		{
			return column2;
		}
		else if (i == 3)
		{
			return column3;
		}
		else
		{
			return 0;
		}
	}//getColumn


}//Stat
