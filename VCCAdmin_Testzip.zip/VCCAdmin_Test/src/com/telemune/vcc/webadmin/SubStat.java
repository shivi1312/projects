
package com.telemune.vcc.webadmin;

import java.sql.ResultSet;
import java.sql.SQLException;
import com.telemune.dbutilities.*;
import com.telemune.vcc.common.TSSJavaUtil;

import org.apache.log4j.*;
public class SubStat
{
			        static Logger logger=Logger.getLogger(SubStat.class);
				private PreparedStatement pstmt = null;
				private Connection con =null;
				private ResultSet rs =null;
				private String query=null;
				private long subGrpId=0;
				private long adId=0;

				// ******************* Add New SubGroup and Alert Details **********
				// ********* 
				public int getSubStat()
				{
								try
								{
												logger.info("Get Sub Stat");
												con = TSSJavaUtil.instance().getconnection();
												PreparedStatement pstmt = null;
												ResultSet rs = null;
												String key = "";
												try
												{
															 query = "select LICENCE_KEY from CRBT_APP_TEMP_KEY where KEY_ID = 1";
																pstmt = con.prepareStatement(query);
																rs = pstmt.executeQuery();
																while (rs.next())
																{
																				logger.info(rs.getString(1));
																				key = rs.getString(1);
																}
																if(rs != null) rs.close();
																pstmt.close();
												}
												catch (SQLException exp)
												{
																exp.printStackTrace();
												}

												String temp = key.substring(0, 6);

												char tmp[] = temp.toCharArray();

												int n_param = Integer.parseInt(decode(tmp.length, tmp));
												if (n_param <=0 || n_param > key.length()/8)
												{
																return -1;
												}
												int loc = 6;

												for(int i =0; i< n_param; i++)
												{
																temp = key.substring(loc);
																if ((temp == null) || (temp.length() <6))
																{
																				return -1;
																}
																temp = key.substring(loc,loc+6);
																tmp = temp.toCharArray();
																int len = Integer.parseInt(decode(tmp.length, tmp));
																loc = loc+6;
																if (len <=0 || (2*len) > key.substring(loc).length())
																{
																				return -1;
																}
																temp = key.substring(loc, loc+2*len);
																tmp = temp.toCharArray();
																String data = decode(tmp.length, tmp);
																loc = loc+2*len;
																logger.info(data);
																if (i==1)
																{
																				return(Integer.parseInt(data));
																}
												}
								}
												catch (Exception sqle)
												{
																try {
																				if (rs != null) rs.close();
																				if (pstmt != null) pstmt.close();
																} catch (Exception e) {}
																logger.error("Exception in getSubStat",sqle);
																sqle.printStackTrace();
																return 0;
												}
												finally
												{
																try {
																	if(con!=null)	TSSJavaUtil.instance().freeConnection(con);
																} catch (Exception e) {
																	// TODO: handle exception
																}
												}

												return -1;
								}//getMaxSubs

				public static String decode(int len, char data[])
				{
								char l_data[] = new char[(len/2) +1];
								for (int i=0; i<len; i++)
								{
												l_data[i/2] = (char) (data[i] - 0x41);
												l_data[i/2] += (char) (data[++i] - 0x41)<<4;
								}
								String s = new String(l_data);
								return s.trim();
				}
}//class
