/*
 * This class is used for system app config for the admin web interface for CRBT.
 *  @Jatinder Pal
 *
 *
 */
package com.telemune.vcc.webadmin;

import com.telemune.vcc.webadmin.SystemConfig;

public class SystemConfig {
  private int paramId = -1;
  
  private String paramTag = "0";
  
  private String paramValue = "0";
  
  private String remarks = "none";
  
  private String vnShortCode = "0";
  
  private String vmShortcode = "0";
  
  private String vnSmsOrigin = "none";
  
  private String vmSmsOrigin = "none";
  
  private String code = "0";
  
  private int priority = -1;
  
  private String selectpriority = "none";
  
  private String selectShortCode = "none";
  
  private int vmCallPartyEnable = 0;
  
  private int vnCallPartyEnable = 0;
  
  private String owner;
  
  private String update;
  
  private String prevalue;
  
  private String mcaSmsOrigin;
  
  public String getCode() {
    return this.code;
  }
  
  public String getMcaSmsOrigin() {
    return this.mcaSmsOrigin;
  }
  
  public void setMcaSmsOrigin(String mcaSmsOrigin) {
    this.mcaSmsOrigin = mcaSmsOrigin;
  }
  
  public int getVmCallPartyEnable() {
    return this.vmCallPartyEnable;
  }
  
  public void setVmCallPartyEnable(int vmCallPartyEnable) {
    this.vmCallPartyEnable = vmCallPartyEnable;
  }
  
  public int getVnCallPartyEnable() {
    return this.vnCallPartyEnable;
  }
  
  public void setVnCallPartyEnable(int vnCallPartyEnable) {
    this.vnCallPartyEnable = vnCallPartyEnable;
  }
  
  public void setCode(String code) {
    this.code = code;
  }
  
  public String getSelectShortCode() {
    return this.selectShortCode;
  }
  
  public void setSelectShortCode(String selectShortCode) {
    this.selectShortCode = selectShortCode;
  }
  
  public String getSelectpriority() {
    return this.selectpriority;
  }
  
  public void setSelectpriority(String selectpriority) {
    this.selectpriority = selectpriority;
  }
  
  public int getPriority() {
    return this.priority;
  }
  
  public void setPriority(int priority) {
    this.priority = priority;
  }
  
  public String getVmShortcode() {
    return this.vmShortcode;
  }
  
  public void setVmShortcode(String vmShortcode) {
    this.vmShortcode = vmShortcode;
  }
  
  public String getVnShortCode() {
    return this.vnShortCode;
  }
  
  public void setVnShortCode(String vnShortCode) {
    this.vnShortCode = vnShortCode;
  }
  
  public String getVmSmsOrigin() {
    return this.vmSmsOrigin;
  }
  
  public void setVmSmsOrigin(String vmSmsOrigin) {
    this.vmSmsOrigin = vmSmsOrigin;
  }
  
  public String getVnSmsOrigin() {
    return this.vnSmsOrigin;
  }
  
  public void setVnSmsOrigin(String vnSmsOrigin) {
    this.vnSmsOrigin = vnSmsOrigin;
  }
  
  public void setParamId(int paramId) {
    this.paramId = paramId;
  }
  
  public void setParamTag(String paramTag) {
    this.paramTag = paramTag;
  }
  
  public void setParamValue(String paramValue) {
    this.paramValue = paramValue;
  }
  
  public void setRemarks(String remarks) {
    this.remarks = remarks;
  }
  
  public void setOwner(String owner) {
    this.owner = owner;
  }
  
  public void setPrevalue(String prevalue) {
    this.prevalue = prevalue;
  }
  
  public void setUpDated(String update) {
    this.update = update;
  }
  
  public int getParamId() {
    return this.paramId;
  }
  
  public String getParamTag() {
    return this.paramTag;
  }
  
  public String getParamValue() {
    return this.paramValue;
  }
  
  public String getRemarks() {
    return this.remarks;
  }
  
  public String getOwner() {
    return this.owner;
  }
  
  public String getPrevalue() {
    return this.prevalue;
  }
  
  public String getUpDated() {
    return this.update;
  }
}
