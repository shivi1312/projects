package com.telemune.vcc.webadmin;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import org.apache.log4j.Logger;

import com.telemune.dbutilities.Connection;
import com.telemune.dbutilities.PreparedStatement;
import com.telemune.vcc.common.TSSJavaUtil;

public class SystemConfigManager {
	static Logger logger = Logger.getLogger(SystemConfigManager.class);
	private PreparedStatement pstmt = null;
	private Connection con = null;
	private ResultSet rs = null;
	private String query = null;

	public int getSystemConfig(ArrayList systemConfigAl, Connection con) {
		logger.info("in function getSystemConfig");
		String p_type = "BOOL";
		try {
			// con = conPool.getConnection();
			query = "SELECT PARAM_NAME,PARAM_TYPE, PARAM_VALUE, REMARKS,OWNER FROM APP_CONFIG_PARAMS WHERE OWNER='OPERATOR'";
			pstmt = con.prepareStatement(query);
			systemConfigAl.clear();
			rs = pstmt.executeQuery();
			while (rs.next()) {
				SystemConfig systemConfig = new SystemConfig();
				systemConfig.setParamTag(rs.getString(1));
				if (p_type.equals(rs.getString(2))) {
					if (rs.getString(3).equals("1"))
						systemConfig.setParamValue("YES");
					else
						systemConfig.setParamValue("NO");

				} else
					systemConfig.setParamValue(rs.getString(3));
				systemConfig.setRemarks(rs.getString(4));
				systemConfigAl.add(systemConfig);
			}
			rs.close();
			pstmt.close();
		} catch (Exception e) {
			try {
				if (pstmt != null)
					pstmt.close();
			} catch (SQLException sqle) {
				logger.error("Exception in listSystemConfig, Exception is : "
						+ sqle.getMessage());
			}
			e.printStackTrace();
			return -1;
		}
		/*
		 * finally { conPool.free(con); }
		 */
		return 0;
	}// getSystemConfig

	public int updateSystemConfig(SystemConfig systemConfig, Connection con) {
		System.out.println("in function updateSystemConfig : "
				+ systemConfig.getParamTag() + ":"
				+ systemConfig.getParamValue() + ":"
				+ systemConfig.getRemarks());
		logger.info("in function updateSystemConfig");
		try {
			// con = conPool.getConnection();
			query = "UPDATE APP_CONFIG_PARAMS SET PARAM_VALUE=?, REMARKS=? WHERE PARAM_NAME=?";
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, systemConfig.getParamValue());
			pstmt.setString(2, systemConfig.getRemarks());
			pstmt.setString(3, systemConfig.getParamTag());
			pstmt.executeUpdate();
			pstmt.close();
		} catch (Exception e) {
			try {
				if (pstmt != null)
					pstmt.close();
			} catch (SQLException sqle) {
				logger.error("Exception in updateSystemConfig, Exception is : "
						+ sqle.getMessage());
			}
			e.printStackTrace();
			return -1;
		}
		/*
		 * finally { conPool.free(con); }
		 */
		return 0;

	}// updateSystemConfigParam

	public int getSystemConfigParamValue(ArrayList systemConfigAl,
			String param, Connection con) {
		int i = 0;
		logger.info("in function getSystemConfigParamValue");
		if (param.equals("DEFAULT_RATE_PLAN")) {
			try {
				// con = conPool.getConnection();
				query = "SELECT PLAN_INDICATOR FROM CRBT_RATE_PLANS";
				pstmt = con.prepareStatement(query);
				// pstmt.setString (1,param);
				systemConfigAl.clear();
				rs = pstmt.executeQuery();
				while (rs.next()) {
					SystemConfig systemConfig = new SystemConfig();
					systemConfig.setParamValue(rs.getString(1));
					systemConfigAl.add(systemConfig);
				}
				rs.close();
				pstmt.close();
			} catch (Exception e) {
				try {
					if (pstmt != null)
						pstmt.close();
				} catch (SQLException sqle) {
					logger.error("Exception in listSystemConfig, Exception is : "
							+ sqle.getMessage());
				}
				e.printStackTrace();
				return -1;
			}
			/*
			 * finally { conPool.free(con); }
			 */
			return 0;
		} else {
			i = 0;
			String zero = "0";
			try {
				con = TSSJavaUtil.instance().getconnection();
				query = "SELECT PARAM_VALUE FROM APP_CONFIG_PARAMS WHERE PARAM_NAME='IVR_LANGUAGE_1'";
				pstmt = con.prepareStatement(query);
				systemConfigAl.clear();
				rs = pstmt.executeQuery();
				while (rs.next()) {
					if (!(zero.equals(rs.getString(1)))) {
						i = i + 1;
						SystemConfig systemConfig = new SystemConfig();
						systemConfig.setParamValue(rs.getString(1));
						systemConfig.setParamTag("1");
						systemConfigAl.add(systemConfig);
					}
				}
				rs.close();
				pstmt.close();
				query = "SELECT PARAM_VALUE FROM APP_CONFIG_PARAMS WHERE PARAM_NAME='IVR_LANGUAGE_2'";
				pstmt = con.prepareStatement(query);
				rs = pstmt.executeQuery();
				while (rs.next()) {
					if (!(zero.equals(rs.getString(1)))) {
						i = i + 1;
						SystemConfig systemConfig = new SystemConfig();
						systemConfig.setParamValue(rs.getString(1));
						systemConfig.setParamTag("2");
						systemConfigAl.add(systemConfig);
					}
				}
				rs.close();
				pstmt.close();
				query = "SELECT PARAM_VALUE FROM APP_CONFIG_PARAMS WHERE PARAM_NAME='IVR_LANGUAGE_3'";
				pstmt = con.prepareStatement(query);
				rs = pstmt.executeQuery();
				while (rs.next()) {
					if (!(zero.equals(rs.getString(1)))) {
						i++;
						SystemConfig systemConfig = new SystemConfig();
						systemConfig.setParamValue(rs.getString(1));
						systemConfig.setParamTag("3");
						systemConfigAl.add(systemConfig);
					}
				}
				rs.close();
				pstmt.close();

			} catch (Exception e) {
				try {
					if (pstmt != null)
						pstmt.close();
				} catch (SQLException sqle) {
					logger.error("Exception in listSystemConfig, Exception is : "
							+ sqle.getMessage());
				}
				e.printStackTrace();
				return -1;
			}
			/*
			 * finally { conPool.free(con); }
			 */
			return i;

		}
	}// getSystemConfigParamValue

	public int updateSystemConfiglogs(SystemConfig systemConfig,
			String user_name, String old_value) {
		logger.info("in function updateSystemConfiglogs");
		try {
			con = TSSJavaUtil.instance().getconnection();
			query = "INSERT INTO SYSTEM_CONFIG_CHANGE_LOG (PARAM_NAME,CURRENT_VALUE,PREVIOUS_VALUE,UPDATED_BY,UPDATED_DATE) VALUES (?,?,?,?,SYSDATE)";
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, systemConfig.getParamTag().trim());
			pstmt.setString(2, systemConfig.getParamValue().trim());
			pstmt.setString(3, old_value.trim());
			pstmt.setString(4, user_name.trim());
			pstmt.executeUpdate();
			pstmt.close();
		} catch (Exception e) {
			try {
				if (pstmt != null)
					pstmt.close();
			} catch (SQLException sqle) {
				logger.error("Exception in updateSystemConfig, Exception is : "
						+ sqle.getMessage());
			}
			e.printStackTrace();
			return -1;
		} finally {
			try {
				if (con != null)
					TSSJavaUtil.instance().freeConnection(con);
			} catch (Exception e2) {
				// TODO: handle exception
			}
		}
		return 0;

	}// updateSystemConfigParam

	public int getSystemConfiglog(ArrayList systemConfigAl, String sdate,
			String edate, String page) {
		logger.info("in function getSystemConfig start date = " + sdate
				+ "end date = " + edate);
		int count = 0;
		int pageno = Integer.parseInt(page);
		pageno = pageno * 5;
		int pagend = pageno + 5;
		try {
			con = TSSJavaUtil.instance().getconnection();

			if (sdate.equalsIgnoreCase("1") || edate.equalsIgnoreCase("1")) {
				logger.info("start date and end date === 1");
				query = "SELECT count(PARAM_NAME) FROM SYSTEM_CONFIG_CHANGE_LOG ";
				pstmt = con.prepareStatement(query);
				rs = pstmt.executeQuery();
				if (rs.next()) {
					count = rs.getInt(1);
				}
				if (count > pageno)
					query = "SELECT PARAM_NAME, CURRENT_VALUE,PREVIOUS_VALUE,UPDATED_BY,UPDATED_DATE FROM (select PARAM_NAME, CURRENT_VALUE,PREVIOUS_VALUE,UPDATED_BY,UPDATED_DATE ,ROWNUM rm FROM SYSTEM_CONFIG_CHANGE_LOG ORDER BY UPDATED_DATE) where rm>="
							+ pageno + " and rm < " + pagend;
				pstmt = con.prepareStatement(query);
			} else {
				query = "SELECT count(PARAM_NAME) FROM SYSTEM_CONFIG_CHANGE_LOG where UPDATED_DATE >= ? AND UPDATED_DATE <= ?";
				pstmt = con.prepareStatement(query);
				pstmt.setString(1, sdate);
				pstmt.setString(2, edate);
				rs = pstmt.executeQuery();
				if (rs.next()) {
					count = rs.getInt(1);
				}
				logger.info("count== " + count + "pageno== " + pageno
						+ "pagend==" + pagend);
				if (count > pageno)
					query = "SELECT PARAM_NAME, CURRENT_VALUE,PREVIOUS_VALUE,UPDATED_BY,UPDATED_DATE FROM (select PARAM_NAME,CURRENT_VALUE,PREVIOUS_VALUE,UPDATED_BY,UPDATED_DATE ,ROWNUM rm FROM SYSTEM_CONFIG_CHANGE_LOG where UPDATED_DATE >=? AND UPDATED_DATE <=? ORDER BY UPDATED_DATE) where rm>="
							+ pageno + " and rm < " + pagend;
				pstmt = con.prepareStatement(query);
				pstmt.setString(1, sdate);
				pstmt.setString(2, edate);

			}

			systemConfigAl.clear();
			rs = pstmt.executeQuery();
			while (rs.next()) {
				SystemConfig systemConfig = new SystemConfig();
				systemConfig.setParamTag(rs.getString(1));
				systemConfig.setParamValue(rs.getString(2));
				systemConfig.setPrevalue(rs.getString(3));
				systemConfig.setOwner(rs.getString(4));
				systemConfig.setUpDated(rs.getString(5));
				systemConfigAl.add(systemConfig);
			}
			rs.close();
			pstmt.close();
		} catch (Exception e) {
			try {
				if (pstmt != null)
					pstmt.close();
			} catch (SQLException sqle) {
				logger.error("Exception in listSystemConfig, Exception is : "
						+ sqle.getMessage());
			}
			e.printStackTrace();
			return -1;
		} finally {
			try {
				if (con != null)
					TSSJavaUtil.instance().freeConnection(con);
			} catch (Exception e2) {
				// TODO: handle exception
			}
		}
		int temp = count % 5;
		if (temp == 0)
			temp = count / 5;
		else
			temp = (count / 5) + 1;
		logger.info("page no==" + temp);
		return temp;
	}// getSystemConfiglog

	public String IVR_Language(String param) {
		String language = "";
		String zero = "0";
		try {
			con = TSSJavaUtil.instance().getconnection();
			if (param.equals("1")) {
				query = "SELECT PARAM_VALUE FROM APP_CONFIG_PARAMS WHERE PARAM_NAME='IVR_LANGUAGE_1'";
				pstmt = con.prepareStatement(query);
				rs = pstmt.executeQuery();
				while (rs.next()) {
					if (!(zero.equals(rs.getString(1)))) {
						language = rs.getString(1);
					}
				}
				rs.close();
				pstmt.close();
				// conPool.free(con);
				// return language;
			}
			if (param.equals("2")) {
				query = "SELECT PARAM_VALUE FROM APP_CONFIG_PARAMS WHERE PARAM_NAME='IVR_LANGUAGE_2'";
				pstmt = con.prepareStatement(query);
				rs = pstmt.executeQuery();
				while (rs.next()) {
					if (!(zero.equals(rs.getString(1)))) {
						language = rs.getString(1);
					}
				}
				rs.close();
				pstmt.close();
				// conPool.free(con);
				// return language;
			}
			if (param.equals("3")) {
				query = "SELECT PARAM_VALUE FROM APP_CONFIG_PARAMS WHERE PARAM_NAME='IVR_LANGUAGE_3'";
				pstmt = con.prepareStatement(query);
				rs = pstmt.executeQuery();
				while (rs.next()) {
					if (!(zero.equals(rs.getString(1)))) {
						language = rs.getString(1);
					}
				}
				rs.close();
				pstmt.close();
				// conPool.free(con);
			}

		} catch (Exception e) {
			try {
				if (pstmt != null)
					pstmt.close();
			} catch (SQLException sqle) {
				logger.error("Exception in listSystemConfig, Exception is : "
						+ sqle.getMessage());
			}
			e.printStackTrace();
		} finally {
			try {
				if (con != null)
					TSSJavaUtil.instance().freeConnection(con);
			} catch (Exception e2) {
				// TODO: handle exception
			}
		}
		return language;

	}// IVR_Language

	// public int updateParam(SystemConfig systemConfig)
	public int updateParam(HashMap<String, String> systemConfigMap) {
		try {
			Set keys = systemConfigMap.keySet();
			Iterator itr = keys.iterator();
			String key = null;
			String value = null;
			con = TSSJavaUtil.instance().getconnection();
			query = "UPDATE APP_CONFIG_PARAMS SET PARAM_VALUE=? WHERE PARAM_NAME=?";
			pstmt = con.prepareStatement(query);
			logger.info("query is" + query);
			while (itr.hasNext()) {
				key = (String) itr.next();
				value = systemConfigMap.get(key);
				pstmt.setString(2, key);
				pstmt.setString(1, value);
				pstmt.executeUpdate();
			}

			/*
			 * pstmt.setString (1,systemConfig.getParamValue ());
			 * pstmt.setString (2,systemConfig.getParamTag ());
			 * pstmt.executeUpdate ();
			 */
			pstmt.close();
		} catch (Exception e) {
			try {
				if (pstmt != null)
					pstmt.close();
			} catch (SQLException sqle) {
				System.out.println("Exception in updateParam , Exception is : "
						+ sqle.getMessage());
			}
			e.printStackTrace();
			return -1;
		} finally {
			try {
				if (con != null)
					TSSJavaUtil.instance().freeConnection(con);
			} catch (Exception e2) {
				// TODO: handle exception
			}
		}
		return 0;

	}// updateSystemConfigParam

	public String getValueByParamName(String param) {
		String ret = "";
		try {
			con = TSSJavaUtil.instance().getconnection();
			query = "select PARAM_VALUE from APP_CONFIG_PARAMS where PARAM_NAME=?";
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, param);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				ret = rs.getString("PARAM_VALUE");
			} else {
				ret = "EMPTY";
			}
			System.out.println(" param  " + ret);
			rs.close();
			pstmt.close();
		} catch (Exception ee) {

			try {
				if (rs != null || pstmt != null) {
					rs.close();
					pstmt.close();
					TSSJavaUtil.instance().freeConnection(con);
				}
			} catch (Exception e) {

			}
			System.out.println("Exception in fetching app_config_param "
					+ ee.getMessage());
			return "ERROR";

		}

		finally {
			if (con != null)
				TSSJavaUtil.instance().freeConnection(con);
		}
		return ret;

	}

} // class SystemConfigManager
