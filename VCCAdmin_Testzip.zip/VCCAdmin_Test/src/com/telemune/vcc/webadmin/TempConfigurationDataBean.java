package com.telemune.vcc.webadmin;

import java.util.Hashtable;

public class TempConfigurationDataBean {
	private String m_userStatus      ="";
	private String m_defaultTempId   ="";

	private String m_ForSameRbtTempId="";
	private Hashtable<String,String> m_rbtHashTable=null;
	public Hashtable<String,String>  m_CategoryHashTable=null;


	

	public Hashtable<String,String> m_artistHashTable=null;
	public Hashtable<String,String> m_albumHashTable=null;
	

	

	
	
	
	
	

	public String getM_userStatus() {
		return m_userStatus;
	}
	public void setM_userStatus(String m_userStatus) {
		this.m_userStatus = m_userStatus;
	}
	public String getM_defaultTempId() {
		return m_defaultTempId;
	}
	public void setM_defaultTempId(String m_defaultTempId) {
		this.m_defaultTempId = m_defaultTempId;
	}
	public String getM_ForSameRbtTempId() {
		return m_ForSameRbtTempId;
	}
	public void setM_ForSameRbtTempId(String m_ForSameRbtTempId) {
		this.m_ForSameRbtTempId = m_ForSameRbtTempId;
	}

	public Hashtable<String, String> getM_rbtHashTable() {
		return m_rbtHashTable;
	}
	public void setM_rbtHashTable(Hashtable<String, String> m_rbtHashTable) {
		this.m_rbtHashTable = m_rbtHashTable;
	}
	public Hashtable<String, String> getM_CategoryHashTable() {
		return m_CategoryHashTable;
	}
	public void setM_CategoryHashTable(Hashtable<String, String> m_CategoryHashTable) {
		this.m_CategoryHashTable = m_CategoryHashTable;
	}

	public Hashtable<String, String> getM_artistHashTable() {
		return m_artistHashTable;
	}
	public void setM_artistHashTable(Hashtable<String, String> m_artistHashTable) {
		this.m_artistHashTable = m_artistHashTable;
	}
	public Hashtable<String, String> getM_albumHashTable() {
		return m_albumHashTable;
	}
	public void setM_albumHashTable(Hashtable<String, String> m_albumHashTable) {
		this.m_albumHashTable = m_albumHashTable;
	}

	


}
