package com.telemune.vcc.webadmin;

import java.util.List;

public class TemplateConfModifyBean {
	
	private boolean m_category=false;
	private boolean m_artist=false;
	private boolean m_album=false;
	private boolean m_rbtCode=false;
	private boolean m_sameRbt=false;
	
	private String m_dataId=""; //like categoryId RbtCode 
	private List<String> m_templateId=null; //Template Id According to DataId
	public boolean isM_category() {
		return m_category;
	}
	public void setM_category(boolean m_category) {
		this.m_category = m_category;
	}
	public boolean isM_artist() {
		return m_artist;
	}
	public void setM_artist(boolean m_artist) {
		this.m_artist = m_artist;
	}
	public boolean isM_album() {
		return m_album;
	}
	public void setM_album(boolean m_album) {
		this.m_album = m_album;
	}
	public boolean isM_rbtCode() {
		return m_rbtCode;
	}
	public void setM_rbtCode(boolean m_rbtCode) {
		this.m_rbtCode = m_rbtCode;
	}
	public boolean isM_sameRbt() {
		return m_sameRbt;
	}
	public void setM_sameRbt(boolean m_sameRbt) {
		this.m_sameRbt = m_sameRbt;
	}
	public String getM_dataId() {
		return m_dataId;
	}
	public void setM_dataId(String m_dataId) {
		this.m_dataId = m_dataId;
	}
	public List<String> getM_templateId() {
		return m_templateId;
	}
	public void setM_templateId(List<String> m_templateId) {
		this.m_templateId = m_templateId;
	}
	
	
	
	
	
	
	

}
