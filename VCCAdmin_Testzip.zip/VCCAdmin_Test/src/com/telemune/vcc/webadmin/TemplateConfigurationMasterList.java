package com.telemune.vcc.webadmin;

import java.util.ArrayList;

public class TemplateConfigurationMasterList {


	public ArrayList<TempConfigurationDataBean> m_TemplateConf=new ArrayList<TempConfigurationDataBean>();

	public ArrayList<TempConfigurationDataBean> getM_TemplateConf() {
		return m_TemplateConf;
	}

	public void setM_TemplateConf(ArrayList<TempConfigurationDataBean> mTemplateConf) {
		m_TemplateConf = mTemplateConf;
	}




}
