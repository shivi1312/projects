package com.telemune.vcc.webadmin;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.Map;
import org.apache.log4j.Logger;

import com.telemune.dbutilities.Connection;
import com.telemune.dbutilities.PreparedStatement;
import com.telemune.vcc.common.Global;
import com.telemune.vcc.common.TSSJavaUtil;

public class TemplateConfigureManager {
	static Logger logger=Logger.getLogger(TemplateConfigureManager.class);
	private PreparedStatement pstmt = null;
	private Connection con = null;
	private ResultSet rs =null;
	private String query = null;
	private String queryUpdate=null;

	public int loadViralSMSConfig(ArrayList<TempConfigurationDataBean> l_TemplateConf)
	{
		logger.info("In function loadViralSMSConfig");
		int ret = -1;
		TempConfigurationDataBean l_tempDataBean=null;
		Hashtable<String, String> l_rbtHashTable=null;
		Hashtable<String, String> l_categoryHashTable=null;
		Hashtable<String, String> l_artistHashTable=null;
		Hashtable<String, String> l_albumHashTable=null;
		try
		{
			/*TempConfigurationDataBean l_tempDataBean_active=new TempConfigurationDataBean();
			TempConfigurationDataBean l_tempDataBean_nonSub=new TempConfigurationDataBean();*/
			l_tempDataBean=new TempConfigurationDataBean();
			l_rbtHashTable=new Hashtable<String, String>();
			l_categoryHashTable=new Hashtable<String,String>();
			l_artistHashTable=new Hashtable<String,String>();
			l_albumHashTable=new Hashtable<String,String>();

			boolean active=false;
			boolean inactive=false;
			boolean nonsub=false;


			con = TSSJavaUtil.instance().getconnection();
			query="select USER_STATUS,CONTENT_TYPE,CONTENT_ID,TEMPLATE_ID from viral_sms_config_param where status='A' order by USER_STATUS,CONTENT_TYPE";
			pstmt = con.prepareStatement(query,ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_READ_ONLY);
			rs = pstmt.executeQuery();
			while(rs.next())
			{
				if(rs.getString("USER_STATUS").trim().equals("A"))

				{
					active=true;
					if(rs.getInt("CONTENT_TYPE")==Global.RBT_TYPE){
						l_rbtHashTable.put(TSSJavaUtil.instance().getRbtName(rs.getString("CONTENT_ID")),rs.getString("TEMPLATE_ID"));
						//l_rbtHashTable.put(rs.getString("CONTENT_ID"),rs.getString("TEMPLATE_ID"));
					}else if(rs.getInt("CONTENT_TYPE")==Global.CAT_TYPE){
						l_categoryHashTable.put(TSSJavaUtil.instance().getCategoryName(rs.getString("CONTENT_ID")),rs.getString("TEMPLATE_ID"));
						//	l_categoryHashTable.put(rs.getString("CONTENT_ID"),rs.getString("TEMPLATE_ID"));
					}
					else if(rs.getInt("CONTENT_TYPE")==Global.ALBUM_TYPE){
						l_albumHashTable.put(rs.getString("CONTENT_ID"),rs.getString("TEMPLATE_ID"));
					}
					else if(rs.getInt("CONTENT_TYPE")==Global.ARTIST_TYPE){
						l_artistHashTable.put(rs.getString("CONTENT_ID"),rs.getString("TEMPLATE_ID"));
					}else if(rs.getInt("CONTENT_TYPE")==Global.SAME_RBT_TYPE){
						l_tempDataBean.setM_ForSameRbtTempId(rs.getString("TEMPLATE_ID"));
					}
					//Arrays.asList(rs.getString("TEMPLATE_ID").split(","))
				}
			}

			if(active){
				l_tempDataBean.setM_userStatus("ACTIVE");
				l_tempDataBean.setM_rbtHashTable(l_rbtHashTable);
				l_tempDataBean.setM_CategoryHashTable(l_categoryHashTable);
				l_tempDataBean.setM_albumHashTable(l_albumHashTable);
				l_tempDataBean.setM_artistHashTable(l_artistHashTable);
				l_TemplateConf.add(l_tempDataBean);

				logger.info("In function loadViralSMSConfig >> data Added active : ["+l_TemplateConf.size()+"]");
				l_tempDataBean=new TempConfigurationDataBean();
				l_rbtHashTable=new Hashtable<String, String>();
				l_categoryHashTable=new Hashtable<String,String>();
				l_artistHashTable=new Hashtable<String,String>();
				l_albumHashTable=new Hashtable<String,String>();
				active=false;
			}
			rs.first();
			while(rs.next()){
				if(rs.getString("USER_STATUS").trim().equals("I"))
				{
					inactive=true;
					if(rs.getInt("CONTENT_TYPE")==Global.RBT_TYPE){
						l_rbtHashTable.put(TSSJavaUtil.instance().getRbtName(rs.getString("CONTENT_ID")),rs.getString("TEMPLATE_ID"));
						//l_rbtHashTable.put(rs.getString("CONTENT_ID"),rs.getString("TEMPLATE_ID"));
					}else if(rs.getInt("CONTENT_TYPE")==Global.CAT_TYPE){
						l_categoryHashTable.put(TSSJavaUtil.instance().getCategoryName(rs.getString("CONTENT_ID")),rs.getString("TEMPLATE_ID"));
						//l_categoryHashTable.put(rs.getString("CONTENT_ID"),rs.getString("TEMPLATE_ID"));
					}
					else if(rs.getInt("CONTENT_TYPE")==Global.ALBUM_TYPE){
						l_albumHashTable.put(rs.getString("CONTENT_ID"),rs.getString("TEMPLATE_ID"));
					}
					else if(rs.getInt("CONTENT_TYPE")==Global.ARTIST_TYPE){
						l_artistHashTable.put(rs.getString("CONTENT_ID"),rs.getString("TEMPLATE_ID"));
					}else if(rs.getInt("CONTENT_TYPE")==Global.SAME_RBT_TYPE){
						l_tempDataBean.setM_ForSameRbtTempId(rs.getString("TEMPLATE_ID"));
					}
				}
			}
			if(inactive){
				l_tempDataBean.setM_userStatus("INACTIVE");
				l_tempDataBean.setM_rbtHashTable(l_rbtHashTable);
				l_tempDataBean.setM_CategoryHashTable(l_categoryHashTable);
				l_tempDataBean.setM_albumHashTable(l_albumHashTable);
				l_tempDataBean.setM_artistHashTable(l_artistHashTable);
				l_TemplateConf.add(l_tempDataBean);

				logger.info("In function loadViralSMSConfig >> data Added inactive : ["+l_TemplateConf.size()+"]");

				l_tempDataBean=new TempConfigurationDataBean();
				l_rbtHashTable=new Hashtable<String, String>();
				l_categoryHashTable=new Hashtable<String,String>();
				l_artistHashTable=new Hashtable<String,String>();
				l_albumHashTable=new Hashtable<String,String>();

				inactive=false;
			}
			rs.first();
			while(rs.next()){
				if(rs.getString("USER_STATUS").trim().equals("N"))
				{
					nonsub=true;
					if(rs.getInt("CONTENT_TYPE")==Global.RBT_TYPE){
						l_rbtHashTable.put(TSSJavaUtil.instance().getRbtName(rs.getString("CONTENT_ID")),rs.getString("TEMPLATE_ID"));
						//l_rbtHashTable.put(rs.getString("CONTENT_ID"),rs.getString("TEMPLATE_ID"));
					}else if(rs.getInt("CONTENT_TYPE")==Global.CAT_TYPE){
						l_categoryHashTable.put(TSSJavaUtil.instance().getCategoryName(rs.getString("CONTENT_ID")),rs.getString("TEMPLATE_ID"));
						//l_categoryHashTable.put(rs.getString("CONTENT_ID"),rs.getString("TEMPLATE_ID"));
					}
					else if(rs.getInt("CONTENT_TYPE")==Global.ALBUM_TYPE){
						l_albumHashTable.put(rs.getString("CONTENT_ID"),rs.getString("TEMPLATE_ID"));
					}
					else if(rs.getInt("CONTENT_TYPE")==Global.ARTIST_TYPE){
						l_artistHashTable.put(rs.getString("CONTENT_ID"),rs.getString("TEMPLATE_ID"));
					}else if(rs.getInt("CONTENT_TYPE")==Global.SAME_RBT_TYPE){
						l_tempDataBean.setM_ForSameRbtTempId(rs.getString("TEMPLATE_ID"));
					}
				}
			}
			if(nonsub){
				l_tempDataBean.setM_userStatus("NONSUB");
				l_tempDataBean.setM_rbtHashTable(l_rbtHashTable);
				l_tempDataBean.setM_CategoryHashTable(l_categoryHashTable);
				l_tempDataBean.setM_albumHashTable(l_albumHashTable);
				l_tempDataBean.setM_artistHashTable(l_artistHashTable);
				l_TemplateConf.add(l_tempDataBean);
				logger.info("In function loadViralSMSConfig >> data Added nonsub : ["+l_TemplateConf.size()+"]");
				nonsub=false;
			}
			logger.info("In function loadViralSMSConfig l_TemplateConf size () : ["+l_TemplateConf.size()+"]");
			ret=1;
		}
		catch (SQLException sqle)
		{
			sqle.printStackTrace();
			ret= -1;
		}
		catch (Exception exp)
		{
			logger.error("Exception in loadViralSMSConfig()",exp);
			exp.printStackTrace();
			ret= -1;
		}
		finally { try {
			if(con!=null)	TSSJavaUtil.instance().freeConnection(con);
			if(rs!=null)rs.close();
			if(pstmt!=null)pstmt.close();

			l_tempDataBean=null;
			l_rbtHashTable=null;
			l_categoryHashTable=null;
			l_artistHashTable=null;
			l_albumHashTable=null;
		} catch (Exception e) {
			// TODO: handle exception
		}}
		return ret;

	} // loadViralSMSConfig


	String m_userStatus="";

	@SuppressWarnings("unused")
	public int addTemplateConfiguration(TempConfigurationDataBean dataBean)
	{
		int l_result=-1;
		String value=""; String key="";
		Hashtable<String, String> getData=new Hashtable<String, String>();
		this.getAllDataOfTempConf(getData);

		query = "INSERT INTO VIRAL_SMS_CONFIG_PARAM values(?,?,?,?,?)";
		queryUpdate="update VIRAL_SMS_CONFIG_PARAM set TEMPLATE_ID=? where USER_STATUS=? and CONTENT_TYPE=? and CONTENT_ID=?";
		logger.info("query = "+query);
		con=TSSJavaUtil.instance().getconnection();

		try{


			//logger.info("Category HashTable Size ["+dataBean.getM_CategoryHashTable().size()+"]");
			if(dataBean.getM_CategoryHashTable()!=null)
			{
				if(dataBean.getM_CategoryHashTable().size()>0)
				{
					for (Map.Entry<String,String> entry : dataBean.getM_CategoryHashTable().entrySet()) {
						logger.info("Category Key Value Going Inside DB: "+entry.getKey() + " : " + entry.getValue());

						key=dataBean.getM_userStatus()+"_"+Global.CAT_TYPE+"_"+entry.getKey();
						value=getData.get(key);
						if(value!=null)
						{
							pstmt = con.prepareStatement (queryUpdate);
							pstmt.setString(1,value+","+entry.getValue());
							pstmt.setString(2,dataBean.getM_userStatus());
							pstmt.setInt(3,Global.CAT_TYPE);
							pstmt.setString(4,entry.getKey());



						}

						else
						{
							pstmt = con.prepareStatement (query);
							pstmt.setString(1,dataBean.getM_userStatus());

							pstmt.setInt(2,Global.CAT_TYPE);
							pstmt.setString(3,entry.getKey());
							pstmt.setString(4,entry.getValue());
							pstmt.setString(5,"A");

						}
						pstmt.executeUpdate ();
					}}
			}

			if(dataBean.getM_albumHashTable()!=null){
				if(dataBean.getM_albumHashTable().size()>0)
				{

					for (Map.Entry<String,String> entry : dataBean.getM_albumHashTable().entrySet()) {


						key=dataBean.getM_userStatus()+"_"+Global.ALBUM_TYPE+"_"+entry.getKey();
						value=getData.get(key);
						if(value!=null)
						{
							pstmt = con.prepareStatement (queryUpdate);
							pstmt.setString(1,value+","+entry.getValue());
							pstmt.setString(2,dataBean.getM_userStatus());
							pstmt.setInt(3,Global.ALBUM_TYPE);
							pstmt.setString(4,entry.getKey());



						}

						else{

							pstmt.setString(1,dataBean.getM_userStatus());
							pstmt.setInt(2,Global.ALBUM_TYPE);
							pstmt.setString(3,entry.getKey()+"");
							pstmt.setString(4,entry.getValue()+"");
							pstmt.setString(5,"A");
						}

						pstmt.executeUpdate ();
					}}
			}


			if(dataBean.getM_rbtHashTable()!=null)
			{
				if(dataBean.getM_rbtHashTable().size()>0)
				{

					for (Map.Entry<String,String> entry : dataBean.getM_rbtHashTable().entrySet()) {


						key=dataBean.getM_userStatus()+"_"+Global.RBT_TYPE+"_"+entry.getKey();
						value=getData.get(key);
						if(value!=null)
						{
							pstmt = con.prepareStatement (queryUpdate);
							pstmt.setString(1,value+","+entry.getValue());
							pstmt.setString(2,dataBean.getM_userStatus());
							pstmt.setInt(3,Global.RBT_TYPE);
							pstmt.setString(4,entry.getKey());

						}else{
							pstmt.setString(1,dataBean.getM_userStatus());
							pstmt.setInt(2,Global.RBT_TYPE);
							pstmt.setString(3,entry.getKey()+"");
							pstmt.setString(4,entry.getValue()+"");
							pstmt.setString(5,"A");
						}

						pstmt.executeUpdate ();
					}}
			}

			if(dataBean.getM_artistHashTable()!=null)
			{
				if(dataBean.getM_artistHashTable().size()>0)
				{

					for (Map.Entry<String,String> entry : dataBean.getM_artistHashTable().entrySet()) {
						logger.info(entry.getKey() + " : " + entry.getValue());

						key=dataBean.getM_userStatus()+"_"+Global.RBT_TYPE+"_"+entry.getKey();
						value=getData.get(key);
						if(value!=null)
						{
							pstmt = con.prepareStatement (queryUpdate);
							pstmt.setString(1,value+","+entry.getValue());
							pstmt.setString(2,dataBean.getM_userStatus());
							pstmt.setInt(3,Global.ARTIST_TYPE);
							pstmt.setString(4,entry.getKey());

						}else{
							pstmt.setString(1,dataBean.getM_userStatus());
							pstmt.setInt(2,Global.ARTIST_TYPE);
							pstmt.setString(3,entry.getKey()+"");
							pstmt.setString(4,entry.getValue()+"");
							pstmt.setString(5,"A");
						}

						pstmt.executeUpdate ();
					}}

			}
			if(dataBean.getM_ForSameRbtTempId()!=null)
			{
				if(dataBean.getM_ForSameRbtTempId().length()!=0)
				{

					key=dataBean.getM_userStatus()+"_"+Global.SAME_RBT_TYPE+"_0";
					value=getData.get(key);
					if(value!=null)
					{
						pstmt = con.prepareStatement (queryUpdate);
						pstmt.setString(1,value+","+dataBean.getM_ForSameRbtTempId());
						pstmt.setString(2,dataBean.getM_userStatus());
						pstmt.setInt(3,Global.SAME_RBT_TYPE);
						pstmt.setString(4,Global.SAME_RBT_TEMPLATE_ID+"");

					}else{
						pstmt.setString(1,dataBean.getM_userStatus());
						pstmt.setInt(2,Global.SAME_RBT_TYPE);
						pstmt.setString(3,Global.SAME_RBT_TEMPLATE_ID+"");
						pstmt.setString(4,dataBean.getM_ForSameRbtTempId());
						pstmt.setString(5,"A");
					}

					pstmt.executeUpdate ();	
				}
			}


			logger.debug("webadmin: query execute");
			pstmt.close ();
			l_result=1;

		}//try
		catch (Exception e)
		{
			try
			{
				if(pstmt != null) pstmt.close ();
				if(rs != null) rs.close ();
			}catch(SQLException sqle)
			{
				logger.error("webadmin-addChargingCode: Exception is: " + sqle.getMessage ());
			}

			e.printStackTrace ();
			return -1;
		}
		finally  { try {
			if(con!=null)	
			{TSSJavaUtil.instance().freeConnection(con);
			//dataBean=null;
			}
		}
		catch (Exception e2) {
			// TODO: handle exception
		} } 


		return l_result;



	}

	public int getAllDataOfTempConf(Map<String,String> confTempDataTable )
	{
		String tempData="";

		try{
			con = TSSJavaUtil.instance().getconnection();
			query="select USER_STATUS,CONTENT_TYPE,CONTENT_ID,TEMPLATE_ID from viral_sms_config_param where status in('A','I','N') order by USER_STATUS,CONTENT_TYPE";
			pstmt = con.prepareStatement(query,ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_READ_ONLY);
			rs = pstmt.executeQuery();
			while(rs.next())
			{
				tempData=rs.getString("USER_STATUS")+"_"+rs.getString("CONTENT_TYPE")+"_"+rs.getString("CONTENT_ID");
				confTempDataTable.put(tempData,rs.getString("TEMPLATE_ID"));
				logger.info("TempData is: "+tempData +"Template Is: "+rs.getString("TEMPLATE_ID"));
			}
		}
		catch(Exception exp)
		{
			logger.error("Exception Inside getAllDataOfTempConf",exp);
		}
		finally  { try {
			if(con!=null)	
			{TSSJavaUtil.instance().freeConnection(con);
			//dataBean=null;
			}
		}
		catch (Exception e2) {
			// TODO: handle exception
		} } 
		return 1;
	}
	
	
	
	
	
	public int modifyViralSMSConfig(ArrayList<UserStatusBean> l_userStatusList)
	{
		logger.info("In function loadViralSMSConfig");
		int ret = -1;
		UserStatusBean l_uerStatusBean=null;
		TemplateConfModifyBean l_templateModifyBean=null;
		
		ArrayList<TemplateConfModifyBean> l_modifyBeanList=null;
		try
		{
			/*TempConfigurationDataBean l_tempDataBean_active=new TempConfigurationDataBean();
			TempConfigurationDataBean l_tempDataBean_nonSub=new TempConfigurationDataBean();*/
			
			
			//l_userStatusList=new ArrayList<UserStatusBean>();
			
			
			boolean active=false;
			boolean inactive=false;
			boolean nonsub=false;


			con = TSSJavaUtil.instance().getconnection();
			query="select USER_STATUS,CONTENT_TYPE,CONTENT_ID,TEMPLATE_ID from viral_sms_config_param where status='A' order by USER_STATUS,CONTENT_TYPE";
			pstmt = con.prepareStatement(query,ResultSet.TYPE_SCROLL_INSENSITIVE,
					ResultSet.CONCUR_READ_ONLY);
			rs = pstmt.executeQuery();
			l_uerStatusBean=new UserStatusBean();
			l_modifyBeanList=new ArrayList<TemplateConfModifyBean>();
			String[] arr=null;
			while(rs.next())
			{
				
				if(rs.getString("USER_STATUS").trim().equals("A"))

				{
					//l_templateId=new ArrayList<String>();
					active=true;
					if(rs.getInt("CONTENT_TYPE")==Global.CAT_TYPE){
						
						l_templateModifyBean=new TemplateConfModifyBean();
						l_templateModifyBean.setM_category(true);
						l_templateModifyBean.setM_dataId(rs.getString("CONTENT_ID"));
						
						arr=rs.getString("TEMPLATE_ID").split(",");
						l_templateModifyBean.setM_templateId(Arrays.asList(arr));
						
						System.out.println("Inside Active: CategoryId"+rs.getString("CONTENT_ID")+"");
						l_modifyBeanList.add(l_templateModifyBean);
						
						
						
					}/*else if(rs.getInt("CONTENT_TYPE")==Global.CAT_TYPE){
						l_categoryHashTable.put(TSSJavaUtil.instance().getCategoryName(rs.getString("CONTENT_ID")),rs.getString("TEMPLATE_ID"));
						//	l_categoryHashTable.put(rs.getString("CONTENT_ID"),rs.getString("TEMPLATE_ID"));
					}
					else if(rs.getInt("CONTENT_TYPE")==Global.ALBUM_TYPE){
						l_albumHashTable.put(rs.getString("CONTENT_ID"),rs.getString("TEMPLATE_ID"));
					}
					else if(rs.getInt("CONTENT_TYPE")==Global.ARTIST_TYPE){
						l_artistHashTable.put(rs.getString("CONTENT_ID"),rs.getString("TEMPLATE_ID"));
					}else if(rs.getInt("CONTENT_TYPE")==Global.SAME_RBT_TYPE){
						l_tempDataBean.setM_ForSameRbtTempId(rs.getString("TEMPLATE_ID"));
					}*/
					//Arrays.asList(rs.getString("TEMPLATE_ID").split(","))
					
				}
				
				
			}

			if(active){
				l_uerStatusBean.setM_unitBean(l_modifyBeanList);
				l_uerStatusBean.setM_Active(true);
				l_userStatusList.add(l_uerStatusBean);
				/*l_tempDataBean.setM_rbtHashTable(l_rbtHashTable);
				l_tempDataBean.setM_CategoryHashTable(l_categoryHashTable);
				l_tempDataBean.setM_albumHashTable(l_albumHashTable);
				l_tempDataBean.setM_artistHashTable(l_artistHashTable);
				l_TemplateConf.add(l_tempDataBean);

				logger.info("In function loadViralSMSConfig >> data Added active : ["+l_TemplateConf.size()+"]");
				l_tempDataBean=new TempConfigurationDataBean();
				l_rbtHashTable=new Hashtable<String, String>();
				l_categoryHashTable=new Hashtable<String,String>();
				l_artistHashTable=new Hashtable<String,String>();
				l_albumHashTable=new Hashtable<String,String>();*/
				active=false;
			}
			rs.first();
		/*	while(rs.next()){
				if(rs.getString("USER_STATUS").trim().equals("I"))
				{
					inactive=true;
					if(rs.getInt("CONTENT_TYPE")==Global.RBT_TYPE){
						l_rbtHashTable.put(TSSJavaUtil.instance().getRbtName(rs.getString("CONTENT_ID")),rs.getString("TEMPLATE_ID"));
						//l_rbtHashTable.put(rs.getString("CONTENT_ID"),rs.getString("TEMPLATE_ID"));
					}else if(rs.getInt("CONTENT_TYPE")==Global.CAT_TYPE){
						l_categoryHashTable.put(TSSJavaUtil.instance().getCategoryName(rs.getString("CONTENT_ID")),rs.getString("TEMPLATE_ID"));
						//l_categoryHashTable.put(rs.getString("CONTENT_ID"),rs.getString("TEMPLATE_ID"));
					}
					else if(rs.getInt("CONTENT_TYPE")==Global.ALBUM_TYPE){
						l_albumHashTable.put(rs.getString("CONTENT_ID"),rs.getString("TEMPLATE_ID"));
					}
					else if(rs.getInt("CONTENT_TYPE")==Global.ARTIST_TYPE){
						l_artistHashTable.put(rs.getString("CONTENT_ID"),rs.getString("TEMPLATE_ID"));
					}else if(rs.getInt("CONTENT_TYPE")==Global.SAME_RBT_TYPE){
						l_tempDataBean.setM_ForSameRbtTempId(rs.getString("TEMPLATE_ID"));
					}
				}
			}
			if(inactive){
				l_tempDataBean.setM_userStatus("INACTIVE");
				l_tempDataBean.setM_rbtHashTable(l_rbtHashTable);
				l_tempDataBean.setM_CategoryHashTable(l_categoryHashTable);
				l_tempDataBean.setM_albumHashTable(l_albumHashTable);
				l_tempDataBean.setM_artistHashTable(l_artistHashTable);
				l_TemplateConf.add(l_tempDataBean);

				logger.info("In function loadViralSMSConfig >> data Added inactive : ["+l_TemplateConf.size()+"]");

				l_tempDataBean=new TempConfigurationDataBean();
				l_rbtHashTable=new Hashtable<String, String>();
				l_categoryHashTable=new Hashtable<String,String>();
				l_artistHashTable=new Hashtable<String,String>();
				l_albumHashTable=new Hashtable<String,String>();

				inactive=false;
			}
			rs.first();
			while(rs.next()){
				if(rs.getString("USER_STATUS").trim().equals("N"))
				{
					nonsub=true;
					if(rs.getInt("CONTENT_TYPE")==Global.RBT_TYPE){
						l_rbtHashTable.put(TSSJavaUtil.instance().getRbtName(rs.getString("CONTENT_ID")),rs.getString("TEMPLATE_ID"));
						//l_rbtHashTable.put(rs.getString("CONTENT_ID"),rs.getString("TEMPLATE_ID"));
					}else if(rs.getInt("CONTENT_TYPE")==Global.CAT_TYPE){
						l_categoryHashTable.put(TSSJavaUtil.instance().getCategoryName(rs.getString("CONTENT_ID")),rs.getString("TEMPLATE_ID"));
						//l_categoryHashTable.put(rs.getString("CONTENT_ID"),rs.getString("TEMPLATE_ID"));
					}
					else if(rs.getInt("CONTENT_TYPE")==Global.ALBUM_TYPE){
						l_albumHashTable.put(rs.getString("CONTENT_ID"),rs.getString("TEMPLATE_ID"));
					}
					else if(rs.getInt("CONTENT_TYPE")==Global.ARTIST_TYPE){
						l_artistHashTable.put(rs.getString("CONTENT_ID"),rs.getString("TEMPLATE_ID"));
					}else if(rs.getInt("CONTENT_TYPE")==Global.SAME_RBT_TYPE){
						l_tempDataBean.setM_ForSameRbtTempId(rs.getString("TEMPLATE_ID"));
					}
				}
			}
			if(nonsub){
				l_tempDataBean.setM_userStatus("NONSUB");
				l_tempDataBean.setM_rbtHashTable(l_rbtHashTable);
				l_tempDataBean.setM_CategoryHashTable(l_categoryHashTable);
				l_tempDataBean.setM_albumHashTable(l_albumHashTable);
				l_tempDataBean.setM_artistHashTable(l_artistHashTable);
				l_TemplateConf.add(l_tempDataBean);
				logger.info("In function loadViralSMSConfig >> data Added nonsub : ["+l_TemplateConf.size()+"]");
				nonsub=false;
			}*/
			logger.info("In function ModifyViralSms List size is: ["+l_userStatusList.size()+"]");
			ret=1;
		}
		catch (SQLException sqle)
		{
			sqle.printStackTrace();
			ret= -1;
		}
		catch (Exception exp)
		{
			logger.error("Exception in loadViralSMSConfig()",exp);
			exp.printStackTrace();
			ret= -1;
		}
		finally { try {
			if(con!=null)	TSSJavaUtil.instance().freeConnection(con);
			if(rs!=null)rs.close();
			if(pstmt!=null)pstmt.close();

			
		} catch (Exception e) {
			// TODO: handle exception
		}}
		return ret;

	}
	
	
}
