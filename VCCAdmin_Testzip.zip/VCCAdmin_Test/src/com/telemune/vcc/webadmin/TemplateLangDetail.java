

package com.telemune.vcc.webadmin;

public class TemplateLangDetail
{    
	private String langName;
	private int langId;
	private String iFace;//interface
	
	public TemplateLangDetail()
	{
		langName="";
		langId=-1;
		iFace="w";
	}
    
	public TemplateLangDetail(String langName, int langId) {
		super();
		this.langName = langName;
		this.langId = langId;
	}


	public String getLangName() {
		return langName;
	}

	public void setLangName(String langName) {
		this.langName = langName;
	}

	public int getLangId() {
		return langId;
	}

	public void setLangId(int langId) {
		this.langId = langId;
	}

	public String getiFace() {
		return iFace;
	}

	public void setiFace(String iFace) {
		this.iFace = iFace;
	}

	@Override
	public String toString(){
		return "Template Language Details [langId="+langId+", Language Name="+langName+"]";
	}

	 
} //class ends
