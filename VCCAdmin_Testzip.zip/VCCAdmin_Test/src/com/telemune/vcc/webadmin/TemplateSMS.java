/*
 * TemplateSMS.java
 *
 * Created on October 8, 2004, 5:29 PM
 */

package com.telemune.vcc.webadmin;

/**
 *
 * @author  jaipal
 */
public class TemplateSMS implements java.io.Serializable
 {
    
    private long templateId ;
    private String templateDescription = null;
    private String templateType;
    private String templateMessage = null;
    private String tokensAllowed = null;
	private int language;
	
	//added by MoHit for common 21 May 2015
	//private HashMap<String, String> langMap=null;
	
	//added by Pankaj for common 10 June 2015
	private String[] languageMsg;
	private int[] langId;
	
	public String[] getLanguageMsg() {
		return languageMsg;
	}


	public void setLanguageMsg(String[] languageMsg) {
		this.languageMsg = languageMsg;
	}


	public int[] getLangId() {
		return langId;
	}



	public void setLangId(int[] langId) {
		this.langId = langId;
	}





	
    
   /** Creates a new instance of TemplateSMS */
    public TemplateSMS()
		 {
        templateId = 0;
        templateDescription = "";
        templateType ="";
        templateMessage = "";
        tokensAllowed = "";
				language=1;
    }
    
    
    
    public TemplateSMS(long templateId, String templateDescription,
		String templateType, String templateMessage, String tokensAllowed,
		int language) {
	super();
	this.templateId = templateId;
	this.templateDescription = templateDescription;
	this.templateType = templateType;
	this.templateMessage = templateMessage;
	this.tokensAllowed = tokensAllowed;
	this.language = language;
}



	public void setTemplateId(long templateId)
		 {
        this.templateId = templateId;
    }

    
    public void setTemplateDescription(String templateDescription)
		 {
        this.templateDescription = templateDescription;
    }
    
    
    public void setTemplateType(String templateType)
		 {
        this.templateType = templateType;
    }
    
    
    public void setTemplateMessage(String templateMessage)
		 {
        this.templateMessage = templateMessage;
    }
    
    public void setTokensAllowed(String tokensAllowed)
		 {
        this.tokensAllowed = tokensAllowed;
    }
   public void setLanguage(int language)
	 {
					 this.language=language;
	 }
/*   **** get values ******            */
    public long  getTemplateId()
		 {
        return templateId;
    }
    public String getTemplateDescription()
		 {
        return templateDescription;
    }
    public String getTemplateType()
		 {
        return templateType;
    }
    public String getTemplateMessage()
		 {
        return templateMessage;
    }
    public String getTokensAllowed()
		 {
        return tokensAllowed;
    }
	 public int getLanguage()
	 {
					 return language;
	 }

	


	@Override
	public String toString() {
		return "TemplateSMS [templateId=" + templateId
				+ ", templateDescription=" + templateDescription
				+ ", templateType=" + templateType + ", templateMessage="
				+ templateMessage + ", tokensAllowed=" + tokensAllowed
				+ ", language=" + language +"]";
	}

	 
} //class TemplateSMS
