
/*@Jatinder Pal*/

package com.telemune.vcc.webadmin;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import com.telemune.dbutilities.*;
import com.telemune.vcc.common.TSSJavaUtil;

import org.apache.log4j.*;
public class TimeZoneManager
{
                                static Logger logger=Logger.getLogger(TimeZoneManager.class);
				private PreparedStatement pstmt = null;
				private Connection con = null;
				private ResultSet rs =null;
				private String query = null;
	
 public int addTimeZone(TimeZones timeZone)
 {
		return 99;
 }//addTimeZone

 public int viewTimeZone(ArrayList timeZoneAl)
 {
		 logger.info("for getting Time Zones");
	 try
	 {
		 con = TSSJavaUtil.instance().getconnection();
			 query = "select * from ROME_TIME_ZONES";
			 pstmt = con.prepareStatement(query);
			 rs = pstmt.executeQuery();
			 while(rs.next() )
			 {
							 	TimeZones timeZone = new TimeZones();
								timeZone.setTimeZone ( rs.getInt("TIME_ZONE") );
								timeZone.setZoneName ( rs.getString("ZONE_NAME") );
								timeZone.setDiffHour ( rs.getInt("DIFF_HOUR") );
								timeZone.setDiffMinute ( rs.getInt("DIFF_MINUTE") );
					timeZoneAl.add(timeZone);			
			 }//while
			pstmt.close();
			rs.close();
    }//try
		catch(Exception e)
		{
			try
			{
				if( pstmt != null || rs != null ) 
				{
									pstmt.close();
									rs.close();
				}//if
   		}//try
      catch (SQLException sqle)
      {
      }
			logger.error("Exception in viewTimeZone",e);
      e.printStackTrace ();
      return -1;
		}//catch
		finally
		{		try {
			if(con!=null)	TSSJavaUtil.instance().freeConnection(con);
		} catch (Exception e2) {
			// TODO: handle exception
		}}
		return 99;
	
 }//viewTimeZone

 public int viewTimeZone(ArrayList timeZoneAl, int timeZone)
 {
				 logger.info("for getting Time Zones"+timeZone);
	 try
	 {
		 con = TSSJavaUtil.instance().getconnection();
			 query = "select * from ROME_TIME_ZONES where TIME_ZONE=?";
			 pstmt = con.prepareStatement(query);
		   pstmt.setInt(1,timeZone);
			 rs = pstmt.executeQuery();
			 while(rs.next() )
			 {
							 	TimeZones time_Zone = new TimeZones();
								time_Zone.setTimeZone ( rs.getInt("TIME_ZONE") );
								time_Zone.setZoneName ( rs.getString("ZONE_NAME") );
								time_Zone.setDiffHour ( rs.getInt("DIFF_HOUR") );
								time_Zone.setDiffMinute ( rs.getInt("DIFF_MINUTE") );
					timeZoneAl.add(time_Zone);			
			 }//while
			pstmt.close();
			rs.close();
    }//try
		catch(Exception e)
		{
			try
			{
				if( pstmt != null || rs != null ) 
				{
									pstmt.close();
									rs.close();
				}//if
   		}//try
      catch (SQLException sqle)
      {
      }
			logger.error("Exception in viewTimeZone",e);
      e.printStackTrace ();
      return -1;
		}//catch
		finally
		{	try {
			if(con!=null)	TSSJavaUtil.instance().freeConnection(con);
		} catch (Exception e2) {
			// TODO: handle exception
		}	}
		return 99;

}//viewTimeZone


}// class TimeZoneManager


