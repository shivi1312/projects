package com.telemune.vcc.webadmin;
import java.util.ArrayList;
public class UserStatusBean {
	private boolean m_Active=false;
	private boolean m_Inactive=false;
	private boolean m_NonSub=false;
	
	
	private  ArrayList<TemplateConfModifyBean> m_unitBean=null;


	public boolean isM_Active() {
		return m_Active;
	}


	public void setM_Active(boolean m_Active) {
		this.m_Active = m_Active;
	}


	public boolean isM_Inactive() {
		return m_Inactive;
	}


	public void setM_Inactive(boolean m_Inactive) {
		this.m_Inactive = m_Inactive;
	}


	public boolean isM_NonSub() {
		return m_NonSub;
	}


	public void setM_NonSub(boolean m_NonSub) {
		this.m_NonSub = m_NonSub;
	}


	public ArrayList<TemplateConfModifyBean> getM_unitBean() {
		return m_unitBean;
	}


	public void setM_unitBean(ArrayList<TemplateConfModifyBean> m_unitBean) {
		this.m_unitBean = m_unitBean;
	}
	
	
	

}
