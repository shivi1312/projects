package com.telemune.vcc.webadmin;

import java.util.ArrayList;

public class VCCRatePlanBean {
	private int PlanId=-1;
	 private int subCode=-1;
	private int subValidity=-1;
	 private int renew=-1;
	 private int renewValidity=-1;
	private  int retCode=-1;
	 private int rcrdCode=-1;
	 private int grpRcrdCode=-1;
	 private String serviceType="";
	 private int PullSms=-1;
	 private String maskName="";
	private int mailBoxId=-1;
	 private String scope="";
	 private ArrayList<Integer> deleteList;
	
	 
	 
	 
	 
	
	public ArrayList<Integer> getDeleteList() {
		return deleteList;
	}
	public void setDeleteList(ArrayList<Integer> deleteList) {
		this.deleteList = deleteList;
	}
	public VCCRatePlanBean() {
	super();	// TODO Auto-generated constructor stub
	}
	 public VCCRatePlanBean(int planId, int subCode, int subValidity, int renew,
			int renewValidity, int retCode, int rcrdCode, int grpRcrdCode,
			String serviceType, int pullSms, String maskName, int mailBoxId,
			String scope) {
		super();
		PlanId = planId;
		this.subCode = subCode;
		this.subValidity = subValidity;
		this.renew = renew;
		this.renewValidity = renewValidity;
		this.retCode = retCode;
		this.rcrdCode = rcrdCode;
		this.grpRcrdCode = grpRcrdCode;
		this.serviceType = serviceType;
		PullSms = pullSms;
		this.maskName = maskName;
		this.mailBoxId = mailBoxId;
		this.scope = scope;
	}
	public int getPlanId() {
		return PlanId;
	}
	public void setPlanId(int planId) {
		PlanId = planId;
	}
	public int getSubCode() {
		return subCode;
	}
	public void setSubCode(int subCode) {
		this.subCode = subCode;
	}
	public int getSubValidity() {
		return subValidity;
	}
	public void setSubValidity(int subValidity) {
		this.subValidity = subValidity;
	}
	public int getRenew() {
		return renew;
	}
	public void setRenew(int renew) {
		this.renew = renew;
	}
	public int getRenewValidity() {
		return renewValidity;
	}
	public void setRenewValidity(int renewValidity) {
		this.renewValidity = renewValidity;
	}
	public int getRetCode() {
		return retCode;
	}
	public void setRetCode(int retCode) {
		this.retCode = retCode;
	}
	public int getRcrdCode() {
		return rcrdCode;
	}
	public void setRcrdCode(int rcrdCode) {
		this.rcrdCode = rcrdCode;
	}
	public int getGrpRcrdCode() {
		return grpRcrdCode;
	}
	public void setGrpRcrdCode(int grpRcrdCode) {
		this.grpRcrdCode = grpRcrdCode;
	}
	public String getServiceType() {
		return serviceType;
	}
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	public int getPullSms() {
		return PullSms;
	}
	public void setPullSms(int pullSms) {
		PullSms = pullSms;
	}
	public String getMaskName() {
		return maskName;
	}
	public void setMaskName(String maskName) {
		this.maskName = maskName;
	}
	public int getMailBoxId() {
		return mailBoxId;
	}
	public void setMailBoxId(int mailBoxId) {
		this.mailBoxId = mailBoxId;
	}
	public String getScope() {
		return scope;
	}
	public void setScope(String scope) {
		this.scope = scope;
	}
	@Override
	public String toString() {
		return "VCCRatePlanBean [subCode=" + subCode + ", subValidity="
				+ subValidity + ", renew=" + renew + ", renewValidity="
				+ renewValidity + ", retCode=" + retCode + ", rcrdCode="
				+ rcrdCode + ", grpRcrdCode=" + grpRcrdCode + ", serviceType="
				+ serviceType + ", PullSms=" + PullSms + ", maskName="
				+ maskName + ", mailBoxId=" + mailBoxId + ", scope=" + scope
				+ "]";
	}

	 
}
