
package com.telemune.vcc.webadmin;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import com.telemune.dbutilities.*;
import com.telemune.vcc.common.TSSJavaUtil;

import org.apache.log4j.*;
public class VLRManager
{
  private static Logger logger=Logger.getLogger(VLRManager.class);
  private PreparedStatement pstmt = null;
  private Connection con = null;
  private ResultSet rs = null;
  private String query = null;

  
  public int addVLRConfig (VLR vlr)
  {
	  
    try
    {
    	logger.info("Inside addVLRConfig()...VLR  ["+vlr+"]");
    	con = TSSJavaUtil.instance().getconnection();
      query = "select VLR_NUMBER from VLR_MASTER where VLR_NUMBER = ?";
      pstmt = con.prepareStatement (query);
      pstmt.setString (1, vlr.getVlrId ());
      rs = pstmt.executeQuery ();
      if (rs.next ())
			{
	  		rs.close();
				pstmt.close ();
			  return -2;
			}
      query = "insert into VLR_MASTER (VLR_NUMBER, DESCRIPTION, OUTROAM_FLAG) values (?, ?, ?)";
      pstmt = con.prepareStatement (query);
      pstmt.setString (1, vlr.getVlrId ());
      pstmt.setString (2, vlr.getDescription ());
      pstmt.setString (3, vlr.getEnabled ());
      pstmt.executeUpdate ();
      pstmt.close ();
    }
    catch (Exception e)
    {
      try
      {
				if (pstmt != null)
				  pstmt.close ();
      }
      catch (SQLException sqle)
      {
      }
      logger.error("Exception in Inside addVLRConfig()",e);
      e.printStackTrace ();
      return -1;
    }
		finally
		{		try {
			if(con!=null)	TSSJavaUtil.instance().freeConnection(con);
		} catch (Exception e2) {
			// TODO: handle exception
		}	}
    return 0;
  }//addVLRConfig

  public int viewVLRConfig(ArrayList vlrConfigAl)
	{
		try
		{
			logger.info("Inside viewVLRConfig()...");
			con = TSSJavaUtil.instance().getconnection();
			query = "select VLR_NUMBER,DESCRIPTION,OUTROAM_FLAG from VLR_MASTER";
			pstmt = con.prepareStatement(query);
			rs = pstmt.executeQuery();
			while( rs.next() )
			{
				VLR vlr = new VLR();
				vlr.setVlrId (rs.getString("VLR_NUMBER" ) );
				vlr.setDescription(rs.getString("DESCRIPTION") );
				vlr.setEnabled(rs.getString("OUTROAM_FLAG") );
				vlrConfigAl.add(vlr);
			}//while
			pstmt.close();
			rs.close();		
		}
		catch(Exception e)
		{
			try
			{
				if( pstmt != null || rs != null ) 
				{
									pstmt.close();
									rs.close();
				}//if
   		}//try
      catch (SQLException sqle)
      {
      }
			logger.error("Exception in  viewVLRConfig()",e);
      e.printStackTrace ();
      return -1;
		}//catch
		finally
		{		try {
			if(con!=null)	TSSJavaUtil.instance().freeConnection(con);
		} catch (Exception e2) {
			// TODO: handle exception
		}	}
		return 99;
	}// viewVLRConfig

  public int modifyVLRConfig (VLR vlr)
  {
			logger.info("modify VLR Config");
    try
    {
    	con = TSSJavaUtil.instance().getconnection();
      query = "update VLR_MASTER set DESCRIPTION = ? , OUTROAM_FLAG = ? where VLR_NUMBER=?";
      pstmt = con.prepareStatement (query);
		  pstmt.setString (1, vlr.getDescription ());
      pstmt.setString (2, vlr.getEnabled ());
      pstmt.setString (3, vlr.getVlrId ());
      
			pstmt.executeUpdate ();
      pstmt.close ();
    }
    catch (Exception e)
    {
      try
      {
				if (pstmt != null)
					  pstmt.close ();
      }
      catch (SQLException sqle)
      {
      }
      logger.error("Exception in modifyVLRConfig",e);
      e.printStackTrace ();
      return -1;
    }
		finally
		{	try {
			if(con!=null)	TSSJavaUtil.instance().freeConnection(con);
		} catch (Exception e2) {
			// TODO: handle exception
		}	}
    return 0;
  }//modifyVLRConfig

   public int delVLRConfig (VLR vlr)
  {
    try
    {
    	con = TSSJavaUtil.instance().getconnection();
      query = "delete from VLR_MASTER where VLR_NUMBER = ? ";
      pstmt = con.prepareStatement (query);
      pstmt.setString (1, vlr.getVlrId ());
      pstmt.executeUpdate ();
      pstmt.close ();
    }
    catch (Exception e)
    {
      try
      {
				if (pstmt != null)
	 				 pstmt.close ();
      }
      catch (SQLException sqle)
      {
      }
      e.printStackTrace ();
      return -1;
    }
		finally
		{		try {
			if(con!=null)	TSSJavaUtil.instance().freeConnection(con);
		} catch (Exception e2) {
			// TODO: handle exception
		}}
    return 2;
  }//delVLRConfig
	
} // class VLRManager
