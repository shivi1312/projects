package com.telemune.vcc.webadmin;

public class ViralSmsAllowedRange 
{
	int rangeId;
	String msisdnRange;
	public int getRangeId() {
		return rangeId;
	}
	public void setRangeId(int rangeId) {
		this.rangeId = rangeId;
	}
	public String getMsisdnRange() {
		return msisdnRange;
	}
	public void setMsisdnRange(String msisdnRange) {
		this.msisdnRange = msisdnRange;
	}
	
}
