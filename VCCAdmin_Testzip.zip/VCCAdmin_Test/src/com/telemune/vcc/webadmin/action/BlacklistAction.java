/**
 * @author MoHit
 * Created on 24 March 2015 for COMMON
 */


package com.telemune.vcc.webadmin.action;

import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.telemune.vcc.common.ValidateAction;
import com.telemune.vcc.webadmin.BlacklistManagerNew;

public class BlacklistAction extends ValidateAction 
{
	{
		setLinkName("webadmin");
	}
	
	private static final long serialVersionUID = 1L;
	private Logger logger=Logger.getLogger(BlacklistAction.class);
	private String msisdn=null;
	private ArrayList<String> blacklistAl=null;
	private ArrayList<String> msisdnToDel=null;
	
	public void setMsisdnToDel(ArrayList<String> msisdnToDel) {
		this.msisdnToDel = msisdnToDel;
	}

	public ArrayList<String> getMsisdnToDel() {
		return msisdnToDel;
	}

	public void setBlacklistAl(ArrayList<String> blacklistAl) {
		this.blacklistAl = blacklistAl;
	}

	public ArrayList<String> getBlacklistAl() {
		return blacklistAl;
	}

	public String getMsisdn() {
		return msisdn;
	}

	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	
	public String getSuccess()
	{
		if(!checkSession().equalsIgnoreCase("success"))
		{
			return ERROR;
		}
		else
		{
			return SUCCESS;
		}
	}
	
	/**
	 * This method is used to validating msisdn before adding to blacklist and to alert
	 * different messages on different results
	 * @return
	 */
	public String addBlacklist()
	{
		
		logger.info("inside addBlacklist() msisdn="+this.msisdn);
		if(!checkSession().equalsIgnoreCase("success"))
		{
			return ERROR;
		}
		else
		{
            String validChars = "1234567890"; //        [0-9]
            for (int i=0;i<this.msisdn.length();i++)
            {
                    char c = this.msisdn.charAt(i);
                    if (validChars.indexOf(c)== -1)
                    {
                            logger.info("MSISDN is not valid = "+this.msisdn);
                            message=getText("web.invalidMsisdn");
                            return SUCCESS;
                    }
            }
		
			BlacklistManagerNew blk=new BlacklistManagerNew();
			int result=blk.addNewBlacklist(this.msisdn);
			logger.info("result return from addNewBlacklist() ="+result);
			if(result==1)
				message=getText("web.addSuccess");
			else if(result==-2)
				message=getText("web.msisdnNotInOpRange");
			else if(result==-3)
				message=getText("web.alreadySub");
			else if(result==-4)
				message=getText("web.alreadyBlkList");
			else if(result==-5 || result==-1)
				message=getText("con.alerrUnknown");
			
			return SUCCESS;
		}
	}//addBlacklist()
	
	/**
	 * This method is used to view all the blacklist numbers and to show result accordingly
	 * @return
	 */
	public String viewBlacklist()
	{
		logger.info("inside viewBlacklist()");
		if(!checkSession().equalsIgnoreCase("success"))
		{
			return ERROR;
		}
		else
		{
			BlacklistManagerNew blk=new BlacklistManagerNew();
			blacklistAl=new ArrayList<String>();
			int result=blk.getAllBlacklists(blacklistAl);
			
			logger.info("result returned from getAllBlacklists ="+result);
			
			if(result==1)
				message=null;
			else if(result==-1)
				message=getText("someError")+" "+getText("con.alerrUnknown");
			
			return SUCCESS;
		}
	}//viewBlacklist()
	
	
	public String deleteBlacklist()
	{
		logger.info("inside deleteBlacklist()");
		if(!checkSession().equalsIgnoreCase("success"))
		{
			return ERROR;
		}
		else
		{
			StringBuffer msisdnsDeleted=new StringBuffer("");
			
			BlacklistManagerNew blk=new BlacklistManagerNew();
			int result=blk.deleteBlacklistNumbers(msisdnToDel,msisdnsDeleted);
			
			logger.info("result returned from deleteBlacklistNumbers() ="+result+" msisdnDeleted="+msisdnsDeleted);
			
			if(result==1)
				message=msisdnsDeleted+" "+getText("web.deletedSuccess");
			else if(result==-2)
				message=getText("MSISDN")+getText("cantDelete");
			else if(result==-1)
				message=getText("con.alerrUnknown");
				
			return SUCCESS;
		}
	}//deleteBlacklist()
	
}
