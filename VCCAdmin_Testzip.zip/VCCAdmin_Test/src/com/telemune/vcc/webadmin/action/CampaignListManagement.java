package com.telemune.vcc.webadmin.action;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;

import com.telemune.dbutilities.Connection;
import com.telemune.dbutilities.PreparedStatement;
import com.telemune.vcc.common.TSSJavaUtil;
import com.telemune.vcc.common.ValidateAction;
import com.telemune.vcc.webadmin.ListCampaginBean;

public class CampaignListManagement extends ValidateAction{
	
	
	Logger logger=Logger.getLogger(CampaignListManagement.class);
	ListCampaginBean listCampaginBean=null;
	ArrayList<ListCampaginBean> listCampaginList=null;
	 int showList=-1; 
	 public int getShowList() {
		return showList;
	}
	public void setShowList(int showList) {
		this.showList = showList;
	}
	public ArrayList<ListCampaginBean> getListCampaginList() {
		return listCampaginList;
	}
	public void setListCampaginList(ArrayList<ListCampaginBean> listCampaginList) {
		this.listCampaginList = listCampaginList;
	}


	{
		 setLinkName("webadmin");
	 }
	
	public ListCampaginBean getListCampaginBean() {
		return listCampaginBean;
	}
	public void setListCampaginBean(ListCampaginBean listCampaginBean) {
		this.listCampaginBean = listCampaginBean;
	}
	
	private String message=null;
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}


	/*
	 * addedCampaignListName() is used for checking List name and createdd List Name if not there 
	 */

	public String addedCampaignListName()
	{
		 this.actionName="createCampaignList.action";
		logger.info("addedCampaignListName() started with List Name ["+listCampaginBean.getListName()+"]");
		String select_query="select * from campaign_list_master where upper(list_name)=?";
		String insert_query="insert into campaign_list_master(list_id,list_name,status) values(CAMPAIGN_LIST_SEQ.nextval,?,'A')";
		Connection con= null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
			}
		    else{
				 try{
						
					  con=TSSJavaUtil.instance().getconnection();
					  /*
					   * Checking for List Name in Table
					   */
					  pstmt=con.prepareStatement(select_query);
					  pstmt.setString(1,listCampaginBean.getListName().trim().toUpperCase());
					  rs=pstmt.executeQuery();
					  if(rs.next())
					  {
	                    this.setMessage(getText("webadmin.campaignListNameExist"));					  
					  }
					  else
					  {	 
						  /*
						   * Adding List Name 
						   */
					   pstmt.clearParameters();
					   pstmt.close();
			          pstmt=con.prepareStatement(insert_query); 
			          pstmt.setString(1,listCampaginBean.getListName().trim().toUpperCase());
				      int response=pstmt.executeUpdate();
				      if(response>0)
				      {
				    	   this.setMessage(getText("webadmin.campaignListName.Created"));
				      }
				      else
				      {
				    	  this.setMessage(getText("webadmin.campaignListName.notcreated"));
				      }
				      
					  }
				  }
				 catch(Exception e)
				  {
					 this.setMessage(getText("webadmin.campaignListName.notcreated"));
				     logger.error("Exception inside getDetailAddPromoPack(),,,,,",e);
				  }finally
				  {
					  insert_query=null;
					  select_query=null;
				  	
				  		try {
				  			if(rs!=null)
					  			rs.close();
					  			if(pstmt!=null)
					  			pstmt.close();	
					  			if(con!=null)
									TSSJavaUtil.instance().freeConnection(con);	
				  		} catch (Exception e) {
				  			// TODO Auto-generated catch block
				  			e.printStackTrace();
				  		}
				  	
				  }
				 
                return "success";
			}
	}
	
	
	public String uploadCampaignListName()
	{
		 Connection con=null;
		 PreparedStatement pstmt=null;
		 ResultSet rs=null; 
		try
		{
		 	listCampaginList=new ArrayList<ListCampaginBean>();
		 	this.getCampaignListNameList(listCampaginList);
		 	  if(listCampaginList.size()==0)
		 		   showList=-1;
		 	  else 
		 		  showList=1;		  
		 	  
		}
		catch(Exception e)
		  {
		     logger.error("Exception inside uploadCampaignListName(),,,,,",e);
		     return "error";
		  }finally
		  {
		  		try {
		  			
		  			if(rs!=null)
		  			rs.close();
		  			if(pstmt!=null)
		  			pstmt.close();
		  			if(con!=null)
						TSSJavaUtil.instance().freeConnection(con);
		  		} catch (Exception e) {
		  			// TODO Auto-generated catch block
		  			e.printStackTrace();
		  		}
		  }
	  return "success";	
	}
	/*
	 * For Geeting All List Names In a List.
	 */
	
	public void getCampaignListNameList(ArrayList<ListCampaginBean> listCampaginList)
	{
		Connection con=null;
		PreparedStatement pstmt=null;
		 ResultSet rs=null;
		 String query="select LIST_ID,LIST_NAME from campaign_list_master where STATUS='A'";
		 try
			{
			 	con=TSSJavaUtil.instance().getconnection();
			 	pstmt=con.prepareStatement(query);
			    rs=pstmt.executeQuery();
			    while(rs.next())
			    {
			         ListCampaginBean listCampaginBean=new ListCampaginBean(rs.getInt("LIST_ID"),rs.getString("LIST_NAME"));
			         listCampaginList.add(listCampaginBean);
			    }
			}
			catch(Exception e)
			  {
				  listCampaginList.clear();
			     logger.error("Exception inside getDetailAddPromoPack(),,,,,",e);
			  }finally
			  {
			  		try {
			  			
			  			if(rs!=null)
			  			rs.close();
			  			if(pstmt!=null)
			  			pstmt.close();
			  			if(con!=null)
							TSSJavaUtil.instance().freeConnection(con);
			  		} catch (Exception e) {
			  			// TODO Auto-generated catch block
			  			e.printStackTrace();
			  		}
			  }
	}
	
	public String uploadedCampaign()
	{
		this.actionName="uploadCampaignList.action";
		Connection con=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		FileReader fileReader=null;
		File file=null;
		String line="";
		String validChars="1234567890";
		StringBuilder msisdnString=new StringBuilder("");
		int notAddedCount=0;
		int faltyMsisdn=0;
		boolean toExit=false; 
		System.out.println("Enter Checking for uploadedCampaign() ");
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
			}
		    else{
		    	System.out.println(" else Here Enter Checking for uploadedCampaign() ");
				 try
				 {
					 System.out.println("File is "+listCampaginBean);
				    file=listCampaginBean.getUploadFile();
				    
					System.out.println("File Object ["+file.getName()+"] listCam List_id "+listCampaginBean.getList_id()); 
					if(file!=null)
					{
						fileReader =new FileReader(file);
						BufferedReader bufferedReader =new BufferedReader(fileReader);
						 while((line = bufferedReader.readLine()) != null)
                         {

                                 System.out.println("Length without trim "+line +"With Trim "+line.trim().length());
                                 msisdnString.append(line.trim()+"  ");
                         }
                         bufferedReader=null;
                         fileReader=null;
                         line=null;
                         if(msisdnString.length()!=0)
                         {
                        	 StringTokenizer str = new StringTokenizer(msisdnString.toString());
                             ArrayList<String> msisdnList = new ArrayList<String>();
                             while(str.hasMoreTokens())
                             {
                                     String tempString=str.nextToken().trim();
                                     for (int i=0;i<tempString.length();i++)
                                     {
                                             char c = tempString.charAt(i);
                                             if (validChars.indexOf(c)== -1)
                                             {
                                                     toExit=true;
                                             }
                                     }

                                     if(toExit)
                                     {
                                       System.out.println("Not Including ["+tempString+"] in List");
                                       faltyMsisdn++;
                                     }
                                     else
                                     {
                                     msisdnList.add(tempString);
                                     }
                                    tempString=null;
                                    toExit=false;
                             }
                             str=null;
                             msisdnString=null;
                             
                             
                             if(msisdnList.size()!=0)
                             {
                                con=TSSJavaUtil.instance().getconnection();
                                String select_query="select * from campaign_list_msisdn where msisdn=?";
                                String insert_query="insert into campaign_list_msisdn(list_id,msisdn,status) values(?,?,'A')";
                            	 for(int i=0;i<msisdnList.size();i++)
                            	 {
                                     
                            		 pstmt=con.prepareStatement(select_query);
                            		 pstmt.setString(1,msisdnList.get(i));
                            		 rs=pstmt.executeQuery();
                            		 if(rs.next())
                            		 {
                            			notAddedCount++; 
                            		 }
                            		 else
                            		 {
                            			 rs.close();
                            			 pstmt.close();
                            			 pstmt=con.prepareStatement(insert_query);
                            			 pstmt.setInt(1, listCampaginBean.getList_id());
                            			 pstmt.setString(2,msisdnList.get(i));
                            			 pstmt.executeUpdate();
                            		 }
                            		 if(rs!=null) rs.close();
                            		 if(pstmt!=null) pstmt.close();
                            		 
                            		 this.setMessage(getText("filecount")+(msisdnList.size()-notAddedCount)+getText("alreadyinfile")+notAddedCount+getText("wrongNumbers")+faltyMsisdn+getText("EnedData"));		 
                            	 }
                             
                             }
                             else
                             {
                            	 this.setMessage(getText("webadmin.fileisblank"));
                             }
                             
						
                        	 
                         }
                         else
                         {
                        	 this.setMessage(getText("webadmin.blankfile"));
                         }
						
						
						
					}
					else
					{
						this.setMessage(getText("webadmin.campaignFileError"));
					}
					
					
					 
				 }
				 catch(Exception e)
				  {
				     logger.error("Exception inside getDetailAddPromoPack(),,,,,",e);
				     return "error";
				  }finally
				  {
				  		try {
				  			
				  			if(rs!=null)
				  			rs.close();
				  			if(pstmt!=null)
				  			pstmt.close();
				  			if(con!=null)
								TSSJavaUtil.instance().freeConnection(con);
				  		} catch (Exception e) {
				  			// TODO Auto-generated catch block
				  			e.printStackTrace();
				  		}
				  }
		    }
		return "success";
	}
	
	
	public String viewCampaignListDetails()
	{
		 this.actionName="createCampaignList.action";
			String select_query="select a.list_id,list_name ,total_data from ( select list_id,list_name from campaign_list_master where status='A') a,(select count(*) total_data,LIST_ID from campaign_list_msisdn where status='A' group by list_id) b where a.list_id=b.list_id";
			
			Connection con= null;
			PreparedStatement pstmt=null;
			ResultSet rs=null;
			if(!checkSession().equalsIgnoreCase("success")){
				return "error";
				}
			    else{
					 try{
							
						  con=TSSJavaUtil.instance().getconnection();
						  /*
						   * Checking for List Name in Table
						   */
						  pstmt=con.prepareStatement(select_query);
						  rs=pstmt.executeQuery();
						  listCampaginList=new ArrayList<ListCampaginBean>();
						  while(rs.next())
						  {
							  
							  ListCampaginBean listCampaginBean=new ListCampaginBean(rs.getInt("LIST_ID"),rs.getString("LIST_NAME"),rs.getInt("TOTAL_DATA"));
							  System.out.println("List Count ["+rs.getInt("TOTAL_DATA")+"] LIST ID ["+rs.getInt("LIST_ID")+"]");
							  listCampaginList.add(listCampaginBean);
						  }
					  }
					 catch(Exception e)
					  {
					     logger.error("Exception inside getDetailAddPromoPack(),,,,,",e);
					     return "error";
					  }
					  finally
					  {
						  select_query=null;
					  	
					  		try {
					  			if(rs!=null)
						  			rs.close();
						  			if(pstmt!=null)
						  			pstmt.close();	
						  			if(con!=null)
										TSSJavaUtil.instance().freeConnection(con);	
					  		} catch (Exception e) {
					  			// TODO Auto-generated catch block
					  			e.printStackTrace();
					  		}
					  	
					  }
					 
	                return "success";
				}
	}
	
	
	public String deletelistData()
	{
		 this.actionName="viewCampaignList.action";
		Connection con=null;
		PreparedStatement pstmt=null;
		 String delete_query="delete from campaign_list_msisdn where list_id=?";
		  try
		  {
			  con=TSSJavaUtil.instance().getconnection();
			  System.out.println("ListBean Here "+listCampaginBean);
			  pstmt=con.prepareStatement(delete_query);
			  pstmt.setInt(1, listCampaginBean.getList_id());
			  int response=pstmt.executeUpdate();
			  this.setMessage(getText("webadmindatadelete"));
			  System.out.println("Deleted Or not"+response);
		  }
		 catch(Exception e)
		  {
		     logger.error("Exception inside getDetailAddPromoPack(),,,,,",e);
		     return "error";
		  }
		  finally
		  {
			   
		  	
		  		try {
		  				if(pstmt!=null)
			  			pstmt.close();	
		  				if(con!=null)
							TSSJavaUtil.instance().freeConnection(con);
		  		} catch (Exception e) {
		  			// TODO Auto-generated catch block
		  			e.printStackTrace();
		  		}
		  	
		  }
		 
       return "success";
		
	}
	
	
}
