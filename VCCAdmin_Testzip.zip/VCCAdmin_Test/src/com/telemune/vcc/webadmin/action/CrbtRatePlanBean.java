package com.telemune.vcc.webadmin.action;


public class CrbtRatePlanBean {
	
	private Integer planIndicator=0;
	private Integer freeRbt=0;
	private Integer freeRecording=0;
	private Integer freeGift=0;
	private String subFbChgCode="";
	private String rbtFbChgCode="";
	private String giftFbChgCode="";
	private String recFbChgCode="";
	private String subRenewFbChgCode="";
	private String rbtRenewFbChgCode="";
	private String recRenewFbChgCode="";
	private String status="NA";
	private String remarks="NA";
	
	private String maskedName="NA";
	private String process="NA";
	
	/*
	 * Added By Rinku For Adding Scope and Country Code in CRBT_RATE_PLAN table
	 */
	private String scope="NA";
	private int countryCode=0;
	
	

	public int getCountryCode() {
		return countryCode;
	}


	public void setCountryCode(int countryCode) {
		this.countryCode = countryCode;
	}


	/**
	 * 
	 * @param subFbChgCode
	 *            Subscription Fall-back charging Code
	 * @param rbtFbChgCode
	 *            RBT Purchase Fall-back charging Code
	 * @param giftFbChgCode
	 *            RBT Gift Fall-back charging Code
	 * @param recFbChgCode
	 *            RBT recording Fall-back charging code
	 * @param subRenewFbChgCode
	 *            Subscription renew Fall-back charging Code
	 * @param rbtRenewFbChgCode
	 *            RBT purchase Renew Fall back Charging Code
	 * @param recRenewFbChgCode
	 *            Recorded RBT renew Fall-back charging Code
	 * 
	 * 
	 * @param status
	 *            Indicates whether Plan is active or not [A-Active, I-Inactive]
	 * @param maskedName
	 *            Masked Name is unique name given by Rateplan creator
	 * @param process
	 *            Process indicates post-handling of Postpaid and Prepaid
	 *            customers' above activities. like - Whether they will be
	 *            renewed automatically or not. Whether they will receive
	 *            Promotional SMS or not.
	 * 
	 */
	public CrbtRatePlanBean(String subFbChgCode, String rbtFbChgCode,
			String giftFbChgCode, String recFbcrbtRateplanBeanChgCode,
			String subRenewFbChgCode, String rbtRenewFbChgCode,
			String recRenewFbChgCode, String status, String maskedName,
			String process) {
		super();
		this.subFbChgCode = subFbChgCode;
		this.rbtFbChgCode = rbtFbChgCode;
		this.giftFbChgCode = giftFbChgCode;
		this.recFbChgCode = recFbcrbtRateplanBeanChgCode;
		this.subRenewFbChgCode = subRenewFbChgCode;
		this.rbtRenewFbChgCode = rbtRenewFbChgCode;
		this.recRenewFbChgCode = recRenewFbChgCode;
		this.status = status;
		this.maskedName = maskedName;
		this.process = process;
	}


	public CrbtRatePlanBean(Integer planIndicator, Integer freeRbt,
			Integer freeRecording, Integer freeGift, String subFbChgCode,
			String rbtFbChgCode, String giftFbChgCode, String recFbChgCode,
			String subRenewFbChgCode, String rbtRenewFbChgCode,
			String recRenewFbChgCode, String status, String remarks,
			String scope, String maskedName, String process) {
		super();
		this.planIndicator = planIndicator;
		this.freeRbt = freeRbt;
		this.freeRecording = freeRecording;
		this.freeGift = freeGift;
		this.subFbChgCode = subFbChgCode;
		this.rbtFbChgCode = rbtFbChgCode;
		this.giftFbChgCode = giftFbChgCode;
		this.recFbChgCode = recFbChgCode;
		this.subRenewFbChgCode = subRenewFbChgCode;
		this.rbtRenewFbChgCode = rbtRenewFbChgCode;
		this.recRenewFbChgCode = recRenewFbChgCode;
		this.status = status;
		this.remarks = remarks;
		this.scope = scope;
		this.maskedName = maskedName;
		this.process = process;
	}

	
	public CrbtRatePlanBean(Integer planIndicator, Integer freeRbt,
			Integer freeRecording, Integer freeGift, String subFbChgCode,
			String rbtFbChgCode, String giftFbChgCode, String recFbChgCode,
			String subRenewFbChgCode, String rbtRenewFbChgCode,
			String recRenewFbChgCode, String status, String remarks,
			String scope, String maskedName) {
		super();
		this.planIndicator = planIndicator;
		this.freeRbt = freeRbt;
		this.freeRecording = freeRecording;
		this.freeGift = freeGift;
		this.subFbChgCode = subFbChgCode;
		this.rbtFbChgCode = rbtFbChgCode;
		this.giftFbChgCode = giftFbChgCode;
		this.recFbChgCode = recFbChgCode;
		this.subRenewFbChgCode = subRenewFbChgCode;
		this.rbtRenewFbChgCode = rbtRenewFbChgCode;
		this.recRenewFbChgCode = recRenewFbChgCode;
		this.status = status;
		this.remarks = remarks;
		this.scope = scope;
		this.maskedName = maskedName;
	}


	public CrbtRatePlanBean() {
		super();
	}

	public Integer getPlanIndicator() {
		return planIndicator;
	}
	public void setPlanIndicator(Integer planIndicator) {
		this.planIndicator = planIndicator;
	}
	public Integer getFreeRbt() {
		return freeRbt;
	}
	public void setFreeRbt(Integer freeRbt) {
		this.freeRbt = freeRbt;
	}
	public Integer getFreeRecording() {
		return freeRecording;
	}
	public void setFreeRecording(Integer freeRecording) {
		this.freeRecording = freeRecording;
	}
	public Integer getFreeGift() {
		return freeGift;
	}
	public void setFreeGift(Integer freeGift) {
		this.freeGift = freeGift;
	}
	public String getSubFbChgCode() {
		return subFbChgCode;
	}
	public void setSubFbChgCode(String subFbChgCode) {
		this.subFbChgCode = subFbChgCode;
	}
	public String getRbtFbChgCode() {
		return rbtFbChgCode;
	}
	public void setRbtFbChgCode(String rbtFbChgCode) {
		this.rbtFbChgCode = rbtFbChgCode;
	}
	public String getGiftFbChgCode() {
		return giftFbChgCode;
	}
	public void setGiftFbChgCode(String giftFbChgCode) {
		this.giftFbChgCode = giftFbChgCode;
	}
	public String getRecFbChgCode() {
		return recFbChgCode;
	}
	public void setRecFbChgCode(String recFbChgCode) {
		this.recFbChgCode = recFbChgCode;
	}
	public String getSubRenewFbChgCode() {
		return subRenewFbChgCode;
	}
	public void setSubRenewFbChgCode(String subRenewFbChgCode) {
		this.subRenewFbChgCode = subRenewFbChgCode;
	}
	public String getRbtRenewFbChgCode() {
		return rbtRenewFbChgCode;
	}
	public void setRbtRenewFbChgCode(String rbtRenewFbChgCode) {
		this.rbtRenewFbChgCode = rbtRenewFbChgCode;
	}
	public String getRecRenewFbChgCode() {
		return recRenewFbChgCode;
	}
	public void setRecRenewFbChgCode(String recRenewFbChgCode) {
		this.recRenewFbChgCode = recRenewFbChgCode;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getScope() {
		return scope;
	}
	public void setScope(String scope) {
		this.scope = scope;
	}
	public String getProcess() {
		return process;
	}
	public void setProcess(String process) {
		this.process = process;
	}

	public String getMaskedName() {
		return maskedName;
	}


	public void setMaskedName(String maskedName) {
		this.maskedName = maskedName;
	}


	@Override
	public String toString() {
		return "CrbtRatePlanBean [planIndicator=" + planIndicator
				+ ", freeRbt=" + freeRbt + ", freeRecording=" + freeRecording
				+ ", freeGift=" + freeGift + ", subFbChgCode=" + subFbChgCode
				+ ", rbtFbChgCode=" + rbtFbChgCode + ", giftFbChgCode="
				+ giftFbChgCode + ", recFbChgCode=" + recFbChgCode
				+ ", subRenewFbChgCode=" + subRenewFbChgCode
				+ ", rbtRenewFbChgCode=" + rbtRenewFbChgCode
				+ ", recRenewFbChgCode=" + recRenewFbChgCode + ", status="
				+ status + ", remarks=" + remarks + ", scope=" + scope
				+ ", maskedName=" + maskedName + ", process=" + process + "]";
	}
	 
}
