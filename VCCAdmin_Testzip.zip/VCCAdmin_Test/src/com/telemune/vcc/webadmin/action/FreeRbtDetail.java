package com.telemune.vcc.webadmin.action;

public class FreeRbtDetail {
	
	private Integer chargingCode;
	private Integer validity;
	//private Integer noOfRbt;
	//private Integer noOfFreeRbt;
	
	
	
	
	public FreeRbtDetail() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public FreeRbtDetail(Integer chargingCode, Integer validity) {
		super();
		this.chargingCode = chargingCode;
		this.validity = validity;
		//this.noOfRbt=noOfRbt;
		//this.noOfFreeRbt=noOfFreeRbt;
	}
	 
	/*public FreeRbtDetail(Integer chargingCode, Integer validity) {
		super();
		this.chargingCode = chargingCode;
		this.validity = validity;
	}*/

	
	
//	public Integer getNoOfRbt() {
//		return noOfRbt;
//	}

//	public void setNoOfRbt(Integer noOfRbt) {
//		this.noOfRbt = noOfRbt;
//	}

//	public Integer getNoOfFreeRbt() {
//		return noOfFreeRbt;
//	}

//	public void setNoOfFreeRbt(Integer noOfFreeRbt) {
//		this.noOfFreeRbt = noOfFreeRbt;
//	}

	public Integer getValidity() {
		return validity;
	}
	public void setValidity(Integer validity) {
		this.validity = validity;
	}
	
	public Integer getChargingCode() {
		return chargingCode;
	}


	public void setChargingCode(Integer chargingCode) {
		this.chargingCode = chargingCode;
	}


	@Override
	public String toString() {
		return "SubscriptionDetail [chargingCode=" + chargingCode
				+ ", validity=" + validity + "]";
	}
	
}
