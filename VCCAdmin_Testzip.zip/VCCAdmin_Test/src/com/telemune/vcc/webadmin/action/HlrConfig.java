package com.telemune.vcc.webadmin.action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;

import com.telemune.dbutilities.Connection;
import com.telemune.vcc.common.HistoryGenerator;
import com.telemune.vcc.common.SessionHistory;
import com.telemune.vcc.common.TSSJavaUtil;
import com.telemune.vcc.common.ValidateAction;
import com.telemune.vcc.crbtcontent.TssStringUtill;
import com.telemune.vcc.model.HistoryDataBean;
import com.telemune.vcc.webadmin.HLR;
import com.telemune.vcc.webadmin.HLRManager;

public class HlrConfig extends ValidateAction {

	Logger logger = Logger.getLogger(HlrConfig.class);
	private HLR bean;
	private ArrayList<HLR> hlrConfigAl = null;
	private String message;
	HLRManager hlrManager = null;

	HistoryDataBean historyDataBean = null;
	HistoryGenerator historyGenerator = null;
	Connection con = null;
	
	public HLR getBean() {
		return bean;
	}

	public void setBean(HLR bean) {
		this.bean = bean;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public ArrayList<HLR> getHlrConfigAl() {
		return hlrConfigAl;
	}

	public void setHlrConfigAl(ArrayList<HLR> hlrConfigAl) {
		this.hlrConfigAl = hlrConfigAl;
	}

	public String addHlrConfig() {

		this.actionName = "viewAllHlrConfig.action?bean.hlrId=-1";
		this.linkName = "webadmin";
		logger.info("addHlrConfig() started with HLR Name ["
				+ bean.getHlrName() + "]");
		int response = -1;
		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		} else {
			HttpServletRequest request = ServletActionContext.getRequest();
			HttpSession session = request.getSession();
			String user = ((SessionHistory) session
					.getAttribute("sessionHistory")).getUser();
			String roleName1 = ((SessionHistory) session
					.getAttribute("sessionHistory")).getRoleName();
			con = TSSJavaUtil.instance().getconnection();
			try {
				hlrManager = new HLRManager();

				if (TssStringUtill.ValidateParams(bean.getHlrName(),
						bean.getHlrIp(), "" + bean.getHlrPort(),
						bean.getLogin(), bean.getPassword(),
						"" + bean.getConn())) {
					response = hlrManager.addHLRConfig(bean);
					if (response == 0) {
						this.setMessage(getText("webadmin.hlrConfig.Created"));
						historyDataBean = new HistoryDataBean();
						historyDataBean.setUser(user);
						historyDataBean.setAction(getText("hlrmanagement"));
						historyDataBean.setEvent("add");
						historyDataBean.setRole(roleName1);
						historyDataBean.setMsg("HLR Config ["+bean.getHlrName()+"] Add [Success]");
						historyGenerator = new HistoryGenerator();
						historyGenerator.insertHistoryData(historyDataBean, con);
					} else if (response == -2) {
						this.setMessage(getText("webadmin.hlrConfig.already"));
						historyDataBean = new HistoryDataBean();
						historyDataBean.setUser(user);
						historyDataBean.setAction(getText("hlrmanagement"));
						historyDataBean.setEvent("Add");
						historyDataBean.setRole(roleName1);
						historyDataBean.setMsg("HLR Config ["+bean.getHlrName()+"] Add [Already Exist]");
						historyGenerator = new HistoryGenerator();
						historyGenerator.insertHistoryData(historyDataBean, con);
					} else {
						this.setMessage(getText("webadmin.hlrConfig.notcreated"));
						historyDataBean = new HistoryDataBean();
						historyDataBean.setUser(user);
						historyDataBean.setAction(getText("hlrmanagement"));
						historyDataBean.setEvent("Add");
						historyDataBean.setRole(roleName1);
						historyDataBean.setMsg("HLR Config ["+bean.getHlrName()+"] Add [Failed]");
						historyGenerator = new HistoryGenerator();
						historyGenerator.insertHistoryData(historyDataBean, con);
					}
				} else {
					this.setMessage(getText("webadmin.hlrConfig.notcreated"));
					historyDataBean = new HistoryDataBean();
					historyDataBean.setUser(user);
					historyDataBean.setAction(getText("hlrmanagement"));
					historyDataBean.setEvent("Add");
					historyDataBean.setRole(roleName1);
					historyDataBean.setMsg("HLR Config ["+bean.getHlrName()+"] Add [Failed]");
					historyGenerator = new HistoryGenerator();
					historyGenerator.insertHistoryData(historyDataBean, con);
				}

			} catch (Exception e) {
				this.setMessage(getText("webadmin.hlrConfig.notcreated"));
				logger.error("Exception inside addHlrConfig(),,,,,", e);
			} finally {
				hlrManager = null;
				if (con != null)
					TSSJavaUtil.instance().freeConnection(con);
			}
			return "success";
		}
	}

	public String viewHlrConfig() {
		logger.info("viewHlrConfig() started ");
		int response = -1;
		this.linkName = "webadmin";
		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		} else {
			try {
				hlrManager = new HLRManager();
				hlrConfigAl = new ArrayList<HLR>();
				response = hlrManager
						.getHLRConfig(hlrConfigAl, bean.getHlrId());

				if (response == -1) {
					return "failure";
				}
				if (hlrConfigAl.size() == 1) {
					bean = hlrConfigAl.get(0);

				}

			} catch (Exception e) {
				logger.error("Exception inside viewHlrConfig(),,,,,", e);
				return "failure";
			} finally {
				hlrManager = null;
			}
			return "success";
		}
	}

	public String modifyHlrConfig() {
		logger.info("modifyHlrConfig() started " + bean.getHlrId());

		this.actionName = "viewAllHlrConfig.action?bean.hlrId=-1";
		this.linkName = "webadmin";
		int response = -1;
		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		} else {
			HttpServletRequest request = ServletActionContext.getRequest();
			HttpSession session = request.getSession();
			String user = ((SessionHistory) session
					.getAttribute("sessionHistory")).getUser();
			String roleName1 = ((SessionHistory) session
					.getAttribute("sessionHistory")).getRoleName();
			con = TSSJavaUtil.instance().getconnection();
			try {
				hlrManager = new HLRManager();
				if (TssStringUtill.ValidateParams(bean.getHlrIp(),
						"" + bean.getHlrPort(), bean.getLogin(),
						bean.getPassword(), "" + bean.getConn())) {
					response = hlrManager.updateHLRConfig(bean);
					if (response == 0) {
						this.setMessage(getText("webadmin.hlrConfig.modified"));
						historyDataBean = new HistoryDataBean();
						historyDataBean.setUser(user);
						historyDataBean.setAction(getText("hlrmanagement"));
						historyDataBean.setEvent("Modify");
						historyDataBean.setRole(roleName1);
						historyDataBean.setMsg("HLR Config for ["+bean.getHlrIp()+"] Modify [Success]");
						historyGenerator = new HistoryGenerator();
						historyGenerator.insertHistoryData(historyDataBean, con);
						
					} else {
						this.setMessage(getText("webadmin.hlrConfig.notmodified"));
						historyDataBean = new HistoryDataBean();
						historyDataBean.setUser(user);
						historyDataBean.setAction(getText("hlrmanagement"));
						historyDataBean.setEvent("Modify");
						historyDataBean.setRole(roleName1);
						historyDataBean.setMsg("HLR Config for ["+bean.getHlrIp()+"] Modify [Failed]");
						historyGenerator = new HistoryGenerator();
						historyGenerator.insertHistoryData(historyDataBean, con);
						
					}
				} else {
					this.setMessage(getText("webadmin.hlrConfig.notmodified"));
					historyDataBean = new HistoryDataBean();
					historyDataBean.setUser(user);
					historyDataBean.setAction(getText("hlrmanagement"));
					historyDataBean.setEvent("Modify");
					historyDataBean.setRole(roleName1);
					historyDataBean.setMsg("HLR Config for ["+bean.getHlrIp()+"] Modify [Failed]");
					historyGenerator = new HistoryGenerator();
					historyGenerator.insertHistoryData(historyDataBean, con);
				}

			} catch (Exception e) {
				logger.error("Exception inside modifyHlrConfig(),,,,,", e);
				return "failure";
			} finally {
				hlrManager = null;
				if (con != null)
					TSSJavaUtil.instance().freeConnection(con);
			}
			return "success";
		}
	}

	public String deleteHlrConfig() {
		logger.info("deleteHlrConfig() started  list size "
				+ (bean.getDeleteList()).size());
		this.actionName = "viewAllHlrConfig.action?bean.hlrId=-1";
		this.linkName = "webadmin";
		int response = -1;
		this.setMessage(getText("webadmin.hlrConfig.notdeleted"));
		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		} else {
			HttpServletRequest request = ServletActionContext.getRequest();
			HttpSession session = request.getSession();
			String user = ((SessionHistory) session
					.getAttribute("sessionHistory")).getUser();
			String roleName1 = ((SessionHistory) session
					.getAttribute("sessionHistory")).getRoleName();
			con = TSSJavaUtil.instance().getconnection();
			try {
				hlrManager = new HLRManager();
				response = hlrManager.deleteHLRConfig(bean.getDeleteList());
				if (response == 0){
					this.setMessage(getText("webadmin.hlrConfig.deleted"));
					historyDataBean = new HistoryDataBean();
					historyDataBean.setUser(user);
					historyDataBean.setAction(getText("hlrmanagement"));
					historyDataBean.setEvent("Delete");
					historyDataBean.setRole(roleName1);
					historyDataBean.setMsg("HLR Config for ID "+bean.getDeleteList()+" Delete [Success]");
					historyGenerator = new HistoryGenerator();
					historyGenerator.insertHistoryData(historyDataBean, con);
				}
			} catch (Exception e) {
				logger.error("Exception inside deleteHlrConfig(),,,,,", e);
				return "failure";
			} finally {
				hlrManager = null;
				if (con != null)
					TSSJavaUtil.instance().freeConnection(con);
			}
			return "success";
		}
	}

}
