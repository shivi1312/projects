/**
*
*@author MoHit
*
*/


package com.telemune.vcc.webadmin.action;

import java.util.ArrayList;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;

import com.telemune.vcc.common.ValidateAction;
import com.telemune.vcc.webadmin.HLR;
import com.telemune.vcc.webadmin.HLRManager;
import com.telemune.vcc.webadmin.HomeSubDetail;
import com.telemune.vcc.webadmin.HomeSubscriberManager;

public class HomeSubscriberAction extends ValidateAction{
	
	
	Logger logger=Logger.getLogger(HomeSubscriberAction.class);
	private HomeSubDetail bean=null;
	private String message="";
	ArrayList homeConfigAl=null;
	
	
	public HomeSubDetail getBean() {
		return bean;
	}
	public void setBean(HomeSubDetail bean) {
		this.bean = bean;
	}
	
	public ArrayList getHomeConfigAl() {
		return homeConfigAl;
	}
	public void setHomeConfigAl(ArrayList homeConfigAl) {
		this.homeConfigAl = homeConfigAl;
	}
	public String getMessage()
	{
		return message;
	}
	public void setMessage(String message)
	{
		this.message=message;
	}
	
	public String addHomeSubs()
	{
		logger.info("inside addHomeSubs()");
		if(!checkSession().equalsIgnoreCase("success"))
		{
			return "error";
		}
		else
		{
			HLRManager manager= null;
			try{
			manager= new HLRManager();
			homeConfigAl= new ArrayList<HLR>();
			manager.getHLRConfig(homeConfigAl, -1);
			return SUCCESS;
			}
			catch (Exception e) {
				 logger.error("Exception inside addHomeSubs(),,,,,",e);
				 return "failure";
			}
			finally
			{
				manager=null;
			}
		}

	}
	
	public String addHomeSubsExecute()
	{
		logger.info("inside addHomeSubsExecute");
		this.actionName="homeSubsViewModify.action?bean.rangeId=-1";
		this.linkName="webadmin";
		if(!checkSession().equalsIgnoreCase("success"))
		{
			return "error";
		}
		else
		{
			HomeSubscriberManager manager= new HomeSubscriberManager();
			ArrayList excludesAl = new ArrayList();
			StringTokenizer st = null;
			try{
			int result=-1;
			st = new StringTokenizer(bean.getExclusion()," ,\r\n");
			
			
            while(st.hasMoreTokens())
            {
                    excludesAl.add(st.nextToken());
            }
            bean.setExcludes(excludesAl);
			result=manager.addHomeSubscriber(bean);
			logger.info("result = "+result+" (0 for success)");
			System.out.println("result = "+result+" (0 for success)");
			if(result==0)
				setMessage(getText("webadmin.homeSubs.Created"));
			else if(result==-1)
				setMessage(getText("webadmin.homeSubs.notcreated"));
			else
				setMessage(getText("webadmin.homeSubs.already"));
			return SUCCESS;
			}
			catch (Exception e) {
				 logger.error("Exception inside addHomeSubsExecute(),,,,,",e);
				 return "failure";
			}
			finally
			{
				manager=null;
				excludesAl=null;
				st=null;
			}
		}
	}
	
	public String gethomeSubs()
	{

		logger.info("gethomeSubs() started ");
		int response=-1;
		this.linkName="webadmin";
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
			}
		    else{
		    	 HomeSubscriberManager manager= new HomeSubscriberManager();
		    	 HLRManager man= new HLRManager();
		    	 ArrayList<HLR> config=null;
				 try{
					 
					  homeConfigAl= new ArrayList<HomeSubDetail>();
					  response=manager.getHomeSubscriber(homeConfigAl,bean.getRangeId());
					  String ex="";
					  
					  for(int i=0;i<homeConfigAl.size();i++)
					  {
						  ex="";						  
						  /* old in which had bug						   
						  for(int j=0;j<((HomeSubDetail)(homeConfigAl.get(i))).getExcludes().size();j++)
						  {
						  ex+=((HomeSubDetail)(homeConfigAl.get(j))).getExcludes().get(j);
						  } 
						   */
						  		  
							  for(int j=0;j<((HomeSubDetail)(homeConfigAl.get(i))).getExcludes().size();j++)
							  {
								    //System.out.println("have SIZE so will add:"+((HomeSubDetail)(homeConfigAl.get(i))).getExcludes().get(j));
									ex+=((HomeSubDetail)(homeConfigAl.get(i))).getExcludes().get(j)+" ";							  							    
							  }						
						  
						  ((HomeSubDetail)(homeConfigAl.get(i))).setExclusion(ex);
						  config= new ArrayList<HLR>();
						 man.getHLRConfig(config,((HomeSubDetail)(homeConfigAl.get(i))).getHlrId());
						  ((HomeSubDetail)(homeConfigAl.get(i))).setHlrName(config.get(0).getHlrName());
						  
					  }
					  
					  
				      if(response==-1)
				      {
				    	return "failure";   
				      }
				      if(homeConfigAl.size()==1)
				      {
				    	  bean=(HomeSubDetail) homeConfigAl.get(0);
				    	  
						    	homeConfigAl= new ArrayList<HLR>();
								man.getHLRConfig(homeConfigAl, -1);
						   }
				      
					  }
				 catch(Exception e)
				  {
					 logger.error("Exception inside gethomeSubs(),,,,,",e);
					 return "failure";
				  }
				 finally
				 {
					 manager=null;
					 man=null;
					 config=null;
				 }
                return "success";
			}

	}



public String modifyhomeSubs()
{
	logger.info("modifyhomeSubs() started "+bean.getRangeId());
	this.actionName="homeSubsViewModify.action?bean.rangeId=-1";
	this.linkName="webadmin";
	int response=-1;
	if(!checkSession().equalsIgnoreCase("success")){
		return "error";
		}
	    else{
			 try{
				  HomeSubscriberManager manager= new HomeSubscriberManager();
				  
				 // if(TssStringUtill.ValidateParams(bean.getUserId(),bean.getPassword(),bean.getNumOfConAllow()+"",bean.getSmscIP(),bean.getSmscPort()+"",bean.getSmscStatus(),bean.getSpeed()+"",bean.getSystemType(),bean.getTon()+""))
				  //{
				  
				  StringTokenizer st = new StringTokenizer(bean.getExclusion()," ,\r\n");
					
					ArrayList excludesAl = new ArrayList();
		            while(st.hasMoreTokens())
		            {
		                    excludesAl.add(st.nextToken());
		            }
		            bean.setExcludes(excludesAl);
					  response=manager.updateHomeSubscriber(bean);
					  if(response==0)
					  this.setMessage(getText("webadmin.homeSubs.modified"));
					  else
						  this.setMessage(getText("webadmin.homeSubs.notmodified"));
				  }
			 catch(Exception e)
			  {
				 logger.error("Exception inside modifyhomeSubs(),,,,,",e);
				 return "failure";
			  }
            return "success";
		}
}



public String deletehomeSubs()
{
	logger.info("deletehomeSubs() started  list size "+homeConfigAl.size());
	this.actionName="homeSubsViewModify.action?bean.rangeId=-1";
	this.linkName="webadmin";
	int response=-1;
	 this.setMessage(getText("webadmin.homeSubs.notdeleted"));
	if(!checkSession().equalsIgnoreCase("success")){
		return "error";
		}
	    else{
			 try{
				  HomeSubscriberManager manager= new HomeSubscriberManager();
					  response=manager.deleteHomeSubscriber(homeConfigAl);
					  if(response==0)
					  this.setMessage(getText("webadmin.homeSubs.deleted"));
					  
				  }
			 catch(Exception e)
			  {
				 logger.error("Exception inside deletehomeSubs(),,,,,",e);
				 return "failure";
			  }
            return "success";
		}
}

}

