/**
*
*@author MoHit
*
*/


package com.telemune.vcc.webadmin.action;

import java.util.ArrayList;
import org.apache.log4j.Logger;

import com.telemune.vcc.common.ValidateAction;
import com.telemune.vcc.webadmin.IMSI;
import com.telemune.vcc.webadmin.IMSIManager;

public class IMSIConfigAction extends ValidateAction{
	
	
	Logger logger=Logger.getLogger(IMSIConfigAction.class);
	private IMSI bean=new IMSI();
	private String message="No Message";
	ArrayList imsiConfigAl=null;
	IMSIManager manager= null;

	
	public IMSI getBean() {
		return bean;
	}
	public void setBean(IMSI bean) {
		this.bean = bean;
	}
	public ArrayList getImsiConfigAl() {
		return imsiConfigAl;
	}
	public void setImsiConfigAl(ArrayList imsiConfigAl) {
		this.imsiConfigAl = imsiConfigAl;
	}
	public String getMessage()
	{
		return message;
	}
	public void setMessage(String message)
	{
		this.message=message;
	}
	
	public String addImsiConfig()
	{
		logger.debug("inside addImsiConfig()");
		this.actionName="imsiConfigViewModify.action?bean.rangeId=X";
		this.linkName="webadmin";
		if(!checkSession().equalsIgnoreCase("success"))
		{
			return "error";
		}
		else
		{
			
			try{
				manager= new IMSIManager();
			int result=-1;
			result=manager.addIMSIConfig(bean);
			logger.info("result = "+result+" (0 for success)");
			if(result==0)
				setMessage(getText("webadmin.imsiConfig.Created"));
			else if(result==-2)
				setMessage(getText("webadmin.imsiConfig.already"));
			else
				setMessage(getText("webadmin.imsiConfig.notcreated"));
			}
			catch (Exception e) {
				logger.error("Exception inside addImsiConfig(),,,,,",e);
				 return "failure";
			}
			finally
			{
				manager=null;
			}
			return SUCCESS;
		}
	}
	
	public String getImsiConfig()
	{

		logger.info("getImsicConfig() started ");
		int response=-1;
		this.linkName="webadmin";
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
			}
		    else{
				 try{
					  manager= new IMSIManager();
					  imsiConfigAl= new ArrayList<IMSI>();
					  response=manager.getIMSIConfig(imsiConfigAl, bean.getRangeId());
					  
				      if(response==-1)
				      {
				    	return "failure";   
				      }
				      if(imsiConfigAl.size()==1)
				      {
				    	  bean=(IMSI) imsiConfigAl.get(0);
				     }
				      
					  }
				 catch(Exception e)
				  {
					 logger.error("Exception inside getImsiConfig(),,,,,",e);
					 return "failure";
				  }
				 finally
					{
						manager=null;
					}
                return "success";
			}

	}



public String modifyImsiConfig()
{
	logger.info("modifyImsiConfig() started "+bean.getRangeId());
	this.actionName="imsiConfigViewModify.action?bean.rangeId=X";
	this.linkName="webadmin";
	int response=-1;
	if(!checkSession().equalsIgnoreCase("success")){
		return "error";
		}
	    else{
			 try{
				  manager= new IMSIManager();
				  
					  response=manager.updateIMSIConfig(bean);
					  if(response==0)
					  this.setMessage(getText("webadmin.imsiConfig.modified"));
					  else
						  this.setMessage(getText("webadmin.imsiConfig.notmodified"));
				
				  }
			 catch(Exception e)
			  {
				 logger.error("Exception inside modifyImsiConfig(),,,,,",e);
				 return "failure";
			  }finally
				{
					manager=null;
				}
            return "success";
		}
}



public String deleteImsiConfig()
{
	logger.info("deleteImsiConfig() started  list size "+imsiConfigAl.size());
	this.actionName="imsiConfigViewModify.action?bean.rangeId=X";
	this.linkName="webadmin";
	int response=-1;
	 this.setMessage(getText("webadmin.imsiConfig.notdeleted"));
	if(!checkSession().equalsIgnoreCase("success")){
		return "error";
		}
	    else{
			 try{
				  manager= new IMSIManager();
					  response=manager.deleteIMSIConfig(imsiConfigAl);
					  if(response==0)
					  this.setMessage(getText("webadmin.imsiConfig.deleted"));
					  
				
				  }
			 catch(Exception e)
			  {
				 logger.error("Exception inside deleteImsiConfig(),,,,,",e);
				 return "failure";
			  }
			 finally
				{
					manager=null;
				}
            return "success";
		}
}

}

