package com.telemune.vcc.webadmin.action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;

import com.telemune.dbutilities.Connection;
import com.telemune.vcc.common.HistoryGenerator;
import com.telemune.vcc.common.SessionHistory;
import com.telemune.vcc.common.TSSJavaUtil;
import com.telemune.vcc.common.ValidateAction;
import com.telemune.vcc.crbtcontent.TssStringUtill;
import com.telemune.vcc.model.HistoryDataBean;
import com.telemune.vcc.webadmin.MailBox;
import com.telemune.vcc.webadmin.MailBoxManager;

public class MailBoxAction extends ValidateAction {
	Logger logger = Logger.getLogger(MailBoxAction.class);
	private MailBox bean;
	private ArrayList<MailBox> mailBoxConfigAl = null;
	private String message;
	MailBoxManager mailBoxManager = null;
	HistoryDataBean historyDataBean = null;
	HistoryGenerator historyGenerator = null;
	Connection con = null;

	public MailBox getBean() {
		return bean;
	}

	public void setBean(MailBox bean) {
		this.bean = bean;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public ArrayList<MailBox> getMailBoxConfigAl() {
		return mailBoxConfigAl;
	}

	public void setMailBoxConfigAl(ArrayList<MailBox> mailBoxConfigAl) {
		this.mailBoxConfigAl = mailBoxConfigAl;
	}

	public String addMailBox() {

		this.actionName = "viewAllMailBox.action?bean.MailBoxId=-1";
		this.linkName = "webadmin";
		// logger.info("addMailBoxConfig() started with MailBox Name ["+bean.getMailBoxName()+"]");
		int response = -1;
		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		} else {
			HttpServletRequest request = ServletActionContext.getRequest();
			HttpSession session = request.getSession();
			String user = ((SessionHistory) session
					.getAttribute("sessionHistory")).getUser();
			String roleName1 = ((SessionHistory) session
					.getAttribute("sessionHistory")).getRoleName();
			con = TSSJavaUtil.instance().getconnection();
			try {
				
				mailBoxManager = new MailBoxManager();

				if (TssStringUtill.ValidateParams(bean.getMailBoxType(), ""
						+ bean.getMaxMessage(), "" + bean.getMaxRecordTime(),
						"" + bean.getMgsTimAftrSav(),
						"" + bean.getMsgLifetime(),
						"" + bean.getMsgTimeAftrRet())) {
					response = mailBoxManager.addMailBoxDetail(bean);
					if (response == 0) {
						this.setMessage(getText("webadmin.mailBox.Created"));
						historyDataBean = new HistoryDataBean();
						historyDataBean.setUser(user);
						historyDataBean.setAction(getText("mailboxmanagement"));
						historyDataBean.setEvent("Add");
						historyDataBean.setRole(roleName1);
						historyDataBean.setMsg("Mail Box Config ["
								+ bean.getMailBoxType()+ "] Add [Success]");
						historyGenerator = new HistoryGenerator();
						historyGenerator.insertHistoryData(historyDataBean, con);
						
					} else if (response == -2) {
						this.setMessage(getText("webadmin.mailBox.already"));
						historyDataBean = new HistoryDataBean();
						historyDataBean.setUser(user);
						historyDataBean.setAction(getText("mailboxmanagement"));
						historyDataBean.setEvent("Add");
						historyDataBean.setRole(roleName1);
						historyDataBean.setMsg("Mail Box Config ["
								+ bean.getMailBoxType()+ "] Add [Already Exist]");
						historyGenerator = new HistoryGenerator();
						historyGenerator.insertHistoryData(historyDataBean, con);
					} else {
						this.setMessage(getText("webadmin.mailBox.notcreated"));
						historyDataBean = new HistoryDataBean();
						historyDataBean.setUser(user);
						historyDataBean.setAction(getText("mailboxmanagement"));
						historyDataBean.setEvent("Add");
						historyDataBean.setRole(roleName1);
						historyDataBean.setMsg("Mail Box Config ["
								+ bean.getMailBoxType()+ "] Add [Failed]");
						historyGenerator = new HistoryGenerator();
						historyGenerator.insertHistoryData(historyDataBean, con);
					}
				} else {
					this.setMessage(getText("webadmin.mailBox.notcreated"));
					historyDataBean = new HistoryDataBean();
					historyDataBean.setUser(user);
					historyDataBean.setAction(getText("mailboxmanagement"));
					historyDataBean.setEvent("Add");
					historyDataBean.setRole(roleName1);
					historyDataBean.setMsg("Mail Box Config ["
								+ bean.getMailBoxType()+ "] Add [Failed]");
					historyGenerator = new HistoryGenerator();
					historyGenerator.insertHistoryData(historyDataBean, con);
				}

			} catch (Exception e) {
				this.setMessage(getText("webadmin.mailBox.notcreated"));
				logger.error("Exception inside addMailBoxConfig(),,,,,", e);
			} finally {
				mailBoxManager = null;
				if (con != null)
					TSSJavaUtil.instance().freeConnection(con);
			}
			return "success";
		}
	}

	public String viewMailBoxDetails() {
		MailBox mailBox = new MailBox();
		logger.info("viewMailBoxDetail() started ");
		int response = -1;
		this.linkName = "webadmin";
		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		} else {
			try {
				mailBoxManager = new MailBoxManager();
				mailBoxConfigAl = new ArrayList();
				response = mailBoxManager.getMailBoxDetail(mailBoxConfigAl,
						bean.getMailBoxId());

				if (mailBoxConfigAl.contains(bean.getMailBoxType()
						.toUpperCase())) {
					logger.info("Already exist");
				}

				if (response == -1) {
					return "failure";
				}
				if (mailBoxConfigAl.size() == 1) {
					bean = mailBoxConfigAl.get(0);

				}

			} catch (Exception e) {
				logger.error("Exception inside viewMailBoxConfig(),,,,,", e);
				return "failure";
			} finally {
				mailBoxManager = null;
			}
			return "success";
		}
	}

	public String modifyMailBoxDetails() {
		logger.info("modifyMailBoxDetails() started " + bean.getMailBoxId());

		this.actionName = "viewAllMailBox.action?bean.MailBoxId=-1";
		this.linkName = "webadmin";
		int response = -1;
		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		} else {
			HttpServletRequest request = ServletActionContext.getRequest();
			HttpSession session = request.getSession();
			String user = ((SessionHistory) session
					.getAttribute("sessionHistory")).getUser();
			String roleName1 = ((SessionHistory) session
					.getAttribute("sessionHistory")).getRoleName();
			con = TSSJavaUtil.instance().getconnection();
			try {
				mailBoxManager = new MailBoxManager();
				if (TssStringUtill
						.ValidateParams("" + bean.getMaxMessage(),
								"" + bean.getMaxRecordTime(),
								"" + bean.getMgsTimAftrSav(),
								"" + bean.getMsgLifetime(),
								"" + bean.getMsgTimeAftrRet(),
								"" + bean.getMailBoxId())) {
					response = mailBoxManager.updateMAilBox(bean);
					if (response == 0) {
						this.setMessage(getText("webadmin.mailBox.modified"));
						historyDataBean = new HistoryDataBean();
						historyDataBean.setUser(user);
						historyDataBean.setAction(getText("mailboxmanagement"));
						historyDataBean.setEvent("Modify");
						historyDataBean.setRole(roleName1);
						historyDataBean.setMsg("Mail Box Config ["
								+ bean.getMailBoxId() +"] Modify [Success]");
						historyGenerator = new HistoryGenerator();
						historyGenerator
								.insertHistoryData(historyDataBean, con);
					} else {
						this.setMessage(getText("webadmin.mailBox.notmodified"));
						historyDataBean = new HistoryDataBean();
						historyDataBean.setUser(user);
						historyDataBean.setAction(getText("mailboxmanagement"));
						historyDataBean.setEvent("Modify");
						historyDataBean.setRole(roleName1);
						historyDataBean.setMsg("Mail Box Config ["
								+ bean.getMailBoxId()+ "] Modify [Failed]");
						historyGenerator = new HistoryGenerator();
						historyGenerator
								.insertHistoryData(historyDataBean, con);
					}
				} else {
					this.setMessage(getText("webadmin.mailBox.notmodified"));
					historyDataBean = new HistoryDataBean();
					historyDataBean.setUser(user);
					historyDataBean.setAction(getText("mailboxmanagement"));
					historyDataBean.setEvent("Modify");
					historyDataBean.setRole(roleName1);
					historyDataBean.setMsg("Mail Box Config ["
							+ bean.getMailBoxId() + "] Modify [Failed]");
					historyGenerator = new HistoryGenerator();
					historyGenerator.insertHistoryData(historyDataBean, con);
				}

			} catch (Exception e) {
				logger.error("Exception inside modifyMailBoxConfig(),,,,,", e);
				return "failure";
			} finally {
				mailBoxManager = null;
				if (con != null)
					TSSJavaUtil.instance().freeConnection(con);
			}
			return "success";
		}
	}

	public String deleteMailBox() {
		logger.info("deleteMailBox() started  list size "
				+ (bean.getDeleteList()).size());
		this.actionName = "viewAllMailBox.action?bean.MailBoxId=-1";
		this.linkName = "webadmin";
		int response = -1;
		this.setMessage(getText("webadmin.mailBox.notdeleted"));
		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		} else {
			HttpServletRequest request = ServletActionContext.getRequest();
			HttpSession session = request.getSession();
			String user = ((SessionHistory) session
					.getAttribute("sessionHistory")).getUser();
			String roleName1 = ((SessionHistory) session
					.getAttribute("sessionHistory")).getRoleName();
			con = TSSJavaUtil.instance().getconnection();
			try {
				mailBoxManager = new MailBoxManager();
				response = mailBoxManager.deleteMailBox(bean.getDeleteList());
				if (response == 0) {
					this.setMessage(getText("webadmin.mailBox.deleted"));

					historyDataBean = new HistoryDataBean();
					historyDataBean.setUser(user);
					historyDataBean.setAction(getText("mailboxmanagement"));
					historyDataBean.setEvent("delete");
					historyDataBean.setRole(roleName1);
					historyDataBean.setMsg("Mail Box Config "
							+ bean.getDeleteList() + " Deleted [Success]");
					historyGenerator = new HistoryGenerator();
					historyGenerator.insertHistoryData(historyDataBean, con);
				}

			} catch (Exception e) {
				logger.error("Exception inside deleteMailBox,,,,,", e);
				return "failure";
			} finally {
				mailBoxManager = null;
				if (con != null)
					TSSJavaUtil.instance().freeConnection(con);
			}
			return "success";
		}
	}

}
