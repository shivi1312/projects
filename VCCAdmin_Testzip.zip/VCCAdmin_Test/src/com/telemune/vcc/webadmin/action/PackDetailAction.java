package com.telemune.vcc.webadmin.action;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.telemune.vcc.common.ValidateAction;
import com.telemune.vcc.webadmin.ActiveInterfaceBean;
import com.telemune.vcc.webadmin.CampaignListBean;
import com.telemune.vcc.webadmin.ChargingCodeDetail;
import com.telemune.vcc.webadmin.IsDefault;
import com.telemune.vcc.webadmin.PackManager;
import com.telemune.vcc.webadmin.PackScope;
import com.telemune.vcc.webadmin.RatePlanManagerNew;
import com.telemune.vcc.webadmin.RbtSetting;
import com.telemune.vcc.webadmin.ScopeBean;
import com.telemune.vcc.webadmin.SubvalidFor;
import com.telemune.vcc.webadmin.TemplateSMS;
import com.telemune.vcc.webadmin.UserScope;
import com.telemune.vcc.webadmin.ValidFor;


/**
 * 
 * @author success
 * This class is responsible to manage creating new, updating existing, deleting and modify
 * fall-back based pack deatils System for CRBT-System.
 *
 */
public class PackDetailAction extends ValidateAction {
	
	private static final long serialVersionUID = 1L;
	
	private Logger logger=Logger.getLogger(PackDetailAction.class);
	

	{
		this.actionName="rateManage.action?bean.searchtext=";
		setLinkName("webadmin");
	}
	
	private ArrayList<ScopeBean> scopeList=null;
	public ArrayList<ScopeBean> getScopeList() {
		return scopeList;
	}
	public void setScopeList(ArrayList<ScopeBean> scopeList) {
		this.scopeList = scopeList;
	}

	private String message;
	int status=1;
	//private String maskedName;
	
	private List<ChargingCodeDetail> chargingCodeList;
	private List<TemplateSMS> templateSMSList;
	
	//private List<CrbtRatePlanBean> crbtRatePlanList;
	
	private List<CampaignListBean> campaignList; 
	
	private List<PackSubNewBean> crbtPackList; 
	private List<ActiveInterfaceBean> activeInterfaceList;
	private List<ValidFor> validForList; 
	private List<SubvalidFor> subValidForList; 
	private List<UserScope> userScopeList;
	private List<PackScope> packScopeList;
	private List<RbtSetting> rbtSettingList;
	private List<IsDefault>  isDefaultList;
	private List<ActiveInterfaceBean> activeInterfacesListFm;
	private List<ActiveInterfaceBean> nonActiveInterfaceList;
	
	//private Map<String,CrbtRatePlanBean> crbtRatePlanMap;
	
	private Map<Integer,String> chgCodeMap;
	
	private PackSubNewBean packSubNewBean;
	private RatePlanBeanNew rateplan;
	private PackSubBean packsub;
	
	//private CrbtRatePlanBean crbtRateplanBean;
	
	private String actionType;
	private Integer packId;
	
	
	
	//by Harjinder
	
	
	
	
	
	
	
	public PackSubBean getPacksub() {
		return packsub;
	}
	
	public List<ActiveInterfaceBean> getNonActiveInterfaceList() {
		return nonActiveInterfaceList;
	}
	public void setNonActiveInterfaceList(
			List<ActiveInterfaceBean> nonActiveInterfaceList) {
		this.nonActiveInterfaceList = nonActiveInterfaceList;
	}
	public List<ActiveInterfaceBean> getActiveInterfacesListFm() {
		return activeInterfacesListFm;
	}
	public void setActiveInterfacesListFm(
			List<ActiveInterfaceBean> activeInterfacesListFm) {
		this.activeInterfacesListFm = activeInterfacesListFm;
	}
	public List<IsDefault> getIsDefaultList() {
		return isDefaultList;
	}
	public void setIsDefaultList(List<IsDefault> isDefaultList) {
		this.isDefaultList = isDefaultList;
	}
	public List<RbtSetting> getRbtSettingList() {
		return rbtSettingList;
	}
	public void setRbtSettingList(List<RbtSetting> rbtSettingList) {
		this.rbtSettingList = rbtSettingList;
	}
	public List<PackScope> getPackScopeList() {
		return packScopeList;
	}
	public void setPackScopeList(List<PackScope> packScopeList) {
		this.packScopeList = packScopeList;
	}
	public List<UserScope> getUserScopeList() {
		return userScopeList;
	}
	public void setUserScopeList(List<UserScope> userScopeList) {
		this.userScopeList = userScopeList;
	}
	public List<SubvalidFor> getSubValidForList() {
		return subValidForList;
	}
	public void setSubValidForList(List<SubvalidFor> subValidForList) {
		this.subValidForList = subValidForList;
	}
	public List<ValidFor> getValidForList() {
		return validForList;
	}
	public void setValidForList(List<ValidFor> validForList) {
		this.validForList = validForList;
	}
	public List<ActiveInterfaceBean> getActiveInterfaceList() {
		return activeInterfaceList;
	}
	public void setActiveInterfaceList(List<ActiveInterfaceBean> activeInterfaceList) {
		this.activeInterfaceList = activeInterfaceList;
	}
	public Integer getPackId() {
		return packId;
	}
	public void setPackId(Integer packId) {
		this.packId = packId;
	}
	public PackSubNewBean getPackSubNewBean() {
		return packSubNewBean;
	}
	public void setPackSubNewBean(PackSubNewBean packSubNewBean) {
		this.packSubNewBean = packSubNewBean;
	}
	public List<PackSubNewBean> getCrbtPackList() {
		return crbtPackList;
	}
	public void setCrbtPackList(List<PackSubNewBean> crbtPackList) {
		this.crbtPackList = crbtPackList;
	}
	public void setPacksub(PackSubBean packsub) {
		this.packsub = packsub;
	}
	//end
	
	public List<CampaignListBean> getCampaignList() {
		return campaignList;
	}
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
 
	public List<TemplateSMS> getTemplateSMSList() {
		return templateSMSList;
	}
	public void setTemplateSMSList(List<TemplateSMS> templateSMSList) {
		this.templateSMSList = templateSMSList;
	}
	
	public List<ChargingCodeDetail> getChargingCodeList() {
		return chargingCodeList;
	}
	public void setChargingCodeList(List<ChargingCodeDetail> chargingCodeList) {
		this.chargingCodeList = chargingCodeList;
	}
	
		public RatePlanBeanNew getRateplan() {
		return rateplan;
	}
	public void setRateplan(RatePlanBeanNew rateplan) {
		this.rateplan = rateplan;
	}
	
	
	/*public List<CrbtRatePlanBean> getCrbtRatePlanList() {
		return crbtRatePlanList;
	}
	public void setCrbtRatePlanList(List<CrbtRatePlanBean> crbtRatePlanList) {
		this.crbtRatePlanList = crbtRatePlanList;
	}*/
	
	/*public String getMaskedName() {
		return maskedName;
	}
	public void setMaskedName(String maskedName) {
		this.maskedName = maskedName;
	}
	*/
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	
	
	
	public String getActionType() {
		return actionType;
	}
	public void setActionType(String actionType) {
		this.actionType = actionType;
	}
	// TODO Auto-generated constructor stub

	
	
	public Map<Integer, String> getChgCodeMap() {
		return chgCodeMap;
	}
	public void setChgCodeMap(Map<Integer, String> chgCodeMap) {
		this.chgCodeMap = chgCodeMap;
	}
	
	
	public String isPackNameExists(){
		PackManager packManager=new PackManager();
		logger.info("action isPackNameExists = PACK_NAME="+packsub.getPackName());
		try{
		 if(packManager.isPackNameExists(packsub.getPackName())){
			 logger.info(" PacName =["+packsub.getPackName()+"] all-ready exists!!");
			  return ERROR;	 
			 	 
		 }else{
			 logger.info(" PackName =["+packsub.getPackName()+"]  is unique!!");
			 message="OK";
			 return SUCCESS;
		 }
		 
		}catch (Exception e) {
			e.printStackTrace();
			return ERROR;
		}
	}//### END of isPackNameExists()
	
	
	/**
	 * @author 
	 * 
	 *         This method is called at Initial stage of Application loading and
	 *         populate private List<ChargingCodeDetail> chargingCodeList;
	 *         private List<TemplateSMS> templateSMSList;
	 *  
	 * @return java.lang.String success = request is successful error = if
	 *         operation failed due to any ERROR
	 */
	public String populateChgCodeAndTemplate(){
		if (!checkSession().equalsIgnoreCase("success")) {
			return checkSession();

		} else {
			RatePlanManagerNew rpManager=new RatePlanManagerNew();
			PackManager pm=new PackManager();
			try{
				chargingCodeList=rpManager.getChargingCodeList();
				templateSMSList=rpManager.getSMSTemplateList();
				//campaignList=pm.getCampaignList();
				logger.info(" CHARGING_CODES="+chargingCodeList);
				logger.info(" SMS_TEMPLATES="+templateSMSList.size());
			}catch (Exception e) {
				logger.error("ERROR in processing chargingCode List!",e);
				return ERROR;
			}
		}
		return SUCCESS;
	}/// ### END of populateChgCodeAndTemplate () ###//
	
	
	/**
	 * Method is responsible of forming the different String of packDetail
	 * Features.
	 *  PACK_ID,
	 *  PACK_NAME, 
	 *  SUB_FB_CHG_CODE,
	 *  SUB_RENEW_FB_CHG_CODE,
	 *  VALID_FOR,
	 *  SUBSCRIBER,
	 *  RBT_FB_CHG_CODE,
	 *  GIFT_FB_CHG_CODE,
	 *  REC_FB_CHG_CODE,
	 *  OFFER_VALIDITY,
	 *  PRIORITY,
	 *  SMS_COMMAND,
	 *  USSD_COMMAND,
	 *  IVR_PROMPT_PATH,
	 *  IVR_SHORT_CODE,
	 *  ACTIVE_ON_INTERFACE
	 *  STATUS,
	 *  MAX_RBT_IN_WALLET,
	 *  SCOPE,
	 *  RBT_SETTING,
	 *  IS_DEFAULT_PACK,
	 *  REMARKS,
	 *  START_DATE,
	 *  END_DATE,
	 *  LIST_ID,
	 *  FREE_RBT_CHG_STRING
	 *  
	 *  
	 *  
	 * after that calling addPack(PackSubNewBean packSubNew) method from PackManager class
	 * and insert new Pack to CRBT_PACK_DETAIL 
	 * 
	 * Forming of String comprises of following sub operation:-
	 * 1- Access list of all Feature Fall-back Rate-plan
	 * 2- Sort Feature Fall-back rate-plan as per validity days of Charging-Codes
	 * 3- Form the string of Fallback Features
	 * 4- Papulating PackSubNewBean packSubNew 
	 * 5- Call the addPack() method of PackManager
	 * 6- Return final response to presentation layer.  
	 * 
	 * @return String SUCCESS=success, ERROR=error
	 */
	
	
	

	/**
	 * 
	 * To add new Pack 
	 * 
	 * */
	
	public String addPack(){
		if (!checkSession().equalsIgnoreCase("success")) {
			return checkSession();
		} else  if( packsub!=null && (!packsub.getPackName().trim().equalsIgnoreCase("")) ){
		
			 String subFbChgCode=""; //used
			 String freeFbChgCode="";
			 String rbtFbChgCode="";
			 String giftFbChgCode="";
			 String recFbChgCode="";
			 String subRenewFbChgCode="";
			 String activeInterface="";
			 
			 boolean subFlag=false;
			 boolean subRenewFlag=false;
			 boolean rbtFlag=false;
			 boolean freeFlag=false;
			 boolean giftFlag=false;
			 boolean recFlag=false;
			 
			try{System.out.println("No of Free Rbts Details = "+packsub.getRbtPurchaseDetails());
				
				logger.info(" ###########################################");
				logger.info(" PACKE_NAME ="+packsub.getPackName());
				logger.info("subscriptionDetails = "+packsub.getSubscriptionDetails());
				logger.info("subscriptionRenewDetails = "+packsub.getSubscriptionRenewDetails());
				logger.info("rbtPurchaseDetails = "+packsub.getRbtPurchaseDetails());
				logger.info("rbtRecordingDetails ="+packsub.getRbtRecordingDetails());
				logger.info("rbtGiftDetails = "+packsub.getRbtGiftDetails());
				logger.info("freeRbtDetails = "+packsub.getFreeRbtDetails());
				logger.info("campaignId = "+packsub.getCampaignId());
				logger.info("ValidFor = "+packsub.getValidFor());
				logger.info("subValidFor = "+packsub.getSubValidFor());
				logger.info("offerValidFor = "+packsub.getOfferValidFor());
				logger.info("packStatus = "+packsub.getPackScope());
				logger.info("priority = "+packsub.getPriority());
				logger.info("smsCommand = "+packsub.getSmsCommand());
				logger.info("ussdCommand = "+packsub.getUssdCommand());
				logger.info("ivrPath = "+packsub.getIvrPath());
				logger.info("ivrShortCode = "+packsub.getIvrShortCode());
				logger.info("maxWalletRbt = "+packsub.getMaxWalletRbt());
				logger.info("isDefault = "+packsub.getIsDefaultPack());
				logger.info("remark = "+packsub.getRemark());
				logger.info("sms = "+packsub.getSms());
				logger.info("Ivr = "+packsub.getIvr());
				logger.info("web = "+packsub.getWeb());
				logger.info("ussd = "+packsub.getUssd());
				logger.info("obd = "+packsub.getObd());
				logger.info("userSCope = "+packsub.getUserScope());
				logger.info("rbtSetting = "+packsub.getRbtSetting());
				logger.info("Start Time = "+packsub.getStart());
				logger.info("End Time = "+packsub.getEnd());
				
				
				
				
				
				System.out.println(" PACK_NAME ="+packsub.getPackName());
				System.out.println("===========================================================================");
				System.out.println("subscriptionDetails = "+packsub.getSubscriptionDetails());
				System.out.println("subscriptionRenewDetails = "+packsub.getSubscriptionRenewDetails());
				System.out.println("rbtPurchaseDetails = "+packsub.getRbtPurchaseDetails());
				System.out.println("rbtRecordingDetails ="+packsub.getRbtRecordingDetails());
				System.out.println("rbtGiftDetails = "+packsub.getRbtGiftDetails());
				System.out.println("freeRbtDetails = "+packsub.getFreeRbtDetails());
				System.out.println("campaignId = "+packsub.getCampaignId());
				System.out.println("ValidFor = "+packsub.getValidFor());
				System.out.println("subValidFor = "+packsub.getSubValidFor());
				System.out.println("offerValidFor = "+packsub.getOfferValidFor());
				System.out.println("packStatus = "+packsub.getPackScope());
				System.out.println("priority = "+packsub.getPriority());
				System.out.println("smsCommand = ["+packsub.getSmsCommand()+"]");
				System.out.println("ussdCommand = ["+packsub.getUssdCommand()+"]");
				System.out.println("ivrPath = "+packsub.getIvrPath());
				System.out.println("ivrShortCode = "+packsub.getIvrShortCode());
				System.out.println("maxWalletRbt = "+packsub.getMaxWalletRbt());
				System.out.println("isDefault = "+packsub.getIsDefaultPack());
				System.out.println("remark = "+packsub.getRemark());
				System.out.println("sms = "+packsub.getSms());
				System.out.println("Ivr = "+packsub.getIvr());
				System.out.println("web = "+packsub.getWeb());
				System.out.println("ussd = "+packsub.getUssd());
				System.out.println("obd = "+packsub.getObd());
				System.out.println("userSCope = "+packsub.getUserScope());
				System.out.println("rbtSetting = "+packsub.getRbtSetting());
				System.out.println("Start Time = "+packsub.getStart());
				System.out.println("End Time = "+packsub.getEnd());
								
				
				
				activeInterface=getActiveInterface(packsub);
				System.out.println("Active Interfaces :"+activeInterface);
				logger.info("Active Interfaces :"+activeInterface);
					
				
				
				
				
				
				logger.info("===========================================================================");
				
				
				SubscriptionDetail subDetail=null;
				//Removing null Entries
				while(packsub.getSubscriptionDetails().remove(null));
				//Sorting by validity Days
				
				
				Collections.sort(packsub.getSubscriptionDetails(), new RatePlanValidityComparator());
				
			    
				for (int i = 0; i < packsub.getSubscriptionDetails().size(); i++) {
					
					subDetail = packsub.getSubscriptionDetails().get(i);
					
					if (subDetail != null && subDetail.getChargingCode() != 0) {
                        subFlag=true;    
						subFbChgCode += RatePlanTags.CHARGE_CODE_TAG + ":"+ subDetail.getChargingCode() + ","
								+ RatePlanTags.VALIDITY_DAYS_TAG + ":"+ subDetail.getValidity();

						//if (validateList(packsub.getSubscriptionDetails(),(i+1))) {
						//	subFbChgCode += ";";
						//}
					//new 
						
					}
					
					if(subDetail.getChargingCode()==0 || subDetail.getChargingCode()!=0)
					{
						if (validateList(packsub.getSubscriptionDetails(),(i+1))) {
							if(subDetail.getChargingCode()==0 && i==0)
							{
								subFbChgCode="";
										
							} 			
						else
						   {
							 if(subDetail.getChargingCode()==0 && i>0)
							 {
							//	 System.out.println("TRUEEEEEEEEEEEEEEEEEEEEEEEEEE["+i+"]");
								 if("".equalsIgnoreCase(subFbChgCode) || subFbChgCode==null || subFbChgCode.lastIndexOf(";")==subFbChgCode.length()-1)
								 {
									 //donothing
								 }
								 else
								 {
									 subFbChgCode += ";";
								 }	 
							 }
							 else
							 {	 
							 //   System.out.println("Inside else["+i+"]");                             							
							    subFbChgCode += ";";
							 }   
						   }  
						 }
					}
				
				}
				if(!subFlag)
				{
					subFbChgCode="NA";
				}	
				
               
				logger.info("subFbChgCode =["+subFbChgCode+"]");
				System.out.println("subFbChgCode =["+subFbChgCode+"]");
				
				logger.info("########################################");
				
				System.out.println("Size of getSubscriptionDetails:["+packsub.getSubscriptionRenewDetails().size()+"]");
				logger.info("##### fromation of subRenewFbChgCode ####");
				SubscriptionRenewDetail subRenewDetail=null;
				//Removing null Entries
				while(packsub.getSubscriptionRenewDetails().remove(null));
				
				//Sorting by validity Days
				Collections.sort(packsub.getSubscriptionRenewDetails(), new Comparator<SubscriptionRenewDetail>() {
					@Override
					public int compare(SubscriptionRenewDetail o1,
							SubscriptionRenewDetail o2) {
						if (o1== null && o2 == null) return 0;
				         if (o1 == null) return true? 1 : -1;
				         if (o2== null) return true? -1 : 1;
						return (o1.getValidity()>o2.getValidity() ? -1 : (o1.getValidity()==o2.getValidity() ? 0 : 1));
					}
				});
				//###
				for(int i=0;i<packsub.getSubscriptionRenewDetails().size();i++)
				{
				//###
					
					//###
					subRenewDetail=packsub.getSubscriptionRenewDetails().get(i);
					//###
					if(subRenewDetail!=null && subRenewDetail.getChargingCode()!=0)
					{	
						subRenewFlag=true;
						if(subRenewDetail.getRenewSuccessTemplateID()==0)
						{
							subRenewDetail.setRenewSuccessTemplateID(-99);
							
						}
						if(subRenewDetail.getRenewFailedTemplateID()==0)
						{
							subRenewDetail.setRenewFailedTemplateID(-99);
						}	
					    subRenewFbChgCode+=RatePlanTags.CHARGE_CODE_TAG+":"+subRenewDetail.getChargingCode()+","
											+RatePlanTags.VALIDITY_DAYS_TAG+":"+subRenewDetail.getValidity()+","
											+RatePlanTags.SUCCESS_TEMPLATE_TAG+":"+subRenewDetail.getRenewSuccessTemplateID()+","
											+RatePlanTags.FAILURE_TEMPLATE_TAG+":"+subRenewDetail.getRenewFailedTemplateID();
					    //#####
					    //if(validateList(packsub.getSubscriptionRenewDetails(), (i+1))){
					    	//subRenewFbChgCode+=";";	
					    //}
					    //#####
					}
					
									
					if(subRenewDetail.getChargingCode()==0 || subRenewDetail.getChargingCode()!=0)
					{
						if(validateList(packsub.getSubscriptionRenewDetails(), (i+1))){
							
							if(subRenewDetail.getChargingCode()==0 && i==0)
							{
							subRenewFbChgCode="";	
										
							}	
							else
							{	
								if(subRenewDetail.getChargingCode()==0 && i>0)
								{
									if("".equalsIgnoreCase(subRenewFbChgCode) || subRenewFbChgCode==null || subRenewFbChgCode.lastIndexOf(";")==subRenewFbChgCode.length()-1)
									 {
										 //donothing
									 }
									 else
									 {
										 subRenewFbChgCode += ";";
									 }	 
									//System.out.println("SubREnew TRuEEEEEE["+i+"]");
								}
								else
								{
									//System.out.println("Subrenew Else ["+i+"]");
									subRenewFbChgCode+=";";	
								}	
							}
					    }
					}
					
				}
				if(!subRenewFlag)
				{
					subRenewFbChgCode="NA";
				}
				
				logger.info("subRenewFbChgCode =["+subRenewFbChgCode+"]");
				System.out.println("subRenewFbChgCode =["+subRenewFbChgCode+"]");
	
				
				logger.info("##### fromation of rbtPurchase ####");
				RbtPurchaseDetail rbtpDetail=null;
				
				//Removing null Entries
				while(packsub.getRbtPurchaseDetails().remove(null));
				
				//Sorting by validity Days
				/*Collections.sort(packsub.getRbtPurchaseDetails(), new Comparator<RbtPurchaseDetail>() {
					@Override
					public int compare(RbtPurchaseDetail o1,
							RbtPurchaseDetail o2) {
						if (o1== null && o2 == null) return 0;
				         if (o1 == null) return true? 1 : -1;
				         if (o2== null) return true? -1 : 1;
						return (o1.getValidity()>o2.getValidity() ? -1 : (o1.getValidity()==o2.getValidity() ? 0 : 1));
					}
				});*/
							
				
					for(int i=0;i<packsub.getRbtPurchaseDetails().size();i++){
						
						rbtpDetail=packsub.getRbtPurchaseDetails().get(i);
						if(rbtpDetail!=null){
							rbtFlag=true;
							rbtFbChgCode+=RatePlanTags.NUMBER_OF_RBT_TAG+":"+rbtpDetail.getNoOfRbt() + ","
											+RatePlanTags.NUMBER_OF_FREE_RBT_TAG+":"+rbtpDetail.getNoOfFreeRbt();
														
								//if(validateList(packsub.getRbtPurchaseDetails(), (i+1))){
								//	rbtFbChgCode+=";";	
							    //}
							/*if(packsub.getRbtPurchaseDetails().size()-1>i){
								rbtFbChgCode+=";";	
						    }*/ //old logic
							
							if(packsub.getRbtPurchaseDetails().size()-1>=i){
								rbtFbChgCode+=",";	
						    }
							
							
							
							
							}
						
											
						/*if(rbtpDetail.getChargingCode()==0 || rbtpDetail.getChargingCode()!=0)
						{
							if(validateList(packsub.getRbtPurchaseDetails(), (i+1))){
								
								if(rbtpDetail.getChargingCode()==0 && i==0)
								{
								rbtFbChgCode=" ";
									
								}
								else
								{
								System.out.println("In else recodingg["+i+"]");
										
								rbtFbChgCode+=";";
								}
						    }
						}*/
						
					
					}
					/*if(!rbtFlag)
					{
						rbtFbChgCode="NA";
					}*/
				
				logger.info("rbtFbChgCode =["+rbtFbChgCode+"]");
				System.out.println("rbtFbChgCode =["+rbtFbChgCode+"]");
				logger.info("########################################");
				
				
				logger.info("##### fromation of recFbChgCode ####");
				RbtRecordingDetail recordingDetail=null;
				
				//Removing null Entries
				while(packsub.getRbtRecordingDetails().remove(null));
				/*
				//Sorting by validity Days
				Collections.sort(packsub.getRbtRecordingDetails(), new Comparator<RbtRecordingDetail>() {
					@Override
					public int compare(RbtRecordingDetail o1,
							RbtRecordingDetail o2) {
						if (o1== null && o2 == null) return 0;
				         if (o1 == null) return true? 1 : -1;
				         if (o2== null) return true? -1 : 1;
						return (o1.getValidity()>o2.getValidity() ? -1 : (o1.getValidity()==o2.getValidity() ? 0 : 1));
					}
				});*/
							
				
				for (int i = 0; i < packsub.getRbtRecordingDetails().size(); i++) {
					
					recordingDetail = packsub.getRbtRecordingDetails().get(i);
						logger.info(" REC_DETAIL: ="+recordingDetail);
						logger.info(" REC_DETAIL: ="+recordingDetail.getChargingCode());
						if(recordingDetail!=null ){
							
							recFlag=true;
							recFbChgCode+=RatePlanTags.NUMBER_OF_RBT_TAG+":"+recordingDetail.getNoOfRbt() + ","
										  +RatePlanTags.NUMBER_OF_FREE_RBT_TAG+":"+recordingDetail.getNoOfFreeRbt();
							    
							/*if(validateList(packsub.getRbtRecordingDetails(), (i+1))){
								recFbChgCode+=";";	
						   }*/
						/*if(packsub.getRbtRecordingDetails().size()-1>i){
								recFbChgCode+=";";	
						   }*/ //old logic
							
							if(packsub.getRbtRecordingDetails().size()-1>=i){
								recFbChgCode+=",";	
						   }


							
						}
						
							
						/*if(recordingDetail.getChargingCode()==0 || recordingDetail.getChargingCode()!=0)
						{
							
							if(validateList(packsub.getRbtRecordingDetails(), (i+1))){
								
								if(recordingDetail.getChargingCode()==0 && i==0)
								{
									recFbChgCode=" ";
								}
								else
								{
									recFbChgCode+=";";
								}	
										
						    }
							
						}*/
						
				}
				/*if(!recFlag)
				{
					recFbChgCode="NA";
				}*/
				logger.info("recFbChgCode =["+recFbChgCode+"]");
				System.out.println("recFbChgCode =["+recFbChgCode+"]");
			
				logger.info("########################################");
				
				
				

				logger.info("##### fromation of giftFbChgCode ####");
				RbtGiftDetail rbtGiftDetail=null;
				
				//Removing null Entries
				while(packsub.getRbtGiftDetails().remove(null));
				
				//Sorting by validity Days
				/*Collections.sort(packsub.getRbtGiftDetails(), new Comparator<RbtGiftDetail>() {
					@Override
					public int compare(RbtGiftDetail o1,
							RbtGiftDetail o2) {
						if (o1== null && o2 == null) return 0;
				         if (o1 == null) return true? 1 : -1;
				         if (o2== null) return true? -1 : 1;
						return (o1.getValidity()>o2.getValidity() ? -1 : (o1.getValidity()==o2.getValidity() ? 0 : 1));
					}
				});*/
							
				for (int i = 0; i < packsub.getRbtGiftDetails().size(); i++) {

					rbtGiftDetail = packsub.getRbtGiftDetails().get(i);
					
					if (rbtGiftDetail != null ){

						giftFlag=true;
						giftFbChgCode += RatePlanTags.NUMBER_OF_RBT_TAG+":"+rbtGiftDetail.getNoOfRbt() + ","
										 +RatePlanTags.NUMBER_OF_FREE_RBT_TAG+":"+rbtGiftDetail.getNoOfFreeRbt();
										 
							
						/*if(validateList(packsub.getRbtGiftDetails(), (i + 1))) {
							giftFbChgCode += ";";
						}*/
						/*if(packsub.getRbtGiftDetails().size()-1>i){
							giftFbChgCode += ";";
						}*/ //old logic
						
						if(packsub.getRbtGiftDetails().size()-1>=i){
							giftFbChgCode += ",";
						}
					}
					/*if(rbtGiftDetail.getChargingCode()==0 || rbtGiftDetail.getChargingCode()!=0)
					{
						if (validateList(packsub.getRbtGiftDetails(), (i + 1))) {
							
							if(rbtGiftDetail.getChargingCode()==0 && i==0)
							{
								giftFbChgCode=" ";
										
							}
							else
							{	
							giftFbChgCode += ";";
							}
						}
					
						
					}*/
				}
				/*if(!giftFlag)
				{
					giftFbChgCode = "NA";
					
				}*/	
				logger.info("giftFbChgCode =["+giftFbChgCode+"]");
				System.out.println("giftFbChgCode =["+giftFbChgCode+"]");
				
				logger.info("########################################");
				
				
			
              //free
				
				logger.info("##### fromation of freeFbChgCode ####");
				FreeRbtDetail freeRbtDetail=null;
				
				//Removing null Entries
				while(packsub.getFreeRbtDetails().remove(null));
				
				//Sorting by validity Days
				Collections.sort(packsub.getFreeRbtDetails(), new Comparator<FreeRbtDetail>() {
					@Override
					public int compare(FreeRbtDetail o1,
							FreeRbtDetail o2) {
						if (o1== null && o2 == null) return 0;
				         if (o1 == null) return true? 1 : -1;
				         if (o2== null) return true? -1 : 1;
						return (o1.getValidity()>o2.getValidity() ? -1 : (o1.getValidity()==o2.getValidity() ? 0 : 1));
					}
				});
							
				for (int i = 0; i < packsub.getFreeRbtDetails().size(); i++) {

					freeRbtDetail = packsub.getFreeRbtDetails().get(i);
					
					if (freeRbtDetail != null && freeRbtDetail.getChargingCode() != 0) {

						freeFlag=true;
						freeFbChgCode += RatePlanTags.CHARGE_CODE_TAG + ":"+ freeRbtDetail.getChargingCode() + ","
										 +RatePlanTags.VALIDITY_DAYS_TAG+":"+freeRbtDetail.getValidity(); 
										 
						//if (validateList(packsub.getFreeRbtDetails(), (i + 1))) {
						//	freeFbChgCode += ";";
						//}
					}
					if(freeRbtDetail.getChargingCode()==0 || freeRbtDetail.getChargingCode()!=0)
					{
						if (validateList(packsub.getFreeRbtDetails(), (i + 1))) {
							
							if(freeRbtDetail.getChargingCode()==0 && i==0)
							{
								freeFbChgCode="";
											
							}
							else
							{	
								if(freeRbtDetail.getChargingCode()==0 && i>0)
								{
									//System.out.println("FreeRbt TUEEEE ["+i+"]");
									if("".equalsIgnoreCase(freeFbChgCode) || freeFbChgCode==null || freeFbChgCode.lastIndexOf(";")==freeFbChgCode.length()-1)
									 {
										 //donothing
									 }
									 else
									 {
										 freeFbChgCode += ";";
									 }	 
								}
								else
								{	
								//System.out.println("FreeRbt ELSE ["+i+"]");
								
							     freeFbChgCode += ";";
								}
							}
						}
					
						
					}
				}
				if(!freeFlag)
				{
					freeFbChgCode += "NA";
					
				}
				logger.info("freeFbChgCode =["+freeFbChgCode+"]");
				System.out.println("freeFbChgCode =["+freeFbChgCode+"]");
				
				logger.info("########################################");
				
				//Setting subValidFor NA if validFor is Not-Subscriber
				if(packsub.getValidFor().equalsIgnoreCase("N"))
				{
					packsub.setSubValidFor("NA");
				}
				
				
//setting default values
				
				if(packsub.getOfferValidFor()==null)
				{
					packsub.setOfferValidFor(-1);
				}
				if(packsub.getPriority()==null)
				{
					packsub.setPriority(-1);
				}
                if(packsub.getSmsCommand().equalsIgnoreCase(""))
                {
                	packsub.setSmsCommand("NA");
                }
                if(packsub.getUssdCommand().equalsIgnoreCase(""))
                {
                	packsub.setUssdCommand("NA");
                }
                if(packsub.getIvrPath().equalsIgnoreCase(""))
                {
                	packsub.setIvrPath("NA");
                }
                if(packsub.getIvrShortCode().equalsIgnoreCase(""))
                {
                	packsub.setIvrShortCode("NA");
                }
                if(packsub.getMaxWalletRbt()==null)
                {
                	packsub.setMaxWalletRbt(-1);
                }
                if(packsub.getRemark().equalsIgnoreCase(""))
                {
                	packsub.setRemark("REMARK");
                }
                //end default values
                
				
				//#############    creating new bean to store data          #########//
			
				PackSubNewBean packSubNew=new PackSubNewBean(packsub.getPackName().toUpperCase(),subFbChgCode, subRenewFbChgCode,
						                                     packsub.getValidFor(), packsub.getSubValidFor(),
						                                     rbtFbChgCode, giftFbChgCode, recFbChgCode,
						                                     freeFbChgCode, packsub.getOfferValidFor(),
						                                     packsub.getPriority(), packsub.getSmsCommand(),
						                                     packsub.getUssdCommand(), packsub.getIvrPath(),
						                                     packsub.getIvrShortCode(),activeInterface,packsub.getPackScope(),
						                                     packsub.getMaxWalletRbt(),packsub.getUserScope(),
						                                     packsub.getRbtSetting(),packsub.getIsDefaultPack(), packsub.getRemark(),
						                                     packsub.getStart(),packsub.getEnd(),packsub.getCampaignId());
				                                     
				
				
				
				
				
				PackManager packManager=new PackManager();
				int result=-1;
				
				
				if(getActionType().equalsIgnoreCase(RatePlanTags.UPDATE_ACTION_TAG))
				  {
					
					//System.out.println("packId["+packsub.getPackId()+"] NEW BEAN["+packSubNew+"]");
					logger.info("Going to Update crbt_pack_detail for pack_id["+packsub.getPackId()+"]");
					result=packManager.updatePack(packSubNew,packsub.getPackId());
					if(result>0)
					{
						logger.info("Pack Updated successfully");
						//message = "Pack detail with PACK-NAME =["+ packsub.getPackName()+ "] is [UPDATED] successfully!";
						message = "Pack  is UPDATED successfully!";
						return "success";
					}
					else
					{
						logger.info("Exception inside PackManager.updatePack()");
						//message = "Failed to update Pack deatil with PACK-NAME =["+ packsub.getPackName()+ "] !";
						message = "Failed to update Pack!";
						return "error";
					}
					
				  }	
				else
				{
				logger.info("Going to add new pack into crbt_pack_detail");
				result=packManager.addPack(packSubNew);
				if(result>0)
				{
					logger.info("New Pack Inserted successfully");
					//message = "Pack detail with PACK-NAME =["+ packsub.getPackName()+ "] is [ADDEDD] successfully!";
					message = "Pack is Created successfully!";
					return "success";
				}
				else
				{
					logger.info("Exception inside PackManager.addPack()");
					//message = "Failed to Add Pack detail with PACK-NAME =["+ packsub.getPackName()+ "]!";
					message = "Failed to Create Pack!";
					
					return "error";
				}
				}
				
				
		    }
			catch(Exception e)
			{
				System.out.println("Exception inside addPack"+e);
				e.printStackTrace();
				
			}
		
	}
		return "failure";
		
		
	}		
		
	//this method is used to get active interfaces for pack
	  
	
	public String getActiveInterface(PackSubBean packsub2) {
		String allActiveInterfaces="";
		String finalString="NA";
		Boolean flag=false;
		
		if(packsub2.getSms().equalsIgnoreCase("true"))
		{
			flag=true;
			allActiveInterfaces+="S,";
		}
		if(packsub2.getWeb().equalsIgnoreCase("true"))
		{
			flag=true;
			allActiveInterfaces+="W,";
		}
		if(packsub2.getIvr().equalsIgnoreCase("true"))
		{
			flag=true;
			allActiveInterfaces+="I,";
		}
		if(packsub2.getUssd().equalsIgnoreCase("true"))
		{
			flag=true;
			allActiveInterfaces+="U,";
		}
		if(packsub2.getObd().equalsIgnoreCase("true"))
		{
			flag=true;
			allActiveInterfaces+="O,";
		}
		if(flag)
		{
			
			int last=allActiveInterfaces.lastIndexOf(",");
		    finalString=allActiveInterfaces.substring(0, last);
		}
		
		
		return finalString;
	}
	
	
	
	/**
	 * This method list all Pack available in CRBT_PACK_DETAIL
	 * @return String
	 * 		success -- If all pack list is accessed successfully
	 * 		error	-- If any error is detected
	 */
	public String showAllPack(){
		
		
		if (!checkSession().equalsIgnoreCase("success")) {
			return checkSession();
		} else {
			
			PackManager pckManager=new PackManager();
			try{
				
					
				crbtPackList=pckManager.getCrbtPackList();
				logger.info("getting crbtPackList from db["+crbtPackList.size()+"]");
				
			}catch (Exception e) {
				logger.error("ERROR in getting crbtPackList!",e);
				return ERROR;
			}
		}
		return SUCCESS;
	}//### END of method showAllPack() 
	

	/**
	 * This method list all Pack details available in CRBT_PACK_DETAIL corresponding particular pack_id
	 * @return String
	 * 		success -- If all pack list is accessed successfully
	 * 		error	-- If any error is detected
	 */
	
	public String viewPack()
	{
		if (!checkSession().equalsIgnoreCase("success")) {
			return checkSession();
		} else {
			packsub=null;
			packsub=new PackSubBean();
			PackManager pckManager=new PackManager();
			
			
			try{
				List <ChargingCodeDetail> chgList=pckManager.getChargingCodeList();
				chgCodeMap=new HashMap<Integer, String>();
				for(Iterator<ChargingCodeDetail> it=chgList.iterator();it.hasNext();){
						ChargingCodeDetail bean=it.next();
					//	chgCodeMap.put(bean.getChargingCode(), bean.getDescription());
				}
                logger.info("Getting pack detail corresponding to pack_id["+packId+"]");		        
				
                packSubNewBean=pckManager.getCrbtPackByPackId(packId);
	            packsub.setPackName(packSubNewBean.getPackName());
	            
                   if(packSubNewBean!=null){
					
					logger.info(" sub_fb_charge_code = "+packSubNewBean.getSubscriptionDetails());
					if(packSubNewBean.getSubscriptionDetails()!=null){
						 formSubAndPurchasePackDetail(packSubNewBean.getSubscriptionDetails(),RatePlanTags.SUBSCRIPTION_TAG); 
					}
					
					logger.info(" SUB_RENEW_FB_CHG_CODE = "+packSubNewBean.getSubscriptionRenewDetails());
					if(packSubNewBean.getSubscriptionRenewDetails()!=null){
						formSubAndPurchaseRenewalPackDetail(packSubNewBean.getSubscriptionRenewDetails(), RatePlanTags.SUBSCRIPTION_TAG);
					}
					
					logger.info("RBT_FB_CHG_CODE = "+packSubNewBean.getRbtPurchaseDetails());
					if(packSubNewBean.getRbtPurchaseDetails()!=null){
						formSubAndPurchasePackDetail(packSubNewBean.getRbtPurchaseDetails(), RatePlanTags.RBT_PURCHASE_TAG);
					}
					
					logger.info("FREE_FB_CHG_CODE = "+packSubNewBean.getFreeRbtDetails());
					if(packSubNewBean.getFreeRbtDetails()!=null){
						formSubAndPurchasePackDetail(packSubNewBean.getFreeRbtDetails(), RatePlanTags.RBT_FREE_TAG);
					}
			
					logger.info("GIFT_FB_CHG_CODE = "+packSubNewBean.getRbtGiftDetails());
					if(packSubNewBean.getRbtGiftDetails()!=null){
						formSubAndPurchasePackDetail(packSubNewBean.getRbtGiftDetails(), RatePlanTags.RBT_GIFT_TAG);
					}
					
					logger.info("REC_FB_CHG_CODE = "+packSubNewBean.getRbtRecordingDetails());
					if(packSubNewBean.getRbtRecordingDetails()!=null){
						formSubAndPurchasePackDetail(packSubNewBean.getRbtRecordingDetails(), RatePlanTags.RECORDING_TAG);
					}
				
				    //get pack valid for Subscriber,Non-Subscriber,Both set inside bean
					
					if(packSubNewBean.getValidFor().equalsIgnoreCase("S"))
				    {
				    	packsub.setValidFor("Subscriber");
				    }
				    else if(packSubNewBean.getValidFor().equalsIgnoreCase("N"))
				    {
				    	packsub.setValidFor("Non-Subscriber");	
				    }
				    else if(packSubNewBean.getValidFor().equalsIgnoreCase("B"))
				    {
				    	packsub.setValidFor("Both");	
				    }
				    else
				    {
				    	logger.info("Not Match case available");	
				    }
				    //end of valid for 
					
					//get pack valid for what type of user Active,In-Active,Both
					if(packSubNewBean.getSubValidFor().equalsIgnoreCase("A"))
				    {
				    	packsub.setSubValidFor("Active");
				    }
				    else if(packSubNewBean.getSubValidFor().equalsIgnoreCase("I"))
				    {
				    	packsub.setSubValidFor("Inactive");	
				    }
				    else if(packSubNewBean.getSubValidFor().equalsIgnoreCase("B"))
				    {
				    	packsub.setSubValidFor("Both");	
				    }
				    else if(packSubNewBean.getSubValidFor().equalsIgnoreCase("NA"))
				    {
				    	packsub.setSubValidFor("NA");	
				    }
					
				    else
				    {
				    	logger.info("Not Match case available");	
				    }
					//end Subscription pack valid for what type of user
					
					packsub.setOfferValidFor(packSubNewBean.getOfferValidFor());
					packsub.setPriority(packSubNewBean.getPriority());
					packsub.setSmsCommand(packSubNewBean.getSmsCommand());
					packsub.setUssdCommand(packSubNewBean.getUssdCommand());
					packsub.setIvrPath(packSubNewBean.getIvrPath());
					packsub.setIvrShortCode(packSubNewBean.getIvrShortCode());
					
					//get pack valid for how many interfaces
					int result=getInterfaces(packSubNewBean.getActiveInterface());
					if(result>0)
					{
						//System.out.println("All interfaces got successfully listsize["+activeInterfaceList.size()+"]");
						logger.info("All interfaces got successfully");
					}
					else
					{
						logger.info("Err from getInterfaces()");	
					}
					
					packsub.setMaxWalletRbt(packSubNewBean.getMaxWalletRbt());
					
					//Setting user Scope that can be Prepaid,Postpaid,Both
					if(packSubNewBean.getUserScope().equalsIgnoreCase("P"))
					{	
					packsub.setUserScope("Prepaid");
					}
					else if(packSubNewBean.getUserScope().equalsIgnoreCase("O"))
					{	
					packsub.setUserScope("Postpaid");
					}
					else if(packSubNewBean.getUserScope().equalsIgnoreCase("B"))
					{	
					packsub.setUserScope("Both");
					}
					else
					{
						logger.info("No match case found");	
					}
					//end user scope
 					
					//setting pack Scope that can be Active,In_Active
					if(packSubNewBean.getPackScope().equalsIgnoreCase("A"))
					{	
					packsub.setPackScope("Active");
					}
					else if(packSubNewBean.getPackScope().equalsIgnoreCase("I"))
					{
					packsub.setPackScope("Inactive");
					 			
					}
					else
					{
						logger.info("No match case found");	
					}
					//end packScope
					
					//setting Rbt Setting that can be Default,Random,Sequential
					if(packSubNewBean.getRbtSetting().equalsIgnoreCase("1"))
					{	
					packsub.setRbtSetting("Default Setting");
					}
					else if(packSubNewBean.getRbtSetting().equalsIgnoreCase("2"))
					{	
					packsub.setRbtSetting("Sequence Setting");
					}
					if(packSubNewBean.getRbtSetting().equalsIgnoreCase("3"))
					{	
					packsub.setRbtSetting("Random Setting");
					}
					else
					{
						logger.info("No match case found");	
					}
										
					//end Rbt Setting
					
					//setting isDefault Pack that can be Yes,No
					if(packSubNewBean.getIsDefaultPack().equalsIgnoreCase("1"))
					{	
					packsub.setIsDefaultPack("Yes");
					}
					else if(packSubNewBean.getIsDefaultPack().equalsIgnoreCase("2"))
					{	
					packsub.setIsDefaultPack("No");
					}
					else
					{
						logger.info("No match case found");
					}
					
					//end isDefault Pack
					
					packsub.setCampaignId(packSubNewBean.getCampaignId());
					packsub.setRemark(packSubNewBean.getRemark());
					packsub.setStart(packSubNewBean.getStart());
					packsub.setEnd(packSubNewBean.getEnd());
					packsub.setPackId(packSubNewBean.getPackId());
					
					logger.info("#####In viewPack() Whole data got successfully indside bean packsub####");        
	                
	                
					
					
	                
					
					
					status=1;
                   }
			}
            catch (Exception e) {
            	logger.error("Err inside viewPack()");
            	e.printStackTrace();
            
            	status=-1;
				}
             		
		 if(status==1)
		 {
			 return "success";
		 }
        else if(status==-1)
        {
        	return ERROR;
        }
        else
        {
        	return ERROR;
        }	
		}	     
		
			
				    
    					
		
		
		
		
		
	}
	
    public int getInterfaces(String interfaces)
    {
         
    	 int result=-1;
    	 String[] noofInterfaces=null;
         noofInterfaces=interfaces.split(",");
         
         activeInterfaceList=new ArrayList<ActiveInterfaceBean>();
         try
         {
         
         if(interfaces.equalsIgnoreCase("NA"))
         {
    		 ActiveInterfaceBean bean1=new ActiveInterfaceBean("NA");
    		 activeInterfaceList.add(bean1);
             	 
         }
         else
         {	 
         
         for(String v : noofInterfaces)
         {
        	 if(v.equalsIgnoreCase("S"))
        	 {
        		 ActiveInterfaceBean bean1=new ActiveInterfaceBean("sms");
        		 activeInterfaceList.add(bean1);
        	 }
        	 else if(v.equalsIgnoreCase("W"))
        	 {
        		 ActiveInterfaceBean bean2=new ActiveInterfaceBean("web");
        		 activeInterfaceList.add(bean2);
        	 }
        	 else if(v.equalsIgnoreCase("I"))
        	 {
        		 ActiveInterfaceBean bean3=new ActiveInterfaceBean("ivr");
        		 activeInterfaceList.add(bean3);
        	 }
        	 else if(v.equalsIgnoreCase("U"))
        	 {
        		 ActiveInterfaceBean bean4=new ActiveInterfaceBean("ussd");
        		 activeInterfaceList.add(bean4);
        	 }
        	 else if(v.equalsIgnoreCase("O"))
        	 {
        		 ActiveInterfaceBean bean5=new ActiveInterfaceBean("obd");
        		 activeInterfaceList.add(bean5);
        	 }
        	 else
        	 {
        		 logger.info("No match case found");	 
        	 }
         }
         }
    	
    
         result=1;
         }
         catch(Exception e)
         {
        	 logger.error("Exception inside getInterfaces()");
        	 e.printStackTrace();
        	 result=-1;
         }
         
    	
    	return result;
    }
    
       
                   
                   
			
	public void formSubAndPurchasePackDetail(String falbackStr,String action){
				
		       
		        
		       logger.info(" ### formSubAndPurchasePackDetail ");
				String fbArr[]=null;
				String detailArr[]=null;
				int chgCode=0;
				int  validity=0;
				int  noOfRbts=0;
				int noOfFreeRbts=0;
				
				if(action.equalsIgnoreCase(RatePlanTags.SUBSCRIPTION_TAG)){
					//CC:83,DAYS:14;CC:82,DAYS:7
					//CC:8,DAYS:30, rbtFbChgCode=CC:3,DAYS:30;CC:34,DAYS:21;CC:31,DAYS:1
					List<SubscriptionDetail> subList=new ArrayList<SubscriptionDetail>();
					
					if(falbackStr.equalsIgnoreCase("NA"))
					{
						chgCode=0;
						validity=0;
						subList.add(new SubscriptionDetail(chgCode,validity));
					}
					else
					{	
					fbArr=falbackStr.split(";");
					
					for (String s : fbArr) {
						logger.info(s);
						detailArr = s.split(",");
						
						chgCode=Integer.parseInt(detailArr[0].split(":")[1]);
						validity=Integer.parseInt(detailArr[1].split(":")[1]);
						
						subList.add(new SubscriptionDetail(chgCode,validity));
					 }
					}
					this.packsub.setSubscriptionDetails(subList);
					
				}else if(action.equalsIgnoreCase(RatePlanTags.RBT_PURCHASE_TAG)){
					//CC:84,DAYS:30,NOR:0,NOFR:6;CC:83,DAYS:14,NOR:0,NOFR:6
					//CC:3,DAYS:30,NOR:0,NOFR:6;CC:34,DAYS:21,NOR:0,NOFR:6;CC:31,DAYS:1
					List<RbtPurchaseDetail> rbtpList=new ArrayList<RbtPurchaseDetail>();
					System.out.println("fallback str["+falbackStr+"]");
					
					if(falbackStr.equalsIgnoreCase("NA"))
					{
						System.out.println("Inside NA");
						chgCode=0;
						validity=0;
			            noOfRbts=0;
			            noOfFreeRbts=0;
			        	rbtpList.add(new RbtPurchaseDetail(noOfRbts,noOfFreeRbts,"pack"));
							
						
					}
					else
					{	
					fbArr=falbackStr.split(";");
					for (String s : fbArr) {
						logger.info(s);
						detailArr = s.split(",");
						
						//chgCode=Integer.parseInt(detailArr[0].split(":")[1]);
						//validity=Integer.parseInt(detailArr[1].split(":")[1]);
			            noOfRbts=Integer.parseInt(detailArr[0].split(":")[1]);
			            noOfFreeRbts=Integer.parseInt(detailArr[1].split(":")[1]);
						
						rbtpList.add(new RbtPurchaseDetail(noOfRbts,noOfFreeRbts,"pack"));
					}
					}
					this.packsub.setRbtPurchaseDetails(rbtpList);
					
				}else if(action.equalsIgnoreCase(RatePlanTags.RECORDING_TAG)){
					//CC:84,DAYS:21,NOR:0,NOFR:6;CC:82,DAYS:7,NOR:0,NOFR:6
					//CC:8,DAYS:30,NOR:0,NOFR:6;CC:84,DAYS:21,NOR:0,NOFR:6;CC:83,DAYS:14,NOR:0,NOFR:6;CC:82,DAYS:7;CC:81,DAYS:1
					
					List <RbtRecordingDetail> rbtRecList=new ArrayList<RbtRecordingDetail>();
					
					if(falbackStr.equalsIgnoreCase("NA"))
					{
						chgCode=0;
						validity=0;
						noOfRbts=0;
			            noOfFreeRbts=0;
			    		rbtRecList.add(new RbtRecordingDetail(noOfRbts,noOfFreeRbts,"pack" ));
								
					}
					else
					{	
					fbArr=falbackStr.split(";");
					for (String s : fbArr) {
						logger.info(s);
						detailArr = s.split(",");
						
						//chgCode=Integer.parseInt(detailArr[0].split(":")[1]);
						//validity=Integer.parseInt(detailArr[1].split(":")[1]);
						noOfRbts=Integer.parseInt(detailArr[0].split(":")[1]);
			            noOfFreeRbts=Integer.parseInt(detailArr[1].split(":")[1]);
						
						
						rbtRecList.add(new RbtRecordingDetail( noOfRbts,noOfFreeRbts,"pack" ));
					}
					}
					this.packsub.setRbtRecordingDetails(rbtRecList);
					
				}else if(action.equalsIgnoreCase(RatePlanTags.RBT_GIFT_TAG)){
					//CC:43,DAYS:7,NOR:0,NOFR:6;CC:41,DAYS:1,NOR:0,NOFR:6
					//CC:4,DAYS:30,NOR:0,NOFR:6;CC:44,DAYS:21,NOR:0,NOFR:6;CC:43,DAYS:14,NOR:0,NOFR:6;CC:42,DAYS:7,NOR:0,NOFR:6;CC:41,DAYS:1
					List<RbtGiftDetail> rbtGiftList=new ArrayList<RbtGiftDetail>();
					if(falbackStr.equalsIgnoreCase("NA"))
					{
						chgCode=0;
						validity=0;
						noOfRbts=0;
			            noOfFreeRbts=0;
						
						rbtGiftList.add(new RbtGiftDetail(noOfRbts,noOfFreeRbts,"pack"));
						
					}
					else
					{	
					fbArr=falbackStr.split(";");
					for (String s : fbArr) {
						logger.info(s);
						detailArr = s.split(",");
					
						//chgCode=Integer.parseInt(detailArr[0].split(":")[1]);
						//validity=Integer.parseInt(detailArr[1].split(":")[1]);
						noOfRbts=Integer.parseInt(detailArr[0].split(":")[1]);
			            noOfFreeRbts=Integer.parseInt(detailArr[1].split(":")[1]);
						
						rbtGiftList.add(new RbtGiftDetail(noOfRbts,noOfFreeRbts,"pack"));
					}
					}
					
					this.packsub.setRbtGiftDetails(rbtGiftList);
					
				}else if(action.equalsIgnoreCase(RatePlanTags.RBT_FREE_TAG)){
					//CC:43,DAYS:7,NOR:0,NOFR:6;CC:41,DAYS:1,NOR:0,NOFR:6
					//CC:4,DAYS:30,NOR:0,NOFR:6;CC:44,DAYS:21,NOR:0,NOFR:6;CC:43,DAYS:14,NOR:0,NOFR:6;CC:42,DAYS:7;CC:41,DAYS:1
					List<FreeRbtDetail> rbtFreeList=new ArrayList<FreeRbtDetail>();
					
					if(falbackStr.equalsIgnoreCase("NA"))
					{
						chgCode=0;
						validity=0;
						noOfRbts=0;
			            noOfFreeRbts=0;
						
						rbtFreeList.add(new FreeRbtDetail( chgCode, validity));
						
					}
					else
					{	
					fbArr=falbackStr.split(";");
					for (String s : fbArr) {
						logger.info(s);
						detailArr = s.split(",");
						
						chgCode=Integer.parseInt(detailArr[0].split(":")[1]);
						validity=Integer.parseInt(detailArr[1].split(":")[1]);
						//noOfRbts=Integer.parseInt(detailArr[2].split(":")[1]);
			            //noOfFreeRbts=Integer.parseInt(detailArr[3].split(":")[1]);
						
						rbtFreeList.add(new FreeRbtDetail( chgCode, validity));
					}
					}
					this.packsub.setFreeRbtDetails(rbtFreeList);
					
				}			
				else{
					logger.warn(" Tags doesn't match with actions!!");
				}
				
			}//### END OF formSubAndPurchasePackDetail()
					
	
	public void formSubAndPurchaseRenewalPackDetail(String falbackRenewStr,String action){
		logger.info(" ### formSubAndPurchaseRenewalPackDetail ");
		
		String fbArr[]=null;
		String detailArr[]=null;
		int chgCode=0;
		int validity=0;
		int stid=0;
		int ftid=0;
		
		if(action.equalsIgnoreCase(RatePlanTags.SUBSCRIPTION_TAG)){
			//CC:2,DAYS:30,STID:1,FTID:1;CC:84,DAYS:21,STID:100,FTID:100
			//CC:8,DAYS:30
			List<SubscriptionRenewDetail> subRenewList=new ArrayList<SubscriptionRenewDetail>();
			
			if(falbackRenewStr.equalsIgnoreCase("NA"))
			{
				chgCode=0;
				validity=0;
				stid=0;
				ftid=0;
				
				subRenewList.add(new SubscriptionRenewDetail(chgCode,validity,stid,ftid));
				
			}
			else
			{	
			fbArr=falbackRenewStr.split(";");
			
			
			
			for (String s : fbArr) {
				logger.info(s);
				detailArr = s.split(",");
				
				chgCode=Integer.parseInt(detailArr[0].split(":")[1]);
				validity=Integer.parseInt(detailArr[1].split(":")[1]);
				stid=Integer.parseInt(detailArr[2].split(":")[1]);
				ftid=Integer.parseInt(detailArr[3].split(":")[1]);
				
				subRenewList.add(new SubscriptionRenewDetail(chgCode,validity,stid,ftid));
				
			}
			}
			this.packsub.setSubscriptionRenewDetails(subRenewList);
			
			}else{
			logger.warn(" Tags doesn't match with actions!!");
		}
	}//### end of method formSubAndPurchaseRenewalPackDetail()
	
	

	//This method is used to Update the CRBT_PACK_DETAIL
	
	public String packUpdation(){
		logger.info("#######PackUpdation()##############");
		
		if (!checkSession().equalsIgnoreCase("success")) {
			return checkSession();
		} else  if( packsub!=null && (!packsub.getPackName().trim().equalsIgnoreCase("")) ){
			setActionType(RatePlanTags.UPDATE_ACTION_TAG);
			return addPack();
		}else {
			message="Pack with PACK-NAME =["+packsub.getPackName()+"] is failed to UPDATE!";
			return ERROR;
		}
	}//##### END OF method updatePack()
	
	
	
	//this function handle the modify page of pack manage
		

	public String modifyPack()
	{
        // System.out.println("###############Indide modifyPack....####################");
		try
		{
		String result=viewPack();
		String result1=populateChgCodeAndTemplate();
		logger.info("Result from viewPack() is ["+result+"]");
		logger.info("Result from populateChgCodeAndTemplate() is ["+result1+"]");
		
		
		PackManager pm=new PackManager();
		
		//getting values from crbt_pack_detail IS_DEFAULT_PACK,RBT_SETTING,SCOPE,STATUS,VALID_FOR,SUBSCRIBER 
		int resp=pm.getSettingValues(packsub,packId);
		if(resp>0)
		{
			logger.info("successfully fetched...data");
		}
		else
		{
			logger.error("err inside getSettingValues()");
		}
		
		
		
		
		
		
		
		//setting validForList
        validForList=new ArrayList<ValidFor>();
		ValidFor bean1=new ValidFor("S", "Subscriber");
        ValidFor bean2=new ValidFor("N", "Non-Subscriber");
        ValidFor bean3=new ValidFor("B", "Both");
        
        validForList.add(bean1);
        validForList.add(bean2);
        validForList.add(bean3);
        //end validForList
        
        //setting subValidForList
        subValidForList=new ArrayList<SubvalidFor>();
        SubvalidFor sub1=new SubvalidFor("A","Active");
        SubvalidFor sub2=new SubvalidFor("I","Inactive");
        SubvalidFor sub3=new SubvalidFor("B","Both");
        
        subValidForList.add(sub1);
        subValidForList.add(sub2);
        subValidForList.add(sub3); 
        //end subValidForList
        
        
		//setting activeInterfacesListFm not used.....############
		/*activeInterfacesListFm=new ArrayList<ActiveInterfaceBean>();
        ActiveInterfaceBean active1=new ActiveInterfaceBean("sms", "S");
		ActiveInterfaceBean active2=new ActiveInterfaceBean("web", "W");
		ActiveInterfaceBean active3=new ActiveInterfaceBean("ivr", "I");
		ActiveInterfaceBean active4=new ActiveInterfaceBean("ussd", "U");
		ActiveInterfaceBean active5=new ActiveInterfaceBean("obd", "O");
        activeInterfacesListFm.add(active1);
        activeInterfacesListFm.add(active2);
        activeInterfacesListFm.add(active3);
        activeInterfacesListFm.add(active4);
        activeInterfacesListFm.add(active5);
        */
        
        //setting activeInterfaceList
        activeInterfaceList=new ArrayList<ActiveInterfaceBean>();
        activeInterfaceList=pm.getActiveList(packId);
        
        //setting nonActiveInterfaceList
        nonActiveInterfaceList=pm.getNonACtiveInterfaceList(activeInterfaceList);
        
        
		
		//setting userScopeList
        userScopeList=new ArrayList<UserScope>();
        UserScope uscope1=new UserScope("P", "Prepaid");
        UserScope uscope2=new UserScope("O", "Postpaid");
        UserScope uscope3=new UserScope("B", "Both");
        
        userScopeList.add(uscope1);
        userScopeList.add(uscope2);
        userScopeList.add(uscope3);
        //end userScopeList
        
        
        //setting packScopeList
        packScopeList=new ArrayList<PackScope>();
        PackScope pkscp1=new PackScope("A","Active");
        PackScope pkscp2=new PackScope("I","Inactive");
        
        packScopeList.add(pkscp1);
        packScopeList.add(pkscp2);
        //end packScopeList
        
        //setting rbtSettingList
        rbtSettingList=new ArrayList<RbtSetting>();
        RbtSetting rbt1=new RbtSetting("1", "Default Setting");
        RbtSetting rbt2=new RbtSetting("2", "Sequence Setting");
        RbtSetting rbt3=new RbtSetting("3", "Random Setting");
        
        rbtSettingList.add(rbt1);
        rbtSettingList.add(rbt2);
        rbtSettingList.add(rbt3);
        //end rbtSettingList
        
         
        //setting isDefaultList
        isDefaultList=new ArrayList<IsDefault>();
        IsDefault df1=new IsDefault("1", "Yes");
        IsDefault df2=new IsDefault("2", "No");
        
        isDefaultList.add(df1);
        isDefaultList.add(df2);
        //end isDefaultList
        
        
             
        status=1;
		}
		catch(Exception e)
		{
			System.out.println("err inside modifyPack");
			e.printStackTrace();
			status=-1;
		}
        if(status>0)
        {
        	logger.info("##########modifyPack() completes successfully###########");
        	return "success";
        }
        else {
			return ERROR;
		}
        
	}
	
/*this method is used to delete pack from crbt_pack_detail corresponding to pack_id
 * 
  * */	
	public String handleDeletePack()
	{
		logger.info("Inside function handleDeletePack().....");
		
		if(!checkSession().equalsIgnoreCase("success"))
		{
			return checkSession();
		 }
		else
		 {
			PackManager pm=new PackManager();
			try{
			logger.info("Going to Delete pack from crbt_pack_detail for packId is:["+packId+"]");
			 status=pm.deleteCrbtPackDetail(packId);
				if(status == 1){
					//message="Pack  details for packName   is deleted: ["+packsub.getPackName()+"]";
					message="Pack  is deleted successfully!";
					linkName="webadmin";
					return SUCCESS;
				}else{
					status=-1;
				//	message=" Failed to delete pack  detail for packName : ["+packsub.getPackName()+"]";
					message=" Failed to delete pack!";
					linkName="webadmin";
					return ERROR;
				}
			}catch (Exception e) {
				logger.error("ERROR in processing chargingCode List!",e);
				return ERROR;
			}
	  }
	}

	
	
	
	
	 
	
	/**
	 * This common validation element for 
	 * This is method is made for validating whether next element of list is null or not 
	 * @param lst  type List
	 * @param i type in
	 * @return boolean
	 */
	public  boolean validateList(List lst,int i){
         try{
                
        	     
        	     Object o=lst.get(i);
                 if(o!=null&& o  instanceof SubscriptionDetail){
         	 
                	 if(((SubscriptionDetail)o).getChargingCode()!=0){
                		 return true;
                	 }else {
                		 return false;
                	 }
                	 
                 }else if(o!=null && o instanceof SubscriptionRenewDetail){
                	 if(((SubscriptionRenewDetail)o).getChargingCode()!=0){
                		 return true;
                	 }else {
                		 return false;
                	 }
                 }
                 else if(o!=null && o instanceof FreeRbtDetail){
                	 if(((FreeRbtDetail)o).getChargingCode()!=0){
                		 return true;
                	 }else {
                		 return false;
                	 }
                 }
                 else if(o!=null && o instanceof RbtPurchaseDetail){
                	 if(((RbtPurchaseDetail)o).getChargingCode()!=0){
                		 return true;
                	 }else {
                		 return false;
                	 }
                 }
                 else if(o!=null && o instanceof RbtRecordingDetail){
                	 if(((RbtRecordingDetail)o).getChargingCode()!=0){
                		 return true;
                	 }else {
                		 return false;
                	 }
                 }else if(o!=null &&  o instanceof RbtGiftDetail){
                	 if(((RbtGiftDetail)o).getChargingCode()!=0){
                		 return true;
                	 }else {
                		 return false;
                	 }
                 }else{
                	 return false;
                 }
         }catch(IndexOutOfBoundsException e){
                 //e.printStackTrace();
                 return false;
         }catch(Exception e){
                 //e.printStackTrace();
                 return false;
         }
	 }
 
}
