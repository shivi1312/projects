package com.telemune.vcc.webadmin.action;

import java.util.List;

public class PackSubBean {
	
	private String packName;
	
	
	
	
	
	
	private Integer campaignId=-1;
	
	private String subValidFor="B";
	private Integer offerValidFor=-1;
	private String packScope="N";
	
	private String activeInterface="NA";
	private Integer priority=-1;
	private String smsCommand="NA";
	private String ussdCommand="NA";
	private String ivrPath="NA";
	private String ivrShortCode="NA";
	private Integer maxWalletRbt=-1;
	private String userScope="NA";
	private String rbtSetting="-1";
	private String isDefaultPack="N";
	private String remark="REMARK";
	
	private String sms;
	private String web;
	private String ivr;
	private String ussd;
	private String obd;
	
	private String start;
	private String end;
	private String validFor="B";
	private Integer PackId;
	
	
	
	
	
	
	
	private String checkbox;
	
	
	private List  <SubscriptionDetail>subscriptionDetails;
	private List <SubscriptionRenewDetail> subscriptionRenewDetails;
	private List  <RbtPurchaseDetail>rbtPurchaseDetails;
	private List  <RbtRenewDetail>rbtRenewDetails;
	private List  <RbtRecordingDetail>rbtRecordingDetails;
	private List  <RecordingRenewDetail>recordingRenewDetails;
	private List  <RbtGiftDetail>rbtGiftDetails;
	private List  <FreeRbtDetail>freeRbtDetails;
	
	
	
	
	
	
	
	
	
	
	
	
	public Integer getPackId() {
		return PackId;
	}


	public void setPackId(Integer packId) {
		PackId = packId;
	}


	public String getActiveInterface() {
		return activeInterface;
	}


	public void setActiveInterface(String activeInterface) {
		  this.activeInterface = activeInterface;
	}


	public String getValidFor() {
		return validFor;
	}


	public void setValidFor(String validFor) {
		this.validFor = validFor;
	}


	public String getStart() {
		return start;
	}


	public void setStart(String start) {
		this.start = start;
	}


	public String getEnd() {
		return end;
	}


	public void setEnd(String end) {
		this.end = end;
	}


	public String getSms() {
		return sms;
	}


	public void setSms(String sms) {
		this.sms = sms;
	}


	public String getWeb() {
		return web;
	}


	public void setWeb(String web) {
		this.web = web;
	}


	public String getIvr() {
		return ivr;
	}


	public void setIvr(String ivr) {
		this.ivr = ivr;
	}


	public String getUssd() {
		return ussd;
	}


	public void setUssd(String ussd) {
		this.ussd = ussd;
	}


	public String getObd() {
		return obd;
	}


	public void setObd(String obd) {
		this.obd = obd;
	}


	public Integer getPriority() {
		return priority;
	}


	public void setPriority(Integer priority) {
		this.priority = priority;
	}


	public String getSmsCommand() {
		return smsCommand;
	}


	public void setSmsCommand(String smsCommand) {
		this.smsCommand = smsCommand;
	}


	public String getUssdCommand() {
		return ussdCommand;
	}


	public void setUssdCommand(String ussdCommand) {
		this.ussdCommand = ussdCommand;
	}


	public String getIvrPath() {
		return ivrPath;
	}


	public void setIvrPath(String ivrPath) {
		this.ivrPath = ivrPath;
	}


	public String getIvrShortCode() {
		return ivrShortCode;
	}


	public void setIvrShortCode(String ivrShortCode) {
		this.ivrShortCode = ivrShortCode;
	}


	public Integer getMaxWalletRbt() {
		return maxWalletRbt;
	}


	public void setMaxWalletRbt(Integer maxWalletRbt) {
		this.maxWalletRbt = maxWalletRbt;
	}


	public String getUserScope() {
		return userScope;
	}


	public void setUserScope(String userScope) {
		this.userScope = userScope;
	}


	public String getRbtSetting() {
		return rbtSetting;
	}


	public void setRbtSetting(String rbtSetting) {
		this.rbtSetting = rbtSetting;
	}


	public String getIsDefaultPack() {
		return isDefaultPack;
	}


	public void setIsDefaultPack(String isDefaultPack) {
		this.isDefaultPack = isDefaultPack;
	}


	public String getRemark() {
		return remark;
	}


	public void setRemark(String remark) {
		this.remark = remark;
	}


	public String getCheckbox() {
		return checkbox;
	}


	public void setCheckbox(String checkbox) {
		this.checkbox = checkbox;
	}


	public String getSubValidFor() {
		return subValidFor;
	}


	public void setSubValidFor(String subValidFor) {
		this.subValidFor = subValidFor;
	}


	public Integer getOfferValidFor() {
		return offerValidFor;
	}


	public void setOfferValidFor(Integer offerValidFor) {
		this.offerValidFor = offerValidFor;
	}


	public String getPackScope() {
		return packScope;
	}


	public void setPackScope(String packScope) {
		this.packScope = packScope;
	}


	public Integer getCampaignId() {
		return campaignId;
	}


	public void setCampaignId(Integer campaignId) {
		this.campaignId = campaignId;
	}


	public List<FreeRbtDetail> getFreeRbtDetails() {
		return freeRbtDetails;
	}


	public void setFreeRbtDetails(List<FreeRbtDetail> freeRbtDetails) {
		this.freeRbtDetails = freeRbtDetails;
	}


	private Integer scopeValue;
	
	
	public Integer getScopeValue() {
		return scopeValue;
	}


	public void setScopeValue(Integer scopeValue) {
		this.scopeValue = scopeValue;
	}


	public PackSubBean() {
		super();
	}

	
	private String scope;
	private int countryCode;
	
	

	public int getCountryCode() {
		return countryCode;
	}


	public void setCountryCode(int countryCode) {
		this.countryCode = countryCode;
	}
	public String getScope() {
		return scope;
	}
	public void setScope(String scope) {
		this.scope = scope;
	}

	public PackSubBean(String packName, 
			List<SubscriptionDetail> subscriptionDetails,
			List<SubscriptionRenewDetail> subscriptionRenewDetails,
			String validFor,
			String subValidFor,
			List<RbtPurchaseDetail> rbtPurchaseDetails,
			List<RbtGiftDetail> rbtGiftDetails,
			List<RbtRecordingDetail> rbtRecordingDetails,
			List<FreeRbtDetail> freeRbtDetails,
			Integer offerValidFor,
			Integer priority,
			String smsCommand,
			String ussdCommand,
			String ivrPath,
			String ivrShortCode,
			String activeInterface,
			String packScope,
			Integer maxWalletRbt,
			String userScope,
			String rbtSetting,
			String isDefaultPack,
			String remark,
			String start,
			String end,
			Integer campaignId
						) {
		
		super();
		this.packName = packName;
		this.subscriptionDetails = subscriptionDetails;
		this.subscriptionRenewDetails = subscriptionRenewDetails;
		this.rbtPurchaseDetails = rbtPurchaseDetails;
		this.rbtRecordingDetails = rbtRecordingDetails;
		this.rbtGiftDetails = rbtGiftDetails;
		this.freeRbtDetails = freeRbtDetails;
		this.campaignId = campaignId;
		this.subValidFor=subValidFor;
		this.offerValidFor=offerValidFor;
		this.packScope=packScope;
		this.priority=priority;
		this.smsCommand=smsCommand;
		this.ussdCommand=ussdCommand;
		this.ivrPath=ivrPath;
		this.ivrShortCode=ivrShortCode;
		this.maxWalletRbt=maxWalletRbt;
		this.userScope=userScope;
		this.isDefaultPack=isDefaultPack;
		this.remark=remark;
		this.validFor=validFor;
		this.userScope=userScope;
		this.start=start;
		this.end=end;
		this.rbtSetting=rbtSetting;
		this.activeInterface=activeInterface;
		
	}




	public String getPackName() {
		return packName;
	}

	public void setPackName(String packName) {
		this.packName = packName;
	}

	



	public List<SubscriptionDetail> getSubscriptionDetails() {
		return subscriptionDetails;
	}

	public void setSubscriptionDetails(
			List<SubscriptionDetail> subscriptionDetails) {
		this.subscriptionDetails = subscriptionDetails;
	}

	public List<SubscriptionRenewDetail> getSubscriptionRenewDetails() {
		return subscriptionRenewDetails;
	}

	public void setSubscriptionRenewDetails(
			List<SubscriptionRenewDetail> subscriptionRenewDetails) {
		this.subscriptionRenewDetails = subscriptionRenewDetails;
	}

	public List<RbtPurchaseDetail> getRbtPurchaseDetails() {
		return rbtPurchaseDetails;
	}

	public void setRbtPurchaseDetails(
			List<RbtPurchaseDetail> rbtPurchaseDetails) {
		this.rbtPurchaseDetails = rbtPurchaseDetails;
	}

	public List<RbtRecordingDetail> getRbtRecordingDetails() {
		return rbtRecordingDetails;
	}

	public void setRbtRecordingDetails(
			List<RbtRecordingDetail> rbtRecordingDetails) {
		this.rbtRecordingDetails = rbtRecordingDetails;
	}

	public List<RbtGiftDetail> getRbtGiftDetails() {
		return rbtGiftDetails;
	}

	public void setRbtGiftDetails(List<RbtGiftDetail> rbtGiftDetails) {
		this.rbtGiftDetails = rbtGiftDetails;
	}


	
	public List<RbtRenewDetail> getRbtRenewDetails() {
		return rbtRenewDetails;
	}




	public void setRbtRenewDetails(List<RbtRenewDetail> rbtRenewDetails) {
		this.rbtRenewDetails = rbtRenewDetails;
	}




	public List<RecordingRenewDetail> getRecordingRenewDetails() {
		return recordingRenewDetails;
	}




	public void setRecordingRenewDetails(
			List<RecordingRenewDetail> recordingRenewDetails) {
		this.recordingRenewDetails = recordingRenewDetails;
	}




	@Override
	public String toString() {
		return "PackSubDean [packName=" + packName
	           	+ subscriptionDetails + ", subscriptionRenewDetails="
				+ subscriptionRenewDetails + ", rbtPurchaseDetails="
				+ rbtPurchaseDetails + ", rbtRenewDetails=" + rbtRenewDetails
				+ ", rbtRecordingDetails=" + rbtRecordingDetails
				+ ", recordingRenewDetails=" + recordingRenewDetails
				+ ", rbtGiftDetails=" + rbtGiftDetails + ",freeRbtDetails="+freeRbtDetails+",campaignId="+campaignId
				+"],subValidFor["+subValidFor+"], offerValidFor ["+offerValidFor+"], packScope["+packScope+"], checkbox["+checkbox+"]"
				+", priority ["+priority+"], smsCommand ["+smsCommand+"], ussdCommand ["+ussdCommand+"], ivrPath ["+ivrPath+"]"
				+", ivrShortCode ["+ivrShortCode+"], maxWalletRbt ["+maxWalletRbt+"], userScope ["+userScope+"], rbtSetting ["+rbtSetting+"]"
				+", isDefaultPack ["+isDefaultPack+"], remark["+remark+"], sms ["+sms+"], web ["+web+"], ivr["+ivr+"]"
				+", ussd["+ussd+", obd["+obd+"], startTime["+start+"], endTime["+end+", PackValidFor["+validFor;
	}


	
}
