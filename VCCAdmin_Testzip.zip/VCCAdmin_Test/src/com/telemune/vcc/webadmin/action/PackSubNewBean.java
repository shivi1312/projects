package com.telemune.vcc.webadmin.action;

public class PackSubNewBean {

	String packName; 
	String subscriptionDetails;
	String subscriptionRenewDetails;
	String validFor;
	String subValidFor;
	String rbtPurchaseDetails;
	String rbtGiftDetails;
	String rbtRecordingDetails;
	String freeRbtDetails;
	Integer offerValidFor;
	Integer priority;
	String smsCommand;
	String ussdCommand;
	String ivrPath;
	String ivrShortCode;
	String activeInterface;
	String packScope;
	Integer maxWalletRbt;
	String userScope;
	String rbtSetting;
	String isDefaultPack;
	String remark;
	String start;
	String end;
	Integer campaignId;
	Integer packId;
	
	
	public PackSubNewBean() {
		// TODO Auto-generated constructor stub
	}
	
	public PackSubNewBean(
			String packName, 
			String subscriptionDetails,
			String subscriptionRenewDetails,
			String validFor,
			String subValidFor,
			String rbtPurchaseDetails,
			String rbtGiftDetails,
			String rbtRecordingDetails,
			String freeRbtDetails,
			Integer offerValidFor,
			Integer priority,
			String smsCommand,
			String ussdCommand,
			String ivrPath,
			String ivrShortCode,
			String activeInterface,
			String packScope,
			Integer maxWalletRbt,
			String userScope,
			String rbtSetting,
			String isDefaultPack,
			String remark,
			String start,
			String end,
			Integer campaignId
	       ){
		
		this.packName = packName;
		this.subscriptionDetails = subscriptionDetails;
		this.subscriptionRenewDetails = subscriptionRenewDetails;
		this.rbtPurchaseDetails = rbtPurchaseDetails;
		this.rbtRecordingDetails = rbtRecordingDetails;
		this.rbtGiftDetails = rbtGiftDetails;
		this.freeRbtDetails = freeRbtDetails;
		this.campaignId = campaignId;
		this.subValidFor=subValidFor;
		this.offerValidFor=offerValidFor;
		this.packScope=packScope;
		this.priority=priority;
		this.smsCommand=smsCommand;
		this.ussdCommand=ussdCommand;
		this.ivrPath=ivrPath;
		this.ivrShortCode=ivrShortCode;
		this.maxWalletRbt=maxWalletRbt;
		this.userScope=userScope;
		this.isDefaultPack=isDefaultPack;
		this.remark=remark;
		this.validFor=validFor;
		this.userScope=userScope;
		this.start=start;
		this.end=end;
		this.rbtSetting=rbtSetting;
		this.activeInterface=activeInterface;
		
	}
	
	
	//constructor overloading
	
	public PackSubNewBean(
			Integer PackId,
			String packName, 
			String subscriptionDetails,
			String subscriptionRenewDetails,
			String validFor,
			String subValidFor,
			String rbtPurchaseDetails,
			String rbtGiftDetails,
			String rbtRecordingDetails,
			String freeRbtDetails,
			Integer offerValidFor,
			Integer priority,
			String smsCommand,
			String ussdCommand,
			String ivrPath,
			String ivrShortCode,
			String activeInterface,
			String packScope,
			Integer maxWalletRbt,
			String userScope,
			String rbtSetting,
			String isDefaultPack,
			String remark,
			String start,
			String end,
			Integer campaignId
	       ){
		this.packId=PackId;
		this.packName = packName;
		this.subscriptionDetails = subscriptionDetails;
		this.subscriptionRenewDetails = subscriptionRenewDetails;
		this.rbtPurchaseDetails = rbtPurchaseDetails;
		this.rbtRecordingDetails = rbtRecordingDetails;
		this.rbtGiftDetails = rbtGiftDetails;
		this.freeRbtDetails = freeRbtDetails;
		this.campaignId = campaignId;
		this.subValidFor=subValidFor;
		this.offerValidFor=offerValidFor;
		this.packScope=packScope;
		this.priority=priority;
		this.smsCommand=smsCommand;
		this.ussdCommand=ussdCommand;
		this.ivrPath=ivrPath;
		this.ivrShortCode=ivrShortCode;
		this.maxWalletRbt=maxWalletRbt;
		this.userScope=userScope;
		this.isDefaultPack=isDefaultPack;
		this.remark=remark;
		this.validFor=validFor;
		this.userScope=userScope;
		this.start=start;
		this.end=end;
		this.rbtSetting=rbtSetting;
		this.activeInterface=activeInterface;
		
	}

	
	

	public Integer getPackId() {
		return packId;
	}


	public void setPackId(Integer packId) {
		this.packId = packId;
	}


	public String getPackName() {
		return packName;
	}

	public void setPackName(String packName) {
		this.packName = packName;
	}

	public String getSubscriptionDetails() {
		return subscriptionDetails;
	}

	public void setSubscriptionDetails(String subscriptionDetails) {
		this.subscriptionDetails = subscriptionDetails;
	}

	public String getSubscriptionRenewDetails() {
		return subscriptionRenewDetails;
	}

	public void setSubscriptionRenewDetails(String subscriptionRenewDetails) {
		this.subscriptionRenewDetails = subscriptionRenewDetails;
	}

	public String getValidFor() {
		return validFor;
	}

	public void setValidFor(String validFor) {
		this.validFor = validFor;
	}

	public String getSubValidFor() {
		return subValidFor;
	}

	public void setSubValidFor(String subValidFor) {
		this.subValidFor = subValidFor;
	}

	public String getRbtPurchaseDetails() {
		return rbtPurchaseDetails;
	}

	public void setRbtPurchaseDetails(String rbtPurchaseDetails) {
		this.rbtPurchaseDetails = rbtPurchaseDetails;
	}

	public String getRbtGiftDetails() {
		return rbtGiftDetails;
	}

	public void setRbtGiftDetails(String rbtGiftDetails) {
		this.rbtGiftDetails = rbtGiftDetails;
	}

	public String getRbtRecordingDetails() {
		return rbtRecordingDetails;
	}

	public void setRbtRecordingDetails(String rbtRecordingDetails) {
		this.rbtRecordingDetails = rbtRecordingDetails;
	}

	public String getFreeRbtDetails() {
		return freeRbtDetails;
	}

	public void setFreeRbtDetails(String freeRbtDetails) {
		this.freeRbtDetails = freeRbtDetails;
	}

	public Integer getOfferValidFor() {
		return offerValidFor;
	}

	public void setOfferValidFor(Integer offerValidFor) {
		this.offerValidFor = offerValidFor;
	}

	public Integer getPriority() {
		return priority;
	}

	public void setPriority(Integer priority) {
		this.priority = priority;
	}

	public String getSmsCommand() {
		return smsCommand;
	}

	public void setSmsCommand(String smsCommand) {
		this.smsCommand = smsCommand;
	}

	public String getUssdCommand() {
		return ussdCommand;
	}

	public void setUssdCommand(String ussdCommand) {
		this.ussdCommand = ussdCommand;
	}

	public String getIvrPath() {
		return ivrPath;
	}

	public void setIvrPath(String ivrPath) {
		this.ivrPath = ivrPath;
	}

	public String getIvrShortCode() {
		return ivrShortCode;
	}

	public void setIvrShortCode(String ivrShortCode) {
		this.ivrShortCode = ivrShortCode;
	}

	public String getActiveInterface() {
		return activeInterface;
	}

	public void setActiveInterface(String activeInterface) {
		this.activeInterface = activeInterface;
	}

	public String getPackScope() {
		return packScope;
	}

	public void setPackScope(String packScope) {
		this.packScope = packScope;
	}

	public Integer getMaxWalletRbt() {
		return maxWalletRbt;
	}

	public void setMaxWalletRbt(Integer maxWalletRbt) {
		this.maxWalletRbt = maxWalletRbt;
	}

	public String getUserScope() {
		return userScope;
	}

	public void setUserScope(String userScope) {
		this.userScope = userScope;
	}

	public String getRbtSetting() {
		return rbtSetting;
	}

	public void setRbtSetting(String rbtSetting) {
		this.rbtSetting = rbtSetting;
	}

	public String getIsDefaultPack() {
		return isDefaultPack;
	}

	public void setIsDefaultPack(String isDefaultPack) {
		this.isDefaultPack = isDefaultPack;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getStart() {
		return start;
	}

	public void setStart(String start) {
		this.start = start;
	}

	public String getEnd() {
		return end;
	}

	public void setEnd(String end) {
		this.end = end;
	}

	public Integer getCampaignId() {
		return campaignId;
	}

	public void setCampaignId(Integer campaignId) {
		this.campaignId = campaignId;
	}
	
	
	
	
}
