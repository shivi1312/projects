package com.telemune.vcc.webadmin.action;

import java.util.ArrayList;
import org.apache.log4j.Logger;
import com.telemune.dbutilities.Connection;
import com.telemune.vcc.common.TSSJavaUtil;
import com.telemune.vcc.common.ValidateAction;
import com.telemune.vcc.webadmin.*;

public class PromotionalMgmtAction extends ValidateAction{

	
	private String message;
	Logger logger=Logger.getLogger(PromotionalMgmtAction.class);
	PromotionalMgmtBean bean= null;
	ArrayList<PromotionPack> packAl=null;
	ChargingCodeManager chgManager = null;
	PromotionPackManager promoManager=null;
	
	
	public PromotionalMgmtAction()
	{
		setLinkName("webadmin");
	}
	String promoPackUrl="promoManageList.action?bean.id=2";
	String promoOfferUrl="showPromoOffer.action?bean.id=2";
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public PromotionalMgmtBean getBean() {
		return bean;
	}
	public void setBean(PromotionalMgmtBean bean) {
		this.bean = bean;
	}
	
	
public ArrayList<PromotionPack> getPackAl() {
		return packAl;
	}
	public void setPackAl(ArrayList<PromotionPack> packAl) {
		this.packAl = packAl;
	}
	

	// this function is for get the data for add or modify promotional pack 
public String getDetailAddPromoPack()
{
	logger.info("Inside function getDetailAddPromoPack()......");
	if(!checkSession().equalsIgnoreCase("success")){
	return "error";
	}else{
		
		Connection con= null;
	  String retVal="failure";
	 int id= bean.getId();
	 
	 ArrayList chgAl =  null;
	  ArrayList newChgAl= null;
	  ArrayList sizeAl =  null;
	  ArrayList freeAl =  null;
	  ArrayList packAl =  null;
	  
	  
	  try{
	  con=TSSJavaUtil.instance().getconnection();
	  chgManager = new ChargingCodeManager() ;
	  chgAl =  new ArrayList();
	  newChgAl= new ArrayList();
	  chgAl.clear();
	  int val = chgManager.getChargingCode(chgAl,con);
	  
	  sizeAl =  new ArrayList();
	  sizeAl.clear();
      for(int i=1;i<=10;i++)
      {
    	  PromotionalMgmtBean valBean= new PromotionalMgmtBean();
          valBean.setVal(Integer.valueOf(i));
          sizeAl.add(valBean);
      }
      freeAl =  new ArrayList();
      freeAl.clear();
      for(int i=0;i<11;i++)
      {
    	  PromotionalMgmtBean valBean= new PromotionalMgmtBean();
          valBean.setVal(Integer.valueOf(i));
          freeAl.add(valBean);
      }
      newChgAl.clear();
      for(int i=0;i<chgAl.size();i++)
      {
    	  
    	  ChargingCode chgOb=(ChargingCode)chgAl.get(i);
    	  if(chgOb.getChgCode()>7)
    	  {
    	  ChargingCode chCode= new ChargingCode();
    	  chCode.setChgName(chgOb.getChgName());
		//	chCode.setAmountP (rs.getDouble ("AMOUNT_PRE"));
			//chCode.setAmountO (rs.getDouble ("AMOUNT_POST"));
			chCode.setChgCode (chgOb.getChgCode());
    	  newChgAl.add(chCode);
    	  }
    	  
      }
      
      if(id==2)
      {
    	  int packId=bean.getPackId();
    	  promoManager = new PromotionPackManager() ;
    	  packAl =  new ArrayList();
    	  bean.setPackId(packId);
    	  int value = promoManager.getPromotionPack(packAl, packId,con);
          for(int z =0;z<packAl.size();z++)
          {
           PromotionPack promo = (PromotionPack) packAl.get(z);
           bean.setPackName(promo.getPackName());
           bean.setFreePack(promo.getFreeRbt());
//           bean.setChgCode(promo.getChgCode());
           bean.setChgCode((int)promo.getPackCost());
           bean.setPackSize(promo.getPackSize());
           
           bean.setOldPackName(promo.getPackName());
           bean.setOldFreePack(promo.getFreeRbt());
           bean.setOldChgCode(promo.getChgCode());
           bean.setOldPackSize(promo.getPackSize());
          }

      }
      
      
      bean.setChgAl(newChgAl);
      bean.setFreeAl(freeAl);
      bean.setSizeAl(sizeAl);
      logger.debug("Inside function getDetailAddPromoPack()...... ArrayList size : "+bean.getSizeAl().size());
      retVal="success"; 
	  }catch(Exception e)
	  {
	  logger.error("Exception inside getDetailAddPromoPack(),,,,,",e);
	  }finally
	  {
	  	if(con!=null)
	  		try {
	  			TSSJavaUtil.instance().freeConnection(con);
	  		} catch (Exception e) {
	  			// TODO Auto-generated catch block
	  			e.printStackTrace();
	  		}
	  	chgManager=null;
	  	chgAl =  null;
		 newChgAl=null;
		 sizeAl =  null;
		 freeAl =  null;
		 packAl =  null;
		 promoManager=null; 
	  }

	return retVal;
	}
}


// this fucntion is for aadd the promotional pack
public String handleAddPromotionalPack()
{
	this.actionName=promoPackUrl;
	logger.info("Inside function handleAddPromotionalPack(),,,,,");
	if(!checkSession().equalsIgnoreCase("success")){
		return "error";
		}else{
			 
	Connection con= null;
	  String retVal="failure";
	  try{
	  con=TSSJavaUtil.instance().getconnection();
	    promoManager = new PromotionPackManager();
      PromotionPack promo = new PromotionPack();

      promo.setPackName(bean.getPackName());
      promo.setPackSize(bean.getPackSize());
      promo.setPackCost(bean.getChgCode());
      promo.setFreeRbt(bean.getFreePack());

      int i = promoManager.addPromotionPack(promo,con);

      if(i < 0)
      {
              if(i == -2 )
              {

                      //logger.info("webadmin/Promotion: The Promotion Pack already exists");
                      this.setMessage(getText("alExist"));
              }
              else
              {
            	  this.setMessage(getText("tryLater"));
              }
      }
      else if(i > 0)
      {
              //logger.info("webadmin/Promotion: Promotion pack is added Successfully");
              this.setMessage(getText("addSuccess"));
      }
      
      logger.debug("Inside function handleAddPromotionalPack(),,,,,  message : "+this.getMessage());
      
      retVal="success";
      
	  }catch(Exception e)
	  {
	  logger.error("Exception inside handleAddPromotionalPack() : ",e);
	  }finally
	  {
	  	if(con!=null)
	  		try {
	  			TSSJavaUtil.instance().freeConnection(con);
	  		} catch (Exception e) {
	  			// TODO Auto-generated catch block
	  			e.printStackTrace();
	  		}
	  	promoManager=null;
	  }
	return retVal;
		}
}

// this function is for manage promotional pack
public String getPromoPackDetail()
{
	logger.info("Inside function getPromoPackDetail().....");
	if(!checkSession().equalsIgnoreCase("success")){
		return "error";
		}else{
			
	  Connection con= null;
	  String retVal="failure";
	  try{
	  con=TSSJavaUtil.instance().getconnection();
	  promoManager = new PromotionPackManager() ;
	  packAl =  new ArrayList<PromotionPack>();
	    
	    int val = promoManager.getPromotionPacks(packAl,con);
	  
	    
	    logger.debug("Inside function getPromoPackDetail().....packAl size : "+packAl.size());
	    
	  retVal="success";
	  }catch(Exception e)
	  {
	  logger.error("Exception inside getPromoPackDetail().....",e);
	  }finally
	  {
	  	if(con!=null)
	  		try {
	  			TSSJavaUtil.instance().freeConnection(con);
	  		} catch (Exception e) {
	  			// TODO Auto-generated catch block
	  			e.printStackTrace();
	  		}
	  	promoManager=null;
	  }
return retVal;
		}
}

// this function is fro handle delete Promotional pack
public String handleDeletePromotionalPack()
{
	
	this.actionName=promoPackUrl;
	logger.info("Inside function handleDeletePromotionalPack()........");
	if(!checkSession().equalsIgnoreCase("success")){
		return "error";
		}else{
			
	//System.out.println("Inside function handleDeletePromotionalPack()........");
	  Connection con= null;
	  String retVal="failure";
	  try{
	  con=TSSJavaUtil.instance().getconnection();
	  promoManager = new PromotionPackManager() ;
	  String Arr[] = bean.getDeleteAl();
	 // System.out.println("length-->"+bean.getDeleteAl().length);
      ArrayList promoArr = new ArrayList();
      for(int x=0;x<Arr.length;x++)
      {
    	  //System.out.println(Arr[x]);
              promoArr.add(Arr[x]);
      }
      int i = promoManager.deletePromoPack(promoArr,con);
      logger.debug("Inside function handleDeletePromotionalPack()........promoArr size : "+promoArr.size());
      if(i <0)
      {
             // logger.info("webadmin/PromotionPack: promopack cannot be deleted");
              this.setMessage(getText("tryLater"));
      }
      else if(i==1)
      {
              //logger.info("webadmin/PromotionPack: promopack deleted successfully");
              this.setMessage(getText("delSuccess"));
      }
      logger.debug("Inside function handleDeletePromotionalPack()........Message : "+this.getMessage());
	  retVal="success";
	  }catch(Exception e)
	  {
	  logger.error("Exception inside handleDeletePromotionalPack()........",e);
	  e.printStackTrace();
	  }finally
	  {
	  	if(con!=null)
	  		try {
	  			TSSJavaUtil.instance().freeConnection(con);
	  		} catch (Exception e) {
	  			// TODO Auto-generated catch block
	  			e.printStackTrace();
	  		}promoManager=null;
	  }

return retVal;	
		}
}


// this fuinction  is for handle the modify Promo pack

public String handlePromoPackModify()
{
	this.actionName=promoPackUrl;
	logger.info("Inside fucntion handlePromoPackModify(),,,,,,");
	if(!checkSession().equalsIgnoreCase("success")){
		return "error";
		}else{
			
	//System.out.println("Inside fucntion handlePromoPackModify(),,,,,,");
	  Connection con= null;
	  String retVal="failure";
	  WebAdminLogManager webadminlogs=null;
	  WebAdminLog logobj=null;
	  PromotionPack promo = null;
	  try{
	  con=TSSJavaUtil.instance().getconnection();
	  
	  String user_name=(String)sessionMap.get("user");
	  promoManager = new PromotionPackManager();
	  promo = new PromotionPack();

	  //System.out.println(bean.getPackName()+ "  "+bean.getPackSize()+"  "+(long)bean.getChgCode()+"  "+bean.getFreePack()+" "+bean.getPackId());
	  promo.setPackName( bean.getPackName());
	  promo.setPackSize(bean.getPackSize());
	  promo.setPackCost(bean.getChgCode());
	  promo.setFreeRbt(bean.getFreePack());
	  promo.setPackId(bean.getPackId());
	  String packnameold= bean.getOldPackName();

	  webadminlogs= new WebAdminLogManager();
	  logobj=new WebAdminLog();
	 int k=0;
	    String old_values="PACK_ID:"+bean.getPackId()+";";
	    String new_values="PACK_ID:"+bean.getPackId()+";";
	 if(!packnameold.equals(bean.getPackName()))
	 {
	 old_values=old_values+"PACK_NAME:"+packnameold+";";
	 new_values=new_values+"PACK_NAME:"+bean.getOldPackName()+";";
	 k=1;
	 }
	 if(bean.getOldPackSize()!=bean.getPackSize())
	 {
	 old_values=old_values+"PACK_SIZE:"+bean.getOldPackSize()+";";
	 new_values=new_values+"PACK_SIZE:"+bean.getPackSize()+";";
	 k=1;
	 }
	 if(bean.getOldChgCode()!=bean.getChgCode())
	 {
	 old_values=old_values+"PACK_COST:"+bean.getOldChgCode()+";";
	 new_values=new_values+"PACK_COST:"+bean.getChgCode()+";";
	 k=1;
	 }
	 if(bean.getOldFreePack()!=bean.getFreePack())
	 {
	 old_values=old_values+"FREE_RBTS:"+bean.getOldFreePack()+";";
	 new_values=new_values+"FREE_RBTS:"+bean.getFreePack()+";";
	 k=1;
	 }
	 if(k==1)
	 {
	                 logobj.setTableName("CRBT_RBT_PACK");
	                 logobj.setlink("promotionmanagementlog");
	                 logobj.setuser(user_name);
	                 logobj.setPreviousvalue(old_values);
	                 logobj.setCurrentvalue(new_values);
	 }

	  int i = promoManager.modifyPromotionPack(promo, packnameold,con);

	  if(i < 0)
	  {
	   if(i == -2 )
	   {

	   // logger.info("webadmin/Promotion: The Promotion Pack already exists");
	    this.setMessage(getText("alExist"));
	   }
	   else
	   {
		   this.setMessage(getText("tryLater"));
	   }
	  }
	  else if(i > 0)
	  {
	 int res = webadminlogs.createLog(logobj,con);
	 //logger.info("logs return =="+res);

	   //logger.info("webadmin/Promotion: Promotion pack is modified Successfully");
	   this.setMessage(getText("modSuccess"));
	  }
	  logger.debug("Inside fucntion handlePromoPackModify(),,,,,, Message : "+this.getMessage());
 retVal="success";
	  }catch(Exception e)
	  {
	  logger.error("Exception inside handlePromoPackModify(),,,,,,",e);
	  }finally
	  {
	  	if(con!=null)
	  		try {
	  			TSSJavaUtil.instance().freeConnection(con);
	  		} catch (Exception e) {
	  			// TODO Auto-generated catch block
	  			e.printStackTrace();
	  		}
	  	promoManager=null;
	  	 webadminlogs=null;
		 logobj=null;
		 promo = null;
		  
	  }
	  
	  return retVal;
		}
}


//@@@@@@@@@@@@@@@@@@@@@@@@ HERE THE FUNCTIONS FOR PROMOTIONAL OFFERS START @@@@@@@@@@@@@@@@@@@@@@@
// this function is for gettingte paln details for add or modify
public String getPlanDetails()
{
	logger.info("Inside function getPlanDetails().... ");
	if(!checkSession().equalsIgnoreCase("success")){
		return "error";
		}else{
			
	  Connection con= null;
	  String retVal="failure";
	  int id=bean.getId();
	  try{
	  con=TSSJavaUtil.instance().getconnection();
if(id==1)
{
	//logger.info("Inside condition where id=1 and  the data is for Add offer");
	promoManager = new PromotionPackManager() ;
     packAl =  new ArrayList();
    int val = promoManager.getPromotionPacks(packAl,con);
   
}else if(id==2)
{
	//logger.info("Inside condition when we are getting the list for view offers");
	 PromotionPackManager promoManager = new PromotionPackManager() ;
	    ArrayList<PromotionPack> offerAl =  new ArrayList<PromotionPack>();
	    int val = promoManager.getPromotionOffers(offerAl,con);
	    bean.setFreeAl(offerAl);
	    bean.setFreePack(offerAl.size());
}else if(id==3)
{
	int promoId=bean.getPackId();
	bean.setPackId(promoId);
}
	  retVal="success";
	  }catch(Exception e)
	  {
	  logger.error("Exception inside getPlanDetails() ,,,,,,, ",e);
	  }finally
	  {
	  	if(con!=null)
	  		try {
	  			TSSJavaUtil.instance().freeConnection(con);
	  		} catch (Exception e) {
	  			// TODO Auto-generated catch block
	  			e.printStackTrace();
	  		}
	  	promoManager=null;
	  }

	return retVal;
		}
	
}


//this function is for Add the promotional offers
public String handleAddPromoOffer()
{	
	this.actionName=promoOfferUrl;
	logger.info("Inside function handleAddPromoOffer().....");
	if(!checkSession().equalsIgnoreCase("success")){
		return "error";
		}else{
			
	  Connection con= null;
	  String retVal="failure";
	  try{
	  con=TSSJavaUtil.instance().getconnection();
	  promoManager = new PromotionPackManager();
      PromotionPack promo = new PromotionPack();
      promo.setStartDate(bean.getStDate());
      promo.setEndDate(bean.getEdDate());
      promo.setPackId(bean.getPackId());
      String subs_offer = bean.getFreSub();
      if(subs_offer==null) subs_offer="N";
      promo.setSubsOffer(subs_offer);
      int i = promoManager.definePromotionOffer(promo,con);
      if(i < 0)
      {
              if(i == -2 || i== -21)
              {
                      logger.info("webadmin/Promotion: The Promotion offer already exists for given parameters");
                      this.setMessage("The Promotion offer already exists for given parameters");
              }
              else
              {
            	  this.setMessage(getText("tryLater"));
              }
      }
      else if(i > 0)
      {
              logger.info("webadmin/Promotion: Promotion offer is added Successfully");
              this.setMessage(getText("addSuccess"));
      }

      retVal="success";
	  }catch(Exception e)
	  {
	  logger.error("Exception inside ",e);
	  }finally
	  {
	  	if(con!=null)
	  		try {
	  			TSSJavaUtil.instance().freeConnection(con);
	  		} catch (Exception e) {
	  			// TODO Auto-generated catch block
	  			e.printStackTrace();
	  		}
	  	promoManager=null;
	  }

	return retVal;
		}
}

// this function is for handle the delete function for promotional offers

public String handleDeletePromoOffer()
{
	this.actionName=promoOfferUrl;
	logger.info("Inside function hanldeDeletePromoOffer().....");
	if(!checkSession().equalsIgnoreCase("success")){
		return "error";
		}else{
			
	  Connection con= null;
	  String retVal="failure";
	  try{
	  con=TSSJavaUtil.instance().getconnection();
	  
	   promoManager = new PromotionPackManager() ;

       String Arr[] = bean.getDeleteAl();
       ArrayList promoArr = new ArrayList();
       for(int x=0;x<Arr.length;x++)
       {
               promoArr.add(Arr[x]);
       }
       int i = promoManager.deletePromoOffer(promoArr,con);

       if(i <0)
       {
               //logger.info("webadmin/PromotionPack: promopack cannot be deleted");
               this.setMessage(getText("cantDelete"));
       }
       else if(i==1)
       {
               //logger.info("webadmin/PromotionPack: promopack deleted successfully");
               this.setMessage(getText("delSuccess"));
       }

       logger.debug("Inside function hanldeDeletePromoOffer().....Message : "+this.getMessage());
	  retVal="success";
	  
	  }catch(Exception e)
	  {
	  logger.error("Exception inside hanldeDeletePromoOffer().......",e);
	  }finally
	  {
	  	if(con!=null)
	  		try {
	  			TSSJavaUtil.instance().freeConnection(con);
	  		} catch (Exception e) {
	  			// TODO Auto-generated catch block
	  			e.printStackTrace();
	  		}
	  	promoManager=null;
	  }
return retVal;
		}
}

// this function is for handle the modify promotional offers
public String handleModifyPromoOffer()
{
	this.actionName=promoOfferUrl;
	logger.info("Inside function handleModifyPromoOffer().............");
	if(!checkSession().equalsIgnoreCase("success")){
		return "error";
		}else{
			
	
	  Connection con= null;
	  String retVal="failure";
	  PromotionPack promo = null;
	  try{
	  con=TSSJavaUtil.instance().getconnection();
	   promoManager = new PromotionPackManager();
      promo = new PromotionPack();
      promo.setStartDate(bean.getStDate());
      promo.setEndDate(bean.getEdDate());
      promo.setPackId(bean.getPackId());
      //System.out.println(bean.getStDate()+"  "+bean.getEdDate()+"   "+bean.getPackId());
      int i = promoManager.modifyPromotionOffer(promo,con);
      if(i < 0)
      {
              if(i == -2 )
              {
                      //logger.info("webadmin/Promotion: The Promotion Offer already exists");
                      this.setMessage(getText("alExist"));
              }
              else
              {
            	  this.setMessage("Please try later");
              }
      }
      else if(i > 0)
      {
              //logger.info("webadmin/Promotion: Promotion offer  modified Successfully");
              this.setMessage(getText("modSuccess"));
      }
      logger.debug("Inside function handleModifyPromoOffer().............Message : "+this.getMessage());
	  retVal="success";
	  }catch(Exception e)
	  {
	  logger.error("Exception inside handleModifyPromoOffer()......",e);
	  }finally
	  {
	  	if(con!=null)
	  		try {
	  			TSSJavaUtil.instance().freeConnection(con);
	  		} catch (Exception e) {
	  			// TODO Auto-generated catch block
	  			e.printStackTrace();
	  		}
	  	promoManager=null;
	  	promo=null;
	  }
	  
	  return retVal;
		}

}


public String modify()
{
	logger.info("Inside function modify().............");
	if(!checkSession().equalsIgnoreCase("success")){
		return "error";
		}else{
			
	return "success";
		}
}


}
