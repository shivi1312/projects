package com.telemune.vcc.webadmin.action;

import java.util.ArrayList;

public class PromotionalMgmtBean {

	private String packName;
	private int packSize;
	private int chgCode;
	private int freePack;
	private int packId;
	private String oldPackName;
	private int oldPackSize;
	private int oldChgCode;
	private int oldFreePack;
	
	private ArrayList chgAl= new ArrayList();
	private ArrayList sizeAl= new ArrayList();
	private ArrayList freeAl= new ArrayList();
	private String[] deleteAl;
	
	private int id;
	private String stDate;
	private String edDate;
	private String freSub;
	
	
	
	public String getStDate() {
		return stDate;
	}
	public void setStDate(String stDate) {
		this.stDate = stDate;
	}
	public String getEdDate() {
		return edDate;
	}
	public void setEdDate(String edDate) {
		this.edDate = edDate;
	}
	public String getFreSub() {
		return freSub;
	}
	public void setFreSub(String freSub) {
		this.freSub = freSub;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getOldPackName() {
		return oldPackName;
	}
	public void setOldPackName(String oldPackName) {
		this.oldPackName = oldPackName;
	}
	public int getOldPackSize() {
		return oldPackSize;
	}
	public void setOldPackSize(int oldPackSize) {
		this.oldPackSize = oldPackSize;
	}
	public int getOldChgCode() {
		return oldChgCode;
	}
	public void setOldChgCode(int oldChgCode) {
		this.oldChgCode = oldChgCode;
	}
	public int getOldFreePack() {
		return oldFreePack;
	}
	public void setOldFreePack(int oldFreePack) {
		this.oldFreePack = oldFreePack;
	}
	public String[] getDeleteAl() {
		return deleteAl;
	}
	public void setDeleteAl(String[] deleteAl) {
		this.deleteAl = deleteAl;
	}
	public int getPackId() {
		return packId;
	}
	public void setPackId(int packId) {
		this.packId = packId;
	}
	private int val;
	
	public int getVal() {
		return val;
	}
	public void setVal(int val) {
		this.val = val;
	}
	public String getPackName() {
		return packName;
	}
	public void setPackName(String packName) {
		this.packName = packName;
	}
	public int getPackSize() {
		return packSize;
	}
	public void setPackSize(int packSize) {
		this.packSize = packSize;
	}
	public int getChgCode() {
		return chgCode;
	}
	public void setChgCode(int chgCode) {
		this.chgCode = chgCode;
	}
	public int getFreePack() {
		return freePack;
	}
	public void setFreePack(int freePack) {
		this.freePack = freePack;
	}
	public ArrayList getChgAl() {
		return chgAl;
	}
	public void setChgAl(ArrayList chgAl) {
		this.chgAl = chgAl;
	}
	public ArrayList getSizeAl() {
		return sizeAl;
	}
	public void setSizeAl(ArrayList sizeAl) {
		this.sizeAl = sizeAl;
	}
	public ArrayList getFreeAl() {
		return freeAl;
	}
	public void setFreeAl(ArrayList freeAl) {
		this.freeAl = freeAl;
	}
	
	
	
}
