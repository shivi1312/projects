package com.telemune.vcc.webadmin.action;

import java.util.ArrayList;
import org.apache.log4j.Logger;
import com.telemune.dbutilities.Connection;
import com.telemune.vcc.common.TSSJavaUtil;
import com.telemune.vcc.common.ValidateAction;
import com.telemune.vcc.webadmin.*;

public class RatePlanAction extends ValidateAction {

	
	private String message;
	Logger logger=Logger.getLogger(RatePlanAction.class);
	RatePlanBean bean= null;
	RbtRatePlanManager rbtrateManager =null;
	
	
	{
		this.actionName="rateManage.action?bean.searchtext=";
		setLinkName("webadmin");
	}
	
	
	
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public RatePlanBean getBean() {
		return bean;
	}

	public void setBean(RatePlanBean bean) {
		this.bean = bean;
	}
	
	
	
		
	
	// this function is for getting the 

	public String getChargingCodeList()
	{
		logger.info("Inside function getChargingCodeList()......");
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
			}else{
				
		bean= new RatePlanBean();
		Connection con= null;
		String retVal="failure";
		RbtRatePlan rbtrateplan  = null;
		ArrayList chargecode= null;
		try{
			con=TSSJavaUtil.instance().getconnection();

			rbtrateManager  = new RbtRatePlanManager();
			rbtrateplan  = new RbtRatePlan();
			chargecode= new ArrayList();
			int m = rbtrateManager.getRowCode(chargecode,con);
			logger.debug("THIS IS THE RETURN VALUE ["+m+"] AND THE SIZE OF LIST IS ["+chargecode.size()+"]");
			bean.setDataAl(chargecode);
			bean.setSize(chargecode.size());
			logger.debug("Inside function getChargingCodeList()......ArrayList size  : "+bean.getDataAl().size());
			retVal="success";  
		}catch(Exception e)
		{
			logger.error("Exception inside getChargingCodeList()......",e);
		}finally
		{
			if(con!=null)
				
					TSSJavaUtil.instance().freeConnection(con);

			rbtrateplan  = null;
			chargecode= null;
			rbtrateManager=null;
		}
		return retVal;
			}
	}

	// this fucntion is for adding the rate plan 
	public String handleAddRatePlan()
	{
		logger.info("Inside function handleAddRatePlan().......");
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
			}else{
				
		Connection con= null;
		String retVal="failure";
		RbtRatePlan rbtrateplan  = null;
		try{
			con=TSSJavaUtil.instance().getconnection();

			rbtrateManager  = new RbtRatePlanManager();
			rbtrateplan  = new RbtRatePlan();
			String result="";
			rbtrateplan.setRbtChgCode(bean.getRbtChgCode());
			rbtrateplan.setRbtGiftChgCode(bean.getGiftChgCode());
			rbtrateplan.setRbtNormalChgCode(bean.getNormalChgCode());
			rbtrateplan.setSubChgCode(bean.getSubChgCode());
			rbtrateplan.setRemarks(bean.getRemarks());
			rbtrateplan.setMRentCode(bean.getMonRenCode());
			rbtrateplan.setThreeWeek(bean.getThreeRenCode());
			rbtrateplan.setTwoWeek(bean.getTwRenCode());
			rbtrateplan.setOneWeek(bean.getOneRenCode());

			int res=rbtrateManager.addRbtRatePlan(rbtrateplan);
			if(res == -2 )
			{
				//logger.info("Rate Plan already exists");
				this.setMessage(getText("alExist"));
			}
			else if(res == 0 )
			{
				//logger.info("Rate Plan added successfully");
				this.setMessage(getText("addSuccess"));
			}
			else
			{
				//logger.info("Error!!! Try Again");
				this.setMessage(getText("tryLater"));
			}
			logger.info("Inside function handleAddRatePlan().......Message : "+this.getMessage());
			retVal="success";
		}catch(Exception e)
		{
			logger.error("Exception inside handleAddRatePlan().......",e);
		}finally
		{
			if(con!=null)
				try {
					TSSJavaUtil.instance().freeConnection(con);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			rbtrateplan=null;
			rbtrateManager=null;
		}

		return retVal;
			}
	}

	// this function is for handle the rate plan manage
	public String handlManageRatePlan()
	{
		logger.info("Inside function handlManageRatePlan().......");
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
			}else{
				
		//System.out.println("Inside function handlManageRatePlan().......");
		Connection con= null;
		String retVal="failure";
		RbtRatePlan rbtrateplan  = null;
		ArrayList chargecode= null;
		try{
			con=TSSJavaUtil.instance().getconnection();
			int defaultplan = Integer.parseInt(TSSJavaUtil.instance().getAppConfigParam("DEFAULT_RATE_PLAN"));
			//System.out.println("default plan : "+defaultplan);
			String searchtext="";
			String order="";
			int searchId=0;
			String keywords="";
			//System.out.println("searchtext : "+bean.getSearchtext());
			// if(bean.getSearchtext()!=null)
			searchtext =bean.getSearchtext().trim();
			//else
			//  searchtext =null;
			order = "ASC";//bean.getOrder();
			searchId =0;//bean.getSearchId();
			keywords =null;//bean.getKeyword();
			if(keywords==null || keywords.equalsIgnoreCase("null"))
			{
				keywords="REMARKS";
			}
			if(searchtext==null || searchtext.equalsIgnoreCase("null"))
			{
				searchtext="X";
			}
			if(searchId==1)
			{
				if(order.equals("ASC"))
				{
					order="DESC";
				}
				else
				{
					order="ASC";
				}
			}
			else
			{
				order="ASC";
			}

			rbtrateManager  = new RbtRatePlanManager();
			rbtrateplan  = new RbtRatePlan();
			chargecode= new ArrayList();
			int i = -1;
			// int pageId = -1;
			//  int pageCount = 0;
			System.out.println("---> "+keywords+":"+order+":"+searchtext);

			//pageId = bean.getPageId();
			// logger.info("* the pageid is---"+pageId);
			//if(pageId == 0)
			//{
			i = rbtrateManager.getrateplan (chargecode,keywords,order,searchtext,con);
			//logger.info("webadmin/RbtRatePlan: chargecode size= "+ chargecode.size() );
			logger.debug("Inside function handlManageRatePlan().....webadmin/RbtRatePlan: chargecode size= "+ chargecode.size() );

			// }
			/*else
              {
                      i = rbtrateManager.getrateplan (chargecode,keywords,order,searchtext,con);
                      //                                                              i=1;
              }*/
			TSSJavaUtil.instance().freeConnection(con);
			//if(( chargecode != null || pageId != -1) && chargecode.size()!=0)
			if( chargecode != null && chargecode.size()!=0)
			{
				logger.debug("Inside function handlManageRatePlan().....chargeCodeList is not null and size not 0");
				//  pageCount = chargecode.size()/10;
				int size=chargecode.size();
				// Object chargecodeArr[] = chargecode.toArray();
				//int start = (pageId *10) + 1;
				//  int end = ((start+10) > chargecodeArr.length)? (chargecodeArr.length): (start+9) ;
				ArrayList dataAl=new ArrayList();
				//  for(int r=start; r<=end; r++)
				for(int r=0; r<size; r++)
				{		
					//if(((RbtRatePlan)chargecodeArr[r-1]).getPlanId()==defaultplan)
					if(((RbtRatePlan)(chargecode.get(r))).getPlanId()==defaultplan)
					{}
					else
					{  //	 System.out.println("setting data not in default plan");
					RatePlanBean bean1=new RatePlanBean();
					bean1.setCodeId(((RbtRatePlan)(chargecode.get(r))).getPlanId());
					bean1.setRemarks(((RbtRatePlan)(chargecode.get(r))).getRemarks());
					dataAl.add(bean1);
					}
				}
				logger.info("Inside function handlManageRatePlan().....dataAl size : "+dataAl.size());  
				bean =new RatePlanBean();
				bean.setDataAl(dataAl);

				//  bean.setOrder(order);
				//  bean.setPageId(pageId);
				//   bean.setSearchId(searchId);
				//  bean.setSearchtext(searchtext);
				bean.setSize(dataAl.size());
				//    bean.setStart(start);
				//    bean.setEnd(end);
				//    bean.setKeyword(keywords);
				//    bean.setPagecount(pageCount);
				retVal="success";
			}

		}catch(Exception e)
		{
			logger.error("Exception inside handlManageRatePlan()............",e);
		}finally
		{
			if(con!=null)
				try {
					TSSJavaUtil.instance().freeConnection(con);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			rbtrateplan  = null;
			chargecode= null;
			rbtrateManager=null;
		}
		return retVal;
			}

	}

	// this function handle the view of rate Plan manage
	public String handleViewRatePlan()
	{
		logger.info("Inside function handleViewRatePlan() ");
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
			}else{
				
		Connection con= null;
		String retVal="failure";
		try{
			con=TSSJavaUtil.instance().getconnection();

			int planId=0;
			planId =bean.getPlanId();
			//int id= bean.getId();
			rbtrateManager  = new RbtRatePlanManager();

			//if(id==1)
			//{
			int m = rbtrateManager.viewRatePlan(bean,planId,con);
			//}
			/*else
	  {
	  ArrayList chargecode= new ArrayList();
	  int m = rbtrateManager.getRowCodeModify(chargecode,bean,planId,con);
	  bean.setDataAl(chargecode);
	  bean.setSize(chargecode.size());
  }*/
			TSSJavaUtil.instance().freeConnection(con); 
			retVal="success";
		}catch(Exception e)
		{
			logger.error("Exception inside handleViewRatePlan...... ",e);
		}finally
		{
			if(con!=null)
				try {
					TSSJavaUtil.instance().freeConnection(con);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			rbtrateManager=null;
		}
		return retVal;
			}
	}


	//this function handle the modify page of rate Plan manage
	public String ratePlanModifyPage()
	{
		logger.info("Inside function ratePlanModifyPage() ");
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
			}else{
				
		Connection con= null;
		String retVal="failure";
		ArrayList chargecode= null;
		try{
			con=TSSJavaUtil.instance().getconnection();

			int planId=0;
			planId =bean.getPlanId();
			//int id= bean.getId();
			rbtrateManager  = new RbtRatePlanManager();
			bean = new RatePlanBean();
			int m = rbtrateManager.viewRatePlan(bean,planId,con);
			chargecode= new ArrayList();
			//System.out.println("connection object 2: "+con);
			int n = rbtrateManager.getRowCode(chargecode,con);
			//System.out.println("connection object 3: "+con);
			bean.setDataAl(chargecode);
			bean.setSize(chargecode.size());
			logger.debug("Inside function ratePlanModifyPage()......ArrayList size() : "+bean.getDataAl().size());
			//}
			/*else
	  {
	  ArrayList chargecode= new ArrayList();
	  int m = rbtrateManager.getRowCodeModify(chargecode,bean,planId,con);
	  bean.setDataAl(chargecode);
	  bean.setSize(chargecode.size());
}*/
			TSSJavaUtil.instance().freeConnection(con); 
			retVal="success";
		}catch(Exception e)
		{
			logger.error("Exception inside ",e);
		}finally
		{
			if(con!=null)
				try {
					TSSJavaUtil.instance().freeConnection(con);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			chargecode=null;
			rbtrateManager=null;
		}
		return retVal;
			}
	}


	// this function is for modify Rate plan   
	public String handleModifyRatePlan()
	{
		logger.info("Inside function handleModifyRatePlan().......");
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
			}else{
				
		//System.out.println("Inside function handleModifyRatePlan().......");
		Connection con= null;
		String retVal="failure";
		WebAdminLogManager webadminlogs= null;
		RbtRatePlan rbtrateplan  = null;
		RbtRatePlan old_rbtrateplan  = null;
		WebAdminLog logobj=null;
		try{
			con=TSSJavaUtil.instance().getconnection();
		

			rbtrateManager  = new RbtRatePlanManager();
			webadminlogs= new WebAdminLogManager();
			ArrayList logarray= new ArrayList();

			rbtrateplan  = new RbtRatePlan();
			old_rbtrateplan  = new RbtRatePlan();
			String result="";
			int pid=bean.getPlanId();
			rbtrateplan.setRbtChgCode(bean.getRbtChgCode());
			rbtrateplan.setRbtGiftChgCode(bean.getGiftChgCode());
			rbtrateplan.setRbtNormalChgCode(bean.getNormalChgCode());
			rbtrateplan.setSubChgCode(bean.getSubChgCode());
			rbtrateplan.setRemarks(bean.getRemarks());
			rbtrateplan.setMRentCode(bean.getMonRenCode());
			rbtrateplan.setThreeWeek(bean.getThreeRenCode());
			rbtrateplan.setTwoWeek(bean.getTwRenCode());
			rbtrateplan.setOneWeek(bean.getOneRenCode());
			int i=0;
			String user_name=(String)sessionMap.get("user");

			if(!bean.getOldRbtChgCode().equals(bean.getRbtchgCode()))
			{
				logobj=new WebAdminLog();
				logobj.setTableName("CRBT_RATE_PLANS");
				logobj.setlink("RatePlanModify");
				logobj.setuser(user_name);
				logobj.setPreviousvalue(bean.getOldRbtChgCode());
				logobj.setCurrentvalue(bean.getRbtChgCode());
				logobj.setColName("RBT_CHARGE_CODE");
				logarray.add(logobj);
				i=1;
			}
			if(!bean.getOldGiftChgCode().equals(bean.getGiftChgCode()))
			{
				logobj=new WebAdminLog();
				logobj.setTableName("CRBT_RATE_PLANS");
				logobj.setlink("RatePlanModify");
				logobj.setuser(user_name);
				logobj.setPreviousvalue(bean.getOldGiftChgCode());
				logobj.setCurrentvalue(bean.getGiftChgCode());
				logobj.setColName("GIFT_CHARGE_CODE");
				logarray.add(logobj);
				i=1;
			}

			if(!bean.getOldNormalChgCode().equals(bean.getNormalChgCode()))
			{
				logobj=new WebAdminLog();
				logobj.setTableName("CRBT_RATE_PLANS");
				logobj.setlink("RatePlanModify");
				logobj.setuser(user_name);
				logobj.setPreviousvalue(bean.getOldNormalChgCode());
				logobj.setCurrentvalue(bean.getNormalChgCode());
				logobj.setColName("RBT_NORMAL_CHARGE_CODE");
				logarray.add(logobj);
				i=1;

			}

			if(!bean.getOldSubChgCode().equals(bean.getSubChgCode()))
			{
				logobj=new WebAdminLog();
				logobj.setTableName("CRBT_RATE_PLANS");
				logobj.setlink("RatePlanModify");
				logobj.setuser(user_name);
				logobj.setPreviousvalue(bean.getOldSubChgCode());
				logobj.setCurrentvalue(bean.getSubChgCode());
				logobj.setColName("SUBSCRIPTION_CHARGE_CODE");
				logarray.add(logobj);
				i=1;
			}
			if(!bean.getOldRemarks().equals(bean.getRemarks()))
			{
				logobj=new WebAdminLog();
				logobj.setTableName("CRBT_RATE_PLANS");
				logobj.setlink("RatePlanModify");
				logobj.setuser(user_name);
				logobj.setPreviousvalue(bean.getOldRemarks());
				logobj.setCurrentvalue(bean.getRemarks());
				logobj.setColName("REMARKS");
				logarray.add(logobj);
				i=1;
			}
			if(!bean.getOldMonRenCode().equals(bean.getMonRenCode()))
			{
				logobj=new WebAdminLog();
				logobj.setTableName("CRBT_RATE_PLANS");
				logobj.setlink("RatePlanModify");
				logobj.setuser(user_name);
				logobj.setPreviousvalue(bean.getOldMonRenCode());
				logobj.setCurrentvalue(bean.getMonRenCode());
				logobj.setColName("MONTHLY_RENT_CODE");
				logarray.add(logobj);
				i=1;
			}
			if(!bean.getOldThreeRenCode().equals(bean.getThreeRenCode()))
			{
				logobj=new WebAdminLog();
				logobj.setTableName("CRBT_RATE_PLANS");
				logobj.setlink("RatePlanModify");
				logobj.setuser(user_name);
				logobj.setPreviousvalue(bean.getOldThreeRenCode());
				logobj.setCurrentvalue(bean.getThreeRenCode());
				logobj.setColName("THREE_WEEK_RENT_CODE");
				logarray.add(logobj);
				i=1;
			}
			if(!bean.getOldTwRenCode().equals(bean.getTwRenCode()))
			{
				logobj=new WebAdminLog();
				logobj.setTableName("CRBT_RATE_PLANS");
				logobj.setlink("RatePlanModify");
				logobj.setuser(user_name);
				logobj.setPreviousvalue(bean.getOldTwRenCode());
				logobj.setCurrentvalue(bean.getTwRenCode());
				logobj.setColName("TWO_WEEK_RENT_CODE");
				logarray.add(logobj);
				i=1;

			}

			if(!bean.getOldOneRenCode().equals(bean.getOneRenCode()))
			{
				logobj=new WebAdminLog();
				logobj.setTableName("CRBT_RATE_PLANS");
				logobj.setlink("RatePlanModify");
				logobj.setuser(user_name);
				logobj.setPreviousvalue(bean.getOldOneRenCode());
				logobj.setCurrentvalue(bean.getOneRenCode());
				logobj.setColName("ONE_WEEK_RENT_CODE");
				logarray.add(logobj);
				i=1;
			}

			int res=rbtrateManager.saveEditRatePlan(rbtrateplan,pid,con);


			if(i==1)
			{
				int rest=webadminlogs.createLog(logarray,con);
			//	logger.info("logs return =="+rest);
			}

			if(res == 0 )
			{
				//logger.info("Rate Plan Modify successfully!!!");
				this.setMessage(getText("modSuccess"));
			}
			else
			{
				//logger.info("Error!!! Try Again");
				this.setMessage(getText("tryLater"));
			}
			logger.info("Inside function handleModifyRatePlan().......Message : "+this.getMessage());
			retVal="success";
			TSSJavaUtil.instance().freeConnection(con);
		}catch(Exception e)
		{
			logger.error("Exception inside handleModifyRatePlan()...",e);
			e.printStackTrace();
		}finally
		{
			if(con!=null)
				try {
					TSSJavaUtil.instance().freeConnection(con);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			webadminlogs= null;
			rbtrateplan  = null;
			old_rbtrateplan  = null;
			logobj=null;
			rbtrateplan=null;
		}

		return retVal;
			}
	}


	//this function is for handle delete rateplan from databse


	public String handleDeleteRatePlan()
	{
		logger.info("Inside function handleDeleteRatePlan().....");
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
			}else{
				
		//System.out.println("Inside function handleDeleteRatePlan().....");

		String retVal="failure";
		Connection con= null;

		RbtRatePlan rbtRatePlan = new RbtRatePlan();

		//ArrayList planIdAl = new ArrayList();
		String planIdAlArr[] = bean.getDeleteAl();
		try{

			rbtrateManager  = new RbtRatePlanManager();
			con=TSSJavaUtil.instance().getconnection();
			int i=0;
			for(int j = 0; j < planIdAlArr.length; j++)
			{
				//System.out.println("deleting planId : "+planIdAlArr[j]);   
				// planIdAl.add(planId);
				i=rbtrateManager.DeleteRbtRatePlan(Integer.parseInt(planIdAlArr[j]),con);
				//System.out.println("Inside function");
			}




			TSSJavaUtil.instance().freeConnection(con);

			if(i<0)
			{
				this.setMessage(getText("tryLater"));
			}else
			{
				this.setMessage(getText("delSuccess"));
			}
			logger.debug("Inside function handleDeleteRatePlan().....Message : "+this.getMessage());
			retVal ="success";
		}catch(Exception exe)
		{
			logger.error("Exception inside handleDeleteUserDetails()....",exe);
			exe.printStackTrace();
		}finally
		{
			
				if(con!=null)
				TSSJavaUtil.instance().freeConnection(con);
			rbtRatePlan=null;
			rbtrateManager=null;

		}

		return retVal;
			}
	}


}
