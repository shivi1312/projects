package com.telemune.vcc.webadmin.action;

import java.util.ArrayList;

public class RatePlanBean {
	
	    private String rbtChgCode;
	    private String giftChgCode;
	    private String normalChgCode;
	    private String subChgCode;
	    private String monRenCode;
	    private String threeRenCode;
	    private String twRenCode;
	    private String oneRenCode;
	    private String remarks;
	    
	    private String oldRbtChgCode;
	    private String oldGiftChgCode;
	    private String oldNormalChgCode;
	    private String oldSubChgCode;
	    private String oldMonRenCode;
	    private String oldThreeRenCode;
	    private String oldTwRenCode;
	    private String oldOneRenCode;
	    private String OldRemarks;
	    
	    private int codeId;
	    private String searchtext="";
	    private int pagecount;
	    private int pageId;
	    private int start;
	    private int end;
	    private int size;
	    private ArrayList dataAl=new ArrayList();
	    private int searchId;
	    private String order;
	    private String keyword;
	    private String[] deleteAl;
	    private int planId;
	    private int rescode;
	    private long rbtchgCode;
	    private String desc;
	    private int id;
	    
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getRbtChgCode() {
			return rbtChgCode;
		}
		public void setRbtChgCode(String rbtChgCode) {
			this.rbtChgCode = rbtChgCode;
		}
		public String getGiftChgCode() {
			return giftChgCode;
		}
		public void setGiftChgCode(String giftChgCode) {
			this.giftChgCode = giftChgCode;
		}
		public String getNormalChgCode() {
			return normalChgCode;
		}
		public void setNormalChgCode(String normalChgCode) {
			this.normalChgCode = normalChgCode;
		}
		public String getSubChgCode() {
			return subChgCode;
		}
		public void setSubChgCode(String subChgCode) {
			this.subChgCode = subChgCode;
		}
		public String getMonRenCode() {
			return monRenCode;
		}
		public void setMonRenCode(String monRenCode) {
			this.monRenCode = monRenCode;
		}
		public String getThreeRenCode() {
			return threeRenCode;
		}
		public void setThreeRenCode(String threeRenCode) {
			this.threeRenCode = threeRenCode;
		}
		public String getTwRenCode() {
			return twRenCode;
		}
		public void setTwRenCode(String twRenCode) {
			this.twRenCode = twRenCode;
		}
		public String getOneRenCode() {
			return oneRenCode;
		}
		public void setOneRenCode(String oneRenCode) {
			this.oneRenCode = oneRenCode;
		}
		public String getRemarks() {
			return remarks;
		}
		public void setRemarks(String remarks) {
			this.remarks = remarks;
		}
		public String getOldRbtChgCode() {
			return oldRbtChgCode;
		}
		public void setOldRbtChgCode(String oldRbtChgCode) {
			this.oldRbtChgCode = oldRbtChgCode;
		}
		public String getOldGiftChgCode() {
			return oldGiftChgCode;
		}
		public void setOldGiftChgCode(String oldGiftChgCode) {
			this.oldGiftChgCode = oldGiftChgCode;
		}
		public String getOldNormalChgCode() {
			return oldNormalChgCode;
		}
		public void setOldNormalChgCode(String oldNormalChgCode) {
			this.oldNormalChgCode = oldNormalChgCode;
		}
		public String getOldSubChgCode() {
			return oldSubChgCode;
		}
		public void setOldSubChgCode(String oldSubChgCode) {
			this.oldSubChgCode = oldSubChgCode;
		}
		public String getOldMonRenCode() {
			return oldMonRenCode;
		}
		public void setOldMonRenCode(String oldMonRenCode) {
			this.oldMonRenCode = oldMonRenCode;
		}
		public String getOldThreeRenCode() {
			return oldThreeRenCode;
		}
		public void setOldThreeRenCode(String oldThreeRenCode) {
			this.oldThreeRenCode = oldThreeRenCode;
		}
		public String getOldTwRenCode() {
			return oldTwRenCode;
		}
		public void setOldTwRenCode(String oldTwRenCode) {
			this.oldTwRenCode = oldTwRenCode;
		}
		public String getOldOneRenCode() {
			return oldOneRenCode;
		}
		public void setOldOneRenCode(String oldOneRenCode) {
			this.oldOneRenCode = oldOneRenCode;
		}
		public String getOldRemarks() {
			return OldRemarks;
		}
		public void setOldRemarks(String oldRemarks) {
			OldRemarks = oldRemarks;
		}
		public int getCodeId() {
			return codeId;
		}
		public void setCodeId(int codeId) {
			this.codeId = codeId;
		}
		public String getSearchtext() {
			return searchtext;
		}
		public void setSearchtext(String searchtext) {
			this.searchtext = searchtext;
		}
		public int getPagecount() {
			return pagecount;
		}
		public void setPagecount(int pagecount) {
			this.pagecount = pagecount;
		}
		public int getPageId() {
			return pageId;
		}
		public void setPageId(int pageId) {
			this.pageId = pageId;
		}
		public int getStart() {
			return start;
		}
		public void setStart(int start) {
			this.start = start;
		}
		public int getEnd() {
			return end;
		}
		public void setEnd(int end) {
			this.end = end;
		}
		public int getSize() {
			return size;
		}
		public void setSize(int size) {
			this.size = size;
		}
		
		
		public ArrayList getDataAl() {
			return dataAl;
		}
		public void setDataAl(ArrayList dataAl) {
			this.dataAl = dataAl;
		}
		public int getSearchId() {
			return searchId;
		}
		public void setSearchId(int searchId) {
			this.searchId = searchId;
		}
		public String getOrder() {
			return order;
		}
		public void setOrder(String order) {
			this.order = order;
		}
		public String getKeyword() {
			return keyword;
		}
		public void setKeyword(String keyword) {
			this.keyword = keyword;
		}
		public String[] getDeleteAl() {
			return deleteAl;
		}
		public void setDeleteAl(String[] deleteAl) {
			this.deleteAl = deleteAl;
		}
		public int getPlanId() {
			return planId;
		}
		public void setPlanId(int planId) {
			this.planId = planId;
		}
		public int getRescode() {
			return rescode;
		}
		public void setRescode(int rescode) {
			this.rescode = rescode;
		}
		public long getRbtchgCode() {
			return rbtchgCode;
		}
		public void setRbtchgCode(long rbtchgCode) {
			this.rbtchgCode = rbtchgCode;
		}
		public String getDesc() {
			return desc;
		}
		public void setDesc(String desc) {
			this.desc = desc;
		}

	    
}
