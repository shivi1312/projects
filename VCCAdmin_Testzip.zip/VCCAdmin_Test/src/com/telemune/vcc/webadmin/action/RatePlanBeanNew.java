package com.telemune.vcc.webadmin.action;

import java.util.List;

/**
 * 
 * @author Pankaj Kumar Mishra 
 * 		This class is made for holding value parsed by RatePlanNewAction, which is accessed from CRBT_RATE_PLAN.
 * 
 * String Description:
 * 		CC:42,DAYS:7,STID:6,FTID:6;CC:33,DAYS:6,STID:6,FTID:5
 * 
 * CC= Charging Code, 
 * DAYS= Validity for Number of days 
 * STID= Success Template ID 
 * FTID= Failure Template ID
 * 
 * ------------------------------------------------------
 * SUB:P,ARSUB:1,ARRBT:0,ARREC:1,SPSMSTID:1,RPSMSTID:1;SUB:O,ARSUB:1, ARRBT:0,ARREC:1,RPSMSTID:6
 * ------------------------------------------------------
 * SUB:P,ARSUB:1,ARRBT:0,ARREC:1,SPSMSTID:1,RPSMSTID:1;SUB:O,ARSUB:1,ARRBT:0,ARREC:1,RPSMSTID:6
 * ------------------------------------------------------
 * SUB= Subscriber [P-Repaid, O-Postpaid]
 * ARSUB = Auto renew Sub
 * ARRBT = Auto Renew RBT
 * ARREC = Auto Renew Recording
 * SPSMSTID = Subscription Promotional Template ID
 * RPSMSTID = Renew Promotional Template ID
 * ARSUB = Auto renew Subscription  [1- Enabled, 0-Disabled]
 * ARREC = Auto Renew Recording  [1- Enabled, 0-Disabled]
 * 
 * 
 */

/**
 * 
 * subFbChgCode
 *            Subscription Fall-back charging Code
 * rbtFbChgCode
 *            RBT Purchase Fall-back charging Code
 * giftFbChgCode
 *            RBT Gift Fall-back charging Code
 * recFbChgCode
 *            RBT recording Fall-back charging code
 * subRenewFbChgCode
 *            Subscription renew Fall-back charging Code
 * rbtRenewFbChgCode
 *            RBT purchase Renew Fall back Charging Code
 * recRenewFbChgCode
 *            Recorded RBT renew Fall-back charging Code
 * 
 * 
 * status
 *            Indicates whether Plan is active or not [A-Active, I-Inactive]
 * maskedName
 *            Masked Name is unique name given by Rateplan creator
 * process
 *            Process indicates post-handling of Postpaid and Prepaid
 *            customers' above activities. like - Whether they will be
 *            renewed automatically or not. Whether they will receive
 *            Promotional SMS or not.
 * 
 */
public class RatePlanBeanNew {
	

	private String maskedName="NA";
	private String subPrepaidPromo="NA";//true or false
	private String subPostpaidPromo="NA";//true or false
	private Integer subPrePaidTemplateId=0;
	private Integer subPostPaidTemplateId=0;
	
	
	private String enableSubAutoRenewPrepaid="NA";//true or false
	private String enableSubAutoRenewPostpaid="NA";//true or false
	
	
	private String rbtPurchasePrepaidPromo="NA";//true or false
	private String rbtPurchasePostpaidPromo="NA";//true or false
	private Integer rbtPurchasePrePaidTemplateId=0;
	private Integer rbtPurchasePostPaidTemplateId=0;
	
	
	private String enableRbtAutoRenewPrepaid="NA";//true or false
	private String enableRbtAutoRenewPostpaid="NA";//true or false
	
	private String enableRecordAutoRenewPostpaid="NA";//true or false
	private String enableRecordAutoRenewPrepaid="NA";//true or false
	
	
	private List  <SubscriptionDetail>subscriptionDetails;
	private List <SubscriptionRenewDetail> subscriptionRenewDetails;
	private List  <RbtPurchaseDetail>rbtPurchaseDetails;
	private List  <RbtRenewDetail>rbtRenewDetails;
	private List  <RbtRecordingDetail>rbtRecordingDetails;
	private List  <RecordingRenewDetail>recordingRenewDetails;
	private List  <RbtGiftDetail>rbtGiftDetails;
	private Integer scopeValue=0;
	
	
	public Integer getScopeValue() {
		return scopeValue;
	}


	public void setScopeValue(Integer scopeValue) {
		this.scopeValue = scopeValue;
	}


	public RatePlanBeanNew() {
		super();
	}

	
	private String scope;
	private int countryCode=0;
	
	

	public int getCountryCode() {
		return countryCode;
	}


	public void setCountryCode(int countryCode) {
		this.countryCode = countryCode;
	}
	public String getScope() {
		return scope;
	}
	public void setScope(String scope) {
		this.scope = scope;
	}

	public RatePlanBeanNew(String maskedName, String subPrepaidPromo,
			String subPostpaidPromo, Integer subPrePaidTemplateId,
			Integer subPostPaidTemplateId, String enableSubAutoRenewPostpaid,
			String enableSubAutoRenewPrepaid, String rbtPurchasePrepaidPromo,
			String rbtPurchasePostpaidPromo,
			Integer rbtPurchasePrePaidTemplateId,
			Integer rbtPurchasePostPaidTemplateId,
			String enableRbtAutoRenewPostpaid,
			String enableRbtAutoRenewPrepaid,
			String enableRecordAutoRenewPostpaid,
			String enableRecordAutoRenewPrepaid,
			List<SubscriptionDetail> subscriptionDetails,
			List<SubscriptionRenewDetail> subscriptionRenewDetails,
			List<RbtPurchaseDetail> rbtPurchaseDetails,
			List<RbtRenewDetail> rbtRenewDetails,
			List<RbtRecordingDetail> rbtRecordingDetails,
			List<RecordingRenewDetail> recordingRenewDetails,
			List<RbtGiftDetail> rbtGiftDetails) {
		
		super();
		this.maskedName = maskedName;
		this.subPrepaidPromo = subPrepaidPromo;
		this.subPostpaidPromo = subPostpaidPromo;
		this.subPrePaidTemplateId = subPrePaidTemplateId;
		this.subPostPaidTemplateId = subPostPaidTemplateId;
		this.enableSubAutoRenewPostpaid = enableSubAutoRenewPostpaid;
		this.enableSubAutoRenewPrepaid = enableSubAutoRenewPrepaid;
		this.rbtPurchasePrepaidPromo = rbtPurchasePrepaidPromo;
		this.rbtPurchasePostpaidPromo = rbtPurchasePostpaidPromo;
		this.rbtPurchasePrePaidTemplateId = rbtPurchasePrePaidTemplateId;
		this.rbtPurchasePostPaidTemplateId = rbtPurchasePostPaidTemplateId;
		this.enableRbtAutoRenewPostpaid = enableRbtAutoRenewPostpaid;
		this.enableRbtAutoRenewPrepaid = enableRbtAutoRenewPrepaid;
		this.enableRecordAutoRenewPostpaid = enableRecordAutoRenewPostpaid;
		this.enableRecordAutoRenewPrepaid = enableRecordAutoRenewPrepaid;
		this.subscriptionDetails = subscriptionDetails;
		this.subscriptionRenewDetails = subscriptionRenewDetails;
		this.rbtPurchaseDetails = rbtPurchaseDetails;
		this.rbtRenewDetails = rbtRenewDetails;
		this.rbtRecordingDetails = rbtRecordingDetails;
		this.recordingRenewDetails = recordingRenewDetails;
		this.rbtGiftDetails = rbtGiftDetails;
	}




	public String getMaskedName() {
		return maskedName;
	}

	public void setMaskedName(String maskedName) {
		this.maskedName = maskedName;
	}

	public String getSubPrepaidPromo() {
		return subPrepaidPromo;
	}

	public void setSubPrepaidPromo(String subPrepaidPromo) {
		this.subPrepaidPromo = subPrepaidPromo;
	}
	

	
	public String getSubPostpaidPromo() {
		return subPostpaidPromo;
	}

	public void setSubPostpaidPromo(String subPostpaidPromo) {
		this.subPostpaidPromo = subPostpaidPromo;
	}

	public Integer getSubPrePaidTemplateId() {
		return subPrePaidTemplateId;
	}

	public void setSubPrePaidTemplateId(Integer subPrePaidTemplateId) {
		this.subPrePaidTemplateId = subPrePaidTemplateId;
	}

	public Integer getSubPostPaidTemplateId() {
		return subPostPaidTemplateId;
	}

	public void setSubPostPaidTemplateId(Integer subPostPaidTemplateId) {
		this.subPostPaidTemplateId = subPostPaidTemplateId;
	}

	public String getEnableSubAutoRenewPostpaid() {
		return enableSubAutoRenewPostpaid;
	}

	public void setEnableSubAutoRenewPostpaid(String enableSubAutoRenewPostpaid) {
		this.enableSubAutoRenewPostpaid = enableSubAutoRenewPostpaid;
	}

	public String getEnableSubAutoRenewPrepaid() {
		return enableSubAutoRenewPrepaid;
	}

	public void setEnableSubAutoRenewPrepaid(String enableSubAutoRenewPrepaid) {
		this.enableSubAutoRenewPrepaid = enableSubAutoRenewPrepaid;
	}

	public String getRbtPurchasePrepaidPromo() {
		return rbtPurchasePrepaidPromo;
	}

	public void setRbtPurchasePrepaidPromo(String rbtPurchasePrepaidPromo) {
		this.rbtPurchasePrepaidPromo = rbtPurchasePrepaidPromo;
	}

	public String getRbtPurchasePostpaidPromo() {
		return rbtPurchasePostpaidPromo;
	}

	public void setRbtPurchasePostpaidPromo(String rbtPurchasePostpaidPromo) {
		this.rbtPurchasePostpaidPromo = rbtPurchasePostpaidPromo;
	}

	public Integer getRbtPurchasePrePaidTemplateId() {
		return rbtPurchasePrePaidTemplateId;
	}

	public void setRbtPurchasePrePaidTemplateId(Integer rbtPurchasePrePaidTemplateId) {
		this.rbtPurchasePrePaidTemplateId = rbtPurchasePrePaidTemplateId;
	}

	public Integer getRbtPurchasePostPaidTemplateId() {
		return rbtPurchasePostPaidTemplateId;
	}

	public void setRbtPurchasePostPaidTemplateId(
			Integer rbtPurchasePostPaidTemplateId) {
		this.rbtPurchasePostPaidTemplateId = rbtPurchasePostPaidTemplateId;
	}

	public String getEnableRbtAutoRenewPostpaid() {
		return enableRbtAutoRenewPostpaid;
	}

	public void setEnableRbtAutoRenewPostpaid(String enableRbtAutoRenewPostpaid) {
		this.enableRbtAutoRenewPostpaid = enableRbtAutoRenewPostpaid;
	}

	public String getEnableRbtAutoRenewPrepaid() {
		return enableRbtAutoRenewPrepaid;
	}

	public void setEnableRbtAutoRenewPrepaid(String enableRbtAutoRenewPrepaid) {
		this.enableRbtAutoRenewPrepaid = enableRbtAutoRenewPrepaid;
	}

	public List<SubscriptionDetail> getSubscriptionDetails() {
		return subscriptionDetails;
	}

	public void setSubscriptionDetails(
			List<SubscriptionDetail> subscriptionDetails) {
		this.subscriptionDetails = subscriptionDetails;
	}

	public List<SubscriptionRenewDetail> getSubscriptionRenewDetails() {
		return subscriptionRenewDetails;
	}

	public void setSubscriptionRenewDetails(
			List<SubscriptionRenewDetail> subscriptionRenewDetails) {
		this.subscriptionRenewDetails = subscriptionRenewDetails;
	}

	public List<RbtPurchaseDetail> getRbtPurchaseDetails() {
		return rbtPurchaseDetails;
	}

	public void setRbtPurchaseDetails(
			List<RbtPurchaseDetail> rbtPurchaseDetails) {
		this.rbtPurchaseDetails = rbtPurchaseDetails;
	}

	public List<RbtRecordingDetail> getRbtRecordingDetails() {
		return rbtRecordingDetails;
	}

	public void setRbtRecordingDetails(
			List<RbtRecordingDetail> rbtRecordingDetails) {
		this.rbtRecordingDetails = rbtRecordingDetails;
	}

	public List<RbtGiftDetail> getRbtGiftDetails() {
		return rbtGiftDetails;
	}

	public void setRbtGiftDetails(List<RbtGiftDetail> rbtGiftDetails) {
		this.rbtGiftDetails = rbtGiftDetails;
	}


	public String getEnableRecordAutoRenewPostpaid() {
		return enableRecordAutoRenewPostpaid;
	}




	public void setEnableRecordAutoRenewPostpaid(
			String enableRecordAutoRenewPostpaid) {
		this.enableRecordAutoRenewPostpaid = enableRecordAutoRenewPostpaid;
	}




	public String getEnableRecordAutoRenewPrepaid() {
		return enableRecordAutoRenewPrepaid;
	}




	public void setEnableRecordAutoRenewPrepaid(String enableRecordAutoRenewPrepaid) {
		this.enableRecordAutoRenewPrepaid = enableRecordAutoRenewPrepaid;
	}




	public List<RbtRenewDetail> getRbtRenewDetails() {
		return rbtRenewDetails;
	}




	public void setRbtRenewDetails(List<RbtRenewDetail> rbtRenewDetails) {
		this.rbtRenewDetails = rbtRenewDetails;
	}




	public List<RecordingRenewDetail> getRecordingRenewDetails() {
		return recordingRenewDetails;
	}




	public void setRecordingRenewDetails(
			List<RecordingRenewDetail> recordingRenewDetails) {
		this.recordingRenewDetails = recordingRenewDetails;
	}




	@Override
	public String toString() {
		return "RatePlanBeanNew [maskedName=" + maskedName
				+ ", subPrepaidPromo=" + subPrepaidPromo
				+ ", subPostpaidPromo=" + subPostpaidPromo
				+ ", subPrePaidTemplateId=" + subPrePaidTemplateId
				+ ", subPostPaidTemplateId=" + subPostPaidTemplateId
				+ ", enableSubAutoRenewPostpaid=" + enableSubAutoRenewPostpaid
				+ ", enableSubAutoRenewPrepaid=" + enableSubAutoRenewPrepaid
				+ ", rbtPurchasePrepaidPromo=" + rbtPurchasePrepaidPromo
				+ ", rbtPurchasePostpaidPromo=" + rbtPurchasePostpaidPromo
				+ ", rbtPurchasePrePaidTemplateId="
				+ rbtPurchasePrePaidTemplateId
				+ ", rbtPurchasePostPaidTemplateId="
				+ rbtPurchasePostPaidTemplateId
				+ ", enableRbtAutoRenewPostpaid=" + enableRbtAutoRenewPostpaid
				+ ", enableRbtAutoRenewPrepaid=" + enableRbtAutoRenewPrepaid
				+ ", enableRecordAutoRenewPostpaid="
				+ enableRecordAutoRenewPostpaid
				+ ", enableRecordAutoRenewPrepaid="
				+ enableRecordAutoRenewPrepaid + ", subscriptionDetails="
				+ subscriptionDetails + ", subscriptionRenewDetails="
				+ subscriptionRenewDetails + ", rbtPurchaseDetails="
				+ rbtPurchaseDetails + ", rbtRenewDetails=" + rbtRenewDetails
				+ ", rbtRecordingDetails=" + rbtRecordingDetails
				+ ", recordingRenewDetails=" + recordingRenewDetails
				+ ", rbtGiftDetails=" + rbtGiftDetails + "]";
	}


	
}
