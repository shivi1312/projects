package com.telemune.vcc.webadmin.action;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;
import org.codehaus.jettison.json.JSONObject;

import com.google.gson.JsonParser;
import com.telemune.dbutilities.Connection;
import com.telemune.vcc.common.HistoryGenerator;
import com.telemune.vcc.common.SessionHistory;
import com.telemune.vcc.common.TSSJavaUtil;
import com.telemune.vcc.common.ValidateAction;
import com.telemune.vcc.crbtcontent.TssStringUtill;
import com.telemune.vcc.model.HistoryDataBean;
import com.telemune.vcc.webadmin.ChargingCodeDetail;
import com.telemune.vcc.webadmin.MailBox;
import com.telemune.vcc.webadmin.MailBoxManager;
import com.telemune.vcc.webadmin.OperatorRange;
import com.telemune.vcc.webadmin.RatePlanManagerNew;
import com.telemune.vcc.webadmin.ScopeBean;
import com.telemune.vcc.webadmin.TemplateSMS;
import com.telemune.vcc.webadmin.VCCRatePlanBean;


/**
 * 
 * @author pankajmishra
 * This class is responsible to manage creating new, updating existing, deleting and modify
 * fall-back based rate-plan System for CRBT-System.
 *
 */
public class RatePlanNewAction extends ValidateAction {
	
	private static final long serialVersionUID = 1L;
	
	private Logger logger=Logger.getLogger(RatePlanNewAction.class);
	HistoryDataBean historyDataBean = null;
	HistoryGenerator historyGenerator = null;
	Connection con = null;
	{
		this.actionName="rateManage.action?bean.searchtext=";
		setLinkName("webadmin");
	}
	
	private ArrayList<ScopeBean> scopeList=null;
	public ArrayList<ScopeBean> getScopeList() {
		return scopeList;
	}
	public void setScopeList(ArrayList<ScopeBean> scopeList) {
		this.scopeList = scopeList;
	}
	
	private VCCRatePlanBean rateplan;
	private String message;
	int status=1;
	private String maskedName;
	RatePlanManagerNew rpManager=null;
	
	private List<ChargingCodeDetail> chargingCodeList;
	private List<TemplateSMS> templateSMSList;
	private List<VCCRatePlanBean> crbtRatePlanList;
	
	private int vmSubEnable=-1;
	private int vmRenEnable=-1;
	private int vmRecordEnable=1;
	private int vmRetrivEnable=-1;
	private int vmGroupEnable=-1;
	private int vmPullEnable=-1;
	
	private int vnSubEnable=-1;
	private int vnRenEnable=-1;
	private int vnRecordEnable=1;
	private int vnRetrivEnable=-1;
	private int vnGroupEnable=-1;
	private int vnPullEnable=1;
	
	
	
	private ArrayList<MailBox> mailBoxList;
	private int mailBox;
	private String operator;
	private ArrayList<OperatorRange> operatorList;
	private OperatorRange operatorRange=null;
	private String subType;
	private String classtype;
	
	

	
	//private Map<String,CrbtRatePlanBean> crbtRatePlanMap;
	
	public int getVnSubEnable() {
		return vnSubEnable;
	}
	public void setVnSubEnable(int vnSubEnable) {
		this.vnSubEnable = vnSubEnable;
	}
	public int getVnRenEnable() {
		return vnRenEnable;
	}
	public void setVnRenEnable(int vnRenEnable) {
		this.vnRenEnable = vnRenEnable;
	}
	public int getVnRecordEnable() {
		return vnRecordEnable;
	}
	public void setVnRecordEnable(int vnRecordEnable) {
		this.vnRecordEnable = vnRecordEnable;
	}
	public int getVnRetrivEnable() {
		return vnRetrivEnable;
	}
	public void setVnRetrivEnable(int vnRetrivEnable) {
		this.vnRetrivEnable = vnRetrivEnable;
	}
	public int getVnGroupEnable() {
		return vnGroupEnable;
	}
	public void setVnGroupEnable(int vnGroupEnable) {
		this.vnGroupEnable = vnGroupEnable;
	}
	public int getVnPullEnable() {
		return vnPullEnable;
	}
	public void setVnPullEnable(int vnPullEnable) {
		this.vnPullEnable = vnPullEnable;
	}
	public String getSubType() {
		return subType;
	}
	public void setSubType(String subType) {
		this.subType = subType;
	}
	public String getClasstype() {
		return classtype;
	}
	public void setClasstype(String classtype) {
		this.classtype = classtype;
	}
	public String getOperator() {
		return operator;
	}
	public void setOperator(String operator) {
		this.operator = operator;
	}
	public ArrayList<OperatorRange> getOperatorList() {
		return operatorList;
	}
	public void setOperatorList(ArrayList<OperatorRange> operatorList) {
		this.operatorList = operatorList;
	}
	public void setMailBox(int mailBox) {
		this.mailBox = mailBox;
	}
	public ArrayList<MailBox> getMailBoxList() {
		return mailBoxList;
	}
	public void setMailBoxList(ArrayList<MailBox> mailBoxList) {
		this.mailBoxList = mailBoxList;
	}
	public int getVmSubEnable() {
		return vmSubEnable;
	}
	public void setVmSubEnable(int vmSubEnable) {
		this.vmSubEnable = vmSubEnable;
	}
	public int getVmRenEnable() {
		return vmRenEnable;
	}
	public void setVmRenEnable(int vmRenEnable) {
		this.vmRenEnable = vmRenEnable;
	}
	public int getVmRecordEnable() {
		return vmRecordEnable;
	}
	public void setVmRecordEnable(int vmRecordEnable) {
		this.vmRecordEnable = vmRecordEnable;
	}
	public int getVmRetrivEnable() {
		return vmRetrivEnable;
	}
	public void setVmRetrivEnable(int vmRetrivEnable) {
		this.vmRetrivEnable = vmRetrivEnable;
	}
	public int getVmGroupEnable() {
		return vmGroupEnable;
	}
	public void setVmGroupEnable(int vmGroupEnable) {
		this.vmGroupEnable = vmGroupEnable;
	}
	public int getVmPullEnable() {
		return vmPullEnable;
	}
	public void setVmPullEnable(int vmPullEnable) {
		this.vmPullEnable = vmPullEnable;
	}

	private Map<Integer,String> chgCodeMap;
	
	/*private RatePlanBeanNew rateplan;*/
	
	private CrbtRatePlanBean crbtRateplanBean;
	private String actionType;
	
	
	
	
	
	
	
	
	
	
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
 
	public List<TemplateSMS> getTemplateSMSList() {
		return templateSMSList;
	}
	public void setTemplateSMSList(List<TemplateSMS> templateSMSList) {
		this.templateSMSList = templateSMSList;
	}
	
	public List<ChargingCodeDetail> getChargingCodeList() {
		return chargingCodeList;
	}
	public void setChargingCodeList(List<ChargingCodeDetail> chargingCodeList) {
		this.chargingCodeList = chargingCodeList;
	}
	
		public VCCRatePlanBean getRateplan() {
		return rateplan;
	}
	public void setRateplan(VCCRatePlanBean rateplan) {
		this.rateplan = rateplan;
	}
	
	
	public List<VCCRatePlanBean> getCrbtRatePlanList() {
		return crbtRatePlanList;
	}
	public void setCrbtRatePlanList(List<VCCRatePlanBean> crbtRatePlanList) {
		this.crbtRatePlanList = crbtRatePlanList;
	}
	
	public String getMaskedName() {
		return maskedName;
	}
	public void setMaskedName(String maskedName) {
		this.maskedName = maskedName;
	}
	
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	
	
	
	public String getActionType() {
		return actionType;
	}
	public void setActionType(String actionType) {
		this.actionType = actionType;
	}
	// TODO Auto-generated constructor stub

	
	
	public Map<Integer, String> getChgCodeMap() {
		return chgCodeMap;
	}
	public void setChgCodeMap(Map<Integer, String> chgCodeMap) {
		this.chgCodeMap = chgCodeMap;
	}
	
	/**
	 * @author pankajmishra
	 * This method validate whether MASKED_NAME given by user is available or all-ready used. 
	 * 
	 * @return java.lang.String
	 * 	success = if masked name is available to assign,
	 *  error   = if masked name is not available to assign or any other case of ERROR
	 */
	public String isMaskedNameExists(){
		rpManager=new RatePlanManagerNew();
		logger.info("action isMaskedNameExists = MASKED_NAME="+rateplan.getMaskName());
		try{
		 if(rpManager.isMaskedNameExists(rateplan.getMaskName())){
			 logger.info(" MaskendName =["+rateplan.getMaskName()+"] all-ready exists!!");
			  return ERROR;	 
			 	 
		 }else{
			 logger.info(" MaskendName =["+rateplan.getMaskName()+"]  is unique!!");
			 message="OK";
			 return SUCCESS;
		 }
		 
		}catch (Exception e) {
			e.printStackTrace();
			return ERROR;
		}
		finally
		{
			rpManager=null;
		}
	}//### END of isMaskedNameExists()
	
	
	public String isPackNameExists(){
		rpManager=new RatePlanManagerNew();
		logger.info("action isPackNameExists = MASKED_NAME="+rateplan.getMaskName());
		try{
		 if(rpManager.isPackNameExists(rateplan.getMaskName())){
			 logger.info(" PacName =["+rateplan.getMaskName()+"] all-ready exists!!");
			  return ERROR;	 
			 	 
		 }else{
			 logger.info(" PackName =["+rateplan.getMaskName()+"]  is unique!!");
			 message="OK";
			 return SUCCESS;
		 }
		 
		}catch (Exception e) {
			e.printStackTrace();
			return ERROR;
		}
		finally
		{
			rpManager=null;
		}
	}//### END of isMaskedNameExists()
	
	
	/**
	 * @author pankajmishra
	 * 
	 *         This method is called at Initial stage of Application loading and
	 *         populate private List<ChargingCodeDetail> chargingCodeList;
	 *         private List<TemplateSMS> templateSMSList;
	 *  
	 * @return java.lang.String success = request is successful error = if
	 *         operation failed due to any ERROR
	 */
	public String populateChgCodeAndTemplate(){
		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";

		} else {
			rpManager=new RatePlanManagerNew();
			operatorRange=new OperatorRange();
			operatorList=new ArrayList<OperatorRange>();
			
			try{
				chargingCodeList=rpManager.getChargingCodeList();
				templateSMSList=rpManager.getSMSTemplateList();
				this.vmSubEnable=Integer.parseInt(TSSJavaUtil.instance().getAppConfigParam("VM_SUB_ENABLE"));
				this.vmRenEnable=Integer.parseInt(TSSJavaUtil.instance().getAppConfigParam("VM_RENEW_ENABLE"));
				this.vmRecordEnable=Integer.parseInt(TSSJavaUtil.instance().getAppConfigParam("VM_RECORDING_ENABLE"));
				this.vmRetrivEnable=Integer.parseInt(TSSJavaUtil.instance().getAppConfigParam("VM_RETRIEVAL_ENABLE"));
				this.vmGroupEnable=Integer.parseInt(TSSJavaUtil.instance().getAppConfigParam("VM_GROUP_ENABLE"));
				this.vmPullEnable=Integer.parseInt(TSSJavaUtil.instance().getAppConfigParam("VM_PULL_ENABLE"));
				
				/////////////////////VN parameter for rate plan
				this.vnSubEnable=Integer.parseInt(TSSJavaUtil.instance().getAppConfigParam("VN_SUB_ENABLE"));
				this.vnRenEnable=Integer.parseInt(TSSJavaUtil.instance().getAppConfigParam("VN_RENEW_ENABLE"));
				this.vnRecordEnable=Integer.parseInt(TSSJavaUtil.instance().getAppConfigParam("VN_RECORDING_ENABLE"));
				this.vnRetrivEnable=Integer.parseInt(TSSJavaUtil.instance().getAppConfigParam("VN_RETRIEVAL_ENABLE"));
				this.vnGroupEnable=Integer.parseInt(TSSJavaUtil.instance().getAppConfigParam("VN_GROUP_ENABLE"));
				this.vnPullEnable=Integer.parseInt(TSSJavaUtil.instance().getAppConfigParam("VN_PULL_ENABLE"));
				
				mailBoxList=getMailBox();
				operatorList=operatorRange.getGroupDetail(-1);
			
				logger.info(" CHARGING_CODES="+chargingCodeList);
				//logger.info(" SMS_TEMPLATES="+templateSMSList.size());
			}catch (Exception e) {
				logger.error("ERROR in processing chargingCode List!",e);
				return ERROR;
			}
			finally
			{
				rpManager=null;
			}
		}
		return SUCCESS;
	}/// ### END of populateChgCodeAndTemplate () ###//
	
	public CrbtRatePlanBean getCrbtRateplanBean() {
		return crbtRateplanBean;
	}
	public void setCrbtRateplanBean(CrbtRatePlanBean crbtRateplanBean) {
		this.crbtRateplanBean = crbtRateplanBean;
	}
	
	
	
	
	
	//getMailBox type
	
	public ArrayList<MailBox> getMailBox()
	{
		logger.info("Inside getMail BOx");
		int response=-1;
			MailBoxManager mailBoxManager=new MailBoxManager();
			mailBoxList=new ArrayList<MailBox>();
			try{
				response=mailBoxManager.getMailBoxDetail(mailBoxList,-1);
				
				logger.info("mailBox list size is "+mailBoxList.size());
		
			}
			catch (Exception e) {
				logger.error("ERROR in processing chargingCode List!",e);
			}
		return mailBoxList;
	}
	
	
	
	/**
	 * Method is responsible of forming the different String of RatePlan
	 * Features.
	 *  PLAN_INDICATOR, 
	 *  FREE_RBT, 
	 *  FREE_RECORDING,
	 *  FREE_GIFT,
	 *  SUB_FB_CHG_CODE,
	 *  RBT_FB_CHG_CODE,
	 *  GIFT_FB_CHG_CODE,
	 *  REC_FB_CHG_CODE
	 *  SUB_RENEW_FB_CHG_CODE, 
	 *  RBT_RENEW_FB_CHG_CODE,
	 *  REC_RENEW_FB_CHG_CODE
	 * 
	 * after that calling addRatePlan(CrbtRatePlanBean crbtRatePlanBean) method from RatePlanManagerNew class
	 * and insert new Rate Plan to CRBT_RATE_PLAN 
	 * 
	 * Forming of String comprises of following sub operation:-
	 * 1- Access list of all Feature Fall-back Rate-plan
	 * 2- Sort Feature Fall-back rate-plan as per validity days of Charging-Codes
	 * 3- Form the string of Fallback Features
	 * 4- Form the process string of pre-paid and post-paid features.
	 * 5- Populate CrbtRatePlanBean
	 * 6- Call the addRatePlan() method of RatePlanManagerNew
	 * 7- Return final response to presentation layer.  
	 * 
	 * @return String SUCCESS=success, ERROR=error
	 */
	
	
	public String addRatePlan(){
		this.actionName="viewAllRatePlan.action?rateplan.PlanId=-1";
		rpManager=new RatePlanManagerNew();
		int status=-1;
		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		}
			else  if( rateplan!=null && (!rateplan.getMaskName().trim().equalsIgnoreCase("")) ){
				try
				{
				
				logger.info("Inside addratePlan subtype"+subType+" opertaor"+operator+"classtype="+classtype);
				
				JSONObject scopeValue= new JSONObject();				
				scopeValue.put("ST",subType);
				scopeValue.put("OR",operator);
				scopeValue.put("SC",classtype);
				rateplan.setScope(scopeValue.toString());
				logger.info("scope of rate plan is"+rateplan.getScope());
				
				status = rpManager.addRatePlan(rateplan);
				logger.info(" Inside addRatePlan() rate plan bean is"+rateplan);
				HttpServletRequest request = ServletActionContext.getRequest();
				HttpSession session = request.getSession();
				String user = ((SessionHistory) session
						.getAttribute("sessionHistory")).getUser();
				String roleName1 = ((SessionHistory) session
						.getAttribute("sessionHistory")).getRoleName();
				con=TSSJavaUtil.instance().getconnection();
				if(status>0)
				{
					logger.info("rate plan added successfully"); 
					 this.setMessage(getText("webadmin.ratePlan.added"));
					 historyDataBean = new HistoryDataBean();
						historyDataBean.setUser(user);
						historyDataBean.setAction(getText("rateplan"));
						historyDataBean.setEvent("Add");
						historyDataBean.setRole(roleName1);
						historyDataBean.setMsg("Rate Plan ["+rateplan.getMaskName()+"] Add [Success]");
						historyGenerator = new HistoryGenerator();
						historyGenerator.insertHistoryData(historyDataBean, con);
						
					return SUCCESS;
				}
				else
				{
					this.setMessage(getText("webadmin.ratePlan.notadded"));
					historyDataBean = new HistoryDataBean();
					historyDataBean.setUser(user);
					historyDataBean.setAction(getText("rateplan"));
					historyDataBean.setEvent("Add");
					historyDataBean.setRole(roleName1);
					historyDataBean.setMsg("Rate Plan ["+rateplan.getMaskName()+"] Add [Failed]");
					historyGenerator = new HistoryGenerator();
					historyGenerator.insertHistoryData(historyDataBean, con);
					return ERROR;
				}
				
				}
				catch (Exception e) {
				logger.error("Exception inside add rateplan()"+e.getMessage());
				return ERROR;// TODO: handle exception
				}
				finally{
					try{
						if(con!=null)
							TSSJavaUtil.instance().freeConnection(con);
					}catch (Exception e) {
						// TODO: handle exception
					}
				}
			}
				else {
					message="Rate Plan with MASKED-NAME =["+rateplan.getMaskName()+"] is failed to add!";
					logoutMessage="Rate Plan with MASKED-NAME =["+rateplan.getMaskName()+"] is failed to add!";
					return ERROR;
				}
			
		}
	
	public String viewRateplan()
	{
		logger.info("viewRatePLan() started ");
		int response=-1;
		this.linkName="webadmin";
		String scope="";
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
			}
		    else{
				 try{
					 rpManager=new RatePlanManagerNew();
					 crbtRatePlanList = new ArrayList<VCCRatePlanBean>();
					 chargingCodeList=rpManager.getChargingCodeList();
					 mailBoxList=getMailBox();
					 operatorRange=new OperatorRange();
						operatorList=new ArrayList<OperatorRange>();
						operatorList=operatorRange.getGroupDetail(-1);
					 response=rpManager.getCrbtRatePlanByMaskedName(crbtRatePlanList,rateplan.getPlanId());
					 logger.info("Size of list is"+crbtRatePlanList.size());
				      if(response==-1)
				      {
				    	return "failure";   
				      }
				      if(crbtRatePlanList.size()==1)
				      {
				    	  rateplan=crbtRatePlanList.get(0);
				    	scope=crbtRatePlanList.get(0).getScope();
				    	JsonParser parser=new JsonParser();
				    	subType=parser.parse(scope).getAsJsonObject().get("ST").getAsString();
				    	operator=parser.parse(scope).getAsJsonObject().get("OR").getAsString();
				    	classtype=parser.parse(scope).getAsJsonObject().get("SC").getAsString();
				    	logger.info("subType="+subType+" operator="+operator+" classtype is "+classtype);
				    	String operatorVal[]=operator.split(",");
				    	
				    	
				    	for (int i=0;i<operatorVal.length;i++ )
				    	{
				    		
				    		for(int j=0;j<operatorList.size();j++)
					    	{
					    		
				    	if(operatorVal[i].trim().equalsIgnoreCase(""+operatorList.get(j).getGroupId()))
				    	{
				    		operatorList.get(j).setIsSelected("true");
				    		logger.info(" operator value is ="+operatorVal[i]);
				    		logger.info("Group id is="+operatorList.get(j).getGroupId());
				    		
				    		break;
				    	}
				     
				    	}
				    	}
				      }
				      
					  }
				 catch(Exception e)
				  {
					 logger.error("Exception inside view RatePLan(),,,,,",e);
					 return "failure";
				  }
				 finally
				 {
					 rpManager=null;
				 }
                return "success";
			}
	}
	
	public String modifyRatePlan()
	{
		logger.info("modifyRatePlan started "+rateplan.getMaskName());
		
		this.actionName="viewAllRatePlan.action?rateplan.PlanId=-1";
		this.linkName="webadmin";
		int response=-1;
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
			}
		    else{
				 try{
					
					 HttpServletRequest request = ServletActionContext.getRequest();
						HttpSession session = request.getSession();
						String user = ((SessionHistory) session
								.getAttribute("sessionHistory")).getUser();
						String roleName1 = ((SessionHistory) session
								.getAttribute("sessionHistory")).getRoleName();
					  rpManager=new RatePlanManagerNew();
					  con = TSSJavaUtil.instance().getconnection();
					  if(TssStringUtill.ValidateParams(""+rateplan.getSubCode(),""+rateplan.getSubValidity(),""+rateplan.getRenew(),""+rateplan.getRenewValidity(),""+rateplan.getRcrdCode(),""+rateplan.getRetCode(),""+rateplan.getGrpRcrdCode(),""+rateplan.getPullSms()))
					  {						  
						  JSONObject scopeValue= new JSONObject();				
							scopeValue.put("ST",subType);
							scopeValue.put("OR",operator);
							scopeValue.put("SC",classtype);
							rateplan.setScope(scopeValue.toString());
							logger.info("scope of rate plan is"+rateplan.getScope());
							
						  response=rpManager.updateRatePlan(rateplan);
						  if(response>0)
						  {
							  logger.info("updated successfully");
						  this.setMessage(getText("webadmin.ratePlan.modified"));
						  historyDataBean = new HistoryDataBean();
							historyDataBean.setUser(user);
							historyDataBean.setAction(getText("rateplan"));
							historyDataBean.setEvent("Modify");
							historyDataBean.setRole(roleName1);
							historyDataBean.setMsg("Rate Plan ["+rateplan.getMaskName()+"] Modify [Success]");
							historyGenerator = new HistoryGenerator();
							historyGenerator.insertHistoryData(historyDataBean, con);
						  }
						  else{
							  this.setMessage(getText("webadmin.ratePlan.notmodified"));
							  historyDataBean = new HistoryDataBean();
								historyDataBean.setUser(user);
								historyDataBean.setAction(getText("rateplan"));
								historyDataBean.setEvent("Modify");
								historyDataBean.setRole(roleName1);
								historyDataBean.setMsg("Rate Plan ["+rateplan.getMaskName()+"] Modify [Failed]");
								historyGenerator = new HistoryGenerator();
								historyGenerator.insertHistoryData(historyDataBean, con);
						  }
					  }
					  else
					  {
						  this.setMessage(getText("webadmin.ratePlan.notmodified"));
						  historyDataBean = new HistoryDataBean();
							historyDataBean.setUser(user);
							historyDataBean.setAction(getText("rateplan"));
							historyDataBean.setEvent("Modify");
							historyDataBean.setRole(roleName1);
							historyDataBean.setMsg("Rate Plan ["+rateplan.getMaskName()+"] Modify [Failed]");
							historyGenerator = new HistoryGenerator();
							historyGenerator.insertHistoryData(historyDataBean, con);
					  }
					
					  }
				 catch(Exception e)
				  {
					 logger.error("Exception inside modifyratePlan(),,,,,",e);
					 return "failure";
				  } finally
					 {
						 rpManager=null;
						 if(con!=null){
							 TSSJavaUtil.instance().freeConnection(con);
					 }}
                return "success";
			}
	}
	
	

	public String deleteRatePlan()
	{
		logger.info("deleteRatePlan() started  list size "+(rateplan.getDeleteList()).size());
		this.actionName="viewAllRatePlan.action?rateplan.PlanId=-1";
		this.linkName="webadmin";
		int response=-1;
		 this.setMessage(getText("webadmin.mailBox.notdeleted"));
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
			}
		    else{
		    	HttpServletRequest request = ServletActionContext.getRequest();
				HttpSession session = request.getSession();
				String user = ((SessionHistory) session
						.getAttribute("sessionHistory")).getUser();
				String roleName1 = ((SessionHistory) session
						.getAttribute("sessionHistory")).getRoleName();
				 try{
					 rpManager=new RatePlanManagerNew();
					    response=rpManager.deleteRatePlan(rateplan.getDeleteList());
					    con = TSSJavaUtil.instance().getconnection();
						  if(response==0){
						  this.setMessage(getText("webadmin.ratePlan.deleted"));
						  historyDataBean = new HistoryDataBean();
							historyDataBean.setUser(user);
							historyDataBean.setAction(getText("rateplan"));
							historyDataBean.setEvent("delete");
							historyDataBean.setRole(roleName1);
							historyDataBean.setMsg("Rate Plan "+rateplan.getDeleteList()+" Delete [Success]");
							historyGenerator = new HistoryGenerator();
							historyGenerator.insertHistoryData(historyDataBean, con);
						  }
					  }
				 catch(Exception e)
				  {
					 logger.error("Exception inside deleteRatePLan,,,,,",e);
					 return "failure";
				  }
				 finally
				 {
					 rpManager=null;
					 if(con!=null)
						 TSSJavaUtil.instance().freeConnection(con);
				 }
                return "success";
			}
	}
	/*public String addRatePlan(){
		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		} else  if( rateplan!=null && (!rateplan.getMaskedName().trim().equalsIgnoreCase("")) ){
			
			
			
			 String subFbChgCode="";
			 String rbtFbChgCode="";
			 String giftFbChgCode="";
			 String recFbChgCode="";
			 String subRenewFbChgCode="";
			 String rbtRenewFbChgCode="";
			 String recRenewFbChgCode="";
			 String process="";
			 			 
			try{
				
				logger.info(" ###########################################");
				logger.info(" MASKED_NAME ="+rateplan.getMaskedName());
				logger.info(" subPrepaidPromo ="+rateplan.getSubPrepaidPromo());
				logger.info(" subPostpaidPromo ="+rateplan.getSubPostpaidPromo());
				logger.info(" subPrePaidTemplateId ="+rateplan.getSubPrePaidTemplateId());
				logger.info(" subPostPaidTemplateId ="+rateplan.getSubPostPaidTemplateId());
				logger.info(" enableSubAutoRenewPostpaid ="+rateplan.getEnableSubAutoRenewPostpaid());
				logger.info(" enableSubAutoRenewPrepaid ="+rateplan.getEnableSubAutoRenewPrepaid());
				logger.info(" rbtPurchasePrepaidPromo ="+rateplan.getRbtPurchasePrepaidPromo());
				logger.info(" rbtPurchasePostpaidPromo ="+rateplan.getRbtPurchasePostpaidPromo());
				logger.info(" rbtPurchasePrePaidTemplateId ="+rateplan.getRbtPurchasePrePaidTemplateId());
				logger.info(" rbtPurchasePostPaidTemplateId ="+rateplan.getRbtPurchasePostPaidTemplateId());
				logger.info(" enableRbtAutoRenewPostpaid ="+rateplan.getEnableRbtAutoRenewPostpaid());
				logger.info(" enableRbtAutoRenewPrepaid ="+rateplan.getEnableRbtAutoRenewPrepaid());
				logger.info(" EnableRecordAutoRenewPostpaid ="+rateplan.getEnableRecordAutoRenewPostpaid());
				logger.info(" enableRecordAutoRenewPrepaid ="+rateplan.getEnableRecordAutoRenewPrepaid());
				logger.info("===========================================================================");
				logger.info("subscriptionDetails = "+rateplan.getSubscriptionDetails());
				logger.info("subscriptionRenewDetails = "+rateplan.getSubscriptionRenewDetails());
				logger.info("rbtPurchaseDetails = "+rateplan.getRbtPurchaseDetails());
				logger.info("rbtRenewDetails = "+rateplan.getRbtRenewDetails());
				logger.info("rbtRecordingDetails ="+rateplan.getRbtRecordingDetails());
				logger.info("recordingRenewDetails = "+rateplan.getRecordingRenewDetails());
				logger.info("rbtGiftDetails = "+rateplan.getRbtGiftDetails());
				System.out.println("ratePlan Scope "+rateplan.getScope());
				System.out.println("ratePlan Country Code "+rateplan.getCountryCode());
				logger.info("===========================================================================");
				logger.info(" ###########################################");
				
				
				logger.info("##### fromation of subFbChgCode ####");
				
				
				SubscriptionDetail subDetail=null;
				//Removing null Entries
				while(rateplan.getSubscriptionDetails().remove(null));
				//Sorting by validity Days
				Collections.sort(rateplan.getSubscriptionDetails(), new RatePlanValidityComparator());
				
			
				for (int i = 0; i < rateplan.getSubscriptionDetails().size(); i++) {
					
					subDetail = rateplan.getSubscriptionDetails().get(i);
					
					if (subDetail != null && subDetail.getChargingCode() != 0) {

						subFbChgCode += RatePlanTags.CHARGE_CODE_TAG + ":"+ subDetail.getChargingCode() + ","
								+ RatePlanTags.VALIDITY_DAYS_TAG + ":"+ subDetail.getValidity();

//Start of Updated by MoHit for COMMON 4 March 2015
						
						//if (validateList(rateplan.getSubscriptionDetails(),(i+1))) {
							//subFbChgCode += ";";
						//}
					}
					
					if(subDetail.getChargingCode()==0 || subDetail.getChargingCode()!=0)
					{
						if (validateList(rateplan.getSubscriptionDetails(), (i + 1))) 
						{
							if(subDetail.getChargingCode()==0 && i==0)
							{
								subFbChgCode="";
							}
							else
							{	
								if(subDetail.getChargingCode()==0 && i>0)
								{
									if("".equalsIgnoreCase(subFbChgCode) || subFbChgCode==null || subFbChgCode.lastIndexOf(";")==subFbChgCode.length()-1)
									 {
										 //do nothing
									 }
									 else
									 {
										 subFbChgCode += ";";
									 }	 
								}
								else
								{	
									subFbChgCode += ";";
								}
							}//else 
							
						}//if validateList
						
					}//main if
					
//End of Updated by MoHit for COMMON 4 March 2015
				}
				
				
				
				logger.info("subFbChgCode =["+subFbChgCode+"]");
				logger.info("########################################");
				
				logger.info("##### fromation of subRenewFbChgCode ####");
				SubscriptionRenewDetail subRenewDetail=null;
				//Removing null Entries
				while(rateplan.getSubscriptionRenewDetails().remove(null));
				
				//Sorting by validity Days
				Collections.sort(rateplan.getSubscriptionRenewDetails(), new Comparator<SubscriptionRenewDetail>() {
					@Override
					public int compare(SubscriptionRenewDetail o1,
							SubscriptionRenewDetail o2) {
						if (o1== null && o2 == null) return 0;
				         if (o1 == null) return true? 1 : -1;
				         if (o2== null) return true? -1 : 1;
						return (o1.getValidity()>o2.getValidity() ? -1 : (o1.getValidity()==o2.getValidity() ? 0 : 1));
					}
				});
				//###
				for(int i=0;i<rateplan.getSubscriptionRenewDetails().size();i++)
				{
				//###
					
					//###
					subRenewDetail=rateplan.getSubscriptionRenewDetails().get(i);
					//###
					if(subRenewDetail!=null && subRenewDetail.getChargingCode()!=0)
					{	
					    subRenewFbChgCode+=RatePlanTags.CHARGE_CODE_TAG+":"+subRenewDetail.getChargingCode()+","
											+RatePlanTags.VALIDITY_DAYS_TAG+":"+subRenewDetail.getValidity()+","
											+RatePlanTags.SUCCESS_TEMPLATE_TAG+":"+subRenewDetail.getRenewSuccessTemplateID()+","
											+RatePlanTags.FAILURE_TEMPLATE_TAG+":"+subRenewDetail.getRenewFailedTemplateID();
					    //#####

//Start of Updated by MoHit for COMMON 4 March 2015
					    if(validateList(rateplan.getSubscriptionRenewDetails(), (i+1))){
					    	subRenewFbChgCode+=";";	
					    }
					    //#####
					}
					
					if(subRenewDetail.getChargingCode()==0 || subRenewDetail.getChargingCode()!=0)
					{
						if (validateList(rateplan.getSubscriptionRenewDetails(), (i + 1))) 
						{
							if(subRenewDetail.getChargingCode()==0 && i==0)
							{
								subRenewFbChgCode="";
							}
							else
							{	
								if(subRenewDetail.getChargingCode()==0 && i>0)
								{
									if("".equalsIgnoreCase(subRenewFbChgCode) || subRenewFbChgCode==null || subRenewFbChgCode.lastIndexOf(";")==subRenewFbChgCode.length()-1)
									 {
										 //donothing
									 }
									 else
									 {
										 subRenewFbChgCode += ";";
									 }	 
								}
								else
								{	
									subRenewFbChgCode += ";";
								}
							}//else
						}//if validateList
					
					}//main if

//End of Updated by MoHit for COMMON 4 March 2015
				}
				
				logger.info("subRenewFbChgCode =["+subRenewFbChgCode+"]");
				logger.info("########################################");
				
				logger.info("##### fromation of rbtPurchase ####");
				RbtPurchaseDetail rbtpDetail=null;
				
				//Removing null Entries
				while(rateplan.getRbtPurchaseDetails().remove(null));
				
				//Sorting by validity Days
				Collections.sort(rateplan.getRbtPurchaseDetails(), new Comparator<RbtPurchaseDetail>() {
					@Override
					public int compare(RbtPurchaseDetail o1,
							RbtPurchaseDetail o2) {
						if (o1== null && o2 == null) return 0;
				         if (o1 == null) return true? 1 : -1;
				         if (o2== null) return true? -1 : 1;
						return (o1.getValidity()>o2.getValidity() ? -1 : (o1.getValidity()==o2.getValidity() ? 0 : 1));
					}
				});
							
				
					for(int i=0;i<rateplan.getRbtPurchaseDetails().size();i++){
						
						rbtpDetail=rateplan.getRbtPurchaseDetails().get(i);
						if(rbtpDetail!=null&&rbtpDetail.getChargingCode()!=0){
							
							rbtFbChgCode+=RatePlanTags.CHARGE_CODE_TAG+":"+rbtpDetail.getChargingCode()+","
											+RatePlanTags.VALIDITY_DAYS_TAG+":"+rbtpDetail.getValidity();
	
//Start of Updated by MoHit for COMMON 4 March 2015
								if(validateList(rateplan.getRbtPurchaseDetails(), (i+1))){
									rbtFbChgCode+=";";	
							    }
							}
						
						if(rbtpDetail.getChargingCode()==0 || rbtpDetail.getChargingCode()!=0)
						{
							if (validateList(rateplan.getRbtPurchaseDetails(), (i + 1))) 
							{
								if(rbtpDetail.getChargingCode()==0 && i==0)
								{
									rbtFbChgCode="";
								}
								else
								{	
									if(rbtpDetail.getChargingCode()==0 && i>0)
									{
										if("".equalsIgnoreCase(rbtFbChgCode) || rbtFbChgCode==null || rbtFbChgCode.lastIndexOf(";")==rbtFbChgCode.length()-1)
										 {
											 //do nothing
										 }
										 else
										 {
											 rbtFbChgCode += ";";
										 }	 
									}
									else
									{	
										rbtFbChgCode += ";";
									}
								}//else 
								
							}//if validateList
							
						}//main if
//End of Updated by MoHit for COMMON 4 March 2015						
					}
				
				logger.info("rbtFbChgCode =["+rbtFbChgCode+"]");
				logger.info("########################################");
				 				
				logger.info("##### fromation of rbtRenewFbChgCode ####");
				RbtRenewDetail rbtrDetail=null;
				//Removing null Entries
				while(rateplan.getRbtRenewDetails().remove(null));
				
				//Sorting by validity Days
				Collections.sort(rateplan.getRbtRenewDetails(), new Comparator<RbtRenewDetail>() {
					@Override
					public int compare(RbtRenewDetail o1,
							RbtRenewDetail o2) {
						if (o1== null && o2 == null) return 0;
				         if (o1 == null) return true? 1 : -1;
				         if (o2== null) return true? -1 : 1;
						return (o1.getValidity()>o2.getValidity() ? -1 : (o1.getValidity()==o2.getValidity() ? 0 : 1));
					}
				});
				
				for (int i = 0; i < rateplan.getRbtRenewDetails().size(); i++) {
					
					rbtrDetail = rateplan.getRbtRenewDetails().get(i);
					
					if(rbtrDetail!=null && rbtrDetail.getChargingCode()!=0){
						
						rbtRenewFbChgCode+=RatePlanTags.CHARGE_CODE_TAG+":"+rbtrDetail.getChargingCode()+","
											+RatePlanTags.VALIDITY_DAYS_TAG+":"+rbtrDetail.getValidity()+","
											+RatePlanTags.SUCCESS_TEMPLATE_TAG+":"+rbtrDetail.getRenewSuccessTemplateID()+","
											+RatePlanTags.FAILURE_TEMPLATE_TAG+":"+rbtrDetail.getRenewFailedTemplateID();
						
//Start of Updated by MoHit for COMMON 4 March 2015
						 if(validateList(rateplan.getRbtRenewDetails(), (i+1))){
							 rbtRenewFbChgCode+=";";	
						    }
					}
					
					if(rbtrDetail.getChargingCode()==0 || rbtrDetail.getChargingCode()!=0)
					{
						if (validateList(rateplan.getRbtRenewDetails(), (i + 1))) 
						{
							if(rbtrDetail.getChargingCode()==0 && i==0)
							{
								rbtRenewFbChgCode="";
							}
							else
							{	
								if(rbtrDetail.getChargingCode()==0 && i>0)
								{
									if("".equalsIgnoreCase(rbtRenewFbChgCode) || rbtRenewFbChgCode==null || rbtRenewFbChgCode.lastIndexOf(";")==rbtRenewFbChgCode.length()-1)
									 {
										 //do nothing
									 }
									 else
									 {
										 rbtRenewFbChgCode += ";";
									 }	 
								}
								else
								{	
									rbtRenewFbChgCode += ";";
								}
							}//else 
							
						}//if validateList
						
					}//main if

//End of Updated by MoHit for COMMON 4 March 2015
				}
				logger.info("rbtRenewFbChgCode =["+rbtRenewFbChgCode+"]");
				logger.info("########################################");
				
				
				
				logger.info("##### fromation of recFbChgCode ####");
				RbtRecordingDetail recordingDetail=null;
				
				//Removing null Entries
				while(rateplan.getRbtRecordingDetails().remove(null));
				
				//Sorting by validity Days
				Collections.sort(rateplan.getRbtRecordingDetails(), new Comparator<RbtRecordingDetail>() {
					@Override
					public int compare(RbtRecordingDetail o1,
							RbtRecordingDetail o2) {
						if (o1== null && o2 == null) return 0;
				         if (o1 == null) return true? 1 : -1;
				         if (o2== null) return true? -1 : 1;
						return (o1.getValidity()>o2.getValidity() ? -1 : (o1.getValidity()==o2.getValidity() ? 0 : 1));
					}
				});
							
				
				for (int i = 0; i < rateplan.getRbtRecordingDetails().size(); i++) {
					
					recordingDetail = rateplan.getRbtRecordingDetails().get(i);
						logger.info(" REC_DETAIL: ="+recordingDetail);
						logger.info(" REC_DETAIL: ="+recordingDetail.getChargingCode());
						if(recordingDetail!=null && recordingDetail.getChargingCode()!=null && recordingDetail.getChargingCode()!=0){
							
							recFbChgCode+=RatePlanTags.CHARGE_CODE_TAG+":"+recordingDetail.getChargingCode()+","
										  +RatePlanTags.VALIDITY_DAYS_TAG+":"+recordingDetail.getValidity();

//Start of Updated by MoHit for COMMON 4 March 2015
							if(validateList(rateplan.getRbtRecordingDetails(), (i+1))){
								recFbChgCode+=";";	
						    }
							
						}
						
						if(recordingDetail.getChargingCode()==0 || recordingDetail.getChargingCode()!=0)
						{
							if (validateList(rateplan.getRbtRecordingDetails(), (i + 1))) 
							{
								if(recordingDetail.getChargingCode()==0 && i==0)
								{
									recFbChgCode="";
								}
								else
								{	
									if(recordingDetail.getChargingCode()==0 && i>0)
									{
										if("".equalsIgnoreCase(recFbChgCode) || recFbChgCode==null || recFbChgCode.lastIndexOf(";")==recFbChgCode.length()-1)
										 {
											 //do nothing
										 }
										 else
										 {
											 recFbChgCode += ";";
										 }	 
									}
									else
									{	
										recFbChgCode += ";";
									}
								}//else 
								
							}//if validateList
							
						}//main if

//End of Updated by MoHit for COMMON 4 March 2015
				}
				logger.info("recFbChgCode =["+recFbChgCode+"]");
				logger.info("########################################");
				
				logger.info("##### fromation of recRenewFbChgCode ####");
				RecordingRenewDetail recRenewDetail=null;
				//Removing null Entries
				while(rateplan.getRecordingRenewDetails().remove(null));
				
				//Sorting by validity Days
				Collections.sort(rateplan.getRecordingRenewDetails(), new Comparator<RecordingRenewDetail>() {
					@Override
					public int compare(RecordingRenewDetail o1,
							RecordingRenewDetail o2) {
						if (o1== null && o2 == null) return 0;
				         if (o1 == null) return true? 1 : -1;
				         if (o2== null) return true? -1 : 1;
						return (o1.getValidity()>o2.getValidity() ? -1 : (o1.getValidity()==o2.getValidity() ? 0 : 1));
					}
				});
				
				for (int i = 0; i < rateplan.getRecordingRenewDetails().size(); i++) {
					
					recRenewDetail = rateplan.getRecordingRenewDetails().get(i);
					
					if(recRenewDetail!=null&&recRenewDetail.getChargingCode()!=0){
						
					    recRenewFbChgCode+=RatePlanTags.CHARGE_CODE_TAG+":"+recRenewDetail.getChargingCode()+","
											+RatePlanTags.VALIDITY_DAYS_TAG+":"+recRenewDetail.getValidity()+","
											+RatePlanTags.SUCCESS_TEMPLATE_TAG+":"+recRenewDetail.getRenewSuccessTemplateID()+","
											+RatePlanTags.FAILURE_TEMPLATE_TAG+":"+recRenewDetail.getRenewFailedTemplateID();

//Start of Updated by MoHit for COMMON 4 March 2015
						if(validateList(rateplan.getRecordingRenewDetails(), (i+1))){
							recRenewFbChgCode+=";";	
							
					    }
					}
					
					if(recRenewDetail.getChargingCode()==0 || recRenewDetail.getChargingCode()!=0)
					{
						if (validateList(rateplan.getRecordingRenewDetails(), (i + 1))) 
						{
							if(recRenewDetail.getChargingCode()==0 && i==0)
							{
								recRenewFbChgCode="";
							}
							else
							{	
								if(recRenewDetail.getChargingCode()==0 && i>0)
								{
									if("".equalsIgnoreCase(recRenewFbChgCode) || recRenewFbChgCode==null || recRenewFbChgCode.lastIndexOf(";")==recRenewFbChgCode.length()-1)
									 {
										 //do nothing
									 }
									 else
									 {
										 recRenewFbChgCode += ";";
									 }	 
								}
								else
								{	
									recRenewFbChgCode += ";";
								}
							}//else 
							
						}//if validateList
						
					}//main if

//End of Updated by MoHit for COMMON 4 March 2015					
				}
				logger.info("recRenewFbChgCode =["+recRenewFbChgCode+"]");
				logger.info("########################################");
				
				
				logger.info("##### fromation of giftFbChgCode ####");
				RbtGiftDetail rbtGiftDetail=null;
				
				//Removing null Entries
				while(rateplan.getRbtGiftDetails().remove(null));
				
				//Sorting by validity Days
				Collections.sort(rateplan.getRbtGiftDetails(), new Comparator<RbtGiftDetail>() {
					@Override
					public int compare(RbtGiftDetail o1,
							RbtGiftDetail o2) {
						if (o1== null && o2 == null) return 0;
				         if (o1 == null) return true? 1 : -1;
				         if (o2== null) return true? -1 : 1;
						return (o1.getValidity()>o2.getValidity() ? -1 : (o1.getValidity()==o2.getValidity() ? 0 : 1));
					}
				});
							
				for (int i = 0; i < rateplan.getRbtGiftDetails().size(); i++) {

					rbtGiftDetail = rateplan.getRbtGiftDetails().get(i);
					
					if (rbtGiftDetail != null && rbtGiftDetail.getChargingCode() != 0) {

						giftFbChgCode += RatePlanTags.CHARGE_CODE_TAG + ":"+ rbtGiftDetail.getChargingCode() + ","
										 +RatePlanTags.VALIDITY_DAYS_TAG+":"+rbtGiftDetail.getValidity();

//Start of Updated by MoHit for COMMON 4 March 2015
						if (validateList(rateplan.getRbtGiftDetails(), (i + 1))) {
							giftFbChgCode += ";";
						}
					}
					
					if(rbtGiftDetail.getChargingCode()==0 || rbtGiftDetail.getChargingCode()!=0)
					{
						if (validateList(rateplan.getRbtGiftDetails(), (i + 1))) 
						{
							if(rbtGiftDetail.getChargingCode()==0 && i==0)
							{
								giftFbChgCode="";
							}
							else
							{	
								if(rbtGiftDetail.getChargingCode()==0 && i>0)
								{
									if("".equalsIgnoreCase(giftFbChgCode) || giftFbChgCode==null || giftFbChgCode.lastIndexOf(";")==giftFbChgCode.length()-1)
									 {
										 //do nothing
									 }
									 else
									 {
										 giftFbChgCode += ";";
									 }	 
								}
								else
								{	
									giftFbChgCode += ";";
								}
							}//else 
							
						}//if validateList
						
					}//main if

//End of Updated by MoHit for COMMON 4 March 2015
				}
				logger.info("giftFbChgCode =["+giftFbChgCode+"]");
				logger.info("########################################");
				
				//########## Formation of [process] ######
				process=formProcessString();
				logger.info(" process= ["+process+"]");
				
				//Added by MoHit for COMMON on 3 March 15
				logger.info("Checking no charging fallback code to be empty");
				
				if(subFbChgCode==null || "".equalsIgnoreCase(subFbChgCode))
					subFbChgCode="NA";
				if(rbtFbChgCode==null || "".equalsIgnoreCase(rbtFbChgCode))
					rbtFbChgCode="NA";
				if(giftFbChgCode==null || "".equalsIgnoreCase(giftFbChgCode))
					giftFbChgCode="NA";
				if(recFbChgCode==null || "".equalsIgnoreCase(recFbChgCode))
					recFbChgCode="NA";
				if(subRenewFbChgCode==null || "".equalsIgnoreCase(subRenewFbChgCode))
					subRenewFbChgCode="NA";
				if(rbtRenewFbChgCode==null || "".equalsIgnoreCase(rbtRenewFbChgCode))
					rbtRenewFbChgCode="NA";
				if(recRenewFbChgCode==null || "".equalsIgnoreCase(recRenewFbChgCode))
					recRenewFbChgCode="NA";
				
				logger.info("################## Formation of CrbtRatePlanBean ######################");
				 
				 CrbtRatePlanBean crbtRatePlanBeanNew=new CrbtRatePlanBean(subFbChgCode, rbtFbChgCode, giftFbChgCode, recFbChgCode, subRenewFbChgCode, rbtRenewFbChgCode, recRenewFbChgCode, "A",rateplan.getMaskedName(), process);
				 crbtRatePlanBeanNew.setScope(rateplan.getScope());
				 crbtRatePlanBeanNew.setCountryCode(rateplan.getCountryCode());
				
				 RatePlanManagerNew rpManager=new RatePlanManagerNew();
                  logger.info("Testing Scope "+crbtRatePlanBeanNew.getScope());
				  logger.info("Country Code "+crbtRatePlanBeanNew.getCountryCode());
				if(getActionType().equalsIgnoreCase(RatePlanTags.UPDATE_ACTION_TAG)){
						status=rpManager.updateRatePlan(crbtRatePlanBeanNew);
						if (status >= 1) {
							
							message = "Rate Plan with MASKED-NAME =["+ rateplan.getMaskedName()+ "] is [UPDATED] successfully!";
							return SUCCESS;
						} else {
							message = "Rate Plan with MASKED-NAME =["+ rateplan.getMaskedName() + "] is failed to [UPDATE]!";
							logoutMessage= "Rate Plan with MASKED-NAME =["+ rateplan.getMaskedName() + "] is failed to [UPDATE]!";
							return ERROR;
						}
					
				}else{
					status = rpManager.addRatePlan(crbtRatePlanBeanNew);
					if (status >= 1) {
					
						message = "Rate Plan with MASKED-NAME =["+ rateplan.getMaskedName()+ "] is [ADDED] successfully!";
						return SUCCESS;
					} else {
						message = "Rate Plan with MASKED-NAME =["+ rateplan.getMaskedName() + "] is failed to [ADD]!";
						logoutMessage= "Rate Plan with MASKED-NAME =["+ rateplan.getMaskedName() + "] is failed to [ADD]!";
						return ERROR;
					}
				}
				
			}catch (Exception e) {
				e.printStackTrace();
				logger.error("ERROR in processing addRatePlan!",e);
				message="Rate Plan with MASKED-NAME =["+rateplan.getMaskedName()+"] is failed to add!";
				logoutMessage="Rate Plan with MASKED-NAME =["+rateplan.getMaskedName()+"] is failed to add!";
				return ERROR;
			}
			
		}else {
			message="Rate Plan with MASKED-NAME =["+rateplan.getMaskedName()+"] is failed to add!";
			logoutMessage="Rate Plan with MASKED-NAME =["+rateplan.getMaskedName()+"] is failed to add!";
			return ERROR;
		}
	}//### end of method  addRatePlan
	
	
	
	
	
	
	*//**
	 * It update Rate-plan values and save it to database
	 * @return String 
	 * 		error = in case of error in request processing
	 * 		success = If operation is successful
	 * 
	 *//*
	public String updateRatePlan(){
		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		} else  if( rateplan!=null && (!rateplan.getMaskName().trim().equalsIgnoreCase("")) ){
			setActionType(RatePlanTags.UPDATE_ACTION_TAG);
			return addRatePlan();
		}else {
			message="Rate Plan with MASKED-NAME =["+rateplan.getMaskName()+"] is failed to UPDATE!";
			logoutMessage="Rate Plan with MASKED-NAME =["+rateplan.getMaskName()+"] is failed to UPDATE!";
			return ERROR;
		}
	}//##### END OF method updateRatePlan()
	
	*//**
	 * This method list all Rateplan available in CRBT_RATE_PLAN
	 * This method propagate presentation layer a java.util.List<CrbtRatePlanBean> object.
	 * @return String
	 * 		success -- If all Rateplan list is accessed successfully
	 * 		error	-- If any error is detected
	 *//*
	public String showAllRatePlan(){
		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		} else {
			RatePlanManagerNew rpManager=new RatePlanManagerNew();
			try{
				
				crbtRatePlanList=rpManager.getCrbtRatePlanList();
			}catch (Exception e) {
				logger.error("ERROR in processing chargingCode List!",e);
				return ERROR;
			}
		}
		return SUCCESS;
	}//### END of method showAllRatePlan() 
	
	
	
		
		
		
		
	
                   
                   
			
	

	

	
	
	*//**
	 * @author pankajmishra 
	 * 
	 * 		   This is method is very crucial in selecting specific
	 *         rate-plan. Parsing rate-plan string of every feature like
	 *         subscription, RBT-Purchase, RBT-recording, RBT-Gift. Parse
	 *         process string of controlling Postpaid and Prepaid string. Then
	 *         assign to value to CrbtRatePlanBean 's Different
	 *         fallback-java.util.List<> like-List<SubscriptionDetail>
	 *         List<RbtRenewDetail> List<SubscriptionRenewDetail>
	 *         List<RbtPurchaseDetail> List<RbtRecordingDetail>
	 *         List<RbtGiftDetail> Pre-paid & Post-Paid PROCESS String private
	 *         String enableRbtAutoRenewPrepaid;//true or false private String
	 *         enableRbtAutoRenewPostpaid;//true or false
	 * 
	 *         private String enableRecordAutoRenewPostpaid;//true or false
	 *         private String enableRecordAutoRenewPrepaid;//true or false
	 * 
	 * @return String
	 * 		success = For successful select and parsing operation
	 * 		error 	= In case of any error encountered
	 *//*
	
	
	public String viewRatePlan()
	{
		logger.info("view rateplan() started maskes name is"+rateplan.getMaskName());
		int response=-1;
		this.linkName="webadmin";
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
			}
		    else{
				 try{
					 rpManager=new RatePlanManagerNew();
					  crbtRatePlanList= new ArrayList();
					 response=rpManager.getCrbtRatePlanByMaskedName(crbtRatePlanList,rateplan.getMaskName());
					 
				      if(response==-1)
				      {
				    	return "failure";   
				      }
				      if(crbtRatePlanList.size()==1)
				      {
				    	  rateplan=crbtRatePlanList.get(0);
			
				      }
				      
					  }
				 catch(Exception e)
				  {
					 logger.error("Exception inside viewMailBoxConfig(),,,,,",e);
					 return "failure";
				  }
				 finally
				 {
					 rpManager=null;
				 }
                return "success";
			}
	}
	 public String viewRatePlan(){
		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		} else {
			rateplan=null;
			rpManager=new RatePlanManagerNew();
			try
			{
				List <ChargingCodeDetail> chgList=rpManager.getChargingCodeList();
				chgCodeMap=new HashMap<Integer, String>();
				for(Iterator<ChargingCodeDetail> it=chgList.iterator();it.hasNext();){
						ChargingCodeDetail bean=it.next();
						chgCodeMap.put(bean.getChargingCode(), bean.getChargingCodeName());
				}
				crbtRatePlanList=rpManager.getCrbtRatePlanByMaskedName(maskedName);
			}
			catch (Exception e) {
			logger.error("Exception inside view Rateplan()");	// TODO: handle exception
			return ERROR;
			}
			return SUCCESS;
		}
	}
	
	
	public String viewRatePlan(){
		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		} else {
			rateplan=null;
			rateplan=new RatePlanBeanNew();
			RatePlanManagerNew rpManager=new RatePlanManagerNew();
			
			try{
				List <ChargingCodeDetail> chgList=rpManager.getChargingCodeList();
				chgCodeMap=new HashMap<Integer, String>();
				for(Iterator<ChargingCodeDetail> it=chgList.iterator();it.hasNext();){
						ChargingCodeDetail bean=it.next();
						chgCodeMap.put(bean.getChargingCode(), bean.getChargingCodeName());
				}
				//Map of chargingCode and description
				
				crbtRateplanBean=rpManager.getCrbtRatePlanByMaskedName(maskedName);
				
				if(crbtRateplanBean!=null){
					
					logger.info(" sub_fb_charge_code = "+crbtRateplanBean.getSubFbChgCode());
					if(crbtRateplanBean.getSubFbChgCode()!=null){
						 formSubAndPurchaseDetail(crbtRateplanBean.getSubFbChgCode(),RatePlanTags.SUBSCRIPTION_TAG); 
					}
					
					logger.info(" SUB_RENEW_FB_CHG_CODE = "+crbtRateplanBean.getSubRenewFbChgCode());
					if(crbtRateplanBean.getSubRenewFbChgCode()!=null){
						formSubAndPurchaseRenewalDetail(crbtRateplanBean.getSubRenewFbChgCode(), RatePlanTags.SUBSCRIPTION_TAG);
					}
					
					logger.info("RBT_FB_CHG_CODE = "+crbtRateplanBean.getRbtFbChgCode());
					if(crbtRateplanBean.getRbtFbChgCode()!=null){
						formSubAndPurchaseDetail(crbtRateplanBean.getRbtFbChgCode(), RatePlanTags.RBT_PURCHASE_TAG);
					}
					
					logger.info("CRBT_RENEW_FB_CHG_CODE = "+crbtRateplanBean.getRbtRenewFbChgCode());
					if(crbtRateplanBean.getRbtRenewFbChgCode()!=null){
						formSubAndPurchaseRenewalDetail(crbtRateplanBean.getRbtRenewFbChgCode(), RatePlanTags.RBT_PURCHASE_TAG);
					}
					
					logger.info("CEC_FB_CHG_CODE = "+crbtRateplanBean.getRecFbChgCode());
					if(crbtRateplanBean.getRecFbChgCode()!=null){
						formSubAndPurchaseDetail(crbtRateplanBean.getRecFbChgCode(),RatePlanTags.RECORDING_TAG);
					}
					
					logger.info("REC_RENEW_FB_CHG_CODE = "+crbtRateplanBean.getRecRenewFbChgCode());
					if(crbtRateplanBean.getRecRenewFbChgCode()!=null){
						formSubAndPurchaseRenewalDetail(crbtRateplanBean.getRecRenewFbChgCode(), RatePlanTags.RECORDING_TAG);
					}
					
					logger.info("GIFT_FB_CHG_CODE = "+crbtRateplanBean.getGiftFbChgCode());
					if(crbtRateplanBean.getGiftFbChgCode()!=null){
						formSubAndPurchaseDetail(crbtRateplanBean.getGiftFbChgCode(), RatePlanTags.RBT_GIFT_TAG);
					}
					
					logger.info(" MASKED_NAME = ["+ crbtRateplanBean.getMaskedName()+"]");
					this.rateplan.setMaskedName(crbtRateplanBean.getMaskedName());
					
					
					
					 * Added By Rinku For Scope and Country Code
					 
				    scopeList=new ArrayList<ScopeBean>();
					
					ScopeBean scopeBean=new ScopeBean("P","Prepaid");
					ScopeBean scopeBean1=new ScopeBean("O","Postpaid");
					ScopeBean scopeBean2=new ScopeBean("B","Both");
					 scopeList.add(scopeBean);
					 scopeList.add(scopeBean1);
					 scopeList.add(scopeBean2);
					if("SUBTYPE:P".equalsIgnoreCase(crbtRateplanBean.getScope()))
					{			     
					  this.rateplan.setScope("P");
					}
					else if("SUBTYPE:O".equalsIgnoreCase(crbtRateplanBean.getScope()))
					{
						
						
						this.rateplan.setScope("O");
					}
					else if("SUBTYPE:B".equalsIgnoreCase(crbtRateplanBean.getScope()))
					{
								
						this.rateplan.setScope("B");
					}	
					else
					{
						
						this.rateplan.setScope("NA");
					}	
					
					this.rateplan.setCountryCode(crbtRateplanBean.getCountryCode());
					
					
					message="Rate plan detail for MASKED NAME : ["+maskedName+"]";
					
					*//**
					 * ############## Formation of [process] filed
					 *//*
					logger.info("**************** PROCESS= ["+crbtRateplanBean.getProcess()+"]");
					if(crbtRateplanBean.getProcess()!=null && !(crbtRateplanBean.getProcess().trim()=="")){
							populatePrepaidPostpaidProcess(crbtRateplanBean.getProcess());
					}
							//this.rateplan.setSubPrepaidPromo("true");
							//this.rateplan.setSubPrePaidTemplateId(20);
					//############ end of Formation of [process] filed 
					status=1;
					return SUCCESS;
				}else{
					message=" Failed to retrive rate plan detail for MASKED NAME : ["+maskedName+"]";
					logoutMessage=" Failed to retrive rate plan detail for MASKED NAME : ["+maskedName+"]";;
					status=0;
					return ERROR;
				}
			}catch (Exception e) {
				logger.error("ERROR in processing chargingCode List!",e);
				message=" Failed to retrive rate plan detail for MASKED NAME : ["+maskedName+"]";
				logoutMessage=" Failed to retrive rate plan detail for MASKED NAME : ["+maskedName+"]";;
				return ERROR;
			}
	  }
	}//### NED of METHOD viewRatePlan()
	*//**
	 *@author pankajmishra
	 *
	 * This method responsible to view all details of Rate-plan with CODE and SMS Template-ID.
	 *   
	 * @return String
	 * 		success = For successful select and parsing operation
	 * 		error 	= In case of any error encountered
	 *//*
	public String updateViewRatePlan(){
		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		} else {
			setActionType(RatePlanTags.UPDATE_ACTION_TAG);//#### NOT IN USE will be used in future!!
			String status_1=populateChgCodeAndTemplate();
			String status_2=viewRatePlan();
			
			if(status_1.equalsIgnoreCase(SUCCESS) && status_2.equalsIgnoreCase(SUCCESS)){
				return SUCCESS;
			}else{
				return ERROR;
			}
		}
	}//### updateViewRatePlan
	
	*//**
	 * @author Manoj Panda
	 *
	 * It delete the Rate-plan of given Masked-Name from CRBT_RATE_PLAN_TABLE
	 * 
	 * @return String success = For successful select and parsing operation
	 *         error = In case of any error encountered
	 * 
	 *//*
	public String handleDeleteRatePlan()
	{
		logger.info("Inside function handleDeleteRatePlan().....");
		
		if(!checkSession().equalsIgnoreCase("success"))
		{
			return "error";
		 }
		else
		 {
			RatePlanManagerNew rpManager=new RatePlanManagerNew();
			try{
			 status=rpManager.deleteCrbtRatePlan(maskedName);
				if(status == 1){
					message="Rate plan detail for MASKED NAME  is deleted: ["+maskedName+"]";
					linkName="webadmin";
					return SUCCESS;
				}else{
					status=-1;
					message=" Failed to delete rate plan detail for MASKED NAME : ["+maskedName+"]";
					logoutMessage=" Failed to delete rate plan detail for MASKED NAME : ["+maskedName+"]";
					linkName="webadmin";
					return ERROR;
				}
			}catch (Exception e) {
				logger.error("ERROR in processing chargingCode List!",e);
				message=" Failed to delete rate plan detail for MASKED NAME : ["+maskedName+"]";
				logoutMessage=" Failed to delete rate plan detail for MASKED NAME : ["+maskedName+"]";
				return ERROR;
			}
	  }
	}

	
	 
	*//**
	 * @author pankajmishra
	 * 
	 *	Method form the string of process field of CRBT_RATE_PLAN table to control.
	 *	Auto-renewal of Subscription, Gift or recorded RBT and Promotional template ID in this regard.
	 *	The process string describe Post-paid and Prepaid plan explicitly by SUB:P and SUB:0
	 * 
	 * @return java.lang.String
	 * 		return proper process string like
	 * 		"SUB:P,ARSUB:1,ARRBT:0,ARREC:1,SPSMSTID:1,RPSMSTID:1;SUB:O,ARSUB:1,ARRBT:0,ARREC:1,RPSMSTID:6"
	 * 	    else blank string. 
	 * 			 
	 *//*
		
	public String formProcessString(){
		String process="";
		String prepaidStr="";
		String postpaidStr="";
		
		logger.info("============================== Formation of Process===================================");
		
		//######### process formation of post paid string
		if(Boolean.parseBoolean(rateplan.getSubPrepaidPromo()) ||
				Boolean.parseBoolean(rateplan.getEnableSubAutoRenewPrepaid())||
				Boolean.parseBoolean(rateplan.getRbtPurchasePrepaidPromo()) ||
				Boolean.parseBoolean(rateplan.getEnableRbtAutoRenewPrepaid())||
				Boolean.parseBoolean(rateplan.getEnableRecordAutoRenewPrepaid()) ){
			
			prepaidStr=RatePlanTags.SUBSCRIPTION_TAG+":"+RatePlanTags.PRE_PAID_TAG;
			
			if(Boolean.parseBoolean(rateplan.getEnableSubAutoRenewPrepaid()) ){
				prepaidStr+=","+RatePlanTags.AUTO_RENEW_SUBSCRIPTION_TAG+":"+RatePlanTags.ENABLE_TAG;
			}else{
				prepaidStr+=","+RatePlanTags.AUTO_RENEW_SUBSCRIPTION_TAG+":"+RatePlanTags.DISABLE_TAG;
			}
			
			if(Boolean.parseBoolean(rateplan.getEnableRbtAutoRenewPrepaid()) ){
				prepaidStr+=","+RatePlanTags.AUTO_RENEW_RBT_TAG+":"+RatePlanTags.ENABLE_TAG;
			}else{
				prepaidStr+=","+RatePlanTags.AUTO_RENEW_RBT_TAG+":"+RatePlanTags.DISABLE_TAG;
			}
			
			if(Boolean.parseBoolean(rateplan.getEnableRecordAutoRenewPrepaid())){
				prepaidStr+=","+RatePlanTags.AUTO_RENEW_RECORDING_TAG+":"+RatePlanTags.ENABLE_TAG;
			}else{
				prepaidStr+=","+RatePlanTags.AUTO_RENEW_RECORDING_TAG+":"+RatePlanTags.DISABLE_TAG;
			}
			
			if(Boolean.parseBoolean(rateplan.getSubPrepaidPromo())){
				prepaidStr+=","+RatePlanTags.SUB_PROMO_SMS_TEMPLATE_TAG+":"+rateplan.getSubPrePaidTemplateId();
			}
			
			if(  Boolean.parseBoolean(rateplan.getRbtPurchasePrepaidPromo())  ){
				prepaidStr+=","+RatePlanTags.RBT_PROMO_SMS_TEMPLATE_TAG+":"+rateplan.getRbtPurchasePrePaidTemplateId();
			}
		}
		//######### process formation of post paid string
		if(Boolean.parseBoolean(rateplan.getSubPostpaidPromo()) ||
				Boolean.parseBoolean(rateplan.getEnableSubAutoRenewPostpaid())||
				Boolean.parseBoolean(rateplan.getRbtPurchasePostpaidPromo()) ||
				Boolean.parseBoolean(rateplan.getEnableRbtAutoRenewPostpaid())||
				Boolean.parseBoolean(rateplan.getEnableRecordAutoRenewPostpaid()) ){
			
			postpaidStr=RatePlanTags.SUBSCRIPTION_TAG+":"+RatePlanTags.POST_PAID_TAG;
			
			if(Boolean.parseBoolean(rateplan.getEnableSubAutoRenewPostpaid()) ){
				postpaidStr+=","+RatePlanTags.AUTO_RENEW_SUBSCRIPTION_TAG+":"+RatePlanTags.ENABLE_TAG;
			}else{
				postpaidStr+=","+RatePlanTags.AUTO_RENEW_SUBSCRIPTION_TAG+":"+RatePlanTags.DISABLE_TAG;
			}
			
			if(Boolean.parseBoolean(rateplan.getEnableRbtAutoRenewPostpaid()) ){
				postpaidStr+=","+RatePlanTags.AUTO_RENEW_RBT_TAG+":"+RatePlanTags.ENABLE_TAG;
			}else{
				postpaidStr+=","+RatePlanTags.AUTO_RENEW_RBT_TAG+":"+RatePlanTags.DISABLE_TAG;
			}
			
			if(Boolean.parseBoolean(rateplan.getEnableRecordAutoRenewPostpaid())){
				postpaidStr+=","+RatePlanTags.AUTO_RENEW_RECORDING_TAG+":"+RatePlanTags.ENABLE_TAG;
			}else{
				postpaidStr+=","+RatePlanTags.AUTO_RENEW_RECORDING_TAG+":"+RatePlanTags.DISABLE_TAG;
			}
			
			if(Boolean.parseBoolean(rateplan.getSubPostpaidPromo())){
				postpaidStr+=","+RatePlanTags.SUB_PROMO_SMS_TEMPLATE_TAG+":"+rateplan.getSubPostPaidTemplateId();
			}
			
			if(  Boolean.parseBoolean(rateplan.getRbtPurchasePostpaidPromo())  ){
				postpaidStr+=","+RatePlanTags.RBT_PROMO_SMS_TEMPLATE_TAG+":"+rateplan.getRbtPurchasePostPaidTemplateId();
			}
		}
		
		logger.info(" PRE-PAID PROCESS STR= "+prepaidStr);
		logger.info(" POST-PAID PROCESS STR= "+postpaidStr);
		process=prepaidStr+";"+postpaidStr;
		logger.info("FINAL PROCESS STR= "+process);
		
	  return process;
	}
	
	*//**
	 * This method is used for formation of Sub, Purchase, Recoding and Gift Detail for 
	 * 1-Subscription <br/>
	 * 2-RbtPurchage <br/>
	 * 3-Recording <br/>
	 * 4-Gift <br/>
	 * @param falbackStr
	 * @param action
	 *//*
	public void formSubAndPurchaseDetail(String falbackStr,String action){
		
		logger.info(" ### formSubAndPurchaseRenewalDetail ");
		String fbArr[]=null;
		String detailArr[]=null;
		int chgCode=0;
		int  validity=0;
		//added by MoHit 
		if(falbackStr.equalsIgnoreCase("NA"))
		{
			//this.rateplan.setSubscriptionDetails(new ArrayList<SubscriptionDetail>());
			return;
		}
		if(action.equalsIgnoreCase(RatePlanTags.SUBSCRIPTION_TAG)){
			//CC:83,DAYS:14;CC:82,DAYS:7
			//CC:8,DAYS:30, rbtFbChgCode=CC:3,DAYS:30;CC:34,DAYS:21;CC:31,DAYS:1
			List<SubscriptionDetail> subList=new ArrayList<SubscriptionDetail>();
			
			fbArr=falbackStr.split(";");
			
			for (String s : fbArr) {
				logger.info(s);
				detailArr = s.split(",");
				
				chgCode=Integer.parseInt(detailArr[0].split(":")[1]);
				validity=Integer.parseInt(detailArr[1].split(":")[1]);
				
				subList.add(new SubscriptionDetail(chgCode,validity));
			}
			this.rateplan.setSubscriptionDetails(subList);
			
		}else if(action.equalsIgnoreCase(RatePlanTags.RBT_PURCHASE_TAG)){
			//CC:84,DAYS:30;CC:83,DAYS:14
			//CC:3,DAYS:30;CC:34,DAYS:21;CC:31,DAYS:1
			List<RbtPurchaseDetail> rbtpList=new ArrayList<RbtPurchaseDetail>();
			fbArr=falbackStr.split(";");
			for (String s : fbArr) {
				logger.info(s);
				detailArr = s.split(",");
				
				chgCode=Integer.parseInt(detailArr[0].split(":")[1]);
				validity=Integer.parseInt(detailArr[1].split(":")[1]);
				
				rbtpList.add(new RbtPurchaseDetail(chgCode,validity));
			}
			this.rateplan.setRbtPurchaseDetails(rbtpList);
			
		}else if(action.equalsIgnoreCase(RatePlanTags.RECORDING_TAG)){
			//CC:84,DAYS:21;CC:82,DAYS:7
			//CC:8,DAYS:30;CC:84,DAYS:21;CC:83,DAYS:14;CC:82,DAYS:7;CC:81,DAYS:1
			
			List <RbtRecordingDetail> rbtRecList=new ArrayList<RbtRecordingDetail>();
			
			fbArr=falbackStr.split(";");
			for (String s : fbArr) {
				logger.info(s);
				detailArr = s.split(",");
				
				chgCode=Integer.parseInt(detailArr[0].split(":")[1]);
				validity=Integer.parseInt(detailArr[1].split(":")[1]);
				
				rbtRecList.add(new RbtRecordingDetail( chgCode, validity ));
			}
			this.rateplan.setRbtRecordingDetails(rbtRecList);
			
		}else if(action.equalsIgnoreCase(RatePlanTags.RBT_GIFT_TAG)){
			//CC:43,DAYS:7;CC:41,DAYS:1
			//CC:4,DAYS:30;CC:44,DAYS:21;CC:43,DAYS:14;CC:42,DAYS:7;CC:41,DAYS:1
			List<RbtGiftDetail> rbtGiftList=new ArrayList<RbtGiftDetail>();
			
			fbArr=falbackStr.split(";");
			for (String s : fbArr) {
				logger.info(s);
				detailArr = s.split(",");
				
				chgCode=Integer.parseInt(detailArr[0].split(":")[1]);
				validity=Integer.parseInt(detailArr[1].split(":")[1]);
				
				rbtGiftList.add(new RbtGiftDetail( chgCode, validity ));
			}
			
			this.rateplan.setRbtGiftDetails(rbtGiftList);
			
		}else{
			logger.warn(" RatePlanTags doesn't match with actions!!");
		}
		
	}//### END OF formSubAndPurchaseDetail()
	
	*//**
	 * This method is used for formation of Renewal Detail of Sub And Purchase and Recording 
	 * 1-RenewSubscription <br/>
	 * 2-RbtRenew <br/>
	 * 3-RecordingRnew <br/>
	 * 
	 * @param falbackRenewStr
	 * @param action
	 *//*
	public void formSubAndPurchaseRenewalDetail(String falbackRenewStr,String action){
		logger.info(" ### formSubAndPurchaseRenewalDetail ");
		
		String fbArr[]=null;
		String detailArr[]=null;
		int chgCode=0;
		int validity=0;
		int stid=0;
		int ftid=0;
		if(falbackRenewStr.equalsIgnoreCase("NA"))
		{
			//this.rateplan.setSubscriptionDetails(new ArrayList<SubscriptionDetail>());
			return;
		}
		if(action.equalsIgnoreCase(RatePlanTags.SUBSCRIPTION_TAG)){
			//CC:2,DAYS:30,STID:1,FTID:1;CC:84,DAYS:21,STID:100,FTID:100
			//CC:8,DAYS:30
			List<SubscriptionRenewDetail> subRenewList=new ArrayList<SubscriptionRenewDetail>();
			
			fbArr=falbackRenewStr.split(";");
			
			
			
			for (String s : fbArr) {
				logger.info(s);
				detailArr = s.split(",");
				
				chgCode=Integer.parseInt(detailArr[0].split(":")[1]);
				validity=Integer.parseInt(detailArr[1].split(":")[1]);
				stid=Integer.parseInt(detailArr[2].split(":")[1]);
				ftid=Integer.parseInt(detailArr[3].split(":")[1]);
				
				subRenewList.add(new SubscriptionRenewDetail(chgCode,validity,stid,ftid));
				
			}
			this.rateplan.setSubscriptionRenewDetails(subRenewList);
			
		}else if(action.equalsIgnoreCase(RatePlanTags.RBT_PURCHASE_TAG)){
			//CC:84,DAYS:21,STID:103,FTID:103;CC:82,DAYS:7,STID:6,FTID:6
			//CC:3,DAYS:30;CC:34,DAYS:21;CC:33,DAYS:14;CC:32,DAYS:7;CC:31,DAYS:1
			List<RbtRenewDetail> rbtRenewList=new ArrayList<RbtRenewDetail>();
			
			fbArr=falbackRenewStr.split(";");
			for (String s : fbArr) {
				logger.info(s);
				detailArr = s.split(",");
				
				chgCode=Integer.parseInt(detailArr[0].split(":")[1]);
				validity=Integer.parseInt(detailArr[1].split(":")[1]);
				stid=Integer.parseInt(detailArr[2].split(":")[1]);
				ftid=Integer.parseInt(detailArr[3].split(":")[1]);
				
				rbtRenewList.add(new RbtRenewDetail(chgCode,validity,stid,ftid));
			}
			this.rateplan.setRbtRenewDetails(rbtRenewList);
			
		}else if(action.equalsIgnoreCase(RatePlanTags.RECORDING_TAG)){
			//CC:84,DAYS:21,STID:104,FTID:104;CC:83,DAYS:14,STID:7,FTID:7
			//CC:8,DAYS:30;CC:84,DAYS:21;CC:83,DAYS:14;CC:82,DAYS:7;CC:81,DAYS:1
			List<RecordingRenewDetail> recRenewList=new ArrayList<RecordingRenewDetail>();
			
			  detailArr =null;
			  fbArr=falbackRenewStr.split(";");
			  
			for (String s : fbArr) {
				logger.info(s);
				detailArr = s.split(",");
				
				chgCode=Integer.parseInt(detailArr[0].split(":")[1]);
				validity=Integer.parseInt(detailArr[1].split(":")[1]);
				stid=Integer.parseInt(detailArr[2].split(":")[1]);
				ftid=Integer.parseInt(detailArr[3].split(":")[1]);
				
				recRenewList.add(new RecordingRenewDetail(chgCode,validity,stid,ftid));
			}
			this.rateplan.setRecordingRenewDetails(recRenewList);
			
		}else{
			logger.warn(" RatePlanTags doesn't match with actions!!");
		}
	}//### end of method formSubAndPurchaseRenewalDetail()
	
	*//**
	 *@author pankajmishra
	 *
	 * It takes process string from CRBT_RATE_PLAN ["SUB:P,ARSUB:1,ARRBT:0,ARREC:1,SPSMSTID:1,RPSMSTID:1;SUB:O,ARSUB:1,ARRBT:0,ARREC:1,RPSMSTID:6"]
	 * further parse the string and populate
	 * the control tokens to respective variables of <b> CrbtRatePlanBeanNew</b>
	 * 
	 * @param  process of type java.lang.String
	 *  
	 * 
	 *//*
	public void populatePrepaidPostpaidProcess(String process){
		logger.info("inside populatePrepaidPostpaidProcess() ");
		logger.info(" PROCESS = ["+process+"");
		//"SUB:P,ARSUB:1,ARRBT:1,ARREC:1,SPSMSTID:2;SUB:O,ARSUB:0,ARRBT:1,ARREC:0,SPSMSTID:2,RPSMSTID:6"
         String prePaid=null;
         String postPaid=null;
         String par[]=process.split(";");
         try{
                    if(par.length==2){
                            if(par[0].toUpperCase().startsWith("SUB:"+RatePlanTags.PRE_PAID_TAG)){
                                    prePaid=par[0];
                            }
                            if(par[1].toUpperCase().startsWith("SUB:"+RatePlanTags.POST_PAID_TAG)){
                                    postPaid=par[1];
                            }
                    }else if(par.length==1){
                            if(par[0].toUpperCase().startsWith("SUB:"+RatePlanTags.PRE_PAID_TAG)){
                                    prePaid=par[0];
                            }else if(par[0].toUpperCase().startsWith("SUB:"+RatePlanTags.POST_PAID_TAG)){
                                    postPaid=par[1];
                            }
                    }
                    *//**
                     * ############ prePaid field population ###########
                     *//*
                    if( prePaid!=null && (!prePaid.equalsIgnoreCase("")) ){
                            String pre_ar[]=prePaid.split(",");

                            for(String s:pre_ar){
                                    if( s.toUpperCase().startsWith(RatePlanTags.AUTO_RENEW_SUBSCRIPTION_TAG+":") ){

                                            if(s.split(":").length==2){
                                                    if( s.split(":")[1].equalsIgnoreCase(RatePlanTags.ENABLE_TAG.toString()) )
                                                    {
                                                            this.rateplan.setEnableSubAutoRenewPrepaid("true");
                                                    }else{
                                                            this.rateplan.setEnableSubAutoRenewPrepaid("false");
                                                    }
                                            }
                                    }else if( s.toUpperCase().startsWith(RatePlanTags.AUTO_RENEW_RBT_TAG+":") ){

                                            if(s.split(":").length==2){
                                                    if( s.split(":")[1].equalsIgnoreCase(RatePlanTags.ENABLE_TAG.toString()) )
                                                    {
                                                            this.rateplan.setEnableRbtAutoRenewPrepaid("true");
                                                    }else{
                                                            this.rateplan.setEnableRbtAutoRenewPrepaid("false");
                                                    }
                                            }
                                    }else if( s.toUpperCase().startsWith(RatePlanTags.AUTO_RENEW_RECORDING_TAG+":") ){

                                            if(s.split(":").length==2){
                                                    if( s.split(":")[1].equalsIgnoreCase(RatePlanTags.ENABLE_TAG.toString()) )
                                                    {
                                                            this.rateplan.setEnableRecordAutoRenewPrepaid("true");
                                                    }else{
                                                            this.rateplan.setEnableRecordAutoRenewPrepaid("false");
                                                    }
                                            }
                                    }else if( s.toUpperCase().startsWith(RatePlanTags.SUB_PROMO_SMS_TEMPLATE_TAG+":") ){
                                        if(s.split(":").length==2){
                                                 this.rateplan.setSubPrepaidPromo("true");
                                                 this.rateplan.setSubPrePaidTemplateId(Integer.parseInt(s.split(":")[1]));
                                        }
                                }else if( s.toUpperCase().startsWith(RatePlanTags.RBT_PROMO_SMS_TEMPLATE_TAG+":") ){
                                        if(s.split(":").length==2){
                                                 this.rateplan.setRbtPurchasePrepaidPromo("true");
                                                 this.rateplan.setRbtPurchasePrePaidTemplateId(Integer.parseInt(s.split(":")[1]));
                                        }
                                }

                        }//### END of pre-paid loop
                }//### END of Pre-Paid Formation

                *//**
                 * ############ postPaid field population ###########
                 *//*

                if( postPaid!=null && (!postPaid.equalsIgnoreCase("")) ){
                        String post_ar[]=postPaid.split(",");

                        for(String s:post_ar){
                                if( s.toUpperCase().startsWith(RatePlanTags.AUTO_RENEW_SUBSCRIPTION_TAG+":") ){

                                        if(s.split(":").length==2){
                                                if( s.split(":")[1].equalsIgnoreCase(RatePlanTags.ENABLE_TAG.toString()) )
                                                {
                                                        this.rateplan.setEnableSubAutoRenewPostpaid("true");
                                                }else{
                                                        this.rateplan.setEnableSubAutoRenewPostpaid("false");
                                                }
                                        }
                                }else if( s.toUpperCase().startsWith(RatePlanTags.AUTO_RENEW_RBT_TAG+":") ){

                                        if(s.split(":").length==2){
                                                if( s.split(":")[1].equalsIgnoreCase(RatePlanTags.ENABLE_TAG.toString()) )
                                                {
                                                        this.rateplan.setEnableRbtAutoRenewPostpaid("true");
                                                }else{
                                                        this.rateplan.setEnableRbtAutoRenewPostpaid("false");
                                                }
                                        }
                                }else if( s.toUpperCase().startsWith(RatePlanTags.AUTO_RENEW_RECORDING_TAG+":") ){

                                        if(s.split(":").length==2){
                                        	
                                        	 if( s.split(":")[1].equalsIgnoreCase(RatePlanTags.ENABLE_TAG.toString()) )
                                             {
                                                     this.rateplan.setEnableRecordAutoRenewPostpaid("true");
                                             }else{
                                                     this.rateplan.setEnableRecordAutoRenewPostpaid("false");
                                             }
                                     }
                             }else if( s.toUpperCase().startsWith(RatePlanTags.SUB_PROMO_SMS_TEMPLATE_TAG+":") ){
                                     if(s.split(":").length==2){
                                              this.rateplan.setSubPostpaidPromo("true");
                                              this.rateplan.setSubPostPaidTemplateId(Integer.parseInt(s.split(":")[1]));
                                     }
                             }else if( s.toUpperCase().startsWith(RatePlanTags.RBT_PROMO_SMS_TEMPLATE_TAG+":") ){
                                     if(s.split(":").length==2){
                                              this.rateplan.setRbtPurchasePostpaidPromo("true");
                                              this.rateplan.setRbtPurchasePostPaidTemplateId(Integer.parseInt(s.split(":")[1]));
                                     }
                             }

                     }//### END of post-paid loop
             }//### END of Post-Paid Formation
           }catch (Exception e) {
			logger.error("ERROR in pupulating from process string ",e);
			e.printStackTrace();
		}
	}//### END of populatePrePaidAndPostPaid process

	*//**
	 * This common validation element for 
	 * This is method is made for validating whether next element of list is null or not 
	 * @param lst  type List
	 * @param i type in
	 * @return boolean
	 *//*
	public  boolean validateList(List lst,int i){
         try{
                
        	     
        	     Object o=lst.get(i);
                 if(o!=null&& o  instanceof SubscriptionDetail){
         	 
                	 if(((SubscriptionDetail)o).getChargingCode()!=0){
                		 logger.info("i+1="+i+"\n\n\n");
                		 return true;
                	 }else {
                		 return false;
                	 }
                	 
                 }else if(o!=null && o instanceof SubscriptionRenewDetail){
                	 if(((SubscriptionRenewDetail)o).getChargingCode()!=0){
                		 return true;
                	 }else {
                		 return false;
                	 }
                 }
                 else if(o!=null && o instanceof FreeRbtDetail){
                	 if(((FreeRbtDetail)o).getChargingCode()!=0){
                		 return true;
                	 }else {
                		 return false;
                	 }
                 }
                 else if(o!=null && o instanceof RbtPurchaseDetail){
                	 if(((RbtPurchaseDetail)o).getChargingCode()!=0){
                		 return true;
                	 }else {
                		 return false;
                	 }
                 }else if(o!=null && o instanceof RbtRenewDetail){
                	 if(((RbtRenewDetail)o).getChargingCode()!=0){
                		 return true;
                	 }else {
                		 return false;
                	 }
                 }else if(o!=null && o instanceof RbtRecordingDetail){
                	 if(((RbtRecordingDetail)o).getChargingCode()!=0){
                		 return true;
                	 }else {
                		 return false;
                	 }
                 }else if(o!=null && o instanceof RecordingRenewDetail){
                	 if(((RecordingRenewDetail)o).getChargingCode()!=0){
                		 return true;
                	 }else {
                		 return false;
                	 }
                 }else if(o!=null &&  o instanceof RbtGiftDetail){
                	 if(((RbtGiftDetail)o).getChargingCode()!=0){
                		 return true;
                	 }else {
                		 return false;
                	 }
                 }else{
                	 return false;
                 }
         }catch(IndexOutOfBoundsException e){
                 //e.printStackTrace();
                 return false;
         }catch(Exception e){
                 //e.printStackTrace();
                 return false;
         }
	 }*/
 
}
