package com.telemune.vcc.webadmin.action;

public interface RatePlanTags {
	public final String CHARGE_CODE_TAG="CC";
	public final String VALIDITY_DAYS_TAG="DAYS";
	public final String SUCCESS_TEMPLATE_TAG="STID";
	public final String FAILURE_TEMPLATE_TAG="FTID";
	
	public final String SUBSCRIPTION_TAG="SUB";
	public final String RBT_PURCHASE_TAG="RBTP";
	public final String RECORDING_TAG="REC";
	public final String RBT_GIFT_TAG="GIFT";
	
	public final String SUB_PROMO_SMS_TEMPLATE_TAG="SPSMSTID";
	public final String RBT_PROMO_SMS_TEMPLATE_TAG="RPSMSTID";
	
	public final String AUTO_RENEW_SUBSCRIPTION_TAG="ARSUB";
	public final String AUTO_RENEW_RBT_TAG="ARRBT";
	public final String AUTO_RENEW_RECORDING_TAG="ARREC";
	
	public final Short ENABLE_TAG=1;
	public final Short DISABLE_TAG=0;
	public final String PRE_PAID_TAG="P";
	public final String POST_PAID_TAG="O";
	
	
	public final String ADD_ACTION_TAG="ADD";
	public final String UPDATE_ACTION_TAG="UPDATE";
	
	public final String VIEW_ACTION_TAG="VIEW";
	public final String UPDATE_VIEW_ACTION_TAG="UPDATE_VIEW";

	public final String NUMBER_OF_RBT_TAG="NOR";
	public final String NUMBER_OF_FREE_RBT_TAG="NOFR";
	public final String RBT_FREE_TAG="FREE";
	
   
	
}
