package com.telemune.vcc.webadmin.action;

import java.util.Comparator;

public class RatePlanValidityComparator implements Comparator<SubscriptionDetail> {

	@Override
	public int compare(SubscriptionDetail o1, SubscriptionDetail o2) {
		 if (o1== null && o2 == null) return 0;
         if (o1 == null) return true? 1 : -1;
         if (o2== null) return true? -1 : 1;
		return (o1.getValidity()>o2.getValidity() ? -1 : (o1.getValidity()==o2.getValidity() ? 0 : 1));
	}

}
