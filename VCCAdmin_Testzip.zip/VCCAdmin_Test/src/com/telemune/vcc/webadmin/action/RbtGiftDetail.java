package com.telemune.vcc.webadmin.action;

public class RbtGiftDetail {
	
	private Integer noOfRbt=0;
	private Integer noOfFreeRbt=0;

	private Integer chargingCode=0;
	private Integer validity=0;
	private String name="";
	
	
	public RbtGiftDetail() {
		super();
		// TODO Auto-generated constructor stub
	}
	 
	public RbtGiftDetail(Integer noOfRbt,Integer noOfFreeRbt,String name) {
		super();
		this.name=name;
		this.noOfRbt=noOfRbt;
		this.noOfFreeRbt=noOfFreeRbt;
	}

	
	public RbtGiftDetail(Integer chargingCode, Integer validity) {
		super();
		this.chargingCode = chargingCode;
		this.validity = validity;
	}
	
	
	
	

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getNoOfRbt() {
		return noOfRbt;
	}

	public void setNoOfRbt(Integer noOfRbt) {
		this.noOfRbt = noOfRbt;
	}

	public Integer getNoOfFreeRbt() {
		return noOfFreeRbt;
	}

	public void setNoOfFreeRbt(Integer noOfFreeRbt) {
		this.noOfFreeRbt = noOfFreeRbt;
	}

	public Integer getValidity() {
		return validity;
	}
	public void setValidity(Integer validity) {
		this.validity = validity;
	}
	
	public Integer getChargingCode() {
		return chargingCode;
	}


	public void setChargingCode(Integer chargingCode) {
		this.chargingCode = chargingCode;
	}


	@Override
	public String toString() {
		return "SubscriptionDetail [chargingCode=" + chargingCode
				+ ", validity=" + validity + "] noOfRbt["+noOfRbt+"] noOfFreeRbt["+noOfFreeRbt+"]";
	}
	
}
