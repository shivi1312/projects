

package com.telemune.vcc.webadmin.action;

import java.util.ArrayList;
import java.util.Hashtable;

import org.apache.log4j.Logger;

import com.telemune.vcc.common.Rbt;
import com.telemune.vcc.common.TSSJavaUtil;
import com.telemune.vcc.common.ValidateAction;
import com.telemune.vcc.webadmin.RbtOrderManager;

public class RbtOrderAction extends ValidateAction 
{
	{
		setLinkName("webadmin");
	}
	
	private static final long serialVersionUID = 1L;
	private Logger logger=Logger.getLogger(RbtOrderAction.class);
	private int catId=-1;
	private int rbtId=-1;
	private int rbtOrder=-1;	
	private ArrayList<Rbt> rbtList=null;
	private Hashtable  categories = null;
	//advanceSettingBean.cpDetail[0].chargingCode
	private ArrayList<Integer> newRbtOrderIds=new ArrayList<Integer>();
	private ArrayList<Integer> newRbtOrderValues=new ArrayList<Integer>();
	


	public ArrayList<Integer> getNewRbtOrderIds() {
		return newRbtOrderIds;
	}


	public void setNewRbtOrderIds(ArrayList<Integer> newRbtOrderIds) {
		this.newRbtOrderIds = newRbtOrderIds;
	}


	public ArrayList<Integer> getNewRbtOrderValues() {
		return newRbtOrderValues;
	}


	public void setNewRbtOrderValues(ArrayList<Integer> newRbtOrderValues) {
		this.newRbtOrderValues = newRbtOrderValues;
	}


	public Hashtable getCategories() {
		return categories;
	}


	public void setCategories(Hashtable categories) {
		this.categories = categories;
	}


	public int getCatId() {
		return catId;
	}


	public void setCatId(int catId) {
		this.catId = catId;
	}


	public int getRbtId() {
		return rbtId;
	}


	public void setRbtId(int rbtId) {
		this.rbtId = rbtId;
	}


	public int getRbtOrder() {
		return rbtOrder;
	}


	public void setRbtOrder(int rbtOrder) {
		this.rbtOrder = rbtOrder;
	}


	public ArrayList<Rbt> getRbtList() {
		return rbtList;
	}


	public void setRbtList(ArrayList<Rbt> rbtList) {
		this.rbtList = rbtList;
	}


	public String getSuccess()
	{
		if(!checkSession().equalsIgnoreCase("success"))
		{
			return ERROR;
		}
		else
		{
			return SUCCESS;
		}
	}
	
	public String getData()
	{
		categories=new Hashtable();
	    TSSJavaUtil.instance();
		categories=TSSJavaUtil.getCategory_params();
	    if(categories==null)
	    {
	    	return ERROR;
	    }
	    else
	    {
	    	return SUCCESS;
	    }
	    
	}
	
	public String getCatData()
	{
		logger.info("Inside function getCatData() where all Rbts to search of CATID:"+catId);
		if(!checkSession().equalsIgnoreCase("success"))
		{
			return ERROR;
		}		
		
		rbtList=new ArrayList<Rbt>();
		RbtOrderManager manager=new RbtOrderManager();
		int result=-1;
		result=manager.searchRbtTones(catId, rbtList);
		
		if(result<=-1)
		{
			rbtList=null;
			return ERROR;
		}
		else
		{
			return SUCCESS;
		}
				
	}//getCatData() ends


	public String addRbtOrder()
	{
		logger.info("In addRbtOrder() To add/Modify rbt orders for category");
	
		if(!checkSession().equalsIgnoreCase("success"))
		{
			return ERROR;
		}
		else
		{	
			//int sizeOfArray=newRbtOrderIds.size();			
			if(newRbtOrderIds.contains(null))
			{
				int index=-1;				
				for(int i=0;i<newRbtOrderIds.size();i++)
				{
					index=newRbtOrderValues.indexOf(null);
					if(index>-1)
					{
						//System.out.println("removing null at index:"+index+", in array:"+newRbtOrderValues+", "+newRbtOrderIds);
						newRbtOrderValues.remove(index);
						newRbtOrderIds.remove(index);
					}
				}
			}
			
			int retVal=-1;
			RbtOrderManager manager=new RbtOrderManager();
			retVal=manager.addNewOrder(newRbtOrderIds,newRbtOrderValues);
			if(retVal>0)
			{
				return SUCCESS;
			}
			else{
				logger.error("Result from RbtOrderManager is nagative while adding/updating RbtOrder in db");
				return ERROR;
			}
		}//else ends
		
	}
	

}//action ends
