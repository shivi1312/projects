package com.telemune.vcc.webadmin.action;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;

import com.telemune.dbutilities.Connection;
import com.telemune.vcc.common.HistoryGenerator;
import com.telemune.vcc.common.RbtManager;
import com.telemune.vcc.common.SessionHistory;
import com.telemune.vcc.common.TSSJavaUtil;
import com.telemune.vcc.common.ValidateAction;
import com.telemune.vcc.model.HistoryDataBean;
import com.telemune.vcc.webadmin.ChargingCode;
import com.telemune.vcc.webadmin.ChargingCodeManager;
import com.telemune.vcc.webadmin.RoleType;
import com.telemune.vcc.webadmin.RoleTypeManager;
import com.telemune.vcc.webadmin.WebAdminLog;
import com.telemune.vcc.webadmin.WebAdminLogManager;

public class RoleChgIvrAction extends ValidateAction {
	Logger logger = Logger.getLogger(RoleChgIvrAction.class);
	ChargingCodeManager chgManager = null;
	private String message;
	RoleChgIvrBean managerBean = null;
	private File msisdnfile;

	HistoryDataBean historyDataBean = null;
	HistoryGenerator historyGenerator = null;

	String roleUrl = "managerole.action?managerBean.id=2";
	String ChgUrl = "manageChgRule.action?managerBean.id=1";
	String ivrUrl = "webIvrManage.action";

	{
		setLinkName("webadmin");
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public RoleChgIvrBean getManagerBean() {
		return managerBean;
	}

	public void setManagerBean(RoleChgIvrBean managerBean) {
		this.managerBean = managerBean;
	}

	public File getMsisdnfile() {
		return msisdnfile;
	}

	public void setMsisdnfile(File msisdnfile) {
		this.msisdnfile = msisdnfile;
	}

	// this function is for handle the Add Charging code
	public String handleAddChargingCode() {
		this.actionName = ChgUrl;
		logger.info("Inside function handleAddChargingCode().....");
		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		} else {

			String retVal = "failure";
			Connection con = null;

			try {
				con = TSSJavaUtil.instance().getconnection();
				chgManager = new ChargingCodeManager();
				ChargingCode chCode = new ChargingCode();
				double amt_p = managerBean.getPreCost();
				double amt_o = managerBean.getPostCost();

				chCode.setChgName(managerBean.getChgName());
				chCode.setAmountP(amt_p);
				chCode.setAmountO(amt_o);

				int i = chgManager.addChargingCode(chCode, con);
				TSSJavaUtil.instance().freeConnection(con);
				if (i < 0) {
					if (i == -2) {
						logger.info("webadmin/ChargingRules: This Charging Rule already exists");
						this.setMessage(getText("alExist"));
					} else {
						this.setMessage(getText("tryLater"));
					}
				} else if (i > 0) {
					logger.info("webadmin/ChargingRules: Chrging Rule is added Successfully");
					this.setMessage(getText("addSuccess"));
				}
				retVal = "success";
			} catch (Exception exe) {
				logger.error("Exception inside handleAddChargingCode(),,,,,",
						exe);
				exe.printStackTrace();
			} finally {

				if (con != null)
					TSSJavaUtil.instance().freeConnection(con);
				chgManager = null;
			}

			return retVal;
		}

	}

	// this function is for handle the Add Charging code
	public String handleDeleteChargingCode() {
		this.actionName = ChgUrl;
		logger.info("Inside function handleDeleteChargingCode().....");
		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		} else {

			String retVal = "failure";
			Connection con = null;

			try {
				con = TSSJavaUtil.instance().getconnection();
				chgManager = new ChargingCodeManager();

				System.out
						.println("?>>>>>>>>   " + managerBean.getDataListAl());
				int i = chgManager.deleteChargingCode(managerBean
						.getDataListAl());
				TSSJavaUtil.instance().freeConnection(con);
				if (i == -1) {
					logger.info("webadmin/ChargingRules: This Charging Rule can't be deleted");
					this.setMessage(getText("cantDelete"));
				} else if (i == 1) {
					logger.info("webadmin/ChargingRules: Chrging Rule is Successfully deleted");
					this.setMessage(getText("delSuccess"));
				}
				retVal = "success";
			} catch (Exception exe) {
				logger.error(
						"Exception inside handleDeleteChargingCode(),,,,,", exe);
				exe.printStackTrace();
			} finally {
				chgManager = null;
				if (con != null)
					TSSJavaUtil.instance().freeConnection(con);

			}

			return retVal;
		}

	}

	// this function handles the manage charging rule
	public String getChargingCodeDetails() {
		logger.info("Inside funtion getChargingCodeDetails(),,,,,,,,,");
		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		} else {

			int id = managerBean.getId();
			String retVal = "failure";
			Connection con = null;
			ArrayList chgAl = null;
			ArrayList dataAl = null;
			ChargingCode chgcode = null;
			ChargingCode oc = null;
			try {
				con = TSSJavaUtil.instance().getconnection();

				chgManager = new ChargingCodeManager();
				chgAl = new ArrayList();
				dataAl = new ArrayList();
				if (id == 1) {
					int val = chgManager.getChargingCode(chgAl, con);
				} else {
					long chgCode = managerBean.getChgCode();
					int val = chgManager.getChargingCode(chgAl, chgCode, con);
				}
				TSSJavaUtil.instance().freeConnection(con);
				dataAl.clear();
				for (int j = 0; j < chgAl.size(); j++) {
					chgcode = new ChargingCode();
					oc = (ChargingCode) chgAl.get(j);
					/*
					 * if(oc.getChgCode()==Integer.parseInt(TSSJavaUtil.instance(
					 * ).getAppConfigParam("FREE_CHARGE_CODE"))) { } else
					 */
					{
						chgcode.setChgCode(oc.getChgCode());
						chgcode.setAmountO(oc.getAmountO());
						chgcode.setAmountP(oc.getAmountP());
						chgcode.setChgName(oc.getChgName());
					}
					dataAl.add(chgcode);
				}
				retVal = "success";
				managerBean.setDataListAl(dataAl);
				managerBean.setSize(dataAl.size());

			} catch (Exception e) {
				logger.error("Exception inside getChargingCodeDetails()....");
				e.printStackTrace();
			} finally {
				chgManager = null;
				chgAl = null;
				dataAl = null;
				chgcode = null;
				oc = null;

				if (con != null)

					TSSJavaUtil.instance().freeConnection(con);

			}
			return retVal;
		}

	}

	// this fucntion hanlde the Modify chgcode()
	public String handleModifyChargingCode() {
		this.actionName = ChgUrl;
		logger.info("Inside fucntion handleModifyChargingCode()......");
		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		} else {

			System.out
					.println("Inside fucntion handleModifyChargingCode()......");
			String retVal = "failure";
			Connection con = null;
			ChargingCode chCode = null;
			WebAdminLogManager webadminlogs = null;
			WebAdminLog logobj = null;
			try {
				con = TSSJavaUtil.instance().getconnection();
				String user_name = (String) sessionMap.get("user");
				chgManager = new ChargingCodeManager();
				chCode = new ChargingCode();
				long chgcode = managerBean.getChgCode();
				double amt_p = managerBean.getPreCost();
				double amt_o = managerBean.getPostCost();

				chCode.setChgName(managerBean.getChgName());
				System.out.println(managerBean.getChgName());
				chCode.setAmountP(amt_p);
				chCode.setAmountO(amt_o);

				webadminlogs = new WebAdminLogManager();
				logobj = new WebAdminLog();
				int k = 0;
				String old_values = "Charging_Code:" + chgcode + ";";
				String new_values = "Charging_Code:" + chgcode + ";";
				if (managerBean.getOldPreCost() != managerBean.getPreCost()) {
					old_values = old_values + "AMOUNT_PRE:"
							+ managerBean.getOldPreCost() + ";";
					new_values = new_values + "AMOUNT_PRE:"
							+ managerBean.getPreCost() + ";";
					k = 1;
				}
				if (managerBean.getOldPostCost() != managerBean.getPostCost()) {
					old_values = old_values + "AMOUNT_POST:"
							+ managerBean.getOldPostCost() + ";";
					new_values = new_values + "AMOUNT_POST:"
							+ managerBean.getPostCost() + ";";
					k = 1;
				}

				if (k == 1) {
					logobj.setTableName("VCC_CHARGING_CODE");
					logobj.setlink("chargingruleslog");
					logobj.setuser(user_name);
					logobj.setPreviousvalue(old_values);
					logobj.setCurrentvalue(new_values);
				}
				int i = chgManager.updateChargingCode(chCode, chgcode, con);

				if (i >= 0 && k == 1) {
					int res = webadminlogs.createLog(logobj, con);
					logger.info("logs return ==" + res);
				}
				TSSJavaUtil.instance().freeConnection(con);

				if (i == 1) {
					logger.info("webadmin/ChargingRule: ChargingRule modified successfully");
					this.setMessage(getText("modSuccess"));
				} else {
					logger.info("Please try later");
					this.setMessage(getText("tryLater"));
				}

				retVal = "success";
			} catch (Exception exe) {
				logger.error("Exception inside handleModifyChargingCode()....",
						exe);
				exe.printStackTrace();
			} finally {
				chCode = null;
				chgManager = null;
				webadminlogs = null;
				logobj = null;
				if (con != null)

					TSSJavaUtil.instance().freeConnection(con);

			}
			return retVal;
		}
	}

	// this function is for add ivr out dail managemenet detail
	public String handleAddIvr() {
		this.actionName = ivrUrl;
		logger.info("Inside function handleAddIvr()......");
		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		} else {

			String retVal = "failure";
			Connection con = null;
			RbtManager rbtMan = null;
			try {
				con = TSSJavaUtil.instance().getconnection();
				String categoryHome = TSSJavaUtil.instance().getAppConfigParam(
						"CATEGORY_FILE_PATH");
				logger.info("categoryHome=" + categoryHome);
				String musicfile = "NA";
				String musicPath = "";
				String origin_address = "7464";

				int error = -1;
				int retvalue = -1;
				String startdate = managerBean.getStartTime().trim();
				String enddate = managerBean.getEndTime().trim();

				logger.info("start=" + startdate + " enddate=" + enddate);
				rbtMan = new RbtManager();
				retvalue = rbtMan.addNewRbt(origin_address, musicfile,
						startdate, enddate, con);
				TSSJavaUtil.instance().freeConnection(con);
				if (retvalue == 0)
					error = 0;
				if (retvalue == 20)
					error = 20;

				if (error == 0) {
					this.setMessage(getText("addSuccess"));
				} else if (error == 20) {
					this.setMessage(getText("opFailed"));
				} else {
					this.setMessage(getText("tryLater"));
				}

				retVal = "success";

			} catch (Exception e) {
				logger.error("Exception inside handleAddIvr(),,,,,", e);
			} finally {
				rbtMan = null;
				if (con != null)

					TSSJavaUtil.instance().freeConnection(con);

			}
			return retVal;
		}

	}

	// this function is for handle the upload file
	public String handleUploadMsisdnList() {
		this.actionName = ivrUrl;
		String retVal = "failure";
		String filepath = "";
		logger.info("Inside function handleUploadMsisdnList()......");
		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		} else {

			System.out
					.println("Inside function handleUploadMsisdnList()......");
			File destfile = null;
			try {
				String categoryHome = TSSJavaUtil.instance().getAppConfigParam(
						"CATEGORY_FILE_PATH");
				logger.info("categoryHome" + categoryHome);
				// categoryHome="D://crbt";
				filepath = categoryHome + "/IVR_OUTDIAL/";
				logger.info("filepath= " + filepath);
				destfile = new File(filepath + "msisdn.txt");
				FileUtils.copyFile(msisdnfile, destfile);

				String cmd = "/home/tomcat/voice/IVR_OUTDIAL/add_to_db.sh";
				Process proc = Runtime.getRuntime().exec(cmd);

				int exitVal = proc.waitFor();// exitValue();
				logger.info("Process exitValue: " + exitVal);
				if (exitVal == 0) {
					this.setMessage(getText("opSuccess"));
				} else {
					this.setMessage(getText("tryLater"));
				}
				retVal = "success";
			} catch (Exception e) {
				e.printStackTrace();
				logger.error("Exception inside handleUploadMsisdnList(),,,,,",
						e);
			}
			return retVal;
		}
	}

	// this fucntion is getting the details of role list

	public String getRoleDetails() {
		int id = managerBean.getId();
		logger.info("Inside function getRoleDetails().....");

		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		} else {
			Connection con = null;
			String retVal = "failure";
			RoleTypeManager roleManager = null;
			RoleType roleType = null;

			ArrayList roleTypeAl = null;

			try {
				con = TSSJavaUtil.instance().getconnection();

				roleManager = new RoleTypeManager();
				roleType = new RoleType();

				roleTypeAl = new ArrayList();

				if (id == 1) {
					int x = roleManager.getHttpLinks(roleTypeAl, con);

				} else if (id == 2) {

					int i = roleManager.getRoleTypes(roleTypeAl, con);
				}

				TSSJavaUtil.instance().freeConnection(con);
				managerBean.setDataListAl(roleTypeAl);
				managerBean.setSize(roleTypeAl.size());
				retVal = "success";
			} catch (Exception e) {
				logger.error("Exception inside getRoleDetails(),,,,,,,,", e);
			} finally {
				roleManager = null;
				roleType = null;
				roleTypeAl = null;

				if (con != null)

					TSSJavaUtil.instance().freeConnection(con);

			}
			return retVal;
		}
	}

	// this function adds the role in database

	public String handleAddRoleTypes() {
		this.actionName = roleUrl;
		logger.info("Inside function handleAddRoleTypes(),,,,,,,,");
		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		} else {

			Connection con = null;
			String retVal = "failure";
			RoleTypeManager roleManager = null;
			RoleType roleType = null;
			HashSet<Integer> linkId = null;
			try {
				con = TSSJavaUtil.instance().getconnection();
				roleManager = new RoleTypeManager();
				roleType = new RoleType();

				String roleName = managerBean.getRoleName();
				String roleDesc = managerBean.getDesc();
				String[] links = managerBean.getDeleteAl();
				linkId = new HashSet<Integer>();
				boolean flagWeb = false, flagCust = false, flagCont = false, flagReport = false;

				for (int i = 0; i < links.length; i++) {
					int id = Integer.parseInt(links[i]);

					System.out.println("linkId:  " + id);
					if (!linkId.contains(id))
						linkId.add(id);
					if (id <= 449 && id >= 10) {
						if (!flagWeb) {
							linkId.add(1);
							flagWeb = true;
						}
						// ****First case when any of children is selected add
						// parent link
						int pId = (id / 10 * 10);
						System.out.println("linkId:  " + pId);
						if (!linkId.contains(pId))
							linkId.add(pId);

						// ****Second Case when add is selected then add
						// view,modify,delete links

						if (id % 10 == 1) {
							if (!linkId.contains(pId + 2)) {
								linkId.add(pId + 2);
								logger.info("added linkId:  " + (pId + 2));
							}
							if (!linkId.contains(pId + 3)) {
								linkId.add(pId + 3);
								logger.info("added linkId:  " + (pId + 3));
							}
							if (!linkId.contains(pId + 4)) {
								linkId.add(pId + 4);
								logger.info("added linkId:  " + (pId + 4));
							}
						} else if (id % 10 == 3 || id % 10 == 4) {
							// *****Third case when delete or modify is selected
							// then add view link
							if (!linkId.contains(pId + 2)) {
								linkId.add(pId + 2);
								System.out.println("linkId:  " + (pId + 2));
							}
						}

					} else if (id <= 699 && id >= 500) {
						if (!flagCust) {
							linkId.add(2);
							flagCust = true;
						}
						int pId = (id / 10 * 10);
						System.out.println("linkId:  " + pId);
						if (!linkId.contains(pId))
							linkId.add(pId);

						// ****Second Case when add is selected then add
						// view,modify,delete links

						if (id % 10 == 1) {

							if (!linkId.contains(pId + 2)) {
								linkId.add(pId + 2);
								logger.info("added linkId:  " + (pId + 2));
							}
							if (!linkId.contains(pId + 3)) {
								linkId.add(pId + 3);
								logger.info("added linkId:  " + (pId + 3));
							}
							if (!linkId.contains(pId + 4)) {
								linkId.add(pId + 4);
								logger.info("added linkId:  " + (pId + 4));
							}
						} else if (id % 10 == 3 || id % 10 == 4) {
							// *****Third case when delete or modify is selected
							// then add view link
							if (!linkId.contains(pId + 2)) {
								linkId.add(pId + 2);
								System.out.println("linkId:  " + (pId + 2));
							}
						}

					} else if (id <= 1449 && id >= 1000) {
						if (!flagCont) {
							linkId.add(3);
							flagCont = true;
						}
						int pId = (id / 10 * 10);
						System.out.println("linkId:  " + pId);
						if (!linkId.contains(pId))
							linkId.add(pId);

						// ****Second Case when add is selected then add
						// view,modify,delete links

						if (id % 10 == 1) {

							if (!linkId.contains(pId + 2)) {
								linkId.add(pId + 2);
								logger.info("added linkId:  " + (pId + 2));
							}
							if (!linkId.contains(pId + 3)) {
								linkId.add(pId + 3);
								logger.info("added linkId:  " + (pId + 3));
							}
							if (!linkId.contains(pId + 4)) {
								linkId.add(pId + 4);
								logger.info("added linkId:  " + (pId + 4));
							}
						} else if (id % 10 == 3 || id % 10 == 4) {
							// *****Third case when delete or modify is selected
							// then add view link
							if (!linkId.contains(pId + 2)) {
								linkId.add(pId + 2);
								System.out.println("linkId:  " + (pId + 2));
							}
						}

					} else if (id <= 1000 && id >= 700) {
						if (!flagReport) {
							linkId.add(4);
							flagReport = true;
						}
						int pId = (id / 10 * 10);
						System.out.println("linkId:  " + pId);
						if (!linkId.contains(pId))
							linkId.add(pId);

						// ****Second Case when add is selected then add
						// view,modify,delete links

						if (id % 10 == 1) {

							if (!linkId.contains(pId + 2)) {
								linkId.add(pId + 2);
								logger.info("added linkId:  " + (pId + 2));
							}
							if (!linkId.contains(pId + 3)) {
								linkId.add(pId + 3);
								logger.info("added linkId:  " + (pId + 3));
							}
							if (!linkId.contains(pId + 4)) {
								linkId.add(pId + 4);
								logger.info("added linkId:  " + (pId + 4));
							}
						} else if (id % 10 == 3 || id % 10 == 4) {
							// *****Third case when delete or modify is selected
							// then add view link
							if (!linkId.contains(pId + 2)) {
								linkId.add(pId + 2);
								System.out.println("linkId:  " + (pId + 2));
							}
						}

					}
				}
				System.out.println(linkId);
				roleType.setRoleName(roleName);
				roleType.setRoleDesc(roleDesc);

				int i = roleManager.addRoleData(roleType, linkId, con); // links
																		// may
																		// be
																		// many,
																		// hence
																		// these
																		// are
																		// passed
																		// as
																		// String
																		// arg.
				HttpServletRequest request=ServletActionContext.getRequest();
				HttpSession session=request.getSession();
				String user=((SessionHistory) session.getAttribute("sessionHistory")).getUser();
				String roleName1 = ((SessionHistory) session.getAttribute("sessionHistory")).getRoleName();
				if (i < 0) {
					if (i == -2) {
						this.setMessage(getText("alExist"));
						historyDataBean = new HistoryDataBean();
						historyDataBean.setUser(user);
						historyDataBean.setAction(getText("rolemanagement"));
						historyDataBean.setEvent("Add");
						historyDataBean.setRole(roleName1);
						historyDataBean.setMsg("Role ["+roleType.getRoleName()+"] Add [Already Exists]");
						historyGenerator = new HistoryGenerator();
						historyGenerator.insertHistoryData(historyDataBean,con);
					} else {
						this.setMessage(getText("tryLater"));
						historyDataBean = new HistoryDataBean();
						historyDataBean.setUser(user);
						historyDataBean.setAction(getText("rolemanagement"));
						historyDataBean.setEvent("Add");
						historyDataBean.setRole(roleName1);
						historyDataBean.setMsg("Role ["+roleType.getRoleName()+"] Add [Failed]");
						historyGenerator = new HistoryGenerator();
						historyGenerator.insertHistoryData(historyDataBean,con);
					}
				} else {
					logger.info("webadmin/RoleManage: role added successfully");
					this.setMessage(getText("addSuccess"));
					historyDataBean = new HistoryDataBean();
					historyDataBean.setUser(user);
					historyDataBean.setAction(getText("rolemanagement"));
					historyDataBean.setEvent("Add");
					historyDataBean.setRole(roleName1);
					historyDataBean.setMsg("Role ["+roleType.getRoleName()+"] Add [Success]");
					historyGenerator = new HistoryGenerator();
					historyGenerator.insertHistoryData(historyDataBean,con);
				}
				TSSJavaUtil.instance().freeConnection(con);
				retVal = "success";
			} catch (Exception e) {
				logger.error("Exception inside ", e);
				e.printStackTrace();
			} finally {
				roleManager = null;
				roleType = null;
				linkId = null;

				if (con != null)

					TSSJavaUtil.instance().freeConnection(con);

			}
			return retVal;
		}
	}

	// this function is for handle the delete role,
	public String handleDeleteRoles() {
		this.actionName = roleUrl;
		logger.info("Inside function handleDeleteRoles().......");
		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		} else {

			Connection con = null;
			String retVal = "failure";
			RoleTypeManager roleManager = null;

			try {
				con = TSSJavaUtil.instance().getconnection();

				roleManager = new RoleTypeManager();
				String[] RoleArr = managerBean.getDeleteAl();
				int i = roleManager.deleteRoleData(RoleArr);
				HttpServletRequest request=ServletActionContext.getRequest();
				HttpSession session=request.getSession();
				String user=((SessionHistory) session.getAttribute("sessionHistory")).getUser();
				String roleName = ((SessionHistory) session.getAttribute("sessionHistory")).getRoleName();
				if (i == -66) {
					logger.info("webadmin/RoleManager: This Role Type is assigned to some other Role");
					//System.out.println("webadmin/RoleManager: This Role Type is assigned to some other Role");
					this.setMessage(getText("webadmin.assigned"));
					
					historyDataBean = new HistoryDataBean();
					historyDataBean.setUser(user);
					historyDataBean.setAction(getText("rolemanagement"));
					historyDataBean.setEvent("Delete");
					historyDataBean.setRole(roleName);
					historyDataBean.setMsg("Role "+Arrays.toString(RoleArr)+" Delete [Failed]");
					historyGenerator = new HistoryGenerator();
					historyGenerator.insertHistoryData(historyDataBean,con);
					
				} else if (i == 99) {
					logger.info("webadmin/RoleManager: The RoleType deleted successfully");
					//System.out.println("webadmin/RoleManager: The RoleType deleted successfully");
					this.setMessage(getText("delSuccess"));
					historyDataBean = new HistoryDataBean();
					historyDataBean.setUser(user);
					historyDataBean.setAction(getText("rolemanagement"));
					historyDataBean.setEvent("Delete");
					historyDataBean.setRole(roleName);
					historyDataBean.setMsg("Role "+Arrays.toString(RoleArr)+" Delete [Success]");
					historyGenerator = new HistoryGenerator();
					historyGenerator.insertHistoryData(historyDataBean,con);
					
				} else {
					logger.info("webadmin/RoleManager: This RoleType cannot be deleted");
					//System.out.println("webadmin/RoleManager: This RoleType cannot be deleted");
					this.setMessage(getText("cantDelete"));
					historyDataBean = new HistoryDataBean();
					historyDataBean.setUser(user);
					historyDataBean.setAction(getText("rolemanagement"));
					historyDataBean.setEvent("Delete");
					historyDataBean.setRole(roleName);
					historyDataBean.setMsg("Role "+Arrays.toString(RoleArr)+" Delete [Failed]");
					historyGenerator = new HistoryGenerator();
					historyGenerator.insertHistoryData(historyDataBean,con);
					
				}

				retVal = "success";
			} catch (Exception e) {
				e.printStackTrace();
				logger.error("Exception inside ", e);
			} finally {
				roleManager = null;
				if (con != null)

					TSSJavaUtil.instance().freeConnection(con);

			}
			return retVal;
		}
	}

	// this function is for view role details corresponding and also it handles
	// the getting data for modify
	public String handleViewRoleDetails() {
		logger.info("Inside function handleViewRoleDetails()......");
		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		} else {

			Connection con = null;
			String retVal = "failure";
			RoleTypeManager roleManager = null;
			ArrayList roleTypeAl = null;
			ArrayList dataAl = null;
			ArrayList validlinksAl = null;
			try {
				con = TSSJavaUtil.instance().getconnection();

				roleManager = new RoleTypeManager();
				roleTypeAl = new ArrayList();
				dataAl = new ArrayList();
				String roleName = managerBean.getRoleName();
				int roleId = managerBean.getRoleId();
				validlinksAl = roleManager.getLinks(roleId, con);
				int links = roleManager.getHttpLinks(roleTypeAl, con);
				TSSJavaUtil.instance().freeConnection(con);
				boolean check = false;

				for (int x = 0; x < roleTypeAl.size(); x++) {
					RoleType role = (RoleType) roleTypeAl.get(x);
					if (validlinksAl.contains(new Integer(role.getLinkId()))) {
						check = true;
					} else {
						check = false;
					}
					role.setCheck(check);

					dataAl.add(role);

				}

				managerBean.setDataListAl(dataAl);
				managerBean.setRoleName(roleName);
				managerBean.setRoleId(roleId);
				logger.info("dataAl: " + managerBean.getDataListAl().toString()
						+ "   RoleName:  " + managerBean.getRoleName()
						+ "   roleId:  " + managerBean.getRoleId());

				retVal = "success";
			} catch (Exception e) {
				logger.error("Exception inside ", e);
			} finally {
				roleManager = null;
				roleTypeAl = null;
				dataAl = null;
				validlinksAl = null;
				if (con != null)

					TSSJavaUtil.instance().freeConnection(con);

			}

			return retVal;
		}
	}

	// this function is for handle the modify Roles type
	public String modifyRoleDetails() {

		this.actionName = roleUrl;
		logger.info("Inside function modifyRoleDetails(),,,,,,");
		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		} else {

			Connection con = null;
			String retVal = "failure";
			RoleTypeManager roleManager = null;
			HashSet<Integer> linkId = null;

			try {
				con = TSSJavaUtil.instance().getconnection();

				roleManager = new RoleTypeManager();

				int roleId = managerBean.getRoleId();
				String[] links = managerBean.getDeleteAl();
				// for(int j=0;j<links.length;j++)
				// System.out.println(links[j]);
				boolean flagWeb = false, flagCust = false, flagCont = false, flagReport = false;
				linkId = new HashSet<Integer>();

				for (int i = 0; i < links.length; i++) {
					int id = Integer.parseInt(links[i]);

					System.out.println("linkId:  " + id);
					if (!linkId.contains(id))
						linkId.add(id);
					if (id <= 449 && id >= 10) {
						if (!flagWeb) {
							linkId.add(1);
							flagWeb = true;
						}
						// ****First case when any of children is selected add
						// parent link
						int pId = (id / 10 * 10);
						System.out.println("linkId:  " + pId);
						if (!linkId.contains(pId))
							linkId.add(pId);

						// ****Second Case when add is selected then add
						// view,modify,delete links

						if (id % 10 == 1) {
							if (!linkId.contains(pId + 2)) {
								linkId.add(pId + 2);
								logger.info("added linkId:  " + (pId + 2));
							}
							if (!linkId.contains(pId + 3)) {
								linkId.add(pId + 3);
								logger.info("added linkId:  " + (pId + 3));
							}
							if (!linkId.contains(pId + 4)) {
								linkId.add(pId + 4);
								logger.info("added linkId:  " + (pId + 4));
							}
						} else if (id % 10 == 3 || id % 10 == 4) {
							// *****Third case when delete or modify is selected
							// then add view link
							if (!linkId.contains(pId + 2)) {
								linkId.add(pId + 2);
								System.out.println("linkId:  " + (pId + 2));
							}
						}

					} else if (id <= 699 && id >= 500) {
						if (!flagCust) {
							linkId.add(2);
							flagCust = true;
						}
						int pId = (id / 10 * 10);
						System.out.println("linkId:  " + pId);
						if (!linkId.contains(pId))
							linkId.add(pId);

						// ****Second Case when add is selected then add
						// view,modify,delete links

						if (id % 10 == 1) {

							if (!linkId.contains(pId + 2)) {
								linkId.add(pId + 2);
								logger.info("added linkId:  " + (pId + 2));
							}
							if (!linkId.contains(pId + 3)) {
								linkId.add(pId + 3);
								logger.info("added linkId:  " + (pId + 3));
							}
							if (!linkId.contains(pId + 4)) {
								linkId.add(pId + 4);
								logger.info("added linkId:  " + (pId + 4));
							}
						} else if (id % 10 == 3 || id % 10 == 4) {
							// *****Third case when delete or modify is selected
							// then add view link
							if (!linkId.contains(pId + 2)) {
								linkId.add(pId + 2);
								System.out.println("linkId:  " + (pId + 2));
							}
						}

					} else if (id <= 1500 && id >= 1100) {
						if (!flagCont) {
							linkId.add(3);
							flagCont = true;
						}
						int pId = (id / 10 * 10);
						System.out.println("linkId:  " + pId);
						if (!linkId.contains(pId))
							linkId.add(pId);

						// ****Second Case when add is selected then add
						// view,modify,delete links

						if (id % 10 == 1) {

							if (!linkId.contains(pId + 2)) {
								linkId.add(pId + 2);
								logger.info("added linkId:  " + (pId + 2));
							}
							if (!linkId.contains(pId + 3)) {
								linkId.add(pId + 3);
								logger.info("added linkId:  " + (pId + 3));
							}
							if (!linkId.contains(pId + 4)) {
								linkId.add(pId + 4);
								logger.info("added linkId:  " + (pId + 4));
							}
						} else if (id % 10 == 3 || id % 10 == 4) {
							// *****Third case when delete or modify is selected
							// then add view link
							if (!linkId.contains(pId + 2)) {
								linkId.add(pId + 2);
								System.out.println("linkId:  " + (pId + 2));
							}
						}

					} else if (id <= 999 && id >= 700) {
						if (!flagReport) {
							linkId.add(4);
							flagReport = true;
						}
						int pId = (id / 10 * 10);
						System.out.println("linkId:  " + pId);
						if (!linkId.contains(pId))
							linkId.add(pId);

						// ****Second Case when add is selected then add
						// view,modify,delete links

						if (id % 10 == 1) {

							if (!linkId.contains(pId + 2)) {
								linkId.add(pId + 2);
								logger.info("added linkId:  " + (pId + 2));
							}
							if (!linkId.contains(pId + 3)) {
								linkId.add(pId + 3);
								logger.info("added linkId:  " + (pId + 3));
							}
							if (!linkId.contains(pId + 4)) {
								linkId.add(pId + 4);
								logger.info("added linkId:  " + (pId + 4));
							}
						} else if (id % 10 == 3 || id % 10 == 4) {
							// *****Third case when delete or modify is selected
							// then add view link
							if (!linkId.contains(pId + 2)) {
								linkId.add(pId + 2);
								System.out.println("linkId:  " + (pId + 2));
							}
						}

					}
				}
				// System.out.println(linkId);
				int i = roleManager.updateRoleData(roleId, linkId, con);
				HttpServletRequest request = ServletActionContext.getRequest();
				HttpSession session = request.getSession();
				String user = ((SessionHistory) session
						.getAttribute("sessionHistory")).getUser();
				String roleName1 = ((SessionHistory) session
						.getAttribute("sessionHistory")).getRoleName();
				if (i < 0) {
					this.setMessage(getText("tryLater"));

					historyDataBean = new HistoryDataBean();
					historyDataBean.setUser(user);
					historyDataBean.setAction(getText("rolemanagement"));
					historyDataBean.setEvent("Modify");
					historyDataBean.setRole(roleName1);
					historyDataBean.setMsg("Role ["+roleId+"] Modify [Failed]");
					historyGenerator = new HistoryGenerator();
					historyGenerator.insertHistoryData(historyDataBean, con);
				} else {
					this.setMessage(getText("modSuccess"));
					logger.info("webadmin/RoleManager: Updation of RoleType "
							+ roleId + " Successfull");

					historyDataBean = new HistoryDataBean();
					historyDataBean.setUser(user);
					historyDataBean.setAction(getText("rolemanagement"));
					historyDataBean.setEvent("Modify");
					historyDataBean.setRole(roleName1);
					historyDataBean.setMsg("Role ["+roleId+"] Modify [Success]");
					historyGenerator = new HistoryGenerator();
					historyGenerator.insertHistoryData(historyDataBean, con);
				}
				TSSJavaUtil.instance().freeConnection(con);
				retVal = "success";
			} catch (Exception e) {
				logger.error("Exception inside ", e);
			} finally {
				roleManager = null;
				linkId = null;
				if (con != null)

					TSSJavaUtil.instance().freeConnection(con);

			}
			return retVal;
		}

	}

}
