package com.telemune.vcc.webadmin.action;

import java.util.ArrayList;

public class RoleChgIvrBean {
	private String chgName;
	private double preCost;
	private double postCost;
	private ArrayList dataListAl= new ArrayList();
	private long chgCode;
	private String[] deleteAl;
	private int id;
	private double oldPreCost;
	private double oldPostCost;
	
	private String endTime;
	private String startTime;
	private String todo;
	private ArrayList roleAl= new ArrayList();
	private int roleId;
	private String roleName;
	private String desc;
	private int size;
	
	
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	public int getRoleId() {
		return roleId;
	}
	public void setRoleId(int roleId) {
		this.roleId = roleId;
	}
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public ArrayList getRoleAl() {
		return roleAl;
	}
	public void setRoleAl(ArrayList roleAl) {
		this.roleAl = roleAl;
	}
	public String getTodo() {
		return todo;
	}
	public void setTodo(String todo) {
		this.todo = todo;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public double getOldPreCost() {
		return oldPreCost;
	}
	public void setOldPreCost(double oldPreCost) {
		this.oldPreCost = oldPreCost;
	}
	public double getOldPostCost() {
		return oldPostCost;
	}
	public void setOldPostCost(double oldPostCost) {
		this.oldPostCost = oldPostCost;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String[] getDeleteAl() {
		return deleteAl;
	}
	public void setDeleteAl(String[] deleteAl) {
		this.deleteAl = deleteAl;
	}
	public String getChgName() {
		return chgName;
	}
	public void setChgName(String chgName) {
		this.chgName = chgName;
	}
	public double getPreCost() {
		return preCost;
	}
	public void setPreCost(double preCost) {
		this.preCost = preCost;
	}
	public double getPostCost() {
		return postCost;
	}
	public void setPostCost(double postCost) {
		this.postCost = postCost;
	}
	public ArrayList getDataListAl() {
		return dataListAl;
	}
	public void setDataListAl(ArrayList dataListAl) {
		this.dataListAl = dataListAl;
	}
	public long getChgCode() {
		return chgCode;
	}
	public void setChgCode(long chgCode) {
		this.chgCode = chgCode;
	}
	
	
	
	

}
