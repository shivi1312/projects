package com.telemune.vcc.webadmin.action;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;
import com.telemune.dbutilities.Connection;
import com.telemune.vcc.common.HistoryGenerator;
import com.telemune.vcc.common.SessionHistory;
import com.telemune.vcc.common.TSSJavaUtil;
import com.telemune.vcc.common.ValidateAction;
import com.telemune.vcc.model.HistoryDataBean;
import com.telemune.vcc.webadmin.*;

public class SmsKeywordTemplateAction extends ValidateAction {

	Logger logger=Logger.getLogger(SmsKeywordTemplateAction.class);
	private String message;
	SmsKeywordTemplateBean bean= null;
	TemplateSMS smsTemp = null;
	SMSKeywordManagerS smsManager=null;
	SMSTemplateManager templateManager=null;

	HistoryDataBean historyDataBean =null;
	HistoryGenerator historyGenerator =null;
	ArrayList<String> templateMsg=null;

	//Start of added by MoHit for COMMON 20 May 2015

	HashMap<Integer, String> templateTypeMap=null;
	HashMap<Integer, String> languageMap=null;

	public HashMap<Integer, String> getLanguageMap() {
		return languageMap;
	}
	public void setLanguageMap(HashMap<Integer, String> languageMap) {
		this.languageMap = languageMap;
	}
	public HashMap<Integer, String> getTemplateTypeMap() {
		return templateTypeMap;
	}
	public void setTemplateTypeMap(HashMap<Integer, String> templateTypeMap) {
		this.templateTypeMap = templateTypeMap;
	}

	//End of added by MoHit for COMMON 20 May 2015
	
	//starts by vpsingh on 15-june
	ArrayList<TemplateLangDetail> languageDetail=null;
	
	public ArrayList<TemplateLangDetail> getLanguageDetail() {
		return languageDetail;
	}
	public void setLanguageDetail(ArrayList<TemplateLangDetail> languageDetail) {
		this.languageDetail = languageDetail;
	}

	//end by vpsingh on 15-june


	{
		setLinkName("webadmin");
		this.actionName="viewKeywords.action?bean.pageId=0&bean.languageId=1&bean.ordrBy=0&bean.srchId=0&bean.srchTxt=";
	}


	public ArrayList<String> getTemplateMsg() {
		return templateMsg;
	}
	public void setTemplateMsg(ArrayList<String> templateMsg) {
		this.templateMsg = templateMsg;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public SmsKeywordTemplateBean getBean() {
		return bean;
	}
	public void setBean(SmsKeywordTemplateBean bean) {
		this.bean = bean;
	}
	// this function is for getting the list for SMS Keyword 

	public String getKeywordsDetails()
	{
		logger.info("Inside function getKeywordsDetails()....... ");
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
		}else{

			Connection con= null;
			String retVal="failure";
			ArrayList templateSmsAl = null;
			try{
				con=TSSJavaUtil.instance().getconnection();
				smsManager = new SMSKeywordManagerS();
				templateSmsAl = new ArrayList();
				int i = -1;
				int tempId=0;
				int pageId = -1;
				int pageCount = 0;
				int searchId =0;
				int proId = 0;
				int orderby = 0;
				String searchtext="";

				pageId = bean.getPageId();
				orderby = Integer.parseInt(bean.getOrdrBy());
				int language = bean.getLanguageId();
				searchId = Integer.parseInt(bean.getSrchId());
				searchtext = bean.getSrchTxt();

				logger.debug("Inside function getKeywordsDetails()....SEARCHTEXT ["+searchtext+ "] SEARCH ID["+ searchId+"] LANGUAGE ID["+language +"] ORDER BY ["+orderby+"] PAGE ID ["+pageId+"]");

				if(searchId==3)
				{
					proId=Integer.parseInt(searchtext);
				}
				i = smsManager.getKeywordSMS(templateSmsAl, language, searchtext,tempId,orderby,searchId,con);
				if(i > 0 || templateSmsAl != null || pageId != -1)
				{
					pageCount = templateSmsAl.size()/10;
					ArrayList dataAl= new ArrayList();
					dataAl.clear();
					Object templateSMSArr[] = templateSmsAl.toArray();
					int start = (pageId *10) + 1;
					int end = ((start+10) > templateSMSArr.length)? (templateSMSArr.length): (start+9) ;
					for(int r = start; r <= end; r++)
					{
						KeywordSMSS smsBean= new KeywordSMSS();
						smsBean.setRequestKeyword(((KeywordSMSS)templateSMSArr[r-1]).getRequestKeyword());
						smsBean.setProcessName(((KeywordSMSS)templateSMSArr[r-1]).getProcessName());	
						smsBean.setPackageName(((KeywordSMSS)templateSMSArr[r-1]).getPackageName());
						smsBean.setCreatedBy(((KeywordSMSS)templateSMSArr[r-1]).getCreatedBy());
						smsBean.setCreationDate(((KeywordSMSS)templateSMSArr[r-1]).getCreationDate());
						smsBean.setUpdateBy(((KeywordSMSS)templateSMSArr[r-1]).getUpdateBy());
						smsBean.setUpdateDate(((KeywordSMSS)templateSMSArr[r-1]).getUpdateDate());
						smsBean.setLanguageId(((KeywordSMSS)templateSMSArr[r-1]).getLanguageId());
						smsBean.setIsWorking(((KeywordSMSS)templateSMSArr[r-1]).getIsWorking());
						dataAl.add(smsBean);
					}
					bean.setDataAl(dataAl);
					bean.setEnd(end);
					bean.setStart(start);
					bean.setSize(templateSmsAl.size());
					bean.setLanguageId(language);
					bean.setPageId(pageId);

					bean.setPagecount(pageCount);

					bean.setOrdrBy(Integer.toString(orderby));
					bean.setSrchId(Integer.toString(searchId));
					bean.setSrchTxt(searchtext);

				}
				retVal="success";

			}catch(Exception e)
			{
				logger.error("Exception inside getKeywordsDetails()......",e);
				e.printStackTrace();
			}finally
			{
				smsManager=null;
				templateSmsAl=null;
				if(con!=null)
					try {
						TSSJavaUtil.instance().freeConnection(con);
					} catch (Exception e) {
						logger.error("Exception inside getKeywordsDetails(),,,,,,",e);

					}
			}

			return retVal;
		}
	}


	// this fucntion is getting the details for particular request keyword

	public String handleViewDetails()
	{
		logger.info("Inside fucntion handleViewDetails()....");
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
		}else{

			Connection con= null;
			String retVal="failure";
			KeywordSMSS templateSms = null;

			try{
				int id= bean.getId();
				con=TSSJavaUtil.instance().getconnection();

				String proname = bean.getProcessName();
				String reqkword =bean.getReqKeyword();
				smsManager = new SMSKeywordManagerS();
				templateSms = new KeywordSMSS();
				ArrayList templateSmsAl = new ArrayList();

				templateSms.setProcessName(proname);
				templateSms.setRequestKeyword(reqkword);
				if(id==2)
				{  String  isWork= bean.getIsWork();
				templateSms.setIsWorking(isWork);
				bean.setReqKeyword(reqkword);
				bean.setProcessName(proname);
				bean.setIsWork(isWork);
				}
				int i = smsManager.getKeywordView(templateSmsAl,proname,reqkword,con);
				bean.setDataAl(templateSmsAl);
				retVal="success";
			}catch(Exception e)
			{
				logger.error("Exception inside handleViewDetails()........",e);

			}finally
			{
				templateSms=null;
				smsManager=null;


				if(con!=null)

					TSSJavaUtil.instance().freeConnection(con);

			}

			return retVal;
		}
	}

	// this fucntion is for modify the request keyword()

	public String handleModifyRequestKeyword()
	{

		logger.info("Inside fucntion handleModifyRequestKeyword()....");
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
		}else{

			//System.out.println("Inside fucntion handleModifyRequestKeyword()....");
			Connection con= null;
			String retVal="failure";
			KeywordSMSS smsTemplate = null;



			try{
				con=TSSJavaUtil.instance().getconnection();
				smsManager = new SMSKeywordManagerS();
				smsTemplate = new KeywordSMSS();

				String pname = bean.getProcessName() ;
				String reqkword= bean.getReqKeyword();
				String  iswork= bean.getIsWork();
				String newreqkwrd=bean.getNewRequestKwd();
				logger.debug("Inside fucntion handleModifyRequestKeyword()...."+pname+"  "+reqkword+ "  "+iswork+"   "+newreqkwrd);

				smsTemplate.setRequestKeyword(reqkword);

				smsTemplate.setProcessName(pname);

				int i = smsManager.updateKeywordSMS(smsTemplate,newreqkwrd,iswork,con);
				HttpServletRequest request=ServletActionContext.getRequest();
				HttpSession session=request.getSession();
				String user=((SessionHistory) session.getAttribute("sessionHistory")).getUser();
				String roleName = ((SessionHistory) session.getAttribute("sessionHistory")).getRoleName();
				if(i > 0)
				{
					this.setMessage(getText("modSuccess"));
					historyDataBean = new HistoryDataBean();
					historyDataBean.setUser(user);
					historyDataBean.setAction(getText("smskeyword"));
					historyDataBean.setEvent("Modify");
					historyDataBean.setRole(roleName);
					historyDataBean.setMsg("SMS Keyword ["+smsTemplate.getRequestKeyword()+"] Modify [Success]");
					historyGenerator = new HistoryGenerator();
					historyGenerator.insertHistoryData(historyDataBean,con);
				}
				else
				{
					this.setMessage(getText("tryLater"));
					historyDataBean = new HistoryDataBean();
					historyDataBean.setUser(user);
					historyDataBean.setAction(getText("smskeyword"));
					historyDataBean.setEvent("Modify");
					historyDataBean.setRole(roleName);
					historyDataBean.setMsg("SMS Keyword ["+smsTemplate.getRequestKeyword()+"] Modify [Failed]");
					historyGenerator = new HistoryGenerator();
					historyGenerator.insertHistoryData(historyDataBean,con);
				}
				logger.debug("Inside fucntion handleModifyRequestKeyword()....Message : "+this.getMessage());
				retVal="success";
			}catch(Exception e)
			{
				logger.error("Exception inside handleModifyRequestKeyword()......",e);
				e.printStackTrace();
			}finally
			{
				smsTemplate=null;
				smsManager=null;

				if(con!=null)

					TSSJavaUtil.instance().freeConnection(con);

			}
			return retVal;	
		}
	}

	//@@@@@@@@@@@@@@@@@@@@ HERE THE FUNCTION DEFINE FOR SMS TEMPLATE @@@@@@@@@@@@@@@@@@@@@@@@@


	public String getTemplateDetails()
	{
		logger.info("Inside function getTemplateDetails()....... ");
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
		}else{

			Connection con= null;
			String retVal="failure";
			ArrayList templateSmsAl = null;

			try{
				con=TSSJavaUtil.instance().getconnection();
				templateManager=new SMSTemplateManager();
				templateSmsAl = new ArrayList();
				int i = -1;
				int tempId=0;
				int pageId = -1;
				int pageCount = 0;
				int searchId =0;
				int proId = 0;
				int orderby = 0;
				String searchtext="";

				pageId = bean.getPageId();
				orderby = Integer.parseInt(bean.getOrdrBy());
				int language = bean.getLanguageId();
				searchId = Integer.parseInt(bean.getSrchId());
				searchtext = bean.getSrchTxt();
				System.out.println("searct text = "+searchtext);
				logger.info("Inside function getTemplateDetails()....SEARCHTEXT ["+searchtext+ "] SEARCH ID["+ searchId+"] LANGUAGE ID["+language +"] ORDER BY ["+orderby+"] PAGE ID ["+pageId+"]");

				if(searchId==4)
				{
					proId=Integer.parseInt(searchtext);
				}
				i = templateManager.getTemplateSMS(templateSmsAl, language, searchtext,tempId,orderby,searchId);
				if(i > 0 || templateSmsAl != null || pageId != -1)
				{
					pageCount = templateSmsAl.size()/10;
					ArrayList dataAl= new ArrayList();
					dataAl.clear();
					Object templateSMSArr[] = templateSmsAl.toArray();
					int start = (pageId *10) + 1;
					int end = ((start+10) > templateSMSArr.length)? (templateSMSArr.length): (start+9) ;
					for(int r = start; r <= end; r++)
					{
						TemplateSMS smsBean= new TemplateSMS();
						smsBean.setTemplateId(((TemplateSMS)templateSMSArr[r-1]).getTemplateId());
						smsBean.setTemplateDescription(((TemplateSMS)templateSMSArr[r-1]).getTemplateDescription());	
						smsBean.setLanguage(((TemplateSMS)templateSMSArr[r-1]).getLanguage());
						smsBean.setTemplateMessage(((TemplateSMS)templateSMSArr[r-1]).getTemplateMessage());
						smsBean.setTemplateType(((TemplateSMS)templateSMSArr[r-1]).getTemplateType());
						smsBean.setTokensAllowed(((TemplateSMS)templateSMSArr[r-1]).getTokensAllowed());
						dataAl.add(smsBean);
					}
					bean.setDataAl(dataAl);
					bean.setEnd(end);
					bean.setStart(start);
					bean.setSize(templateSmsAl.size());
					bean.setLanguageId(language);
					bean.setPageId(pageId);

					bean.setPagecount(pageCount);

					bean.setOrdrBy(Integer.toString(orderby));
					bean.setSrchId(Integer.toString(searchId));
					bean.setSrchTxt(searchtext);

				}
				retVal="success";

			}catch(Exception e)
			{
				logger.error("Exception inside getTemplateDetails()......",e);
				e.printStackTrace();
			}finally
			{
				templateManager=null;
				templateSmsAl=null;

				if(con!=null)
					TSSJavaUtil.instance().freeConnection(con);

			}

			return retVal;
		}
	}


	// this fucntion is getting the details for particular request keyword

	public String handleViewTemplateDetails()
	{
		logger.info("Inside fucntion handleViewTemplateDetails()....");
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
		}else{

			Connection con= null;
			String retVal="failure";
			TemplateSMS templateSMS=null;
			ArrayList templateSmsAl = null;


			try{
				int tempid= bean.getId();
				con=TSSJavaUtil.instance().getconnection();
				int lang=bean.getLanguageId();
				String tempType =bean.getReqKeyword();
				templateManager=new SMSTemplateManager();
				templateSMS=new TemplateSMS();
				templateSmsAl = new ArrayList();
				String[] str=null;
				templateSMS.setTemplateId(tempid);
				templateSMS.setTemplateType(tempType);
				templateSMS.setLanguage(lang);

				int i = templateManager.getTemplateSMS(templateSmsAl, lang, tempType, tempid,str );
				bean.setDataAl(templateSmsAl);
				retVal="success";
			}catch(Exception e)
			{
				logger.error("Exception inside handleViewTemplateDetails()........",e);

			}finally
			{
				templateSMS=null;
				templateSmsAl = null;
				templateManager=null;	  
				if(con!=null)

					TSSJavaUtil.instance().freeConnection(con);

			}

			return retVal;
		}
	}





	public String handleModifyTemplateDetails()
	{
		logger.info("Inside fucntion handleViewTemplateDetails()....");
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
		}else{

			TemplateSMS templateSMS=null;
			ArrayList templateSmsAl = null;
			Connection con= null;
			String retVal="failure";
			StringTokenizer st;
			try{
				int tempid= bean.getId();
				con=TSSJavaUtil.instance().getconnection();
				int lang=bean.getLanguageId();
				String tempType =bean.getReqKeyword();
				templateManager=new SMSTemplateManager();
				templateSMS=new TemplateSMS();
				templateSmsAl = new ArrayList();
				String[] str=null;
				templateSMS.setTemplateId(tempid);
				templateSMS.setTemplateType(tempType);
				templateSMS.setLanguage(lang);

				int i = templateManager.getTemplateSMS(templateSmsAl, lang, tempType, tempid,str );

				if(templateSmsAl.size()>0)
				{

					for(int j=0;j<templateSmsAl.size();j++)
					{
						
						/*st=new StringTokenizer(((TemplateSMS)templateSmsAl.get(j)).getTemplateMessage(),"$(");*/
						
						//Added by Sanchit Atri
						String st1[]=((TemplateSMS)templateSmsAl.get(j)).getTemplateMessage().split("\\$\\(");
						String temp="";
						
						int checksize=-1;
						String fixed="";
						templateMsg=new ArrayList<String>();
						/*while(st.hasMoreTokens())*/
						if(st1.length>=2){
						for(int k=0;k<st1.length;k++)
						{
							fixed="";
							checksize=-1;
							//temp=st.nextToken();
							temp=st1[k];
							checksize=temp.indexOf(")");
							
							if(checksize>0 && k > 0)
							{
								
									
								fixed=temp.substring(0,checksize+1);
								System.out.println("fixed== "+fixed);
								templateMsg.add("$("+fixed);
								temp=temp.substring(checksize+1);
								
							}
							templateMsg.add(temp);
						}
						}else{
							templateMsg.add(st1[0]);
						}
						
						System.out.println("************      "+templateMsg);
					}
				}
				bean.setDataAl(templateSmsAl);
				retVal="success";
			}catch(Exception e)
			{
				logger.error("Exception inside handleViewTemplateDetails()........",e);

			}finally
			{
				templateSMS=null;
				templateSmsAl=null;
				templateManager=null;

				if(con!=null)

					TSSJavaUtil.instance().freeConnection(con);

			}

			return retVal;
		}
	}



	// this fucntion is for modify the request keyword()

	public String ModifyRequestTemplate()
	{

		logger.info("Inside fucntion handleModifyRequestKeyword()....");
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
		}else{

			//System.out.println("Inside fucntion handleModifyRequestKeyword()....");
			Connection con= null;
			String retVal="failure";
			TemplateSMS templateSMS=null;
			actionName="viewTemplate.action?bean.pageId="+bean.getPageId()+"&bean.languageId="+bean.getLanguageId()+"&bean.ordrBy=0&bean.srchId=0&bean.srchTxt=";
			try{
				int tempid= bean.getId();
				con=TSSJavaUtil.instance().getconnection();
				int lang=bean.getLanguageId();
				String tempType =bean.getReqKeyword();
				templateManager=new SMSTemplateManager();
				templateSMS=new TemplateSMS();

				templateSMS.setTemplateId(tempid);
				templateSMS.setTemplateType(tempType);
				templateSMS.setLanguage(lang);
				templateSMS.setTemplateMessage(message);


				int i = templateManager.updateTemplateSMS(templateSMS);
				HttpServletRequest request=ServletActionContext.getRequest();
				HttpSession session=request.getSession();
				String user=((SessionHistory) session.getAttribute("sessionHistory")).getUser();
				String roleName = ((SessionHistory) session.getAttribute("sessionHistory")).getRoleName();
				if(i > 0)
				{
					this.setMessage(getText("modSuccess"));
					historyDataBean = new HistoryDataBean();
					historyDataBean.setUser(user);
					historyDataBean.setAction(getText("smstemplate"));
					historyDataBean.setEvent("Modify");
					historyDataBean.setRole(roleName);
					historyDataBean.setMsg("SMS Template ["+templateSMS.getTemplateId()+"] Modify [Success]");
					historyGenerator = new HistoryGenerator();
					historyGenerator.insertHistoryData(historyDataBean,con);

				}
				else
				{
					this.setMessage(getText("tryLater"));
					historyDataBean = new HistoryDataBean();
					historyDataBean.setUser(user);
					historyDataBean.setAction(getText("smstemplate"));
					historyDataBean.setEvent("Modify");
					historyDataBean.setRole(roleName);
					historyDataBean.setMsg("SMS Template ["+templateSMS.getTemplateId()+"] Modify [Failed]");
					historyGenerator = new HistoryGenerator();
					historyGenerator.insertHistoryData(historyDataBean,con);

				}
				logger.debug("Inside fucntion handleModifyRequestKeyword()....Message : "+this.getMessage());
				retVal="success";
			}catch(Exception e)
			{
				logger.error("Exception inside handleModifyRequestKeyword()......",e);
				e.printStackTrace();
			}finally
			{
				templateSMS=null;
				templateManager=null;
				if(con!=null)

					TSSJavaUtil.instance().freeConnection(con);

			}
			return retVal;	
		}
	}


	//Added by MoHit for COMMON 20 May 2015
	/**
	 * This method is used to get the data required to show on page while adding an SMS Template
	 * @return
	 */
	public String getDataToAddTemplate()
	{
		/////Check session
		try{
			logger.info("inside getDataToAddTemplate().....");
			templateManager=new SMSTemplateManager();
			languageMap=new HashMap<Integer, String>();
			int retval=templateManager.loadLanguageDetails(languageMap);
			logger.debug("loadLanguageDetails() retval ["+retval+"]and languageMap size ["+languageMap.size()+"]");
			
			templateTypeMap=new HashMap<Integer, String>();
			templateTypeMap.put(10, "SMS");

			
			return SUCCESS;
		}catch(Exception e)
		{
			logger.error("Exception inside addNewTemplate()......",e);
			return ERROR;
		}
		finally{
			templateManager=null;
		}
	}//getDataToAddTemplate()


	//Added by Pankaj for COMMON 21 May 2015
	/**
	 * This method is used to handle adding new SMS Template
	 * @return
	 */
	public String addNewTemplate()
	{
		Connection con=null;
		try{
			logger.info("in addNewTemplate().......... languageMsg size ["+smsTemp.getLanguageMsg().length+"] message is ["+smsTemp.getLanguageMsg().toString()+" LangId size ["+smsTemp.getLangId().length+"] TemplateSMS["+smsTemp.getTemplateDescription()+"]");
			
			templateManager=new SMSTemplateManager();
						
			int retval=templateManager.addTemplateSMS(smsTemp);
			logger.debug("addTemplateSMS() retval["+retval+"]");
			con = TSSJavaUtil.instance().getconnection();
			HttpServletRequest request = ServletActionContext.getRequest();
			HttpSession session = request.getSession();
			String user = ((SessionHistory) session
					.getAttribute("sessionHistory")).getUser();
			String roleName = ((SessionHistory) session
					.getAttribute("sessionHistory")).getRoleName();
			if(retval<0){
				if(retval==-2){
					//template description already exist in database
					this.setMessage(getText("webadmin.smsTempDescpExist"));
					
				}else{
					//some error occured
					this.setMessage(getText("tryLater"));
					
				}
				this.actionName="goBack";
				historyDataBean = new HistoryDataBean();
				historyDataBean.setUser(user);
				historyDataBean.setAction(getText("smstemplate"));
				historyDataBean.setEvent("Add");
				historyDataBean.setRole(roleName);
				historyDataBean.setMsg("New Template Add [Failed]");
				historyGenerator = new HistoryGenerator();
				historyGenerator
						.insertHistoryData(historyDataBean, con);
			}else{
				//success case
				this.setMessage(getText("webadmin.smsTempAddSuccess"));
				this.actionName="webSmsTempManage.action";
				historyDataBean = new HistoryDataBean();
				historyDataBean.setUser(user);
				historyDataBean.setAction(getText("smstemplate"));
				historyDataBean.setEvent("Add");
				historyDataBean.setRole(roleName);
				historyDataBean.setMsg("New Template Add [Success]");
				historyGenerator = new HistoryGenerator();
				historyGenerator
						.insertHistoryData(historyDataBean, con);
			}
			return SUCCESS;
		}catch(Exception e)
		{
			logger.error("Exception inside addNewTemplate()......",e);
			return ERROR;
		}
		finally{
			templateManager=null;
		}
	}//addNewTemplate()



	//Added by MoHit for COMMON 21 May 2015
	public TemplateSMS getSmsTemp() {
		return smsTemp;
	}
	public void setSmsTemp(TemplateSMS smsTemp) {
		this.smsTemp = smsTemp;
	}



//added by vpsingh to get lang ids from crbt_lang_detail to show links of that language on 15-june
public String getLanguageIds()
{
	logger.info("In getLanguageIds()....");	
	int result=-1;
	SMSTemplateManager manager=new SMSTemplateManager();
	languageDetail=new ArrayList<TemplateLangDetail>();
	try
	{
		result=manager.getLanguageDetail(languageDetail);
		
		if(result>0)
		{
			return SUCCESS;
		}
		else
		{
			return ERROR;
		}
		
	}
	catch(Exception e){
	logger.error("Error in getLanguageIds() of SmsKeywordTemplateAction: "+e);
	e.printStackTrace();
	return ERROR;
	}

}//getLanguageIds ends


}
