package com.telemune.vcc.webadmin.action;

import java.util.ArrayList;

public class SmsKeywordTemplateBean {
	private int pageId;
	private String processName;
	private int processId;
	private int pagecount;
	private int start;
	private int end;
	private String srchTxt;
	private String srchId;
	private String ordrBy;
	private ArrayList dataAl= new ArrayList();
	private int languageId;
	private int size;
	private String reqKeyword;
	private String isWork;
	private int id;
	private String newRequestKwd;
	
	
	public String getNewRequestKwd() {
		return newRequestKwd;
	}
	public void setNewRequestKwd(String newRequestKwd) {
		this.newRequestKwd = newRequestKwd;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getReqKeyword() {
		return reqKeyword;
	}
	public void setReqKeyword(String reqKeyword) {
		this.reqKeyword = reqKeyword;
	}
	public String getIsWork() {
		return isWork;
	}
	public void setIsWork(String isWork) {
		this.isWork = isWork;
	}
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	public int getPageId() {
		return pageId;
	}
	public void setPageId(int pageId) {
		this.pageId = pageId;
	}
	public String getProcessName() {
		return processName;
	}
	public void setProcessName(String processName) {
		this.processName = processName;
	}
	public int getProcessId() {
		return processId;
	}
	public void setProcessId(int processId) {
		this.processId = processId;
	}
	public int getPagecount() {
		return pagecount;
	}
	public void setPagecount(int pagecount) {
		this.pagecount = pagecount;
	}
	public int getStart() {
		return start;
	}
	public void setStart(int start) {
		this.start = start;
	}
	public int getEnd() {
		return end;
	}
	public void setEnd(int end) {
		this.end = end;
	}
	public String getSrchTxt() {
		return srchTxt;
	}
	public void setSrchTxt(String srchTxt) {
		this.srchTxt = srchTxt;
	}
	public String getSrchId() {
		return srchId;
	}
	public void setSrchId(String srchId) {
		this.srchId = srchId;
	}
	public String getOrdrBy() {
		return ordrBy;
	}
	public void setOrdrBy(String ordrBy) {
		this.ordrBy = ordrBy;
	}
	public ArrayList getDataAl() {
		return dataAl;
	}
	public void setDataAl(ArrayList dataAl) {
		this.dataAl = dataAl;
	}
	public int getLanguageId() {
		return languageId;
	}
	public void setLanguageId(int languageId) {
		this.languageId = languageId;
	}
	
	
	

}
