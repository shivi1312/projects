/**
 *
 *@author MoHit
 *
 */

package com.telemune.vcc.webadmin.action;

import java.util.ArrayList;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;

import com.telemune.dbutilities.Connection;
import com.telemune.vcc.common.HistoryGenerator;
import com.telemune.vcc.common.SessionHistory;
import com.telemune.vcc.common.TSSJavaUtil;
import com.telemune.vcc.common.ValidateAction;
import com.telemune.vcc.model.HistoryDataBean;
import com.telemune.vcc.webadmin.SmscConfigManager;

public class SmscConfigAction extends ValidateAction {

	Logger logger = Logger.getLogger(SmscConfigAction.class);
	private SmscConfig bean = new SmscConfig();
	private String message = "No Message";
	SmscConfigManager scm = null;
	ArrayList smscConfigAl = null;
	HistoryDataBean historyDataBean = null;
	HistoryGenerator historyGenerator = null;
	Connection con = null;

	public ArrayList getSmscConfigAl() {
		return smscConfigAl;
	}

	public void setSmscConfigAl(ArrayList smscConfigAl) {
		this.smscConfigAl = smscConfigAl;
	}

	public void setSmscConfig(SmscConfig smscConfig) {
		this.bean = smscConfig;
	}

	public SmscConfig getBean() {
		return this.bean;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String addSmscConfig() {
		logger.debug("inside addSMSCConfig()");
		this.actionName = "smscConfigViewModify.action?bean.smscId=-1";
		this.linkName = "webadmin";
		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		} else {
			HttpServletRequest request = ServletActionContext.getRequest();
			HttpSession session = request.getSession();
			String user = ((SessionHistory) session
					.getAttribute("sessionHistory")).getUser();
			String roleName1 = ((SessionHistory) session
					.getAttribute("sessionHistory")).getRoleName();
			con = TSSJavaUtil.instance().getconnection();
			try {
				scm = new SmscConfigManager();
				int result = -1;
				result = scm.addSMSCConfig(this.bean);
				logger.info("result = " + result + " (0 for success)");
				if (result == 0) {
					setMessage(getText("addSuccess"));
					historyDataBean = new HistoryDataBean();
					historyDataBean.setUser(user);
					historyDataBean.setAction(getText("smscmanagement"));
					historyDataBean.setEvent("Add");
					historyDataBean.setRole(roleName1);
					historyDataBean.setMsg("SMSC [" + this.bean.getSmscIP()
							+ "] Add [Success]");
					historyGenerator = new HistoryGenerator();
					historyGenerator.insertHistoryData(historyDataBean, con);

				} else {
					setMessage(getText("someError"));

					historyDataBean = new HistoryDataBean();
					historyDataBean.setUser(user);
					historyDataBean.setAction(getText("smscmanagement"));
					historyDataBean.setEvent("Add");
					historyDataBean.setRole(roleName1);
					historyDataBean.setMsg("SMSC [" + bean.getSmscIP()
							+ "] Add [Failed]");
					historyGenerator = new HistoryGenerator();
					historyGenerator.insertHistoryData(historyDataBean, con);
				}
			} catch (Exception e) {
				logger.error("Exception inside addSmscConfig(),,,,,", e);
				return "failure";
			} finally {
				scm = null;
				if (con != null)
					TSSJavaUtil.instance().freeConnection(con);
			}
			return SUCCESS;
		}
	}

	public String getSmscConfig() {

		logger.info("getSmscConfig() started ");
		System.out.println("getSmscConfig() started ");
		int response = -1;
		this.linkName = "webadmin";
		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		} else {
			try {
				scm = new SmscConfigManager();
				smscConfigAl = new ArrayList<SmscConfig>();
				response = scm.getSmscConfig(smscConfigAl, bean.getSmscId());

				if (response == -1) {
					return "failure";
				}
				if (smscConfigAl.size() == 1) {
					bean = (SmscConfig) smscConfigAl.get(0);

					if (bean.getSmscStatus().equals("A")) {
						bean.setSmscStatus(getText("webadmin.activated"));
					}
					if (bean.getSmscStatus().equals("D")) {
						bean.setSmscStatus(getText("webadmin.deactivated"));
					}
					if (bean.getClientType().equals("T")) {
						bean.setClientType(getText("webadmin.transmitter"));
					}
					if (bean.getClientType().equals("R")) {
						bean.setClientType(getText("webadmin.reciever"));
					}
					if (bean.getClientType().equals("TR")) {
						bean.setClientType(getText("webadmin.transreciever"));
					}
				}

			} catch (Exception e) {
				logger.error("Exception inside getSmscConfig(),,,,,", e);
				return "failure";
			} finally {
				scm = null;
			}
			return "success";
		}

	}

	public String modifySmscConfig() {
		logger.info("modifySmscConfig() started " + bean.getSmscId());
		this.actionName = "smscConfigViewModify.action?bean.smscId=-1";
		this.linkName = "webadmin";
		int response = -1;
		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		} else {
			HttpServletRequest request = ServletActionContext.getRequest();
			HttpSession session = request.getSession();
			String user = ((SessionHistory) session
					.getAttribute("sessionHistory")).getUser();
			String roleName1 = ((SessionHistory) session
					.getAttribute("sessionHistory")).getRoleName();
			con = TSSJavaUtil.instance().getconnection();
			try {
				scm = new SmscConfigManager();
				response = scm.updateSMSC(bean);
				if (response == 0) {
					this.setMessage(getText("webadmin.smscConfig.modified"));
					historyDataBean = new HistoryDataBean();
					historyDataBean.setUser(user);
					historyDataBean.setAction(getText("smscmanagement"));
					historyDataBean.setEvent("Modify");
					historyDataBean.setRole(roleName1);
					historyDataBean.setMsg("SMSC [" + bean.getSmscIP()
							+ "] Modify [Success]");
					historyGenerator = new HistoryGenerator();
					historyGenerator.insertHistoryData(historyDataBean, con);
				} else {
					this.setMessage(getText("webadmin.smscConfig.notmodified"));
					historyDataBean = new HistoryDataBean();
					historyDataBean.setUser(user);
					historyDataBean.setAction(getText("smscmanagement"));
					historyDataBean.setEvent("Modify");
					historyDataBean.setRole(roleName1);
					historyDataBean.setMsg("SMSC [" + bean.getSmscIP()
							+ "] Modify [Failed]");
					historyGenerator = new HistoryGenerator();
					historyGenerator.insertHistoryData(historyDataBean, con);
				}
			} catch (Exception e) {
				logger.error("Exception inside modifySmscConfig(),,,,,", e);
				return "failure";
			} finally {
				scm = null;
				if (con != null)
					TSSJavaUtil.instance().freeConnection(con);
			}
			return "success";
		}
	}

	public String deleteSmscConfig() {
		logger.info("deleteSmscConfig() started  list size "
				+ smscConfigAl.size());
		this.actionName = "smscConfigViewModify.action?bean.smscId=-1";
		this.linkName = "webadmin";
		int response = -1;
		this.setMessage(getText("webadmin.smscConfig.notdeleted"));
		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		} else {
			HttpServletRequest request = ServletActionContext.getRequest();
			HttpSession session = request.getSession();
			String user = ((SessionHistory) session
					.getAttribute("sessionHistory")).getUser();
			String roleName1 = ((SessionHistory) session
					.getAttribute("sessionHistory")).getRoleName();
			con = TSSJavaUtil.instance().getconnection();
			try {
				scm = new SmscConfigManager();

				response = scm.deleteSMSC(smscConfigAl);
				if (response == 0) {
					this.setMessage(getText("webadmin.smscConfig.deleted"));
					historyDataBean = new HistoryDataBean();
					historyDataBean.setUser(user);
					historyDataBean.setAction(getText("smscmanagement"));
					historyDataBean.setEvent("Delete");
					historyDataBean.setRole(roleName1);
					historyDataBean.setMsg("SMSC "+smscConfigAl
							+" Delete [Success]");
					historyGenerator = new HistoryGenerator();
					historyGenerator.insertHistoryData(historyDataBean, con);
				}
			} catch (Exception e) {
				logger.error("Exception inside deleteSmscConfig(),,,,,", e);
				return "failure";
			} finally {
				scm = null;
				if (con != null)
					TSSJavaUtil.instance().freeConnection(con);
			}

			return "success";
		}
	}

}
