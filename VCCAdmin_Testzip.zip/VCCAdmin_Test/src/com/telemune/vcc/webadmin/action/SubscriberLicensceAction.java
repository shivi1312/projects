package com.telemune.vcc.webadmin.action;

import org.apache.log4j.Logger;

import com.telemune.vcc.common.ValidateAction;
import com.telemune.vcc.webadmin.SubStat;

public class SubscriberLicensceAction extends ValidateAction 
{
	Logger logger=Logger.getLogger(SubscriberLicensceAction.class);
	int substat;
	
	public int getSubstat() {
		return substat;
	}

	public void setSubstat(int substat) {
		this.substat = substat;
	}

	public String getSubLic() 
	{
		logger.debug("inside getSubLic() ");
		if(!checkSession().equalsIgnoreCase("success"))
		{
			return "error";
		}
		else
		{
			SubStat stat=null;
			try{
			stat= new SubStat();
			substat=stat.getSubStat();
			return SUCCESS;
			}
			catch (Exception e) {
				 logger.error("Exception inside addHomeSubs(),,,,,",e);
				 return "failure";
			}
			finally{
				stat=null;
			}
		}
	}

}
