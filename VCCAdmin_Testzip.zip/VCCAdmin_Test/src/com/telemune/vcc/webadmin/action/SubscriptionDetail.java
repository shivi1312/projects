package com.telemune.vcc.webadmin.action;

public class SubscriptionDetail {
	
	private Integer chargingCode=0;
	private String description="NA";
	private Integer validity=0;
	
	
	
	public SubscriptionDetail() {
		super();
		// TODO Auto-generated constructor stub
	}
	 
	public SubscriptionDetail(Integer chargingCode, Integer validity) {
		super();
		this.chargingCode = chargingCode;
		this.validity = validity;
	}

	public Integer getValidity() {
		return validity;
	}
	public void setValidity(Integer validity) {
		this.validity = validity;
	}
	
	public Integer getChargingCode() {
		return chargingCode;
	}


	public void setChargingCode(Integer chargingCode) {
		this.chargingCode = chargingCode;
	}


	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		return "SubscriptionDetail [chargingCode=" + chargingCode
				+ ", validity=" + validity + "]";
	}
	
}
