package com.telemune.vcc.webadmin.action;

public class SubscriptionRenewDetail {
	
	private Integer chargingCode=0;
	private Integer validity=0;
	
	private Integer renewSuccessTemplateID=0;
	private Integer renewFailedTemplateID=0;
	
	public SubscriptionRenewDetail() {
		super();
		// TODO Auto-generated constructor stub
	}
	 
	

	public SubscriptionRenewDetail(Integer chargingCode, Integer validity,
			Integer renewSuccessTemplateID, Integer renewFailedTemplateID) {
		super();
		this.chargingCode = chargingCode;
		this.validity = validity;
		this.renewSuccessTemplateID = renewSuccessTemplateID;
		this.renewFailedTemplateID = renewFailedTemplateID;
	}



	public Integer getValidity() {
		return validity;
	}
	public void setValidity(Integer validity) {
		this.validity = validity;
	}
	
	public Integer getChargingCode() {
		return chargingCode;
	}


	public void setChargingCode(Integer chargingCode) {
		this.chargingCode = chargingCode;
	}


	public Integer getRenewSuccessTemplateID() {
		return renewSuccessTemplateID;
	}



	public void setRenewSuccessTemplateID(Integer renewSuccessTemplateID) {
		this.renewSuccessTemplateID = renewSuccessTemplateID;
	}



	public Integer getRenewFailedTemplateID() {
		return renewFailedTemplateID;
	}



	public void setRenewFailedTemplateID(Integer renewFailedTemplateID) {
		this.renewFailedTemplateID = renewFailedTemplateID;
	}



	@Override
	public String toString() {
		return "SubscriptionRenewDetail [chargingCode=" + chargingCode
				+ ", validity=" + validity + ", renewSuccessTemplateID="
				+ renewSuccessTemplateID + ", renewFailedTemplateID="
				+ renewFailedTemplateID + "]";
	}
	
}
