package com.telemune.vcc.webadmin.action;

import com.telemune.dbutilities.Connection;
import com.telemune.vcc.common.HistoryGenerator;
import com.telemune.vcc.common.SessionHistory;
import com.telemune.vcc.common.TSSJavaUtil;
import com.telemune.vcc.common.ValidateAction;
import com.telemune.vcc.model.HistoryDataBean;
import com.telemune.vcc.webadmin.SystemConfig;
import com.telemune.vcc.webadmin.SystemConfigManager;
import com.telemune.vcc.webadmin.action.SystemConfigAction;
import java.util.ArrayList;
import java.util.HashMap;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;

public class SystemConfigAction extends ValidateAction {
  Logger logger = Logger.getLogger(SystemConfigAction.class);
  
  private SystemConfig systemConfig = new SystemConfig();
  
  private ArrayList<String> selections = null;
  
  private HashMap<String, String> serviceMap = null;
  
  Connection con = null;
  
  SystemConfigManager systemConfigManager = null;
  
  String selectShortCode = "";
  
  int selectpriority = -1;
  
  int vmSMSOrigin = -1;
  
  int vnSMSOrigin = -1;
  
  int mcaSMSOrigin = -1;
  
  HistoryDataBean historyDataBean = null;
  
  HistoryGenerator historyGenerator = null;
  
  public int getMcaSMSOrigin() {
    return this.mcaSMSOrigin;
  }
  
  public void setMcaSMSOrigin(int mcaSMSOrigin) {
    this.mcaSMSOrigin = mcaSMSOrigin;
  }
  
  public HashMap<String, String> getServiceMap() {
    return this.serviceMap;
  }
  
  public void setServiceMap(HashMap<String, String> serviceMap) {
    this.serviceMap = serviceMap;
  }
  
  public int getVmSMSOrigin() {
    return this.vmSMSOrigin;
  }
  
  public void setVmSMSOrigin(int vmSMSOrigin) {
    this.vmSMSOrigin = vmSMSOrigin;
  }
  
  public int getVnSMSOrigin() {
    return this.vnSMSOrigin;
  }
  
  public void setVnSMSOrigin(int vnSMSOrigin) {
    this.vnSMSOrigin = vnSMSOrigin;
  }
  
  public String getDefaultSelection() {
    return getText("webadmin.sameShortCode");
  }
  
  public SystemConfig getSystemConfig() {
    return this.systemConfig;
  }
  
  public void setSelectShortCode(String selectShortCode) {
    this.selectShortCode = selectShortCode;
  }
  
  public String getSelectShortCode() {
    return this.selectShortCode;
  }
  
  public void setSelectpriority(int selectpriority) {
    this.selectpriority = selectpriority;
  }
  
  public int getSelectpriority() {
    return this.selectpriority;
  }
  
  public void setSystemConfig(SystemConfig systemConfig) {
    this.systemConfig = systemConfig;
  }
  
  public String getMessage() {
    return this.message;
  }
  
  public void setMessage(String message) {
    this.message = message;
  }
  
  public ArrayList<String> getSelections() {
    return this.selections;
  }
  
  public void setSelections(ArrayList<String> selections) {
    this.selections = selections;
  }
  
  public SystemConfigAction() {
    this.selections = new ArrayList<String>();
    this.selections.add(getText("webadmin.sameShortCode"));
    this.selections.add(getText("webadmin.differentShortCode"));
  }
  
  public String getShortCodeDetails() {
    this.logger.info("Inside fucntion getShortCodeDetails().....");
    if (!checkSession().equalsIgnoreCase("success"))
      return "error"; 
    this.systemConfigManager = new SystemConfigManager();
    String retVal = "failure";
    try {
      String vm_short_code = this.systemConfigManager
        .getValueByParamName("VM_SHORT_CODE");
      String vn_short_code = this.systemConfigManager
        .getValueByParamName("VN_SHORT_CODE");
      String priority = this.systemConfigManager
        .getValueByParamName("SERVICE_PRIORITY");
      if (priority.equals("EMPTY") || priority.equals("ERROR") || 
        vm_short_code.equals("EMPTY") || 
        vm_short_code.equals("EMPTY") || 
        vn_short_code.equals("ERROR") || 
        vn_short_code.equals("ERROR")) {
        if (vm_short_code.equals("EMPTY"))
          setMessage(getText("webadmin.shortCode.vmnotfind")); 
        if (vn_short_code.equals("EMPTY"))
          setMessage(getText("webadmin.shortCode.vnnotfind")); 
        if (priority.equals("EMPTY"))
          setMessage(getText("webadmin.shortCode.prioritynotfind")); 
        if (vm_short_code.equals("ERROR") || 
          vm_short_code.equals("ERROR") || 
          priority.equals("ERROR"))
          setMessage(getText("webadmin.shortCode.error")); 
      } else {
        this.systemConfig.setVmShortcode(vm_short_code);
        this.systemConfig.setVnShortCode(vn_short_code);
        this.systemConfig.setPriority(Integer.parseInt(priority));
      } 
      this.logger.info("Inside fucntion getSystemConfDetails().....");
      retVal = "success";
    } catch (Exception exe) {
      this.logger.error("Exception inside getSystemConfDetails().....", 
          exe);
    } finally {
      if (this.con != null)
        TSSJavaUtil.instance().freeConnection(this.con); 
      this.systemConfigManager = null;
    } 
    return retVal;
  }
  
  public String getSmsOriginDetails() {
    this.logger.info("Inside fucntion getSmsOriginDetails().....");
    if (!checkSession().equalsIgnoreCase("success"))
      return "error"; 
    this.systemConfigManager = new SystemConfigManager();
    TSSJavaUtil.instance();
    this.logger.info("control 1 with size of service " + TSSJavaUtil.getServiceMap());
    TSSJavaUtil.instance();
    setServiceMap(TSSJavaUtil.getServiceMap());
    String retVal = "failure";
    try {
      String vm_sms_number = null;
      String vn_sms_number = null;
      String mca_sms_number = null;
      if (((String)this.serviceMap.get("VM")).equalsIgnoreCase("Voice Mail"))
        vm_sms_number = this.systemConfigManager
          .getValueByParamName("VM_SMS_NUMBER"); 
      if (((String)this.serviceMap.get("VN")).equalsIgnoreCase("Voice Note"))
        vn_sms_number = this.systemConfigManager
          .getValueByParamName("VN_SMS_NUMBER"); 
      if (((String)this.serviceMap.get("MCA")).equalsIgnoreCase("MCA"))
        mca_sms_number = this.systemConfigManager
          .getValueByParamName("MCA_SMS_NUMBER"); 
      if (vm_sms_number.equals("EMPTY") || 
        vn_sms_number.equals("EMPTY") || 
        mca_sms_number.equals("EMPTY") || 
        vm_sms_number.equals("ERROR") || 
        vn_sms_number.equals("ERROR") || 
        mca_sms_number.equals("ERROR")) {
        if (vm_sms_number.equals("EMPTY"))
          setMessage(getText("webadmin.vmSms.vmnotfind")); 
        if (vn_sms_number.equals("EMPTY"))
          setMessage(getText("webadmin.vmSms.vnnotfind")); 
        if (mca_sms_number.equals("EMPTY"))
          setMessage(getText("webadmin.mcaSms.mcanotfind")); 
        if (vm_sms_number.equals("ERROR") || 
          vn_sms_number.equals("ERROR") || 
          mca_sms_number.equals("ERROR"))
          setMessage(getText("webadmin.smsorigin.error")); 
      } else {
        this.systemConfig.setVmSmsOrigin(vm_sms_number);
        this.systemConfig.setVnSmsOrigin(vn_sms_number);
        this.systemConfig.setMcaSmsOrigin(mca_sms_number);
      } 
      this.logger.info("Inside fucntion getSmsOriginDetails().....");
      retVal = "success";
    } catch (Exception exe) {
      this.logger.error("Exception inside getSmsOriginDetails().....", exe);
    } finally {
      if (this.con != null)
        TSSJavaUtil.instance().freeConnection(this.con); 
      this.systemConfigManager = null;
    } 
    return retVal;
  }
  
  public String modifyShortCode() {
    this.logger.info("Inside modifyshort code");
    HashMap<String, String> sysBeanMap = new HashMap<String, String>();
    this.actionName = "manageShortCode.action";
    int i = -1;
    int j = -1;
    int k = -1;
    this.linkName = "webadmin";
    if (!checkSession().equalsIgnoreCase("success"))
      return "error"; 
    HttpServletRequest request = ServletActionContext.getRequest();
    HttpSession session = request.getSession();
    String user = ((SessionHistory)session
      .getAttribute("sessionHistory")).getUser();
    String roleName1 = ((SessionHistory)session
      .getAttribute("sessionHistory")).getRoleName();
    this.con = TSSJavaUtil.instance().getconnection();
    try {
      this.systemConfigManager = new SystemConfigManager();
      System.out.println("short code is " + this.selectShortCode + 
          "vmshortcode is" + this.systemConfig.getVmShortcode() + 
          "vnshortcode is " + this.systemConfig.getVnShortCode());
      if (this.selectShortCode
        .equalsIgnoreCase(getText("webadmin.sameShortCode"))) {
        sysBeanMap.put("VM_SHORT_CODE", this.systemConfig.getCode());
        sysBeanMap.put("VN_SHORT_CODE", this.systemConfig.getCode());
        sysBeanMap.put("SERVICE_PRIORITY", String.valueOf(this.selectpriority));
        i = this.systemConfigManager.updateParam(sysBeanMap);
      } else {
        sysBeanMap.put("VM_SHORT_CODE", 
            this.systemConfig.getVmShortcode());
        sysBeanMap.put("VN_SHORT_CODE", 
            this.systemConfig.getVnShortCode());
        i = this.systemConfigManager.updateParam(sysBeanMap);
      } 
      if (i == 0) {
        setMessage(getText("webadmin.shortCode.modified"));
        this.historyDataBean = new HistoryDataBean();
        this.historyDataBean.setUser(user);
        this.historyDataBean.setAction(getText("shortcodes"));
        this.historyDataBean.setEvent("Modify");
        this.historyDataBean.setRole(roleName1);
        this.historyDataBean.setMsg("Short Code Modified [Success]");
        this.historyGenerator = new HistoryGenerator();
        this.historyGenerator.insertHistoryData(this.historyDataBean, this.con);
      } else {
        setMessage(getText("webadmin.shortCode.notmodified"));
        this.historyDataBean = new HistoryDataBean();
        this.historyDataBean.setUser(user);
        this.historyDataBean.setAction(getText("shortcodes"));
        this.historyDataBean.setEvent("Modify");
        this.historyDataBean.setRole(roleName1);
        this.historyDataBean.setMsg("Short Code Modified [Failed]");
        this.historyGenerator = new HistoryGenerator();
        this.historyGenerator.insertHistoryData(this.historyDataBean, this.con);
      } 
    } catch (Exception e) {
      this.logger.error("Exception inside modifyMailBoxConfig(),,,,,", e);
      return "failure";
    } finally {
      sysBeanMap = null;
      this.systemConfigManager = null;
      if (this.con != null)
        TSSJavaUtil.instance().freeConnection(this.con); 
    } 
    return "success";
  }
  
  public String modifySmsorigin() {
    this.logger.info("Inside modifySmsorigin");
    HashMap<String, String> sysBeanMap = new HashMap<String, String>();
    this.actionName = "manageSmsOrigin.action";
    SystemConfig sysBean1 = new SystemConfig();
    int i = -1;
    int j = -1;
    this.linkName = "webadmin";
    if (!checkSession().equalsIgnoreCase("success"))
      return "error"; 
    HttpServletRequest request = ServletActionContext.getRequest();
    HttpSession session = request.getSession();
    String user = ((SessionHistory)session
      .getAttribute("sessionHistory")).getUser();
    String roleName1 = ((SessionHistory)session
      .getAttribute("sessionHistory")).getRoleName();
    this.con = TSSJavaUtil.instance().getconnection();
    try {
      this.systemConfigManager = new SystemConfigManager();
      this.logger.info("vm SMS Origin is [" + this.vmSMSOrigin + 
          "] VN SMS Origin is [" + this.vnSMSOrigin + "] VN SMS Origin is " + this.mcaSMSOrigin);
      if (this.vmSMSOrigin == 1) {
        sysBeanMap.put("VM_SMS_NUMBER", "Calling Party Number");
        sysBeanMap.put("VM_SMS_SENDER_CPN", "1");
      } else if (this.vmSMSOrigin == 2) {
        sysBeanMap.put("VM_SMS_NUMBER", 
            this.systemConfig.getVmSmsOrigin());
        sysBeanMap.put("VM_SMS_SENDER_CPN", "0");
      } 
      if (this.vnSMSOrigin == 1) {
        sysBeanMap.put("VN_SMS_NUMBER", "Calling Party Number");
        sysBeanMap.put("VN_SMS_SENDER_CPN", "1");
      } else if (this.vnSMSOrigin == 2) {
        sysBeanMap.put("VN_SMS_NUMBER", 
            this.systemConfig.getVnSmsOrigin());
        sysBeanMap.put("VN_SMS_SENDER_CPN", "0");
      } 
      if (this.mcaSMSOrigin == 1) {
        sysBeanMap.put("MCA_SMS_NUMBER", "Calling Party Number");
        sysBeanMap.put("MCA_SMS_SENDER_CPN", "1");
      } else if (this.mcaSMSOrigin == 2) {
        sysBeanMap.put("MCA_SMS_NUMBER", 
            this.systemConfig.getMcaSmsOrigin());
        sysBeanMap.put("MCA_SMS_SENDER_CPN", "0");
      } 
      i = this.systemConfigManager.updateParam(sysBeanMap);
      if (i == 0) {
        setMessage(getText("webadmin.smsOrigin.modified"));
        this.historyDataBean = new HistoryDataBean();
        this.historyDataBean.setUser(user);
        this.historyDataBean.setAction(getText("smsoriginationnumber"));
        this.historyDataBean.setEvent("Modify");
        this.historyDataBean.setRole(roleName1);
        this.historyDataBean.setMsg("SMS_Origin_Number Modified for VM, VN and MCA [Success]");
        this.historyGenerator = new HistoryGenerator();
        this.historyGenerator.insertHistoryData(this.historyDataBean, this.con);
      } else {
        setMessage(getText("webadmin.smsOrigin.notmodified"));
        this.historyDataBean = new HistoryDataBean();
        this.historyDataBean.setUser(user);
        this.historyDataBean.setAction(getText("smsoriginationnumber"));
        this.historyDataBean.setEvent("Modify");
        this.historyDataBean.setRole(roleName1);
        this.historyDataBean.setMsg("SMS_Origin_Number Modified for VM, VN and MCA[Success]");
        this.historyGenerator = new HistoryGenerator();
        this.historyGenerator.insertHistoryData(this.historyDataBean, this.con);
      } 
    } catch (Exception e) {
      this.logger.error("Exception inside modifyMailBoxConfig(),,,,,", e);
      return "failure";
    } finally {
      sysBeanMap = null;
      this.systemConfigManager = null;
      if (this.con != null)
        TSSJavaUtil.instance().freeConnection(this.con); 
    } 
    return "success";
  }
}
