package com.telemune.vcc.webadmin.action;

import java.util.ArrayList;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;

import com.telemune.dbutilities.Connection;
import com.telemune.vcc.common.HistoryGenerator;
import com.telemune.vcc.common.SessionHistory;
import com.telemune.vcc.common.TSSJavaUtil;
import com.telemune.vcc.common.ValidateAction;
import com.telemune.vcc.model.HistoryDataBean;
import com.telemune.vcc.webadmin.SystemConfig;
import com.telemune.vcc.webadmin.SystemConfigManager;

public class SystemConfigMonitorAction extends ValidateAction {

	SystemConfigMonitorBean sysBean = null;
	private Logger logger = Logger.getLogger(SystemConfigMonitorAction.class);
	private String message;
	SystemConfigManager systemConfigManager = null;
	HistoryDataBean historyDataBean = null;
	HistoryGenerator historyGenerator = null;

	{
		setLinkName("webadmin");
		this.actionName = "viewSysConfig.action";
	}

	public SystemConfigMonitorBean getSysBean() {
		return sysBean;
	}

	public void setSysBean(SystemConfigMonitorBean sysBean) {
		this.sysBean = sysBean;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	// this function is getting the list of app config params

	public String getAppConfigDetails() {
		logger.info("Inside fucntion getAppConfigDetails().....");
		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		} else {

			sysBean = new SystemConfigMonitorBean();
			String retVal = "failure";
			Connection con = null;
			ArrayList dataAl = new ArrayList();
			systemConfigManager = new SystemConfigManager();
			SystemConfig systemConfig = null;
			SystemConfig newSysBean = null;
			ArrayList systemConfigAl = new ArrayList();
			try {
				con = TSSJavaUtil.instance().getconnection();

				int i = systemConfigManager
						.getSystemConfig(systemConfigAl, con);

				if (i < 0) {
					retVal = "failure";
					this.setMessage(getText("tryLater"));
				} else {

					Iterator ite = systemConfigAl.iterator();
					while (ite.hasNext()) {
						systemConfig = (SystemConfig) ite.next();
						newSysBean = new SystemConfig();
						if (systemConfig.getParamTag().equalsIgnoreCase(
								"IVR_DEFAULT_LANGUAGE")) {// this function is
															// getting the path
															// of ivr file

							String ivr_language = systemConfigManager
									.IVR_Language(systemConfig.getParamValue());

							newSysBean.setParamTag(systemConfig.getParamTag());
							newSysBean.setParamValue(ivr_language);
							newSysBean.setRemarks(systemConfig.getRemarks());

						} else {
							newSysBean.setParamTag(systemConfig.getParamTag());
							newSysBean.setParamValue(systemConfig
									.getParamValue());
							newSysBean.setRemarks(systemConfig.getRemarks());

						}

						dataAl.add(newSysBean);
					}

					logger.info("Inside fucntion getAppConfigDetails().....ArrayList Size : "
							+ dataAl.size());
					retVal = "success";
					sysBean.setDataAl(dataAl);
					sysBean.setSize(dataAl.size());
				}

			} catch (Exception exe) {
				logger.error("Exception inside getAppConfigDetails().....", exe);

			} finally {
				if (con != null)
					TSSJavaUtil.instance().freeConnection(con);
				dataAl = null;
				systemConfigManager = null;
				systemConfig = null;
				newSysBean = null;
				systemConfigAl = null;
			}

			return retVal;
		}
	}

	// this function is for getting the data for modify app config param
	public String getDataForModify() {
		logger.info("inside function getDataForModify().........");
		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		} else {

			String paramTag = sysBean.getParamname();
			String paramValue = sysBean.getParamValue();
			String remarks = sysBean.getRemarks();
			Connection con = null;
			String retval = "failure";
			sysBean.setOldValue(paramValue);
			int i = -1;
			boolean defParam = false;
			boolean ivrFlag = false;
			boolean flag = false;
			// System.out.println("Inside fucntion getDataForModify()...where PARAM TAG ["+paramTag+"] PARAM VALUE ["+paramValue+"] REMARKS ["+remarks+"]");
			logger.debug("Inside fucntion getDataForModify()...where PARAM TAG ["
					+ paramTag
					+ "] PARAM VALUE ["
					+ paramValue
					+ "] REMARKS ["
					+ remarks + "]");
			ArrayList systemConfigVl = new ArrayList();
			ArrayList dataList = new ArrayList();
			SystemConfig systemConfig = null;
			SystemConfigMonitorBean bean = null;
			SystemConfigManager systemConfigManager = null;
			try {
				con = TSSJavaUtil.instance().getconnection();
				if ((paramTag.equals("DEFAULT_RATE_PLAN"))
						|| (paramTag.equals("IVR_DEFAULT_LANGUAGE"))) {
					systemConfigManager = new SystemConfigManager();
					i = systemConfigManager.getSystemConfigParamValue(
							systemConfigVl, paramTag, con);
				}

				if (paramTag.equals("DFAULT_RATE_PLAN")) {
					defParam = true;
					Iterator ite = systemConfigVl.iterator();

					while (ite.hasNext()) {
						systemConfig = (SystemConfig) ite.next();
						bean = new SystemConfigMonitorBean();
						if (!paramValue.equals(systemConfig.getParamValue())) {

							bean.setParamValue(systemConfig.getParamValue());
						}
						dataList.add(bean);

					}
				} else if (paramTag.equals("IVR_DEFAULT_LANGUAGE")) {
					ivrFlag = true;

					if (i > 1) {
						flag = true;
						String language_name = "";
						Iterator ite = systemConfigVl.iterator();
						int count = 0;
						while (ite.hasNext()) {
							systemConfig = (SystemConfig) ite.next();
							bean = new SystemConfigMonitorBean();

							if (paramValue.equals(systemConfig.getParamTag())) {
								language_name = systemConfig.getParamValue();
							}
							sysBean.setParamValue(paramValue);
							bean.setParamname(paramValue);
							bean.setParamValue(language_name);

							if (!language_name.equals(systemConfig
									.getParamValue())) {
								bean.setParamname(systemConfig.getParamTag());
								bean.setParamValue(systemConfig.getParamValue());
							}

							dataList.add(bean);
						}
					} else {
						sysBean.setParamValue(paramValue);
					}

				} else if (paramValue.equalsIgnoreCase("YES")) {
					flag = true;
					paramValue = "1";
					sysBean.setParamValue(paramValue);

				} else if (paramValue.equalsIgnoreCase("NO")) {
					flag = true;
					paramValue = "0";
					sysBean.setParamValue(paramValue);
				} else {
					sysBean.setParamValue(paramValue);
				}

				retval = "success";

				sysBean.setDataAl(dataList);
				sysBean.setRemarks(remarks);
				sysBean.setDefaultflag(defParam);
				sysBean.setIvrFlag(ivrFlag);
				sysBean.setFlag(flag);
				// sysBean.setParamValue(paramValue);
				sysBean.setParamname(paramTag);

			} catch (Exception exe) {
				logger.error(
						"Exception inside function getDataForModify()........",
						exe);
				exe.printStackTrace();
			} finally {
				if (con != null)
					TSSJavaUtil.instance().freeConnection(con);
				systemConfigVl = null;
				dataList = null;
				systemConfig = null;
				bean = null;
				systemConfigManager = null;
			}

			return retval;
		}
	}

	// this function update the SYSTEM CONFIGURATION
	public String updateSystemConfiguration() {
		logger.info("inside function updateSystemConfiguration().........");

		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		} else {
			String param = sysBean.getParamname();
			String value = sysBean.getParamValue();
			String old_value = sysBean.getOldValue();
			String remark = sysBean.getRemarks();
			String retVal = "failure";
			Connection con = null;
			logger.debug("Inside fucntion updateSystemConfiguration() where PARAM NAME ["
					+ param
					+ "] NEW PARAM VALUE ["
					+ value
					+ "] OLD PARAM VALUE ["
					+ old_value
					+ "] REMARKS ["
					+ remark + "]");
			// System.out.println("Inside fucntion where PARAM NAME ["+param+"] NEW PARAM VALUE ["+value+"] OLD PARAM VALUE ["+old_value+"] REMARKS ["+remark+"]");

			SystemConfigManager systemConfigManager = null;
			SystemConfig systemConfig = null;
			try {

				con = TSSJavaUtil.instance().getconnection();

				systemConfigManager = new SystemConfigManager();
				systemConfig = new SystemConfig();

				systemConfig.setParamTag(param);
				systemConfig.setParamValue(value);
				systemConfig.setRemarks(remark);

				int j = systemConfigManager.updateSystemConfig(systemConfig,
						con);

				/*
				 * if(!old_value.equals(value) && j==0) { String
				 * user_name=sessionHistory.getUser(); int i =
				 * systemConfigManager
				 * .updateSystemConfiglogs(systemConfig,user_name,old_value); }
				 */
				historyDataBean = new HistoryDataBean();
				historyGenerator = new HistoryGenerator();
				HttpServletRequest request=ServletActionContext.getRequest();
				HttpSession session=request.getSession();
				String user=((SessionHistory) session.getAttribute("sessionHistory")).getUser();
				String roleName = ((SessionHistory) session.getAttribute("sessionHistory")).getRoleName();
				if (j < 0) {	
					// Added By AbhiShek Rana for creating user history.
					historyDataBean.setUser(user);
					//historyDataBean.setAction("System Config Management");
					historyDataBean.setAction(getText("systemconfigmanagement"));
					historyDataBean.setEvent("Modify");
					historyDataBean.setRole(roleName);
					historyDataBean.setMsg("Updated [" + param + "] with New value [" + value + "] [Failed]");
					historyGenerator.insertHistoryData(historyDataBean,
							con);
				//////////////////////END //////////////////////////
					this.setMessage(getText("tryLater"));
				} else {
					// Added By AbhiShek Rana for creating user history.
					historyDataBean.setUser(user);
					//historyDataBean.setAction("System Config Management");
					historyDataBean.setAction(getText("systemconfigmanagement"));
					historyDataBean.setEvent("Modify");
					historyDataBean.setRole(roleName);
					historyDataBean.setMsg("Updated [" + param
							+ "] with New value [" + value + "] [Success]");
					historyGenerator.insertHistoryData(historyDataBean,
							con);
					
					////////////////////// END //////////////////////////
					this.setMessage(getText("modSuccess"));
				}
				logger.info("inside function updateSystemConfiguration().........Message : "
						+ this.getMessage());
				retVal = "success";
			} catch (Exception ex) {
				logger.error(
						"Exception inside updateSystemConfiguration()....", ex);
				ex.printStackTrace();
			} finally {
				if (con != null)
					TSSJavaUtil.instance().freeConnection(con);
				systemConfig = null;
				systemConfigManager = null;
			}

			return retVal;
		}

	}

}
