package com.telemune.vcc.webadmin.action;

import java.util.ArrayList;

public class SystemConfigMonitorBean {
	
private ArrayList dataAl= new ArrayList();
private String paramValue;
private String paramname;
private String remarks;
private int size;
private boolean defaultflag;
private boolean ivrFlag;
private String oldValue;
private boolean flag;




public boolean isFlag() {
	return flag;
}

public void setFlag(boolean flag) {
	this.flag = flag;
}

public String getOldValue() {
	return oldValue;
}

public void setOldValue(String oldValue) {
	this.oldValue = oldValue;
}

public boolean isDefaultflag() {
	return defaultflag;
}

public void setDefaultflag(boolean defaultflag) {
	this.defaultflag = defaultflag;
}

public boolean isIvrFlag() {
	return ivrFlag;
}

public void setIvrFlag(boolean ivrFlag) {
	this.ivrFlag = ivrFlag;
}

public String getParamValue() {
	return paramValue;
}

public void setParamValue(String paramValue) {
	this.paramValue = paramValue;
}

public int getSize() {
	return size;
}

public void setSize(int size) {
	this.size = size;
}

public String getParamname() {
	return paramname;
}

public void setParamname(String paramname) {
	this.paramname = paramname;
}

public String getRemarks() {
	return remarks;
}

public void setRemarks(String remarks) {
	this.remarks = remarks;
}

public ArrayList getDataAl() {
	return dataAl;
}

public void setDataAl(ArrayList dataAl) {
	this.dataAl = dataAl;
}	
	

}
