package com.telemune.vcc.webadmin.action;

import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.telemune.vcc.common.TSSJavaUtil;
import com.telemune.vcc.common.ValidateAction;
import com.telemune.vcc.webadmin.systemMonitor;

public class SystemMonitorAction extends ValidateAction {
	systemMonitor monitor;
	ArrayList<String> serverList;
	private Logger logger= Logger.getLogger(SystemMonitorAction.class);
	
	public ArrayList<String> getServerList() {
		return serverList;
	}

	public void setServerList(ArrayList<String> serverList) {
		this.serverList = serverList;
	}

	public systemMonitor getMonitor() {
		return monitor;
	}

	public void setMonitor(systemMonitor monitor) {
		this.monitor = monitor;
	}

	public SystemMonitorAction()
	{
		setLinkName("webadmin");
	}

	@Override
	public String execute(){
		logger.info("Inside fucntion showMonitor().....");
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
			}else{
				try{
		serverList=TSSJavaUtil.instance().getTotalServer();
		return "success";
				}
				catch(Exception exe)
				{
					logger.error("Exception inside showMonitor().....",exe);
					return "failure";
				}
			}
	}
	
	
	public String showMonitor()
	{
		
		logger.info("Inside fucntion showMonitor().....");
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
			}else{
				try{
				
		monitor.setImagename("mrtg/"+monitor.getServer()+"_"+monitor.getParameter()+"-"+monitor.getDuration()+".png");
		if(monitor.getParameter().equalsIgnoreCase("cpu"))
		{
			monitor.setHeader(getText("webadmin.sysCpuTop")+"(%)");
			monitor.setUsed("##"+getText("webadmin.sysmCPUind1"));
			monitor.setIdle("##"+getText("webadmin.sysmCPUind2"));
		}
		else if(monitor.getParameter().equalsIgnoreCase("mem"))
		{
			monitor.setHeader(getText("webadmin.sysMemTop")+"(%)");
			monitor.setIdle("##"+getText("webadmin.sysmMemind1"));
		}
		else if(monitor.getParameter().equalsIgnoreCase("trafficeth0"))
		{
			monitor.setHeader(getText("webadmin.sysNetTop")+"eth(0) (%)");
			monitor.setUsed("##"+getText("webadmin.sysmNetind1"));
			monitor.setIdle("##"+getText("webadmin.sysmNetind2"));
		}
		else if(monitor.getParameter().equalsIgnoreCase("eth1"))
		{
			monitor.setHeader(getText("webadmin.sysNetTop")+"eth(1) (%)");
			monitor.setUsed("##"+getText("webadmin.sysmNetind1"));
			monitor.setIdle("##"+getText("webadmin.sysmNetind2"));
		}
		else if(monitor.getParameter().equalsIgnoreCase("bond0"))
		{
			monitor.setHeader(getText("webadmin.sysNetTop")+" (%)");
			monitor.setUsed("##"+getText("webadmin.sysmNetind1"));
			monitor.setIdle("##"+getText("webadmin.sysmNetind2"));
		}
		else if(monitor.getParameter().equalsIgnoreCase("disk"))
		{
			monitor.setHeader(getText("webadmin.sysDiskTop")+" (%)");
			monitor.setUsed("##"+getText("webadmin.sysmDiskind1"));
			monitor.setIdle("##"+getText("webadmin.sysmDiskind2"));
		}
		
		if(monitor.getDuration().equalsIgnoreCase("day"))
		{
			monitor.setGraphheader(getText("webadmin.sysDaily"));
		}
		else if(monitor.getDuration().equalsIgnoreCase("week"))
		{
			monitor.setGraphheader(getText("webadmin.sysWeek"));
		}
		else if(monitor.getDuration().equalsIgnoreCase("Month"))
		{
			monitor.setGraphheader(getText("webadmin.sysMonth"));
		}
		else if(monitor.getDuration().equalsIgnoreCase("year"))
		{
			monitor.setGraphheader(getText("webadmin.sysYear"));
		}
		
		return "success";
	}
	catch(Exception exe)
	{
		logger.error("Exception inside showMonitor().....",exe);
		return "failure";
	}
		
		}
	}
	}
