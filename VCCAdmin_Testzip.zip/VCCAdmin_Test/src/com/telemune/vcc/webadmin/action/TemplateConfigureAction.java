package com.telemune.vcc.webadmin.action;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.telemune.vcc.common.TSSJavaUtil;
import com.telemune.vcc.common.ValidateAction;
import com.telemune.vcc.webadmin.RatePlanManagerNew;
import com.telemune.vcc.webadmin.TempConfigurationDataBean;
import com.telemune.vcc.webadmin.TemplateConfigurationMasterList;
import com.telemune.vcc.webadmin.TemplateConfigureManager;
import com.telemune.vcc.webadmin.TemplateSMS;
import com.telemune.vcc.webadmin.UserStatusBean;



public class TemplateConfigureAction extends ValidateAction {
	private Logger logger=Logger.getLogger(TemplateConfigureAction.class);





	private List<TemplateSMS> templateSMSList=null;
	private Hashtable<String, String> m_CategoryParams=null;
	private Hashtable<String, String> m_RbtCode=null;
	private ArrayList<String> m_ArtistList=null;
	private ArrayList<String> m_AlbumList=null;

	private Map<String,String> userConfTempDetail=null;

	private RatePlanManagerNew m_rpManager=null;
	private TemplateConfigureManager m_tempConfigManager=null; 


	private TemplateConfigurationMasterList m_TempConfData=null;; 
//private UserStatusBean m_userStatusBean=null; //Bean of Active Inactive Nonsubscriber User


private ArrayList<UserStatusBean> m_userStatusList=null;






	public ArrayList<UserStatusBean> getM_userStatusList() {
	return m_userStatusList;
}




public void setM_userStatusList(ArrayList<UserStatusBean> m_userStatusList) {
	this.m_userStatusList = m_userStatusList;
}








	private String jsonTempConf="";



	public String getJsonTempConf() {
		return jsonTempConf;
	}




	public void setJsonTempConf(String jsonTempConf) {
		this.jsonTempConf = jsonTempConf;
	}




	public TemplateConfigurationMasterList getM_TempConfData() {
		return m_TempConfData;
	}




	public void setM_TempConfData(TemplateConfigurationMasterList mTempConfData) {
		m_TempConfData = mTempConfData;
	}




	public List<TemplateSMS> getTemplateSMSList() {
		return templateSMSList;
	}




	public void setTemplateSMSList(List<TemplateSMS> templateSMSList) {
		this.templateSMSList = templateSMSList;
	}




	public Hashtable<String, String> getM_CategoryParams() {
		return m_CategoryParams;
	}




	public void setM_CategoryParams(Hashtable<String, String> mCategoryParams) {
		m_CategoryParams = mCategoryParams;
	}




	public Hashtable<String, String> getM_RbtCode() {
		return m_RbtCode;
	}




	public void setM_RbtCode(Hashtable<String, String> mRbtCode) {
		m_RbtCode = mRbtCode;
	}




	public ArrayList<String> getM_ArtistList() {
		return m_ArtistList;
	}




	public void setM_ArtistList(ArrayList<String> mArtistList) {
		m_ArtistList = mArtistList;
	}




	public ArrayList<String> getM_AlbumList() {
		return m_AlbumList;
	}




	public void setM_AlbumList(ArrayList<String> mAlbumList) {
		m_AlbumList = mAlbumList;
	}



	/***     Setter Getter Of Hashtable User Data *******************/

	public Map<String, String> getUserConfTempDetail() {
		return userConfTempDetail;
	}

	public void setUserConfTempDetail(Map<String, String> userConfTempDetail) {
		this.userConfTempDetail = userConfTempDetail;
	}





	public String getSmsTemplateId(){
		if (!checkSession().equalsIgnoreCase("success")) {
			return checkSession();

		} else {
			m_rpManager=new RatePlanManagerNew();
			m_tempConfigManager=new TemplateConfigureManager();
			logger.info("Inside getSmsTemplateId "+m_rpManager);
			try{

				templateSMSList=m_rpManager.getSMSTemplateList();
				m_tempConfigManager=new TemplateConfigureManager();
				userConfTempDetail=new Hashtable<String, String>();

				TSSJavaUtil.instance();
				m_CategoryParams=TSSJavaUtil.getCategory_params();
				TSSJavaUtil.instance();
				m_RbtCode=TSSJavaUtil.getRbt_params();
				m_ArtistList=TSSJavaUtil.instance().getM_artistNameList();
				m_AlbumList=TSSJavaUtil.instance().getM_albumNameList();

				m_tempConfigManager.getAllDataOfTempConf(userConfTempDetail);//Detail oF added User
				Gson gson = new Gson(); 
				jsonTempConf = gson.toJson(userConfTempDetail); 
				logger.info(" SMS_TEMPLATES="+templateSMSList.size() +"Category HashTable size: ["+m_CategoryParams.size()+"] RbtCodes List Size ["+m_RbtCode.size()+"] Artist List Size ["+m_ArtistList.size()+"] Added User Detail is: ["+userConfTempDetail.size()+"] Json String is: ["+jsonTempConf+"]");

				m_userStatusList=new ArrayList<UserStatusBean>();
				m_tempConfigManager.modifyViralSMSConfig(m_userStatusList);
				
				

				logger.info("Modify Data is: ["+m_userStatusList.get(0).getM_unitBean().get(0).getM_dataId());

			}catch (Exception e) {
				logger.error("ERROR in getSmsTemplateId()",e);
				return ERROR;
			}
		}
		return SUCCESS;
	}/// ### END of getSmsTemplateId () ###//







	public String addConfTemplate(){
		String l_result="error";
		if (!checkSession().equalsIgnoreCase("success")) {
			return checkSession();

		} else {

			logger.info("Inside function addConfTemplate()......");

			try{
				int l_retval=-1;
				m_tempConfigManager=new TemplateConfigureManager();
				for(int i=0;i<m_TempConfData.getM_TemplateConf().size();i++)
				{
					logger.info("Category Value is: "+m_TempConfData.getM_TemplateConf().get(i).getM_CategoryHashTable() + "] For Same RBT::: ["+m_TempConfData.getM_TemplateConf().get(i).getM_ForSameRbtTempId()+"] Artist Value is: ["+m_TempConfData.getM_TemplateConf().get(i).getM_artistHashTable()+"] RBT Code: ["+m_TempConfData.getM_TemplateConf().get(i).getM_rbtHashTable()+"] User Status is: ["+m_TempConfData.getM_TemplateConf().get(i).getM_userStatus()+"]");


					l_retval=m_tempConfigManager.addTemplateConfiguration(m_TempConfData.getM_TemplateConf().get(i));
				}
				if(l_retval<0){
					this.message=getText("tryLater");
					this.actionName="goBack";
				}else{
					this.message=getText("addSuccess");
					this.actionName="viewConfTemp.action";
				}
				l_result="success";
				//m_tempConfigManager=null;
				//m_TempConfData=null;
			}catch (Exception e) {

				logger.error("ERROR in processing addConfTemplate!",e);

				logger.error("ERROR in addConfTemplate()",e);
				e.printStackTrace();


			}finally{
				m_rpManager=null;
			}
		}
		return l_result;
	}/// ### END of addConfTemplate () ###//



	public String viewConfTemplate(){
		if (!checkSession().equalsIgnoreCase("success")) {
			return checkSession();

		} else {
			logger.info("Inside function viewConfTemplate()......");
			ArrayList<TempConfigurationDataBean> l_TemplateConf=null;
			try{
				TSSJavaUtil.instance();
				//load all the dropdown boxes
				m_CategoryParams=TSSJavaUtil.getCategory_params();
				TSSJavaUtil.instance();
				m_RbtCode=TSSJavaUtil.getRbt_params();
				m_ArtistList=TSSJavaUtil.instance().getM_artistNameList();
				m_AlbumList=TSSJavaUtil.instance().getM_albumNameList();

				m_rpManager=new RatePlanManagerNew();
				templateSMSList=m_rpManager.getSMSTemplateList();
				logger.info("m_CategoryParams["+m_CategoryParams.size()+"]m_RbtCode["+m_RbtCode.size()+"]m_ArtistList["+m_ArtistList.size()+"]m_AlbumList["+m_AlbumList.size()+"]templateSMSList["+templateSMSList.size()+"]");

				m_tempConfigManager=new TemplateConfigureManager();
				m_TempConfData=new TemplateConfigurationMasterList();
				l_TemplateConf=new ArrayList<TempConfigurationDataBean>();
				int retval=m_tempConfigManager.loadViralSMSConfig(l_TemplateConf);
				m_TempConfData.setM_TemplateConf(l_TemplateConf);

				logger.info("viralSMSConfig size() ["+m_TempConfData.m_TemplateConf.size()+"]and retval["+retval+"]");
				//logger.info("++++++++++++++++++>>>"+m_TempConfData.m_TemplateConf.get(0).getM_userStatus());				

			}catch (Exception e) {
				logger.error("ERROR in viewConfTemplate()",e);
				e.printStackTrace();
				return ERROR;
			}finally{
				m_rpManager=null;
				l_TemplateConf=null;
			}
		}
		return SUCCESS;
	}
}//viewConfTemplate
