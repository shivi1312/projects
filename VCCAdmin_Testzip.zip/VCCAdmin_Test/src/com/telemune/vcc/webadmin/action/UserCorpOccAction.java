package com.telemune.vcc.webadmin.action;

import java.util.ArrayList;
import java.util.Iterator;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;
import com.telemune.dbutilities.Connection;
import com.telemune.vcc.common.HistoryGenerator;
import com.telemune.vcc.common.SessionHistory;
import com.telemune.vcc.common.TSSJavaUtil;
import com.telemune.vcc.common.ValidateAction;
import com.telemune.vcc.model.HistoryDataBean;
import com.telemune.vcc.webadmin.*;

public class UserCorpOccAction extends ValidateAction {

	UserCorpOccBean bean = null;
	String userId = "";
	ArrayList<UserCorpOccBean> userAl = null;

	String userUrl = "searchRole.action?bean.roleId=0&bean.username=";
	String corpUrl = "managecorp.action?bean.end=2";
	String OccUrl = "occmanage.action?bean.end=1";

	HistoryDataBean historyDataBean=null;
	HistoryGenerator historyGenerator =null;
	
	public UserCorpOccAction() {
		setLinkName("webadmin");
	}

	Logger logger = Logger.getLogger(UserCorpOccAction.class);
	private String message;

	public UserCorpOccBean getBean() {
		return bean;
	}

	public void setBean(UserCorpOccBean bean) {
		this.bean = bean;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public ArrayList<UserCorpOccBean> getUserAl() {
		return userAl;
	}

	public void setUserAl(ArrayList<UserCorpOccBean> userAl) {
		this.userAl = userAl;
	}

	// this function is for for getting the role list

	public String getRoleListFromDataBase() {
		logger.info("inside function getRoleListFromDataBase().........");
		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		} else {

			bean = new UserCorpOccBean();
			// logger.info("Inside function getRoleListFromDataBase()...");
			String retVal = "failure";
			Connection con = null;
			RoleTypeManager roleManager = null;
			ArrayList roletypesAl = null;

			try {

				con = TSSJavaUtil.instance().getconnection();
				roleManager = new RoleTypeManager();
				roletypesAl = new ArrayList();
				int i = roleManager.getRoleTypes(roletypesAl, con);
				bean.setSize(roletypesAl.size());
				bean.setDataAl(roletypesAl);
				logger.debug("inside function getRoleListFromDataBase().........Arraylist size : "
						+ bean.getDataAl().size());
			} catch (Exception exe) {
				logger.error("Exception inside getRoleListFromDataBase()...",
						exe);
			} finally {
				if (con != null)
					TSSJavaUtil.instance().freeConnection(con);

				roleManager = null;
				roletypesAl = null;

			}
			return "success";
		}

	}

	// this function is for add the user MANAGEMENT

	public String addUserMangement() {
		logger.info("inside function addUserMangement().........");
		this.actionName = userUrl;

		Connection con = null;
		String retVal = "failure";
		// logger.info("Inside function addUserMangement().. ");
		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		} else {

			AdminUserManager adminManager = new AdminUserManager();
			AdminUser adminUser = new AdminUser();

			adminUser.setUserName(bean.getUsername());
			adminUser.setPassword(bean.getPass());
			adminUser.setEmail(bean.getEmail());
			adminUser.setMobileNum(bean.getMobileNumber());
			adminUser.setRoleId(bean.getRoleId());

			try {
				con = TSSJavaUtil.instance().getconnection();
				int i = adminManager.addUser(adminUser, con);
				/*HistoryDataBean historyDataBean = null;
				HistoryGenerator historyGenerator = null;*/
				HttpServletRequest request = ServletActionContext.getRequest();
				HttpSession session = request.getSession();
				String user = ((SessionHistory) session
						.getAttribute("sessionHistory")).getUser();
				String roleName = ((SessionHistory) session
						.getAttribute("sessionHistory")).getRoleName();
				if (i < 0) {
					if (i == -2) {
						// logger.info("User already exist");
						this.setMessage(getText("alExist"));
						historyDataBean = new HistoryDataBean();
						historyDataBean.setUser(user);
						historyDataBean.setAction(getText("usermanagement"));
						historyDataBean.setEvent("Add");
						historyDataBean.setRole(roleName);
						historyDataBean.setMsg("User ["+ adminUser.getUserName()+"] Add [User Already Exist]");
						historyGenerator = new HistoryGenerator();
						historyGenerator
								.insertHistoryData(historyDataBean, con);
					} else {
						// logger.info("Please try later");
						this.setMessage(getText("tryLater"));
						historyDataBean = new HistoryDataBean();
						historyDataBean.setUser(user);
						historyDataBean.setAction(getText("usermanagement"));
						historyDataBean.setEvent("Add");
						historyDataBean.setRole(roleName);
						historyDataBean.setMsg("User ["+ adminUser.getUserName()+"] Add [Failed]");
						historyGenerator = new HistoryGenerator();
						historyGenerator
								.insertHistoryData(historyDataBean, con);
					}
				} else {
					// logger.info("User is added successfully");
					this.setMessage(getText("addSuccess"));
					historyDataBean = new HistoryDataBean();
					historyDataBean.setUser(user);
					historyDataBean.setAction(getText("usermanagement"));
					historyDataBean.setEvent("Add");
					historyDataBean.setRole(roleName);
					historyDataBean.setMsg("User ["+ adminUser.getUserName()+"] Add [Success]");
					historyGenerator = new HistoryGenerator();
					historyGenerator
							.insertHistoryData(historyDataBean, con);
				}
				logger.debug("inside function addUserMangement().........Message : "
						+ this.getMessage());
				retVal = "success";
			} catch (Exception exe) {
				logger.error("Inside fucntion addUserMangement()...", exe);
			} finally {
				adminManager = null;
				if (con != null)
					TSSJavaUtil.instance().freeConnection(con);

			}

			return retVal;

		}

	}

	// this function is for getting the details for user management roles
	public String getUserManageViewDetails() {
		logger.info("inside function getUserManageViewDetails().........");
		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		} else {

			logger.debug("inside function getUserManageViewDetails().........userName : "
					+ bean.getUsername()
					+ " || roleId :  "
					+ bean.getRoleId()
					+ " || userId : " + userId);

			Connection con = null;
			String retVal = "failure";
			// logger.info("Inside function  getUserManageViewDetails()... where pageId ["+pageId+"]");

			AdminUserManager adminManager = new AdminUserManager();
			AdminUser adminUser = new AdminUser();
			ArrayList adminUserAl = new ArrayList();
			RoleTypeManager roleManager = new RoleTypeManager();
			ArrayList roletypeAl = new ArrayList();

			int i = -1;
			// int pageCount = 0;
			// int start = -1;
			// int end = -1;
			String userName = bean.getUsername();
			if (userName != null && !userName.equalsIgnoreCase("")) {
				String action = "user";
				adminUser.setUserId(action);
			}
			int roleId = bean.getRoleId();

			adminUser.setUserName(userName);
			adminUser.setRoleId(roleId);
			adminUser.setUserId(userId);
			userAl = new ArrayList<UserCorpOccBean>();

			try {

				con = TSSJavaUtil.instance().getconnection();
				i = adminManager.getUserData(adminUserAl, adminUser, con); // roleId=0
																			// for
																			// getting
																			// data
																			// of
																			// all
																			// users.
				int x = roleManager.getRoleTypes(roletypeAl, con);
				// System.out.println("adminUserAl list size : "+adminUserAl.size());
				logger.debug("inside function getUserManageViewDetails().........Arraylist size : "
						+ adminUserAl.size());
				// if(i > 0 || adminUserAl != null || pageId != -1)
				if (i > 0 && adminUserAl != null) {

					// pageCount = adminUserAl.size()/10;

					// Object adminUserArr[] = adminUserAl.toArray();
					// start = (pageId *10) + 1;
					// end = ((start+10) > adminUserArr.length)?
					// (adminUserArr.length): (start+9) ;
					// for(int r=start; r<=end; r++)
					for (int r = 0; r < adminUserAl.size(); r++) {
						bean = new UserCorpOccBean();
						// bean.setUsername(((AdminUser)adminUserArr[i]).getUserName());
						bean.setUsername(((AdminUser) adminUserAl.get(r))
								.getUserName());

						for (int j = 0; j < roletypeAl.size(); j++) {
							RoleType roleType = (RoleType) roletypeAl.get(j);
							// if( ((AdminUser)adminUserArr[i]).getRoleId() ==
							// roleType.getRoleId() )
							if (((AdminUser) adminUserAl.get(r)).getRoleId() == roleType
									.getRoleId()) {

								// out.print(roleType.getRoleName());
								bean.setRoleName(roleType.getRoleName());
								break;
							}

						}
						userAl.add(bean);
					}
				}

				logger.debug("inside function getUserManageViewDetails().....UserAl List Size : "
						+ userAl.size());
				// bean.setUsername(userName);
				// bean.setRoleId(roleId);
				// bean.setPageId(pageId);
				// bean.setPageCount(pageCount);
				// bean.setStart(start);
				// bean.setEnd(end);
				// bean.setDataAl(dataList);
				// bean.setSize(dataList.size());
				retVal = "success";
			} catch (Exception exe) {
				logger.error("Exception inside getUserManageViewDetails()...",
						exe);
			} finally {
				adminManager = null;
				adminUser = null;
				adminUserAl = null;
				roleManager = null;
				roletypeAl = null;

				if (con != null)
					TSSJavaUtil.instance().freeConnection(con);

			}
			return retVal;
		}

	}

	// this function is for getting the data for view/MODIFY UserManagement
	// profile
	public String handleViewUserDetails() {
		logger.info("inside function handleViewUserDetails().........");
		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		} else {

			logger.debug("inside function handleViewUserDetails ....... roleId = "
					+ bean.getRoleId() + " || userName : " + bean.getUsername());
			RoleTypeManager roleManager = new RoleTypeManager();
			AdminUserManager adminManager = new AdminUserManager();
			AdminUser adminUser = new AdminUser();
			Connection con = null;
			ArrayList adminUserAl = new ArrayList();
			ArrayList roletypeAl = new ArrayList();
			String retVal = "failure";
			// String userName = bean.getUsername();
			// int roleId = 0;

			String action = "view";
			adminUser.setRoleId(bean.getRoleId());
			adminUser.setUserName(bean.getUsername());
			adminUser.setUserId(action);

			try {
				con = TSSJavaUtil.instance().getconnection();
				int k = adminManager.getUserData(adminUserAl, adminUser, con); // (ArrayList,adminUser
																				// )to
																				// get
																				// data
																				// for
																				// userName

				int i = roleManager.getRoleTypes(roletypeAl, con);

				for (int z = 0; z < adminUserAl.size(); z++) {
					adminUser = (AdminUser) adminUserAl.get(z);
					bean.setUsername(adminUser.getUserName());
					for (int j = 0; j < roletypeAl.size(); j++) {
						RoleType roleType = (RoleType) roletypeAl.get(j);
						if (adminUser.getRoleId() == roleType.getRoleId()) {
							bean.setRoleName(roleType.getRoleName());
							bean.setRoleId(roleType.getRoleId());
							break;
						}
					}

					bean.setEmail(adminUser.getEmail());
					bean.setMobileNumber(adminUser.getMobileNum());
					bean.setPass(adminUser.getPassword());
					// System.out.println("userPass : "+bean.getPass());
					bean.setRePass(adminUser.getPassword());

				}

				bean.setSize(roletypeAl.size());
				bean.setDataAl(roletypeAl);
				logger.debug("inside function handleViewUserDetails...... bean.DataAl size : "
						+ bean.getDataAl().size()
						+ "  || bean.size() : "
						+ bean.getSize());
				retVal = "success";
			} catch (Exception exe) {
				logger.error("Exception inside handleViewUserDetails().....",
						exe);
			} finally {
				adminManager = null;
				adminUser = null;
				adminUserAl = null;
				roleManager = null;
				roletypeAl = null;

				if (con != null)
					TSSJavaUtil.instance().freeConnection(con);

			}
			return retVal;
		}

	}

	// this fucntion is for update the user management details
	public String handleUpdateUserDetails() {
		logger.info("Inside function handleUpdateUserDetails()......");
		this.actionName = userUrl;

		// logger.info("Inside function handleUpdateUserDetails()......");
		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		} else {

			AdminUserManager adminManager = new AdminUserManager();
			AdminUser adminUser = new AdminUser();
			String user_name = (String) sessionMap.get("user");
			adminUser.setUserName(bean.getUsername());
			adminUser.setPassword(bean.getPass());
			adminUser.setEmail(bean.getEmail());
			adminUser.setMobileNum(bean.getMobileNumber());
			adminUser.setRoleId(bean.getRoleId());
			String retVal = "failure";
			Connection con = null;
			WebAdminLogManager webadminlogs = new WebAdminLogManager();
			WebAdminLog logobj = new WebAdminLog();
			int k = 0;
			String old_values = "USER_NAME:" + bean.getOldUsername() + ";";
			String new_values = "USER_NAME:" + bean.getUsername() + ";";
			if (!bean.getOldPass().equals(bean.getPass())) {
				old_values = old_values + "PASSWORD:" + bean.getOldPass() + ";";
				new_values = new_values + "PASSWORD:" + bean.getPass() + ";";
				k = 1;
			}
			if (!bean.getOldEmail().equals(bean.getEmail())) {
				old_values = old_values + "EMAIL:" + bean.getOldEmail() + ";";
				new_values = new_values + "EMAIL:" + bean.getEmail() + ";";
				k = 1;
			}
			if (!bean.getOldMobileNumber().equals(bean.getMobileNumber())) {
				old_values = old_values + "MOBILE_NUM:"
						+ bean.getOldMobileNumber() + ";";
				new_values = new_values + "MOBILE_NUM:"
						+ bean.getMobileNumber() + ";";
				k = 1;
			}
			if (bean.getOldRoleId() != bean.getRoleId()) {
				old_values = old_values + "ROLE_ID:" + bean.getOldRoleId()
						+ ";";
				new_values = new_values + "ROLE_ID:" + bean.getRoleId() + ";";
				k = 1;

			}
			if (k == 1) {
				logobj.setTableName("CRBT_ADMINUSER");
				logobj.setlink("usermanagementlog");
				logobj.setuser(user_name);
				logobj.setPreviousvalue(old_values);
				logobj.setCurrentvalue(new_values);
			}

			try {
				con = TSSJavaUtil.instance().getconnection();

				int i = adminManager.updateUser(adminUser, con);
				HttpServletRequest request=ServletActionContext.getRequest();
				HttpSession session=request.getSession();
				String user=((SessionHistory) session.getAttribute("sessionHistory")).getUser();
				String roleName = ((SessionHistory) session.getAttribute("sessionHistory")).getRoleName();
				if (i < 0) {
					this.setMessage(getText("tryLater"));
					historyDataBean = new HistoryDataBean();
					historyDataBean.setUser(user);
					historyDataBean.setAction(getText("usermanagement"));
					historyDataBean.setEvent("Modify");
					historyDataBean.setRole(roleName);
					historyDataBean.setMsg("User ["+ adminUser.getUserName()+"] Modify [Failed]");
					historyGenerator = new HistoryGenerator();
					historyGenerator.insertHistoryData(historyDataBean,
							con);		
				} else {
					this.setMessage(getText("modSuccess"));
					historyDataBean = new HistoryDataBean();
					historyDataBean.setUser(user);
					historyDataBean.setAction(getText("usermanagement"));
					historyDataBean.setEvent("Modify");
					historyDataBean.setRole(roleName);
					historyDataBean.setMsg("User ["+ adminUser.getUserName()+"] Modify [Success]");
					historyGenerator = new HistoryGenerator();
					historyGenerator.insertHistoryData(historyDataBean,
							con);
				}
				logger.debug("Inside function handleUpdateUserDetails()......Message: "
						+ this.getMessage());
				retVal = "success";
			} catch (Exception exe) {
				logger.error("Exception inside handleUpdateUserDetails()...",
						exe);

			} finally {
				adminManager = null;
				adminUser = null;

				if (con != null)
					TSSJavaUtil.instance().freeConnection(con);

			}
			return retVal;
		}
	}

	// this function is for handle delete userdetails from databse

	public String handleDeleteUserDetails() {
		this.actionName = userUrl;
		logger.info("Inside function handleDeleteUserDetails().....");
		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		} else {

			String retVal = "failure";
			Connection con = null;

			AdminUserManager adminManager = new AdminUserManager();

			ArrayList adminUserAl = new ArrayList();
			String adminUserArr[] = bean.getDeleteAl();

			for (int j = 0; j < adminUserArr.length; j++) {
				String userName = adminUserArr[j];
				adminUserAl.add(userName);
			}

			try {
				con = TSSJavaUtil.instance().getconnection();
				int i = adminManager.deleteUser(adminUserAl, con);
				Iterator ite = adminUserAl.iterator ();
				String delUser = "";
				while(ite.hasNext ())
				{
					 delUser+= (String)ite.next ();
					 delUser+=" ";
				}
				
				HttpServletRequest request=ServletActionContext.getRequest();
				HttpSession session=request.getSession();
				String user=((SessionHistory) session.getAttribute("sessionHistory")).getUser();
				String roleName = ((SessionHistory) session.getAttribute("sessionHistory")).getRoleName();
				if (i < 0) {
					this.setMessage(getText("tryLater"));
					historyDataBean = new HistoryDataBean();
					historyDataBean.setUser(user);
					historyDataBean.setAction(getText("usermanagement"));
					historyDataBean.setEvent("Delete");
					historyDataBean.setRole(roleName);
					historyDataBean.setMsg("User ["+ delUser+"] Delete [Failed]");
					historyGenerator = new HistoryGenerator();
					historyGenerator.insertHistoryData(historyDataBean,
							con);
				} else {
					this.setMessage(getText("delSuccess"));
					historyDataBean = new HistoryDataBean();
					historyDataBean.setUser(user);
					historyDataBean.setAction(getText("usermanagement"));
					historyDataBean.setEvent("Delete");
					historyDataBean.setRole(roleName);
					historyDataBean.setMsg("User ["+delUser+"] Delete [Success]");
					historyGenerator = new HistoryGenerator();
					historyGenerator.insertHistoryData(historyDataBean,
							con);
				}
				logger.debug("Inside function handleDeleteUserDetails().....Message : "
						+ this.getMessage());
				retVal = "success";
			} catch (Exception exe) {
				logger.error("Exception inside handleDeleteUserDetails()....",
						exe);
			} finally {
				adminManager = null;
				adminUserAl = null;

				if (con != null)
					TSSJavaUtil.instance().freeConnection(con);

			}

			return retVal;
		}
	}

	// ###################################################################################################
	// ########################## Action for Corporate Management Starts Here
	// ############################

	// this function is for getting the corporate account details fo add

	// this function is for for getting the bill Plan

	/*
	 * public String getBillPlanFromDataBase() { bean= new UserCorpOccBean();
	 * logger.info("Inside fucntion getBillPlanFromDataBase()..."); String
	 * retVal="failure"; Connection con= null; try{
	 * 
	 * con= TSSJavaUtil.instance().getconnection(); CorpManager corpManager =
	 * new CorpManager(); ArrayList corptypesAl = new ArrayList(); int i =
	 * corpManager.getCorpPlanId(corptypesAl,con);
	 * TSSJavaUtil.instance().freeConnection(con);
	 * 
	 * bean.setSize(corptypesAl.size()); bean.setDataAl(corptypesAl);
	 * }catch(Exception exe) {
	 * logger.error("Exception inside getRoleListFromDataBase()...",exe);
	 * }finally{
	 * 
	 * try { TSSJavaUtil.instance().freeConnection(con); } catch (SQLException
	 * e) { // TODO Auto-generated catch block e.printStackTrace(); } } return
	 * "success";
	 * 
	 * }
	 */

	// this function is for add the corp MANAGEMENT

	public String addCorpMangement() {
		logger.info("Inside function addCorpMangement().....");
		this.actionName = corpUrl;
		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		} else {

			Connection con = null;
			String retVal = "failure";
			logger.debug("Inside function addCorpMangement().. "
					+ bean.getCorpName() + ":" + bean.getUsername() + ":"
					+ bean.getPass() + ":" + bean.getMobileNumber() + ":"
					+ bean.getPlanId());
			System.out.println("Inside function addCorpMangement().. "
					+ bean.getCorpName() + ":" + bean.getUsername() + ":"
					+ bean.getPass() + ":" + bean.getMobileNumber() + ":"
					+ bean.getPlanId());
			CorpManager corpManager = new CorpManager();
			CorpUser corpUser = new CorpUser();

			corpUser.setCorpName(bean.getCorpName());
			corpUser.setUserName(bean.getUsername());
			corpUser.setPassword(bean.getPass());
			corpUser.setChargingMsisdn(bean.getMobileNumber());
			corpUser.setPlanIndicator(bean.getPlanId());

			try {
				con = TSSJavaUtil.instance().getconnection();
				int i = corpManager.addCorporate(corpUser, con);
				System.out.println("Return type of addCorporate : " + i);
				if (i < 0) {
					if (i == -2) {
						// logger.info("User already exist");
						this.setMessage(getText("alExist"));
					} else if (i == -12) {

						logger.info("charging number not in range");
						this.setMessage(getText("webadmin.msisdnNotInRange"));
					} else if (i == -3) {

						logger.info("this msisdn is already being billed for some corporate");
						this.setMessage(getText("webadmin.alreadybilled"));
					} else {
						// logger.info("Please try later");
						this.setMessage(getText("tryLater"));
					}
				} else {
					// logger.info("User is added successfully");
					this.setMessage(getText("addSuccess"));
				}
				logger.debug("Inside function addCorpMangement().....Message : "
						+ this.getMessage());
				retVal = "success";
			} catch (Exception exe) {
				logger.error("Inside fucntion addUserMangement()...", exe);
			} finally {
				corpManager = null;
				corpUser = null;
				if (con != null)
					TSSJavaUtil.instance().freeConnection(con);
			}
			return retVal;
		}

	}

	public String getCorpDetails() {
		logger.info("Inside function getCorpDetails().....");

		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		} else {

			int id = bean.getEnd();

			logger.debug("Inside fucntion getCorpDetails()...where ID [" + id
					+ "].");
			String retVal = "failure";
			ArrayList dataAl = new ArrayList();
			CorpManager corpMan = new CorpManager();
			ArrayList corpAl = new ArrayList();
			Connection con = null;
			// bean= new UserCorpOccBean();
			ArrayList corp1Al = null;

			try {

				con = TSSJavaUtil.instance().getconnection();

				int defaultplan = Integer.parseInt(TSSJavaUtil.instance()
						.getAppConfigParam("DEFAULT_RATE_PLAN"));
				// logger.info("Default RATEPLAN= "+defaultplan);
				if (id == 1) {

					int ret = corpMan.getCorpPlanId(corpAl, con);
					// TSSJavaUtil.instance().freeConnection(con);
					// logger.info("This is the return value of getcorpDetails(),,,"+ret);
					for (int x = 0; x < corpAl.size(); x++) {
						CorpUser corpUser = (CorpUser) corpAl.get(x);
						CorpUser corp = null;
						int planId = corpUser.getPlanIndicator();
						if (planId != defaultplan) {
							corp = new CorpUser();
							corp.setPlanIndicator(planId);
							corp.setPlanRemarks(corpUser.getPlanRemarks());
							dataAl.add(corp);
						}

						// System.out.println("dataAl size : "+dataAl.size());
					}

				} else if (id == 2) {
					logger.debug("This condition handle View Corp Details");
					long corpid = 0; // to get all corporates
					String corpName = "all";
					int val = corpMan.getCorporateData(corpAl, corpid,
							corpName, con);
					// logger.info("result ::::::"+val);
					for (int x = 0; x < corpAl.size(); x++) {
						CorpUser corpUser = (CorpUser) corpAl.get(x);
						CorpUser corp = new CorpUser();
						int planId = corpUser.getPlanIndicator();
						if (corpUser.getCorpId() == 0) {
						} else {
							corp.setCorpId(corpUser.getCorpId());
							corp.setCorpName(corpUser.getCorpName());
							corp.setUserName(corpUser.getUserName());
							dataAl.add(corp);
						}

					}

				} else {
					logger.debug("This fucntion handle the Getting the data for modify corp");

					long corpId = bean.getCorpId();
					String corpName = bean.getCorpName();

					defaultplan = Integer.parseInt(TSSJavaUtil.instance()
							.getAppConfigParam("DEFAULT_RATE_PLAN"));

					corp1Al = new ArrayList();

					int ret = corpMan.getCorporateData(corpAl, corpId,
							corpName, con);
					int ret1 = corpMan.getCorpPlanId(corp1Al, con);

					for (int x = 0; x < corp1Al.size(); x++) {
						CorpUser corpUser = (CorpUser) corp1Al.get(x);
						CorpUser corp = new CorpUser();
						int planId = corpUser.getPlanIndicator();
						if (planId == defaultplan) {
						} else {
							corp.setPlanIndicator(planId);
							corp.setPlanRemarks(corpUser.getPlanRemarks());
							dataAl.add(corp);
						}

					}

					bean.setCorpAl(corpAl);
					bean.setCorpId(corpId);

				}

				bean.setSize(dataAl.size());
				bean.setDataAl(dataAl);
				retVal = "success";
			} catch (Exception exe) {
				logger.error("Exception inside getCorpDetails()......", exe);
			} finally {
				dataAl = null;
				corpMan = null;
				corpAl = null;

				if (con != null)
					TSSJavaUtil.instance().freeConnection(con);

			}
			return retVal;
		}

	}

	// this function is for delete corporate account from db
	public String handleDeleteCorp() {
		logger.info("Inside function handleDeleteCorp()...");
		this.actionName = corpUrl;
		logger.debug("Inside function handleDeleteCorp()...: "
				+ bean.getDeleteAl());
		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		} else {

			// System.out.println("Inside function handleDeleteCorp()...: "+bean.getDeleteAl());

			String retVal = "failure";
			Connection con = null;
			CorpManager corpManager = new CorpManager();
			String Arr[] = bean.getDeleteAl();
			ArrayList corpArr = new ArrayList();
			for (int x = 0; x < Arr.length; x++) {
				// logger.info("***to delete corpid= "+Arr[x]);
				// System.out.println("***to delete corpid= "+Arr[x]);
				corpArr.add(Arr[x]);
			}

			try {
				con = TSSJavaUtil.instance().getconnection();
				int i = corpManager.deleteCorpData(corpArr, con);
				if (i < 0) {
					// logger.info("webadmin/CorpManager: corporate cannot be deleted");
					this.setMessage(getText("cantDelete"));
				} else if (i == 1) {
					// logger.info("webadmin/CorpManager: Corporates deleted successfully");
					this.setMessage(getText("delSuccess"));
				}
				logger.info("Inside function handleDeleteCorp()...Message : "
						+ this.getMessage());
				retVal = "success";
			} catch (Exception exe) {
				logger.error(
						"Inside function handleDeleteCorp().....Exception in handleDeleteCorp()..",
						exe);
			} finally {
				corpManager = null;
				corpArr = null;

				if (con != null)
					TSSJavaUtil.instance().freeConnection(con);

			}

			return retVal;
		}
	}

	// this function update corp profile
	public String updateCorpProfile() {
		this.actionName = corpUrl;
		logger.info("Inside function updateCorpProfile()...");
		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		} else {

			logger.debug("Inside function updateCorpProfile()... : "
					+ bean.getCorpName() + ":" + bean.getMobileNumber() + ":"
					+ bean.getUsername() + ":" + bean.getPass() + ":"
					+ bean.getPlanId() + ":" + bean.getCorpId());

			Connection con = null;
			String retval = "failure";
			CorpManager corpManager = new CorpManager();
			CorpUser corpUser = new CorpUser();
			String user_name = (String) sessionMap.get("user");
			System.out.println("Inside function updateCorpProfile()... : "
					+ bean.getCorpName() + ":" + bean.getMobileNumber() + ":"
					+ bean.getUsername() + ":" + bean.getPass() + ":"
					+ bean.getPlanId() + ":" + bean.getCorpId());
			String msisdn = TSSJavaUtil.instance().getInternationalNumber(
					bean.getMobileNumber());
			System.out.println(msisdn);
			corpUser.setCorpName(bean.getCorpName());
			corpUser.setChargingMsisdn(bean.getMobileNumber());
			corpUser.setUserName(bean.getUsername());
			corpUser.setPassword(bean.getPass());
			corpUser.setPlanIndicator(bean.getPlanId());
			corpUser.setCorpId(bean.getCorpId());
			WebAdminLogManager webadminlogs = new WebAdminLogManager();
			WebAdminLog logobj = new WebAdminLog();
			int k = 0;
			String old_values = "CORP_ID:" + bean.getCorpId() + ";";
			String new_values = "CORP_ID:" + bean.getCorpId() + ";";
			if (!bean.getOldMobileNumber().equals(bean.getMobileNumber())) {
				old_values = old_values + "CHARGING_MSISDN:"
						+ bean.getOldMobileNumber() + ";";
				new_values = new_values + "CHARGING_MSISDN:"
						+ bean.getMobileNumber() + ";";
				k = 1;
			}
			if (bean.getPlanId() != bean.getOldPlanId()) {
				old_values = old_values + "PLAN_INDICATOR:"
						+ bean.getOldPlanId() + ";";
				new_values = new_values + "PLAN_INDICATOR:" + bean.getPlanId()
						+ ";";
				k = 1;
			}
			if (!bean.getOldPass().equals(bean.getPass())) {
				old_values = old_values + "PASSWORD:" + bean.getOldPass() + ";";
				new_values = new_values + "PASSWORD:" + bean.getPass() + ";";
				k = 1;
			}
			if (k == 1) {
				logobj.setTableName("CRBT_CORP_DETAIL");
				logobj.setlink("corpmanagementlog");
				logobj.setuser(user_name);
				logobj.setPreviousvalue(old_values);
				logobj.setCurrentvalue(new_values);
			}

			try {
				con = TSSJavaUtil.instance().getconnection();
				int i = corpManager.updateCorp(corpUser, con);
				if (i >= 0 && k == 1) {
					int res = webadminlogs.createLog(logobj, con);
					// logger.info("logs return =="+res);
				}

				if (i == -3) {

					// logger.info("webadmin/CorporateManagement: The Corporate billing msisdn already exists for other corpUser");
					this.setMessage(getText("webadmin.alExistForOtherCorp"));
				} else if (i == -12) {
					// logger.info("webadmin/CorporateManagement: The billing msisdn is not in specified range");
					this.setMessage(getText("webadmin.msisdnNotInRange"));
				} else if (i == 1) {
					// logger.info("webadmin/UserManagement: The Corporate details are modified successfully");
					this.setMessage(getText("modSuccess"));
				} else {
					this.setMessage(getText("tryLater"));
				}

				logger.debug("Inside function updateCorpProfile()...Message : "
						+ this.getMessage());
				retval = "success";

			} catch (Exception exe) {
				logger.error("Exception inside function update ", exe);

			} finally {
				corpManager = null;
				corpUser = null;
				webadminlogs = null;
				logobj = null;

				if (con != null)
					TSSJavaUtil.instance().freeConnection(con);
			}

			return retval;
		}

	}

	// ###############################################################################################
	// ################# HERE THE FUNCTIONS HANDLE THE OCCASION MANAGEMENT
	// ###########################

	// this fucntion is for ADD OCCASION ,,,,,,,,,,,,,,,,,,,,,,
	public String addOccasion() {
		this.actionName = OccUrl;
		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		} else {

			String retVal = "failure";
			Connection con = null;
			logger.info("Inside function addOccasion().....");
			logger.debug("Inside function addOccasion()..... : "
					+ bean.getOccName() + ":" + bean.getDate() + ":"
					+ bean.getIsConsistence() + ":" + bean.getDesc());
			OccasionManager ocManager = new OccasionManager();
			Occasion ocob = new Occasion();
			ocob.setOccasionName(bean.getOccName());
			ocob.setOccasionDate(bean.getDate());
			ocob.setIsConstant(bean.getIsConsistence());
			ocob.setDescription(bean.getDesc());
			try {
				con = TSSJavaUtil.instance().getconnection();
				int i = ocManager.addOccasion(ocob, con);
				if (i < 0) {
					if (i == -2) {
						// logger.info("webadmin/OccassionManagement: The Occasion name already exists");
						this.setMessage(getText("alExist"));
					} else {
						this.setMessage(getText("tryLater"));
					}

				} else if (i > 0) {
					// logger.info("webadmin/OccassionManagement: The Occasion is added Successfully");
					this.setMessage(getText("addSuccess"));
				}
				logger.debug("Inside function addOccasion().....Message : "
						+ this.getMessage());
				retVal = "success";

			} catch (Exception e) {
				// TODO: handle exception
				logger.error("Exception in addOccasion(),,,,,,", e);
			} finally {
				ocManager = null;
				ocob = null;
				if (con != null)
					TSSJavaUtil.instance().freeConnection(con);
			}
			return retVal;
		}

	}

	// this fucntion handle the data for View And For MOdify Ocaasion
	public String getOccasionDetails() {
		logger.info("Inside function getOccasionDetails()");
		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		} else {

			int id = bean.getEnd();
			String retVal = "failure";
			Connection con = null;
			logger.debug("Inside function getOccasionDetails() Where id [" + id
					+ "]");
			OccasionManager ocManager = null;
			ArrayList ocAl = null;
			System.out
					.println("Inside function getOccasionDetails() Where id ["
							+ id + "]");
			try {
				con = TSSJavaUtil.instance().getconnection();
				if (id == 1) {
					logger.debug("Inside function getOccasionDetails() ......This is for getting details for view");
					ocManager = new OccasionManager();
					ocAl = new ArrayList();
					int val = ocManager.getOccasions(ocAl, con);
					logger.debug("Inside function getOccasionDetails() .......occasion list size : "
							+ ocAl.size());
					bean.setDataAl(ocAl);
					bean.setSize(ocAl.size());
				} else {
					String ocName = bean.getOccName();
					ocAl = new ArrayList();
					ocManager = new OccasionManager();
					int ret = ocManager.getOccasions(ocAl, ocName, con);
					for (int i = 0; i < ocAl.size(); i++) {
						Occasion ocob = (Occasion) ocAl.get(i);
						bean.setOccName(ocob.getOccasionName());
						bean.setDate(ocob.getOccasionDate());
						bean.setIsConsistence(ocob.getIsConstant());
						bean.setDesc(ocob.getDescription());
						bean.setOldOccName(ocob.getOccasionName());
						bean.setOldDate(ocob.getOccasionDate());
						bean.setOldIsConsistence(ocob.getIsConstant());
						bean.setOldDesc(ocob.getDescription());
					}
				}

				retVal = "success";

			} catch (Exception ex) {
				logger.error("Exception inside getOccasionsDetails().....", ex);
			} finally {
				ocAl = null;
				ocManager = null;
				if (con != null)
					TSSJavaUtil.instance().freeConnection(con);
			}

			return retVal;
		}
	}

	// this fucntion is for delete the occasions
	public String deleteOccasions() {
		logger.info("Inside function deleteOccasions() ......");
		this.actionName = OccUrl;
		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		} else {

			String retVal = "failure";
			Connection con = null;

			OccasionManager ocManager = new OccasionManager();
			ArrayList ocArr = new ArrayList();

			try {
				con = TSSJavaUtil.instance().getconnection();
				String Arr[] = bean.getDeleteAl();
				for (int x = 0; x < Arr.length; x++) {
					ocArr.add(Arr[x]);
				}
				int i = ocManager.deleteOccasion(ocArr, con);

				if (i < 0) {
					// logger.info("webadmin/OccasionManager: occasion cannot be deleted");
					this.setMessage(getText("cantDelete"));
				} else if (i == 1) {
					// logger.info("webadmin/OccasionManager: Occassion deleted successfully");
					this.setMessage(getText("delSuccess"));
				}
				logger.info("Inside function deleteOccasions() ......Message : "
						+ this.getMessage());
				retVal = "success";

			} catch (Exception exe) {
				logger.error("Inside function deleteOccasions()...", exe);
			} finally {
				ocArr = null;
				ocManager = null;

				if (con != null)
					TSSJavaUtil.instance().freeConnection(con);

			}
			return retVal;
		}
	}

	// this function is for update the occasion details

	public String updateOccasionDetails() {
		logger.info("Inside function updateOccasionDetails() ......");
		this.actionName = OccUrl;
		if (!checkSession().equalsIgnoreCase("success")) {
			return "error";
		} else {

			String retVal = "failure";
			Connection con = null;
			OccasionManager ocManager = new OccasionManager();
			Occasion ocob = new Occasion();
			logger.debug("Inside function updateOccasionDetails() ...... : "
					+ bean.getOccName() + ":" + bean.getDate() + ":"
					+ bean.getIsConsistence() + ":" + bean.getDesc());
			// System.out.println("Inside function updateOccasionDetails() ...... : "+bean.getOccName()+":"+bean.getDate()+":"+bean.getIsConsistence()+":"+bean.getDesc());
			try {
				con = TSSJavaUtil.instance().getconnection();

				String user_name = (String) sessionMap.get("user");

				ocob.setOccasionName(bean.getOccName());
				String oldName = bean.getOldOccName();
				ocob.setOccasionDate(bean.getDate());
				ocob.setIsConstant(bean.getIsConsistence());
				ocob.setDescription(bean.getDesc());

				WebAdminLogManager webadminlogs = new WebAdminLogManager();
				WebAdminLog logobj = new WebAdminLog();
				int k = 0;
				String old_values = "OCCASION_NAME:" + bean.getOldOccName()
						+ ";";
				String new_values = "OCCASION_NAME:" + bean.getOccName() + ";";
				if (!bean.getOldDate().equals(bean.getDate())) {
					old_values = old_values + "OCCASION_DATE:"
							+ bean.getOldDate() + ";";
					new_values = new_values + "OCCASION_DATE:" + bean.getDate()
							+ ";";
					k = 1;
				}
				if (!bean.getOldIsConsistence().equals(bean.getIsConsistence())) {
					old_values = old_values + "IS_CONSTANT:"
							+ bean.getOldIsConsistence() + ";";
					new_values = new_values + "IS_CONSTANT:"
							+ bean.getIsConsistence() + ";";
					k = 1;
				}
				if (!bean.getOldDesc().equals(bean.getDesc())) {
					old_values = old_values + "DESCRIPTION:"
							+ bean.getOldDesc() + ";";
					new_values = new_values + "DESCRIPTION:" + bean.getDesc()
							+ ";";
					k = 1;
				}
				if (k == 1) {
					logobj.setTableName("CRBT_OCCASION_LIST");
					logobj.setlink("occmanagementlog");
					logobj.setuser(user_name);
					logobj.setPreviousvalue(old_values);
					logobj.setCurrentvalue(new_values);
				}
				int i = ocManager.updateOccasion(ocob, oldName, con);
				System.out.println("return value of updateOccasion() : " + i);
				if (i >= 0 && k == 1) {
					int res = webadminlogs.createLog(logobj, con);
					// logger.info("logs return =="+res);
				}
				if (i == 1) {
					// logger.info("webadmin/OccasionManagement: The Occasion details are modified successfully");
					this.setMessage(getText("modSuccess"));
				} else if (i == -2) {
					// logger.info("webadmin/OccasionManagement: name exists already");
					this.setMessage(getText("alExist"));
				} else {
					this.setMessage(getText("tryLater"));
				}
				logger.debug("Inside function updateOccasionDetails() ......Message : "
						+ this.getMessage());
				retVal = "success";

			} catch (Exception exe) {
				logger.error("Inside function deleteOccasions()...", exe);
			} finally {
				ocManager = null;
				ocob = null;
				if (con != null)
					TSSJavaUtil.instance().freeConnection(con);

			}
			return retVal;
		}
	}

}
