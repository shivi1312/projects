package com.telemune.vcc.webadmin.action;

import java.util.ArrayList;

public class UserCorpOccBean {

//private String
	private String username;
	private int roleId;
	private String pass;
	private String rePass;
	private String email;
	private String mobileNumber;
	private int size;
	private int pageId;
	private String roleName;
	private int pageCount;
	private int start;
	private int end;
	
	private String[] deleteAl;
	private String oldRoleName;
	private String oldUsername;
	private int oldRoleId;
	private String oldPass;
	private String oldRePass;
	private String oldEmail;
	private String oldMobileNumber;
	private long corpId;
	private String corpName;
	private ArrayList corpAl= new ArrayList();
	private int planId;
	
	
	public int getPlanId() {
		return planId;
	}
	public void setPlanId(int planId) {
		this.planId = planId;
	}
	private String occName;
	private String date;
	private String desc;
	private String isConsistence;
	private String oldOccName;
	private String oldDate;
	private String oldDesc;
	private String oldIsConsistence;
	private int oldPlanId;
	
	
	
	
	public int getOldPlanId() {
		return oldPlanId;
	}
	public void setOldPlanId(int oldPlanId) {
		this.oldPlanId = oldPlanId;
	}
	
	
	
	public String getOccName() {
		return occName;
	}
	public void setOccName(String occName) {
		this.occName = occName;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public String getIsConsistence() {
		return isConsistence;
	}
	public void setIsConsistence(String isConsistence) {
		this.isConsistence = isConsistence;
	}
	public String getOldOccName() {
		return oldOccName;
	}
	public void setOldOccName(String oldOccName) {
		this.oldOccName = oldOccName;
	}
	public String getOldDate() {
		return oldDate;
	}
	public void setOldDate(String oldDate) {
		this.oldDate = oldDate;
	}
	public String getOldDesc() {
		return oldDesc;
	}
	public void setOldDesc(String oldDesc) {
		this.oldDesc = oldDesc;
	}
	public String getOldIsConsistence() {
		return oldIsConsistence;
	}
	public void setOldIsConsistence(String oldIsConsistence) {
		this.oldIsConsistence = oldIsConsistence;
	}
	public String getOldRoleName() {
		return oldRoleName;
	}
	public void setOldRoleName(String oldRoleName) {
		this.oldRoleName = oldRoleName;
	}
	public ArrayList getCorpAl() {
		return corpAl;
	}
	public void setCorpAl(ArrayList corpAl) {
		this.corpAl = corpAl;
	}
	public long getCorpId() {
		return corpId;
	}
	public void setCorpId(long corpId) {
		this.corpId = corpId;
	}
	public String getCorpName() {
		return corpName;
	}
	public void setCorpName(String corpName) {
		this.corpName = corpName;
	}
	public String[] getDeleteAl() {
		return deleteAl;
	}
	public void setDeleteAl(String[] deleteAl) {
		this.deleteAl = deleteAl;
	}
	public String getOldUsername() {
		return oldUsername;
	}
	public void setOldUsername(String oldUsername) {
		this.oldUsername = oldUsername;
	}
	public int getOldRoleId() {
		return oldRoleId;
	}
	public void setOldRoleId(int oldRoleId) {
		this.oldRoleId = oldRoleId;
	}
	public String getOldPass() {
		return oldPass;
	}
	public void setOldPass(String oldPass) {
		this.oldPass = oldPass;
	}
	public String getOldRePass() {
		return oldRePass;
	}
	public void setOldRePass(String oldRePass) {
		this.oldRePass = oldRePass;
	}
	public String getOldEmail() {
		return oldEmail;
	}
	public void setOldEmail(String oldEmail) {
		this.oldEmail = oldEmail;
	}
	public String getOldMobileNumber() {
		return oldMobileNumber;
	}
	public void setOldMobileNumber(String oldMobileNumber) {
		this.oldMobileNumber = oldMobileNumber;
	}
	public int getStart() {
		return start;
	}
	public void setStart(int start) {
		this.start = start;
	}
	public int getEnd() {
		return end;
	}
	public void setEnd(int end) {
		this.end = end;
	}
	public int getPageCount() {
		return pageCount;
	}
	public void setPageCount(int pageCount) {
		this.pageCount = pageCount;
	}
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	public int getPageId() {
		return pageId;
	}
	public void setPageId(int pageId) {
		this.pageId = pageId;
	}
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public String getRePass() {
		return rePass;
	}
	public void setRePass(String rePass) {
		this.rePass = rePass;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	private ArrayList dataAl= new ArrayList();
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public int getRoleId() {
		return roleId;
	}
	public void setRoleId(int roleId) {
		this.roleId = roleId;
	}
	public ArrayList getDataAl() {
		return dataAl;
	}
	public void setDataAl(ArrayList dataAl) {
		this.dataAl = dataAl;
	}
	
	
	
	
	
}
