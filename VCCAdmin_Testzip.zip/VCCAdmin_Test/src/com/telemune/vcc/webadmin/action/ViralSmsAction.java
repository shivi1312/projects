package com.telemune.vcc.webadmin.action;

import java.util.ArrayList;
import org.apache.log4j.Logger;
import com.telemune.dbutilities.Connection;
import com.telemune.vcc.common.TSSJavaUtil;
import com.telemune.vcc.common.ValidateAction;
import com.telemune.vcc.webadmin.ViralSMSRange;
import com.telemune.vcc.webadmin.ViralSmsAllowedRange;

public class ViralSmsAction extends ValidateAction {

	private String message;
	ViralSmsBean bean= null;
	Logger logger=Logger.getLogger(ViralSmsAction.class);
	
	{
		setLinkName("webadmin");
		this.actionName="viewViralRange.action?bean.srchTxt=X";		
	}
	ViralSmsAllowedRange allowedRange;
	
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public ViralSmsBean getBean() {
		return bean;
	}

	public void setBean(ViralSmsBean bean) {
		this.bean = bean;
	}

	public ViralSmsAllowedRange getAllowedRange() {
		return allowedRange;
	}

	public void setAllowedRange(ViralSmsAllowedRange allowedRange) {
		this.allowedRange = allowedRange;
	}

	
// this function is for add the viral sms range
	
	public String handleViralSmsRangeAdd()
	{
		logger.info("Inside function handleViralSmsRangeAdd().........");
		if(!checkSession().equalsIgnoreCase("success")){
			return "error";
			}else{
				
		//System.out.println("Inside function handleViralSmsRangeAdd().........");
		  Connection con= null;
		  String retVal="failure";
		  ViralSMSRange NewRange =null;
		  try{
		  con=TSSJavaUtil.instance().getconnection();
		  	
		  String msisdn=bean.getRange();
          NewRange = new ViralSMSRange();
          int res=NewRange.addNewRange(msisdn);
          logger.info("return value=="+res);

          if(res == -2 )
          {
        	  		//logger.info("Msisdn Range already exists");
        	  		System.out.println("Msisdn Range already exists");
        	  		this.setMessage(getText("alExist"));
          }
      else if(res == 0 )
          {
                  //logger.info("Msisdn Range added successfully!!!");
                  System.out.println("Msisdn Range added successfully!!!");
                  this.setMessage(getText("addSuccess"));
           }
          else
                {
        	  this.setMessage(getText("tryLater"));
                    //  logger.info("Please try later");
          }

          retVal="success";
          
		  }catch(Exception e)
		  {
		  logger.error("Exception inside handleViralSmsRangeAdd().........",e);
		  e.printStackTrace();
		  }finally
		  {
			  NewRange=null;
		  	if(con!=null)
		  		try {
		  			TSSJavaUtil.instance().freeConnection(con);
		  		} catch (Exception e) {
		  			// TODO Auto-generated catch block
		  			e.printStackTrace();
		  		}
		  }
		return retVal;
			}
		
	}
	
	
// this function is for handle the data for virl sms
	
/*public String getViralDetail()
{
	logger.info("Inside function getViralDetail()....");
	  Connection con= null;
	  String retVal="failure";
	  try{
		con=TSSJavaUtil.instance().getconnection();
		String searchtext="";
	    String order="";
	    int searchId=0;
	    String keywords="";
	    searchtext = bean.getSrchTxt();
	    order = bean.getOrder();
	    searchId =bean.getSrchId();
	    System.out.println(bean.getSrchTxt()+"   "+bean.getOrder()+"  "+bean.getSrchId());
	    if(searchId==1)
	    {
	            if(order.equals("ASC"))
	            {
	                    order="DESC";
	            }
	            else
	            {
	                    order="ASC";
	            }
	    }
	    else{
	            order="ASC";
	    }
	    ViralSMSRange viralsmsrange  = new ViralSMSRange();
	    ArrayList chargecode= new ArrayList();
	    ArrayList al=new ArrayList();
	    al.clear();
	    int i = -1;
	    int pageId = -1;
	    int pageCount = 0;
	  
	    pageId = bean.getPageId();
	    
	    if(pageId == 0)
	          {
	                    i = viralsmsrange.getviralmsisdn (chargecode,order,searchtext,con);
	                   logger.info("webadmin/Viral Range: chargecode size= "+ chargecode.size()+"    return is "+i );
	                   System.out.println("webadmin/Viral Range: chargecode size= "+ chargecode.size()+"    return is "+i );

	           }
	           else
	            {
	                    i = viralsmsrange.getviralmsisdn (chargecode,order,searchtext,con);
	            }
	
	     
	     if(( chargecode != null || pageId != -1) && chargecode.size()!=0)
	    {
	            pageCount = chargecode.size()/10;
	            int size=chargecode.size();
	             Object chargecodeArr[] = chargecode.toArray();

	             int start = (pageId *10) + 1;
	             int end = ((start+10) > chargecodeArr.length)? (chargecodeArr.length): (start+9) ;
	             for(int r=start; r<=end; r++)
	            {
	              ViralSmsBean bean1=new ViralSmsBean();   
	              bean1.setChgCode((Integer)chargecodeArr[r-1]);
	              logger.info(" chcode"+chargecodeArr[r-1]);
	                 al.add(bean1);
	             }
	                            bean.setDataAl(al);
	                            bean.setOrder(order);
	                            bean.setPageId(pageId);
	                            bean.setPageCount(pageCount);
	                            bean.setSrchId(searchId);
	                            bean.setSrchTxt(searchtext);
	                            bean.setEnd(end);
	                            bean.setStart(start);
	                            bean.setSize(size);
	                           
	    }
	  
	    bean.setSize(0);
	    retVal="success"; 
	  }catch(Exception e)
	  {
	  logger.error("Exception inside getViralDetail()......",e);
	  e.printStackTrace();
	  }finally
	  {
	  	if(con!=null)
	  		try {
	  			TSSJavaUtil.instance().freeConnection(con);
	  		} catch (Exception e) {
	  			// TODO Auto-generated catch block
	  			e.printStackTrace();
	  		}
	  }
return retVal;	
}
	
*/
// this function handle the Modify Viral sms range
public String handleModifyViralRange()
{
	
	logger.info("inside function handleModifyViralRange().......");
	if(!checkSession().equalsIgnoreCase("success")){
		return "error";
		}else{
			
	//System.out.println("inside function handleModifyViralRange().......");
	// System.out.println(allowedRange.getRangeId());
		Connection con= null;
		String retVal="failure";
		ViralSMSRange viralsmsrange  = null;
	  try{
		con=TSSJavaUtil.instance().getconnection();
		viralsmsrange  = new ViralSMSRange();
		 viralsmsrange.rangeEdit(allowedRange.getMsisdnRange(),allowedRange.getRangeId());
		retVal="success";
		
	  }
	  catch(Exception e)
	  {
	  logger.error("Exception inside handleModifyViralRange()......",e);
	  e.printStackTrace();
	  }finally
	  {
		  viralsmsrange=null;
		  if(retVal.equals("success"))	
			  this.setMessage(getText("modSuccess"));
		  else
			  this.setMessage(getText("tryLater"));
			  
			  
	  	if(con!=null)
	  		try {
	  			TSSJavaUtil.instance().freeConnection(con);
	  		} catch (Exception e) {
	  			// TODO Auto-generated catch block
	  			e.printStackTrace();
	  		}
	  }
	  return retVal ;
		}
	  
}


public String modify()
{
	if(!checkSession().equalsIgnoreCase("success")){
		return "error";
		}else{
			
	return "success";
		}
}


	public String getViralDetail()
	{
		
		
			logger.info("Inside function getViralDetail()....");
			if(!checkSession().equalsIgnoreCase("success")){
				return "error";
				}else{
					
			Connection con= null;
			String retVal="failure";
			  ViralSMSRange viralsmsrange  = new ViralSMSRange();
			   ArrayList<ViralSmsAllowedRange> chargecode= new ArrayList();
			  
		  try{
			con=TSSJavaUtil.instance().getconnection();
			String order="";
		    String searchtext = bean.getSrchTxt();
		    
		    
		    int i = viralsmsrange.getViralmsisdn(chargecode,searchtext,con);
            logger.debug("webadmin/Viral Range: chargecode size= "+ chargecode.size()+"    return is "+i );
           // System.out.println("webadmin/Viral Range: chargecode size= "+ chargecode.size()+"    return is "+i );
            bean.setDataAl(chargecode);
		   
		    retVal="success";
		    
		    
		    
		  }catch(Exception e)
		  {
		  logger.error("Exception inside getViralDetail()......",e);
		  }finally
		  {
			  viralsmsrange=null;
			  chargecode=null;
		  	if(con!=null)
		  		try {
		  			TSSJavaUtil.instance().freeConnection(con);
		  		} catch (Exception e) {
		  			// TODO Auto-generated catch block
		  			e.printStackTrace();
		  		}
		  }
		  
		
		return retVal;
				}
	}
}
