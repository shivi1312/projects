package com.telemune.vcc.webadmin.action;

import java.util.ArrayList;

public class ViralSmsBean {
	
	private String range;
	private String order;
	private String srchTxt;
	private int srchId;
	private ArrayList dataAl= new ArrayList();
	private int pageId;
	private int pageCount;
	private int start;
	private int end;
	private int chgCode;
	private int size;
	private String[] deleteAl;
	
	
	public String[] getDeleteAl() {
		return deleteAl;
	}
	public void setDeleteAl(String[] deleteAl) {
		this.deleteAl = deleteAl;
	}
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	public int getChgCode() {
		return chgCode;
	}
	public void setChgCode(int chgCode) {
		this.chgCode = chgCode;
	}
	public int getPageId() {
		return pageId;
	}
	public void setPageId(int pageId) {
		this.pageId = pageId;
	}
	
	
	public int getPageCount() {
		return pageCount;
	}
	public void setPageCount(int pageCount) {
		this.pageCount = pageCount;
	}
	public int getStart() {
		return start;
	}
	public void setStart(int start) {
		this.start = start;
	}
	public int getEnd() {
		return end;
	}
	public void setEnd(int end) {
		this.end = end;
	}
	public String getRange() {
		return range;
	}
	public void setRange(String range) {
		this.range = range;
	}
	public String getOrder() {
		return order;
	}
	public void setOrder(String order) {
		this.order = order;
	}
	public String getSrchTxt() {
		return srchTxt;
	}
	public void setSrchTxt(String srchTxt) {
		this.srchTxt = srchTxt;
	}
	public int getSrchId() {
		return srchId;
	}
	public void setSrchId(int srchId) {
		this.srchId = srchId;
	}
	public ArrayList getDataAl() {
		return dataAl;
	}
	public void setDataAl(ArrayList dataAl) {
		this.dataAl = dataAl;
	}
	
	

}
