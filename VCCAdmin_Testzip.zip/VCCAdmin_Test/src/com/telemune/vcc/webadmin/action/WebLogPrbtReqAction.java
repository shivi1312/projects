package com.telemune.vcc.webadmin.action;

import java.util.ArrayList;
import org.apache.log4j.Logger;
import com.telemune.dbutilities.Connection;
import com.telemune.vcc.common.TSSJavaUtil;
import com.telemune.vcc.common.ValidateAction;
import com.telemune.vcc.webadmin.*;

public class WebLogPrbtReqAction extends ValidateAction {

	
	WebLogPrbtReqBean bean= null;
	private String message;
	Logger logger=Logger.getLogger(WebLogPrbtReqAction.class);
	
	
	
public WebLogPrbtReqBean getBean() {
		return bean;
	}
	public void setBean(WebLogPrbtReqBean bean) {
		this.bean = bean;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

public WebLogPrbtReqAction()
{
	setLinkName("webadmin");
}
	
	
	// this function is for handle the PRBT request
public String handlePrbtRequest()
{
	logger.info("Inside function handlePrbtRequest()........");
	if(!checkSession().equalsIgnoreCase("success")){
		return "error";
		}else{
			
	  Connection con= null;
	  String retVal="failure";
	  RequestNewCrbt reqMan=null;
	  ArrayList<RequestNewCrbt> reqAl =  null;
	  
	  try{
	  con=TSSJavaUtil.instance().getconnection();
	  String startDate=bean.getStDate();
	  String endDate=bean.getEdDate();

	startDate+=" 00:00:00";
	endDate+=" 23:00:00";
	 logger.debug("startDate========["+startDate+"] endDate=========="+endDate);
	 reqMan=new RequestNewCrbt();
	 reqAl =  new ArrayList<RequestNewCrbt>();
	 int val = reqMan.viewRequest(reqAl,startDate,endDate,con);
	 TSSJavaUtil.instance().freeConnection(con);
	 if(val<0)
	 {
		 this.setMessage(getText("tryLater"));
		 retVal="success";
	 }else
	 {
		 bean.setDataAl(reqAl);
		 bean.setSize(reqAl.size());
		 retVal="result";
	 }
	  }catch(Exception e)
	  {
	  logger.error("Exception inside handlePrbtRequest().....",e);
	  }finally
	  {
		  reqAl=null;
		  reqMan=null;
	  	if(con!=null)
	  		try {
	  			TSSJavaUtil.instance().freeConnection(con);
	  		} catch (Exception e) {
	  			// TODO Auto-generated catch block
	  			e.printStackTrace();
	  		}
	  }

	return retVal;
		}
	
}
	
	

// this function is for handle the web log details 

public String handleWebLogsDetails()
{	
	logger.info("Inside function handleWebLogsDetails().....");
	if(!checkSession().equalsIgnoreCase("success")){
		return "error";
		}else{
			
	int id=bean.getId();
	  Connection con= null;
	  String retVal="failure";
	  ArrayList linkLogs=null;
	  WebAdminLogManager webMan=null;
	  
	  try{
	  con=TSSJavaUtil.instance().getconnection();
	  
	  if(id==1)
	  {
      bean=new WebLogPrbtReqBean();
	  linkLogs=new ArrayList();
	  webMan=new WebAdminLogManager();
	  webMan.getLinks(linkLogs,con);
	  bean.setDataAl(linkLogs);
	  bean.setSize(linkLogs.size());
	  }else
	  {
		  //bean=new WebLogPrbtReqBean();
		  linkLogs=new ArrayList();
		  webMan=new WebAdminLogManager();
		  webMan.getLogWithoutPage(linkLogs, bean.getLogBy(), bean.getStDate(),bean.getEdDate(),con);
		  bean=new WebLogPrbtReqBean();
		  bean.setDataAl(linkLogs);
		  bean.setSize(linkLogs.size());
		  
		  
	  }
	  
	  TSSJavaUtil.instance().freeConnection(con);
	  }catch(Exception e)
	  {
	  logger.error("Exception inside function handleWebLogsDetails().....",e);
	  
	  }finally
	  {
		  linkLogs=null;
		  webMan=null;
		  
	  	if(con!=null)
	  		try {
	  			TSSJavaUtil.instance().freeConnection(con);
	  		} catch (Exception e) {
	  			// TODO Auto-generated catch block
	  			e.printStackTrace();
	  		}
	  }
	  return "success";
		}

	
}








}
