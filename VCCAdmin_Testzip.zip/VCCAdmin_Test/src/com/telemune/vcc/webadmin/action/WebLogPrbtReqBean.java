package com.telemune.vcc.webadmin.action;

import java.util.ArrayList;

public class WebLogPrbtReqBean {
	private String stDate;
	private String edDate;
	private ArrayList dataAl= new ArrayList();
	private int size;
	private String logBy;
	private int id;
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getStDate() {
		return stDate;
	}
	public void setStDate(String stDate) {
		this.stDate = stDate;
	}
	public String getEdDate() {
		return edDate;
	}
	public void setEdDate(String edDate) {
		this.edDate = edDate;
	}
	public ArrayList getDataAl() {
		return dataAl;
	}
	public void setDataAl(ArrayList dataAl) {
		this.dataAl = dataAl;
	}
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	public String getLogBy() {
		return logBy;
	}
	public void setLogBy(String logBy) {
		this.logBy = logBy;
	}
	

}
