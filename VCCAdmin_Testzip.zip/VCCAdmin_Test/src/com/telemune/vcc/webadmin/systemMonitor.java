package com.telemune.vcc.webadmin;

public class systemMonitor {

private int servercount;
private String header;
private String graphheader;
private String used;
private String idle;
private String imagename;
private String server;
private String parameter;
private String duration;



public int getServercount() {
	return servercount;
}
public void setServercount(int servercount) {
	this.servercount = servercount;
}
public String getGraphheader() {
	return graphheader;
}
public void setGraphheader(String graphheader) {
	this.graphheader = graphheader;
}
public String getServer() {
	return server;
}
public void setServer(String server) {
	this.server = server;
}
public String getParameter() {
	return parameter;
}
public void setParameter(String parameter) {
	this.parameter = parameter;
}
public String getDuration() {
	return duration;
}
public void setDuration(String duration) {
	this.duration = duration;
}
public String getHeader() {
	return header;
}
public void setHeader(String header) {
	this.header = header;
}
public String getUsed() {
	return used;
}
public void setUsed(String used) {
	this.used = used;
}
public String getIdle() {
	return idle;
}
public void setIdle(String idle) {
	this.idle = idle;
}
public String getImagename() {
	return imagename;
}
public void setImagename(String imagename) {
	this.imagename = imagename;
}


}
