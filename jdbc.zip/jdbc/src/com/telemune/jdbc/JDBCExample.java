package com.telemune.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JDBCExample {
	
	
	
	
   static final String DB_URL = "jdbc:mysql://192.168.1.102:3306/test_new";
   static final String USER = "umang";
   static final String PASS = "umang";
   static final String QUERY ="SELECT USERNAME,PASSWORD FROM smsc_user";

   public static void main(String[] args) {
      try(Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
    		  java.sql.Statement stmt = conn.createStatement();
         ResultSet rs = stmt.executeQuery(QUERY);
      ) {		      
//         while(rs.next()){
//        	 System.out.println("username: " + rs.getString("USERNAME"));
//        	  System.out.println(", password: " + rs.getString("PASSWORD"));
//            
//          }
    	  if(rs.next()) {             
	             String val = rs.getString("username");
	             String reason = rs.getString("password");
	             
	             System.out.println(val);
	             System.out.println(reason);

	             
	             
	           }
       } catch (SQLException e) {
          e.printStackTrace();
       } 
    }
 }
         